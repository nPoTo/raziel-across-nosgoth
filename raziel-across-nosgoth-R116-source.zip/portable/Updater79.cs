// SPDX-License-Identifier: GPL-3.0-or-later
using System;using System.IO;using System.Diagnostics;using System.Drawing;using System.Windows.Forms;using System.Threading;using System.Security.Principal;
internal static class Updater79 {
 [STAThread]static int Main(string[] args){
  Application.EnableVisualStyles();Application.SetCompatibleTextRenderingDefault(false);
  try{
   string root=null,tag=null,donor=PortableCore60.ReadDonor();for(int i=0;i+1<args.Length;i+=2){if(args[i]=="--root")root=Path.GetFullPath(args[i+1]);if(args[i]=="--tag")tag=args[i+1];if(args[i]=="--donor")donor=args[i+1];}
   if(root==null||tag==null||Path.GetFileName(root)!="RazielR60"||!PortableCore60.Host(Directory.GetParent(root).FullName))throw new IOException("Select a supported installed mod folder.");
   bool created;using(var mutex=new Mutex(true,"Local\\RazielUpdater79",out created)){if(!created)return 0;
    if(!Writable(root)){
     if(new WindowsPrincipal(WindowsIdentity.GetCurrent()).IsInRole(WindowsBuiltInRole.Administrator))throw new IOException("The mod folder is not writable.");
     mutex.ReleaseMutex();Process.Start(new ProcessStartInfo(Application.ExecutablePath,"--root "+PortableCore60.Quote(root)+" --tag "+PortableCore60.Quote(tag)+" --donor "+PortableCore60.Quote(donor)){UseShellExecute=true,Verb="runas"});return 0;
    }
    Application.Run(new DownloadWindow(root,tag,donor));mutex.ReleaseMutex();
   }return 0;
  }catch(System.ComponentModel.Win32Exception e){if(e.NativeErrorCode==1223)return 0;MessageBox.Show(e.Message,"Raziel updater");return 1;}
  catch(Exception e){MessageBox.Show(e.Message,"Raziel updater",MessageBoxButtons.OK,MessageBoxIcon.Error);return 1;}
 }
 static bool Writable(string root){string test=Path.Combine(root,".updater-write-"+Guid.NewGuid().ToString("N"));try{using(File.Create(test)){}File.Delete(test);return true;}catch{return false;}}
 internal sealed class DownloadWindow:Form {
  readonly string modRoot,tag,donorRoot;readonly ProgressBar progress=new ProgressBar();readonly Label status=new Label();readonly Button cancel=new Button();volatile bool cancelled;bool working=true;UpdateOffer79 offer;string installer;System.Windows.Forms.Timer wait;
  internal DownloadWindow(string root,string version,string donor){modRoot=root;tag=version;donorRoot=donor;Text="Raziel — Download update";ClientSize=new Size(560,180);StartPosition=FormStartPosition.CenterScreen;FormBorderStyle=FormBorderStyle.FixedDialog;MaximizeBox=false;TopMost=true;
   status.SetBounds(22,22,516,48);status.Text="Preparing "+tag+"…";progress.SetBounds(22,80,516,25);cancel.SetBounds(420,128,118,30);cancel.Text="Cancel";cancel.Click+=(s,e)=>Close();Controls.AddRange(new Control[]{status,progress,cancel});Shown+=(s,e)=>ThreadPool.QueueUserWorkItem(_=>Download());FormClosing+=(s,e)=>{if(working){cancelled=true;e.Cancel=true;cancel.Enabled=false;status.Text="Cancelling download…";}};
  }
  void Ui(Action action){if(!IsDisposed&&IsHandleCreated)try{BeginInvoke(action);}catch(InvalidOperationException){}}
  void Download(){string part=null;try{
   offer=UpdateCore79.Select(UpdateCore79.Releases(),ReleaseVersion79.Number,tag);if(offer==null)throw new IOException("This published update no longer has a verified installer.");
   installer=UpdateCore79.Destination(modRoot,tag);Directory.CreateDirectory(Path.GetDirectoryName(installer));part=installer+"."+Guid.NewGuid().ToString("N")+".part";
   using(var response=UpdateCore79.Open(offer.Url))using(var input=response.GetResponseStream())using(var output=File.Create(part))UpdateCore79.Copy(input,output,offer.Bytes,n=>Ui(()=>{progress.Value=(int)Math.Min(99,n*100/offer.Bytes);status.Text="Downloading "+tag+" — "+(n/1048576.0).ToString("0.0")+" / "+(offer.Bytes/1048576.0).ToString("0.0")+" MB";}),()=>cancelled);
   UpdateCore79.Verify(part,offer);if(cancelled)throw new OperationCanceledException();if(File.Exists(installer))File.Delete(installer);File.Move(part,installer);part=null;
   Ui(()=>{working=false;progress.Value=100;status.Text=tag+" downloaded and verified.";cancel.Text="Finish";
    if(MessageBox.Show(this,"Install "+tag+" now?\n\nSR1 and Defiance will close. Save your progress before choosing Yes.","Raziel update",MessageBoxButtons.YesNo,MessageBoxIcon.Question)!=DialogResult.Yes)return;
    // Installation consent includes closing the games. Request ordinary close,
    // never kill a process or overwrite a loaded module.
    foreach(string name in new[]{"SRX","Defiance"})foreach(var game in Process.GetProcessesByName(name)){try{game.CloseMainWindow();}catch{}finally{game.Dispose();}}
    status.Text="Closing games before installing "+tag+"…";cancel.Text="Cancel";
    wait=new System.Windows.Forms.Timer{Interval=250};wait.Tick+=(s,e)=>{if(!PortableCore60.GamesClosed())return;wait.Stop();try{UpdateCore79.Verify(installer,offer);Process.Start(new ProcessStartInfo(installer,"--update --host "+PortableCore60.Quote(Directory.GetParent(modRoot).FullName)+" --donor "+PortableCore60.Quote(donorRoot)+" --wait-pid "+Process.GetCurrentProcess().Id){UseShellExecute=true});Close();}catch(Exception failure){status.Text=failure.Message;cancel.Text="Finish";}};wait.Start();
   });
  }catch(OperationCanceledException){}catch(Exception e){Ui(()=>{status.Text="Update not installed: "+e.Message;cancel.Text="Finish";});}finally{if(part!=null&&File.Exists(part))try{File.Delete(part);}catch{}Ui(()=>{working=false;cancel.Enabled=true;if(cancelled)Close();});}}
  protected override void Dispose(bool disposing){if(disposing&&wait!=null)wait.Dispose();base.Dispose(disposing);}
 }
}
