// SPDX-License-Identifier: GPL-3.0-or-later
using System;using System.IO;using System.Net;using System.Text;using System.Linq;using System.Security.Cryptography;using System.Text.RegularExpressions;using System.Web.Script.Serialization;
internal sealed class ReleaseAsset79 {public string name,browser_download_url,digest,state;public long size;}
internal sealed class ReleaseEntry79 {public string tag_name,published_at;public bool draft;public ReleaseAsset79[] assets;}
internal sealed class UpdateOffer79 {public int Number;public string Tag,Url,Sha256;public long Bytes;}
internal static class UpdateCore79 {
 internal const string Api="https://api.github.com/repos/nPoTo/raziel-across-nosgoth/releases?per_page=100";
 internal const long Limit=268435456;
 internal static UpdateOffer79 Select(string json,int current,string exactTag=null){
  var entries=new JavaScriptSerializer{MaxJsonLength=2097152}.Deserialize<ReleaseEntry79[]>(json);UpdateOffer79 best=null;
  foreach(var release in entries??new ReleaseEntry79[0]){
   int n;var m=Regex.Match(release.tag_name??"","^R([1-9][0-9]{0,5})$");
   if(release.draft||String.IsNullOrEmpty(release.published_at)||!m.Success||!Int32.TryParse(m.Groups[1].Value,out n)||n<=current||(exactTag!=null&&release.tag_name!=exactTag))continue;
   foreach(var asset in release.assets??new ReleaseAsset79[0]){
    // GitHub normalizes spaces to dots when a release asset is uploaded.
    // Accept only the two exact version-bound names, with a matching URL.
    Uri url;string spaced="Raziel "+release.tag_name+" Setup.exe",normalized="Raziel."+release.tag_name+".Setup.exe";
    string expected="/nPoTo/raziel-across-nosgoth/releases/download/"+release.tag_name+"/"+asset.name;
    if((asset.name!=spaced&&asset.name!=normalized)||asset.state!="uploaded"||asset.size<1024||asset.size>Limit||!Regex.IsMatch(asset.digest??"","^sha256:[0-9a-fA-F]{64}$")||!Uri.TryCreate(asset.browser_download_url,UriKind.Absolute,out url)||url.Scheme!="https"||url.Host!="github.com"||!String.IsNullOrEmpty(url.UserInfo)||!String.IsNullOrEmpty(url.Query)||Uri.UnescapeDataString(url.AbsolutePath)!=expected)continue;
    if(best==null||n>best.Number)best=new UpdateOffer79{Number=n,Tag=release.tag_name,Url=url.AbsoluteUri,Sha256=asset.digest.Substring(7).ToLowerInvariant(),Bytes=asset.size};
   }
  }return best;
 }
 internal static bool DownloadHost(Uri url){return url.Scheme=="https"&&String.IsNullOrEmpty(url.UserInfo)&&(url.Host=="github.com"||url.Host=="release-assets.githubusercontent.com"||url.Host=="objects.githubusercontent.com"||url.Host=="api.github.com");}
 internal static HttpWebResponse Open(string address){
  ServicePointManager.SecurityProtocol=SecurityProtocolType.Tls12;Uri at=new Uri(address);
  for(int redirect=0;redirect<6;redirect++){
   if(!DownloadHost(at))throw new IOException("Unexpected update download destination.");
   var req=(HttpWebRequest)WebRequest.Create(at);req.AllowAutoRedirect=false;req.Timeout=8000;req.ReadWriteTimeout=8000;req.UserAgent="RazielAcrossNosgoth/"+ReleaseVersion79.Tag;req.Accept="application/vnd.github+json";
   var response=(HttpWebResponse)req.GetResponse();int code=(int)response.StatusCode;
   if(code>=300&&code<400){string location=response.Headers["Location"];response.Dispose();if(String.IsNullOrEmpty(location))throw new IOException("Missing download redirect.");at=new Uri(at,location);continue;}
   return response;
  }throw new IOException("Too many update redirects.");
 }
 internal static string Releases(){using(var response=Open(Api))using(var input=response.GetResponseStream())using(var output=new MemoryStream()){Copy(input,output,2097152,null,null);return Encoding.UTF8.GetString(output.ToArray());}}
 internal static UpdateOffer79 Check(){return Select(Releases(),ReleaseVersion79.Number);}
 internal static void Copy(Stream input,Stream output,long limit,Action<long> progress,Func<bool> cancelled){
  byte[] buffer=new byte[65536];long total=0;int n;while((n=input.Read(buffer,0,buffer.Length))>0){if(cancelled!=null&&cancelled())throw new OperationCanceledException();total+=n;if(total>limit)throw new IOException("Update exceeds the declared size.");output.Write(buffer,0,n);if(progress!=null)progress(total);}
 }
 internal static void Verify(string file,UpdateOffer79 offer){
  if(new FileInfo(file).Length!=offer.Bytes||PortableCore60.Hash(file)!=offer.Sha256)throw new IOException("Installer checksum verification failed. Nothing was installed.");
  using(var stream=File.OpenRead(file)){if(stream.ReadByte()!='M'||stream.ReadByte()!='Z')throw new IOException("The downloaded file is not a Windows installer.");}
 }
 internal static string Destination(string modRoot,string tag){if(!Regex.IsMatch(tag??"","^R[1-9][0-9]{0,5}$"))throw new IOException("Invalid update version.");string result=Path.Combine(modRoot,"updates",tag,"Raziel "+tag+" Setup.exe");if(!PortableCore60.Within(modRoot,result))throw new IOException("Invalid update path.");return result;}
}
