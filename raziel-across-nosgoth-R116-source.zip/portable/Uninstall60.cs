// SPDX-License-Identifier: GPL-3.0-or-later
using System;using System.IO;using System.Diagnostics;using System.Reflection;using System.Windows.Forms;
internal static class Uninstall60 {
 [STAThread]static int Main(string[] args){try{Application.EnableVisualStyles();string root;if(args.Length==2&&args[0]=="--root")root=args[1];else{root=Directory.GetParent(Path.GetDirectoryName(Assembly.GetExecutingAssembly().Location)).FullName;string tmp=Path.Combine(Path.GetTempPath(),"RazielR60-uninstall-"+Guid.NewGuid().ToString("N")+".exe");File.Copy(Assembly.GetExecutingAssembly().Location,tmp);Process.Start(new ProcessStartInfo(tmp,"--root "+PortableCore60.Quote(root)){UseShellExecute=true});return 0;}if(MessageBox.Show("Remove R79 and restore its backed-up files? Saves will be preserved.","Raziel R79",MessageBoxButtons.YesNo,MessageBoxIcon.Question)!=DialogResult.Yes)return 0;MessageBox.Show(InstallEngine60.Uninstall(root),"Raziel R79");return 0;}catch(Exception ex){MessageBox.Show(ex.Message,"Raziel R79",MessageBoxButtons.OK,MessageBoxIcon.Error);return 1;}}
}

