// SPDX-License-Identifier: GPL-3.0-or-later
using System;using System.IO;using System.IO.Compression;using System.Diagnostics;using System.Reflection;using System.Drawing;using System.Threading;using System.Windows.Forms;
internal sealed class UpdateInstall79:Form {
 readonly string host,donor;readonly int parentPid;readonly Label text=new Label();readonly ProgressBar progress=new ProgressBar();readonly Button finish=new Button();bool installing=true;System.Windows.Forms.Timer parentWait;
 internal UpdateInstall79(string gameRoot,string donorRoot,int parent){
  host=gameRoot;donor=donorRoot;parentPid=parent;Text="Raziel — Install "+ReleaseVersion79.Tag;ClientSize=new Size(560,180);StartPosition=FormStartPosition.CenterScreen;FormBorderStyle=FormBorderStyle.FixedDialog;MaximizeBox=false;TopMost=true;
  text.SetBounds(22,22,516,48);text.Text="Installing "+ReleaseVersion79.Tag+"…";progress.SetBounds(22,80,516,25);progress.Style=ProgressBarStyle.Marquee;finish.SetBounds(420,128,118,30);finish.Text="Finish";finish.Enabled=false;finish.Click+=(s,e)=>Close();Controls.AddRange(new Control[]{text,progress,finish});FormClosing+=(s,e)=>{if(installing)e.Cancel=true;};
  Shown+=(s,e)=>{parentWait=new System.Windows.Forms.Timer{Interval=100};parentWait.Tick+=(sender,ev)=>{try{if(parentPid>0){using(var p=Process.GetProcessById(parentPid))if(!p.HasExited&&p.ProcessName=="RazielUpdater")return;}}catch(ArgumentException){}parentWait.Stop();ThreadPool.QueueUserWorkItem(_=>Install());};parentWait.Start();};
 }
 void Install(){string outcome;bool ok=false;try{
  if(!PortableCore60.GamesClosed())throw new IOException("A game is still running. Close it and start this installer again.");
  using(var payload=Assembly.GetExecutingAssembly().GetManifestResourceStream("payload.zip")){outcome=InstallPayload(payload,host,donor);}
  ok=true;
 }catch(Exception e){outcome="Update failed.\n"+e.Message;}
 BeginInvoke((Action)(()=>{installing=false;progress.Style=ProgressBarStyle.Continuous;progress.Value=ok?100:0;text.Text=outcome;finish.Enabled=true;}));}
 protected override void Dispose(bool disposing){if(disposing&&parentWait!=null)parentWait.Dispose();base.Dispose(disposing);}
 internal static string InstallPayload(Stream payload,string host,string donor,bool verifyGames=true){
  if(payload==null||!payload.CanSeek)throw new IOException("Missing or unreadable installer payload.");
  long start=payload.Position;using(var zip=new ZipArchive(payload,ZipArchiveMode.Read,true)){var version=zip.GetEntry("RazielR60/version.txt");if(version==null)throw new IOException("Missing update version.");using(var reader=new StreamReader(version.Open()))if(reader.ReadToEnd().Trim()!=ReleaseVersion79.Tag)throw new IOException("This payload belongs to another version. Nothing was installed.");}payload.Position=start;
  InstallEngine60.Install(payload,host,donor,verifyGames);
  string versionFile=Path.Combine(host,"RazielR60","version.txt");if(File.ReadAllText(versionFile).Trim()!=ReleaseVersion79.Tag)throw new IOException("The installed version could not be verified.");
  return "DONE\nYou are now on version "+ReleaseVersion79.Tag+".";
 }
 internal static void Run(string[] args){string host=null,donor="";int parent=0;for(int i=0;i+1<args.Length;i++){if(args[i]=="--host")host=args[++i];else if(args[i]=="--donor")donor=args[++i];else if(args[i]=="--wait-pid")Int32.TryParse(args[++i],out parent);}if(String.IsNullOrEmpty(host)){MessageBox.Show("Missing SR1 installation folder.","Raziel update");return;}Application.Run(new UpdateInstall79(Path.GetFullPath(host),donor,parent));}
}
