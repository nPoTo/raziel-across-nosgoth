RAZIEL ACROSS NOSGOTH — R79

Defiance-style movement, combat and Reaver powers in Soul Reaver 1 Remastered.

REQUIRES
Windows 10/11 x64 and both installed games:
- Legacy of Kain: Soul Reaver 1 & 2 Remastered
- Legacy of Kain: Defiance Remastered
The original non-remastered games are not supported. Defiance must stay installed, but does not need to run. No extra launcher or development tools are needed.

INSTALL
1. Close both games and back up your saves and any files you replace.
2. Extract R79-Copy-Paste.zip. Copy its contents into the Soul Reaver folder containing SRX.exe.
3. Start Soul Reaver 1 normally, load a save and press F10. The F7 guide can select the installed Defiance folder if automatic detection fails.

MAIN BUTTONS
F10: mod On/Off.
F7: guide above the game. Choose Combo controls for the move list.
F6: Reaver On/Off.
F9: all powers, swords, portals, maximum HP and full mana On/Off. First press saves your current values; second press restores them for the same character/session. Stand on the ground with menus closed. Saving the game can make cheats persist.

Move: WASD / left stick. Jump: Space / A.
Attack: left click / X. Lift or air slam: right click / Y.
Target lock: hold Shift / LB. Dodge: direction + Shift + Space / direction + LB + A.
Telekinesis: F / B. Feed or finish a stunned enemy: E / RB.
Change sword: mouse wheel, Z/X / D-pad Left/Right. Select directly: 1–8.

STORY AND SWORDS
You can play unarmed up to the first Kain encounter. For the normal story, leave the mod Off until you earn the Reaver. F6 can give or remove it if you prefer.

1 Normal / Spectral: the acquired Reaver; appearance follows the realm.
2 Dark: Force Glyph.
3 Earth: Stone Glyph.
4 Water: Water Glyph.
5 Wind: Sound Glyph.
6 Fire: Fire Glyph.
7 Light: Sunlight Glyph.
8 Spirit: all Glyphs, including Shift; Material only.

Normal, Spectral and elemental swords deal 500 damage plus 300 for each unlocked elemental sword: 500 with no elemental forms, 800 with one, up to 2,300 with all six. Each unlocked element increases the damage of every standard sword. Spirit deals a fixed 5,000. Helicopter contacts use the selected sword's normal damage.

Examples from measured enemies: one Sluagh has 6,144 HP; one Ronin variant has 15,360 HP. Enemy variants can differ. A 2,300-damage sword needs 3 and 7 successful hits respectively, ignoring regeneration, resistance and special vulnerability rules. Stunned enemies may need a finisher rather than further damage.

Fill the sword meter by hitting enemies. At full charge, hold attack for one second to release its spell. Hits on stunned enemies give half the normal charge.

UPDATES
When SR1 starts, the mod checks the project's GitHub releases in the background. No newer version, no internet or a failed check: nothing appears.
If a newer version is available, choose Yes or No to download it. Yes downloads the installer EXE into the mod's updates folder with a horizontal progress bar. The file is checked before installation.
After downloading, choose Yes or No to install. Yes closes the games and updates the mod; save your progress before choosing it. No leaves the installer downloaded for later. A successful update shows DONE, the installed version and Finish. Windows may ask for administrator permission to write inside Program Files.

UNINSTALL
For a manual ZIP copy, close both games and remove only files you copied from this ZIP. Restore any originals from your backup. Keep saves and other mods. The automatic Uninstall R60.exe command is for installations made with Setup, which creates an ownership record.

This is a test release. Full campaign coverage and a second clean PC are not fully verified. If an action fails, try F10 Off and report it. The mod uses GPL-3.0-or-later. Original game files and saves are not distributed.
