// SPDX-License-Identifier: GPL-3.0-or-later
#include "../sr1-local-controller-test/host.c"
#include <assert.h>
int wmain(int argc,wchar_t **argv){
 assert(argc==2);setvbuf(stdout,NULL,_IONBF,0);
 assert(wcslen(argv[1])<ARRAYSIZE(portableReports60));
 wcscpy(portableReports60,argv[1]);
 assert(MH_Initialize()==MH_OK);
 HANDLE thread=CreateThread(NULL,0,sluaghResourceWorker80,NULL,0,NULL);assert(thread);
 printf("PID %lu\n",GetCurrentProcessId());
 assert(WaitForSingleObject(thread,90000)==WAIT_OBJECT_0);CloseHandle(thread);
 assert(InterlockedCompareExchange(&sluaghReady80,0,0)==1);
 assert(sluaghResources80.module&&sluaghResources80.vertices>0&&sluaghResources80.clipCount==48);
 puts("PASS original native Kain worker: selected executable hash, mapped AI hooks, complete RAM parser, resourcesReady=1. No SR1 actor or Defiance process.");
 return 0;
}
