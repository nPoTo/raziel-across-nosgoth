// SPDX-License-Identifier: GPL-3.0-or-later
#pragma once
// Same submitted hand/camera and private GL state as the accepted blade effect.
static bool localArmPoints108(const float palm[16],float points[3][3]){
 for(unsigned i=0;i<3;i++)for(unsigned k=0;k<3;k++){
  float dot=0,norm=0;for(unsigned a=0;a<3;a++){dot+=(localArm107.points[i][a]-palm[12+a])*palm[k*4+a];norm+=palm[k*4+a]*palm[k*4+a];}
  if(!isfinite(dot)||norm<.1f)return false;points[i][k]=dot/norm;
 }
 return true;
}
// Convex wrist -> elbow -> shoulder curve. Bone38 is the clavicle near the
// neck; stop at bone39 (upper-arm origin), using bone40 as elbow control.
// A convex Bezier cannot overshoot toward the head as the old fitted curve did.
static void localArmCurve108(float out[3],float tangent[3],const float points[3][3],float start,float t){
 const float a[3]={0,0,start};const float *b=points[(unsigned)kainPolicy110->elbowPoint],*c=points[(unsigned)kainPolicy110->shoulderPoint];
 for(unsigned k=0;k<3;k++){
  out[k]=(1-t)*(1-t)*a[k]+2*(1-t)*t*b[k]+t*t*c[k];
  tangent[k]=2*(1-t)*(b[k]-a[k])+2*t*(c[k]-b[k]);
 }
}
