// SPDX-License-Identifier: GPL-3.0-or-later
#pragma once
// Host execution policy. These functions choose no AI attacks.
static inline float kainGuideStep95(float speed,uint64_t milliseconds){
 return fmaxf(0,fminf(900,speed*fminf((float)milliseconds,50.f)*.03f));
}
static inline bool kainGuide95(const float from[3],const float target[3],float step,float radius,float next[3]){
 float delta[3],length=0;for(unsigned k=0;k<3;k++){delta[k]=target[k]-from[k];if(!isfinite(delta[k]))return false;length+=delta[k]*delta[k];}
 length=sqrtf(length);const float fraction=length>0?fminf(1,step/length):1;
 for(unsigned k=0;k<3;k++)next[k]=from[k]+delta[k]*fraction;
 return length<=step+radius;
}
static inline float kainSoleCorrection95(float minimum){return isfinite(minimum)?fmaxf(0,fminf(256,-minimum-1.5f)):0;}
static inline bool kainAirLanded95(bool grounded,float height,float floor,bool seen){return seen&&grounded&&height<=floor+48;}
static inline bool kainAirExpired95(uint64_t launch,uint64_t now){return !launch||now<launch||now-launch>=2500;}
static inline unsigned kainChargeHit96(unsigned charge){return charge>=80?100:charge+20;}
static inline bool kainHoldMessage96(uint32_t id,uint64_t now,uint64_t until){return until&&now<until&&(id==0x8000000u||id==0x8000001u);}
static inline bool kainImpulse96(const float from[3],const float toward[3],bool pull,int velocity[3]){
 float dx=toward[0]-from[0],dy=toward[1]-from[1],distance=hypotf(dx,dy);if(!isfinite(distance)||distance<1)return false;
 const float speed=pull?fminf(100,fmaxf(0,(distance-280)*.15f)):-100;
 velocity[0]=(int)lroundf(dx/distance*speed);velocity[1]=(int)lroundf(dy/distance*speed);velocity[2]=pull?100:65;return true;
}
static inline bool kainRigidBasis98(float m[16]){
 float x[3]={m[0],m[1],m[2]},y[3]={m[4],m[5],m[6]},length=sqrtf(x[0]*x[0]+x[1]*x[1]+x[2]*x[2]);if(!isfinite(length)||length<.001f)return false;
 for(unsigned k=0;k<3;k++)x[k]/=length;const float dot=x[0]*y[0]+x[1]*y[1]+x[2]*y[2];for(unsigned k=0;k<3;k++)y[k]-=x[k]*dot;
 length=sqrtf(y[0]*y[0]+y[1]*y[1]+y[2]*y[2]);if(!isfinite(length)||length<.001f)return false;for(unsigned k=0;k<3;k++){y[k]/=length;m[k]=x[k];m[4+k]=y[k];}
 m[8]=x[1]*y[2]-x[2]*y[1];m[9]=x[2]*y[0]-x[0]*y[2];m[10]=x[0]*y[1]-x[1]*y[0];return true;
}
