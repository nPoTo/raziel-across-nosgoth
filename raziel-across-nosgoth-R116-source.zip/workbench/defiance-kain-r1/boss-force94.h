// SPDX-License-Identifier: GPL-3.0-or-later
#pragma once
// R99:original Defiance AI outputs;host-only bolts.Native SR1 missile FX are not created.
typedef struct {bool active;uintptr_t player;uint32_t generation,playerGeneration,world;uint64_t born,last;uint16_t speed;float position[3];} KainForce94;
static KainForce94 kainForces94[8];static uint32_t kainForceSerial99;
static unsigned kainProjectileSeen94,kainShockSeen94,kainPowerSeen94,kainPowerCastSeen95;
static bool kainForceCurrent94(const KainForce94 *shot){
 return shot->active&&sluaghOwned80(sluagh80.actor)&&shot->player==sluagh80.player&&generation(shot->player)==shot->playerGeneration&&shot->world==sluagh80.world;
}
static void kainRetireForce94(KainForce94 *shot){
 AcquireSRWLockExclusive(&kainEffectLock95);for(unsigned i=0;i<8;i++)if(kainProjectileStars97[i].generation==shot->generation)memset(kainProjectileStars97+i,0,sizeof kainProjectileStars97[i]);ReleaseSRWLockExclusive(&kainEffectLock95);
 memset(shot,0,sizeof *shot);
}
static void kainClearForce94(void){for(unsigned i=0;i<8;i++)kainRetireForce94(kainForces94+i);kainProjectileSeen94=kainShockSeen94=kainPowerSeen94=kainPowerCastSeen95=0;}
static void kainPollForce94(const Sr1LocalFrame *frame,uint64_t now){
 for(unsigned i=0;i<8;i++){
 KainForce94 *shot=kainForces94+i;if(!shot->active)continue;
 if(!kainForceCurrent94(shot)||now<shot->born||now-shot->born>=3000||!frame->ready||frame->realm!=1||frame->worldGeneration!=shot->world||!InterlockedCompareExchange(&portableActive60,0,0)){kainRetireForce94(shot);continue;}
 int16_t destination[3];LocalSphere body;if(!readAt(shot->player+0x9c,destination,6)){kainRetireForce94(shot);continue;}
 float from[3];memcpy(from,shot->position,12);float target[3]={destination[0],destination[1],destination[2]+300.f},next[3];float radius=90;
 if(localContactSphere(shot->player,false,true,NULL,NULL,&body)){for(unsigned k=0;k<3;k++)target[k]=body.native.center[k];radius=fmaxf(radius,body.native.radius);}
 bool contact=kainGuide95(from,target,kainGuideStep95(shot->speed,now-shot->last),radius+40,next);shot->last=now;
 int16_t to[3];for(unsigned k=0;k<3;k++)to[k]=(int16_t)lroundf(next[k]);
 if(!localNativeLineClear(sluagh80.actor,shot->world,from,to)){record("kain99 force-wall generation=%u traveled=%.1f no-impact-effect=1",shot->generation,hypotf(next[0]-from[0],next[1]-from[1]));kainRetireForce94(shot);continue;}
 memcpy(shot->position,next,12);kainProjectileStar97(shot->generation,next,now);
 if(contact){const unsigned serial=shot->generation;kainRetireForce94(shot);const bool hit=kainPlayerContact96(sluagh80.actor,sluagh80.player,4096,99,false,frame,now);record("kain99 guided-contact projectile=%u hp-applied=%u",serial,hit);}
 }
}
static bool kainHurtPlayer94(uintptr_t attacker,uintptr_t target,int power,const Sr1LocalFrame *frame,uint64_t now){
 return kainPlayerContact96(attacker,target,power,0,power>=8192,frame,now);
}
static void kainBlast95(const Sr1LocalFrame *frame,uint64_t now){
 int16_t root[3],goal[3];if(!readAt(sluagh80.actor+0x9c,root,6)||!readAt(sluagh80.player+0x9c,goal,6))return;
 float source[3]={root[0],root[1],root[2]+200.f},distance=hypotf(goal[0]-root[0],goal[1]-root[1]);int16_t to[3]={goal[0],goal[1],(int16_t)(goal[2]+200)};
 kainFlash95(now);kainEffect95(source,6000,true,now);
 bool hit=distance<=6000&&abs(goal[2]-root[2])<=1800&&localNativeLineClear(sluagh80.actor,sluagh80.world,source,to)&&kainHurtPlayer94(sluagh80.actor,sluagh80.player,8192,frame,now);
 if(hit){float target[3]={goal[0],goal[1],goal[2]+240.f};kainEffect95(target,600,false,now);}
 record("kain95 blood-wave radius=6000 distance=%.1f hit-requested=%u",distance,hit);
}
static bool kainLaunchForce94(const Sr1LocalFrame *frame,uint64_t now){
 if(!frame->ready||frame->realm!=1||frame->worldGeneration!=sluagh80.world||!sluaghOwned80(sluagh80.actor))return false;
 unsigned slot=8;for(unsigned i=0;i<8;i++)if(!kainForces94[i].active){slot=i;break;}if(slot==8)return false;
 uintptr_t playerData=0,list=0,tuning=0;uint16_t speed=0;int16_t root[3],target[3];
 if(!readAt(base+AIR_PLAYER_DATA_RVA,&playerData,8)||!playerData||!readAt(playerData+0x20,&list,8)||!list||!readAt(list+0x28,&tuning,8)||!tuning||!readAt(tuning+0x18,&speed,2)||!speed||!readAt(sluagh80.actor+0x9c,root,6)||!readAt(sluagh80.player+0x9c,target,6))return false;
 float position[3]={root[0],root[1],root[2]+700.f};const float dx=target[0]-root[0],dy=target[1]-root[1],d=hypotf(dx,dy);if(d>1){position[0]+=dx*120/d;position[1]+=dy*120/d;}
 if(++kainForceSerial99==0)++kainForceSerial99;const unsigned serial=kainForceSerial99;
 KainForce94 *shot=kainForces94+slot;*shot=(KainForce94){.active=true,.player=sluagh80.player,.generation=serial,.playerGeneration=sluagh80.playerGeneration,.world=sluagh80.world,.born=now,.last=now,.speed=speed};memcpy(shot->position,position,12);
 kainProjectileStar97(serial,position,now);record("kain99 force-spawn generation=%u speed=%u xyz=%.1f/%.1f/%.1f native-missile=0 cast-flash=0",serial,speed,position[0],position[1],position[2]);return true;
}
