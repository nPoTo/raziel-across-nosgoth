// SPDX-License-Identifier: GPL-3.0-or-later
#pragma once
// Installed Defiance speech decoded in RAM;no synthesized/recreated voice.
typedef struct{unsigned kind;uint64_t tick;uintptr_t actor,player;uint32_t generation,playerGeneration,world,epoch;} KainVoiceJob100;
static SRWLOCK kainVoiceLock100=SRWLOCK_INIT;static KainVoiceJob100 kainVoiceQueue100[16];static unsigned kainVoiceRead100,kainVoiceWrite100;static volatile LONG kainVoiceEpoch100;static volatile LONG64 kainVoicePulse100;
static void kainVoiceHeartbeat100(uint64_t now){InterlockedExchange64(&kainVoicePulse100,(LONG64)now);}
static void kainVoiceCancel100(void){InterlockedIncrement(&kainVoiceEpoch100);AcquireSRWLockExclusive(&kainVoiceLock100);kainVoiceRead100=kainVoiceWrite100=0;ReleaseSRWLockExclusive(&kainVoiceLock100);}
static void kainVoice100(unsigned kind,uint64_t now){
 if(kind>=4||!sluaghOwned80(sluagh80.actor)||!sluaghResources80.voicePcm100[kind])return;
 static uint64_t last[4];if(now>=last[kind]&&now-last[kind]<(kind==3?80:kind==2?1200:500))return;last[kind]=now;kainVoiceHeartbeat100(now);
 KainVoiceJob100 job={kind,now,sluagh80.actor,sluagh80.player,sluagh80.generation,sluagh80.playerGeneration,sluagh80.world,(uint32_t)InterlockedCompareExchange(&kainVoiceEpoch100,0,0)};
 AcquireSRWLockExclusive(&kainVoiceLock100);unsigned next=(kainVoiceWrite100+1)%16;if(next!=kainVoiceRead100){kainVoiceQueue100[kainVoiceWrite100]=job;kainVoiceWrite100=next;}ReleaseSRWLockExclusive(&kainVoiceLock100);
 record("kain100 voice-queued kind=%u",kind);
}
static bool kainVoiceCurrent100(const KainVoiceJob100 *job,uint64_t now){
 DWORD foreground=0;GetWindowThreadProcessId(GetForegroundWindow(),&foreground);Sr1LocalFrame frame=readFrame();uint8_t enabled=0;uintptr_t current=0;const uint64_t heartbeat=(uint64_t)InterlockedCompareExchange64(&kainVoicePulse100,0,0);
 return foreground==GetCurrentProcessId()&&frame.ready&&frame.realm==1&&InterlockedCompareExchange(&portableActive60,0,0)&&readAt(base+sheet_sr1Audio44_installed_audio.sfxEnabledRva,&enabled,1)&&enabled&&readAt(base+host->actorRva,&current,8)&&current==job->player&&generation(current)==job->playerGeneration&&frame.worldGeneration==job->world&&sluaghOwned80(job->actor)&&generation(job->actor)==job->generation&&job->epoch==(uint32_t)InterlockedCompareExchange(&kainVoiceEpoch100,0,0)&&now>=heartbeat&&now-heartbeat<=250;
}
static DWORD WINAPI kainVoiceWorker100(void *unused){
 (void)unused;LocalAudioVoice voices[2]={{0}};KainVoiceJob100 owners[2]={{0}};
 for(;;){const uint64_t now=GetTickCount64();for(unsigned channel=0;channel<2;channel++)if(voices[channel].device&&(!kainVoiceCurrent100(owners+channel,now)||(voices[channel].header.dwFlags&WHDR_DONE)))localAudioClose(voices+channel,!(voices[channel].header.dwFlags&WHDR_DONE));
 KainVoiceJob100 job={0};bool pending=false;AcquireSRWLockExclusive(&kainVoiceLock100);if(kainVoiceRead100!=kainVoiceWrite100){job=kainVoiceQueue100[kainVoiceRead100];kainVoiceRead100=(kainVoiceRead100+1)%16;pending=true;}ReleaseSRWLockExclusive(&kainVoiceLock100);
 if(pending&&now>=job.tick&&now-job.tick<=250&&kainVoiceCurrent100(&job,now)){
 const unsigned channel=job.kind==3?1:0;LocalAudioVoice *selected=voices+channel;KainVoiceJob100 *selectedOwner=owners+channel;
 #define voice (*selected)
 #define owner (*selectedOwner)
 if(voice.device){const unsigned oldPriority=owner.kind==1?3:owner.kind==0?2:1,newPriority=job.kind==1?3:job.kind==0?2:1;if(newPriority<oldPriority){Sleep(2);continue;}localAudioClose(&voice,true);}
 if(!voice.device){const unsigned kind=job.kind,rate=sluaghResources80.voiceRate100[kind],bytes=sluaghResources80.voiceBytes100[kind];WAVEFORMATEX format={WAVE_FORMAT_PCM,1,rate,rate*2,2,16,0};voice.data=HeapAlloc(GetProcessHeap(),0,bytes);if(voice.data){memcpy(voice.data,sluaghResources80.voicePcm100[kind],bytes);MMRESULT result=waveOutOpen(&voice.device,WAVE_MAPPER,&format,0,0,CALLBACK_NULL);if(result==MMSYSERR_NOERROR){voice.header=(WAVEHDR){.lpData=(LPSTR)voice.data,.dwBufferLength=bytes};result=waveOutPrepareHeader(voice.device,&voice.header,sizeof voice.header);if(!result)result=waveOutWrite(voice.device,&voice.header,sizeof voice.header);owner=job;if(result)localAudioClose(&voice,true);}else{HeapFree(GetProcessHeap(),0,voice.data);memset(&voice,0,sizeof voice);}record("kain100 voice-play kind=%u result=%u",kind,(unsigned)result);}}
 #undef voice
 #undef owner
 }Sleep(2);
 }return 0;
}
