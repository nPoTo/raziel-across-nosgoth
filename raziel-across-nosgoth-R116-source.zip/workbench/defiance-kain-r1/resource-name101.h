// SPDX-License-Identifier: GPL-3.0-or-later
#pragma once
static inline bool kainResourceName101(const char *name){return name&&(!_stricmp(name,"kain")||!strcmp(name,"kain____"));}
