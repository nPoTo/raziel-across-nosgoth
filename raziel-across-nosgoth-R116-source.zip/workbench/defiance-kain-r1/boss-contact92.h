// SPDX-License-Identifier: GPL-3.0-or-later
#pragma once
static inline float kainSegmentDistance92(const float a[3],const float b[3],const int16_t point[3]){
 float length=0,dot=0;for(unsigned k=0;k<3;k++){const float d=b[k]-a[k];length+=d*d;dot+=(point[k]-a[k])*d;}
 const float t=length>1e-6f?fmaxf(0,fminf(1,dot/length)):0;float distance=0;
 for(unsigned k=0;k<3;k++){const float d=point[k]-(a[k]+t*(b[k]-a[k]));distance+=d*d;}return distance;
}
