// SPDX-License-Identifier: GPL-3.0-or-later
#pragma once
// The original debug processor moves XY directly in fly mode; the original
// player processor also suppresses physics. Mask the setting for those calls
// only, retaining the original user setting outside the owned encounter calls.
static void (*kainOriginalDebug106)(uintptr_t);
static LocalStrikeUpdate kainOriginalPlayer106;
static uintptr_t (*kainOriginalCheats106)(void);
typedef struct {uintptr_t address;bool changed;} KainFlyLease106;
static bool kainFlyContext106(uintptr_t tracker){
 uintptr_t actor=0,current=0;uint16_t mode=UINT16_MAX;
 return tracker&&readAt(base+(uintptr_t)kainPolicy104->trackerPointerRva,&current,8)&&current==tracker&&
  readAt(tracker+(uintptr_t)kainPolicy106->trackerPlayerOffset,&actor,8)&&kainSupportOwner105(actor)&&
  readAt(tracker+(uintptr_t)kainPolicy106->trackerModeOffset,&mode,2)&&mode==0;
}
static KainFlyLease106 kainFlyBegin106(uintptr_t tracker){
 const DWORD saved=GetLastError();KainFlyLease106 lease={0};uint8_t flag=0;
 if(kainFlyContext106(tracker)&&
  readAt(tracker+(uintptr_t)kainPolicy106->trackerFlyOffset,&flag,1)&&flag==1){
  MEMORY_BASIC_INFORMATION region={0};const uintptr_t at=tracker+(uintptr_t)kainPolicy106->trackerFlyOffset;unsigned char expected=1;
  if(VirtualQuery((void*)at,&region,sizeof region)==sizeof region&&region.State==MEM_COMMIT&&
   (region.Protect&(PAGE_READWRITE|PAGE_WRITECOPY|PAGE_EXECUTE_READWRITE|PAGE_EXECUTE_WRITECOPY))&&
   atomic_compare_exchange_strong((_Atomic unsigned char*)at,&expected,0)){lease.address=at;lease.changed=true;}
 }SetLastError(saved);return lease;
}
static void kainFlyEnd106(KainFlyLease106 lease,unsigned boundary){
 const DWORD saved=GetLastError();bool restored=false;
 if(lease.changed){unsigned char expected=0;restored=atomic_compare_exchange_strong((_Atomic unsigned char*)lease.address,&expected,1);}
 if(lease.changed){static uint64_t last[2];const uint64_t now=GetTickCount64();
  if(boundary<2&&now-last[boundary]>=1000){last[boundary]=now;record("kain106 native-fly masked boundary=%s restored=%u persistent-write=0",boundary?"player":"debug",restored);}
 }SetLastError(saved);
}
static void kainDebug106(uintptr_t tracker){
 const KainFlyLease106 lease=kainFlyBegin106(tracker);kainOriginalDebug106(tracker);kainFlyEnd106(lease,0);
}
static int kainProcessPlayer106(uintptr_t actor,uintptr_t tracker,uintptr_t pad,int32_t mode){
 kainStatusBoundary114(actor);
 const KainFlyLease106 lease=actor==sluagh80.player?kainFlyBegin106(tracker):(KainFlyLease106){0};
 const int result=kainOriginalPlayer106(actor,tracker,pad,mode);const DWORD error=GetLastError();kainFlyEnd106(lease,1);
 if(actor==sluagh80.player)kainFinishNativeHealth113(actor);SetLastError(error);return result;
}
static uintptr_t kainCheats106(void){
 const DWORD saved=GetLastError();uintptr_t tracker=0;uint32_t held=0,masked=0;bool changed=false;
 const uintptr_t address=base+(uintptr_t)kainPolicy106->controlHeldRva;const uint32_t mask=(uint32_t)kainPolicy106->cheatHeldMask;
 bool debugBlocked=false;
 if(readAt(address,&held,4)){
  uint32_t remove=0;const uint32_t debugMask=(uint32_t)kainPolicy113->debugChordMask;
  if(kainDebugBusy113()&&(held&debugMask)==debugMask){remove|=debugMask;debugBlocked=true;}
  if(readAt(base+(uintptr_t)kainPolicy104->trackerPointerRva,&tracker,8)&&kainFlyContext106(tracker)&&
   ((held&((uint32_t)kainPolicy106->cheatActivationMask))==(uint32_t)kainPolicy106->cheatActivationMask||(held&(mask|2u))==(mask|2u)))remove|=mask;
  if(remove){masked=held&~remove;uint32_t expected=held;changed=atomic_compare_exchange_strong((_Atomic uint32_t*)address,&expected,masked);}
 }SetLastError(saved);const uintptr_t result=kainOriginalCheats106();const DWORD after=GetLastError();
 if(changed){uint32_t expected=masked;const bool restored=atomic_compare_exchange_strong((_Atomic uint32_t*)address,&expected,held);
  static uint64_t last;const uint64_t now=GetTickCount64();if(now-last>=1000){last=now;record("kain113 native-cheat-chord blocked=1 debug=%u held=%x restored=%u combat-input-preserved=1",debugBlocked,held,restored);}
 }SetLastError(after);return result;
}
static bool kainPrepareFly106(void){
 const uintptr_t debug=(uintptr_t)kainPolicy106->debugProcessRva,process=(uintptr_t)kainPolicy106->playerProcessRva;
 const bool prepared=kainPolicy106->sharedPlayerEntry&&originalStrikeUpdate&&strikeTravel->updateRva==process&&
  matches(debug,(unsigned char[]){0x48,0x89,0x5c,0x24,0x10,0x48,0x89,0x6c,0x24,0x18,0x48,0x89,0x74,0x24,0x20,0x57},16)&&
  matches(process,(unsigned char[]){0x48,0x89,0x5c,0x24,0x08,0x48,0x89,0x6c,0x24,0x10,0x48,0x89,0x74,0x24,0x18,0x57},16)&&
  matches(0xeb496,(unsigned char[]){0x80,0xb8,0xcb,0x02,0x00,0x00,0x01},7)&&
  matches((uintptr_t)kainPolicy106->cheatDispatchRva,(unsigned char[]){0x48,0x89,0x5c,0x24,0x08,0x57,0x48,0x83,0xec,0x20},10)&&
  MH_CreateHook((void*)(base+debug),kainDebug106,(void**)&kainOriginalDebug106)==MH_OK&&
  MH_CreateHook((void*)(base+(uintptr_t)kainPolicy106->cheatDispatchRva),kainCheats106,(void**)&kainOriginalCheats106)==MH_OK;
 if(prepared){kainOriginalPlayer106=originalStrikeUpdate;originalStrikeUpdate=kainProcessPlayer106;}
 return prepared;
}
