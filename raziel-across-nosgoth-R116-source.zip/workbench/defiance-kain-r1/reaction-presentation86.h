// SPDX-License-Identifier: GPL-3.0-or-later
#pragma once
static inline uint32_t hyldenMaterialFlags90(uint32_t flags){return flags&~0x08000000u;}
static inline bool hyldenDeadState90(unsigned state){return state==16||state==23;}
// Animation service adapter. It does not choose attacks or alter damage.
// Selectors are bounded to the hash-pinned Sluagh attributes (53 logical IDs).
static inline const unsigned char *snCombat86(const SluaghNativeAI *n){
 const unsigned char *sub=snPtr(n->state,0x3e0),*const *combat=snPtr(n->attributes,0x30);
 return sub&&combat&&sub[8]==0?combat[0]:NULL;
}
static inline unsigned snAnimSlot86(const SluaghNativeAI *n,unsigned slot){
 const unsigned char *sub=snPtr(n->state,0x3e0),*const *lists=snPtr(n->attributes,0xf8);
 return sub&&lists&&sub[7]==0&&slot<33?lists[0][slot]:255;
}
static inline unsigned snDeathAnimation89(const SluaghNativeAI *n){
 // Hylden has no Sluagh other-plane/death slot9. Its own corpse slot18 is27.
 return snAnimSlot86(n,18);
}
static inline unsigned snDamageAnimation86(const SluaghNativeAI *n,bool launch){
 const unsigned char *combat=snCombat86(n),*damage=snPtr(n->attributes,0xb0);
 if(!combat||!damage||combat[0x23]>=48)return 255;
 // Original THROWN entry bcdb0 selects throw+0a, not its later airborne key0d.
 if(launch){const unsigned char *throws=snPtr(n->attributes,0xe8);return throws?throws[0x0a]:255;}
 const unsigned index=combat[0x23];
 // Original HIT entry has already chosen the directional reaction.
 return n->mode==15?n->logical:damage[index*48+0x1a];
}
static inline unsigned snFallAnimation86(SluaghNativeAI *n,int height,unsigned field){
 if(field!=2&&field!=3&&field!=6)return 255;
 const unsigned char *(*select)(void*,int)=(void*)(n->module+0xa7360);
 const unsigned char *row=select(n->actor,height),*table=snPtr(n->attributes,0xb8);
 if(!row||!table||(row!=table&&row!=table+16))return 255;
 return row[field];
}
static inline unsigned snThrowSlot94(const SluaghNativeAI *n,unsigned field){
 const unsigned char *record=snPtr(n->attributes,0xe8);
 return record&&(field==0x0a||field==0x0d||field==0x0e)?record[field]:255;
}
static inline bool snPresent86(SluaghNativeAI *n,unsigned logical,bool loop){
 if(logical>=48)return false;
 n->state[0x478]=(unsigned char)logical;n->state[0x479]=loop?2:1;
 return snConsumeAnimation(n)!=0;
}
static inline void snFace86(SluaghNativeAI *n,float delta){
 if(!isfinite(delta)||delta<=0||delta>100)return;
 const unsigned char *sub=snPtr(n->state,0x3e0);int16_t rate;memcpy(&rate,sub+0xa,2);
 float (*heading)(const float*,const float*)=(void*)(n->module+0x8cba0);
 void (*step)(float*,float,float)=(void*)(n->module+0x8cd70);
 const float desired=heading((const float*)(n->actor+0x20),(const float*)n->target);
 const float maximum=rate*(1.f/4096.f)*delta*snFloat(n->state,0x40c);
 if(isfinite(desired)&&isfinite(maximum)&&maximum>=0)step((float*)(n->actor+0x48),desired,maximum);
}
// These decisions acknowledge presentation completion, never arbitrary timeouts.
static inline bool snRecoveryEnd86(unsigned nativeState,int hp,bool wasAirborne,bool finished,bool genericLanding){
 return nativeState==15&&hp>0&&wasAirborne&&finished&&genericLanding;
}
static inline float snAdvancePresentation86(float sample,float delta,float end,bool loop){
 if(!isfinite(sample)||!isfinite(delta)||!isfinite(end)||delta<0||end<=0)return 0;
 return loop?fmodf(sample+delta,end):fminf(sample+delta,end);
}
