// SPDX-License-Identifier: GPL-3.0-or-later
#pragma once
// Explicit SR1 execution adaptation for the creator's requested aerial fight.
// It neither selects a Kain attack nor writes Raziel's position/control flags.
static struct {uint64_t pending,launched,last;bool lift,seenAir,floorSet,interrupted;float floor,playerFloor;uint32_t playerGeneration;} kainAir95;
static void kainAirClear95(void){memset(&kainAir95,0,sizeof kainAir95);sluagh80.airPursuit95=false;}
static void kainAirContact95(const Sr1LocalFrame *frame,uint64_t now,unsigned kind){
 if(!frame->ready||frame->realm!=1||(!frame->grounded&&kainAir95.launched&&now-kainAir95.launched>=2500))return;
 int16_t playerZ=0;readAt(sluagh80.player+0xa0,&playerZ,2);
 if(kind!=5&&frame->grounded&&(!kainAir95.launched||playerZ<=kainAir95.playerFloor+48))return;
 if(!kainAir95.launched){int16_t z=0;readAt(sluagh80.actor+0xa0,&z,2);kainAir95.floor=z;kainAir95.playerFloor=frame->grounded?playerZ:z;kainAir95.launched=now;kainAir95.seenAir=!frame->grounded;kainAir95.floorSet=kainAir95.interrupted=false;}
 kainAir95.pending=now;kainAir95.lift=kind==5;kainAir95.playerGeneration=frame->playerGeneration;
 record("kain95 air-contact kind=%u launch=%u",kind,kainAir95.lift);
}
static void kainAirPoll95(const Sr1LocalFrame *frame,uint64_t now){
 if(!kainAir95.pending&&!sluagh80.airPursuit95)return;
 if(!frame->ready||!sluaghOwned80(sluagh80.actor)||frame->realm!=1||frame->playerGeneration!=kainAir95.playerGeneration){if(frame->ready)kainAirClear95();return;}
 uint32_t ownWorld=0;if(!readAt(sluagh80.actor+0x60,&ownWorld,4)||ownWorld!=sluagh80.world)return;
 if(kainAir95.pending){
  uintptr_t callback=0;readAt(base+host->callbackRva,&callback,8);
  if(now-kainAir95.pending>300){kainAir95.pending=0;if(!sluagh80.airPursuit95)kainAir95.launched=0;}
  else if(callback==base+0xf1f90){
   // The native hit entry has already applied its HP loss and ResetPhysics.
   // Fall owns gravity, collision and the eventual native landing transition.
   if(kainAir95.lift){int16_t root[3];if(readAt(sluagh80.player+0x9c,root,6)){float from[3]={root[0],root[1],root[2]+400.f};int16_t head[3]={root[0],root[1],(int16_t)(root[2]+560)},raised[3]={root[0],root[1],(int16_t)(root[2]+160)};if(frame->grounded&&root[2]<31000&&localNativeLineClear(sluagh80.player,sluagh80.world,from,head))((void(*)(uintptr_t,const int16_t*,int))(base+0x117810))(sluagh80.player,raised,0);}}
   ((uintptr_t(*)(uintptr_t,uintptr_t,uintptr_t))(base+0x10ffc0))(base+host->stateActorRva,base+groundPolicy->fallRva,0);
   int32_t velocity=kainAir95.lift?168:45;
   // ProcessPhysics overwrites zAccl from ExternalForces every frame. Setting
   // zAccl alone cannot establish gravity after a native zero-force state.
   ((void(*)(uintptr_t,int,int,int,int))(base+0xe4230))(sluagh80.player,-16,0,0,velocity);
   sluagh80.airPursuit95=true;
   kainAir95.pending=0;record("kain95 player-air native-fall=1 velocity=%d gravity=-16 external-force=1",velocity);
   return; // The input frame still describes the pre-launch grounded state.
  }
 }
 if(!sluagh80.airPursuit95)return;
 uint32_t state=0;readAt(sluagh80.actor+0x2f0,&state,4);
 if(state==11){sluagh80.airborne86=true;sluagh80.groundZ86=kainAir95.floor;kainAirClear95();return;}
 if(state==8||state==9||state==15)kainAir95.interrupted=true;
 int16_t own[3],target[3];if(!readAt(sluagh80.actor+0x9c,own,6)||!readAt(sluagh80.player+0x9c,target,6)){kainAirClear95();return;}
 kainAir95.seenAir|=!frame->grounded;
 const bool descend=kainAir95.interrupted||frame->worldGeneration!=sluagh80.world||kainAirExpired95(kainAir95.launched,now)||kainAirLanded95(frame->grounded,target[2],kainAir95.playerFloor,kainAir95.seenAir);
 if(descend&&!kainAir95.floorSet){
  float top[3]={own[0],own[1],own[2]+128.f};int16_t bottom[3]={own[0],own[1],(int16_t)fmaxf(-32000,own[2]-4096.f)};
  if(!localNativeLineClear(sluagh80.actor,sluagh80.world,top,bottom)){float low=bottom[2],high=top[2];for(unsigned j=0;j<12;j++){bottom[2]=(int16_t)lroundf((low+high)*.5f);if(localNativeLineClear(sluagh80.actor,sluagh80.world,top,bottom))high=bottom[2];else low=bottom[2];}kainAir95.floor=ceilf(high)+1;}
  kainAir95.floorSet=true;
 }
 float goal=descend?kainAir95.floor:target[2]-80.f;
 if(goal<kainAir95.floor)goal=kainAir95.floor;
 const float delta=kainAir95.last?fminf(50,(float)(now-kainAir95.last)):33;kainAir95.last=now;
 const float step=fmaxf(-60,fminf(60,(goal-own[2])*.4f))*delta/33.f;
 if(own[2]+step<-31500||own[2]+step>31500){kainAirClear95();return;}
 int16_t next[3]={own[0],own[1],(int16_t)lroundf(own[2]+step)},to[3]={next[0],next[1],(int16_t)(next[2]+300)};float from[3]={own[0],own[1],own[2]+300.f};
 if(localNativeLineClear(sluagh80.actor,sluagh80.world,from,to))((void(*)(uintptr_t,const int16_t*,int))(base+0x117810))(sluagh80.actor,next,0);
 if(descend&&abs(next[2]-(int)kainAir95.floor)<3){kainAirClear95();record("kain95 aerial-pursuit-landed");}
}
