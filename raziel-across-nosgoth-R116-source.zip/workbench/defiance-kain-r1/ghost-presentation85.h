// SPDX-License-Identifier: GPL-3.0-or-later
#pragma once
#include <math.h>
static float ghostClamp85(float x){return fmaxf(0,fminf(1,x));}
// Visual deformation only. Head-leading curve ends at the current mouth;
// native SR1 still owns root movement, collision, intake and removal.
static void ghostSuctionPoint85(float world[3],float localHeight,float headHeight,const float root[3],const float mouth[3],float blend,float width){
 const float u=ghostClamp85((localHeight+4.1f)/fmaxf(1,headHeight+4.1f)),v=1-u;
 float delta[3],distance=0;for(unsigned k=0;k<3;k++){delta[k]=mouth[k]-root[k];distance+=delta[k]*delta[k];}
 distance=sqrtf(distance);const float arc=fminf(260.f,distance*.18f),narrow=powf(v,1.4f)*fmaxf(.08f,fminf(1,width));
 for(unsigned k=0;k<3;k++){
  const float control=(root[k]+mouth[k])*.5f+(k==2?arc:0);
  const float center=root[k]*v*v+2.f*control*u*v+mouth[k]*u*u;
  const float radial=k==2?0:(world[k]-root[k])*narrow;
  world[k]+=(center+radial-world[k])*ghostClamp85(blend);
 }
}
