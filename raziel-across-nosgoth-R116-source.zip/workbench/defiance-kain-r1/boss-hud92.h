// SPDX-License-Identifier: GPL-3.0-or-later
#pragma once
static inline float kainHealthFraction92(int health,int maximum){
 if(maximum<=0)return 0;return fmaxf(0,fminf(1,(float)health/maximum));
}
static void kainHudQuad92(float left,float right,float bottom,float top,const float color[4]){
 ReaverGLVertex v[4]={0};const float xy[4][2]={{left,bottom},{right,bottom},{right,top},{left,top}};
 for(unsigned i=0;i<4;i++){v[i].position[0]=xy[i][0];v[i].position[1]=xy[i][1];memcpy(v[i].rgba,color,16);}
 const uint16_t index[6]={0,1,2,0,2,3};const float identity[16]={1,0,0,0,0,1,0,0,0,0,1,0,0,0,0,1};
 reaverGLDraw(&sluaghGL80,v,4,index,6,18,1,identity,0,0);
}
static void kainHud92(void){
 int hp=0,max=0;AcquireSRWLockShared(&sluaghRenderLock80);hp=sluagh80.hp*4;max=sluagh80.maxHp*4;ReleaseSRWLockShared(&sluaghRenderLock80);
 if(max<=0)return;if(!sluaghGL80.textures[18]){const unsigned char white[4]={255,255,255,255};if(!reaverGLTexture(&sluaghGL80,18,1,1,white,false,false))return;}
 GLint viewport[4];glGetIntegerv(GL_VIEWPORT,viewport);if(viewport[2]<320||viewport[3]<200)return;
 const float pixelX=2.f/viewport[2],pixelY=2.f/viewport[3],left=-.63f,right=.94f,top=.91f,bottom=.872f;
 const float edge[4]={.66f,.48f,.24f,1},background[4]={.035f,.018f,.018f,.96f},blood[4]={.57f,.025f,.035f,1};
 GLdouble depth[2];glGetDoublev(GL_DEPTH_RANGE,depth);glDepthRange(0,0);
 kainHudQuad92(left,right,bottom,top,edge);kainHudQuad92(left+pixelX*2,right-pixelX*2,bottom+pixelY*2,top-pixelY*2,background);
 const float fraction=kainHealthFraction92(hp,max);if(fraction>0)kainHudQuad92(left+pixelX*3,left+pixelX*3+(right-left-pixelX*6)*fraction,bottom+pixelY*3,top-pixelY*3,blood);
 const float charge=fminf(1,sluagh80.ai.bladeCharge96/100.f),red[4]={1,.02f,.06f,1};
 kainHudQuad92(left,right,bottom-.014f,bottom-.006f,background);if(charge>0)kainHudQuad92(left,left+(right-left)*charge,bottom-.014f,bottom-.006f,red);
 const float yellow=fminf(1,sluagh80.yellowCharge100/100.f),gold[4]={1,.82f,.08f,1};
 kainHudQuad92(left,right,bottom-.053f,bottom-.029f,edge);kainHudQuad92(left+pixelX,right-pixelX,bottom-.053f+pixelY,bottom-.029f-pixelY,background);
 if(yellow>0)kainHudQuad92(left+pixelX,left+pixelX+(right-left-pixelX*2)*yellow,bottom-.053f+pixelY,bottom-.029f-pixelY,gold);
 glDepthRange(depth[0],depth[1]);
}
