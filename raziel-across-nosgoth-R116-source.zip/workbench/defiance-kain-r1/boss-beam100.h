// SPDX-License-Identifier: GPL-3.0-or-later
#pragma once
#include "resource-name101.h"
// User-added charged ability;ordinary attacks still chosen by original Defiance AI.
static struct{uint64_t cast,beam,lastResource,lastWait,retreat,dashStart,recover,notBefore,raise;uintptr_t field,zap,originalObject,tracker;bool pinned,requested,hit,chargeLogged104;unsigned dashes,dashGoal;int16_t anchor107[3];float direction[2],done[2],entry[1264];} kainBeam100;
static bool kainEffectCurrent100(uintptr_t effect,unsigned type){
 uintptr_t node=0;if(!effect||!readAt(base+0x2bccd0,&node,8))return false;
 for(unsigned i=0;node&&i<2048;i++){if(node==effect){uintptr_t owner=0;uint16_t kind=0;return readAt(node+0x10,&owner,8)&&owner==sluagh80.actor&&readAt(node+0x18,&kind,2)&&kind==type;}if(!readAt(node,&node,8))return false;}return false;
}
static void kainEndEffect100(uintptr_t *effect,unsigned type){
 // Native instance-FX cleanup unlinks before freeing. A raw lifeTime write is
 // overwritten by the remaster's interpolated lifetime snapshots.
 if(sluaghOwned80(sluagh80.actor)&&kainEffectCurrent100(*effect,type)){
  ((void(*)(uintptr_t))(base+(uintptr_t)kainPolicy102->nativeEffectCleanupRva))(sluagh80.actor);
  kainBeam100.field=kainBeam100.zap=0;
 }*effect=0;
}
static void kainClearBeam100(void){
 kainEndEffect100(&kainBeam100.field,0x86);kainEndEffect100(&kainBeam100.zap,0x87);
 if(kainBeam100.pinned){uintptr_t object=0;int16_t users=0;if(readAt(kainBeam100.tracker+0x10,&object,8)&&object==kainBeam100.originalObject&&readAt(kainBeam100.tracker+0x1a,&users,2)&&users>0){users--;memcpy((void*)(kainBeam100.tracker+0x1a),&users,2);}}
 memset(&kainBeam100,0,sizeof kainBeam100);
}
static bool kainOriginalObject100(uint64_t now){
 if(kainBeam100.pinned)return true;if(now-kainBeam100.lastResource<200)return false;kainBeam100.lastResource=now;
 uintptr_t array=0;if(!readAt(base+44602192,&array,8)||!array)return false;
 for(unsigned i=0;i<48;i++){char name[17]={0};int16_t status=0;uintptr_t at=array+i*56,object=0;readAt(at,name,16);readAt(at+24,&status,2);
 if(status!=2||!kainResourceName101(name)||!readAt(at+16,&object,8)||!object)continue;
 uint32_t flags=0;readAt(object+0x48,&flags,4);if(flags&0x10000000u){((void(*)(uintptr_t))(base+0xb7a10))(at);return false;}
 uintptr_t clips=0,hd=0,clip=0;int16_t count=0,users=0;uint32_t magic=0;
 if(!readAt(object+10,&count,2)||count<=20||!readAt(object+24,&clips,8)||!clips||!readAt(clips+20*8,&clip,8)||!clip||!readAt(clip,&magic,4)||magic==0x0face0ffu||!readAt(object+0x6d88,&hd,8)||!hd||!readAt(hd+20*8,&clip,8)||!clip||!readAt(at+0x1a,&users,2)||users<0||users>=32765)return false;
 users++;memcpy((void*)(at+0x1a),&users,2);kainBeam100.originalObject=object;kainBeam100.tracker=at;kainBeam100.pinned=true;record("kain100 original-SR1-paired-clip ready=20");return true;
 }
 if(!kainBeam100.requested){((uintptr_t(*)(const char*))(base+0x115b40))("Kain");kainBeam100.requested=true;}return false;
}
static void kainBeamPoint100(int16_t source[3],int16_t target[3]){
 readAt(sluagh80.actor+0x9c,source,6);readAt(sluagh80.player+0x9c,target,6);source[2]+=700;target[2]+=300;
 if(sluagh80.render){const float *m=sluagh80.matrices+65*16,c=cosf(sluagh80.yaw),s=sinf(sluagh80.yaw),scale=.9598479333948396f;source[0]=(int16_t)lroundf(sluagh80.position[0]+scale*(c*m[12]-s*m[13]));source[1]=(int16_t)lroundf(sluagh80.position[1]+scale*(s*m[12]+c*m[13]));source[2]=(int16_t)lroundf(sluagh80.position[2]+scale*m[14]);}
 LocalSphere sphere;if(localContactSphere(sluagh80.player,false,true,NULL,NULL,&sphere))for(unsigned k=0;k<3;k++)target[k]=sphere.native.center[k];
}
static bool kainBeamParameters100(int values[7],uint32_t colors[2]){
 uintptr_t particle=((uintptr_t(*)(const char*))(base+0xb7850))("particle"),data=0,list=0,effects=0;uint8_t index=0;
 if(!particle||!readAt(particle+0x28,&data,8)||!data||!readAt(data+0x18,&list,8)||!list||!readAt(kainBeam100.originalObject+0x58,&effects,8)||!effects||!readAt(effects+5,&index,1))return false;
 const uintptr_t p=list+index*40;int16_t a=0;const unsigned offsets[6]={4,6,0x18,0x1a,0x1c,0x1e};for(unsigned k=0;k<6;k++){if(!readAt(p+offsets[k],&a,2))return false;values[k<4?k:k+1]=a;}values[4]=0;if(!readAt(p+0x17,&index,1))return false;values[4]=index;
 return values[2]>0&&values[2]<2048&&values[3]>=0&&values[3]<2048&&values[4]>=2&&values[4]<=128&&readAt(p+0x20,colors,8);
}
static int kainBeamPower100(unsigned scale){return scale<=13?(int)((uint64_t)(scale+1)*50000u*4096u/20000u):0;}
static bool kainBeamDamage100(const Sr1LocalFrame *frame,uint64_t now){
 int16_t scale=0;if(!readAt(base+0x2a88ccc,&scale,2)||scale<0)return false;int remaining=kainBeamPower100((unsigned)scale),before=0,after=0;readAt(base+0x2a88cd0,&before,4);if(!remaining)return false;bool applied=false;
 while(remaining>0){const int chunk=remaining>32768?32768:remaining;if(!kainPlayerContact96(sluagh80.actor,sluagh80.player,chunk,101,true,frame,now))break;remaining-=chunk;applied=true;}
 uint32_t actualRealm=0;readAt(base+44600604,&actualRealm,4);
 if(applied&&actualRealm==1&&!kainPlayer96.fatal113){uintptr_t callback=0;readAt(base+host->callbackRva,&callback,8);kainProneStart97(now,!frame->grounded||(callback==base+groundPolicy->fallRva&&kainPlayerUnsupported103()));unsigned char nativeHost[0x38]={0};memcpy(nativeHost+0x30,&kainBeam100.originalObject,8);
 ((void(*)(uintptr_t,uintptr_t,int,int,int,int))(base+0x10d990))(sluagh80.player,(uintptr_t)nativeHost,20,0,3,2);
 record("kain100 writhing original-SR1-host-animation=20 hold=1000");}
 readAt(base+0x2a88cd0,&after,4);record("kain100 beam-damage max-hp=%d wanted=%d hp=%d/%d realm=%u applied=%u",(scale+1)*100000,(scale+1)*50000,before,after,actualRealm,applied);return applied;
}
#include "beam-sequence102.h"
