// SPDX-License-Identifier: GPL-3.0-or-later
#pragma once
// Damage and reaction are independent: the stock GetHit state drops new hit
// messages, and LoseHealth has a timer. Only this boss's distinct contacts may
// bypass the timer created by its own last successful hit; all other guards stay.
static void (*kainOriginalLose96)(int);
static void (*kainOriginalHit96)(uintptr_t,int,uintptr_t);
static void (*kainOriginalStumble99)(uintptr_t,int,uintptr_t);
static NTSTATUS (WINAPI *kainRandom99)(BCRYPT_ALG_HANDLE,PUCHAR,ULONG,ULONG)=BCryptGenRandom;
static uintptr_t (*kainOriginalPeek96)(uintptr_t);
static _Thread_local bool kainReactionEntry96;
static _Thread_local uintptr_t kainReactionQueue96;
static struct {uintptr_t player;uint32_t generation,world;uint64_t hold,impulseEnd,last,proneStart,proneUntil,reactionUntil,landDeadline,fatalAttempt113;int immunity;bool ownsImmunity,pull,impulse,landProne,stumble99,resumeFall103,fatal113,held[3];float direction[3];} kainPlayer96;
static bool kainPlayerCurrent96(void){
 uintptr_t current=0;uint32_t world=0;
 return sluaghOwned80(sluagh80.actor)&&kainPlayer96.player==sluagh80.player&&
 generation(kainPlayer96.player)==kainPlayer96.generation&&readAt(base+host->actorRva,&current,8)&&current==kainPlayer96.player&&
 readAt(current+0x60,&world,4)&&world==kainPlayer96.world;
}
static void kainLose96(int power){
 if(kainReactionEntry96)return;
 kainPlayer96.ownsImmunity=false;kainOriginalLose96(power);
}
static uintptr_t kainPeek96(uintptr_t queue){
 uintptr_t event=kainOriginalPeek96(queue);
 if(queue!=kainReactionQueue96||!kainPlayerCurrent96()||!InterlockedCompareExchange(&portableActive60,0,0))return event;
 for(unsigned i=0;event&&i<16;i++){
  uint32_t id=0;readAt(event,&id,4);if(!(kainPlayer96.stumble99&&id==0x100000u&&GetTickCount64()<kainPlayer96.hold)&&!kainHoldMessage96(id,GetTickCount64(),kainPlayer96.hold))break;
  const uintptr_t first=base+host->stateActorRva+0x18;const unsigned section=(unsigned)((queue-first)/0x228);
  if(section<3)kainPlayer96.held[section]=true;
  ((void(*)(uintptr_t))(base+0x10cc50))(queue);event=kainOriginalPeek96(queue);
 }
 return event;
}
static void kainHit96(uintptr_t state,int section,uintptr_t data){
 const uintptr_t previous=kainReactionQueue96;
 if(state==base+host->stateActorRva&&section>=0&&section<3&&kainPlayerCurrent96())kainReactionQueue96=state+0x18+(uintptr_t)section*0x228;
 kainOriginalHit96(state,section,data);kainReactionQueue96=previous;
}
static void kainStumble99(uintptr_t state,int section,uintptr_t data){
 const uintptr_t previous=kainReactionQueue96;
 if(state==base+host->stateActorRva&&section>=0&&section<3&&kainPlayerCurrent96())kainReactionQueue96=state+0x18+(uintptr_t)section*0x228;
 kainOriginalStumble99(state,section,data);kainReactionQueue96=previous;
}
static bool kainTkStun99(void){
 uint32_t roll=0;for(unsigned attempt=0;attempt<8;attempt++){
  if(kainRandom99(NULL,(PUCHAR)&roll,4,BCRYPT_USE_SYSTEM_PREFERRED_RNG)<0)return false;
  if(roll<4294967200u)return roll%100u<30u;
 }return false;
}
static void kainReleaseHold96(void){
 if(kainPlayerCurrent96())for(unsigned section=0;section<3;section++)if(kainPlayer96.held[section]){
  uintptr_t callback=0;readAt(base+host->callbackRva+section*0x228,&callback,8);
  if(callback==base+0xf1f90||callback==base+0xf59d0)((void(*)(uintptr_t,uint32_t,uintptr_t))(base+0x10ccc0))(base+host->stateActorRva+0x18+section*0x228,callback==base+0xf59d0?0x100000u:0x8000000u,0);
 }
 if(kainPlayer96.stumble99&&kainPlayerCurrent96())for(unsigned section=0;section<3;section++)if(!kainPlayer96.held[section]){
 uintptr_t callback=0;readAt(base+host->callbackRva+section*0x228,&callback,8);
 if(callback==base+0xf59d0)((void(*)(uintptr_t,uint32_t,uintptr_t))(base+0x10ccc0))(base+host->stateActorRva+0x18+section*0x228,0x100000u,0);
 }
 kainPlayer96.hold=0;kainPlayer96.stumble99=false;memset(kainPlayer96.held,0,sizeof kainPlayer96.held);
}
static void kainClearPlayer96(void){kainReleaseHold96();memset(&kainPlayer96,0,sizeof kainPlayer96);}
static bool kainPlayerUnsupported103(void){
 int16_t foot[3];if(!readAt(sluagh80.player+0x9c,foot,6)||foot[2]<=-31000||foot[2]>=31000)return false;
 const float from[3]={foot[0],foot[1],foot[2]+16.f};const int16_t to[3]={foot[0],foot[1],(int16_t)(foot[2]-64)};
 return localNativeLineClear(sluagh80.player,sluagh80.world,from,to);
}
static void kainProneStart97(uint64_t now,bool airborne){
 // Historical name retained;R99 uses the real standing native Stumble state.
 kainReleaseHold96();kainPlayer96.hold=now+1000;kainPlayer96.proneStart=kainPlayer96.proneUntil=0;kainPlayer96.reactionUntil=now+1000;kainPlayer96.impulse=false;kainPlayer96.landProne=false;kainAir95.pending=0;kainPlayer96.stumble99=true;
 kainPlayer96.resumeFall103|=airborne;
 ((void(*)(uintptr_t,uintptr_t,uintptr_t))(base+0x10ffc0))(base+host->stateActorRva,base+0xf59d0,4096);
 kainVoice100(2,now);record("kain99 stagger until=%llu native-handler=f59d0 animation=128",(unsigned long long)kainPlayer96.hold);
}
static bool kainPlayerBusy97(uintptr_t actor,uint64_t now){
 return actor==kainPlayer96.player&&kainPlayerCurrent96()&&InterlockedCompareExchange(&portableActive60,0,0)&&
  (kainPlayer96.fatal113||now<kainPlayer96.reactionUntil||now<kainPlayer96.hold||(kainPlayer96.proneStart&&now<kainPlayer96.proneUntil+200)||kainPlayer96.impulse||kainPlayer96.landProne||kainAir95.pending||sluagh80.airPursuit95);
}
static void kainPlayerFrame97(Sr1LocalFrame *frame,uintptr_t actor){
 if(!frame->ready||!kainPlayerBusy97(actor,GetTickCount64()))return;
 frame->nativeControl=true;frame->renderBlend=false;frame->groundStrike=false;frame->strikePending=false;frame->strikeTransition=false;
}
static bool kainPlayerInput97(NativePad *output){
 static uint32_t suppressed;static uintptr_t owner;static uint32_t gen;
 if(!InterlockedCompareExchange(&portableActive60,0,0)||!kainPlayerCurrent96()){suppressed=0;owner=0;return false;}
 if(owner!=sluagh80.player||gen!=sluagh80.playerGeneration){suppressed=0;owner=sluagh80.player;gen=sluagh80.playerGeneration;}
 uint32_t attack=0;readAt(base+signals->attackMaskRva,&attack,4);const uint32_t mask=attack|(uint32_t)inputBoundary->liftNativeMask|(uint32_t)kainPolicy107->releaseInputMask;
 if(!kainPlayerBusy97(sluagh80.player,GetTickCount64())){
  suppressed&=output->held;output->held&=~suppressed;output->pressed&=~suppressed;output->released&=~suppressed;return false;
 }
 const uint32_t consumed=(output->held|output->pressed)&mask;suppressed|=consumed;
 output->held&=~mask;output->pressed&=~mask;output->released&=~mask;
 static uint64_t receipt;const uint64_t now=GetTickCount64();if(consumed&&now-receipt>=1000){receipt=now;record("kain107 reaction-input consumed=%x native-attack-blocked=1",consumed);}
 static _Thread_local uint64_t cleared;const uint64_t serial=kainPlayer96.last>kainPlayer96.proneStart?kainPlayer96.last:kainPlayer96.proneStart;
 if(cleared!=serial){cleared=serial;localCancelCombo57();}output->x=output->y=0;return true;
}
static bool kainPlayerPronePose97(uintptr_t actor,const float source[66][13],float out[66][13]){
 (void)actor;(void)source;(void)out;return false; // Native upright animation;no procedural prone transform.
}
static bool kainFatal113(const Sr1LocalFrame *frame,uint64_t now){
 (void)now;uint32_t realm=0,debug=0;int hp=0;
 if(!kainPlayerCurrent96()||!InterlockedCompareExchange(&portableActive60,0,0)||!frame->ready||frame->realm!=1||frame->worldGeneration!=kainPlayer96.world||
  !readAt(base+44600604,&realm,4)||realm!=1||!readAt(base+0x2a88cd0,&hp,4)||hp>(int)kainPolicy113->fatalThreshold||
  !readAt(base+0x2a89434,&debug,4)||!(debug&0x800u))return false;
 if(!kainPlayer96.fatal113){
  kainReleaseHold96();kainPlayer96.fatal113=true;kainPlayer96.reactionUntil=0;kainPlayer96.resumeFall103=false;kainPlayer96.impulse=kainPlayer96.landProne=false;
  kainAirClear95();localCancelCombo57();record("kain113 fatal-queued hp=%d native-player-update-required=1",hp);
 }return true;
}
static void kainFinishNativeHealth113(uintptr_t actor){
 const DWORD saved=GetLastError();const uint64_t now=GetTickCount64();uint32_t realm=0,flags=0;uint16_t mode=0;int hp=0;uintptr_t callback=0;
 if(!kainPlayer96.fatal113||actor!=sluagh80.player||!kainPlayerCurrent96()||!InterlockedCompareExchange(&portableActive60,0,0)||
  !readAt(base+44600604,&realm,4)||!readAt(base+0x2a88cd0,&hp,4)||!readAt(base+0x2a89536,&mode,2)||mode||
  !readAt(base+0x2a8950c,&flags,4)||(flags&0x10000000u)||!readAt(base+host->callbackRva,&callback,8)||callback==base+0xf41c0){SetLastError(saved);return;}
 if(realm==1&&hp<=(int)kainPolicy113->fatalThreshold){
  int timer=0;readAt(base+0x2a88cd8,&timer,4);
  const bool owned=kainPlayer96.ownsImmunity&&timer>=0&&timer<=kainPlayer96.immunity&&now>=kainPlayer96.last&&now-kainPlayer96.last<2000;
  if(owned){const int zero=0;memcpy((void*)(base+0x2a88cd8),&zero,4);kainPlayer96.ownsImmunity=false;timer=0;}
  if(!timer){
   ((void(*)(uintptr_t))(base+(uintptr_t)kainPolicy113->nativeHealthRva))(actor);
   readAt(base+44600604,&realm,4);readAt(base+0x2a88cd0,&hp,4);
   if(realm==1&&hp<=(int)kainPolicy113->fatalThreshold)((int(*)(uintptr_t))(base+(uintptr_t)kainPolicy113->nativePlaneShiftRva))(actor);
  }
 }
 int16_t type=-1,time=-1;readAt(base+44600604,&realm,4);readAt(base+(uintptr_t)kainPolicy113->morphTypeRva,&type,2);readAt(base+(uintptr_t)kainPolicy113->morphTimeRva,&time,2);
 // Type0 is normal DURING a Material->Spectral morph. Do not restart it.
 // Only a settled Material world with an already Spectral player needs the
 // original pending morph service at this post-player boundary.
 if(realm==2&&type==0&&time==1000){((void(*)(void))(base+(uintptr_t)kainPolicy113->nativeMorphRva))();readAt(base+(uintptr_t)kainPolicy113->morphTimeRva,&time,2);readAt(base+(uintptr_t)kainPolicy113->morphTypeRva,&type,2);}
 if(realm==2&&type==1&&time==1000)kainPlayer96.fatal113=false;
 if(!kainPlayer96.fatalAttempt113||now-kainPlayer96.fatalAttempt113>=250){kainPlayer96.fatalAttempt113=now;readAt(base+0x2a88cd0,&hp,4);record("kain113 native-death-phase realm=%u morph=%d time=%d hp=%d pending=%u",realm,type,time,hp,kainPlayer96.fatal113);}
 SetLastError(saved);
}
static bool kainPlayerContact96(uintptr_t attacker,uintptr_t target,int power,unsigned kind,bool release,const Sr1LocalFrame *frame,uint64_t now){
 if(!sluaghOwned80(attacker)||target!=sluagh80.player||generation(target)!=sluagh80.playerGeneration||!frame->ready||frame->realm!=1||frame->worldGeneration!=sluagh80.world||
  !InterlockedCompareExchange(&portableActive60,0,0))return false;
 if(localDodgeBusy56(frame,target,now)){if(kind==101)record("kain103 beam-contact-refused reason=dodge");return false;}
 int before=0,after=0,timer=0;uint32_t debug=0;uintptr_t current=0;
 uint32_t actualRealm=0;
 if(!readAt(base+host->actorRva,&current,8)||current!=target||!readAt(base+44600604,&actualRealm,4)||actualRealm!=1||!readAt(base+0x2a88cd0,&before,4)||!readAt(base+0x2a89434,&debug,4)||!(debug&0x800u))return false;
 if(!kainPlayerCurrent96()){kainClearPlayer96();kainPlayer96.player=target;kainPlayer96.generation=sluagh80.playerGeneration;kainPlayer96.world=sluagh80.world;}
 if(before<=(int)kainPolicy113->fatalThreshold){kainFatal113(frame,now);return false;}
 readAt(base+0x2a88cd8,&timer,4);
 const bool ownTimer=kainPlayer96.ownsImmunity&&timer>=0&&timer<=kainPlayer96.immunity&&now>=kainPlayer96.last&&now-kainPlayer96.last<2000;
 if(ownTimer){const int zero=0;memcpy((void*)(base+0x2a88cd8),&zero,4);}
 kainOriginalLose96(power);readAt(base+0x2a88cd0,&after,4);
 if(after>=before){if(ownTimer)memcpy((void*)(base+0x2a88cd8),&timer,4);record("kain96 contact-no-hp power=%d hp=%d immunity=%d",power,before,timer);return false;}
 readAt(base+0x2a88cd8,&kainPlayer96.immunity,4);kainPlayer96.last=now;kainPlayer96.ownsImmunity=true;
 if(after<=(int)kainPolicy113->fatalThreshold){
  int16_t root[3];if(kind!=101&&readAt(target+0x9c,root,6)){const float point[3]={root[0],root[1],root[2]+260.f};kainImpact96(point,now);}
  record("kain96 contact-applied kind=%u power=%d hp=%d/%d loss=%d charge=%u heavy=%u release=%u yellow=%u fatal=1",kind,power,before,after,before-after,sluagh80.ai.bladeCharge96,power>=8192,release,sluagh80.yellowCharge100);
  kainFatal113(frame,now);return true;
 }
 uintptr_t callback=0;readAt(base+host->callbackRva,&callback,8);
 const bool beam100=kind==101,heavy=!beam100&&power>=8192,tk=kind==99||kind==100,stun=tk?kainTkStun99():heavy;
 if(stun)kainProneStart97(now,!frame->grounded||(callback==base+groundPolicy->fallRva&&kainPlayerUnsupported103()));
 else if(!tk&&!beam100&&kainPlayer96.reactionUntil<now+180)kainPlayer96.reactionUntil=now+180;
 if(!tk&&!beam100&&!stun&&callback!=base+0xf1f90&&!kainPlayer96.stumble99){
  uintptr_t event=((uintptr_t(*)(uintptr_t,uintptr_t,int,int,int))(base+0x10ee20))(attacker,target,power,120,13);
  if(event){const bool previous=kainReactionEntry96;kainReactionEntry96=true;((void(*)(uintptr_t,uintptr_t,uintptr_t))(base+0x10ffc0))(base+host->stateActorRva,base+0xf1f90,event);kainReactionEntry96=previous;}
 }
 int16_t root[3];if(!beam100&&readAt(target+0x9c,root,6)){float point[3]={root[0],root[1],root[2]+260.f};LocalSphere body;if(localContactSphere(target,false,true,NULL,NULL,&body))for(unsigned k=0;k<3;k++)point[k]=body.native.center[k];kainImpact96(point,now);}
 if(!release){sluagh80.ai.bladeCharge96=kainChargeHit96(sluagh80.ai.bladeCharge96);sluagh80.yellowCharge100=sluagh80.yellowCharge100>=90?100:sluagh80.yellowCharge100+10;}
 if(!tk&&!beam100&&!stun&&(!kainPlayer96.hold||now>=kainPlayer96.hold))kainAirContact95(frame,now,kind);
 if(tk)record("kain99 tk-contact stun=%u chance=30 hp=%d/%d",stun,before,after);
 record("kain96 contact-applied kind=%u power=%d hp=%d/%d loss=%d charge=%u heavy=%u release=%u yellow=%u",kind,power,before,after,before-after,sluagh80.ai.bladeCharge96,heavy,release,sluagh80.yellowCharge100);return true;
}
static bool kainTelekinesis96(const Sr1LocalFrame *frame,uint64_t now,bool pull){
 int16_t own[3],victim[3];if(!readAt(sluagh80.actor+0x9c,own,6)||!readAt(sluagh80.player+0x9c,victim,6))return false;
 float from[3]={own[0],own[1],own[2]+700.f};int16_t to[3]={victim[0],victim[1],(int16_t)(victim[2]+300)};
 if(hypotf(victim[0]-own[0],victim[1]-own[1])>6000||!localNativeLineClear(sluagh80.actor,sluagh80.world,from,to))return false;
 const bool hit=kainPlayerContact96(sluagh80.actor,sluagh80.player,4096,100,false,frame,now);
 record("kain99 original-tk-request pull=%u hit=%u no-forced-fall=1",pull,hit);return hit;
}
static void kainPollPlayer96(const Sr1LocalFrame *frame,uint64_t now){
 if(!kainPlayer96.player)return;
 if(!kainPlayerCurrent96()||!InterlockedCompareExchange(&portableActive60,0,0)||frame->worldGeneration!=kainPlayer96.world){kainClearPlayer96();return;}
 if(kainPlayer96.fatal113)return; // Keep ownership until the native world morph completes.
 if(frame->realm!=1){kainClearPlayer96();return;}
 if(!frame->ready)return;
 if(kainFatal113(frame,now)||kainPlayer96.fatal113)return;
 if(kainPlayer96.hold&&now>=kainPlayer96.hold){
  const bool resume=kainPlayer96.resumeFall103;uintptr_t callback=0;readAt(base+host->callbackRva,&callback,8);
  kainReleaseHold96();kainPlayer96.resumeFall103=false;
  if(resume&&kainPlayerUnsupported103()&&(callback==base+0xf59d0||callback==base+groundPolicy->fallRva||callback==base+0xf1f90)){
   int speed[3]={0};readAt(sluagh80.player+0x2cc,speed,12);
   ((void(*)(uintptr_t,uintptr_t,uintptr_t))(base+0x10ffc0))(base+host->stateActorRva,base+groundPolicy->fallRva,0);
   ((void(*)(uintptr_t,int,int,int,int))(base+0xe4230))(sluagh80.player,-16,speed[0],speed[1],speed[2]>0?0:speed[2]);
   record("kain103 aerial-reaction-ended native-fall=1 gravity=-16");
  }
 }


}
static bool kainPreparePlayer96(void){
 const unsigned char lose[]={0x48,0x83,0xec,0x28,0x66,0x83,0x3d},reaction[]={0x48,0x89,0x6c,0x24,0x20,0x56,0x57,0x41,0x56},peek[]={0x48,0x63,0x01,0x3b,0x41,0x04,0x75,0x03};
 if(!matches((uintptr_t)kainPolicy113->nativeHealthRva,(unsigned char[]){0x40,0x53,0x48,0x83,0xec,0x30},6)||
 !matches((uintptr_t)kainPolicy113->nativePlaneShiftRva,(unsigned char[]){0x48,0x83,0xec,0x28,0xf7,0x05},6)||
 !matches((uintptr_t)kainPolicy113->nativeMorphRva,(unsigned char[]){0x48,0x89,0x5c,0x24,0x08,0x48,0x89,0x74,0x24,0x10,0x57},11)||
 !matches(0xe6050,lose,sizeof lose)||!matches(0xf1f90,reaction,sizeof reaction)||!matches(0x10e620,peek,sizeof peek)||!matches(0xf59d0,(unsigned char[]){0x48,0x89,0x5c,0x24,0x18,0x55,0x56,0x57},8))return false;
 return MH_CreateHook((void*)(base+0xf59d0),kainStumble99,(void**)&kainOriginalStumble99)==MH_OK&&
 MH_CreateHook((void*)(base+0xe6050),kainLose96,(void**)&kainOriginalLose96)==MH_OK&&
 MH_CreateHook((void*)(base+0xf1f90),kainHit96,(void**)&kainOriginalHit96)==MH_OK&&
 MH_CreateHook((void*)(base+0x10e620),kainPeek96,(void**)&kainOriginalPeek96)==MH_OK;
}
