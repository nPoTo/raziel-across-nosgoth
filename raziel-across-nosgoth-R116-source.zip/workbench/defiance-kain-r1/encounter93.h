// SPDX-License-Identifier: GPL-3.0-or-later
#pragma once
typedef struct {
 bool saved;uintptr_t player;uint32_t generation,world;uint64_t session,phase;
 int16_t hp,maximum,position[3];float yaw,behaviorTimer,cooldowns[128];
 unsigned bladeCharge96,yellowCharge100;
 uint64_t lastTelekinesis98;
} KainEncounter93;
static bool kainSameEncounter93(const KainEncounter93 *s,uintptr_t player,uint32_t generation,uint64_t session){
 return s->saved&&s->player==player&&s->generation==generation&&s->session==session;
}
static bool kainCanResume93(const KainEncounter93 *s,uintptr_t player,uint32_t generation,uint64_t session,uint32_t world,unsigned realm,bool active,bool ready){
 return active&&ready&&realm==1&&s->hp>0&&s->maximum>=s->hp&&s->maximum<=32767&&s->world==world&&kainSameEncounter93(s,player,generation,session);
}
static void kainRemember93(KainEncounter93 *s,uintptr_t player,uint32_t generation,uint64_t session,uint32_t world,int16_t hp,int16_t maximum,const int16_t position[3],float yaw,uint64_t phase,float behaviorTimer,const float cooldowns[128]){
 if(hp<=0||maximum<=0||hp>maximum){s->saved=false;return;}
 const bool same=kainSameEncounter93(s,player,generation,session)&&s->world==world;
 if(same&&hp>s->hp)hp=s->hp;
 *s=(KainEncounter93){.saved=true,.player=player,.generation=generation,.session=session,.world=world,.hp=hp,.maximum=maximum,.yaw=yaw,.phase=phase,.behaviorTimer=behaviorTimer};
 memcpy(s->position,position,6);memcpy(s->cooldowns,cooldowns,sizeof s->cooldowns);
}
static inline bool kainMaterial93(unsigned material,unsigned count){return count==18&&material<count;}
