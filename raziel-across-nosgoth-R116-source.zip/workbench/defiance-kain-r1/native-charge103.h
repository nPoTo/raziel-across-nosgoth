// SPDX-License-Identifier: GPL-3.0-or-later
#pragma once
// Run the installed SR1 KAIN_ChargeUp, not a replacement animation curve.
// Only this stack context is synthetic; the field is a real owned native FX.
// The routine stores no context pointers. Its native helper reads only matrix
// translation; no temporary actor is ever registered in the game.
static bool kainChargeRays103(uint64_t elapsed,const int16_t source[3]){
 if(!kainEffectCurrent100(kainBeam100.field,0x86)||
    !matches((uintptr_t)kainPolicy103->chargeUpRva,(unsigned char[]){0x48,0x89,0x5c,0x24,0x10,0x48,0x89,0x6c},8))return false;
 unsigned char actor[0x2d0]={0},mv[0x298]={0},vars[0x30]={0},attrs[0x20]={0},ma[0x10]={0},matrix[32]={0};
 uintptr_t p=(uintptr_t)mv;memcpy(actor+0x2c0,&p,8);p=(uintptr_t)ma;memcpy(actor+0x40,&p,8);
 if(!readAt(sluagh80.actor+0x9c,actor+0x9c,6))return false;
 p=(uintptr_t)matrix;memcpy(actor+0x68,&p,8);p=(uintptr_t)vars;memcpy(mv+0x290,&p,8);
 p=(uintptr_t)attrs;memcpy(ma+8,&p,8);memcpy(vars+0x10,&kainBeam100.field,8);
 // Native timeToBolt is integral frames*33. Scaling both time arguments by33
 // preserves its exact original curve over the requested two real seconds.
 const int duration=(int)kainPolicy103->castMs,total=duration*33;
 const int16_t ticks=(int16_t)duration;memcpy(attrs+0x12,&ticks,2);memcpy(vars+4,&total,4);
 for(unsigned k=0;k<3;k++){const int value=source[k];memcpy(matrix+0x14+k*4,&value,4);}
 ((void(*)(uintptr_t,int,int))(base+(uintptr_t)kainPolicy103->chargeUpRva))((uintptr_t)actor,(int)(elapsed>(uint64_t)duration?duration:elapsed)*33,0);
 return true;
}
