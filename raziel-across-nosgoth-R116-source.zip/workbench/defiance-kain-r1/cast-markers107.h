// SPDX-License-Identifier: GPL-3.0-or-later
#pragma once
static bool kainMarkerTarget107(int16_t target[3]){
 const uintptr_t level=((uintptr_t(*)(int32_t))(base+0x115b00))((int32_t)sluagh80.world);uint32_t count=0;uintptr_t markers=0;unsigned eligible=0;
 if(!level||!readAt(level+(uintptr_t)kainPolicy107->markerCountOffset,&count,4)||!count||count>2048||
  !readAt(level+(uintptr_t)kainPolicy107->markerListOffset,&markers,8)||!markers)return false;
 for(unsigned i=0;i<count;i++){int16_t record[4];if(!readAt(markers+i*8,record,8))return false;if(record[3]>=kainPolicy107->markerStart&&record[3]<=kainPolicy107->markerEnd)eligible++;}
 if(!eligible)return false;
 target[0]=target[1]=target[2]=INT16_MIN;
 ((void(*)(uintptr_t,int16_t*,int,int))(base+(uintptr_t)kainPolicy107->markerFunctionRva))(sluagh80.actor,target,(int)kainPolicy107->markerStart,(int)kainPolicy107->markerEnd);
 for(unsigned k=0;k<3;k++)if(target[k]<=-31000||target[k]>=31000)return false;
 record("kain107 native-cast-marker candidates=%u target=%d/%d/%d farthest-native=1",eligible,target[0],target[1],target[2]);return true;
}
static bool kainMarkerReached107(void){
 int16_t root[3];return readAt(sluagh80.actor+0x9c,root,6)&&hypotf(root[0]-kainBeam100.anchor107[0],root[1]-kainBeam100.anchor107[1])<=(float)kainPolicy107->markerTolerance;
}
static bool kainMarkerDash107(float direction[2]){
 int16_t root[3];if(!readAt(sluagh80.actor+0x9c,root,6))return false;
 const float dx=kainBeam100.anchor107[0]-root[0],dy=kainBeam100.anchor107[1]-root[1],distance=hypotf(dx,dy);if(distance<=1)return false;
 const float angles[]={0,.78539816339f,-.78539816339f,1.57079632679f,-1.57079632679f};
 for(unsigned divisor=1;divisor<=8;divisor*=2){for(unsigned a=0;a<5;a++){
  const float length=fminf(distance,(float)kainPolicy102->dashDistance/divisor),c=cosf(angles[a]),s=sinf(angles[a]);
  const float x=(c*dx-s*dy)*length/distance,y=(s*dx+c*dy)*length/distance;const unsigned steps=(unsigned)ceilf(length/60.f);int16_t at[3],next[3];memcpy(at,root,6);bool clear=true;kainMotion97.floorValid=false;
  for(unsigned i=0;i<steps;i++){if(!kainStepPlan97(at,x/steps,y/steps,next)){clear=false;break;}memcpy(at,next,6);}kainMotion97.floorValid=false;
  if(clear){direction[0]=x;direction[1]=y;return true;}
 }}
 return false;
}
