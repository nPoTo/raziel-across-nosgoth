// SPDX-License-Identifier: GPL-3.0-or-later
#pragma once
#include "kain107-policy.h"
static const Sheet_kain107 *const kainPolicy107=&sheet_kain107_arm_winding_native_markers_and_reaction_input;
static const Sheet_kain108 *const kainPolicy108=&sheet_kain108_arm_primary_continuous_coil_and_story_kain;
static const Sheet_kain109 *const kainPolicy109=&sheet_kain109_story_resume_training_and_arm_volume;
static const Sheet_kain110 *const kainPolicy110=&sheet_kain110_door_preload_single_proxy_and_shoulder_coil;
static const Sheet_kain111 *const kainPolicy111=&sheet_kain111_native_original_victory_visibility;
static const Sheet_kain112 *const kainPolicy112=&sheet_kain112_fatal_native_shift_and_original_fade;
static const Sheet_kain113 *const kainPolicy113=&sheet_kain113_native_death_phase_unarmed_and_shortcuts;
static const Sheet_kain114 *const kainPolicy114=&sheet_kain114_boss_percent_damage_scene_fade_and_status;
static volatile LONG localArmEnabled107=1;
static SHORT (WINAPI *localArmKey107)(int)=GetAsyncKeyState;
static _Thread_local struct {uintptr_t actor;uint32_t generation,world,realm;uint64_t tick;float points[3][3];unsigned char matrices[41*32];bool valid;} localArm107;
static uint32_t localSwordTint75(unsigned);
static _Thread_local bool localArmDrawing107;
typedef void (*LocalArmLightning107)(uintptr_t,int,const int16_t*,const int16_t*,int,int,int,int,int,uint32_t,uint32_t,int,int);
static LocalArmLightning107 localArmOriginalLightning107;
static void localArmLightning107(uintptr_t m,int angle,const int16_t *a,const int16_t *b,int width,int small,int segments,int sine,int variation,uint32_t color,uint32_t glow,int mode,int layer){
 if(localArmDrawing107&&(uintptr_t)__builtin_return_address(0)==base+(uintptr_t)kainPolicy107->windingThirdReturnRva)return;
 localArmOriginalLightning107(m,angle,a,b,width,small,segments,sine,variation,color,glow,mode,layer);
}
static uint32_t localArmNativeColor109(uint32_t rgb){return ((rgb&255u)<<16)|(rgb&0xff00u)|((rgb>>16)&255u);}
static void localArmToggle107(const Sr1LocalFrame *frame,bool down){
 down=down||(localArmKey107((int)kainPolicy107->glowKey)&0x8000);static bool held;const bool edge=down&&!held;held=down;
 if(edge&&frame->ready&&frame->renderBlend&&!localPhysicalCarry(player)){
  const LONG enabled=InterlockedXor(&localArmEnabled107,1)^1;record("reaver-arm108 toggle=%ld key=V-or-dpad-up",enabled);
 }
}
static void localArmCapture107(uintptr_t actor,const float pose[66][13],const Sr1LocalFrame *frame){
 localArm107.valid=false;
 if(!frame->ready||actor!=player||!localCurrentForm(frame->realm)||localPhysicalCarry(actor))return;
 for(unsigned bone=38;bone<=40;bone++)for(unsigned k=0;k<3;k++){
  const float v=pose[bone][10+k];if(!isfinite(v)||fabsf(v)>1000000)return;localArm107.points[bone-38][k]=v;
 }
 memset(localArm107.matrices,0,sizeof localArm107.matrices);
 for(unsigned bone=39;bone<=40;bone++){
  unsigned char *out=localArm107.matrices+bone*32;
  for(unsigned k=0;k<9;k++){if(!isfinite(pose[bone][k])||fabsf(pose[bone][k])>7)return;const int16_t v=(int16_t)lroundf(pose[bone][k]*4096.f);memcpy(out+k*2,&v,2);}
  for(unsigned k=0;k<3;k++){const int32_t v=(int32_t)lroundf(pose[bone][10+k]);memcpy(out+20+k*4,&v,4);}
 }
 localArm107.actor=actor;localArm107.generation=frame->playerGeneration;localArm107.world=frame->worldGeneration;localArm107.realm=frame->realm;localArm107.tick=GetTickCount64();localArm107.valid=true;
}
static bool localArmCurrent108(const Sr1LocalFrame *f,uintptr_t actor,uint64_t now){
 return f->ready&&actor==player&&localCurrentForm(f->realm)&&InterlockedCompareExchange(&portableActive60,0,0)&&
  InterlockedCompareExchange(&localArmEnabled107,0,0)&&localArm107.valid&&localArm107.actor==actor&&
  localArm107.generation==f->playerGeneration&&localArm107.world==f->worldGeneration&&localArm107.realm==(uint32_t)f->realm&&
  now>=localArm107.tick&&now-localArm107.tick<=(uint64_t)kainPolicy108->armCaptureMs&&!localPhysicalCarry(actor);
}
static bool localArmWinding107(uintptr_t actor,unsigned form,uint64_t now){
 const DWORD saved=GetLastError();uintptr_t originalMatrix=0;if(!readAt(actor+0x68,&originalMatrix,8)||!originalMatrix){SetLastError(saved);return false;}
 unsigned char scratch[0x2c8]={0},data[0x28]={0},bladeMatrix[64]={0};const uintptr_t dataPtr=(uintptr_t)data,bladePtr=(uintptr_t)bladeMatrix,armPtr=(uintptr_t)localArm107.matrices;
 memcpy(scratch+0x2c0,&dataPtr,8);memcpy(scratch+0x68,&bladePtr,8);data[0]=data[1]=1;const int16_t type=2,scale=4096,phase=(int16_t)(-(int)(now%1600)*4096/1600);memcpy(data+4,&type,2);memcpy(data+6,&phase,2);memcpy(data+0x1c,&scale,2);
 // CVECTOR stores R in the low byte. R107 passed the generic RRGGBB FX
 // palette unchanged. Retain its exact native glow volume but use the blade
 // primary RGB. Black additive core leaves only native glow when uncharged;
 // the existing joined GL helix supplies the charged core continuously.
 const uint32_t primary=localSwordTint75(form),tint=localArmNativeColor109(primary);memcpy(data+0x18,&tint,4);
 uintptr_t expected=originalMatrix;if(!atomic_compare_exchange_strong((_Atomic uintptr_t*)(actor+0x68),&expected,armPtr)){SetLastError(saved);return false;}
 localArmDrawing107=true;((void(*)(uintptr_t))(base+(uintptr_t)kainPolicy107->windingRva))((uintptr_t)scratch);localArmDrawing107=false;
 expected=armPtr;const bool restored=atomic_compare_exchange_strong((_Atomic uintptr_t*)(actor+0x68),&expected,originalMatrix);
 static uint64_t last;if(now-last>=1000){last=now;record("reaver-arm109 native-volume107=1 form=%u primary-rgb=%06x native-cvector=%06x matrix-restored=%u core=charged-coil-only",form,primary,tint,restored);}
 SetLastError(saved);return restored;
}
static bool localArmDraw107(uintptr_t blade){
 const DWORD saved=GetLastError();const Sr1LocalFrame f=readFrame();const uint64_t now=GetTickCount64();
 if(!localArmCurrent108(&f,player,now)||!localBladeMatches(blade)){SetLastError(saved);return false;}const bool result=localArmWinding107(player,localCurrentForm(f.realm),now);SetLastError(saved);return result;
}
static bool localArmPrepare107(void){
 return matches((uintptr_t)kainPolicy107->windingRva,(unsigned char[]){0x4c,0x8b,0xdc,0x41,0x55,0x41,0x57,0x48,0x81,0xec,0x98,0,0,0},14)&&
  MH_CreateHook((void*)(base+(uintptr_t)kainPolicy107->lightningRva),localArmLightning107,(void**)&localArmOriginalLightning107)==MH_OK;
}
