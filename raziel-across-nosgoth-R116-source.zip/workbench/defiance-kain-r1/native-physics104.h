// SPDX-License-Identifier: GPL-3.0-or-later
#pragma once
#include "native-support105.h"
// The engine may replace PhysicsMode after the character callbacks (eb496).
// Adapt the argument at the actual integration boundary; never write that
// global or the user's debug/cheat setting, and never manually integrate XYZ.
static void (*kainOriginalPhysics104)(uintptr_t,uintptr_t,int,int);
static uint64_t kainPhysicsWait104,kainPhysicsLog104;
static uintptr_t kainPhysicsOwner104;static uint32_t kainPhysicsGeneration104,kainPhysicsWorld104;
static void kainRunPhysics104(uintptr_t nativePlayer,uintptr_t state,int section,int mode,const Sr1LocalFrame frame,uint64_t now){
 const DWORD saved=GetLastError();uintptr_t actor=0,callback=0,current=0;
 readAt(state+0x10,&callback,8);readAt(state,&actor,8);
 const bool lostGround=kainGroundState105(callback)&&kainLostSupport105(actor,now);
 const bool owner=(mode==3||(mode==0&&lostGround))&&section==0&&state==base+host->stateActorRva&&frame.ready&&frame.realm==1&&
  InterlockedCompareExchange(&portableActive60,0,0)&&sluaghOwned80(sluagh80.actor)&&sluagh80.hp>0&&
  frame.playerGeneration==sluagh80.playerGeneration&&frame.worldGeneration==sluagh80.world&&
  actor==sluagh80.player&&readAt(base+host->actorRva,&current,8)&&current==actor&&generation(actor)==sluagh80.playerGeneration&&
  (callback==base+groundPolicy->fallRva||lostGround)&&
  now>=kainPlayer96.hold&&now>=kainPlayer96.reactionUntil&&
  !readLocalSlam(&frame,actor,now,250).owner.tick&&kainPlayerUnsupported103();
 bool recovered=false;int before=0;
 if(owner){
  if(kainPhysicsOwner104!=actor||kainPhysicsGeneration104!=frame.playerGeneration||kainPhysicsWorld104!=frame.worldGeneration){kainPhysicsWait104=0;kainPhysicsOwner104=actor;kainPhysicsGeneration104=frame.playerGeneration;kainPhysicsWorld104=frame.worldGeneration;}
  if(!kainPhysicsWait104)kainPhysicsWait104=now;
  if(now>=kainPhysicsWait104&&now-kainPhysicsWait104>=(uint64_t)kainPolicy104->graceMs){
   if(lostGround){
    int speed[3]={0};readAt(actor+0x2cc,speed,12);
    ((void(*)(uintptr_t,uintptr_t,uintptr_t))(base+0x10ffc0))(state,base+groundPolicy->fallRva,0);
    ((void(*)(uintptr_t,int,int,int,int))(base+0xe4230))(actor,-16,speed[0],speed[1],speed[2]>0?0:speed[2]);
    record("kain105 lost-support native-fall=1 previous-handler=%llx",(unsigned long long)(callback-base));
   }mode=0;recovered=true;readAt(actor+0x2d4,&before,4);
  }
 }else{kainPhysicsWait104=0;kainPhysicsOwner104=0;}
 SetLastError(saved);kainOriginalPhysics104(nativePlayer,state,section,mode);const DWORD afterError=GetLastError();
 if(recovered&&(!kainPhysicsLog104||now-kainPhysicsLog104>=1000)){
  kainPhysicsLog104=now;int after=0,globalMode=-1;uintptr_t tracker=0;uint8_t cheat=255;
  readAt(actor+0x2d4,&after,4);readAt(base+0xd6b2ac,&globalMode,4);
  if(readAt(base+(uintptr_t)kainPolicy104->trackerPointerRva,&tracker,8)&&tracker)readAt(tracker+(uintptr_t)kainPolicy104->cheatOffset,&cheat,1);
  record("kain104 native-physics-fall global=%d dispatched=0 vz=%d/%d cheat=%u",globalMode,before,after,cheat);
 }SetLastError(afterError);
}
static void kainPhysics104(uintptr_t nativePlayer,uintptr_t state,int section,int mode){
 const DWORD saved=GetLastError();const Sr1LocalFrame frame=readLocalFrame(false);SetLastError(saved);
 kainRunPhysics104(nativePlayer,state,section,mode,frame,GetTickCount64());
}
static bool kainPreparePhysics104(void){
 const uintptr_t rva=(uintptr_t)kainPolicy104->processPhysicsRva;
 return matches(0xbbb70,(unsigned char[]){0x40,0x53,0x48,0x83,0xec,0x20,0x83,0x49,0x24,0x40},10)&&
  matches(rva,(unsigned char[]){0x48,0x89,0x5c,0x24,0x10,0x48,0x89,0x7c,0x24,0x18,0x41,0x56},12)&&
  MH_CreateHook((void*)(base+rva),kainPhysics104,(void**)&kainOriginalPhysics104)==MH_OK;
}
