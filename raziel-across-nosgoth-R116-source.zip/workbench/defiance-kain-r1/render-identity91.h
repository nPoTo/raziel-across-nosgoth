// SPDX-License-Identifier: GPL-3.0-or-later
#pragma once
// Original sr1.dll 42833..4297e selects a render record independently of
// the legacy model index: object + 0x70 + recordIndex * 0xda0. Eight records
// end at object+0x6d70; native fallback/variant fields follow at 6d74/6d78.
// The current model and instance matrices still have to match exactly.
static inline int hyldenPoseRecord91(uintptr_t record,uintptr_t model,uintptr_t matrices,
 uintptr_t object,uintptr_t expectedModel,uintptr_t expectedMatrices){
 if(!object||object>UINTPTR_MAX-0x6d70||!expectedModel||!expectedMatrices||
 model!=expectedModel||matrices!=expectedMatrices||record<object+0x70)return -1;
 const uintptr_t delta=record-object-0x70;
 if(delta%0xda0||delta/0xda0>=8)return -1;
 return (int)(delta/0xda0);
}
