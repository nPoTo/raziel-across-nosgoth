// SPDX-License-Identifier: GPL-3.0-or-later
#pragma once
#include "native-charge103.h"
#include "cast-markers107.h"
// Explicit requested host ability;ordinary combat still uses original AI.
static bool kainBeamBusy102(void){return kainBeam100.retreat||kainBeam100.raise||kainBeam100.cast||kainBeam100.beam||kainBeam100.recover;}
static void kainBeamIdle102(uint64_t now){
 if(sluagh80.ai.module&&sluagh80.hp>0)snCancel(&sluagh80.ai);
 sluagh80.clip=sluagh80.ai.clip;sluagh80.sample=0;sluagh80.presentationState=sluagh80.reaction86=0;
 sluagh80.hitActive=false;sluagh80.decision=now>=50?now-50:0;kainGrabTick92=0;
 sluagh80.pendingMove[0]=sluagh80.pendingMove[1]=0;sluagh80.pendingMoveTick=0;kainMotion97.dash=false;
}
static void kainAbortBeam102(uint64_t now,bool resume){
 kainEndEffect100(&kainBeam100.field,0x86);kainEndEffect100(&kainBeam100.zap,0x87);
 kainBeam100.retreat=kainBeam100.raise=kainBeam100.cast=kainBeam100.beam=kainBeam100.recover=kainBeam100.dashStart=0;
 sluagh80.pendingMove[0]=sluagh80.pendingMove[1]=0;sluagh80.pendingMoveTick=0;kainMotion97.dash=false;
 if(resume)kainBeamIdle102(now);record("kain102 beam-cleanup resume=%u",resume);
}
static void kainChargePose102(float pose[1264]){
 float upper[1264],root[3];sluaghSample80((unsigned)kainPolicy102->chargePoseLegClip,0,pose,root);
 sluaghSample80((unsigned)kainPolicy102->chargePoseUpperClip,(float)kainPolicy102->chargePoseSample,upper,root);
 // Authored vertical sword carry in front of the face;standing hips/legs.
 const float offset[3]={pose[28]-upper[28],pose[29]-upper[29],pose[30]-upper[30]};
 for(unsigned bone=11;bone<79;bone++){memcpy(pose+bone*16,upper+bone*16,64);for(unsigned k=0;k<3;k++)pose[bone*16+12+k]+=offset[k];}
}
static void kainCastBlend102(float pose[1264],uint64_t elapsed,uint64_t duration){
 const float t=fminf(1,elapsed/(float)duration),w=t*t*(3-2*t);
 for(unsigned i=0;i<1264;i++)pose[i]=kainBeam100.entry[i]+w*(pose[i]-kainBeam100.entry[i]);
}
static void kainCastPoint102(const float pose[1264],int16_t source[3],int16_t target[3]){
 kainBeamPoint100(source,target);int16_t root[3];if(!readAt(sluagh80.actor+0x9c,root,6))return;
 const float *m=pose+65*16,c=cosf(sluagh80.yaw),s=sinf(sluagh80.yaw),scale=.9598479333948396f;
 source[0]=(int16_t)lroundf(root[0]+scale*(c*m[12]-s*m[13]));source[1]=(int16_t)lroundf(root[1]+scale*(s*m[12]+c*m[13]));source[2]=(int16_t)lroundf(root[2]+scale*m[14]);
}
static bool kainSpellFace104(void){
 int16_t own[3],target[3];if(!kainPolicy104->castFacesRoot||!readAt(sluagh80.actor+0x9c,own,6)||!readAt(sluagh80.player+0x9c,target,6))return false;
 const float dx=target[0]-own[0],dy=target[1]-own[1];if(hypotf(dx,dy)<=1)return false;
 // The original mesh faces -Y,matching the gait/world matrix convention.
 // Use actor centres so the raised hand cannot steer the body sideways.
 sluagh80.yaw=atan2f(dx,-dy);
 if(sluagh80.ai.module)snSetFloat(sluagh80.ai.actor,0x48,sluagh80.yaw/6.28318530718f);
 return true;
}
static bool kainBeamFrame100(const Sr1LocalFrame *frame,uint64_t now,bool canFight,float pose[1264]){
 const bool originalReady=kainOriginalObject100(now);
 if(kainBeamBusy102()&&!canFight){kainAbortBeam102(now,false);return false;}
 if(!originalReady)return false;
 int16_t source[3],target[3],root[3];kainBeamPoint100(source,target);
 if(!kainBeamBusy102()&&now>=kainBeam100.notBefore&&canFight&&sluagh80.yellowCharge100>=100&&!sluagh80.airPursuit95&&frame->grounded&&(sluagh80.ai.mode==12||sluagh80.ai.mode==36||sluagh80.ai.mode==41)){
  int v[7];uint32_t colors[2];if(!kainBeamParameters100(v,colors))return false;
  if(!kainMarkerTarget107(kainBeam100.anchor107)){kainBeam100.notBefore=now+1000;record("kain107 native-cast-markers not-found=1 charge-retained=1");return false;}
  kainBeamIdle102(now);sluagh80.yellowCharge100=0;kainBeam100.retreat=now;kainBeam100.dashes=0;kainBeam100.dashStart=0;
  record("kain107 beam-retreat native-marker=1 no-fixed-dash-count=1");
 }
 if(kainBeam100.retreat){
  sluagh80.opacity86=.28f;kainMotion97.dash=true;
  if(!kainBeam100.dashStart){
   if(kainMarkerReached107()){
    kainBeam100.retreat=0;kainBeam100.raise=now;memcpy(kainBeam100.entry,sluagh80.matrices,sizeof kainBeam100.entry);sluagh80.blendTick86=0;kainMotion97.dash=false;sluagh80.opacity86=1;
    record("kain102 sword-raise duration=%lld",(long long)kainPolicy102->raiseMs);
   }else if(now-kainBeam100.retreat>=(uint64_t)kainPolicy107->retreatTimeoutMs||!kainMarkerDash107(kainBeam100.direction)){
    sluagh80.yellowCharge100=100;kainBeam100.notBefore=now+1000;kainAbortBeam102(now,true);record("kain107 native-marker-unreachable retry=1000 charge-retained=1");return false;
   }else{kainBeam100.dashStart=now;memset(kainBeam100.done,0,sizeof kainBeam100.done);record("kain107 marker-dash index=%u vector=%.1f/%.1f",kainBeam100.dashes+1,kainBeam100.direction[0],kainBeam100.direction[1]);}
  }
  if(kainBeam100.retreat){
   const float progress=fminf(1,(now-kainBeam100.dashStart)/(float)kainPolicy102->dashMs);
   for(unsigned k=0;k<2;k++){const float desired=kainBeam100.direction[k]*progress,step=desired-kainBeam100.done[k];sluagh80.pendingMove[k]+=step;kainBeam100.done[k]=desired;}sluagh80.pendingMoveTick=now;
   const SluaghClip80 clip=sluaghResources80.clips[14];float unused[3];sluaghSample80(14,progress*(clip.keys-1)*clip.timePerKey,pose,unused);
   if(progress>=1){kainBeam100.dashes++;kainBeam100.dashStart=0;}return true;
  }
 }
 if(kainBeam100.raise){
  const uint64_t elapsed=now-kainBeam100.raise;kainSpellFace104();
  kainChargePose102(pose);kainCastBlend102(pose,elapsed,(uint64_t)kainPolicy102->raiseMs);if(elapsed<(uint64_t)kainPolicy102->raiseMs)return true;
  kainBeam100.raise=0;kainBeam100.cast=now;kainCastPoint102(pose,source,target);readAt(sluagh80.actor+0x9c,root,6);int16_t offset[3];for(unsigned k=0;k<3;k++)offset[k]=source[k]-root[k];
  kainBeam100.field=((uintptr_t(*)(uintptr_t,int,const int16_t*,int,int,int,uint32_t))(base+0x5a560))(sluagh80.actor,(int)kainPolicy103->chargeSize,offset,(int)kainPolicy103->chargeBand,(int)kainPolicy103->chargeChange,0,(uint32_t)kainPolicy103->chargeColor);
  const bool rays104=kainChargeRays103(0,source);kainBeam100.chargeLogged104=false;
  record("kain104 charge-native begin=%u size=%d change=%d duration=2000",rays104,kainEffectCurrent100(kainBeam100.field,0x86)?*(int16_t*)(kainBeam100.field+0x30):-1,kainEffectCurrent100(kainBeam100.field,0x86)?*(int16_t*)(kainBeam100.field+0x34):-1);
  kainVoice100(1,now);record("kain102 beam-cast start=1 duration=%lld dashes=%u field=%u",(long long)kainPolicy102->castMs,kainBeam100.dashes,kainBeam100.field!=0);
 }
 if(kainBeam100.cast){
  const uint64_t elapsed=now-kainBeam100.cast;
  kainSpellFace104();
  kainChargePose102(pose);kainCastPoint102(pose,source,target);
  if(elapsed<(uint64_t)kainPolicy102->castMs){
   const bool rays104=kainChargeRays103(elapsed,source);
   if(!kainBeam100.chargeLogged104&&elapsed>=(uint64_t)kainPolicy103->castMs/2){kainBeam100.chargeLogged104=true;record("kain104 charge-native middle=%u elapsed=%llu size=%d change=%d",rays104,(unsigned long long)elapsed,kainEffectCurrent100(kainBeam100.field,0x86)?*(int16_t*)(kainBeam100.field+0x30):-1,kainEffectCurrent100(kainBeam100.field,0x86)?*(int16_t*)(kainBeam100.field+0x34):-1);}
   if(rays104){readAt(sluagh80.actor+0x9c,root,6);for(unsigned k=0;k<3;k++){const int16_t offset=source[k]-root[k];memcpy((void*)(kainBeam100.field+0x28+k*2),&offset,2);}}return true;
  }
  kainEndEffect100(&kainBeam100.field,0x86);kainBeam100.cast=0;kainBeam100.beam=now;
  int v[7];uint32_t colors[2];if(kainBeamParameters100(v,colors))kainBeam100.zap=((uintptr_t(*)(uintptr_t,int,int,int,int,int,int,int,int,uint32_t,uint32_t))(base+0x52dc0))(sluagh80.actor,(int)(kainPolicy102->beamMs/33+2),v[0],v[1],v[2],v[3],v[4],v[5],v[6],colors[0],colors[1]);
  float unused[3];sluaghSample80(42,1000,pose,unused);kainCastPoint102(pose,source,target);
  if(kainEffectCurrent100(kainBeam100.zap,0x87))((void(*)(uintptr_t,uintptr_t,int,const int16_t*,uintptr_t,int,const int16_t*,int))(base+0x58500))(kainBeam100.zap,0,0,source,0,0,target,-1);
  const float from[3]={source[0],source[1],source[2]};kainBeam100.hit=hypotf(target[0]-source[0],target[1]-source[1])<=8000&&localNativeLineClear(sluagh80.actor,sluagh80.world,from,target)&&kainBeamDamage100(frame,now);
  record("kain102 beam-release hit=%u native-lightning=%u",kainBeam100.hit,kainBeam100.zap!=0);return true;
 }
 if(kainBeam100.beam){
  if(now-kainBeam100.beam<(uint64_t)kainPolicy102->beamMs){
   kainSpellFace104();
   float unused[3];sluaghSample80(42,1000,pose,unused);kainCastPoint102(pose,source,target);
   if(kainEffectCurrent100(kainBeam100.zap,0x87))((void(*)(uintptr_t,uintptr_t,int,const int16_t*,uintptr_t,int,const int16_t*,int))(base+0x58500))(kainBeam100.zap,0,0,source,0,0,target,-1);return true;
  }
  kainEndEffect100(&kainBeam100.zap,0x87);kainBeam100.beam=0;kainBeam100.recover=now;memcpy(kainBeam100.entry,sluagh80.matrices,sizeof kainBeam100.entry);kainBeamIdle102(now);record("kain102 beam-end effects-cleared=1");
 }
 if(kainBeam100.recover){
  const uint64_t elapsed=now-kainBeam100.recover;float unused[3];sluaghSample80(sluagh80.clip,0,pose,unused);kainCastBlend102(pose,elapsed,(uint64_t)kainPolicy102->recoveryMs);
  if(elapsed<(uint64_t)kainPolicy102->recoveryMs)return true;kainBeam100.recover=0;record("kain102 beam-recovery-complete");
 }return false;
}
