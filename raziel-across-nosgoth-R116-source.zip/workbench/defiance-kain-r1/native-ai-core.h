// SPDX-License-Identifier: GPL-3.0-or-later
#pragma once
// Private boss decision probe derived from the proven Hylden native adapter.
// Not installed and not a complete boss runtime. No host game memory is used.
// Caller supplies relocated original attributes and authentic host facts.
#include <windows.h>
#include <stdint.h>
#include <stdbool.h>
#include <string.h>
#include <math.h>
typedef struct {
 _Alignas(16) unsigned char actor[0x500],state[0x900],target[10*0x68],targetActor[0x500],settings92[0xb00],controller92[0x60],transform93[0x80];
 unsigned char object[0x90],model[0x30],clipMeta[16];
 void *models[1];float cooldowns[128];
 unsigned char *attributes;uintptr_t module;unsigned mode,clip,logical,animationMode;
 float time,speed;unsigned calls,events,animationSerial;
 unsigned damageEvents92,grabEvents92,fxEvents92,projectileRequests94,shockRequests94,powerEffects94,powerCasts95,command95;bool damageIsPower95;uint32_t lastMessage92;unsigned char playerEvent92[96],shockEvent94[80];
 unsigned bladeCharge96,strikeSerial96;
 uint64_t lastTelekinesis98;bool suppressTelekinesis98;
} SluaghNativeAI;
static void snPointer(void *memory,unsigned offset,const void *value){memcpy((char*)memory+offset,&value,8);}
static float snFloat(const void *memory,unsigned offset){float v;memcpy(&v,(const char*)memory+offset,4);return v;}
static void snSetFloat(void *memory,unsigned offset,float v){memcpy((char*)memory+offset,&v,4);}
static uint32_t snU32(const void *memory,unsigned offset){uint32_t v;memcpy(&v,(const char*)memory+offset,4);return v;}
static void snSetU32(void *memory,unsigned offset,uint32_t v){memcpy((char*)memory+offset,&v,4);}
static void *snPtr(const void *memory,unsigned offset){void *v;memcpy(&v,(const char*)memory+offset,8);return v;}
static float snWorldYaw(const SluaghNativeAI *n){return snFloat(n->actor,0x48)*6.28318530718f;}
static _Thread_local SluaghNativeAI *snCurrent92;
static void snCallback(SluaghNativeAI *n,unsigned state,unsigned field){
 if(state>=67)return;snCurrent92=n;
 void (*fn)(void*)=NULL;memcpy(&fn,(void*)(n->module+0x67a2f0+state*40+field),8);if(fn)fn(n->actor);snCurrent92=NULL;
}
// Engine animation service from original 9ed80: AI requests logical IDs;
// descriptors select runtime keylists. Native command timing uses current 3c0,
// not pending request 478. Boss Kain has 48 descriptors, ending at attrs+0x58.
static int snConsumeAnimation(SluaghNativeAI *n){
 unsigned logical=n->state[0x478];if(logical==255)return 1;
 const unsigned char *table=snPtr(n->attributes,0x40),*end=snPtr(n->attributes,0x58);
 if(!table||end!=table+48*16||logical>=48)return 0;
 const unsigned char *descriptor=table+logical*16;uint16_t speed;memcpy(&speed,descriptor,2);
 if(descriptor[8]>=48||speed!=4096)return 0;
 n->logical=logical;n->clip=descriptor[8];n->animationMode=n->state[0x479];n->speed=speed/4096.f;
 n->state[0x478]=255;n->state[0x3c0]=(unsigned char)logical;n->state[0x3c1]=(unsigned char)n->animationMode;
 memset(n->state+0x3c2,0,2);snPointer(n->state,0x3b8,descriptor);n->animationSerial++;
 n->clipMeta[5]=(n->clip>=8&&n->clip<=11)?75:100;
 n->time=0;return 1;
}
static int snInit(SluaghNativeAI *n,uintptr_t module,unsigned char *attributes){
 memset(n,0,sizeof(*n));n->attributes=attributes;n->module=module;n->mode=12;n->clip=3;
 snPointer(n->actor,0x310,attributes);snPointer(n->actor,0x3f8,n->state);
 snPointer(n->actor,0x60,n->transform93);snSetFloat(n->transform93,0x7c,1);
 snPointer(n->state,0x3e0,snPtr(snPtr(attributes,0x28),0));
 snPointer(n->state,0x508,n->target);snPointer(n->state,0x470,n->cooldowns);
 n->models[0]=n->model;snSetU32(n->model,4,79);n->object[0x20]=1;
 snPointer(n->object,0x28,n->models);snPointer(n->actor,0x88,n->object);
 snPointer(n->target,0x40,n->targetActor);n->target[0x5c]=0xa0;for(unsigned i=1;i<10;i++)n->target[i*0x68+0x5c]=1;snPointer(n->state,0x4b8,n->target);
 snPointer((void*)module,0xc67120,n->settings92);snPointer((void*)module,0xc5aa78,n->targetActor);snPointer((void*)module,0x67b760,(void*)(module+0xc87ac0));
 n->clipMeta[5]=100;snPointer(n->actor,0x220,n->clipMeta);
 snSetFloat(n->state,0x860,100);snSetFloat(n->state,0x40c,1);
 snSetU32(n->state,0x574,5000);snSetU32(n->state,0x578,5000);
 snSetU32(n->actor,0x404,12);n->state[0x47b]=0xff;n->state[0x478]=0xff;
 snPointer((void*)module,0xc5b0f0,n->state+0x338); // Original single-attacker slot0.
 snSetFloat((void*)module,0xc5b1f0,0);snCallback(n,12,0);return snConsumeAnimation(n);
}
static void snWorld(SluaghNativeAI *n,const float position[3],const float target[3],float health,float maxHealth){
 memcpy(n->actor+0x20,position,12);memcpy(n->target,target,12);memcpy(n->targetActor+0x20,target,12);
 memcpy(n->transform93+0x70,position,12);
 memcpy(n->state+0x314,target,12);
 const float angle=snWorldYaw(n),c=cosf(angle),s=sinf(angle);
 float d[3];for(unsigned i=0;i<3;i++)d[i]=target[i]-position[i];
 snSetFloat(n->target,0x10,c*d[0]+s*d[1]);snSetFloat(n->target,0x14,-s*d[0]+c*d[1]);snSetFloat(n->target,0x18,d[2]);
 snSetFloat(n->target,0x4c,sqrtf(d[0]*d[0]+d[1]*d[1]+d[2]*d[2]));
 snSetU32(n->state,0x574,(uint32_t)fmaxf(0,health));snSetU32(n->state,0x578,(uint32_t)fmaxf(1,maxHealth));
}
static void snClock94(SluaghNativeAI *n,float delta){
 if(!isfinite(delta)||delta<=0||delta>100)return;
 snSetFloat(n->state,0x9c,delta);
 for(unsigned i=0;i<128;i++)n->cooldowns[i]=fmaxf(0,n->cooldowns[i]-delta);
 const unsigned timers[]={0x410,0x414,0x418,0x444,0x454};
 for(unsigned i=0;i<5;i++)snSetFloat(n->state,timers[i],fmaxf(0,snFloat(n->state,timers[i])-delta));
}
static unsigned snDecision(SluaghNativeAI *n,const float position[3],const float target[3],float delta,float health,float maxHealth){
 if(!isfinite(delta)||delta<=0||delta>100)return 255;
 snWorld(n,position,target,health,maxHealth);snSetFloat(n->state,0x9c,delta);
 n->state[0x47b]=0xff;snSetU32(n->state,0x3e8,snU32(n->state,0x3e8)&~1u);
 snSetU32(n->actor,0x404,12);snCallback(n,12,8);n->calls++;
 unsigned next=n->state[0x47b];
 if(next==37||next==42){
  snSetU32(n->actor,0x404,next);snSetU32(n->state,0x3e8,snU32(n->state,0x3e8)&~1u);
  snCallback(n,next,0);n->mode=next;n->time=0;
 }else if(next==36||next==41){
  snSetU32(n->actor,0x404,next);n->mode=next;snCallback(n,next,0);
 }else {
  if(n->mode==36||n->mode==41)snCallback(n,12,0);
  n->mode=12;
 }
 if(!snConsumeAnimation(n))return 254;
 return next;
}
static unsigned snActionEnd(SluaghNativeAI *n){
 unsigned previous=n->mode;if(previous!=37&&previous!=42)return 255;
 void *oldDescriptor=snPtr(n->state,0x200);
 uintptr_t (*message)(void*,uint32_t,uintptr_t)=snPtr((void*)(n->module+0x67a2f0+previous*40),24);
 snCurrent92=n;if(message)message(n->actor,0x08000000,0);snCurrent92=NULL;
 unsigned next=n->state[0x47b];
 // Periodic original actions can remain in state37 after an animation end.
 // Their original update chooses the next action when timer414 expires.
 if(next==255&&!(snU32(n->state,0x3e8)&1u))return previous;
 if(next!=12&&next!=37&&next!=42&&next!=36&&next!=41)return 255;
 // Preserve the original next descriptor while the previous state's exit runs.
 void *descriptor=snPtr(n->state,0x200);snPointer(n->state,0x200,oldDescriptor);snCallback(n,previous,16);snPointer(n->state,0x200,descriptor);
 snSetU32(n->state,0x3e8,snU32(n->state,0x3e8)&~1u);n->state[0x47b]=0xff;
 snSetU32(n->actor,0x404,next);snCallback(n,next,0);n->mode=next;n->time=0;return snConsumeAnimation(n)?next:255;
}
static void snCancel(SluaghNativeAI *n){
 if(n->mode==37||n->mode==42)snCallback(n,n->mode,16);
 snSetU32(n->state,0x3e8,snU32(n->state,0x3e8)&~1u);n->state[0x47b]=0xff;
 snSetU32(n->actor,0x404,12);snCallback(n,12,0);n->mode=12;n->time=0;snConsumeAnimation(n);
}
static void snAttackFrame(SluaghNativeAI *n,float nativeTime,int previousKey,float delta){
 if(n->mode!=37)return;
 snSetFloat(n->state,0x9c,delta);snSetFloat(n->actor,0x1d4,nativeTime);
 int16_t previous=(int16_t)previousKey;memcpy(n->state+0x3c2,&previous,2);
 void *oldDescriptor=snPtr(n->state,0x200);snCallback(n,37,8);n->calls++;
 if(snU32(n->state,0x3e8)&1u){
  const unsigned next=n->state[0x47b];
  if(next==12||next==37||next==42){
   void *nextDescriptor=snPtr(n->state,0x200);snPointer(n->state,0x200,oldDescriptor);snCallback(n,37,16);snPointer(n->state,0x200,nextDescriptor);
   snSetU32(n->state,0x3e8,snU32(n->state,0x3e8)&~1u);n->state[0x47b]=255;snSetU32(n->actor,0x404,next);snCallback(n,next,0);n->mode=next;
   if(!snConsumeAnimation(n))n->clip=255;
  }
 }
}
// Native paired-grab admission after the host confirms that the requested
// target is in contact. Original c3060 chooses GRAB or ALTGRAB and copies
// the original pending command/target; no replacement attack is selected.
static int snCommit92(SluaghNativeAI *n){
 if(!(snU32(n->state,0x3e8)&1u))return 1;const unsigned next=n->state[0x47b];
 if(next>=67)return 0;snCallback(n,n->mode,16);snSetU32(n->state,0x3e8,snU32(n->state,0x3e8)&~1u);n->state[0x47b]=255;
 snSetU32(n->actor,0x404,next);n->mode=next;snCallback(n,next,0);return snConsumeAnimation(n);
}
static int snPursuit95(SluaghNativeAI *n){
 if(n->mode!=36&&n->mode!=41)return 1;
 snCallback(n,n->mode,8);
 if((snU32(n->state,0x3e8)&1u)&&n->state[0x47b]!=12&&n->state[0x47b]!=36&&n->state[0x47b]!=41&&n->state[0x47b]!=37&&n->state[0x47b]!=42)return 0;
 return snCommit92(n)&&snConsumeAnimation(n);
}
static int snGrab92(SluaghNativeAI *n){
 if(n->mode!=37||!snPtr(n->state,0x258)||!snPtr(n->state,0x268))return 0;
 snSetU32(n->target,0x5c,snU32(n->target,0x5c)|0x4000u);snCurrent92=n;
 ((void(*)(void*))(n->module+0xc3060))(n->actor);snCurrent92=NULL;
 return snCommit92(n)&&(n->mode==48||n->mode==60);
}
static int snPairFrame92(SluaghNativeAI *n,float delta,bool complete){
 if(n->mode!=48&&n->mode!=49&&n->mode!=60)return n->clip<48;
 snSetFloat(n->state,0x9c,delta);
 if(complete&&(n->mode==48||n->mode==60))snSetU32(n->target,0x5c,snU32(n->target,0x5c)&~0x4000u);
 snCallback(n,n->mode,8);if(!snCommit92(n))return 0;
 if(n->mode==49&&complete&&snFloat(n->state,0x410)<=0)snCancel(n);
 return n->clip<48;
}
static int snHit95(SluaghNativeAI *n,bool grounded,int side){
 const unsigned char *sub=snPtr(n->state,0x3e0),*const *combats=snPtr(n->attributes,0x30),*damage=snPtr(n->attributes,0xb0);
 if(!sub||sub[8]!=0||!combats||!combats[0]||!damage)return 0;
 const unsigned index=grounded?(side<0?5:7):combats[0][0x23];if(index>=48)return 0;
 snCallback(n,n->mode,16);snSetU32(n->target,0x5c,snU32(n->target,0x5c)&~0x4000u);
 snPointer(n->state,0x178,damage+index*48);const uint16_t stun=1;memcpy(n->state+0x198,&stun,2);
 snSetU32(n->state,0x3e8,(snU32(n->state,0x3e8)&~0x40u)|(grounded?0x40u:0));
 snSetU32(n->actor,0x404,15);n->state[0x47b]=255;n->mode=15;snCallback(n,15,0);
 return snConsumeAnimation(n);
}
static int snHit92(SluaghNativeAI *n){return snHit95(n,false,0);}
