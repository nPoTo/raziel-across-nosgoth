// SPDX-License-Identifier: GPL-3.0-or-later
#pragma once
typedef struct {uint64_t tick;uint32_t generation;float point[3],radius;bool ring,blood;} KainEffect95;
static SRWLOCK kainEffectLock95=SRWLOCK_INIT;
static KainEffect95 kainEffects95[16];static unsigned kainEffectCursor95;
typedef struct {uint32_t generation;uint64_t tick;float point[3];} KainProjectileStar97;
static KainProjectileStar97 kainProjectileStars97[8];
static void kainProjectileStar97(uint32_t generation,const float point[3],uint64_t now){
 AcquireSRWLockExclusive(&kainEffectLock95);unsigned slot=8;for(unsigned i=0;i<8;i++){if(kainProjectileStars97[i].generation==generation){slot=i;break;}if(slot==8&&now-kainProjectileStars97[i].tick>80)slot=i;}
 if(slot<8){kainProjectileStars97[slot].generation=generation;kainProjectileStars97[slot].tick=now;memcpy(kainProjectileStars97[slot].point,point,12);}ReleaseSRWLockExclusive(&kainEffectLock95);
}
static void kainEffect95(const float point[3],float radius,bool ring,uint64_t now){
 KainEffect95 effect={.tick=now,.generation=sluagh80.generation,.radius=radius,.ring=ring};memcpy(effect.point,point,12);
 AcquireSRWLockExclusive(&kainEffectLock95);kainEffects95[kainEffectCursor95++%16]=effect;ReleaseSRWLockExclusive(&kainEffectLock95);
}
static void kainImpact96(const float point[3],uint64_t now){
 KainEffect95 effect={.tick=now,.generation=sluagh80.generation,.radius=230,.blood=true};memcpy(effect.point,point,12);
 AcquireSRWLockExclusive(&kainEffectLock95);kainEffects95[kainEffectCursor95++%16]=effect;ReleaseSRWLockExclusive(&kainEffectLock95);
}
static void kainFlash95(uint64_t now){
 float point[3]={sluagh80.position[0],sluagh80.position[1],sluagh80.position[2]+500};
 if(sluagh80.render){const float *joint=sluagh80.matrices+65*16,c=cosf(sluagh80.yaw),s=sinf(sluagh80.yaw),scale=.9598479333948396f;
  point[0]+=scale*(c*joint[12]-s*joint[13]);point[1]+=scale*(s*joint[12]+c*joint[13]);point[2]=sluagh80.position[2]+scale*joint[14];}
 kainEffect95(point,(float)sheet_sr1Combat52_target_cast_camera.castRadius,false,now);
}
static void kainEffectsDraw95(const float camera[16],uint64_t now){
 KainEffect95 list[16];AcquireSRWLockShared(&kainEffectLock95);memcpy(list,kainEffects95,sizeof list);ReleaseSRWLockShared(&kainEffectLock95);
 if(!c2ImpactInit())return;
 for(unsigned i=0;i<16;i++){KainEffect95 *effect=&list[i];if(!effect->tick||effect->generation!=sluagh80.generation||now<effect->tick||now-effect->tick>=700)continue;
  float life=(now-effect->tick)/700.f,color[4]={2.5f,.025f,.08f,(1-life)*.9f};
  localFxMesh51.n=0;
  if(effect->ring){float radius=effect->radius*(.05f+.95f*life),r[3]={1,0,0},u[3]={0,1,0},c[3];memcpy(c,effect->point,12);c[2]+=20;
   for(unsigned j=0;j<80;j++){float a=j*6.28318530718f/80,b=(j+1)*6.28318530718f/80,p[3]={c[0]+cosf(a)*radius,c[1]+sinf(a)*radius,c[2]},q[3]={c[0]+cosf(b)*radius,c[1]+sinf(b)*radius,c[2]};localFxSegment51(p,q,r,u,24+40*(1-life),color);}
   localFxDraw51(camera,3,2);
  }else{float c[3],r[3],u[3];memcpy(c,effect->point,12);if(!c2ImpactBillboard(camera,0,c,r,u))continue;float radius=effect->radius*(.85f+.15f*life);
   localFxQuad51(c,r,u,radius*.5f,radius*.5f,color);localFxDraw51(camera,1,2);localFxMesh51.n=0;localFxQuad51(c,r,u,radius,radius,color);localFxDraw51(camera,2,2);
   localFxMesh51.n=0;for(unsigned ray=0;ray<16;ray++){float a=ray*6.28318530718f/16,end[3];for(unsigned k=0;k<3;k++)end[k]=c[k]+radius*.8f*(r[k]*cosf(a)+u[k]*sinf(a));localFxSegment51(c,end,r,u,radius*.018f,color);}localFxDraw51(camera,3,2);
   if(effect->blood){const float blue[4]={.05f,.45f,2.f,(1-life)*.9f};localFxMesh51.n=0;for(unsigned drop=0;drop<12;drop++){float a=drop*2.39996323f,p[3];for(unsigned k=0;k<3;k++)p[k]=c[k]+life*400*(r[k]*cosf(a)+u[k]*sinf(a));p[2]+=life*180-life*life*450;localFxQuad51(p,r,u,8*(1-life)+2,16*(1-life)+2,blue);}localFxDraw51(camera,1,2);}
  }
 }
 KainProjectileStar97 stars[8];AcquireSRWLockShared(&kainEffectLock95);memcpy(stars,kainProjectileStars97,sizeof stars);ReleaseSRWLockShared(&kainEffectLock95);
 for(unsigned i=0;i<8;i++){const KainProjectileStar97 *star=stars+i;if(!star->tick||now<star->tick||now-star->tick>80)continue;float c[3],r[3],u[3],color[4]={2.5f,.025f,.08f,1};memcpy(c,star->point,12);if(!c2ImpactBillboard(camera,0,c,r,u))continue;
  localFxMesh51.n=0;localFxQuad51(c,r,u,57.5f,57.5f,color);localFxDraw51(camera,1,2);localFxMesh51.n=0;localFxQuad51(c,r,u,115,115,color);localFxDraw51(camera,2,2);
  localFxMesh51.n=0;for(unsigned ray=0;ray<16;ray++){const float a=ray*6.28318530718f/16;float end[3];for(unsigned k=0;k<3;k++)end[k]=c[k]+92*(r[k]*cosf(a)+u[k]*sinf(a));localFxSegment51(c,end,r,u,2.1f,color);}localFxDraw51(camera,3,2);
 }
}
static void kainSwordCoil97(const float camera[16],const float model[16],const float joint[16],unsigned charge,uint64_t now){
 if(!charge||!c2ImpactInit())return;float weapon[16],mvp[16];hostMultiply(model,joint,weapon);hostMultiply(camera,weapon,mvp);
 const float amount=fminf(1,charge/100.f),tip=493.724121f,phase=(now%1600)*6.28318530718f/1600.f;float center[3]={0,0,tip*.5f},r[3],u[3];if(!c2ImpactBillboard(mvp,0,center,r,u))return;
 for(unsigned pass=0;pass<2;pass++){const float color[4]={pass?1.5f:2.5f,pass?.35f:.015f,pass?.4f:.04f,amount};localFxMesh51.n=0;
  for(unsigned helix=0;helix<2;helix++){for(unsigned i=0;i<48;i++){
   float a[3],b[3];const float t=i/48.f,next=(i+1)/48.f;localFxCoilPoint51(a,t,0,tip,phase,helix*3.14159265359f);localFxCoilPoint51(b,next,0,tip,phase,helix*3.14159265359f);
   const float width=(pass?1.4f:4.5f)*localFxTaper51(t);localFxSegment51(a,b,r,u,width,color);
  }}localFxDraw51(mvp,4,2);
 }
 // Two jagged electric strands echo the side-meter lightning, in blade space.
 localFxMesh51.n=0;const float red[4]={2.5f,.04f,.09f,amount};for(unsigned side=0;side<2;side++){float previous[3]={0};for(unsigned i=0;i<=32;i++){const float t=i/32.f,taper=localFxTaper51(t);const unsigned seed=(unsigned)(now/33)*747796405u+i*2891336453u+side*277803737u;const float jag=((seed^(seed>>16))&1023)/511.5f-1;float point[3]={(side?1:-1)*(16+10*jag)*taper,8*sinf(phase+t*30)*taper,t*tip};if(i)localFxSegment51(previous,point,r,u,2*taper,red);memcpy(previous,point,12);}}localFxDraw51(mvp,4,2);
}
