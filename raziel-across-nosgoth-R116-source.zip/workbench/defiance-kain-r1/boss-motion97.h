// SPDX-License-Identifier: GPL-3.0-or-later
#pragma once
// The original AI still selects movement/actions. Host execution matches its
// authored gait to actual travel and compresses only the requested evade dash.
static struct {bool valid,dash,floorValid;uint64_t dashStart;unsigned dashSerial,gaitClip,gaitOld;float gaitAge,gaitMix,last[3],phase,weight,heading,dashVector[2],dashDone[2],dashFirst,stride,period,floorHeight,periods[2],strides[2];int16_t floorRoot[3];} kainMotion97;
static void kainClearMotion97(void){memset(&kainMotion97,0,sizeof kainMotion97);}
static bool kainFloor97(float x,float y,float root,float rise,float drop,float *height){
 if(!isfinite(x)||!isfinite(y)||fabsf(x)>31500||fabsf(y)>31500||root+rise>31500||root-drop<-31500)return false;
 float from[3]={x,y,root+rise};int16_t end[3]={(int16_t)lroundf(x),(int16_t)lroundf(y),(int16_t)lroundf(root-drop)};
 if(localNativeLineClear(sluagh80.actor,sluagh80.world,from,end))return false;
 float low=end[2],high=from[2];for(unsigned i=0;i<11;i++){end[2]=(int16_t)lroundf((low+high)*.5f);if(localNativeLineClear(sluagh80.actor,sluagh80.world,from,end))high=end[2];else low=end[2];}
 *height=ceilf(high);return true;
}
static bool kainProjectNavigation105(const float *goal,float *grounded){
 for(unsigned k=0;k<3;k++)if(!isfinite(goal[k])||fabsf(goal[k])>31000)return false;
 float floor=0;if(!kainFloor97(goal[0],goal[1],goal[2],80,(float)kainPolicy105->navigationDrop,&floor)||goal[2]-floor<(float)kainPolicy105->navigationHeightTolerance)return false;
 grounded[0]=goal[0];grounded[1]=goal[1];grounded[2]=floor;return true;
}
static bool kainStepPlan97(const int16_t current[3],float dx,float dy,int16_t next[3]){
 float destination[3]={current[0]+dx,current[1]+dy,current[2]};const float length=hypotf(dx,dy),sideX=length>0?-dy/length:1,sideY=length>0?dx/length:0;
 if(length>61||!isfinite(length)||fabsf(destination[0])>31500||fabsf(destination[1])>31500)return false;
 float following=0;if(!sluagh80.airPursuit95){float floor=0,probeRise=1600;
  const float origin[3]={current[0],current[1],current[2]+80.f};int16_t ceiling[3]={current[0],current[1],(int16_t)(current[2]+1600)};
  if(!localNativeLineClear(sluagh80.actor,sluagh80.world,origin,ceiling)){float low=80,high=1600;for(unsigned i=0;i<10;i++){ceiling[2]=(int16_t)lroundf(current[2]+(low+high)*.5f);if(localNativeLineClear(sluagh80.actor,sluagh80.world,origin,ceiling))low=(low+high)*.5f;else high=(low+high)*.5f;}probeRise=low-8;if(probeRise<96)return false;}
  if(kainMotion97.floorValid&&!memcmp(current,kainMotion97.floorRoot,6))floor=kainMotion97.floorHeight;
  else if(!kainFloor97(current[0],current[1],current[2],probeRise,768,&floor))return false;
  if(!kainFloor97(destination[0],destination[1],current[2],probeRise,768,&following))return false;
  const float change=following-floor;if(change>768||change<-768)return false;destination[2]=following;
 }
 const float raised=fmaxf(current[2],destination[2]);
 for(unsigned height=0;height<2;height++)for(int edge=-1;edge<=1;edge++){
  float from[3]={current[0]+sideX*edge*80,current[1]+sideY*edge*80,raised+(height?560:80)},end[3]={destination[0]+sideX*edge*80,destination[1]+sideY*edge*80,raised+(height?560:80)};int16_t to[3];
  for(unsigned k=0;k<3;k++)to[k]=(int16_t)lroundf(end[k]);if(!localNativeLineClear(sluagh80.actor,sluagh80.world,from,to))return false;
  if(raised>current[2]){float foot[3]={from[0],from[1],current[2]+(height?560.f:80.f)};int16_t up[3]={(int16_t)lroundf(from[0]),(int16_t)lroundf(from[1]),(int16_t)lroundf(from[2])};if(!localNativeLineClear(sluagh80.actor,sluagh80.world,foot,up))return false;}
 }
 for(unsigned k=0;k<3;k++)next[k]=(int16_t)lroundf(destination[k]);if(!sluagh80.airPursuit95){memcpy(kainMotion97.floorRoot,next,6);kainMotion97.floorHeight=following;kainMotion97.floorValid=true;}return true;
}
static bool kainPlant104(void){
 int16_t current[3];if(!readAt(sluagh80.actor+0x9c,current,6)||sluagh80.airborne86||sluagh80.airPursuit95)return false;
 float floor=0;
 if(kainMotion97.floorValid&&!memcmp(current,kainMotion97.floorRoot,6))floor=kainMotion97.floorHeight;
 else if(!kainFloor97(current[0],current[1],current[2],80,(float)kainPolicy104->groundPlantMax,&floor))return false;
 if(fabsf(current[2]-floor)>(float)kainPolicy104->groundPlantMax)return false;
 int16_t grounded[3]={current[0],current[1],(int16_t)lroundf(floor)};
 memcpy(kainMotion97.floorRoot,grounded,6);kainMotion97.floorHeight=floor;kainMotion97.floorValid=true;
 if(grounded[2]==current[2])return false;
 ((void(*)(uintptr_t,const int16_t*,int))(base+0x117810))(sluagh80.actor,grounded,0);
 record("kain104 ground-plant z=%d/%d native-relocate=1",current[2],grounded[2]);return true;
}
static bool kainMelee97(const SluaghNativeAI *ai){
 const unsigned char *descriptor=snPtr(ai->state,0x200),*commands=snPtr(ai->attributes,0xe0);if(!descriptor||!commands||descriptor[0x44]>16)return false;
 for(unsigned i=0;i<descriptor[0x44];i++)if(commands[descriptor[0x5f+i]*88+1]==0)return true;return false;
}
static void kainGaitClock97(const float point[3],float delta,bool allowed){
 if(!kainMotion97.period){for(unsigned k=0;k<2;k++){const unsigned clip=k?7:8;const SluaghClip80 c=sluaghResources80.clips[clip];kainMotion97.periods[k]=fmaxf(1,(c.keys-1)*c.timePerKey);float root[3];sluaghRootMotion80(clip,0,kainMotion97.periods[k],root);kainMotion97.strides[k]=fmaxf(1,hypotf(root[0],root[1])*.9598479333948396f);}kainMotion97.gaitClip=7;kainMotion97.period=kainMotion97.periods[1];kainMotion97.stride=kainMotion97.strides[1];}
 float step=0,dx=0,dy=0;if(kainMotion97.valid){dx=point[0]-kainMotion97.last[0];dy=point[1]-kainMotion97.last[1];step=hypotf(dx,dy);}
 memcpy(kainMotion97.last,point,12);kainMotion97.valid=true;
 const bool walking=allowed&&!kainMotion97.dash&&step>.4f&&step<250;
 kainMotion97.gaitAge+=delta;kainMotion97.gaitMix=fminf(1,kainMotion97.gaitMix+delta/(float)kainPolicy108->gaitBlendMs);
 if(walking){const float speed=step/fmaxf(1,delta),threshold=(kainMotion97.strides[0]/kainMotion97.periods[0]+kainMotion97.strides[1]/kainMotion97.periods[1])*.5f,hysteresis=(float)kainPolicy108->gaitHysteresisPermille/1000.f;const unsigned gait=speed>threshold*(kainMotion97.gaitClip==7?1-hysteresis:1+hysteresis)?1:0;
  if(kainMotion97.gaitClip!=(gait?7u:8u)&&(!kainMotion97.gaitOld||kainMotion97.gaitAge>=(float)kainPolicy108->gaitBlendMs)){const float phase=kainMotion97.phase/kainMotion97.period;kainMotion97.gaitOld=kainMotion97.gaitClip;kainMotion97.gaitClip=gait?7:8;kainMotion97.gaitAge=kainMotion97.gaitMix=0;kainMotion97.period=kainMotion97.periods[gait];kainMotion97.stride=kainMotion97.strides[gait];kainMotion97.phase=phase*kainMotion97.period;record("kain108 gait clip=%u speed=%.3f native-stride=%.1f period=%.1f",kainMotion97.gaitClip,speed,kainMotion97.stride,kainMotion97.period);}
  kainMotion97.phase=fmodf(kainMotion97.phase+step*kainMotion97.period/kainMotion97.stride,kainMotion97.period);kainMotion97.heading=atan2f(dy,dx)+1.57079632679f;}
 const float blend=fminf(1,delta/300.f);kainMotion97.weight=fmaxf(0,fminf(1,kainMotion97.weight+(walking?blend:-blend)));
}
static void kainGaitPose97(float pose[1264]){
 if(kainMotion97.weight<=0||kainMotion97.dash)return;float running[1264],root[3];sluaghSample80(kainMotion97.gaitClip,kainMotion97.phase,running,root);
 if(kainMotion97.gaitOld&&kainMotion97.gaitMix<1){float old[1264];const unsigned slot=kainMotion97.gaitOld==7?1:0;sluaghSample80(kainMotion97.gaitOld,kainMotion97.phase/kainMotion97.period*kainMotion97.periods[slot],old,root);for(unsigned k=0;k<1264;k++)running[k]=old[k]+(running[k]-old[k])*kainMotion97.gaitMix;}
 const float angle=kainMotion97.heading-sluagh80.yaw,c=cosf(angle),s=sinf(angle),*hip=pose+16,*sourceHip=running+16;
 for(unsigned bone=2;bone<=10;bone++){const float *a=running+bone*16;float transformed[16];memcpy(transformed,a,64);
  for(unsigned column=0;column<3;column++){transformed[column*4]=c*a[column*4]-s*a[column*4+1];transformed[column*4+1]=s*a[column*4]+c*a[column*4+1];}
  float x=a[12]-sourceHip[12],y=a[13]-sourceHip[13];transformed[12]=hip[12]+c*x-s*y;transformed[13]=hip[13]+s*x+c*y;transformed[14]=hip[14]+a[14]-sourceHip[14];
  for(unsigned k=0;k<16;k++)pose[bone*16+k]+=kainMotion97.weight*(transformed[k]-pose[bone*16+k]);
 }
}
static float kainDash97(uint64_t now,float yaw,float end){
 if(!kainMotion97.dash||kainMotion97.dashSerial!=sluagh80.ai.animationSerial){
  kainMotion97.dash=true;kainMotion97.dashSerial=sluagh80.ai.animationSerial;kainMotion97.dashStart=now;float root[3];sluaghRootMotion80(sluagh80.clip,0,end,root);
  const float c=cosf(yaw),s=sinf(yaw),scale=.9598479333948396f;kainMotion97.dashVector[0]=(c*root[0]-s*root[1])*scale;kainMotion97.dashVector[1]=(s*root[0]+c*root[1])*scale;
  const float length=hypotf(kainMotion97.dashVector[0],kainMotion97.dashVector[1]);if(length>1600)for(unsigned k=0;k<2;k++)kainMotion97.dashVector[k]*=1600/length;
  memset(kainMotion97.dashDone,0,8);kainMotion97.dashFirst=0;
  for(float time=0;time<end;time+=100){float scratch[1264];sluaghSample80(sluagh80.clip,time,scratch,root);if(hypotf(root[0],root[1])>1){kainMotion97.dashFirst=time;break;}}
  record("kain97 dash-start clip=%u native-root=%.1f/%.1f duration=100",sluagh80.clip,kainMotion97.dashVector[0],kainMotion97.dashVector[1]);
 }
 const float progress=fminf(1,fmaxf(.12f,(now-kainMotion97.dashStart)/100.f));
 for(unsigned k=0;k<2;k++){const float desired=kainMotion97.dashVector[k]*progress,step=desired-kainMotion97.dashDone[k];sluagh80.pendingMove[k]+=step;kainMotion97.dashDone[k]=desired;}sluagh80.pendingMoveTick=now;
 return kainMotion97.dashFirst+(end-kainMotion97.dashFirst)*progress;
}
