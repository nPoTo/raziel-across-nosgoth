// SPDX-License-Identifier: GPL-3.0-or-later
#pragma once
// Only creator-owned Kain. Ordinary enemies retain their original damage path.
static NTSTATUS (WINAPI *kainDamageRandom114)(BCRYPT_ALG_HANDLE,PUCHAR,ULONG,ULONG)=BCryptGenRandom;
static unsigned kainBasis114(unsigned minimum,unsigned maximum){
 const unsigned span=maximum-minimum+1;uint32_t value=0;
 for(unsigned i=0;i<8;i++)if(kainDamageRandom114(NULL,(PUCHAR)&value,4,BCRYPT_USE_SYSTEM_PREFERRED_RNG)>=0&&value<UINT32_MAX-UINT32_MAX%span)return minimum+value%span;
 return (minimum+maximum)/2;
}
static int kainPercent114(unsigned bp){return (int)(((int64_t)sluagh80.maxHp*bp+5000)/10000);}
static struct {bool valid,filled,refill;uintptr_t player;uint32_t generation;PortablePowers60 powers;PortablePowerState114 toggle;LocalForms45 forms;LONG arm;}kainStatus114;
static bool kainStatusCurrent114(void){uintptr_t p=0;return kainStatus114.valid&&readAt(base+host->actorRva,&p,8)&&p==kainStatus114.player&&generation(p)==kainStatus114.generation;}
static void kainStatusCapture114(uintptr_t actor){
 if(kainStatusCurrent114())return;PortablePowers60 p={0};if(!actor||!generation(actor)||!portablePowerRead60(&p))return;
 kainStatus114=(__typeof__(kainStatus114)){.valid=true,.player=actor,.generation=generation(actor),.powers=p,.toggle=portablePowerState114,.forms=localFormsRead(),.arm=localArmEnabled107};
 record("kain114 status-saved generation=%u hp=%d level=%d abilities=%x mana=%u f9=%u",kainStatus114.generation,p.health,p.level,p.abilities,p.mana,kainStatus114.toggle.grant);
}
static void kainStatusFill114(void){
 kainStatusCapture114(sluagh80.player);if(!kainStatusCurrent114())return;PortablePowers60 p={0};if(!portablePowerRead60(&p))return;
 p.level=(int16_t)kainPolicy114->hiddenLevel;
 const bool refill=!kainStatus114.filled||kainStatus114.refill;if(refill)p.health=(int32_t)kainPolicy114->hiddenMaterialHealth;
 if(portablePowerWrite60(&p)){kainStatus114.filled=true;kainStatus114.refill=false;record("kain114 hp-filled hp=%d hidden-level=%d visible-level=%d refill=%u",p.health,p.level,kainStatus114.powers.level,refill);}
}
static void kainStatusBoundary114(uintptr_t actor){
 const DWORD error=GetLastError();uint32_t realm=0;int16_t level=0;
 if(actor==sluagh80.player&&sluagh80.actor&&kainStatusCurrent114()&&kainStatus114.filled&&InterlockedCompareExchange(&portableActive60,0,0)&&
 readAt(base+44600604,&realm,4)&&realm==1&&readAt(base+0x2a88ccc,&level,2)&&level!=(int16_t)kainPolicy114->hiddenLevel){
  level=(int16_t)kainPolicy114->hiddenLevel;memcpy((void*)(base+0x2a88ccc),&level,2);
 }SetLastError(error);
}
static void kainStatusRestore114(void){
 if(!kainStatusCurrent114()){memset(&kainStatus114,0,sizeof kainStatus114);return;}
 PortablePowers60 before={0},after={0};if(!portablePowerRead60(&before)){record("kain114 status-restore read-failed=1 retained-snapshot=1");return;}
 if(!portablePowerWrite60(&kainStatus114.powers)||!portablePowerRead60(&after)||memcmp(&after,&kainStatus114.powers,sizeof after)){
  portablePowerWrite60(&before);record("kain114 status-restore failed=1 retained-snapshot=1");return;
 }
 uintptr_t blade=0;if(((before.abilities^after.abilities)&0xc08u)&&readAt(base+host->reaverRva,&blade,8)&&blade&&!localPhysicalCarry(kainStatus114.player)){
  ((void(*)(uintptr_t))(base+0xe77f0))(kainStatus114.player);portablePowerWrite60(&after);
 }
 portablePowerState114=kainStatus114.toggle;
 AcquireSRWLockExclusive(&localFormsLock);localForms=kainStatus114.forms;ReleaseSRWLockExclusive(&localFormsLock);localArmEnabled107=kainStatus114.arm;
 record("kain114 status-restored hp=%d level=%d abilities=%x mana=%u f9=%u",after.health,after.level,after.abilities,after.mana,portablePowerState114.grant);memset(&kainStatus114,0,sizeof kainStatus114);
}
static void (*kainOriginalSpiral114)(int,int,int);
static void kainSpiral114(int level,int hp,int maximum){
 const DWORD error=GetLastError();uint32_t realm=0;
 if(kainStatusCurrent114()&&kainStatus114.filled&&InterlockedCompareExchange(&portableActive60,0,0)&&readAt(base+44600604,&realm,4)&&realm==1){
  const int visible=(kainStatus114.powers.level+1)*100000;
  if(visible>0&&maximum>0){hp=(int)((int64_t)hp*visible/maximum);maximum=visible;level=kainStatus114.powers.level;}
 }
 SetLastError(error);kainOriginalSpiral114(level,hp,maximum);
}
static bool kainDamageOwner114(uintptr_t actor){return sluaghOwned80(actor)&&sluagh80.player&&sluagh80.maxHp==30000&&InterlockedCompareExchange(&portableActive60,0,0);}
static int kainSpellAmount114(uintptr_t actor,int amount){
 if(!kainDamageOwner114(actor))return amount;uintptr_t data=0;int16_t hp=0;
 if(!readAt(actor+0x2c0,&data,8)||!data||!readAt(data+contactPolicy->healthOffset,&hp,2)||hp<=1)return 0;
 if(kainGuard102())return 0;const int damage=kainPercent114((unsigned)kainPolicy114->spellBp);return damage<hp?damage:hp-1;
}
static int kainPulse114(uintptr_t actor,int amount){return kainSpellAmount114(actor,amount);}
static struct {uintptr_t actor;uint32_t gen;uint64_t last,end;float x,y;}kainPush114;
static bool kainPushPoll114(uint64_t now){
 if(!kainPush114.end)return false;
 if(!kainDamageOwner114(kainPush114.actor)||generation(kainPush114.actor)!=kainPush114.gen||now>=kainPush114.end){memset(&kainPush114,0,sizeof kainPush114);return false;}
 const float dt=(float)(now-kainPush114.last)/(float)kainPolicy114->forceMs;kainPush114.last=now;
 if(dt>0&&dt<=1)sluaghMove80(kainPush114.x*dt,kainPush114.y*dt);return true;
}
static bool kainGlyph114(uintptr_t actor,uint32_t id){
 if(!kainDamageOwner114(actor)||id<(uint32_t)kainPolicy114->glyphFirst||id>(uint32_t)kainPolicy114->glyphLast)return false;
 const DWORD error=GetLastError();const uint64_t now=GetTickCount64();uintptr_t ring=0;readAt(base+sheet_sr1Combat48_combat_charge.ringRva,&ring,8);
 static uintptr_t lastActor,lastRing;static uint32_t lastGen,lastId;static uint64_t lastTime,cast;
 const uint64_t currentCast=localSpellCast55.owner.tick;
 if(lastActor==actor&&lastGen==generation(actor)&&lastId==id&&lastRing==ring&&cast==currentCast&&now-lastTime<1000){SetLastError(error);return true;}
 lastActor=actor;lastGen=generation(actor);lastId=id;lastRing=ring;lastTime=now;cast=currentCast;
 if(id-0x80000u==(unsigned)kainPolicy114->forceGlyph){
  int16_t a[3],p[3];if(readAt(actor+0x9c,a,6)&&readAt(sluagh80.player+0x9c,p,6)){
   float dx=a[0]-p[0],dy=a[1]-p[1],length=hypotf(dx,dy);if(length<1){dx=1;dy=0;length=1;}
   kainPush114=(__typeof__(kainPush114)){actor,generation(actor),now,now+(uint64_t)kainPolicy114->forceMs,dx/length*kainPolicy114->forceDistance,dy/length*kainPolicy114->forceDistance};
  }
  record("kain114 glyph force-push=1 native-kill-suppressed=1");
 }else{
  const int amount=kainSpellAmount114(actor,0);if(amount>0)originalLocalEnemyDamage(actor,amount,(uint32_t)contactPolicy->damageKind);
  record("kain114 glyph id=%x damage=%d nonlethal=1 native-kill-suppressed=1",id,amount);
 }
 SetLastError(error);return true;
}
