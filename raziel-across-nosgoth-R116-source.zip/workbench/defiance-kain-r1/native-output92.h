// SPDX-License-Identifier: GPL-3.0-or-later
#pragma once
// Private Defiance engine outputs are requests. The SR1 actor/world verifies
// contact and executes them. Original decision and command routines remain intact.
static uintptr_t (*snOriginalPost92)(void*,uint32_t,uintptr_t);
static uintptr_t (*snOriginalFx92)(void*,void*,void*,uintptr_t,uintptr_t);
static void *(*snOriginalController92)(void*,unsigned,unsigned);
static void (*snOriginalEnable92)(void*,unsigned,unsigned);
static void (*snOriginalCommand95)(void*,void*,void*);
static int (*snOriginalEligible96)(void*,void*);
static bool snPowerDescriptor96(const SluaghNativeAI *n,const void *descriptor){
 void **table=snPtr(n->attributes,0x38);return table&&descriptor==table[35];
}
static bool snTkReady98(const SluaghNativeAI *n,uint64_t now){return !n->lastTelekinesis98||(now>=n->lastTelekinesis98&&now-n->lastTelekinesis98>=2000);}
static bool snTkDescriptor98(const SluaghNativeAI *n,const unsigned char *descriptor){
 const unsigned char *commands=snPtr(n->attributes,0xe0);if(!descriptor||!commands||(uintptr_t)descriptor<(uintptr_t)n->attributes||(uintptr_t)descriptor+0x70>(uintptr_t)n->attributes+12448||snPowerDescriptor96(n,descriptor)||descriptor[0x44]>16)return false;
 for(unsigned i=0;i<descriptor[0x44];i++){const uintptr_t command=(uintptr_t)commands+descriptor[0x5f+i]*88;if(command<(uintptr_t)n->attributes||command+88>(uintptr_t)n->attributes+12448)continue;const unsigned kind=((const unsigned char*)command)[1];if(kind==7||kind==13||kind==14)return true;}return false;
}
static int snEligible96(void *actor,void *descriptor){
 SluaghNativeAI *n=snCurrent92;
 if(n&&actor==n->actor&&snPowerDescriptor96(n,descriptor)&&n->bladeCharge96<100)return 0;
 if(n&&actor==n->actor&&snTkDescriptor98(n,descriptor)&&!snTkReady98(n,GetTickCount64()))return 0;
 return snOriginalEligible96(actor,descriptor);
}
static void snCommand95(void *actor,void *target,void *command){
 SluaghNativeAI *n=snCurrent92;
 if(!n||actor!=n->actor){snOriginalCommand95(actor,target,command);return;}
 const unsigned previous=n->command95;n->command95=((unsigned char*)command)[1];
 const bool previousSuppressed=n->suppressTelekinesis98;
 if((n->command95==7||n->command95==13||n->command95==14)&&!snPowerDescriptor96(n,snPtr(n->state,0x200))){const uint64_t now=GetTickCount64();n->suppressTelekinesis98=!snTkReady98(n,now);if(!n->suppressTelekinesis98)n->lastTelekinesis98=now;}
 if(n->command95==0)n->strikeSerial96++;
 if(n->command95==9&&n->bladeCharge96>=100){n->bladeCharge96=0;n->powerCasts95++;}
 snOriginalCommand95(actor,target,command);n->command95=previous;n->suppressTelekinesis98=previousSuppressed;
}
static void *snController92(void *animation,unsigned bone,unsigned kind){
 SluaghNativeAI *n=snCurrent92;if(n&&animation==n->actor+0x1a8)return n->controller92;
 return snOriginalController92(animation,bone,kind);
}
static void snEnable92(void *animation,unsigned bone,unsigned kind){
 SluaghNativeAI *n=snCurrent92;if(n&&animation==n->actor+0x1a8)return;
 snOriginalEnable92(animation,bone,kind);
}
static uintptr_t snPost92(void *receiver,uint32_t message,uintptr_t payload){
 SluaghNativeAI *n=snCurrent92;
 if(!n||(receiver!=n->actor&&receiver!=n->targetActor))return snOriginalPost92(receiver,message,payload);
 n->lastMessage92=message;n->events++;
 if(receiver==n->targetActor){
  if(n->suppressTelekinesis98&&(message==0x1000000||message==0x1000002||message==0x200007))return 0;
  if(message==0x1000000){n->damageEvents92++;n->damageIsPower95=n->command95==9;if(payload)memcpy(n->playerEvent92,(void*)payload,sizeof n->playerEvent92);}
  if(message==0x1000002)n->grabEvents92++;
  if(message==0x200007){n->fxEvents92++;n->shockRequests94++;if(payload)memcpy(n->shockEvent94,(void*)payload,80);}
  if(message==0x400001)n->powerEffects94++;
  return 0;
 }
 // Native self messages go to the current original state handler.
 uintptr_t (*handler)(void*,uint32_t,uintptr_t)=snPtr((void*)(n->module+0x67a2f0+n->mode*40),24);
 return handler?handler(n->actor,message,payload):0;
}
static uintptr_t snFx92(void *actor,void *target,void *command,uintptr_t kind,uintptr_t mode){
 SluaghNativeAI *n=snCurrent92;if(n&&actor==n->actor){if(n->suppressTelekinesis98)return 0;n->fxEvents92++;
  const uintptr_t first=(uintptr_t)snPtr(n->attributes,0xe0),at=(uintptr_t)command;
  if(at>=first&&at+88<=(uintptr_t)n->attributes+12448&&(at-first)%88==0&&((unsigned char*)command)[1]==13)n->projectileRequests94++;
  return 0;}
 return snOriginalFx92(actor,target,command,kind,mode);
}
static int snOutputs92(uintptr_t module){
 return MH_CreateHook((void*)(module+0xa1e40),snEligible96,(void**)&snOriginalEligible96)==MH_OK&&MH_EnableHook((void*)(module+0xa1e40))==MH_OK&&
 MH_CreateHook((void*)(module+0xb8970),snCommand95,(void**)&snOriginalCommand95)==MH_OK&&MH_EnableHook((void*)(module+0xb8970))==MH_OK&&
 MH_CreateHook((void*)(module+0x7d940),snPost92,(void**)&snOriginalPost92)==MH_OK&&
 MH_CreateHook((void*)(module+0xd76b0),snFx92,(void**)&snOriginalFx92)==MH_OK&&
 MH_CreateHook((void*)(module+0x5b470),snController92,(void**)&snOriginalController92)==MH_OK&&
 MH_CreateHook((void*)(module+0x59d50),snEnable92,(void**)&snOriginalEnable92)==MH_OK&&
 MH_EnableHook((void*)(module+0x7d940))==MH_OK&&MH_EnableHook((void*)(module+0xd76b0))==MH_OK&&MH_EnableHook((void*)(module+0x5b470))==MH_OK&&MH_EnableHook((void*)(module+0x59d50))==MH_OK;
}
