// SPDX-License-Identifier: GPL-3.0-or-later
#pragma once
// Exclude only our enemy as a standable object during the player's original
// gravity query. World terrain and other physical platforms remain native.
static struct {uintptr_t actor;uint32_t generation,world;uint64_t tick;bool missing;} kainSupport105;
static bool kainSupportOwner105(uintptr_t actor){
 uintptr_t current=0;uint32_t world=0,realm=0,enemyWorld=0;
 return actor&&actor==sluagh80.player&&generation(actor)==sluagh80.playerGeneration&&
  InterlockedCompareExchange(&portableActive60,0,0)&&sluaghOwned80(sluagh80.actor)&&sluagh80.hp>0&&
  readAt(base+host->actorRva,&current,8)&&current==actor&&readAt(base+host->realmRva,&realm,4)&&realm==1&&
  readAt(actor+0x60,&world,4)&&world==sluagh80.world&&readAt(sluagh80.actor+0x60,&enemyWorld,4)&&enemyWorld==world;
}
static void kainGroundBegin105(uintptr_t actor,uint16_t flags,uintptr_t lease[3]){
 const DWORD saved=GetLastError();memset(lease,0,3*sizeof(*lease));uint32_t prior=0;
 if(flags==7&&kainSupportOwner105(actor)&&readAt(sluagh80.actor+(uintptr_t)kainPolicy105->flagsOffset,&prior,4)){
  lease[0]=sluagh80.actor;lease[1]=sluagh80.generation;lease[2]=prior;
  InterlockedOr((volatile LONG*)(lease[0]+(uintptr_t)kainPolicy105->flagsOffset),(LONG)kainPolicy105->noPointMask);
 }SetLastError(saved);
}
static void kainGroundEnd105(uintptr_t actor,uint16_t flags,const uintptr_t lease[3],uint32_t result){
 const DWORD saved=GetLastError();
 if(lease[0]&&generation(lease[0])==(uint32_t)lease[1]&&!(lease[2]&(uintptr_t)kainPolicy105->noPointMask))
  InterlockedAnd((volatile LONG*)(lease[0]+(uintptr_t)kainPolicy105->flagsOffset),~(LONG)kainPolicy105->noPointMask);
 if(lease[0]&&flags==7&&kainSupportOwner105(actor)){
  const uint64_t now=GetTickCount64();kainSupport105.actor=actor;kainSupport105.generation=generation(actor);kainSupport105.world=sluagh80.world;kainSupport105.tick=now;kainSupport105.missing=(result&1u)==0;
  static uint64_t lastLog105;if(now-lastLog105>=1000){lastLog105=now;int16_t playerZ=0,enemyZ=0;readAt(actor+0xa0,&playerZ,2);readAt(lease[0]+0xa0,&enemyZ,2);record("kain105 support-query result=%x no-support=%u player-z=%d enemy-z=%d restored=1",result,kainSupport105.missing,playerZ,enemyZ);}
 }else if(flags==7&&actor==kainSupport105.actor)memset(&kainSupport105,0,sizeof kainSupport105);SetLastError(saved);
}
static bool kainLostSupport105(uintptr_t actor,uint64_t now){
 return kainSupport105.missing&&kainSupport105.actor==actor&&kainSupport105.generation==generation(actor)&&
  kainSupport105.world==sluagh80.world&&now>=kainSupport105.tick&&now-kainSupport105.tick<=(uint64_t)kainPolicy105->supportReceiptMs;
}
static bool kainGroundState105(uintptr_t callback){
 return callback==base+0xf2180||callback==base+0xf3280||callback==base+0xf54d0||callback==base+0xf5340||callback==base+0xf7dd0;
}
