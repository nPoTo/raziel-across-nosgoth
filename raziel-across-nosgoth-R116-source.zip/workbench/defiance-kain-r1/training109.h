// SPDX-License-Identifier: GPL-3.0-or-later
#pragma once
static int (*trainingOriginalAction109)(uintptr_t,uintptr_t,uintptr_t);
static int trainingSkip109(uintptr_t event,uintptr_t script,uintptr_t cursor,uintptr_t caller){
 if(!InterlockedCompareExchange(&portableActive60,0,0)||!event||!script||!cursor||(caller!=0x4a755&&caller!=0x4a7a7))return 0;
 uintptr_t actor=0,level=0,table=0,actions=0,first=0,start=0;uint32_t count=0;int16_t id=0;uint8_t header[6];uint16_t flags=0;
 if(!readAt(base+host->actorRva,&actor,8)||!actor||!generation(actor)||!readAt(event,header,sizeof header)||header[4]!=1||header[5]!=1||
  !readAt(script+2,&flags,2)||(flags&3u)||!readAt(script+8,&start,8)||start!=cursor||!readAt(event+0x20,&actions,8)||!actions||!readAt(actions,&first,8)||first!=script||
  !readAt(base+0x2bb608,&level,8)||!level||!readAt(level+0x178,&table,8)||!table||!readAt(table,&count,4)||count>256)return 0;
 memcpy(&id,header,2);
 for(unsigned i=0;i<sheet_training109_count;i++){
  const Sheet_training109 *row=sheet_training109_rows[i];if(id!=row->event||count!=(unsigned)row->eventCount||((uintptr_t(*)(int32_t))(base+0x115b00))((int32_t)row->stream)!=level)continue;
  bool member=false;for(unsigned j=0;j<count;j++){uintptr_t candidate=0;if(!readAt(table+8+j*8,&candidate,8))return 0;if(candidate==event){member=true;break;}}if(!member)return 0;
  uintptr_t verified=0;if(kainStoryScript108(event,0,(unsigned)row->words,row->archiveSha,&verified)||kainStoryScript108(event,0,(unsigned)row->words,row->runtimeSha,&verified))return (int)i+1;
 }return 0;
}
static int trainingAction109(uintptr_t event,uintptr_t script,uintptr_t cursor){
 const DWORD error=GetLastError();const int selected=trainingSkip109(event,script,cursor,(uintptr_t)__builtin_return_address(0)-base);
 if(selected){const Sheet_training109 *row=sheet_training109_rows[selected-1];record("training109 skipped=1 stream=%lld event=%lld original-caller-completes=1",(long long)row->stream,(long long)row->event);SetLastError(error);return 1;}
 kainStoryDoor110(event,script,cursor);
 SetLastError(error);return trainingOriginalAction109(event,script,cursor);
}
static bool trainingPrepare109(void){
 const unsigned char entry[]={0x48,0x89,0x5c,0x24,0x08,0x48,0x89,0x6c,0x24,0x10};
 return matches(0x45730,entry,sizeof entry)&&MH_CreateHook((void*)(base+0x45730),trainingAction109,(void**)&trainingOriginalAction109)==MH_OK;
}
