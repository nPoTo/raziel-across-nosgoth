// SPDX-License-Identifier: GPL-3.0-or-later
#pragma once
// Scoped recovery for the demonstrated stranded native Fall state. This does
// not replace collision, force movement, or write player coordinates/flags.
static uint64_t kainZeroForce101,kainFallLog101,kainStranded103;
static void kainFallFrame101(const Sr1LocalFrame *frame,uint64_t now){
 uintptr_t current=0,callback=0,forces=0;uint32_t world=0;int mode=-1,gravity=1,forceZ=1;int16_t friction=-1;
 if(!frame->ready||!frame->renderBlend||frame->realm!=1||!sluaghOwned80(sluagh80.actor)||sluagh80.hp<=0||
    !InterlockedCompareExchange(&portableActive60,0,0)||frame->playerGeneration!=sluagh80.playerGeneration||
    frame->worldGeneration!=sluagh80.world||!readAt(base+host->actorRva,&current,8)||current!=sluagh80.player||
    generation(current)!=sluagh80.playerGeneration||!readAt(current+0x60,&world,4)||world!=sluagh80.world||
    !readAt(base+host->callbackRva,&callback,8)||callback!=base+groundPolicy->fallRva||
    !readAt(base+0xd6b2ac,&mode,4)||!readAt(current+0x2e0,&gravity,4)||
    !readAt(base+0xd6b210,&forces,8)||!forces||!readAt(forces+12,&forceZ,4)||
    !readAt(forces+16,&friction,2)){kainZeroForce101=kainStranded103=0;return;}
 if(now>=kainFallLog101&&now-kainFallLog101>=1000){kainFallLog101=now;int vz=0;readAt(current+0x2d4,&vz,4);record("kain101 fall-observe physics=%d vz=%d gravity=%d force=%d friction=%d",mode,vz,gravity,forceZ,friction);}
 // R104 mode3 recovery runs at native ProcessPhysics;do not repeatedly
 // reenter Fall and zero its velocity here.
 if(mode!=0||gravity!=0||forceZ!=0||readLocalSlam(frame,current,now,250).owner.tick){kainZeroForce101=0;return;}
 if(!kainZeroForce101){kainZeroForce101=now;return;}
 if(now<kainZeroForce101||now-kainZeroForce101<250)return;
 int speed[3]={0};if(!readAt(current+0x2cc,speed,sizeof speed)){kainZeroForce101=0;return;}
 // Native SetPhysics initializes the external gravity source. Retain planar
 // motion; cap only an unsupported upward drift, never add a second launch.
 ((void(*)(uintptr_t,int,int,int,int))(base+0xe4230))(current,-16,speed[0],speed[1],speed[2]>0?0:speed[2]);
 record("kain101 fall-gravity-restored native=1 previous-vz=%d force=%d friction=%d",speed[2],forceZ,friction);
 kainZeroForce101=0;
}
