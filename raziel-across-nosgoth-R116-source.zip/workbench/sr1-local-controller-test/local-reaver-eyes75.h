// SPDX-License-Identifier: GPL-3.0-or-later
#pragma once
// Joint-local fit to the two eye regions in RAZIEL_4_E on the HD player mesh.
// The opaque almond is surrounded by a narrow falloff. World depth hides the far eye.
static void localDrawEyes75(void){
    const Sr1LocalFrame f=readFrame();
    if(!f.ready || !f.renderBlend || localEyeSession75!=f.session ||
        localBladePalette.hand.actor!=player || localCurrentForm(f.realm)!=localBladeStaged45 ||
        !localFullCharge51(&f,player,GetTickCount64()) || !c2ImpactInit())return;
    const uint32_t tint=localSwordTint75(localBladeStaged45);
    ReaverGLVertex vertices[34]={0};uint16_t indices[144];unsigned n=0;
    for(unsigned eye=0;eye<2;eye++){
        const unsigned baseIndex=eye*17;
        const float side=eye?1.f:-1.f;
        const Sheet_sr1Reaver75 *p=&sheet_sr1Reaver75_blade_material;
        const float center[3]={(eye?p->eye1X:p->eye0X)*.001f,
            (eye?p->eye1Y:p->eye0Y)*.001f-1.5f,(eye?p->eye1Z:p->eye0Z)*.001f};
        memcpy(vertices[baseIndex].position,center,sizeof center);
        localSwordColor74(tint,1,1,0,vertices[baseIndex].rgba);
        for(unsigned ring=0;ring<2;ring++)for(unsigned j=0;j<8;j++){
            const float angle=.7853981634f*j;
            const float dx=cosf(angle)*(ring?6.1f:4.6f);
            const float dz=sinf(angle)*(ring?2.6f:1.45f);
            const unsigned index=baseIndex+1+ring*8+j;
            ReaverGLVertex *v=&vertices[index];
            v->position[0]=center[0]+side*dx;
            v->position[1]=center[1]+.36f*dx;
            v->position[2]=center[2]+.24f*dx+dz;
            localSwordColor74(tint,1,ring?0:1,0,v->rgba);
        }
        for(unsigned j=0;j<8;j++){
            const uint16_t a=(uint16_t)(baseIndex+1+j),b=(uint16_t)(baseIndex+1+(j+1)%8);
            const uint16_t tri[]={baseIndex,a,b,a,a+8,b,b,a+8,b+8};
            memcpy(indices+n,tri,sizeof tri);n+=9;
        }
    }
    reaverGLDraw(&c2ImpactGl,vertices,34,indices,n,4,1,localEyeMvp75,0,-1);
}

