// SPDX-License-Identifier: GPL-3.0-or-later
#pragma once
typedef struct {LocalActionOwner owner;float distance;float target[3];int16_t root[3];bool rooted,aimed;} LocalThrustFollow76;
static SRWLOCK localThrustLock76=SRWLOCK_INIT;
static LocalThrustFollow76 localThrustFollow76;
static bool localThrustTarget76(const Sr1LocalFrame *f,uintptr_t actor,uint64_t now,float center[3]){
 uintptr_t target=0;uint32_t gen=0;int16_t root[3],pos[3];uint16_t yaw=0;
 const LocalTargetLock47 lock=localTargetSnapshot47(false);
 if(lock.held&&localTargetValid47(&lock,f,actor,now,pos))target=lock.target;
 else if(!lock.held){
  const LocalTargetLock47 recent=localTargetSnapshot47(true);
  if(localTargetValid47(&recent,f,actor,now,pos))target=recent.target;
  else if(localNearestTarget49(f,actor,&target,&gen)&&!localLockReadTarget47(target,f,&gen,pos))target=0;
 }
 if(!target||!readAt(actor+0x9c,root,6)||!readAt(actor+sheet_sr1GroundSteering_camera_relative_start.yawOffset,&yaw,2))return false;
 if(!lock.held){const float angle=yaw*6.28318530718f/4096.f,dx=pos[0]-root[0],dy=pos[1]-root[1];if(dx*sinf(angle)-dy*cosf(angle)<.5f*hypotf(dx,dy))return false;}
 LocalSphere sphere;
 if(!localContactSphere(target,false,false,NULL,NULL,&sphere)&&!localContactSphere(target,false,true,NULL,NULL,&sphere))return false;
 for(unsigned k=0;k<3;k++)center[k]=sphere.native.center[k];return true;
}
static LocalThrustFollow76 localReadThrust76(const Sr1LocalFrame *f,uintptr_t actor,uint64_t now){
 AcquireSRWLockShared(&localThrustLock76);LocalThrustFollow76 value=localThrustFollow76;ReleaseSRWLockShared(&localThrustLock76);
 if(!sameLocalAction(&value.owner,f,actor,now,150))return (LocalThrustFollow76){0};return value;
}
