// SPDX-License-Identifier: GPL-3.0-or-later
#pragma once
// Native f3c40 has a distinct Query(4)==9 interaction branch: its two
// animation bytes are tune+0x11/+0x12, not the physical grab array at+0x14.
static bool localNativeContext68(const Sr1LocalFrame *frame,uintptr_t actor){
 const Sheet_sr1Context68 *const p=&sheet_sr1Context68_native_context_priority;
 uint32_t flags=0,world=0,kind=0;uintptr_t slots=0,target=0,blade=0,parent=0;
 if(!frame->ready||!actor||frame->realm==SR1_LOCAL_UNKNOWN||!frame->groundContact48||frame->airState!=SR1_AIR_NONE||
    !readAt(base+host->interactionFlagsRva,&flags,4)||!(flags&(uint32_t)p->senseMask)||
    !readAt(base+host->interactionTypeRva,&kind,4)||kind!=0x1000||
    !readAt(base+host->targetsRva,&slots,8)||!slots||!readAt(slots+0x30,&target,8)||!target||target==actor||
    !readAt(base+host->reaverRva,&blade,8)||target==blade||
    !readAt(target+0x60,&world,4)||world!=frame->worldGeneration||
    !readAt(target+host->parentOffset,&parent,8)||parent)return false;
 const uint32_t gen=generation(target);if(!gen)return false;
 typedef uintptr_t (*ContextQuery68)(uintptr_t,uint32_t);
 const ContextQuery68 query=(ContextQuery68)(base+signals->queryRva);
 if(query(target,(uint32_t)p->typeQuery)!=(uintptr_t)p->contextType)return false;
 const uintptr_t tune=query(target,(uint32_t)p->tuneQuery);unsigned char anim[2];
 if(!tune||!readAt(tune+(uintptr_t)p->animationOffset,anim,2)||(anim[0]==255&&anim[1]==255))return false;
 uintptr_t again=0;uint32_t after=0;
 return generation(target)==gen&&readAt(target+0x60,&after,4)&&after==world&&
  readAt(slots+0x30,&again,8)&&again==target;
}
typedef struct{uintptr_t actor;uint32_t generation,world;Sr1LocalRealm realm;} LocalContextOwner68;
static SRWLOCK localContextLock68=SRWLOCK_INIT;
static LocalContextOwner68 localContextOwner68;
static bool localNativeContextFrame68(const Sr1LocalFrame *frame,uintptr_t actor,const uintptr_t callbacks[3]){
 const bool candidate=localNativeContext68(frame,actor);
 const uintptr_t handler=base+(uintptr_t)sheet_sr1Context68_native_context_priority.handlerRva;
 bool running=false;for(unsigned i=0;i<3;i++)running|=callbacks[i]==handler;
 AcquireSRWLockExclusive(&localContextLock68);
 const LocalContextOwner68 old=localContextOwner68;
 const bool same=frame->ready&&old.actor==actor&&old.generation==frame->playerGeneration&&
  old.world==frame->worldGeneration&&old.realm==frame->realm;
 const bool active=candidate||(same&&running);
 localContextOwner68=active?(LocalContextOwner68){actor,frame->playerGeneration,frame->worldGeneration,frame->realm}:(LocalContextOwner68){0};
 ReleaseSRWLockExclusive(&localContextLock68);return active;
}
