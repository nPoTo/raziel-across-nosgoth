// SPDX-License-Identifier: GPL-3.0-or-later
#pragma once
#ifdef SR1_LOCAL_COMBAT75
static uint32_t localSwordTint75(unsigned form){
 const Sheet_sr1Reaver75 *p=&sheet_sr1Reaver75_blade_material;
 const uint32_t tints[]={0,p->rgb1,p->rgb2,p->rgb3,p->rgb4,p->rgb5,p->rgb6,p->rgb7,p->rgb8,p->rgb9};
 return form<ARRAYSIZE(tints)?tints[form]:0;
}
#endif
static float localSwordCharge74(float charge){return isfinite(charge)?fmaxf(0,fminf(1,charge)):0;}
static void localSwordColor74(uint32_t rgb,float charge,float alpha,unsigned kind,float out[4]){
#ifdef SR1_LOCAL_COMBAT75
 (void)charge;(void)kind;
 out[0]=((rgb>>16)&255)/255.f;out[1]=((rgb>>8)&255)/255.f;out[2]=(rgb&255)/255.f;
 out[3]=isfinite(alpha)?fmaxf(0,fminf(1,alpha)):0;
#else
 const Sheet_sr1SwordColor74*p=&sheet_sr1SwordColor74_saturated_shadow;charge=localSwordCharge74(charge);
 float peak=(kind==0?p->trailStartPermille:kind==1?p->flashStartPermille:p->worldStartPermille)/1000.f;
 const float full=(kind==0?p->trailFullPermille:kind==1?p->flashFullPermille:p->worldFullPermille)/1000.f;peak+=(full-peak)*charge;
 const float power=(p->saturationStartPermille+(p->saturationFullPermille-p->saturationStartPermille)*charge)/1000.f;
 out[0]=((rgb>>16)&255)/255.f;out[1]=((rgb>>8)&255)/255.f;out[2]=(rgb&255)/255.f;
 const float max=fmaxf(out[0],fmaxf(out[1],out[2])),min=max>0?fminf(out[0],fminf(out[1],out[2]))/max:0,deep=powf(min,power);
 for(unsigned k=0;k<3;k++)out[k]=max>0?(min<1?deep+(1-deep)*(out[k]/max-min)/(1-min):1)*peak:0;
 const float opacity=1+charge*((kind==0?p->trailOpacityFullPermille:kind==1?p->flashOpacityFullPermille:1000)/1000.f-1);
 out[3]=isfinite(alpha)?fmaxf(0,fminf(1,alpha*opacity)):0;
#endif
}
