// SPDX-License-Identifier: GPL-3.0-or-later
#pragma once
// Same branch order as the released 0.2 nativeInteractionR12Classify.
typedef struct{uintptr_t handler,slot,target;uint32_t generation,kind;} LocalContextCandidate69;
static LocalContextCandidate69 localContextBranch69(uint32_t flags){
 const Sheet_sr1Context69 *const p=&sheet_sr1Context69_released02_native_priority;
 if(flags&(uint32_t)p->pushMask)return (LocalContextCandidate69){.handler=(uintptr_t)p->pushRva,.slot=(uintptr_t)p->pushSlot,.kind=1};
 if(flags&(uint32_t)p->switchMask)return (LocalContextCandidate69){.handler=(uintptr_t)p->switchRva,.slot=(uintptr_t)p->switchSlot,.kind=2};
 if(flags&(uint32_t)p->animationMask)return (LocalContextCandidate69){.handler=(uintptr_t)p->animationRva,.slot=(flags&0x10u)?(uintptr_t)p->animationSlot:(uintptr_t)p->otherAnimationSlot,.kind=3};
 if(flags&(uint32_t)p->messageMask)return (LocalContextCandidate69){0};
 if(flags&(uint32_t)p->gateMask)return (LocalContextCandidate69){.handler=(uintptr_t)p->gateRva,.slot=(uintptr_t)p->gateSlot,.kind=5};
 return (LocalContextCandidate69){0};
}
static LocalContextCandidate69 localContextCandidate69(const Sr1LocalFrame *f,uintptr_t actor){
 const Sheet_sr1Context69 *const p=&sheet_sr1Context69_released02_native_priority;
 LocalContextCandidate69 none={0};uint32_t flags=0,kind=0,world=0,disabled=0;uintptr_t slots=0,blade=0,parent=0,queryFn=0;
 if(!f->ready||!actor||f->realm==SR1_LOCAL_UNKNOWN||!f->groundContact48||f->airState!=SR1_AIR_NONE||
    generation(actor)!=f->playerGeneration||!readAt(actor+0x24,&disabled,4)||(disabled&(uint32_t)p->disabledActorMask)||
    !readAt(base+(uintptr_t)p->controlFlagsRva,&disabled,4)||(disabled&(uint32_t)p->disabledControlMask)||
    !readAt(base+host->interactionFlagsRva,&flags,4)||!readAt(base+host->interactionTypeRva,&kind,4)||kind!=0x1000)return none;
 LocalContextCandidate69 c=localContextBranch69(flags);if(!c.kind)return none;
 if(!readAt(base+host->targetsRva,&slots,8)||!slots||!readAt(slots+c.slot,&c.target,8)||!c.target||c.target==actor||
    !readAt(base+host->reaverRva,&blade,8)||c.target==blade||!readAt(c.target+0x60,&world,4)||world!=f->worldGeneration||
    !readAt(c.target+host->parentOffset,&parent,8)||parent||!readAt(c.target+0x1b0,&queryFn,8)||
    queryFn<base+(uintptr_t)p->textStart||queryFn>=base+(uintptr_t)p->textEnd||!(c.generation=generation(c.target)))return none;
 typedef uintptr_t(*ContextQuery69)(uintptr_t,uint32_t);
 if(((ContextQuery69)(base+signals->queryRva))(c.target,(uint32_t)p->typeQuery)&(uintptr_t)p->queryMask)return none;
 uintptr_t again=0;uint32_t after=0,typeAfter=0;
 if(generation(c.target)!=c.generation||!readAt(c.target+0x60,&after,4)||after!=world||
    !readAt(slots+c.slot,&again,8)||again!=c.target||!readAt(base+host->interactionFlagsRva,&after,4)||after!=flags||
    !readAt(base+host->interactionTypeRva,&typeAfter,4)||typeAfter!=kind)return none;
 return c;
}
static bool localNativeContext68(const Sr1LocalFrame *f,uintptr_t actor){return localContextCandidate69(f,actor).kind!=0;}
typedef struct{uintptr_t actor,handler;uint32_t generation,world,target,kind;Sr1LocalRealm realm;bool entered;}LocalContextOwner69;
static SRWLOCK localContextLock69=SRWLOCK_INIT;
static LocalContextOwner69 localContextOwner69;
static bool localContextHeld69(const Sr1LocalFrame *f,uintptr_t actor){
 AcquireSRWLockShared(&localContextLock69);const LocalContextOwner69 o=localContextOwner69;ReleaseSRWLockShared(&localContextLock69);
 return f->ready&&o.actor==actor&&o.generation==f->playerGeneration&&o.world==f->worldGeneration&&o.realm==f->realm&&o.kind;
}
static bool localNativeContextFrame68(const Sr1LocalFrame *f,uintptr_t actor,const uintptr_t callbacks[3]){
 const Sheet_sr1Context69 *const p=&sheet_sr1Context69_released02_native_priority;
 const LocalContextCandidate69 c=localContextCandidate69(f,actor);
 AcquireSRWLockExclusive(&localContextLock69);LocalContextOwner69 o=localContextOwner69;
 const bool same=f->ready&&o.actor==actor&&o.generation==f->playerGeneration&&o.world==f->worldGeneration&&o.realm==f->realm;
 bool running=false;for(unsigned i=0;i<3;i++){const uintptr_t r=callbacks[i]-base;
  running|=same&&(r==o.handler||r==(uintptr_t)p->pushRva||r==(uintptr_t)p->blockTailRva||r==(uintptr_t)p->switchRva||r==(uintptr_t)p->animationRva||r==(uintptr_t)p->gateRva);
 }
 if(c.kind){
  if(!same||!o.kind){o=(LocalContextOwner69){actor,c.handler,f->playerGeneration,f->worldGeneration,c.generation,c.kind,f->realm,false};
   record("native-context69-candidate kind=%u target=%u handler=%llx world=%u",c.kind,c.generation,(unsigned long long)c.handler,f->worldGeneration);
  }
 }else if(!running){
  if(same&&o.kind)record("native-context69-return kind=%u target=%u entered=%u",o.kind,o.target,o.entered);
  o=(LocalContextOwner69){0};
 }
 if(running&&!o.entered){o.entered=true;record("native-context69-enter kind=%u target=%u",o.kind,o.target);}
 localContextOwner69=o;const bool active=o.kind!=0;ReleaseSRWLockExclusive(&localContextLock69);return active;
}
