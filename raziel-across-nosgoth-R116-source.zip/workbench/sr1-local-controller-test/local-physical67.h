// SPDX-License-Identifier: GPL-3.0-or-later
#pragma once
// Reaver Y uses SRX's spare Look binding. A physical weapon must receive the
// native aim/throw/contextual-finisher command instead of native Look.
static bool localPhysicalAlias67(NativePad *p,bool admitted,uint32_t look,uint32_t aim){
 if(!admitted||!look||!aim||look==aim||(look&aim))return false;
 const uint32_t held=p->held,pressed=p->pressed,released=p->released;
 if(!((held|pressed|released)&look))return false;
 p->held=(held&~look)|((held&look)?aim:0);
 p->pressed=(pressed&~look)|((pressed&look)?aim:0);
 p->released=(released&~look)|((released&look)?aim:0);
 // Releasing one alias must not release a still-held native aim button.
 if(p->held&aim)p->released&=~aim;
 return true;
}
#ifndef LOCAL_PHYSICAL67_POLICY_ONLY
static bool localPhysicalReady67(const Sr1LocalFrame *frame,uintptr_t actor,uint32_t *kind){
 uintptr_t child=0,blade=0,parent=0;uint16_t mode=1;uint32_t flags=UINT32_MAX;
 if(!frame->ready||!actor||actor!=player||frame->realm==SR1_LOCAL_UNKNOWN||!frame->playerGeneration||generation(actor)!=frame->playerGeneration||
    !readAt(base+0x2a89536,&mode,2)||mode||!readAt(base+0x2a8950c,&flags,4)||(flags&(0x10000000u|motion->scriptedPadMask))||
    !readAt(base+host->interactionTypeRva,kind,4)||*kind<1||*kind>3||
    !readAt(actor+host->childOffset,&child,8)||!readAt(base+host->reaverRva,&blade,8))return false;
 for(unsigned i=0;child&&i<8;i++){
  if(child!=blade&&generation(child)&&readAt(child+host->parentOffset,&parent,8)&&parent==actor)return true;
  if(!readAt(child+host->siblingOffset,&child,8))return false;
 }return false;
}
static void localPhysicalInput67(NativePad *p,const Sr1LocalFrame *frame){
 const Sheet_sr1Physical67 *const policy=&sheet_sr1Physical67_native_weapon_y;
 uint32_t kind=0;const NativePad before=*p;
 if(!localPhysicalAlias67(p,localPhysicalReady67(frame,player,&kind),(uint32_t)policy->lookMask,(uint32_t)policy->finishMask))return;
 if((before.pressed|before.released)&(uint32_t)policy->lookMask){
  int32_t speed[6]={0},physics=-1;readAt(player+0x2cc,speed,sizeof speed);readAt(base+policy->physicsModeRva,&physics,4);
  record("native-physical-y67 kind=%u held=%x/%x pressed=%x/%x released=%x/%x physics=%ld velocity=%ld,%ld,%ld gravity=%ld",kind,before.held,p->held,before.pressed,p->pressed,before.released,p->released,(long)physics,(long)speed[0],(long)speed[1],(long)speed[2],(long)speed[5]);
 }
}
#endif
