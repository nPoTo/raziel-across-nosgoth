// SPDX-License-Identifier: GPL-3.0-or-later
#pragma once
#ifdef SR1_LOCAL_COMBAT50
#ifdef SR1_LOCAL_COMBAT52
static bool localCameraRotor52(const Sr1LocalFrame *frame,uintptr_t actor){return localReadSpecial(frame,actor,GetTickCount64()).move==LOCAL_SPECIAL_TEMPEST;}
#endif
#include "local-camera50.h"
#endif

#define worldRead readAt
#include "root-controller-read.h"
#undef worldRead

typedef int (*LocalStrikeUpdate)(uintptr_t, uintptr_t, uintptr_t, int32_t);
typedef void (*LocalMotionToggle)(uintptr_t, int32_t, int32_t);

static const Sheet_sr1LocalStrikeTravel *const strikeTravel = &sheet_sr1LocalStrikeTravel_first_ground_strike;
static LocalStrikeUpdate originalStrikeUpdate;
static const uintptr_t strikeEnable[2] = {0x61ce0, 0x61d80}, strikeDisable[2] = {0x61bb0, 0x61bf0};
static const uintptr_t strikeAnim[2] = {0x328, 0x448};
static _Thread_local struct {
    uintptr_t actor;
    uint32_t generation;
    unsigned count;
    RootController native[2];
    unsigned char applied[2][12];
} strikeMotion;
static _Thread_local struct {
    LocalActionOwner owner;
    uintptr_t descriptor;
    int32_t time, end;
    unsigned ordinal;
    float total;
#ifdef SR1_LOCAL_COMBAT_RECOVERY
    uint64_t startTick;
#endif
} strikeCursor;
#if defined(SR1_LOCAL_COMBAT_HANDOFF) && !defined(SR1_LOCAL_GROUND_X)
static bool thirdStrikeRecovery(const Sr1LocalFrame *frame, uintptr_t actor, uint64_t now) {
    if (strikeCursor.ordinal != 2 || !strikeCursor.descriptor ||
        !frame->ready || !frame->renderBlend || !frame->grounded || frame->nativeControl ||
        frame->airState != SR1_AIR_NONE || frame->groundStrike || frame->strikePending ||
        InterlockedCompareExchange64(&groundIntentTick, 0, 0) ||
        !sameLocalAction(&strikeCursor.owner, frame, actor, now, strikeTravel->maxGapMs)) return false;
    const LocalCombatInput controls = readLocalCombatInput();
    return !localYPresentation(&controls, frame, actor, now);
}
#endif
#ifdef SR1_LOCAL_COMBAT_PRESENTATION
static _Thread_local bool maintainingStrikeVector;
#ifdef SR1_LOCAL_SPECIAL_INPUT
static _Thread_local LocalActionOwner guardRoot;
static bool guardRootEligible(const Sr1LocalFrame *frame,uintptr_t actor,uint64_t now) {
#ifdef SR1_LOCAL_COMBAT56
    if(localFinishActive53(frame,actor,now))return false;
#endif
    const LocalCombatInput guard=readLocalCombatInput();
    return frame->ready && frame->renderBlend && frame->grounded && !frame->nativeControl &&
        !frame->groundStrike && !frame->strikePending && frame->airState==SR1_AIR_NONE &&
        guard.guardHeld && guard.guardDirectional && guard.guardSpeed>0.f &&
        now>=guard.guardSample && now-guard.guardSample<=(uint64_t)groundPolicy->maxGapMs &&
        sameLocalAction(&guard.guard,frame,actor,now,UINT64_MAX) &&
        !localYPresentation(&guard,frame,actor,now) &&
        !localReadSpecial(frame,actor,now).move && !readLocalDodge(frame,actor,now,0).owner.tick;
}
#endif
#ifdef SR1_LOCAL_AIR_CONTACT
static _Thread_local struct { uint64_t bank, tick; float total; } specialDrive;
#endif

static uintptr_t localHeldStrikeVector(unsigned kind, uintptr_t animation) {
    if (!maintainingStrikeVector || kind >= strikeMotion.count ||
        animation != strikeMotion.actor + strikeAnim[kind]) return 0;
    const Sr1LocalFrame current = readFrame();
    if (current.playerGeneration != strikeMotion.generation || player != strikeMotion.actor) return 0;
#ifdef SR1_LOCAL_GROUND_X
    const uint64_t now = GetTickCount64();
#ifdef SR1_LOCAL_SPECIAL_INPUT
    if (sameLocalAction(&guardRoot,&current,strikeMotion.actor,now,groundPolicy->maxGapMs) &&
        guardRootEligible(&current,strikeMotion.actor,now)) return (uintptr_t)strikeMotion.applied[kind];
#endif
#ifdef SR1_LOCAL_AIR_CONTACT
    const LocalSpecial special=localReadSpecial(&current,strikeMotion.actor,now);
    if (special.move==LOCAL_SPECIAL_PERFORATE && special.owner.tick==specialDrive.bank)
        return (uintptr_t)strikeMotion.applied[kind];
#endif
#ifdef SR1_LOCAL_CALIBRATED_COMBAT
    if (readLocalDodge(&current, strikeMotion.actor, now, groundPolicy->maxGapMs).owner.tick)
        return (uintptr_t)strikeMotion.applied[kind];
#endif
    const LocalGroundX x = readGroundX(&current, strikeMotion.actor, now);
    if (!x.owner.tick || x.start != strikeCursor.startTick || x.ordinal != strikeCursor.ordinal) return 0;
#else
    if (!(current.groundStrike && current.strikeIdentity == strikeCursor.descriptor)
#ifdef SR1_LOCAL_COMBAT_HANDOFF
        && !thirdStrikeRecovery(&current, strikeMotion.actor, GetTickCount64())
#endif
    ) return 0;
#endif
    return (uintptr_t)strikeMotion.applied[kind];
}
#endif

static bool strikeMotionActor(uintptr_t actor, uint32_t expected) {
    uintptr_t current, stateActor;
    return expected && readAt(base + host->actorRva, &current, sizeof(current)) && current == actor &&
        readAt(base + host->stateActorRva, &stateActor, sizeof(stateActor)) && stateActor == actor &&
        generation(actor) == expected;
}

static void releaseStrikeMotion(void) {
    if (!strikeMotion.count) return;
    if (strikeMotionActor(strikeMotion.actor, strikeMotion.generation)) {
        for (unsigned i = 0; i < strikeMotion.count
#ifdef SR1_LOCAL_COMBAT49
            && i<2
#endif
        ; ++i) {
            RootController observed;
            const uintptr_t animation = strikeMotion.actor + strikeAnim[i];
            if (!rootControllerRead(base, animation, i, &observed) || !observed.active ||
                observed.node != strikeMotion.native[i].node ||
                memcmp(observed.vector, strikeMotion.applied[i], i ? 12 : 6)) continue;
#ifdef SR1_LOCAL_COMBAT59
            // A saved pre-guard run vector is not an ongoing movement command after release.
            const Sr1LocalFrame released59=readFrame();
            unsigned char restored59[12];memcpy(restored59,strikeMotion.native[i].vector,12);
            if(localNeutralGuard59(&released59,GetTickCount64()))memset(restored59,0,i?8:4);
            originalLocalMotion[i](animation, 0, 34, (uintptr_t)restored59);
#else
            originalLocalMotion[i](animation, 0, 34, (uintptr_t)strikeMotion.native[i].vector);
#endif
            if (!strikeMotion.native[i].active) {
                ((LocalMotionToggle)(base + strikeDisable[i]))(animation, 0, 34);
            }
        }
    }
    strikeMotion.count = 0;
}

static bool applyStrikeVector(uintptr_t actor, uint32_t generation, float side, float forward) {
#ifdef SR1_LOCAL_COMBAT57
    localSpacingVector57(actor,&side,&forward);
#endif
#ifdef SR1_LOCAL_COMBAT49
    if(strikeMotion.count){
        bool owned=strikeMotion.count<=2&&strikeMotion.actor==actor&&strikeMotion.generation==generation&&strikeMotionActor(actor,generation);
        for(unsigned i=0;owned&&i<strikeMotion.count;i++){
            RootController current;
            owned=rootControllerRead(base,actor+strikeAnim[i],i,&current)&&current.active&&current.node==strikeMotion.native[i].node&&
                !memcmp(current.vector,strikeMotion.applied[i],i?12:6);
        }
        if(!owned){releaseStrikeMotion();return false;}
    }else
#endif
    {
    for (unsigned i = 0; i < 2; ++i) {
        RootController *saved = &strikeMotion.native[i];
        if (!rootControllerRead(base, actor + strikeAnim[i], i, saved) || !saved->found) return false;
    }
    }
    strikeMotion.actor = actor;
    strikeMotion.generation = generation;
    const int16_t legacy[3] = {(int16_t)lroundf(side), (int16_t)lroundf(forward), 0};
    const float remaster[3] = {side, forward, 0};
    for (unsigned i = 0; i < 2; ++i) {
        const uintptr_t animation = actor + strikeAnim[i];
        const void *vector = i ? (const void *)remaster : (const void *)legacy;
        if (!strikeMotion.native[i].active) ((LocalMotionToggle)(base + strikeEnable[i]))(animation, 0, 34);
        originalLocalMotion[i](animation, 0, 34, (uintptr_t)vector);
        memcpy(strikeMotion.applied[i], vector, i ? 12 : 6);
#ifdef SR1_LOCAL_COMBAT49
        if(strikeMotion.count<i+1)strikeMotion.count=i+1;
#else
        ++strikeMotion.count;
#endif
        RootController observed;
        if (!rootControllerRead(base, animation, i, &observed) || !observed.active ||
            observed.node != strikeMotion.native[i].node ||
            memcmp(observed.vector, vector, i ? 12 : 6)) {
            releaseStrikeMotion();
            return false;
        }
    }
    return true;
}

static bool applyStrikeStep(uintptr_t actor, uint32_t generation, float step) {
    return applyStrikeVector(actor, generation, 0.f, step);
}

#ifdef SR1_LOCAL_CALIBRATED_COMBAT
static _Thread_local struct {
    uint64_t start, last;
    float total;
} dodgeMotion;
#endif

#ifdef SR1_LOCAL_COMBAT_LINKS
static void maintainGuardFacing(uintptr_t actor, const Sr1LocalFrame *frame, uint64_t now) {
#ifdef SR1_LOCAL_COMBAT57
 if(localDodgeBusy56(frame,actor,now)){AcquireSRWLockShared(&localDodgeLock);const uint16_t yaw57=localDodge.bodyYaw;ReleaseSRWLockShared(&localDodgeLock);SIZE_T written=0;WriteProcessMemory(GetCurrentProcess(),(void*)(actor+sheet_sr1GroundSteering_camera_relative_start.yawOffset),&yaw57,2,&written);return;}
#endif
#ifdef SR1_LOCAL_COMBAT53
    if(localFinishActive53(frame,actor,now))return;
#endif
#ifdef SR1_LOCAL_LOCK47
    if (localTargetApply47(frame,actor,now)) return;
#endif
    const LocalCombatInput controls=readLocalCombatInput();
#ifdef SR1_LOCAL_COMBAT72
    if(now<controls.guardSample||now-controls.guardSample>(uint64_t)sheet_sr1Unlock72_explicit_release.heldFreshMs)return;
#endif
    if (!controls.guardHeld || !frame->ready || !frame->renderBlend ||
        !sameLocalAction(&guardFacing,frame,actor,now,UINT64_MAX)) return;
    const uintptr_t at=actor+sheet_sr1GroundSteering_camera_relative_start.yawOffset;
    uint16_t current;
#ifndef SR1_LOCAL_LOCK47
    if (hasLocalCombatTarget(frame)) {
        if (readAt(at,&current,sizeof(current))) guardFacingYaw=current;
        return;
    }
#endif
    SIZE_T written=0;
    WriteProcessMemory(GetCurrentProcess(),(void *)at,&guardFacingYaw,sizeof(guardFacingYaw),&written);
}
#endif

static int localStrikeUpdate(uintptr_t actor, uintptr_t context, uintptr_t input, int32_t mode) {
    if ((uintptr_t)__builtin_return_address(0) != base + (uintptr_t)strikeTravel->updateReturnRva) {
        return originalStrikeUpdate(actor, context, input, mode);
    }
#ifdef SR1_LOCAL_COMBAT_PRESENTATION
    if (strikeMotion.count) {
        const Sr1LocalFrame before = readFrame();
#ifdef SR1_LOCAL_GROUND_X
        const LocalGroundX x = readGroundX(&before, actor, GetTickCount64());
        maintainingStrikeVector = x.owner.tick && x.start == strikeCursor.startTick &&
            x.ordinal == strikeCursor.ordinal && player == actor && strikeMotionActor(actor, strikeMotion.generation);
#ifdef SR1_LOCAL_SPECIAL_INPUT
        maintainingStrikeVector |= sameLocalAction(&guardRoot,&before,actor,GetTickCount64(),groundPolicy->maxGapMs) &&
            guardRootEligible(&before,actor,GetTickCount64()) && player==actor &&
            strikeMotionActor(actor,strikeMotion.generation);
#endif
#ifdef SR1_LOCAL_AIR_CONTACT
        const LocalSpecial special=localReadSpecial(&before,actor,GetTickCount64());
        maintainingStrikeVector |= special.move==LOCAL_SPECIAL_PERFORATE && special.owner.tick==specialDrive.bank &&
            player==actor && strikeMotionActor(actor,strikeMotion.generation);
#endif
#ifdef SR1_LOCAL_CALIBRATED_COMBAT
        const LocalDodge dodge = readLocalDodge(&before, actor, GetTickCount64(), groundPolicy->maxGapMs);
        maintainingStrikeVector |= dodge.owner.tick && dodge.owner.tick == dodgeMotion.start &&
            player == actor && strikeMotionActor(actor, strikeMotion.generation);
#endif
#else
        maintainingStrikeVector = player == actor && strikeMotionActor(actor, strikeMotion.generation) &&
            ((before.groundStrike && before.strikeIdentity == strikeCursor.descriptor)
#ifdef SR1_LOCAL_COMBAT_HANDOFF
             || thirdStrikeRecovery(&before, actor, GetTickCount64())
#endif
            );
#endif
    }
    if (!maintainingStrikeVector) releaseStrikeMotion();
#else
    releaseStrikeMotion();
#endif
#ifdef SR1_LOCAL_COMBAT_FACING
    const DWORD turnError=GetLastError();
    const uint64_t turnNow=GetTickCount64();
#ifdef SR1_LOCAL_COMBAT75
    uint16_t entryYaw75;
    facingAvailable75=actor==player && readAt(actor+sheet_sr1GroundSteering_camera_relative_start.yawOffset,&entryYaw75,sizeof entryYaw75);
    if(facingAvailable75)facingBeforeStrike75=entryYaw75&4095u;
#endif
#ifdef SR1_LOCAL_COMBAT_LINKS
    if (actor==player) {
        const Sr1LocalFrame guardFrame=readFrame();
        maintainGuardFacing(actor,&guardFrame,turnNow);
    }
#endif
    if (actor==player && groundAim.tick) {
        const Sr1LocalFrame attackFrame=readFrame();
        const LocalCombatInput controls=readLocalCombatInput();
        if (attackFrame.groundStrike && attackFrame.airState==SR1_AIR_NONE &&
            sameLocalAction(&groundAim,&attackFrame,actor,turnNow,groundPolicy->maxGapMs) &&
#ifdef SR1_LOCAL_COMBAT_LINKS
            !controls.guardHeld) {
#else
            !(controls.guardHeld && hasLocalCombatTarget(&attackFrame))) {
#endif
            const uintptr_t yawAt=actor+sheet_sr1GroundSteering_camera_relative_start.yawOffset;
            uint16_t yaw;
            if (readAt(yawAt,&yaw,sizeof(yaw))) {
#ifdef SR1_LOCAL_COMBAT_LINKS
                const int delta=combatYawDelta(yaw,groundAimYaw);
                if (abs(delta)>=(int)combatLinks->groundDirectionBreak &&
                    !sameLocalAction(&directionRestart,&attackFrame,actor,turnNow,groundPolicy->maxGapMs)) {
                    directionRestart=localActionOwner(&attackFrame,actor,turnNow);
                    const uint16_t next=(uint16_t)groundAimYaw;
                    SIZE_T written=0;
                    if (WriteProcessMemory(GetCurrentProcess(),(void *)yawAt,&next,sizeof(next),&written) &&
                        written==sizeof(next)) {
                        memset(&groundedChain,0,sizeof(groundedChain));
                        AcquireSRWLockExclusive(&groundXLock);
                        groundXPlayback=(LocalGroundX){0};
                        ReleaseSRWLockExclusive(&groundXLock);
                        for (int section=0;section<3;++section)
                            originalGroundSwitch(base+host->stateActorRva,section,base+combatPolicy->nativeAttackRva,
                                (uintptr_t)groundActions->standingEntry);
                        AcquireSRWLockExclusive(&strikeLock);
                        strikePress=localActionOwner(&attackFrame,actor,turnNow);
                        ReleaseSRWLockExclusive(&strikeLock);
                        record("standalone-direction-restart realm=%u from=%u to=%u",attackFrame.realm,(unsigned)yaw,(unsigned)next);
                    }
                } else
#endif
                {
                const uint16_t next=(uint16_t)combatTurnStep(yaw,groundAimYaw);
                if (next!=(yaw&4095u)) {
                    SIZE_T written=0;
                    if (WriteProcessMemory(GetCurrentProcess(),(void *)yawAt,&next,sizeof(next),&written) && written==sizeof(next))
                        record("standalone-ground-aim realm=%u ordinal=%u from=%u to=%u",attackFrame.realm,
                            attackFrame.strikeOrdinal,(unsigned)yaw,(unsigned)next);
                }
                }
            }
        }
    }
    SetLastError(turnError);
#endif
    const int result = originalStrikeUpdate(actor, context, input, mode);
    const DWORD error = GetLastError();
#ifdef SR1_LOCAL_COMBAT_PRESENTATION
    maintainingStrikeVector = false;
    releaseStrikeMotion();
#endif
    const Sr1LocalFrame frame = readFrame();
#ifdef SR1_LOCAL_COMBAT50
    if(actor==player)localCameraUpdate50(&frame,actor);
#endif
#ifdef SR1_LOCAL_COMBAT48
    if(actor==player)localChargeCommit48(&frame,actor,GetTickCount64());
#ifdef SR1_LOCAL_COMBAT53
    if(actor==player)localUtilityTick53(&frame,GetTickCount64());
#ifdef SR1_LOCAL_COMBAT55
    if(actor==player)localSpellWatch55(&frame,GetTickCount64());
#endif
#endif
#endif
#ifdef SR1_LOCAL_COMBAT_LINKS
    if (actor==player) maintainGuardFacing(actor,&frame,GetTickCount64());
#endif
#ifdef SR1_LOCAL_GROUND_X
    const uint64_t now = GetTickCount64();
    const bool authorized = player == actor && strikeMotionActor(actor, frame.playerGeneration) &&
        InterlockedCompareExchange(&calibratedDrawReady, 0, 0);
#ifdef SR1_LOCAL_AIR_CONTACT
    const LocalSpecial special=authorized?localReadSpecial(&frame,actor,now):(LocalSpecial){0};
    if (special.move==LOCAL_SPECIAL_PERFORATE) {
        const Sheet_sr1LocalSpecialBanks *const stage=sheet_sr1LocalSpecialBanks_rows[special.bank];
        const float age=fminf(1.f,(float)(now-special.owner.tick)/(float)stage->durationMs);
        const float total=(float)stage->travelUnits*age*age*(3.f-2.f*age);
        const bool same=specialDrive.bank==special.owner.tick && now>=specialDrive.tick &&
            now-specialDrive.tick<=(uint64_t)groundPolicy->maxGapMs;
        if (!same) specialDrive.total=0.f;
        float step=total-specialDrive.total;
#ifdef SR1_LOCAL_COMBAT76
        const Sheet_sr1Combat76 *p76=&sheet_sr1Combat76_full_eyes_and_perforate;
        float target76[3]={0};bool aimed76=false;
        LocalThrustFollow76 follow76=localReadThrust76(&frame,actor,now);
        if(special.bank>special.first&&(special.bank<special.last
#ifdef SR1_LOCAL_COMBAT77
            ||(special.bank==special.last&&now-special.owner.tick<(uint64_t)sheet_sr1Combat77_authored_hand_and_charge.finalLungeMs)
#endif
        )){
            int16_t root76[3];
            aimed76=localThrustTarget76(&frame,actor,now,target76)&&readAt(actor+0x9c,root76,6);
            if(aimed76){
                const uint64_t dt76=follow76.owner.tick?now-follow76.owner.tick:0;
                const float gap76=hypotf(target76[0]-root76[0],target76[1]-root76[1]);
                const float speed76=
#ifdef SR1_LOCAL_COMBAT77
                    special.bank==special.last?(float)sheet_sr1Combat77_authored_hand_and_charge.finalLungeSpeed:
#endif
                    (float)p76->followMaxSpeed;
                step=localFollowStep76(fmaxf(0,step),gap76,(float)p76->followGap,speed76,dt76);
            }
        }
        int16_t rootBefore76[3];
        const bool rootReady76=readAt(actor+0x9c,rootBefore76,6);
        if(special.bank==special.first)follow76.distance=0;
        else if(rootReady76&&follow76.rooted&&follow76.owner.tick){
            const float walked76=hypotf((float)rootBefore76[0]-follow76.root[0],(float)rootBefore76[1]-follow76.root[1]);
            if(walked76<=(float)strikeTravel->maxStep)follow76.distance+=walked76;
        }
        follow76.rooted=rootReady76;if(rootReady76)memcpy(follow76.root,rootBefore76,sizeof rootBefore76);
#endif
#ifdef SR1_LOCAL_COMBAT76
        float side76=0,forward76=-step;
        if(aimed76&&rootReady76){
            uint16_t yaw76=0;
            if(readAt(actor+sheet_sr1GroundSteering_camera_relative_start.yawOffset,&yaw76,2)){
                const unsigned bearing76=(unsigned)(int)lroundf(atan2f(target76[0]-rootBefore76[0],rootBefore76[1]-target76[1])*(4096.f/6.28318530718f))&4095u;
                combatDodgeVector(yaw76,bearing76,step,&side76,&forward76);
            }
        }
        if(step>=0.f&&step<=(float)strikeTravel->maxStep&&applyStrikeVector(actor,frame.playerGeneration,side76,forward76))
#else
        if (step>=0.f && step<=(float)strikeTravel->maxStep && applyStrikeStep(actor,frame.playerGeneration,
#ifdef SR1_LOCAL_COMBAT_LINKS
            -step
#else
            step
#endif
        ))
#endif
        {
            specialDrive.total=total;

        }
#ifdef SR1_LOCAL_COMBAT76
        if(specialDrive.bank!=special.owner.tick)record("perforate-follow76 bank=%u aimed=%u step=%.2f actual-total=%.2f",special.bank,aimed76,step,follow76.distance);
        follow76.owner=localActionOwner(&frame,actor,now);follow76.aimed=aimed76;memcpy(follow76.target,target76,sizeof target76);
        AcquireSRWLockExclusive(&localThrustLock76);localThrustFollow76=follow76;ReleaseSRWLockExclusive(&localThrustLock76);
#endif
        specialDrive.bank=special.owner.tick;
        specialDrive.tick=now;
        SetLastError(error);
        return result;
    }
    specialDrive.bank=0;
#endif
#ifdef SR1_LOCAL_CALIBRATED_COMBAT
    const LocalDodge dodge = authorized ? readLocalDodge(&frame, actor, now, groundPolicy->maxGapMs) : (LocalDodge){0};
    if (dodge.owner.tick) {
        const uint64_t age = now - dodge.owner.tick;
        const bool continuous = dodgeMotion.start == dodge.owner.tick && dodgeMotion.last <= now &&
            now - dodgeMotion.last <= (uint64_t)groundPolicy->maxGapMs;
        const float target = localDodgeDistance(dodge.direction, age);
        const float pending = continuous ? target - dodgeMotion.total : 0.f;
        if (dodgeMotion.start != dodge.owner.tick)
            record("defiance-dodge-drive realm=%u direction=%u first=%llu", frame.realm, dodge.direction, (unsigned long long)age);
        float side = dodge.direction == 1 ? 0.f : dodge.direction == 0 ? pending : -pending;
        float forward = dodge.direction == 1 ? pending : 0.f;
        bool directionReady=true;
#ifdef SR1_LOCAL_COMBAT_FACING
        if (dodge.directional) {
            uint16_t yaw;
            directionReady=readAt(actor+sheet_sr1GroundSteering_camera_relative_start.yawOffset,&yaw,sizeof(yaw));
            if (directionReady) combatDodgeVector(yaw,dodge.bearing,pending,&side,&forward);
        }
#endif
#ifdef SR1_LOCAL_COMBAT49
        if(directionReady&&pending>0.f&&!localDodgeClear49(&frame,actor,side,forward)){
            releaseStrikeMotion();cancelLocalDodge();dodgeMotion=(__typeof__(dodgeMotion)){0};
            record("defiance-dodge-blocked realm=%u wall-or-support=1",frame.realm);SetLastError(error);return result;
        }
#endif
        if (directionReady && pending >= 0.f && pending <= (float)strikeTravel->maxStep &&
            applyStrikeVector(actor, frame.playerGeneration, side, forward)) {
            dodgeMotion.total = target;
        } else if (!continuous) {
            dodgeMotion.total = target;
        }
        dodgeMotion.start = dodge.owner.tick;
        dodgeMotion.last = now;
        SetLastError(error);
        return result;
    }
    dodgeMotion.start = dodgeMotion.last = 0;
    dodgeMotion.total = 0.f;
#endif
#ifdef SR1_LOCAL_SPECIAL_INPUT
    if (authorized && guardRootEligible(&frame,actor,now)) {
        const LocalCombatInput guard=readLocalCombatInput();
        uint16_t yaw;
        const uint64_t dt=sameLocalAction(&guardRoot,&frame,actor,now,groundPolicy->maxGapMs) ? now-guardRoot.tick : 0;
        if (readAt(actor+sheet_sr1GroundSteering_camera_relative_start.yawOffset,&yaw,sizeof(yaw))) {
            const float distance=(float)sheet_sr1LocalGuardDirection_combat_run.unitsPerSecond*guard.guardSpeed*dt/1000.f;
            float side,forward;
            combatDodgeVector(yaw,guard.guardBearing,distance,&side,&forward);
            if (distance<=(float)strikeTravel->maxStep && applyStrikeVector(actor,frame.playerGeneration,side,forward)) {
                static _Thread_local unsigned samples;
                if (++samples<=8 || samples%120==0)
                    record("standalone-guard-camera realm=%u body=%u bearing=%u side=%.2f forward=%.2f dt=%llu",
                        frame.realm,(unsigned)yaw,guard.guardBearing,side,forward,(unsigned long long)dt);
            }
        }
        guardRoot=localActionOwner(&frame,actor,now);
        SetLastError(error);
        return result;
    }
    guardRoot=(LocalActionOwner){0};
#endif
    const LocalGroundX x = advanceGroundX(&frame, actor, now, authorized);
    if (x.owner.tick) {
        const uint64_t age = now - x.start;
#if defined(SR1_LOCAL_NATIVE_COMBO_CLOCK)
        float total = nativeClockGroundXDistance(x.ordinal, age, x.fastClock);
#ifdef SR1_LOCAL_COMBAT75
        if(x.openerSlot)total*=(float)sheet_sr1Reaver75_blade_material.slot4Travel/(float)strikeTravel->distance;
#endif
#elif defined(SR1_LOCAL_CALIBRATED_COMBAT)
        const float total = calibratedGroundXDistance(x.ordinal,
#ifdef SR1_LOCAL_SPECIAL_INPUT
            combatGroundPoseAge(x.ordinal,age)
#else
            age
#endif
        );
#else
        const float total = groundXDistance(x.ordinal, age, (float)strikeTravel->distance);
#endif
        const bool continuous = sameLocalAction(&strikeCursor.owner, &frame, actor, now, strikeTravel->maxGapMs) &&
            strikeCursor.startTick == x.start && strikeCursor.ordinal == x.ordinal;
        float step = continuous ? total - strikeCursor.total : 0.f;
        if (continuous && x.ordinal == 2) {
#ifdef SR1_LOCAL_X_TEMPO
#ifdef SR1_LOCAL_CALIBRATED_COMBAT
            const float authoredEnd = -groundXDistance(2, 5000, (float)strikeTravel->distance);
            const float distanceScale = sheet_sr1CombatGroundReference_third.distance / authoredEnd;
            step = distanceScale * limitThirdDriveAtTempo(step / distanceScale, now - strikeCursor.owner.tick,
                groundXPlaybackAge(x.ordinal, age));
#else
            step = limitThirdDriveAtTempo(step, now - strikeCursor.owner.tick, age);
#endif
#else
            step = limitThirdDrive(step, now - strikeCursor.owner.tick);
#endif
        }
        strikeCursor.owner = x.owner;
        strikeCursor.startTick = x.start;
        strikeCursor.ordinal = x.ordinal;
        strikeCursor.total = total;
        if (fabsf(step) <= (float)strikeTravel->maxStep && applyStrikeStep(actor, frame.playerGeneration, step)) {
            record("defiance-ground-x realm=%u ordinal=%u elapsed=%llu native=%u phase=%ld/%ld step=%.2f total=%.2f",
                frame.realm, x.ordinal, (unsigned long long)age, frame.groundStrike,
                (long)frame.strikeTime, (long)frame.strikeEnd, step, total);
        }
    } else if (!frame.strikePending) {
        strikeCursor.owner = (LocalActionOwner){0};
    }
#else
#ifdef SR1_LOCAL_COMBAT_HANDOFF
    const uint64_t recoveryTick = GetTickCount64();
    if (player == actor && strikeMotionActor(actor, frame.playerGeneration) &&
        InterlockedCompareExchange(&calibratedDrawReady, 0, 0) &&
        thirdStrikeRecovery(&frame, actor, recoveryTick) &&
        thirdDrivePhase(strikeCursor.startTick, strikeCursor.owner.tick) < 1.f) {
        const float phase = thirdDrivePhase(strikeCursor.startTick, recoveryTick);
        const float total = measuredStrikeTravel(2, phase, (float)strikeTravel->distance);
        const float step = limitThirdDrive(total - strikeCursor.total, recoveryTick - strikeCursor.owner.tick);
        strikeCursor.owner = localActionOwner(&frame, actor, recoveryTick);
        strikeCursor.total = total;
        if (step != 0.f && fabsf(step) <= (float)strikeTravel->maxStep &&
            applyStrikeStep(actor, frame.playerGeneration, step)) {
            record("defiance-third-recovery realm=%u phase=%.3f step=%.2f total=%.2f",
                frame.realm, phase, step, total);
        }
        SetLastError(error);
        return result;
    }
#endif
    if (frame.groundStrike && player == actor && strikeMotionActor(actor, frame.playerGeneration) &&
        InterlockedCompareExchange(&calibratedDrawReady, 0, 0)) {
        const uint64_t now = GetTickCount64();
        unsigned poses = GROUND_POSE_STRIKE;
        float distance = strikeTravel->distance, advanceKeys = strikeTravel->advanceKeys;
#ifdef SR1_LOCAL_STRIKE_COMBO
        const Sheet_sr1LocalStrikeCombo *const descriptor = sheet_sr1LocalStrikeCombo_rows[frame.strikeOrdinal];
        poses = localStrikePoses[frame.strikeOrdinal];
        distance = descriptor->mode == 1 ? (float)descriptor->distance : 0.f;
        advanceKeys = descriptor->advanceKeys;
#endif
        const float key = (poses / 2.f - 1.f) * (float)frame.strikeTime / (float)(frame.strikeEnd - 1);
        float total = -distance * fminf(1.f, key / advanceKeys);
#ifdef SR1_MEASURED_GROUND_COMBO
        if (frame.strikeOrdinal)
            total = measuredStrikeTravel(frame.strikeOrdinal, (float)frame.strikeTime / (float)(frame.strikeEnd - 1),
                (float)strikeTravel->distance);
#endif
        const bool continuous = sameLocalAction(&strikeCursor.owner, &frame, actor, now, strikeTravel->maxGapMs) &&
            strikeCursor.descriptor == frame.strikeIdentity && strikeCursor.end == frame.strikeEnd &&
            strikeCursor.ordinal == frame.strikeOrdinal &&
            strikeCursor.time <= frame.strikeTime;
#ifdef SR1_LOCAL_COMBAT_RECOVERY
        if (!continuous) strikeCursor.startTick = now;
        if (frame.strikeOrdinal == 2) {
            const float phase =
#ifdef SR1_LOCAL_COMBAT_HANDOFF
                thirdDrivePhase(strikeCursor.startTick, now);
#else
                (float)(now - strikeCursor.startTick) / (float)combatTiming->groundThirdMs;
#endif
            total = measuredStrikeTravel(2, phase, (float)strikeTravel->distance);
        }
#endif
        float step = continuous ? total - strikeCursor.total : 0;
#ifdef SR1_LOCAL_COMBAT_RECOVERY
        if (continuous && frame.strikeOrdinal == 2) {
            step = limitThirdDrive(step, now - strikeCursor.owner.tick);
        }
#endif
        strikeCursor.owner = localActionOwner(&frame, actor, now);
        strikeCursor.descriptor = frame.strikeIdentity;
        strikeCursor.time = frame.strikeTime;
        strikeCursor.ordinal = frame.strikeOrdinal;
        strikeCursor.end = frame.strikeEnd;
        strikeCursor.total = total;
        if (fabsf(step) <= (float)strikeTravel->maxStep && applyStrikeStep(actor, frame.playerGeneration, step)) {
            record("defiance-strike-drive realm=%u ordinal=%u phase=%ld/%ld step=%.2f total=%.2f", frame.realm,
                frame.strikeOrdinal, (long)frame.strikeTime, (long)frame.strikeEnd, step, total);
        }
    } else {
        strikeCursor.owner = (LocalActionOwner){0};
    }
#endif
    SetLastError(error);
    return result;
}

static bool prepareLocalStrikeTravel(void) {
    const unsigned char call[] = {0xe8, 0x02, 0xf0, 0xfe, 0xff};
    if (!matches(strikeTravel->updateReturnRva - sizeof(call), call, sizeof(call)) ||
        !verifyDrawBlock(strikeTravel->updateRva, strikeTravel->updateBytes, LOCAL_STRIKE_UPDATE_SHA)) return false;
    for (unsigned i = 5; i < ARRAYSIZE(instantRootProofs); ++i) {
        if (!verifyDrawBlock(instantRootProofs[i].rva, instantRootProofs[i].size, instantRootProofs[i].sha256)) return false;
    }
    return MH_CreateHook((void *)(base + strikeTravel->updateRva), localStrikeUpdate,
        (void **)&originalStrikeUpdate) == MH_OK;
}
