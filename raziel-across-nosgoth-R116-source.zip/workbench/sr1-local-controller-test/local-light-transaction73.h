// SPDX-License-Identifier: GPL-3.0-or-later
#pragma once
typedef void(*LocalLightUniform73)(void*,int,float[4],bool);
typedef void(*LocalLightDraw73)(void*);
static bool localLightTransaction73(void*ctx,LocalLightUniform73 uniform,LocalLightDraw73 draw,int pos,int col,const float beforePos[4],const float beforeCol[4],const float nextPos[4],const float nextCol[4],bool*failed){
 if(*failed||pos<0||col<0||pos==col)return false;
 float p[4],c[4];memcpy(p,nextPos,16);memcpy(c,nextCol,16);uniform(ctx,pos,p,false);uniform(ctx,col,c,false);uniform(ctx,pos,p,true);uniform(ctx,col,c,true);
 if(memcmp(p,nextPos,16)||memcmp(c,nextCol,16)){
  memcpy(p,beforePos,16);memcpy(c,beforeCol,16);uniform(ctx,pos,p,false);uniform(ctx,col,c,false);uniform(ctx,pos,p,true);uniform(ctx,col,c,true);if(memcmp(p,beforePos,16)||memcmp(c,beforeCol,16))*failed=true;return false;
 }
 draw(ctx);uniform(ctx,pos,p,true);uniform(ctx,col,c,true);
 const bool ownP=!memcmp(p,nextPos,16),ownC=!memcmp(c,nextCol,16);
 if(ownP){memcpy(p,beforePos,16);uniform(ctx,pos,p,false);}else *failed=true;
 if(ownC){memcpy(c,beforeCol,16);uniform(ctx,col,c,false);}else *failed=true;
 uniform(ctx,pos,p,true);uniform(ctx,col,c,true);if((ownP&&memcmp(p,beforePos,16))||(ownC&&memcmp(c,beforeCol,16)))*failed=true;
 return true;
}
