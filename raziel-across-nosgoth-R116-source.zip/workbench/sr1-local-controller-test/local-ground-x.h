// SPDX-License-Identifier: GPL-3.0-or-later
#pragma once

#include "local-ground-x-curve.h"

typedef struct {
    LocalActionOwner owner;
    uint64_t start;
    unsigned ordinal;
    bool nativeStrike;
#ifdef SR1_LOCAL_COMBAT75
    unsigned openerSlot;
#endif
#ifdef SR1_LOCAL_NATIVE_COMBO_CLOCK
    bool fastClock;
#endif
} LocalGroundX;

static SRWLOCK groundXLock = SRWLOCK_INIT;
static LocalGroundX groundXPlayback;
#ifdef SR1_LOCAL_COMBAT75
#include "local-context-opener75.h"
static _Thread_local unsigned facingBeforeStrike75;
static _Thread_local bool facingAvailable75;
static unsigned localContextOpener75(const Sr1LocalFrame *f,uintptr_t actor,uint64_t now){
    if(!facingAvailable75)return 0;
    unsigned bearing;
    int16_t from[3],to[3];
    const LocalTargetLock47 lock=localTargetSnapshot47(false);
    if(lock.held){
        if(!localTargetValid47(&lock,f,actor,now,to)||!readAt(actor+0x9c,from,sizeof from)||
           (from[0]==to[0]&&from[1]==to[1]))return 0;
        bearing=localTargetYaw47(from,to);
    }else if(sameLocalAction(&groundAim,f,actor,now,groundPolicy->maxGapMs)){
        bearing=groundAimYaw;
    }else{
        uint32_t flags=0,gen=0;uintptr_t slots=0,target=0;
        if(!readAt(base+host->interactionFlagsRva,&flags,4)||!(flags&signals->finishEngagementMask)||
           !readAt(base+host->targetsRva,&slots,8)||!slots||
           !readAt(slots+signals->finishTargetOffset,&target,8)||!localLockReadTarget47(target,f,&gen,to)||
           !readAt(actor+0x9c,from,sizeof from)||(from[0]==to[0]&&from[1]==to[1]))return 0;
        bearing=localTargetYaw47(from,to);
    }
    return localAngleOpener75(facingBeforeStrike75,bearing);
}
#endif

static bool groundXContext(const Sr1LocalFrame *frame, uintptr_t actor, uint64_t now) {
#ifdef SR1_LOCAL_COMBAT56
    if(localDodgeBusy56(frame,actor,now)||localFinishActive53(frame,actor,now))return false;
#endif
    if (!frame->ready || !frame->renderBlend || frame->realm == SR1_LOCAL_UNKNOWN) return false;
    if (frame->groundStrike) return true;
    if (frame->airState != SR1_AIR_NONE || frame->strikePending) return false;
#ifdef SR1_LOCAL_THIRD_FINISH
    if (frame->strikeSettled) return true;
#endif
    if (frame->nativeControl || !frame->grounded)
        return false;
    const LocalCombatInput controls = readLocalCombatInput();
    return !localYPresentation(&controls, frame, actor, now);
}

static bool groundXCurrent(const LocalGroundX *x, const Sr1LocalFrame *frame, uintptr_t actor, uint64_t now) {
    return sameLocalAction(&x->owner, frame, actor, now, sheet_sr1LocalStrikeTravel_first_ground_strike.maxGapMs);
}

static LocalGroundX readGroundX(const Sr1LocalFrame *frame, uintptr_t actor, uint64_t now) {
    if (!groundXContext(frame, actor, now)) return (LocalGroundX){0};
    AcquireSRWLockShared(&groundXLock);
    const LocalGroundX x = groundXPlayback;
    ReleaseSRWLockShared(&groundXLock);
    if (!groundXCurrent(&x, frame, actor, now) || (frame->groundStrike && x.ordinal != frame->strikeOrdinal))
        return (LocalGroundX){0};
    return x;
}

static LocalGroundX advanceGroundX(const Sr1LocalFrame *frame, uintptr_t actor, uint64_t now, bool authorized) {
    const bool eligible = authorized && groundXContext(frame, actor, now);
    AcquireSRWLockExclusive(&groundXLock);
    LocalGroundX x = groundXPlayback;
    const bool continuous = eligible && groundXCurrent(&x, frame, actor, now);
    if (eligible && frame->groundStrike) {
        if (!continuous || !x.nativeStrike || x.ordinal != frame->strikeOrdinal) {
            x.start = now;
            x.ordinal = frame->strikeOrdinal;
#ifdef SR1_LOCAL_COMBAT75
            x.openerSlot=x.ordinal==0?localContextOpener75(frame,actor,now):0;
            if(x.openerSlot)record("defiance-context-opener75 slot=%u sequence=%llu",x.openerSlot,(unsigned long long)now);
#endif
        }
        x.owner = localActionOwner(frame, actor, now);
        x.nativeStrike = true;
#ifdef SR1_LOCAL_NATIVE_COMBO_CLOCK
        x.fastClock = nativeGroundLinkKnown(x.ordinal, frame->strikeEnd);
#endif
    } else if (continuous &&
#ifdef SR1_LOCAL_NATIVE_COMBO_CLOCK
        groundXRecoveryRemaining(x.ordinal, x.owner.tick - x.start, x.fastClock)
#else
        groundXHasRemaining(x.ordinal, groundXPlaybackAge(x.ordinal,
#ifdef SR1_LOCAL_COMBAT_SYNC42
            combatGroundPoseAge(x.ordinal,x.owner.tick-x.start)
#else
            x.owner.tick-x.start
#endif
        ))
#endif
    ) {
        // Publish the final clamped step once. The next native update consumes it and retires ownership.
        x.owner = localActionOwner(frame, actor, now);
        x.nativeStrike = false;
    } else if (!frame->strikePending || !groundXCurrent(&x, frame, actor, now)) {
        x = (LocalGroundX){0};
    }
    groundXPlayback = x;
    ReleaseSRWLockExclusive(&groundXLock);
    return eligible ? x : (LocalGroundX){0};
}
