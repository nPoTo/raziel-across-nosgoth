// SPDX-License-Identifier: GPL-3.0-or-later
#pragma once
static uint32_t localFxColor51(unsigned);
static void localHudLightning54(const unsigned char*packet,const GLint viewport[4],unsigned form){
 const LocalChargeView48 charge=localChargeRead48();if(!charge.charge||charge.charge>100)return;
 static const unsigned char white[4]={255,255,255,255};const unsigned slot=HUD_MAX_TEXTURES-1;
 if(!localHud45GL.textures[slot]&&!reaverGLTexture(&localHud45GL,slot,1,1,white,false,false))return;
 const unsigned char*blade=packet+96;const unsigned frame=(unsigned)(GetTickCount64()*sheet_sr1Combat54_utility_aim_hud.hudHz/1000);
 const float a[2]={hudF32(blade+16),hudF32(blade+20)},b[2]={hudF32(blade+24),hudF32(blade+28)},d[2]={hudF32(blade+40),hudF32(blade+44)};
 const float across[2]={d[0]-a[0],d[1]-a[1]},l=hypotf(across[0],across[1]);if(l<1)return;
 const float reach=.6f*charge.charge/100.f,normal[2]={across[0]/l,across[1]/l};
 const uint32_t rgb=
#ifdef SR1_LOCAL_COMBAT76
 localSwordTint75(form);
#else
 localFxColor51(form);
#endif
 const unsigned segments=(unsigned)sheet_sr1Combat54_utility_aim_hud.hudSegments;
#ifdef SR1_LOCAL_COMBAT77
 const float white77=sheet_sr1Combat77_authored_hand_and_charge.lightningWhitePermille/1000.f;
#endif
 for(unsigned side=0;side<2;side++){
  float previous[2]={0};
  for(unsigned i=0;i<=segments;i++){
   const float t=(float)i/segments,u=.05f+reach*t;
   const uint32_t seed=(frame*747796405u+i*2891336453u+side*277803737u)^0x9e3779b9u;
   const float jag=(float)((seed^(seed>>16))&1023u)/511.5f-1.f;
   const float offset=(side?1.f:-1.f)*(sheet_sr1Combat54_utility_aim_hud.hudAmplitude*(.45f+.55f*jag))*sinf(t*3.141592654f);
   const float point[2]={a[0]+(b[0]-a[0])*u+across[0]*.33f+normal[0]*offset,a[1]+(b[1]-a[1])*u+across[1]*.33f+normal[1]*offset};
   if(i){const float dx=point[0]-previous[0],dy=point[1]-previous[1],length=hypotf(dx,dy);if(length>0){
    for(unsigned pass=0;pass<2;pass++){
     unsigned char q[80]={0};const uint32_t blend=
#ifdef SR1_LOCAL_COMBAT76
 1;
#else
 2;
#endif
     memcpy(q+4,&blend,4);
     const float width=pass?sheet_sr1Combat54_utility_aim_hud.hudWidth:sheet_sr1Combat54_utility_aim_hud.hudHaloWidth;
     const float n[2]={-dy/length*width,dx/length*width};
     const float xy[8]={previous[0]+n[0],previous[1]+n[1],point[0]+n[0],point[1]+n[1],point[0]-n[0],point[1]-n[1],previous[0]-n[0],previous[1]-n[1]};
     memcpy(q+16,xy,sizeof xy);const float uv[4]={0,0,1,1};memcpy(q+48,uv,sizeof uv);
     const float color[4]={
#if defined(SR1_LOCAL_COMBAT77)
 pass?white77+(1-white77)*((rgb>>16)&255)/255.f:((rgb>>16)&255)/255.f,
 pass?white77+(1-white77)*((rgb>>8)&255)/255.f:((rgb>>8)&255)/255.f,
 pass?white77+(1-white77)*(rgb&255)/255.f:(rgb&255)/255.f,
#elif defined(SR1_LOCAL_COMBAT76)
 ((rgb>>16)&255)/255.f,((rgb>>8)&255)/255.f,(rgb&255)/255.f,
#else
 .35f+.65f*((rgb>>16)&255)/255.f,.35f+.65f*((rgb>>8)&255)/255.f,.35f+.65f*(rgb&255)/255.f,
#endif
 pass?.95f:.2f};memcpy(q+64,color,sizeof color);
     hudDrawQuad(&localHud45GL,q,slot,viewport);
    }
   }}memcpy(previous,point,sizeof point);
  }
 }
}
