// SPDX-License-Identifier: GPL-3.0-or-later
#pragma once
// Defiance 0x125250 compares facing and desired attack bearing in turns.
// Its half-turn tie keeps the sign of the unwrapped difference.
static unsigned localAngleOpener75(unsigned facing,unsigned bearing){
    int delta=(int)(bearing&4095u)-(int)(facing&4095u);
    if(delta>2048)delta-=4096;
    if(delta< -2048)delta+=4096;
    if((int64_t)abs(delta)*1000000 <= 4096*sheet_sr1Reaver75_blade_material.frontAngleMillionths)return 0;
    return delta>0?4:5;
}

