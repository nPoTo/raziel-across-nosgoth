// SPDX-License-Identifier: GPL-3.0-or-later
#pragma once
#include "local-eye-proof76.h"
static unsigned char *localEyes76;
static unsigned localEyesVertices76,localEyesIndices76;
static _Thread_local ReaverGL localEyesGl76;
static _Thread_local ReaverGLVertex localEyesDraw76[8192];
static bool loadLocalEyes76(HANDLE pipe,uint64_t deadline){
 unsigned char *data=HeapAlloc(GetProcessHeap(),0,LOCAL_EYES76_BYTES);if(!data)return false;
 DWORD filled=0;while(filled<LOCAL_EYES76_BYTES&&GetTickCount64()<deadline){
  DWORD got=0,available=0;if(!PeekNamedPipe(pipe,NULL,0,NULL,&available,NULL))break;if(!available){Sleep(2);continue;}
  DWORD n=LOCAL_EYES76_BYTES-filled;if(!ReadFile(pipe,data+filled,available<n?available:n,&got,NULL)||!got)break;filled+=got;
 }
 char hash[65];unsigned v=0,i=0;memcpy(&v,data,4);memcpy(&i,data+4,4);
 bool valid=filled==LOCAL_EYES76_BYTES&&boundedSha256(data,filled,LOCAL_EYES76_BYTES,hash)&&!strcmp(hash,LOCAL_EYES76_HASH)&&v>0&&v<=2048&&i>0&&i%3==0&&8u+v*36u+i*2u+512u*512u*4u==LOCAL_EYES76_BYTES;
 if(!valid){HeapFree(GetProcessHeap(),0,data);return false;}
 const uint16_t *indices=(const void*)(data+8+v*36);for(unsigned j=0;j<i;j++)if(indices[j]>=v){HeapFree(GetProcessHeap(),0,data);return false;}
 localEyesVertices76=v;localEyesIndices76=i;localEyes76=data;
 record("reaver-eyes76 RAM-ready vertices=%u indices=%u",v,i);return true;
}
static uint32_t localCoreTint76(unsigned form){
 const Sheet_sr1Combat76 *p=&sheet_sr1Combat76_full_eyes_and_perforate;
 const uint32_t colors[]={p->coreRgb1,p->coreRgb2,p->coreRgb3,p->coreRgb4,p->coreRgb5,p->coreRgb6,p->coreRgb7,p->coreRgb8,p->coreRgb9};
 return form&&form<=9?colors[form-1]:0;
}
static void localDrawEyes76(void){
 const Sr1LocalFrame f=readFrame();const unsigned form=localCurrentForm(f.realm);
 if(!localEyes76||!f.ready||!f.renderBlend||localEyeSession75!=f.session||localBladePalette.hand.actor!=player||form!=localBladeStaged45||!localFullCharge51(&f,player,GetTickCount64()))return;
 if(localEyesGl76.context!=wglGetCurrentContext()){memset(&localEyesGl76,0,sizeof localEyesGl76);if(!reaverGLInit(&localEyesGl76))return;}
 const uint16_t *indices=(const void*)(localEyes76+8+localEyesVertices76*36);
 if(!localEyesGl76.textures[0]&&!reaverGLTexture(&localEyesGl76,0,512,512,(const unsigned char*)(indices+localEyesIndices76),true,false))return;
 memcpy(localEyesDraw76,localEyes76+8,localEyesVertices76*sizeof(ReaverGLVertex));
 const unsigned rgb=localCoreTint76(form);
 for(unsigned i=0;i<localEyesVertices76;i++)for(unsigned k=0;k<3;k++)localEyesDraw76[i].rgba[k]=((rgb>>(16-8*k))&255u)/255.f;
 bool rendered=true;
 for(unsigned offset=0;offset<localEyesIndices76;offset+=8190){
  const unsigned count=localEyesIndices76-offset<8190?localEyesIndices76-offset:8190;
  rendered=reaverGLDraw(&localEyesGl76,localEyesDraw76,localEyesVertices76,indices+offset,count,0,1,localEyeMvp75,0,.5f)&&rendered;
 }
 if(rendered){
  static _Thread_local unsigned reported;static _Thread_local uint64_t session;
  if(reported!=form||session!=f.session){reported=form;session=f.session;record("reaver-eyes76 rendered form=%u rgb=%06x",form,rgb);}
 }
}
