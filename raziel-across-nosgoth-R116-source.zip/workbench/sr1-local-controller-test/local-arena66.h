// SPDX-License-Identifier: GPL-3.0-or-later
#pragma once
// All engine calls below run on the original compose/game thread.
typedef uintptr_t (*ArenaLookup66)(const char *);
typedef uintptr_t (*ArenaBirth66)(uintptr_t,uintptr_t,int);
typedef void (*ArenaInit66)(uintptr_t);
typedef void (*ArenaRemove66)(uintptr_t,uintptr_t,int);
typedef void (*ArenaResolve66)(uintptr_t);
typedef struct {const char *name;bool spectral;uintptr_t tracker,object;bool pinned;} ArenaFamily66;
static ArenaFamily66 arenaFamilies66[]={
 {"aluka",false,0,0,false},{"hunter",false,0,0,false},{"morlock",false,0,0,false},
 {"ronin",false,0,0,false},{"skinner",false,0,0,false},{"wallcr",false,0,0,false},
 {"wrshp",false,0,0,false},{"sluagh",true,0,0,false},{"vwraith",true,0,0,false}};
typedef struct {uintptr_t actor,object;uint32_t generation;unsigned family;} ArenaActor66;
static ArenaActor66 arenaActors66[18];
static const Sheet_sr1Arena66 *const arenaPolicy66=&sheet_sr1Arena66_temporary_arena;
static ArenaInit66 arenaOriginalInit66;
static ArenaLookup66 arenaLookupNative66;
static ArenaBirth66 arenaBirthNative66;
static ArenaRemove66 arenaRemoveNative66;
static ArenaResolve66 arenaResolveNative66;
static volatile LONG arenaCommand66;
static HANDLE arenaSignals66[3];
typedef struct {uintptr_t player,list;uint32_t generation,world;int16_t origin[3];unsigned count,next,total;bool pilot,loading;uint64_t started,lastSpawn;} ArenaState66;
typedef struct {bool active,applied;uintptr_t parent,object;int16_t position[3];bool spectral;} ArenaInitScope66;
static ArenaState66 arena66;
static _Thread_local ArenaInitScope66 arenaInitScope66;
static void arenaNotice66(const char *text){record("arena66 status=%s",text);portableStatus60(text);}
static uintptr_t arenaList66(void){uintptr_t list=0;readAt(base+arenaPolicy66->listRva,&list,8);return list;}
static bool arenaMember66(uintptr_t list,const ArenaActor66 *owned){
 uintptr_t actor=0;if(!owned->actor||!readAt(list+8,&actor,8))return false;
 for(unsigned i=0;actor&&i<80;i++){
  if(actor==owned->actor){uintptr_t object=0;return generation(actor)==owned->generation&&readAt(actor+0x30,&object,8)&&object==owned->object;}
  if(!readAt(actor+0x10,&actor,8))return false;
 }return false;
}
static bool arenaTracker66(const ArenaFamily66 *family,uintptr_t *tracker,uintptr_t *object){
 uintptr_t array=0;if(!readAt(base+arenaPolicy66->trackersRva,&array,8)||!array)return false;
 for(unsigned i=0;i<(unsigned)arenaPolicy66->trackerCount;i++){
  const uintptr_t at=array+i*arenaPolicy66->trackerStride;char name[17]={0};int16_t status=0;
  if(!readAt(at,name,16)||!readAt(at+0x18,&status,2))return false;
  if(status==2&&!strcmp(name,family->name)&&readAt(at+0x10,object,8)&&*object){*tracker=at;return true;}
 }return false;
}
static void arenaRelease66(ArenaFamily66 *family){
 uintptr_t tracker=0,object=0;int16_t users=0;
 if(family->pinned&&arenaTracker66(family,&tracker,&object)&&tracker==family->tracker&&object==family->object&&readAt(tracker+0x1a,&users,2)&&users>0){users--;memcpy((void*)(tracker+0x1a),&users,2);}
 family->pinned=false;family->tracker=family->object=0;
}
static void arenaCleanup66(void){
 const uintptr_t list=arenaList66();
 for(unsigned i=0;i<ARRAYSIZE(arenaActors66);i++){
  if(list&&arenaMember66(list,&arenaActors66[i]))arenaRemoveNative66(list,arenaActors66[i].actor,0);
  arenaActors66[i]=(ArenaActor66){0};
 }
 for(unsigned i=0;i<ARRAYSIZE(arenaFamilies66);i++)arenaRelease66(&arenaFamilies66[i]);
 arena66=(ArenaState66){0};arenaInitScope66.active=false;
}
static void arenaInit66(uintptr_t actor){
 uintptr_t object=0,parent=0;
 if(arenaInitScope66.active&&!arenaInitScope66.applied&&actor!=arenaInitScope66.parent&&
    readAt(actor+0x30,&object,8)&&object==arenaInitScope66.object&&readAt(actor+0x50,&parent,8)&&parent==arenaInitScope66.parent){
  // Never inherit Raziel's authored intro, script data, parent or physical pose.
  const uintptr_t zero=0;const int16_t rotation[4]={0,0,0,0},scale[3]={4096,4096,4096};
  for(unsigned i=0;i<3;i++){const uintptr_t at=actor+(i==0?0x38:i==1?0x48:0x50);memcpy((void*)at,&zero,8);}
  memcpy((void*)(actor+0x9c),arenaInitScope66.position,6);
  memcpy((void*)(actor+0xb2),arenaInitScope66.position,6);memcpy((void*)(actor+0xc8),arenaInitScope66.position,6);
  // Remaster uses parallel IEEE floats in the same native units:78b70..78c1f.
  for(unsigned i=0;i<3;i++){
   const float v=(float)arenaInitScope66.position[i],zeroFloat=0.f,scaleFloat=4096.f;
   memcpy((void*)(actor+0xa4+i*4),&v,4);memcpy((void*)(actor+0xb8+i*4),&v,4);
   memcpy((void*)(actor+0xd8+i*4),&zeroFloat,4);memcpy((void*)(actor+0xf0+i*4),&zeroFloat,4);
   memcpy((void*)(actor+0x108+i*4),&scaleFloat,4);
  }
  memcpy((void*)(actor+0xce),rotation,8);memcpy((void*)(actor+0xe8),rotation,8);memcpy((void*)(actor+0x100),scale,6);
  uint32_t flags=0;readAt(actor+0x28,&flags,4);flags=arenaInitScope66.spectral?(flags|0x8000000u):(flags&~0x8000000u);memcpy((void*)(actor+0x28),&flags,4);
  arenaInitScope66.applied=true;
 }
 arenaOriginalInit66(actor);
}
static bool arenaObject66(const ArenaFamily66 *family,uintptr_t object){
 uintptr_t at=0,data=0;char name[17]={0};uint32_t magic=0,type=0;int16_t models=0;
 if(!readAt(object+0x30,&at,8)||!at||!readAt(at,name,8)||strncmp(name,family->name,strlen(family->name))||
    !readAt(object+0x28,&data,8)||!data||!readAt(data,&magic,4)||magic!=0xace00065u||
    !readAt(data+0x20,&type,4)||(type&0x10000u)||!readAt(object+8,&models,2)||models<=0||models>32)return false;
 return true;
}
static bool arenaAnimationReady66(uintptr_t object){
 uint32_t flags=0;int16_t count=0;uintptr_t anims=0;
 if(!readAt(object+0x48,&flags,4)||(flags&0x10000000u)||!readAt(object+0xa,&count,2)||count<=0||count>4096||!readAt(object+0x18,&anims,8)||!anims)return false;
 for(int i=0;i<count;i++){uintptr_t key=0;uint32_t magic=0;if(!readAt(anims+(uintptr_t)i*8,&key,8)||!key||!readAt(key,&magic,4)||magic==0xface0ffu)return false;}
 return true;
}
static unsigned arenaFamilyIndex66(unsigned ordinal){return arena66.pilot?(ordinal==0?3u:8u):ordinal/2;}
static bool arenaCapacity66(unsigned required){
 uintptr_t pool=0;int32_t freeCount=0;const uintptr_t list=arenaList66();
 return list&&readAt(list+0x10,&pool,8)&&pool&&readAt(pool+4,&freeCount,4)&&freeCount>=(int32_t)(required+arenaPolicy66->reserveActors);
}
static bool arenaLoad66(void){
 unsigned loaded=0;const unsigned needed=arena66.pilot?2:9;
 for(unsigned i=0;i<needed;i++){
  const unsigned index=arena66.pilot?(i==0?3:8):i;ArenaFamily66 *family=&arenaFamilies66[index];uintptr_t tracker=0,object=0;
  if(arenaTracker66(family,&tracker,&object)){
   if(!arenaObject66(family,object))return false;
   if(!family->pinned){int16_t users=0;if(!readAt(tracker+0x1a,&users,2)||users<0||users>=32766)return false;users++;memcpy((void*)(tracker+0x1a),&users,2);family->tracker=tracker;family->object=object;family->pinned=true;record("arena66 model=%s loaded=1",family->name);}
   // Native IntroduceInstance789d7..789fe performs this same readiness step.
   // A loaded Object can still contain 0x0FACE0FF references to shared animations.
   uint32_t flags=0;if(!readAt(object+0x48,&flags,4))return false;
   if(flags&0x10000000u){
    uintptr_t array=0;unsigned freeSlots=0;if(!readAt(base+arenaPolicy66->trackersRva,&array,8)||!array)return false;
    for(unsigned j=0;j<(unsigned)arenaPolicy66->trackerCount;j++){int16_t status=0;if(!readAt(array+j*arenaPolicy66->trackerStride+0x18,&status,2))return false;if(!status)freeSlots++;}
    if(freeSlots<2)return false;
    arenaResolveNative66(tracker);
   }
   if(!arenaAnimationReady66(object))return true; // No birth until every family is complete.
   loaded++;continue;
  }
  uintptr_t array=0;bool freeSlot=false,loading=false;if(!readAt(base+arenaPolicy66->trackersRva,&array,8)||!array)return false;
  for(unsigned j=0;j<(unsigned)arenaPolicy66->trackerCount;j++){int16_t status=0;char name[17]={0};if(!readAt(array+j*arenaPolicy66->trackerStride+0x18,&status,2)||!readAt(array+j*arenaPolicy66->trackerStride,name,16))return false;if(!status)freeSlot=true;if(status==1&&!strcmp(name,family->name))loading=true;}
  if(!loading){if(!freeSlot){arenaNotice66("Arena stopped: no free model slot.");return false;}arenaLookupNative66(family->name);}
  return true; // At most one new native asynchronous request per game frame.
 }
 if(loaded==needed){arena66.loading=false;arenaNotice66("Arena models ready; spawning temporary opponents.");}
 return true;
}
static bool arenaSpawn66(void){
 if(!arenaCapacity66(arena66.total-arena66.next))return false;
 const unsigned index=arenaFamilyIndex66(arena66.next);ArenaFamily66 *family=&arenaFamilies66[index];uintptr_t tracker=0,object=0;
 if(!arenaTracker66(family,&tracker,&object)||object!=family->object||!arenaObject66(family,object)||!arenaAnimationReady66(object))return false;
 const unsigned ringIndex=family->spectral?(arena66.pilot?0:arena66.next-14):arena66.next;
 const unsigned inRing=family->spectral?(arena66.pilot?1:4):(arena66.pilot?1:14);
 const double angle=6.283185307179586*(double)ringIndex/(double)inRing;
 arenaInitScope66=(ArenaInitScope66){.active=true,.parent=arena66.player,.object=object,.spectral=family->spectral};
 for(unsigned i=0;i<3;i++){double v=arena66.origin[i]+(i==0?cos(angle)*arenaPolicy66->radius:i==1?sin(angle)*arenaPolicy66->radius:64);if(v<-32000||v>32000)return false;arenaInitScope66.position[i]=(int16_t)lround(v);}
 const uintptr_t actor=arenaBirthNative66(arena66.player,object,0);const bool initialized=arenaInitScope66.applied;arenaInitScope66.active=false;
 if(!actor)return false;
 ArenaActor66 owned={actor,object,generation(actor),index};arenaActors66[arena66.next]=owned;arena66.count++;
 if(!initialized||!owned.generation)return false;
 uintptr_t state=0,parent=1,intro=1;uint32_t flags=0;readAt(actor+0x2c0,&state,8);readAt(actor+0x50,&parent,8);readAt(actor+0x38,&intro,8);readAt(actor+0x28,&flags,4);
 record("arena66 born=%s generation=%u realm=%u state=%u parent=%u intro=%u flags=%x",family->name,owned.generation,family->spectral?2:1,state!=0,parent!=0,intro!=0,flags);
 if(!state||parent||intro||((flags&0x8000000u)!=0)!=family->spectral)return false;
 arena66.next++;arena66.lastSpawn=GetTickCount64();return true;
}
static void arenaFrame66(void){
 const LONG command=InterlockedExchange(&arenaCommand66,0);
 if(command==3){arenaCleanup66();arenaNotice66("Arena cleared. Original level enemies preserved.");return;}
 uintptr_t actor=0;uint32_t world=0;readAt(base+host->actorRva,&actor,8);if(actor)readAt(actor+0x60,&world,4);
 if(arena66.player&&(actor!=arena66.player||generation(actor)!=arena66.generation||world!=arena66.world||arenaList66()!=arena66.list)){
  arenaCleanup66();arenaNotice66("Arena cleared after player or level change.");return;
 }
 if(command){
  if(arena66.player){arenaNotice66("Arena already exists. Shift+F11 clears it.");return;}
  const Sr1LocalFrame frame=readLocalFrame(true);
  if(!InterlockedCompareExchange(&portableActive60,0,0)||!frame.ready||!frame.grounded||!frame.renderBlend||frame.nativeControl||frame.realm!=SR1_LOCAL_MATERIAL||localPhysicalCarry(actor)){
   arenaNotice66("Arena: enable F10, close menus and stand on flat ground in Material.");return;}
  const bool pilot=command==2;const unsigned total=pilot?2:18;if(!arenaCapacity66(total)){arenaNotice66("Arena refused: insufficient free actors (12 reserved).");return;}
  arena66.player=actor;arena66.generation=generation(actor);arena66.list=arenaList66();arena66.world=world;arena66.total=total;arena66.pilot=pilot;arena66.loading=true;arena66.started=GetTickCount64();
  if(!readAt(actor+0x9c,arena66.origin,6)){arenaCleanup66();return;}arenaNotice66("Arena: loading original enemy models in memory.");
 }
 if(!arena66.player||arena66.next>=arena66.total)return;
 const Sr1LocalFrame frame=readLocalFrame(true);if(!frame.ready||!frame.renderBlend)return;
 if(arena66.loading){if(GetTickCount64()-arena66.started>(uint64_t)arenaPolicy66->loadTimeoutMs||!arenaLoad66()){arenaCleanup66();arenaNotice66("Arena aborted: native model loading/validation failed.");}return;}
 if(GetTickCount64()-arena66.lastSpawn<(uint64_t)arenaPolicy66->spawnGapMs)return;
 if(!arenaSpawn66()){arenaCleanup66();arenaNotice66("Arena aborted: native creation failed; owned opponents removed.");return;}
 if(arena66.next==arena66.total)arenaNotice66(arena66.pilot?"Arena pilot ready: one Material Ronin and one Spectral V-Wraith.":"Arena ready: 14 Material and 4 Spectral opponents. Shift+F11 clears.");
}
static bool arenaPrepare66(void){
 arenaLookupNative66=(ArenaLookup66)(base+arenaPolicy66->lookupRva);arenaBirthNative66=(ArenaBirth66)(base+arenaPolicy66->birthRva);arenaRemoveNative66=(ArenaRemove66)(base+arenaPolicy66->removeRva);arenaResolveNative66=(ArenaResolve66)(base+arenaPolicy66->resolveAnimationsRva);
 static const unsigned char init[]={0x40,0x53,0x48,0x83,0xec,0x20,0x48,0x8b,0x41,0x30};
 static const unsigned char birth[]={0x48,0x89,0x5c,0x24,0x08,0x48,0x89,0x6c,0x24,0x10};
 static const unsigned char remove[]={0x40,0x53,0x41,0x56,0x48,0x83,0xec,0x28};
 return matches(arenaPolicy66->initRva,init,sizeof init)&&matches(arenaPolicy66->birthRva,birth,sizeof birth)&&matches(arenaPolicy66->removeRva,remove,sizeof remove)&&
  MH_CreateHook((void*)(base+arenaPolicy66->initRva),arenaInit66,(void**)&arenaOriginalInit66)==MH_OK;
}
