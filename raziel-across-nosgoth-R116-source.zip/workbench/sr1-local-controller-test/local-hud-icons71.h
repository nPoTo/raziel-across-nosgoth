// SPDX-License-Identifier: GPL-3.0-or-later
#pragma once
static void localHudIconPoint71(uint32_t id,float centerX,float centerY,float *x,float *y){
 const Sheet_sr1HudIcons71 *p=&sheet_sr1HudIcons71_all_selected_reaver_symbols;
 if(id<(uint32_t)p->firstTexture||id>(uint32_t)p->lastTexture||p->quarterTurns!=-1)return;
 // HUD pixels use +Y down. A screen-space CCW quarter turn maps right to up.
 const float dx=*x-centerX,dy=*y-centerY;*x=centerX+dy;*y=centerY-dx;
}
