// SPDX-License-Identifier: GPL-3.0-or-later
#pragma once
#include "local-damage61.h"
static unsigned localChargeGlyph48(unsigned form){return c5GlyphFromForm(form);}
static bool localChargePulse48(const Sr1LocalFrame *f,uintptr_t actor,unsigned form,uint64_t now){
 uintptr_t glyph=0,object=0,config=0,list=0,node=0;uint32_t count=0;int16_t root[3],range=(int16_t)sheet_sr1Combat48_combat_charge.spectralRadius;
 if(!readAt(base+LOCAL_GLYPH48_RVA,&glyph,8)||!glyph||!readAt(actor+0x9c,root,6))return false;
 if(
#ifdef SR1_LOCAL_COMBAT54
 true
#else
 form!=1
#endif
 ){if(!readAt(glyph+0x30,&object,8)||!object||!readAt(object+0x28,&config,8)||!config||
    !readAt(config+0xa+2*5,&range,2)||range<=0)return false;}
 if(!readAt(base+contactPolicy->listRva,&list,8)||!list||!readAt(list,&count,4)||!count||count>512||!readAt(list+8,&node,8))return false;
 uintptr_t candidates[512],previous=0;unsigned found=0;bool sourceFound=false;
 while(count--){uintptr_t next=0,back=0;if(!node||!readAt(node+0x10,&next,8)||!readAt(node+0x18,&back,8)||back!=previous)return false;
  if(node==actor)sourceFound=true;else candidates[found++]=node;previous=node;node=next;}
 if(node||!sourceFound)return false;
 unsigned hits=0;const int amount=form==1?sheet_sr1Combat48_combat_charge.spectralPulseDamage:form==2?sheet_sr1Combat48_combat_charge.basePulseDamage:sheet_sr1Combat48_combat_charge.spiritPulseDamage;
#ifdef SR1_LOCAL_COMBAT54
 unsigned seen54=0,realm54=0,allegiance54=0,range54=0,terrain54=0,damage54=0;
#endif
 const uint32_t playerClass=(uint32_t)((QueryInstance)(base+signals->queryRva))(actor,1);
 if(!playerClass)return false;
 for(unsigned i=0;i<found;i++){
  LocalTarget before,after;int16_t point[3];uintptr_t data=0,attributes=0,allegiances=0;uint32_t type=0,enemies=0;
  if(!localReadContactTarget(candidates[i],f->worldGeneration,&before)||!readAt(before.actor+0x9c,point,6)||
   !readAt(before.actor+0x40,&data,8)||!data||!readAt(data+0x20,&type,4))continue;
#ifdef SR1_LOCAL_COMBAT54
  seen54++;
#endif
  if((form==1)!=(type==2050u||type==4098u)){
#ifdef SR1_LOCAL_COMBAT54
   realm54++;
#endif
   continue;}
  if(!readAt(before.state+0x280,&attributes,8)||!attributes||!readAt(attributes+0x18,&allegiances,8)||!allegiances||
   !readAt(allegiances,&enemies,4)||!(enemies&playerClass)){
#ifdef SR1_LOCAL_COMBAT54
   allegiance54++;
#endif
   continue;}
  int64_t distance=0;for(unsigned k=0;k<3;k++){int64_t d=(int)point[k]-root[k];distance+=d*d;}if(distance>(int64_t)range*range){
#ifdef SR1_LOCAL_COMBAT54
   range54++;
   record("defiance-pulse-target form=%u target=%u reason=range distance=%.1f radius=%d hp=%d",form,before.generation,sqrt((double)distance),range,before.hp);
#endif
   continue;}
  const float sight[3]={root[0],root[1],root[2]+128.f};point[2]+=128;
  if(!localNativeLineClear(actor,f->worldGeneration,sight,point)){
#ifdef SR1_LOCAL_COMBAT54
   terrain54++;
   record("defiance-pulse-target form=%u target=%u reason=terrain distance=%.1f radius=%d hp=%d",form,before.generation,sqrt((double)distance),range,before.hp);
#endif
   continue;}
  int adjusted114=amount;
#ifdef SR1_BOSS_KAIN93
  adjusted114=kainPulse114(before.actor,amount);
#endif
  const int result=adjusted114>0?originalLocalEnemyDamage(before.actor,adjusted114,(uint32_t)contactPolicy->damageKind):0;
#ifdef SR1_LOCAL_COMBAT54
  damage54++;
  const bool current=localReadContactTarget(before.actor,f->worldGeneration,&after)&&after.generation==before.generation&&after.state==before.state;
  record("defiance-pulse-target form=%u target=%u reason=native-damage distance=%.1f radius=%d amount=%d hp=%d/%d result=%d current=%u",form,before.generation,sqrt((double)distance),range,adjusted114,before.hp,current?after.hp:-1,result,current);
#endif
  if(localReadContactTarget(before.actor,f->worldGeneration,&after)&&after.generation==before.generation&&after.state==before.state&&
    localDamageHealth61(before.hp,after.hp,result)){hits++;
#ifdef SR1_LOCAL_COMBAT55
      localSpellPause55(f,before.actor,before.generation,before.state,before.hp,after.hp,form,now);
#endif
#ifdef SR1_LOCAL_COMBAT52
      localImpactTarget52(f,actor,now,before.actor,after.generation,form);
      localFxTarget52(f,actor,now,form,before.actor,after.generation,false);
#else
      localImpactQueue48(f,actor,now,point,form);
#ifdef SR1_LOCAL_COMBAT51
      localFxQueue51(f,actor,now,form,point,after.generation,false,true,false);
#endif
#endif
    }
 }
#ifdef SR1_LOCAL_COMBAT54
 record("defiance-pulse-audit form=%u seen=%u realm-refused=%u allegiance-refused=%u range-refused=%u terrain-refused=%u native-calls=%u confirmed=%u",form,seen54,realm54,allegiance54,range54,terrain54,damage54,hits);
#endif
 record("defiance-charge-pulse form=%u radius=%d hits=%u",form,range,hits);return true;
}
static void localChargeCommit48(const Sr1LocalFrame *f,uintptr_t actor,uint64_t now){
 if(!localCast48.casting)return;
 const LocalChargeView48 cast=localCast48;
 const Sheet_sr1ChargeClip48 *clip=sheet_sr1ChargeClip48_rows[cast.form-1];
 const uint64_t age=now>=cast.start?now-cast.start:UINT64_MAX;
 if(!sameLocalAction(&cast.owner,f,actor,now,5000)||!f->ready||!f->renderBlend||!f->grounded||localPhysicalCarry(actor)){
  localCast48=(LocalChargeView48){0};localChargePublish48(f,actor,now);record("defiance-charge-interrupt form=%u",cast.form);return;
 }
#ifdef SR1_LOCAL_COMBAT51
 localCastAudio51(f,actor,cast.form,cast.start,now);
#endif
 if(!localCastCommitted48&&age>=(uint64_t)clip->releaseClock/3u){
  uintptr_t glyph=0,ring=0;uint16_t effect=0,armed=0;bool committed=false;
  if(localMeter48.charge==100&&localCurrentForm(f->realm)==cast.form&&
   readAt(base+LOCAL_GLYPH48_RVA,&glyph,8)&&glyph&&readAt(base+sheet_sr1Combat48_combat_charge.ringRva,&ring,8)&&
   readAt(base+sheet_sr1Combat48_combat_charge.effectIdRva,&effect,2)&&readAt(base+sheet_sr1Combat48_combat_charge.armedRva,&armed,2)&&!ring&&!effect&&!armed){
    const unsigned spell=localChargeGlyph48(cast.form);
    if(spell){uint32_t powers=0;if(readAt(base+acquisition->abilitiesRva,&powers,4)&&(powers&(1u<<(17+spell)))&&
      verifyDrawBlock(sheet_sr1Combat48_combat_charge.glyphEffectRva,sheet_sr1Combat48_combat_charge.glyphEffectBytes,LOCAL_GLYPH48_SHA)){
#ifdef SR1_LOCAL_COMBAT55
       localSpellBegin55(f,spell,now);
#endif
       ((void(*)(uintptr_t,int32_t))(base+sheet_sr1Combat48_combat_charge.glyphEffectRva))(glyph,(int32_t)spell);
       uint16_t made=0;committed=readAt(base+sheet_sr1Combat48_combat_charge.ringRva,&ring,8)&&ring&&readAt(base+sheet_sr1Combat48_combat_charge.effectIdRva,&made,2)&&made==spell;
#ifdef SR1_LOCAL_COMBAT55
       localSpellCommit55(committed,ring);
#endif
    }}else committed=localChargePulse48(f,actor,cast.form,now);
  }
  localCastCommitted48=true;if(committed)localMeter48.charge=0;
#ifdef SR1_LOCAL_COMBAT51
  if(committed)localFxQueue51(f,actor,now,cast.form,NULL,0,true,false,false);
#endif
  record("defiance-charge-effect form=%u glyph=%u committed=%u age=%llu meter=%u",cast.form,localChargeGlyph48(cast.form),committed,(unsigned long long)age,localMeter48.charge);
 }
 if(age>=(uint64_t)clip->clipKeys*1000u/30u+100u)localCast48=(LocalChargeView48){0};
 localChargePublish48(f,actor,now);
}
