// SPDX-License-Identifier: GPL-3.0-or-later
#pragma once
// Observe the original composed face hold before utility/native-context returns.
// Never change native pad bits, targets, AI or a finisher/rotor's action-owned yaw.
static void localTargetBoundary72(const NativePad *out,const Sr1LocalFrame *frame,uint64_t now){
 uint32_t face=0;const bool sampled=readAt(base+sheet_sr1StandaloneBlade_standalone_default_blade.combatMaskRva,&face,4)&&face;
 const bool live=frame->ready&&frame->renderBlend&&!localPhysicalCarry(player);
 if(live&&sampled&&(out->held&face))return;
 const LocalTargetLock47 before=localTargetSnapshot47(false);
 localTargetInput47(frame,player,false,now);
 AcquireSRWLockExclusive(&localCombatInputLock);
 const bool held=combatInput.guardHeld;
 if(held){combatInput.guardAtEdge=localGuardWeight(&combatInput,now);combatInput.guard=localActionOwner(frame,player,now);combatInput.guardHeld=false;}
 combatInput.guardSpeed=0;combatInput.guardDirectional=false;combatInput.guardSample=now;
 ReleaseSRWLockExclusive(&localCombatInputLock);
 guardFacing=(LocalActionOwner){0};
 if(before.held||held)record("defiance-target-release72 reason=%s target=%u",!live?"context":!sampled?"unreadable":"button-up",before.generation);
}
