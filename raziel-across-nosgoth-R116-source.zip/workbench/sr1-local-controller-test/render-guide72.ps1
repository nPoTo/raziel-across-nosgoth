#requires -Version 7.0
# SPDX-License-Identifier: GPL-3.0-or-later
param([switch]$GuideOnly)
$ErrorActionPreference='Stop'
Add-Type -AssemblyName System.Drawing.Common
$assets=[IO.Path]::GetFullPath((Join-Path $PSScriptRoot '../desktop-sr1-linked-r1/assets'))

function Color([string]$hex) { [Drawing.ColorTranslator]::FromHtml($hex) }
function Fill($g,[string]$hex,[int]$x,[int]$y,[int]$w,[int]$h) {
    $brush=[Drawing.SolidBrush]::new((Color $hex))
    try { $g.FillRectangle($brush,$x,$y,$w,$h) } finally { $brush.Dispose() }
}
function Label($g,[string]$content,[int]$x,[int]$y,[int]$size,[string]$hex,[switch]$Bold) {
    $style=if($Bold){[Drawing.FontStyle]::Bold}else{[Drawing.FontStyle]::Regular}
    $font=[Drawing.Font]::new('Segoe UI',$size,$style,[Drawing.GraphicsUnit]::Pixel)
    $brush=[Drawing.SolidBrush]::new((Color $hex))
    try { $g.DrawString($content,$font,$brush,[single]$x,[single]$y) }
    finally { $font.Dispose(); $brush.Dispose() }
}

$canvas=[Drawing.Bitmap]::new(1440,900)
$g=[Drawing.Graphics]::FromImage($canvas)
$art=[Drawing.Image]::FromFile((Join-Path $assets 'launch-loading.png'))
try {
    $g.TextRenderingHint=[Drawing.Text.TextRenderingHint]::AntiAliasGridFit
    $g.InterpolationMode=[Drawing.Drawing2D.InterpolationMode]::HighQualityBicubic
    $bg=[Drawing.Drawing2D.LinearGradientBrush]::new(
        [Drawing.Rectangle]::new(0,0,1440,900),(Color '#101c29'),(Color '#080c13'),35)
    try { $g.FillRectangle($bg,0,0,1440,900) } finally { $bg.Dispose() }
    Fill $g '#61cbb6' 0 0 1440 3
    Label $g 'SOUL REAVER 1 × DEFIANCE' 40 23 19 '#d9b978' -Bold
    Label $g 'Field Guide' 38 43 49 '#f5faf9' -Bold
    Label $g 'Play the SR1 story with your save and its unlocked Reaver forms.' 43 103 18 '#bbcad5'
    Label $g 'F6 switches the base Reaver on or off during ordinary grounded gameplay.' 43 129 18 '#bbcad5'
    Fill $g '#415164' 1072 24 328 186
    $g.DrawImage($art,1074,26,324,182)

    Fill $g '#182533' 40 163 998 112
    Label $g 'HOTKEYS' 54 171 15 '#77dcca' -Bold
    $hotkeys=@(
        @('F6','Toggle base Reaver on / off'), @('F7','Open/close guide'),
        @('F9','Toggle all-powers preset'), @('F10','Toggle mod in a loaded save')
    )
    for($i=0;$i -lt $hotkeys.Count;$i++) {
        $x=57+($i % 2)*487
        $y=196+[Math]::Floor($i/2)*29
        Fill $g '#263b49' $x $y 48 25
        Label $g $hotkeys[$i][0] ($x+5) ($y+1) 16 '#b4f2e6' -Bold
        Label $g $hotkeys[$i][1] ($x+61) ($y+1) 17 '#e7f0f5'
    }
    Label $g 'Wait for resources to load. F10 switches the mod on or off; F7 opens this guide.' 57 253 15 '#bbcad5'
    Label $g 'F9 grants all Glyphs and Warp Gates,' 1074 214 15 '#bbcad5'
    Label $g 'plus maximum health and mana.' 1074 233 15 '#bbcad5'
    Label $g 'Tray' 1074 253 15 '#d9b978' -Bold
    $trayIcons=@(
        @{File='reaver-light.ico';Text='On';X=1124},
        @{File='reaver-dark.ico';Text='Off';X=1209}
    )
    foreach($entry in $trayIcons) {
        $icon=[Drawing.Icon]::new((Join-Path $assets $entry.File),32,32)
        try { $g.DrawIcon($icon,[Drawing.Rectangle]::new($entry.X,250,22,22)) }
        finally { $icon.Dispose() }
        Label $g $entry.Text ($entry.X+26) 253 15 '#e7f0f5' -Bold
    }

    Fill $g '#182533' 40 285 1360 53
    Label $g 'DEBUG MENU' 57 294 15 '#77dcca' -Bold
    Label $g 'Controller   B + X' 212 292 17 '#e7f0f5' -Bold
    Label $g 'Keyboard / mouse   E + Left Click' 458 292 17 '#e7f0f5' -Bold
    Label $g 'The chord switches the mod off and opens native Debug. Close it, then use F10 to resume.' 57 316 15 '#bbcad5'

    Fill $g '#162331' 40 350 775 430
    Label $g 'ACTION · MOD ON' 57 361 15 '#77dcca' -Bold
    Label $g 'CONTROLLER' 380 361 15 '#77dcca' -Bold
    Label $g 'KEYBOARD / MOUSE' 592 361 15 '#77dcca' -Bold
    $controls=@(
        @('Move','Left stick','WASD'),
        @('Look / rotate camera','Right stick','Move mouse'),
        @('Jump / swim','A','Space'),
        @('Crouch','Hold LT','Hold Left Ctrl'),
        @('High jump','LT + A','Left Ctrl + Space'),
        @('Glide while airborne','Hold A','Hold Space'),
        @('Normal attack / combo','X','Left click'),
        @('Launcher / air slam','Y','Right click'),
        @('Lock onto enemy','Hold LB','Hold Left Shift'),
        @('Directional dodge','LB + A + direction','Shift + Space + direction'),
        @('Feed / finish stunned enemy','RB (hold to feed)','E (hold to feed)'),
        @('Telekinesis','B','F'),
        @('Release full Reaver charge','Hold X for 1 s','Hold left click for 1 s'),
        @('Cycle unlocked Reavers','D-pad Left / Right','Wheel, Z / X'),
        @('Select unlocked Reaver','—','1–8 / numpad'),
        @('Map','Press right stick (R3)','M'),
        @('Pause','Menu (Start)','Esc')
    )
    for($i=0;$i -lt $controls.Count;$i++) {
        $y=386+$i*21
        Fill $g '#293847' 58 ($y+20) 738 1
        Label $g $controls[$i][0] 58 $y 16 '#e7f0f5'
        Label $g $controls[$i][1] 380 $y 16 '#e7f0f5'
        Label $g $controls[$i][2] 592 $y 16 '#e7f0f5'
    }
    Label $g "Held weapons and special traversal use SR1's native controls." 58 751 15 '#bbcad5'

    Fill $g '#162331' 835 350 565 181
    Label $g 'CHANGE REALMS & OPEN GLYPHS' 854 361 15 '#77dcca' -Bold
    Label $g 'Quick shift' 853 388 17 '#f5faf9' -Bold
    Label $g 'Controller   D-pad Down → release → A' 853 413 16 '#e7f0f5'
    Label $g 'Keyboard   C → release → Space' 853 437 16 '#e7f0f5'
    Label $g 'C opens the native Glyph menu. Realm changes keep SR1 requirements.' 853 466 16 '#e7f0f5'
    Label $g 'To return to Material, stand on a usable SR1 portal.' 853 491 15 '#bbcad5'
    Label $g 'Physical weapons and story interactions keep native controls.' 853 510 15 '#bbcad5'

    Fill $g '#162331' 835 541 565 239
    Label $g 'DAMAGE' 854 553 15 '#77dcca' -Bold
    $damage=@(
        @('Telekinesis','1,000'),
        @('Standard Reaver','500 base'),
        @('Each other unlocked standard form','+300'),
        @('Spirit Reaver','5,000'),
        @('Helicopter contact','Normal strike DMG'),
        @('Charged spell','Full meter'),
        @('Spell blocks regeneration','8 seconds')
    )
    for($i=0;$i -lt $damage.Count;$i++) {
        $y=579+$i*26
        Fill $g '#293847' 854 ($y+22) 527 1
        Label $g $damage[$i][0] 853 $y 16 '#e7f0f5'
        Label $g $damage[$i][1] 1213 $y 16 '#f1d7a1' -Bold
    }

    Fill $g '#302921' 40 795 1360 84
    Fill $g '#e2b674' 40 795 4 84
    Label $g 'PLAYING WITH THE MOD' 56 803 20 '#ffe0a7' -Bold
    Label $g 'Defiance does not need to be running. Keep both games installed so their resources can be read.' 57 832 17 '#f5e9d6'
    Label $g 'If a problem occurs, use F10 to switch off. Back up saves before using F6, F9 or Debug.' 57 854 17 '#f5e9d6'
    $canvas.Save((Join-Path $PSScriptRoot 'build/defiance-combat-r60/guide72.png'),[Drawing.Imaging.ImageFormat]::Png)
} finally {
    $art.Dispose()
    $g.Dispose()
    $canvas.Dispose()
}

