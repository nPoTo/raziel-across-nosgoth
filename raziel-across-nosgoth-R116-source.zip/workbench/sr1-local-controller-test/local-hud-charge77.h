// SPDX-License-Identifier: GPL-3.0-or-later
#pragma once
static void localHudPoint77(const unsigned char *q,float u,float v,float point[2]){
 for(unsigned k=0;k<2;k++)point[k]=(1-v)*((1-u)*hudF32(q+16+k*4)+u*hudF32(q+24+k*4))+v*((1-u)*hudF32(q+40+k*4)+u*hudF32(q+32+k*4));
}
static void localHudLine77(const float a[2],const float b[2],float width,uint32_t rgb,float alpha,unsigned slot,const GLint viewport[4]){
 const float dx=b[0]-a[0],dy=b[1]-a[1],length=hypotf(dx,dy);if(length<.0001f)return;
 const float nx=-dy*width/length,ny=dx*width/length;
 unsigned char q[80]={0};const uint32_t blend=1;memcpy(q+4,&blend,4);
 const float xy[]={a[0]+nx,a[1]+ny,b[0]+nx,b[1]+ny,b[0]-nx,b[1]-ny,a[0]-nx,a[1]-ny},uv[]={0,0,1,1};
 const float color[]={((rgb>>16)&255)/255.f,((rgb>>8)&255)/255.f,(rgb&255)/255.f,alpha};
 memcpy(q+16,xy,sizeof xy);memcpy(q+48,uv,sizeof uv);memcpy(q+64,color,sizeof color);hudDrawQuad(&localHud45GL,q,slot,viewport);
}
static void localHudCoil77(const unsigned char *packet,const GLint viewport[4],unsigned form){
 const LocalChargeView48 charge=localChargeRead48();if(!charge.charge||charge.charge>100)return;
 static const unsigned char white[]={255,255,255,255};const unsigned slot=HUD_MAX_TEXTURES-1;
 if(!localHud45GL.textures[slot]&&!reaverGLTexture(&localHud45GL,slot,1,1,white,false,false))return;
 const unsigned char *blade=packet+96;const uint32_t rgb=localSwordTint75(form);
 const float phase=GetTickCount64()*.008f,reach=.6f*charge.charge/100.f;
 const unsigned segments=40;const float turns=sheet_sr1Combat77_authored_hand_and_charge.coilTurns;
 for(unsigned strand=0;strand<2;strand++){
  float previous[2]={0};
  for(unsigned i=0;i<=segments;i++){
   const float t=(float)i/segments,angle=phase+6.28318530718f*turns*t+strand*3.14159265359f;
   const float radius=.11f*(1-t)*sinf(3.14159265359f*fminf(1,t*4));
   float point[2];localHudPoint77(blade,.05f+reach*t,.33f+radius*cosf(angle),point);
   if(i){const float depth=.55f+.35f*sinf(angle);localHudLine77(previous,point,.7f,rgb,depth,slot,viewport);localHudLine77(previous,point,.2f,0xffffff,.65f*depth,slot,viewport);}
   memcpy(previous,point,sizeof point);
  }
 }
}
static void localHudEyes77(const unsigned char *packet,const GLint viewport[4],unsigned form){
 if(localChargeRead48().charge!=100)return;
 const unsigned slot=HUD_MAX_TEXTURES-2;const Sheet_sr1Combat77 *p=&sheet_sr1Combat77_authored_hand_and_charge;
 if(!localHud45GL.textures[slot]){
  unsigned char mask[16*16*4];for(unsigned y=0;y<16;y++)for(unsigned x=0;x<16;x++){
   const float d=hypotf((x-7.5f)/7.5f,(y-7.5f)/7.5f);const unsigned i=4*(y*16+x);
   mask[i]=mask[i+1]=mask[i+2]=255;mask[i+3]=(unsigned char)(255.f*fmaxf(0,fminf(1,(1-d)*3)));
  }
  if(!reaverGLTexture(&localHud45GL,slot,16,16,mask,true,false))return;
 }
 const unsigned char *blade=packet+96;const float u0=hudF32(blade+48),v0=hudF32(blade+52),du=hudF32(blade+56)-u0,dv=hudF32(blade+60)-v0;
 if(fabsf(du)<.00001f||fabsf(dv)<.00001f)return;
 for(unsigned eye=0;eye<2;eye++){
  const float x=eye?p->eye1X:p->eye0X,y=eye?p->eye1Y:p->eye0Y;
  const float u[2]={((x-p->eyeRadiusX)/1024.f-u0)/du,((x+p->eyeRadiusX)/1024.f-u0)/du};
  const float v[2]={((y-p->eyeRadiusY)/256.f-v0)/dv,((y+p->eyeRadiusY)/256.f-v0)/dv};
  unsigned char q[80]={0};const uint32_t blend=1;memcpy(q+4,&blend,4);
  for(unsigned corner=0;corner<4;corner++){float point[2];localHudPoint77(blade,u[corner==1||corner==2],v[corner>=2],point);memcpy(q+16+corner*8,point,sizeof point);}
  const float uv[]={0,0,1,1};memcpy(q+48,uv,sizeof uv);const uint32_t rgb=localSwordTint75(form);
  const float color[]={((rgb>>16)&255)/255.f,((rgb>>8)&255)/255.f,(rgb&255)/255.f,1};memcpy(q+64,color,sizeof color);
  hudDrawQuad(&localHud45GL,q,slot,viewport);
 }
}
