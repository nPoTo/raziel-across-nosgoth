// SPDX-License-Identifier: GPL-3.0-or-later
#pragma once
// Released0.2 trail/switch geometry, using its untextured fallback. Stored trail
// vertices stay in world space and are reprojected through the current hand.
static void localSwordFxDraw73(uintptr_t actor,const float palm[16],const float mvp[16],float tip,float reveal){
 const Sr1LocalFrame f=readFrame();const uint64_t now=GetTickCount64();const unsigned form=localCurrentForm(f.realm);
#ifdef SR1_LOCAL_COMBAT75
 const uint64_t inputFlash=localSwitchTime75(&f,actor,form,now);
 const bool visible=reveal>0 || inputFlash;
#else
 const bool visible=reveal>0;
#endif
 if(!f.ready||!f.renderBlend||actor!=player||!form||localPhysicalCarry(actor)||!isfinite(tip)||tip<=0||!visible){memset(&localSword73,0,sizeof(localSword73));return;}
 float position[3],heel[3],end[3];for(unsigned k=0;k<3;k++){position[k]=palm[12+k];end[k]=position[k]+palm[8+k]*tip;heel[k]=position[k]+.12f*(end[k]-position[k]);}
 LocalVictimAttack attack=LOCAL_VICTIM_NO_ACTION;const bool swing=localStrikeContactAction(&f,actor,now,&attack).tick!=0;
#ifdef SR1_LOCAL_COMBAT75
 if(localSwordSession75!=f.session){memset(&localSword73,0,sizeof localSword73);localSwordSession75=f.session;}
#endif
 localSwordUpdate73(&localSword73,localActionOwner(&f,actor,now),(uintptr_t)wglGetCurrentContext(),form,position,heel,end,swing,localFullCharge51(&f,actor,now),reveal);
#ifdef SR1_LOCAL_COMBAT75
 if(inputFlash)localSword73.flash=inputFlash;
#endif
 if(!c2ImpactInit())return;const Sheet_sr1SwordLight73*p=&sheet_sr1SwordLight73_swing_switch_world_light;const uint32_t tint=
#ifdef SR1_LOCAL_COMBAT75
  localSwordTint75(form);
#else
  localFxColor51(form);
#endif
#ifdef SR1_LOCAL_COMBAT74
 const Sheet_sr1SwordColor74*colorPolicy=&sheet_sr1SwordColor74_saturated_shadow;const unsigned blend=(unsigned)colorPolicy->blend;
#else
 const float gain=localSwordGain73(&localSword73);const unsigned blend=2;
#endif
 ReaverGLVertex vertices[24]={0};uint16_t indices[66]={0};unsigned count=0,indexCount=0;
 for(unsigned i=0;i<localSword73.count;i++){const LocalSwordTrail73*point=&localSword73.trail[(localSword73.cursor+11-i)%12];if(now<point->tick||now-point->tick>=(uint64_t)p->trailMs)break;
  const float fade=1-(float)(now-point->tick)/(float)p->trailMs;const float*ends[2]={point->heel,point->tip};
  for(unsigned j=0;j<2;j++){ReaverGLVertex*v=&vertices[count++];for(unsigned axis=0;axis<3;axis++)for(unsigned k=0;k<3;k++)v->position[axis]+=palm[axis*4+k]*(ends[j][k]-palm[12+k]);v->uv[0]=(float)j;v->uv[1]=.5f;
#ifdef SR1_LOCAL_COMBAT74
   localSwordColor74(tint,localSword73.charged,fade*(j?colorPolicy->trailTipAlphaPermille:colorPolicy->trailHeelAlphaPermille)/1000.f*reveal,0,v->rgba);
#else
   c2ImpactColor(tint,fade*(j?.86f:.16f)*reveal,v->rgba);for(unsigned k=0;k<3;k++)v->rgba[k]*=p->trailGainPermille/1000.f*gain;
#endif
  }
  if(i){const uint16_t e=(uint16_t)(count-1),strip[]={e-3,e-2,e-1,e-2,e,e-1};memcpy(indices+indexCount,strip,sizeof strip);indexCount+=6;}
 }
#ifdef SR1_LOCAL_COMBAT75
 static _Thread_local bool drewTrail75;
 const bool renderedTrail75=indexCount&&reaverGLDraw(&c2ImpactGl,vertices,count,indices,indexCount,4,blend,mvp,0,-1);
 if(renderedTrail75&&!drewTrail75)record("reaver-trail75 form=%u rgb=%06x points=%u",form,tint,count/2);
 drewTrail75=renderedTrail75;
#else
 if(indexCount)reaverGLDraw(&c2ImpactGl,vertices,count,indices,indexCount,4,blend,mvp,0,-1);
#endif
 if(localSword73.flash&&now>=localSword73.flash&&now-localSword73.flash<(uint64_t)p->flashMs){float center[3]={0},right[3],up[3],color[4];if(!c2ImpactBillboard(mvp,0,center,right,up))return;
  const float life=1-(float)(now-localSword73.flash)/(float)p->flashMs;
#ifdef SR1_LOCAL_COMBAT74
  const float flashVisibility=
#ifdef SR1_LOCAL_COMBAT75
   inputFlash?1.f:reveal;
#else
   reveal;
#endif
  localSwordColor74(tint,localSword73.charged,.625f*life*flashVisibility,1,color);
#else
  c2ImpactColor(tint,.625f*life*reveal,color);for(unsigned k=0;k<3;k++)color[k]*=p->flashGainPermille/1000.f*gain;
#endif
  ReaverGLVertex flash[9]={0};uint16_t order[24]={0};memcpy(flash[0].rgba,color,16);
  for(unsigned i=0;i<8;i++){const float angle=.78539816339f*i;for(unsigned k=0;k<3;k++)flash[i+1].position[k]=cosf(angle)*(float)p->flashRadius*right[k]+sinf(angle)*(float)p->flashRadius*up[k];memcpy(flash[i+1].rgba,color,16);order[i*3+1]=(uint16_t)(i+1);order[i*3+2]=(uint16_t)((i+1)%8+1);}
#ifdef SR1_LOCAL_COMBAT74
  for(unsigned i=1;i<9;i++)flash[i].rgba[3]=0;
#endif
#ifdef SR1_LOCAL_COMBAT75
  static _Thread_local uint64_t flashReported75;
  if(reaverGLDraw(&c2ImpactGl,flash,9,order,24,4,blend,mvp,0,-1)&&flashReported75!=localSword73.flash){
   flashReported75=localSword73.flash;record("reaver-flash75 form=%u rgb=%06x",form,tint);
  }
#else
  reaverGLDraw(&c2ImpactGl,flash,9,order,24,4,blend,mvp,0,-1);
#endif
 }
 static uint32_t priorForm;static bool priorFull;if(priorForm!=form||priorFull!=(localSword73.charged>.99f)){priorForm=form;priorFull=localSword73.charged>.99f;
#ifdef SR1_LOCAL_COMBAT74
  record("reaver-color74 form=%u full=%u trail=%u switch=%u alpha-blend=%u",form,priorFull,count/2,localSword73.flash&&now-localSword73.flash<(uint64_t)p->flashMs,blend);
#else
  record("reaver-light73 form=%u full=%u trail=%u switch=%u gain=%.2f",form,priorFull,count/2,localSword73.flash&&now-localSword73.flash<(uint64_t)p->flashMs,gain);
#endif
 }
}
