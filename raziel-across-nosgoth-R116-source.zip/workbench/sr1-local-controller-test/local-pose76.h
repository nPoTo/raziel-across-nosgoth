// SPDX-License-Identifier: GPL-3.0-or-later
#pragma once
// Pose-only rotations. Every descendant keeps its length and local orientation.
static bool localAimBone76(float pose[66][13],const int16_t parents[66],unsigned joint,unsigned child,const float to[3],float weight){
 if(joint>=66||child>=66||parents[child]!=(int)joint||!isfinite(weight)||weight<=0)return false;
 float a[3],b[3],axis[3],an=0,bn=0,dot=0;
 for(unsigned k=0;k<3;k++){a[k]=pose[child][10+k]-pose[joint][10+k];b[k]=to[k]-pose[joint][10+k];an+=a[k]*a[k];bn+=b[k]*b[k];}
 if(!isfinite(an)||!isfinite(bn)||an<.001f||bn<.001f)return false;
 an=sqrtf(an);bn=sqrtf(bn);for(unsigned k=0;k<3;k++){a[k]/=an;b[k]/=bn;dot+=a[k]*b[k];}
 axis[0]=a[1]*b[2]-a[2]*b[1];axis[1]=a[2]*b[0]-a[0]*b[2];axis[2]=a[0]*b[1]-a[1]*b[0];
 float n=hypotf(hypotf(axis[0],axis[1]),axis[2]);dot=fmaxf(-1,fminf(1,dot));
 if(n<.00001f){if(dot>0)return true;axis[0]=-a[1];axis[1]=a[0];axis[2]=0;n=hypotf(axis[0],axis[1]);if(n<.00001f){axis[0]=1;n=1;}}
 for(unsigned k=0;k<3;k++)axis[k]/=n;
 const float angle=acosf(dot)*fminf(1,weight),c=cosf(angle),s=sinf(angle),t=1-c,x=axis[0],y=axis[1],z=axis[2];
 const float r[9]={c+x*x*t,x*y*t-z*s,x*z*t+y*s,y*x*t+z*s,c+y*y*t,y*z*t-x*s,z*x*t-y*s,z*y*t+x*s,c+z*z*t};
 const float pivot[3]={pose[joint][10],pose[joint][11],pose[joint][12]};
 for(unsigned bone=0;bone<66;bone++){
  int ancestor=(int)bone;for(unsigned count=0;count<66&&ancestor>=0&&ancestor!=(int)joint;count++)ancestor=parents[ancestor];
  if(ancestor!=(int)joint)continue;
  float old[13];memcpy(old,pose[bone],sizeof old);
  for(unsigned row=0;row<3;row++){
   pose[bone][10+row]=pivot[row];for(unsigned k=0;k<3;k++)pose[bone][10+row]+=r[row*3+k]*(old[10+k]-pivot[k]);
   for(unsigned col=0;col<3;col++){pose[bone][row*3+col]=0;for(unsigned k=0;k<3;k++)pose[bone][row*3+col]+=r[row*3+k]*old[k*3+col];}
  }
 }return true;
}
static bool localThrustAim76(float pose[66][13],const int16_t parents[66],const float target[3],float weight){
 return localAimBone76(pose,parents,40,41,target,weight);
}
static void localGripFingers76(float pose[66][13],const int16_t parents[66],const float blade[16],float weight){
 for(unsigned finger=0;finger<4;finger++){
  const unsigned joint=42+2*finger,tip=joint+1;float target[3];
  for(unsigned k=0;k<3;k++)target[k]=blade[12+k]+blade[k]*((float)finger-1.5f)*3.5f-blade[4+k]*3.f-blade[8+k]*7.f;
  localAimBone76(pose,parents,joint,tip,target,weight);
 }
}
static float localFollowStep76(float nominal,float distance,float gap,float maxSpeed,uint64_t dt){
 if(!isfinite(nominal)||!isfinite(distance)||dt>150||!dt)return 0;
 const float correction=fmaxf(0,distance-gap);
 return fminf(fmaxf(nominal,correction),maxSpeed*(float)dt*.001f);
}
