// SPDX-License-Identifier: GPL-3.0-or-later
#pragma once
static uint32_t localReaverToggleBits70(uint32_t abilities){
 const Sheet_sr1KainReaver70 *p=&sheet_sr1KainReaver70_throne_and_reaver;
 return abilities&p->acquiredMask?abilities&~(uint32_t)p->reaverMask:abilities|(uint32_t)p->reaverMask;
}
