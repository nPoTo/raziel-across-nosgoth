// SPDX-License-Identifier: GPL-3.0-or-later
#pragma once
#ifdef SR1_LOCAL_COMBAT74
#include "local-sword-color74.h"
#endif
typedef struct{float heel[3],tip[3];uint64_t tick;} LocalSwordTrail73;
typedef struct{LocalActionOwner owner;uintptr_t context;uint32_t form;uint64_t flash,lastTrail;unsigned count,cursor;float position[3],reveal,charged;LocalSwordTrail73 trail[12];}LocalSwordLight73;
static _Thread_local LocalSwordLight73 localSword73;
#ifdef SR1_LOCAL_COMBAT75
static _Thread_local uint64_t localSwordSession75;
#endif
static bool localSwordSame73(const LocalActionOwner*a,const LocalActionOwner*b){return a->tick&&a->actor==b->actor&&a->generation==b->generation&&a->world==b->world&&a->realm==b->realm;}
static void localSwordUpdate73(LocalSwordLight73*s,LocalActionOwner owner,uintptr_t context,unsigned form,const float position[3],const float heel[3],const float tip[3],bool swing,bool full,float reveal){
 const Sheet_sr1SwordLight73*p=&sheet_sr1SwordLight73_swing_switch_world_light;
 if(!owner.tick||!owner.actor||!context||!form||form>9||!isfinite(reveal)||reveal<=0){memset(s,0,sizeof(*s));return;}
 for(unsigned k=0;k<3;k++)if(!isfinite(position[k])||!isfinite(heel[k])||!isfinite(tip[k])){memset(s,0,sizeof(*s));return;}
 const bool same=localSwordSame73(&s->owner,&owner)&&s->context==context&&owner.tick>=s->owner.tick&&owner.tick-s->owner.tick<=(uint64_t)p->sourceFreshMs;
 const uint64_t delta=same?owner.tick-s->owner.tick:0;
 if(!same)memset(s,0,sizeof(*s));else if(s->form!=form){s->flash=owner.tick;s->count=s->cursor=0;s->lastTrail=0;}
 const float step=(float)(delta>50?50:delta)/(float)p->chargeFadeMs;s->charged=fmaxf(0,fminf(1,s->charged+(full?step:-step)));
 s->owner=owner;s->context=context;s->form=form;s->reveal=fminf(1,reveal);memcpy(s->position,position,12);
 if(swing&&owner.tick!=s->lastTrail){if(!s->lastTrail||owner.tick<s->lastTrail||owner.tick-s->lastTrail>(uint64_t)p->trailGapMs)s->count=s->cursor=0;
  LocalSwordTrail73*point=&s->trail[s->cursor++%12];point->tick=owner.tick;memcpy(point->heel,heel,12);memcpy(point->tip,tip,12);if(s->count<12)s->count++;s->lastTrail=owner.tick;
 }
}
static float localSwordGain73(const LocalSwordLight73*s){return 1+s->charged*(sheet_sr1SwordLight73_swing_switch_world_light.fullGainPermille/1000.f-1);}
static bool localSwordCurrent73(const LocalSwordLight73*s,const Sr1LocalFrame*f,uintptr_t actor,uintptr_t context,unsigned form,uint64_t now){return f->ready&&f->renderBlend&&form&&s->form==form&&s->context==context&&s->reveal>0&&sameLocalAction(&s->owner,f,actor,now,sheet_sr1SwordLight73_swing_switch_world_light.sourceFreshMs);}
static bool localSwordNativeSlot73(const float position[4],const float color[4],const float nativeHand[3],uint32_t packed){
 bool unused=true;for(unsigned k=0;k<4;k++){if(!isfinite(position[k])||!isfinite(color[k]))return false;if(fabsf(color[k])>1e-6f)unused=false;}if(unused)return true;
 if(!packed||fabsf(position[3]-512)>.01f||fabsf(color[3])>1e-6f)return false;
 for(unsigned k=0;k<3;k++)if(!isfinite(nativeHand[k])||fabsf(position[k]-nativeHand[k])>.1f||fabsf(color[k]-((packed>>(8*k))&255)*4.f/255.f)>1e-5f)return false;
 return true;
}
