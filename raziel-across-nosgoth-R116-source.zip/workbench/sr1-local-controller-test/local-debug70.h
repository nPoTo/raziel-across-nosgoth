// SPDX-License-Identifier: GPL-3.0-or-later
#pragma once
#include "local-debug70-proof.h"
static struct {uintptr_t platform;uint64_t requested;bool owned,seen;} localDebug70;
static void localDebugRestore70(void){
 const Sheet_sr1Debug70 *p=&sheet_sr1Debug70_original_debug_entry;
 uintptr_t current=0;LONG value=0;
 if(localDebug70.owned&&readAt(base+p->platformRva,&current,8)&&current==localDebug70.platform&&
  readAt(current+p->allowedOffset,&value,4)&&value==1)
  InterlockedCompareExchange((volatile LONG*)(current+p->allowedOffset),0,1);
 memset(&localDebug70,0,sizeof localDebug70);
}
static void localDebugObserve70(void){
 if(!localDebug70.requested)return;
 const Sheet_sr1Debug70 *p=&sheet_sr1Debug70_original_debug_entry;
 uint16_t mode=0;uintptr_t root=0;
 if(!readAt(base+p->modeRva,&mode,2)||!readAt(base+p->rootRva,&root,8)){localDebugRestore70();return;}
 if(mode==p->openMode&&root){
  if(!localDebug70.seen){localDebug70.seen=true;record("portable-debug-menu70 event=opened native=1");}
 }else if(localDebug70.seen){record("portable-debug-menu70 event=closed native=1");localDebugRestore70();}
 else if(GetTickCount64()-localDebug70.requested>(uint64_t)p->timeoutMs){record("portable-debug-menu70 event=entry-refused native=1");localDebugRestore70();}
}
static bool localDebugInput70(NativePad *out){
 const Sheet_sr1Debug70 *p=&sheet_sr1Debug70_original_debug_entry;
 uint16_t mode=0;uintptr_t platform=0;LONG enabled=0;
 if(!verifyDrawBlock(p->proofRva,(DWORD)p->proofBytes,LOCAL_DEBUG70_SHA)||
  !readAt(base+p->modeRva,&mode,2)||(mode!=0&&mode!=p->openMode)||
  !readAt(base+p->platformRva,&platform,8)||!platform||
  !readAt(platform+p->allowedOffset,&enabled,4)||(enabled!=0&&enabled!=1))return false;
 if(!enabled){
  MEMORY_BASIC_INFORMATION region={0};const uintptr_t address=platform+p->allowedOffset;
  if(VirtualQuery((void*)address,&region,sizeof region)!=sizeof region||region.State!=MEM_COMMIT||
   !(region.Protect&(PAGE_READWRITE|PAGE_WRITECOPY|PAGE_EXECUTE_READWRITE|PAGE_EXECUTE_WRITECOPY)))return false;
  if(InterlockedCompareExchange((volatile LONG*)address,1,0)!=0)return false;
  localDebug70.platform=platform;localDebug70.owned=true;
 }
 // Use the original native entry/exit input, independent of the current binding
 // profile. Native SR1 owns mode, root-menu pointer and the complete menu lifetime.
 out->held=(out->held&~(uint32_t)p->directionMask)|(uint32_t)(p->heldMask|p->pressedMask);
 out->pressed=(out->pressed&~(uint32_t)p->directionMask)|(uint32_t)p->pressedMask;
 out->released&=~(uint32_t)(p->directionMask|p->heldMask|p->pressedMask);out->x=out->y=0;
 if(!localDebug70.requested)localDebug70.requested=GetTickCount64();
 record("portable-debug-menu70 event=request mode=%u native=1 owned-enable=%u",mode,localDebug70.owned);
 return true;
}
