// SPDX-License-Identifier: GPL-3.0-or-later
#pragma once
// Original0.2 native regen product boundary; keep stock rate/product outside the requested pause.
typedef struct{LocalActionOwner owner;uintptr_t target,state;uint32_t gen;uint64_t until;} LocalSpellLease55;
static _Thread_local LocalSpellLease55 localSpellLeases55[512];static _Thread_local unsigned localSpellCursor55;
static _Thread_local struct{LocalActionOwner owner;unsigned glyph;uintptr_t ring;bool dispatch;}localSpellCast55;
static void*localRegenOriginal55 __attribute__((used));
#ifdef SR1_BOSS_KAIN93
static bool kainNoRegen93(uintptr_t actor);
#endif
static bool localSpellHealth55(uintptr_t actor,uint32_t world,LocalSpellHealth55*out){
 LocalTarget target;if(!localReadContactTarget(actor,world,&target))return false;
 *out=(LocalSpellHealth55){target.actor,target.state,target.generation,target.hp};return true;
}
static void localSpellPause55(const Sr1LocalFrame*f,uintptr_t target,uint32_t gen,uintptr_t state,int16_t before,int16_t after,unsigned effect,uint64_t now){
 if(!target||!gen||!state||before<=0||after<0||after>=before||!f->ready||generation(target)!=gen)return;
 unsigned at=512;for(unsigned i=0;i<512;i++)if(localSpellLeases55[i].target==target&&localSpellLeases55[i].gen==gen){at=i;break;}
 if(at==512)at=localSpellCursor55++%512;
 localSpellLeases55[at]=(LocalSpellLease55){.owner=localActionOwner(f,player,now),.target=target,.state=state,.gen=gen,.until=now+(uint64_t)sheet_sr1Combat55_finish_contact_regen.regenMs};
 record("defiance-spell-regen-pause target=%u effect=%u hp=%d/%d start=%llu until=%llu",gen,effect,before,after,(unsigned long long)now,(unsigned long long)localSpellLeases55[at].until);
}
static void localSpellWatch55(const Sr1LocalFrame*f,uint64_t now){
 if(!localSpellCast55.owner.tick||localSpellCast55.dispatch)return;uintptr_t ring=0;uint16_t effect=0;
 if(!sameLocalAction(&localSpellCast55.owner,f,player,now,UINT64_MAX)||!readAt(base+sheet_sr1Combat48_combat_charge.ringRva,&ring,8)||
  !ring||ring!=localSpellCast55.ring||!readAt(base+sheet_sr1Combat48_combat_charge.effectIdRva,&effect,2)||effect!=localSpellCast55.glyph)
  memset(&localSpellCast55,0,sizeof localSpellCast55);
}
static void localSpellBegin55(const Sr1LocalFrame*f,unsigned glyph,uint64_t now){
 localSpellCast55.owner=localActionOwner(f,player,now);localSpellCast55.glyph=glyph;localSpellCast55.ring=0;localSpellCast55.dispatch=true;
}
static void localSpellCommit55(bool committed,uintptr_t ring){
 if(committed&&ring){localSpellCast55.ring=ring;localSpellCast55.dispatch=false;}
 else memset(&localSpellCast55,0,sizeof localSpellCast55);
}
static bool localSpellEventBefore55(uintptr_t actor,uint32_t message,LocalSpellHealth55*out){
 const Sr1LocalFrame f=readLocalFrame(false);const uint64_t now=GetTickCount64();localSpellWatch55(&f,now);
 return message>=(uint32_t)sheet_sr1Combat55_finish_contact_regen.glyphFirst&&message<=(uint32_t)sheet_sr1Combat55_finish_contact_regen.glyphLast&&
  message-0x80000u==localSpellCast55.glyph&&sameLocalAction(&localSpellCast55.owner,&f,player,now,UINT64_MAX)&&
  localSpellHealth55(actor,f.worldGeneration,out)&&out->hp>0;
}
static void localSpellEventAfter55(uint32_t message,const LocalSpellHealth55*before){
 const Sr1LocalFrame f=readLocalFrame(false);LocalSpellHealth55 after;
 if(localSpellHealth55(before->actor,f.worldGeneration,&after)&&after.state==before->state&&after.generation==before->generation)
  localSpellPause55(&f,before->actor,before->generation,before->state,before->hp,after.hp,message,GetTickCount64());
}
static uint32_t __attribute__((used,noinline)) localRegenProduct55(uintptr_t actor,int maximum,int health,uint32_t stock){
 const DWORD error=GetLastError();uint32_t result=stock;
#ifdef SR1_BOSS_KAIN93
 if(kainNoRegen93(actor)){SetLastError(error);return 0;}
#endif
#ifdef SR1_LOCAL_COMBAT60
 if(localStunRegenHold62(actor)){SetLastError(error);return 0;}
#endif
 if(actor&&maximum>0&&health>=0&&health<maximum){const uint64_t now=GetTickCount64();
  for(unsigned i=0;i<512;i++){LocalSpellLease55*lease=&localSpellLeases55[i];if(lease->target!=actor)continue;
#ifdef SR1_LOCAL_COMBAT56
   if(now>=lease->until&&generation(actor)==lease->gen)record("defiance-spell-regen-resume target=%u tick=%llu deadline=%llu product=%u hp=%d",lease->gen,(unsigned long long)now,(unsigned long long)lease->until,stock,health);
#endif
   const Sr1LocalFrame f=readLocalFrame(false);LocalSpellHealth55 current;
   if(now>=lease->until||!sameLocalAction(&lease->owner,&f,player,now,UINT64_MAX)||!localSpellHealth55(actor,f.worldGeneration,&current)||
    current.generation!=lease->gen||current.state!=lease->state){memset(lease,0,sizeof *lease);break;}
   result=0;break;
  }
 }SetLastError(error);return result;
}
static void __attribute__((used,naked)) localRegenScale55(void){
 __asm__ volatile("pushq %rcx\n pushq %rdx\n pushq %r8\n pushq %r9\n pushq %r10\n pushq %r11\n subq $128,%rsp\n"
 "movdqu %xmm0,32(%rsp)\n movdqu %xmm1,48(%rsp)\n movdqu %xmm2,64(%rsp)\n movdqu %xmm3,80(%rsp)\n movdqu %xmm4,96(%rsp)\n movdqu %xmm5,112(%rsp)\n"
 "movq %rsi,%rcx\n movl %eax,%r9d\n callq localRegenProduct55\n"
 "movdqu 32(%rsp),%xmm0\n movdqu 48(%rsp),%xmm1\n movdqu 64(%rsp),%xmm2\n movdqu 80(%rsp),%xmm3\n movdqu 96(%rsp),%xmm4\n movdqu 112(%rsp),%xmm5\n"
 "addq $128,%rsp\n popq %r11\n popq %r10\n popq %r9\n popq %r8\n popq %rdx\n popq %rcx\n jmp *localRegenOriginal55(%rip)\n");
}
static bool localSpellPrepare55(void){
 const unsigned char expected[]={0xc1,0xe8,0x0c,0x66,0x41,0x03,0xc0,0x66,0x89,0x83,0x58,0x02,0,0,0x66,0x3b,0xc2};unsigned char live[sizeof expected];
 const uintptr_t at=base+sheet_sr1Combat55_finish_contact_regen.regenRva;
 return readAt(at,live,sizeof live)&&!memcmp(live,expected,sizeof live)&&MH_CreateHook((void*)at,localRegenScale55,&localRegenOriginal55)==MH_OK;
}
