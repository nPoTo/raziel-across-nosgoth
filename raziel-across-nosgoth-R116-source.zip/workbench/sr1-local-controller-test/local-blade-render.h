// SPDX-License-Identifier: GPL-3.0-or-later
#pragma once

#include "reaver-gl-render.h"
#include "host-transform.h"
#include "reaver-submitted-hand.h"
#include "reaver-joint-palette.h"
#include "reaver-palm-frame.h"
#ifdef SR1_LOCAL_COMBAT73
#include "local-sword-light73.h"
#endif
#ifdef SR1_LOCAL_COMBAT48
#include "local-wrist48.h"
#ifdef SR1_LOCAL_COMBAT50
#include "local-forearm50.h"
#endif
#endif

#define PROBE_REPORT_DIR REPORT_PATH
#define overlayProgram 0u
#define logLine record
#define pglGetProgramiv ghGetProgramiv
#define pglGetUniformLocation ghGetUniformLocation
#define pglBindBuffer ghBindBuffer
#include "camera-probe.h"
#include "reaver-host-camera.h"
#include "reaver-gpu-palette.h"
#undef logLine
#undef overlayProgram
#undef pglGetProgramiv
#undef pglGetUniformLocation
#undef pglBindBuffer

typedef struct {
    uint32_t count, width, height, blend, repeat;
    float alpha;
    const uint16_t *indices;
    const unsigned char *rgba;
} LocalBladeBatch;

static const Sheet_sr1StandaloneBlade *const localBladePolicy = &sheet_sr1StandaloneBlade_standalone_default_blade;
static unsigned char *localBladeBytes;
static const ReaverGLVertex *localBladeVertices;
static unsigned localBladeCount, localBladeBatchCount;
#ifdef SR1_LOCAL_COMBAT_HANDOFF
static float localBladeWristZ;
#endif
#ifdef SR1_LOCAL_THIRD_FINISH
static float localBladeLength;
#endif
static LocalBladeBatch localBladeBatches[4];
static volatile LONG64 localBladeSwaps;
static _Thread_local ReaverJointPalette localBladePalette;
static _Thread_local uint64_t localBladeSerial, localBladeStagedFrame;
static _Thread_local HGLRC localBladeStagedContext;
static _Thread_local float localBladeMvp[16];
static _Thread_local bool localBladeStaged;
#ifdef SR1_LOCAL_COMBAT75
static _Thread_local float localEyeHead75[16],localEyeMvp75[16];
static _Thread_local bool localEyeCaptured75,localEyeStaged75;
static _Thread_local uint64_t localEyeSession75;
#endif
static _Thread_local ReaverGL localBladeGL;
#ifdef SR1_LOCAL_BLADE_ARC
typedef struct {
    float sample, gap;
} LocalBladeContact;
static _Thread_local LocalBladeContact localBladeContact, localBladeStagedContact;
#endif
#ifdef SR1_LOCAL_COMBAT_TIMING
static _Thread_local float localBladeAmount, localBladeFrameAmount;
static _Thread_local ReaverGLVertex fadingBladeVertices[2048];
#endif
#ifdef SR1_LOCAL_COMBAT_RECOVERY
static _Thread_local uint64_t localBladeWantedFrame;
static _Thread_local unsigned localBladeMisses;
#endif
static void (WINAPI *originalLocalIndexed)(GLenum, GLsizei, GLenum, const void *);
static BOOL (WINAPI *originalLocalSwap)(HDC);

static const unsigned char *takeLocalBlade(const unsigned char **p, const unsigned char *end, size_t bytes) {
    if (bytes > (size_t)(end - *p)) return NULL;
    const unsigned char *prior = *p;
    *p += bytes;
    return prior;
}

static bool parseLocalBlade(unsigned char *data,size_t length) {
    uint32_t sizes[2];
    memcpy(sizes, data, sizeof(sizes));
    if (sizes[0] != LOCAL_BLADE_VERTICES || !sizes[1] || sizes[1] > ARRAYSIZE(localBladeBatches)) return false;
    const unsigned char *p = data + sizeof(sizes), *end = data + length;
    const ReaverGLVertex *vertices = (const void *)takeLocalBlade(&p, end, sizes[0] * sizeof(*vertices));
    if (!vertices) return false;
    for (unsigned i = 0; i < sizes[1]; ++i) {
        LocalBladeBatch *batch = &localBladeBatches[i];
        const unsigned char *meta = takeLocalBlade(&p, end, 24);
        if (!meta) return false;
        memcpy(batch, meta, 24);
        if (!batch->count || batch->count > 8192 || batch->count % 3 || !batch->width || !batch->height ||
            batch->width > 2048 || batch->height > 2048 || batch->repeat > 1 || (batch->blend != 1 && batch->blend != 2) ||
            !isfinite(batch->alpha) || batch->alpha < -1 || batch->alpha > 1) return false;
        batch->indices = (const void *)takeLocalBlade(&p, end, batch->count * sizeof(*batch->indices));
        batch->rgba = takeLocalBlade(&p, end, (size_t)batch->width * batch->height * 4);
        if (!batch->indices || !batch->rgba) return false;
    }
    if (p != end) return false;
#ifdef SR1_LOCAL_COMBAT_HANDOFF
    float rootZ = INFINITY, tipZ = -INFINITY;
    for (unsigned i = 0; i < sizes[0]; ++i) {
        const float z = vertices[i].position[2];
        if (!isfinite(z)) return false;
        rootZ = fminf(rootZ, z);
        tipZ = fmaxf(tipZ, z);
    }
    if (!(rootZ < 0.f && tipZ > 0.f)) return false;
    localBladeWristZ = rootZ;
#ifdef SR1_LOCAL_THIRD_FINISH
    localBladeLength = tipZ - rootZ;
#ifdef SR1_LOCAL_BLADE_ARC
    if (groundXVisibleBladeLength() >= localBladeLength) return false;
#endif
#endif
#endif
    localBladeVertices = vertices;
    localBladeCount = sizes[0];
    localBladeBatchCount = sizes[1];
    return true;
}

#ifdef SR1_LOCAL_FORMS45
typedef struct {const ReaverGLVertex *vertices;unsigned count,batches;LocalBladeBatch batch[4];
#ifdef SR1_LOCAL_COMBAT51
 float wristZ,length;
#endif
} LocalBladeForm45;
static LocalBladeForm45 localBladeForms45[9];
static _Thread_local unsigned localBladeSelected45,localBladeStaged45;
static bool parseLocalBladeForms45(unsigned char *data){
 if(memcmp(data,"BF45",4))return false;size_t offset=40;
 for(unsigned i=0;i<9;i++){uint32_t length;memcpy(&length,data+4+i*4,4);if(length>LOCAL_BLADE_BYTES-offset||!parseLocalBlade(data+offset,length))return false;localBladeForms45[i]=(LocalBladeForm45){.vertices=localBladeVertices,.count=localBladeCount,.batches=localBladeBatchCount};memcpy(localBladeForms45[i].batch,localBladeBatches,sizeof(localBladeBatches));offset+=length;
#ifdef SR1_LOCAL_COMBAT51
 localBladeForms45[i].wristZ=localBladeWristZ;localBladeForms45[i].length=localBladeLength;
#endif
 }
 return offset==LOCAL_BLADE_BYTES;
}
static void selectLocalBlade45(unsigned selected){if(!selected||selected>9)return;const LocalBladeForm45 *f=&localBladeForms45[selected-1];localBladeVertices=f->vertices;localBladeCount=f->count;localBladeBatchCount=f->batches;memcpy(localBladeBatches,f->batch,sizeof(localBladeBatches));localBladeSelected45=selected;
#ifdef SR1_LOCAL_COMBAT51
 localBladeWristZ=f->wristZ;localBladeLength=f->length;
#endif
}
#include "local-hud45.h"
#endif
static void loadLocalBlade(HANDLE pipe, uint64_t deadline) {
    unsigned char *data = HeapAlloc(GetProcessHeap(), 0, LOCAL_BLADE_BYTES);
    if (!data) return;
    size_t filled = 0;
    while (filled < LOCAL_BLADE_BYTES && GetTickCount64() < deadline) {
        DWORD available, got;
        if (!PeekNamedPipe(pipe, NULL, 0, NULL, &available, NULL)) break;
        if (!available) {
            Sleep(4);
            continue;
        }
        const DWORD remaining = (DWORD)(LOCAL_BLADE_BYTES - filled);
        if (!ReadFile(pipe, data + filled, available < remaining ? available : remaining, &got, NULL) || !got) break;
        filled += got;
    }
    char hash[65];
    if (filled == LOCAL_BLADE_BYTES && boundedSha256(data, filled, LOCAL_BLADE_BYTES, hash) &&
        !strcmp(hash, LOCAL_BLADE_HASH) &&
#ifdef SR1_LOCAL_FORMS45
        parseLocalBladeForms45(data)
#else
        parseLocalBlade(data,LOCAL_BLADE_BYTES)
#endif
    ) {
        localBladeBytes = data;
        record("defiance-blade-assets vertices=%u batches=%u", localBladeCount, localBladeBatchCount);
        return;
    }
    HeapFree(GetProcessHeap(), 0, data);
    record("defiance-blade-assets refused filled=%llu", (unsigned long long)filled);
}

static bool currentLocalBlade(uintptr_t actor) {
    uint32_t actual, mirror, kind;
    uintptr_t blade;
    return actor && readAt(base + host->interactionTypeRva, &kind, sizeof(kind)) && kind == 0x1000 &&
        readAt(base + acquisition->abilitiesRva, &actual, sizeof(actual)) &&
        readAt(base + acquisition->mirrorRva, &mirror, sizeof(mirror)) && actual == mirror &&
        (actual & combatPolicy->reaverAbility) &&
        readAt(base + host->reaverRva, &blade, sizeof(blade)) && localBladeMatches(blade);
}

static uint64_t localBladeFrame(void) {
    return (uint64_t)InterlockedCompareExchange64(&localBladeSwaps, 0, 0) + 1;
}

#ifdef SR1_CONDITIONAL_BLADE
static bool localBladeRequested(const Sr1LocalFrame *frame) {
#ifdef SR1_LOCAL_COMBAT53
    if(localFinishActive53(frame,player,GetTickCount64()))return true;
#endif
#ifdef SR1_LOCAL_COMBAT52
    const uint64_t fxNow52=GetTickCount64();const LocalChargeView48 cast52=localChargeRead48();
    if((cast52.casting&&sameLocalAction(&cast52.owner,frame,player,fxNow52,5000))||localFxActive52(frame,player,fxNow52))return true;
#endif
    if (frame->groundStrike) return true;
#ifdef SR1_LOCAL_COMBAT_TIMING
    if (groundTransition.active && groundTransition.phase == GROUND_STRIKE) return true;
#endif
#ifdef SR1_LOCAL_NATIVE_CONTROLS
    const LocalCombatInput input = readLocalCombatInput();
    const uint64_t now = GetTickCount64();
#ifdef SR1_LOCAL_AIR_CONTACT
    if (localReadSpecial(frame,player,now).move) return true;
#ifdef SR1_LOCAL_SPECIAL_RECOVERY
    if (readSpecialRecovery(frame,player,now).released) return true;
#endif
#endif
#ifdef SR1_LOCAL_AIR_SLAM
    if (readLocalSlam(frame, player, now, slamRecoveryDuration()).windup) return true;
#endif
#ifdef SR1_LOCAL_AIR_STRIKE
    if (readLocalAirStrike(frame, player, now).owner.tick) return true;
#endif
#ifdef SR1_LOCAL_COMBAT_TEMPO
    if (localLiftJumpPresentation(&input, frame, player, now)) return true;
#endif
    if (localYPresentation(&input, frame, player, now)) return true;
#ifdef SR1_LOCAL_CONTROL_EDGES
    if (input.guardHeld && input.guardSample <= now && now - input.guardSample <= (uint64_t)groundPolicy->maxGapMs &&
        sameLocalAction(&input.guard, frame, player, now, UINT64_MAX)) return true;
#endif
#endif
    uintptr_t pad;
    uint32_t held, mask;
    return readAt(base + localBladePolicy->currentPadRva, &pad, sizeof(pad)) && pad &&
        readAt(base + localBladePolicy->combatMaskRva, &mask, sizeof(mask)) && mask &&
        readAt(pad, &held, sizeof(held)) && (held & mask);
}
#endif

static void localBladeCapture(uintptr_t actor, uintptr_t model, const float submitted[66][13],
    const Sr1LocalFrame *frame) {
#ifdef SR1_BOSS_KAIN93
    localArmCapture107(actor,submitted,frame);
#endif
#ifndef SR1_LOCAL_COMBAT_RECOVERY
    memset(&localBladePalette, 0, sizeof(localBladePalette));
#endif
#ifdef SR1_LOCAL_FORMS45
    const unsigned selected=localCurrentForm(frame->realm);if(!selected)return;selectLocalBlade45(selected);
#endif
    HGLRC context = wglGetCurrentContext();
    if (!localBladeBytes || !context || !currentLocalBlade(actor)) {
#ifdef SR1_LOCAL_COMBAT_RECOVERY
        localBladePalette.valid = false;
#endif
        return;
    }
#ifdef SR1_CONDITIONAL_BLADE
    static _Thread_local bool showing;
    const bool requested = localBladeRequested(frame);
    if (showing != requested) {
        showing = requested;
        record("defiance-blade-request visible=%u strike=%u realm=%u", requested, frame->groundStrike, frame->realm);
    }
#ifdef SR1_LOCAL_COMBAT_TIMING
    static _Thread_local LocalActionOwner fadeOwner;
    static _Thread_local uint64_t lastTick, edgeTick;
    static _Thread_local bool fadeTarget;
    static _Thread_local float edgeAmount;
    const uint64_t now = GetTickCount64();
    if (!sameLocalAction(&fadeOwner, frame, actor, now, UINT64_MAX) || now < lastTick ||
        now - lastTick > (uint64_t)groundPolicy->maxGapMs) {
        localBladeAmount = edgeAmount = 0.f;
        edgeTick = now;
        fadeTarget = false;
        fadeOwner = localActionOwner(frame, actor, now);
    }
    if (requested != fadeTarget) {
        edgeAmount = localBladeAmount;
        edgeTick = now;
        fadeTarget = requested;
    }
    const uint64_t duration = fadeTarget ? combatTiming->bladeDrawMs : combatTiming->bladeStowMs;
#ifdef SR1_LOCAL_COMBAT_RECOVERY
    const uint64_t elapsed = now - edgeTick;
    const float progress = elapsed >= duration ? 1.f : (float)elapsed / (float)duration;
    localBladeAmount = edgeAmount + ((fadeTarget ? 1.f : 0.f) - edgeAmount) * progress;
#else
    localBladeAmount = edgeAmount + ((fadeTarget ? 1.f : 0.f) - edgeAmount) * combatEase(now - edgeTick, duration);
#endif
    lastTick = now;
    if (localBladeAmount <= 0.f
#ifdef SR1_LOCAL_COMBAT75
        && !localFullCharge51(frame,actor,now) && !localSwitchTime75(frame,actor,selected,now)
#ifdef SR1_BOSS_KAIN93
        && !localArmCurrent108(frame,actor,now)
#endif
#endif
    ) {
#ifdef SR1_LOCAL_COMBAT_RECOVERY
        localBladePalette.valid = false;
#endif
        return;
    }
#else
    if (!requested) return;
#endif
#else
    (void)frame;
#endif
    ReaverSubmittedHand receipt;
#ifdef SR1_LOCAL_THIRD_SWEEP
    float projectedFloorGap = INFINITY;
#endif
    const uint64_t renderFrame = localBladeFrame(), session = GetCurrentProcessId();
#ifdef SR1_LOCAL_COMBAT_RECOVERY
    localBladeWantedFrame = renderFrame;
#endif
    if (!reaverHandCapture(&receipt, submitted, submitted, actor, model, session, renderFrame,
        ++localBladeSerial, true, true, 1)) return;
#if !defined(SR1_AUTHORED_BLADE_SOCKET) || defined(SR1_LOCAL_COMBAT_HANDOFF)
    const Sheet_reaverPalmBasis *const palm = &sheet_reaverPalmBasis_anatomical;
    const unsigned joints[] = {(unsigned)palm->targetWrist, (unsigned)palm->targetFinger, (unsigned)palm->targetThumb};
    float points[9], matrix[16];
    if (palm->targetSocket != localBladePolicy->handBone) return;
    for (unsigned i = 0; i < 3; ++i) {
        if (joints[i] >= 66) return;
        memcpy(points + i * 3, submitted[joints[i]] + 10, 3 * sizeof(float));
    }
#ifdef SR1_LOCAL_COMBAT48
    // The complete rigid grip comes from this frame's wrist, before any palm/socket fallback.
#ifdef SR1_LOCAL_COMBAT50
    #ifdef SR1_LOCAL_COMBAT76
    const float *wrist76=localGripActive76?localGripSource76:submitted[sheet_sr1Combat50_forearm_slam_camera.wristBone];
    if(!localForearmBlade50(matrix,submitted[sheet_sr1Combat50_forearm_slam_camera.elbowBone],wrist76))return;
#else
    if(!localForearmBlade50(matrix,submitted[sheet_sr1Combat50_forearm_slam_camera.elbowBone],submitted[sheet_sr1Combat50_forearm_slam_camera.wristBone]))return;
#endif
#else
    if(!localWristBlade48(matrix,submitted[palm->targetWrist],points))return;
#endif
    if(renderedThirdSample>=0.f)projectedFloorGap=groundXVisibleTipGap(matrix,points[2]-(submitted[0][12]+GROUND_SOLE_FLOOR),localBladeAmount);
#else
#ifdef SR1_LOCAL_COMBAT_HANDOFF
    // The verified mesh extends along positive Z. Use the live wrist and palm for both edges.
#ifdef SR1_LOCAL_COMBAT_FACING
    const LocalSpecial special=localReadSpecial(frame,actor,now);
    const bool authoredSocket=special.move==LOCAL_SPECIAL_PERFORATE
#ifndef SR1_LOCAL_SPECIAL_INPUT
        || special.move==LOCAL_SPECIAL_TEMPEST
#endif
#ifdef SR1_LOCAL_SPECIAL_RECOVERY
#ifndef SR1_LOCAL_SPECIAL_INPUT
        || readSpecialRecovery(frame,actor,now).released
#endif
#endif
        ;
    if (authoredSocket) {
#ifdef SR1_LOCAL_SPECIAL_INPUT
        if (special.bank==special.first) {
            if (!reaverPalmFrame(matrix,points,points)) return;
            combatBlendBladeBasis(matrix,receipt.matrix,combatEase(now-special.owner.tick,combatLinks->linkBlendMs));
        } else
#endif
        {
        memcpy(matrix,receipt.matrix,sizeof(matrix));
        memcpy(matrix+12,points,3*sizeof(float));
        }
    } else
#endif
    if (!reaverPalmFrame(matrix, points, points)) return;
#ifdef SR1_LOCAL_SPECIAL_INPUT
    const LocalSpecialRecovery recovery=readSpecialRecovery(frame,actor,now);
    if (!authoredSocket && recovery.released) {
        // Use the current blended wrist, closing the socket/palm orientation handoff continuously.
        const float blend=1.f-combatEase(now-recovery.released,
            sheet_sr1CombatSpecialRecovery_special_recovery.recoveryMs);
        combatBlendBladeBasis(matrix,receipt.matrix,blend);
    }
#endif
#ifdef SR1_LOCAL_THIRD_FINISH
#ifdef SR1_LOCAL_THIRD_SWEEP
    const float sample = renderedThirdSample;
    const bool useSocket = sample >= 0.f;
#else
    const LocalGroundX attack = readGroundX(frame, actor, now);
    const bool useSocket = attack.owner.tick && attack.ordinal == 2;
    const float sample = useSocket ? groundXSample(2, now - attack.start, localStrikePoses[2]) : -1.f;
#endif
#ifdef SR1_LOCAL_BLADE_ARC
    static _Thread_local LocalActionOwner bladeArcOwner;
    static _Thread_local float lastArcWeight;
    float weight = 0.f;
    if (useSocket) {
        weight = lastArcWeight = groundXBladeArcWeight(sample);
        bladeArcOwner = localActionOwner(frame, actor, now);
    } else if (!frame->groundStrike &&
#ifdef SR1_LOCAL_COMBAT_FACING
        !authoredSocket &&
#ifdef SR1_LOCAL_SPECIAL_INPUT
        !recovery.released &&
#endif
#endif
        sameLocalAction(&bladeArcOwner, frame, actor, now, combatTiming->bladeStowMs)) {
        weight = lastArcWeight * (1.f - combatEase(now - bladeArcOwner.tick, combatTiming->bladeStowMs));
    }
    const bool limitToFloor = useSocket && submitted[0][8] > .97f && groundXBladeSocketWeight(sample) > 0.f;
    if (weight > 0.f) {
        const float floor = submitted[0][12] + GROUND_SOLE_FLOOR;
        const float wristHeight = points[2] - floor;
        const float clampHeight = limitToFloor ? wristHeight - groundXBladeClearance() : NAN;
        const float tipLength = groundXVisibleBladeLength();
#else
    if (useSocket && submitted[0][8] > .97f) {
        const float weight = groundXBladeSocketWeight(sample);
        const float floor = submitted[0][12] + GROUND_SOLE_FLOOR;
        const float clampHeight = points[2] - floor, tipLength = localBladeLength;
#endif
        float axis[3];
        if (weight > 0.f && groundXBladeDirection(axis, matrix + 8, receipt.matrix + 8,
            weight, clampHeight, tipLength * localBladeAmount)) {
            float contact[9];
            memcpy(contact, points, 3 * sizeof(float));
            for (unsigned i = 0; i < 3; ++i) {
                contact[3 + i] = points[i] + axis[i];
                contact[6 + i] = points[i] + matrix[i];
            }
            if (reaverPalmFrame(matrix, contact, points)) {
#ifdef SR1_LOCAL_BLADE_ARC
                if (limitToFloor) projectedFloorGap = groundXVisibleTipGap(matrix, wristHeight, localBladeAmount);
#elif defined(SR1_LOCAL_THIRD_SWEEP)
                projectedFloorGap = points[2] - floor + matrix[10] * localBladeLength * localBladeAmount;
#endif
            }
        }
    }
#endif
#else
    if (!reaverPalmFrame(matrix, points, receipt.matrix + 12)) return;
#endif
#endif
    memcpy(receipt.matrix, matrix, sizeof(matrix));
#endif
    const Sheet_reaverPalettePolicy *const p = &sheet_reaverPalettePolicy_submitted_gpu_palette;
    unsigned before, after;
    float a[96*12], b[96*12];
    if (!readAt(base + p->countRva, &before, sizeof(before)) || !before || before > 96 ||
        !readAt(base + p->paletteRva, a, before * 48) || !readAt(base + p->paletteRva, b, before * 48) ||
        !readAt(base + p->countRva, &after, sizeof(after))) return;
#ifdef SR1_LOCAL_COMBAT_RECOVERY
    // A failed secondary pass must not discard a fully validated capture from the same frame.
    ReaverJointPalette candidate;
    if (reaverPaletteCapture(&candidate, &receipt, (uintptr_t)context, a, before, b, after, true)) {
        localBladePalette = candidate;
#ifdef SR1_LOCAL_COMBAT75
        localEyeCaptured75=localFullCharge51(frame,actor,now) && decodeHostRenderRoot(
            (const unsigned char*)submitted[sheet_sr1Reaver75_blade_material.eyeBone],localEyeHead75);
#endif
#ifdef SR1_LOCAL_BLADE_ARC
        localBladeContact = (LocalBladeContact){renderedThirdSample, projectedFloorGap};
#elif defined(SR1_LOCAL_THIRD_SWEEP)
        static _Thread_local bool reportedContact;
        const bool contact = fabsf(projectedFloorGap) <= 2.f;
        if (contact && !reportedContact)
            record("ground-x-blade-floor realm=%u sample=%.2f tip-gap=%.2f", frame->realm, renderedThirdSample, projectedFloorGap);
        reportedContact = contact;
#endif
    }
#else
    reaverPaletteCapture(&localBladePalette, &receipt, (uintptr_t)context, a, before, b, after, true);
#endif
}

static bool localBladeCamera(HGLRC context) {
    if (!context) return false;
    if (cameraReady && cameraContext == context) return true;
    if (!guidanceLoadGL()) return false;
#define LOCAL_LOAD_CAMERA(type, name) do { PROC p = wglGetProcAddress(#name); \
        if (!p || (uintptr_t)p <= 3 || (uintptr_t)p == UINTPTR_MAX) return false; c##name = (type)p; } while (0);
    CAMERA_GL(LOCAL_LOAD_CAMERA)
#undef LOCAL_LOAD_CAMERA
    cameraContext = context;
    cameraReady = true;
    cameraDiscover();
    return true;
}

#ifdef SR1_LOCAL_COMBAT73
#include "local-sword-light73-gl.h"
#endif
static void WINAPI localBladeIndexed(GLenum mode, GLsizei count, GLenum type, const void *indices) {
#ifdef SR1_SLUAGH_TEST80
    if(sluaghHideNative80(mode,count,type))return;
#endif
#ifdef SR1_LOCAL_COMBAT73
    if(!localSwordWorldDraw73(mode,count,type,indices))
#endif
    originalLocalIndexed(mode, count, type, indices);
#ifdef SR1_SLUAGH_TEST80
    // Enemy camera lifetime must not depend on sword visibility or target lock.
    if(mode==GL_TRIANGLES&&type==GL_UNSIGNED_SHORT&&count==(GLsizei)localBladePolicy->bodyIndices){
        GLint enemyProgram80=0,enemyFbo80=0;glGetIntegerv(GL_CURRENT_PROGRAM,&enemyProgram80);glGetIntegerv(GL_DRAW_FRAMEBUFFER_BINDING,&enemyFbo80);
        HGLRC enemyContext80=wglGetCurrentContext();if(!enemyFbo80&&enemyProgram80>0&&localBladeCamera(enemyContext80))sluaghCapture80(localBladeFrame(),enemyContext80,(GLuint)enemyProgram80);
    }
#endif
#ifdef SR1_LOCAL_COMBAT60
    if(!InterlockedCompareExchange(&portableActive60,0,0))return;
#endif
    const uint64_t frame = localBladeFrame();
    const ReaverSubmittedHand *const hand = &localBladePalette.hand;
    if (mode != GL_TRIANGLES || type != GL_UNSIGNED_SHORT || count != (GLsizei)localBladePolicy->bodyIndices ||
        !localBladePalette.valid || hand->frame != frame || localBladeStagedFrame == frame) return;
    GLint framebuffer, program;
    glGetIntegerv(GL_DRAW_FRAMEBUFFER_BINDING, &framebuffer);
    glGetIntegerv(GL_CURRENT_PROGRAM, &program);
    HGLRC context = wglGetCurrentContext();
    if (framebuffer || program <= 0 || !localBladeCamera(context)) return;
#ifdef SR1_SLUAGH_TEST80
    sluaghCapture80(frame,context,(GLuint)program);
#endif
    uintptr_t actor;
    if (!readAt(base + host->actorRva, &actor, sizeof(actor)) || actor != hand->actor ||
        !currentLocalBlade(actor) ||
        !reaverGpuPaletteMatches(&localBladePalette, context, (GLuint)program, actor, hand->model, hand->session, frame)) return;
    if (!reaverHostCameraMvp(localBladeMvp, hand, context, actor, hand->model, hand->session, frame, (GLuint)program, true)) return;
#ifdef SR1_LOCAL_FORMS45
    localBladeStaged45=localBladeSelected45;
#endif
#ifdef SR1_LOCAL_COMBAT75
    localEyeStaged75=false;
    if(localEyeCaptured75){
        ReaverSubmittedHand head=*hand;
        memcpy(head.matrix,localEyeHead75,sizeof head.matrix);
        const Sr1LocalFrame eyeFrame=readFrame();
        localEyeSession75=eyeFrame.session;
        localEyeStaged75=reaverHostCameraMvp(localEyeMvp75,&head,context,actor,hand->model,hand->session,frame,(GLuint)program,true);
    }
#endif
    localBladeStagedFrame = frame;
    localBladeStagedContext = context;
#ifdef SR1_LOCAL_COMBAT_TIMING
    localBladeFrameAmount = localBladeAmount;
#endif
#ifdef SR1_LOCAL_BLADE_ARC
    localBladeStagedContact = localBladeContact;
#endif
    localBladeStaged = true;
}

#ifdef SR1_LOCAL_COMBAT48
#include "local-impact-render48.h"
#ifdef SR1_BOSS_KAIN93
#include "arm-render108.h"
#endif
#ifdef SR1_LOCAL_COMBAT51
#include "local-fx-render51.h"
#endif
#endif
#ifdef SR1_LOCAL_COMBAT73
#include "local-sword-light73-draw.h"
#endif
#ifdef SR1_LOCAL_COMBAT75
#include "local-reaver-eyes75.h"
#ifdef SR1_LOCAL_COMBAT76
#include "local-eyes76.h"
#endif
#endif
static bool drawLocalBlade(void) {
#ifdef SR1_LOCAL_FORMS45
    selectLocalBlade45(localBladeStaged45);const unsigned textureBase=(localBladeSelected45-1)*4;
#else
    const unsigned textureBase=0;
#endif
    if (localBladeGL.context != wglGetCurrentContext()) {
        // The old GL context owns its objects until the game destroys it.
        memset(&localBladeGL, 0, sizeof(localBladeGL));
        if (!reaverGLInit(&localBladeGL)) return false;
    }
    for (unsigned i = 0; i < localBladeBatchCount; ++i) {
        const LocalBladeBatch *const batch = &localBladeBatches[i];
        if (!localBladeGL.textures[textureBase+i] && !reaverGLTexture(&localBladeGL, textureBase+i, batch->width, batch->height, batch->rgba, true, batch->repeat)) return false;
    }
    const ReaverGLVertex *vertices = localBladeVertices;
#ifdef SR1_LOCAL_COMBAT_TIMING
    const float alpha = localBladeFrameAmount;
#ifdef SR1_LOCAL_COMBAT_HANDOFF
    {
#else
    if (alpha < 1.f) {
#endif
        if (localBladeCount > ARRAYSIZE(fadingBladeVertices)) return false;
        for (unsigned i = 0; i < localBladeCount; ++i) {
            fadingBladeVertices[i] = localBladeVertices[i];
#ifdef SR1_LOCAL_COMBAT_HANDOFF
            bladeRevealPosition(fadingBladeVertices[i].position, localBladeVertices[i].position,
                localBladeWristZ, alpha);
#else
            fadingBladeVertices[i].position[2] *= .4f + .6f * alpha;
#endif
            fadingBladeVertices[i].rgba[3] *= alpha;
        }
        vertices = fadingBladeVertices;
    }
#else
    const float alpha = 1.f;
#endif
    for (unsigned i = 0; i < localBladeBatchCount; ++i) {
        const LocalBladeBatch *const batch = &localBladeBatches[i];
        const float cutoff = batch->alpha < 0.f ? batch->alpha : batch->alpha * alpha;
        if (!reaverGLDraw(&localBladeGL, vertices, localBladeCount, batch->indices, batch->count,
            textureBase+i, batch->blend, localBladeMvp, 0, cutoff)) return false;
    }
    return true;
}

static BOOL WINAPI localBladeSwap(HDC dc) {
#ifdef SR1_SLUAGH_TEST80
    sluaghDraw80(localBladeFrame());
#endif
#ifdef SR1_LOCAL_COMBAT60
    if(!InterlockedCompareExchange(&portableActive60,0,0)){localBladeStaged=false;
#ifdef SR1_LOCAL_COMBAT73
        memset(&localSword73,0,sizeof(localSword73));
#endif
        return originalLocalSwap(dc);}
#endif
#ifdef SR1_LOCAL_COMBAT_RECOVERY
    if (localBladeWantedFrame == localBladeFrame() && !localBladeStaged) {
        if (++localBladeMisses <= 6 || localBladeMisses % 120 == 0)
            record("defiance-blade-display-miss count=%u fade=%.2f", localBladeMisses, localBladeAmount);
    }
#endif
    if (localBladeStaged && localBladeStagedFrame == localBladeFrame() &&
        localBladeStagedContext == wglGetCurrentContext() && wglGetCurrentDC() == dc) {
        GLint framebuffer;
        glGetIntegerv(GL_DRAW_FRAMEBUFFER_BINDING, &framebuffer);
#ifdef SR1_BOSS_KAIN93
        if(!framebuffer){
            const Sr1LocalFrame armFrame108=readFrame();const uint64_t armNow108=GetTickCount64();
            float armStart108=INFINITY,armTip108=-INFINITY;
            for(unsigned i=0;i<localBladeCount;i++){const float z=localBladeVertices[i].position[2];armStart108=fminf(armStart108,z);armTip108=fmaxf(armTip108,z);}
            const float reveal108=localBladeFrameAmount,geometry108=reveal108>0?reveal108:1.f;
            localDrawCoil51(&armFrame108,localBladePalette.hand.actor,localBladeMvp,(fmaxf(0,armStart108)-localBladeWristZ)*geometry108,(armTip108-localBladeWristZ)*geometry108,reveal108,armNow108);
        }
#endif
#ifdef SR1_LOCAL_COMBAT75
        #ifdef SR1_LOCAL_COMBAT76
        if(!framebuffer && localEyeStaged75)localDrawEyes76();
#else
        if(!framebuffer && localEyeStaged75)localDrawEyes75();
#endif
        if(!framebuffer && localBladeFrameAmount<=0){
            const Sr1LocalFrame flashFrame=readFrame();
            if(localSwitchTime75(&flashFrame,player,localBladeStaged45,GetTickCount64()))
                localSwordFxDraw73(localBladePalette.hand.actor,localBladePalette.hand.matrix,localBladeMvp,1.f,0.f);
        }
#endif
        if (!framebuffer &&
#ifdef SR1_LOCAL_COMBAT75
            localBladeFrameAmount>0 &&
#endif
            drawLocalBlade()) {
#ifdef SR1_LOCAL_AIR_CONTACT
            localPublishContactDraw(localBladePalette.hand.actor,localBladePalette.hand.matrix,
                groundXVisibleBladeLength()*localBladeFrameAmount);
#ifdef SR1_LOCAL_COMBAT53
            const Sr1LocalFrame finishFrame53=readFrame();localFinishBladePoint53(&finishFrame53,localBladePalette.hand.actor,localBladePalette.hand.matrix,groundXVisibleBladeLength()*localBladeFrameAmount,GetTickCount64());
#endif
#endif
#ifdef SR1_LOCAL_BLADE_ARC
            static _Thread_local bool reportedVisibleContact;
            const float gap = localBladeStagedContact.gap;
            const bool contact = fabsf(gap - groundXBladeClearance()) <= 3.f;
            if (contact && !reportedVisibleContact)
                record("ground-x-visible-blade-floor sample=%.2f visible-gap=%.2f", localBladeStagedContact.sample, gap);
            reportedVisibleContact = contact;
#endif
#ifdef SR1_LOCAL_COMBAT48
            localDrawImpacts48(localBladePalette.hand.actor,localBladePalette.hand.matrix,localBladeMvp,true);
#ifdef SR1_LOCAL_COMBAT51
            float start51=INFINITY,tip51=-INFINITY;
            for(unsigned i=0;i<localBladeCount;i++){const float z=localBladeVertices[i].position[2];start51=fminf(start51,z);tip51=fmaxf(tip51,z);}
            const float revealedStart51=(fmaxf(0,start51)-localBladeWristZ)*localBladeFrameAmount;
            const float revealedTip51=(tip51-localBladeWristZ)*localBladeFrameAmount;
#ifdef SR1_LOCAL_COMBAT73
            localSwordFxDraw73(localBladePalette.hand.actor,localBladePalette.hand.matrix,localBladeMvp,revealedTip51,localBladeFrameAmount);
#endif
            localDrawChargedFx51(localBladePalette.hand.actor,localBladePalette.hand.matrix,localBladeMvp,revealedStart51,revealedTip51,localBladeFrameAmount);
#endif
#endif
            static unsigned draws;
            if (++draws == 1 || draws % 300 == 0) record("defiance-blade drawn frames=%u", draws);
        }
    }
#ifdef SR1_LOCAL_FORMS45
    localHud45Draw();
#endif
    localBladeStaged = false;
    InterlockedIncrement64(&localBladeSwaps);
    return originalLocalSwap(dc);
}

static PVOID *localBladeImport(HMODULE image, const char *dll, const char *symbol, PVOID *previous) {
    unsigned char *const module = (void *)image;
    const IMAGE_DOS_HEADER *dos = (const void *)module;
    if (dos->e_magic != IMAGE_DOS_SIGNATURE || dos->e_lfanew <= 0 || dos->e_lfanew >= 0x100000) return NULL;
    const IMAGE_NT_HEADERS64 *nt = (const void *)(module + dos->e_lfanew);
    if (nt->Signature != IMAGE_NT_SIGNATURE || nt->OptionalHeader.Magic != IMAGE_NT_OPTIONAL_HDR64_MAGIC) return NULL;
    const IMAGE_DATA_DIRECTORY directory = nt->OptionalHeader.DataDirectory[IMAGE_DIRECTORY_ENTRY_IMPORT];
    if (!directory.VirtualAddress || !directory.Size) return NULL;
    const IMAGE_IMPORT_DESCRIPTOR *desc = (const void *)(module + directory.VirtualAddress);
    for (; desc->Name; ++desc) {
        if (_stricmp((const char *)module + desc->Name, dll)) continue;
        if (!desc->OriginalFirstThunk) return NULL;
        const IMAGE_THUNK_DATA64 *names = (const void *)(module + desc->OriginalFirstThunk);
        IMAGE_THUNK_DATA64 *values = (void *)(module + desc->FirstThunk);
        for (; names->u1.AddressOfData; ++names, ++values) {
            if (IMAGE_SNAP_BY_ORDINAL64(names->u1.Ordinal)) continue;
            const IMAGE_IMPORT_BY_NAME *name = (const void *)(module + names->u1.AddressOfData);
            if (!strcmp((const char *)name->Name, symbol)) {
                HMODULE provider = GetModuleHandleA(dll);
                const PVOID known = provider ? (PVOID)GetProcAddress(provider, symbol) : NULL;
                if (!known || (PVOID)(uintptr_t)values->u1.Function != known) return NULL;
                *previous = known;
                return (PVOID *)&values->u1.Function;
            }
        }
    }
    return NULL;
}

static bool replaceLocalBladeImport(PVOID *slot, PVOID old, PVOID next) {
    DWORD saved, ignored;
    if (!VirtualProtect(slot, sizeof(*slot), PAGE_READWRITE, &saved)) return false;
    PVOID actual = InterlockedCompareExchangePointer(slot, next, old);
    if (!VirtualProtect(slot, sizeof(*slot), saved, &ignored)) record("defiance-blade could not restore IAT page flags");
    return actual == old;
}

static bool prepareLocalBladeRender(void) {
    if (!localBladeBytes) return false;
    const HMODULE exe = GetModuleHandleW(NULL);
    PVOID *draw = localBladeImport(exe, "OPENGL32.dll", "glDrawElements", (PVOID *)&originalLocalIndexed);
    PVOID *swap = localBladeImport(exe, "GDI32.dll", "SwapBuffers", (PVOID *)&originalLocalSwap);
    if (!draw || !swap || !replaceLocalBladeImport(swap, (PVOID)originalLocalSwap, (PVOID)localBladeSwap)) return false;
    if (!replaceLocalBladeImport(draw, (PVOID)originalLocalIndexed, (PVOID)localBladeIndexed)) {
        replaceLocalBladeImport(swap, (PVOID)localBladeSwap, (PVOID)originalLocalSwap);
        return false;
    }
    return true;
}
