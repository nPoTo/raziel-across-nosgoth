// SPDX-License-Identifier: GPL-3.0-or-later
// Pure quad renderer from reaver-menu-r2/hud-render.h.
#pragma once
#ifdef SR1_LOCAL_COMBAT71
#include "local-hud-icons71.h"
#endif
static float hudF32(const unsigned char *p){float v;memcpy(&v,p,4);return v;}
static bool hudDrawQuad(ReaverGL *r,const unsigned char *q,unsigned slot,const GLint viewport[4]){
 if(!r||!q||!r->context||wglGetCurrentContext()!=r->context||slot>=HUD_MAX_TEXTURES||!r->textures[slot]||viewport[2]<320||viewport[3]<240)return false;
 float k=fminf(viewport[2]*HUD_WIDTH_PERMILLE/(1000.f*HUD_WIDTH),viewport[3]*HUD_HEIGHT_PERMILLE/(1000.f*HUD_HEIGHT));
 float x=viewport[2]*HUD_LEFT_PERMILLE/1000.f,y=viewport[3]*(1-HUD_BOTTOM_PERMILLE/1000.f)-HUD_HEIGHT*k;
 ReaverGLVertex v[4]={0};const float u[]={hudF32(q+48),hudF32(q+56)},t[]={hudF32(q+52),hudF32(q+60)};
 for(unsigned i=0;i<4;i++){float px=hudF32(q+16+i*8),py=hudF32(q+20+i*8);
#ifdef SR1_LOCAL_COMBAT71
  uint32_t icon71=0;memcpy(&icon71,q,4);float cx71=0,cy71=0;for(unsigned corner71=0;corner71<4;corner71++){cx71+=hudF32(q+16+corner71*8)*.25f;cy71+=hudF32(q+20+corner71*8)*.25f;}
  localHudIconPoint71(icon71,cx71,cy71,&px,&py);
#endif
  v[i].position[0]=2*(x+k*px)/viewport[2]-1;v[i].position[1]=1-2*(y+k*py)/viewport[3];v[i].uv[0]=u[i==1||i==2];v[i].uv[1]=t[i>=2];for(unsigned j=0;j<4;j++)v[i].rgba[j]=hudF32(q+64+j*4);}
 const uint16_t indices[]={0,1,2,0,2,3};const float identity[16]={1,0,0,0,0,1,0,0,0,0,1,0,0,0,0,1};
 ReaverGLState saved={0};reaverGLSave(&saved);ghActiveTexture(GL_TEXTURE0);glBindTexture(GL_TEXTURE_2D,r->textures[slot]);ghBindSampler(0,0);ghUseProgram(r->program);ghBindVertexArray(r->vao);
 ghBindBuffer(GL_ARRAY_BUFFER,r->vbo);rgBufferData(GL_ARRAY_BUFFER,sizeof(v),v,GL_STREAM_DRAW);ghBindBuffer(GL_ELEMENT_ARRAY_BUFFER,r->ebo);rgBufferData(GL_ELEMENT_ARRAY_BUFFER,sizeof(indices),indices,GL_STREAM_DRAW);
 rgUniformMatrix4fv(ghGetUniformLocation(r->program,"mvp"),1,GL_FALSE,identity);ghUniform1i(ghGetUniformLocation(r->program,"blade"),0);rgUniform1f(ghGetUniformLocation(r->program,"scroll"),0);rgUniform1f(ghGetUniformLocation(r->program,"alphaTest"),-1);
 uint32_t blend=0;memcpy(&blend,q+4,4);
 ghEnablei(GL_BLEND,0);rgBlendFuncSeparatei(0,GL_SRC_ALPHA,blend==2?GL_ONE:GL_ONE_MINUS_SRC_ALPHA,GL_ONE,GL_ONE_MINUS_SRC_ALPHA);rgBlendEquationSeparatei(0,GL_FUNC_ADD,GL_FUNC_ADD);glDisable(GL_DEPTH_TEST);glDepthMask(GL_FALSE);
 ghColorMaski(0,GL_TRUE,GL_TRUE,GL_TRUE,GL_TRUE);glPolygonMode(GL_FRONT_AND_BACK,GL_FILL);glDisable(GL_STENCIL_TEST);glDisable(GL_CULL_FACE);glDisable(GL_SCISSOR_TEST);glDisable(GL_RASTERIZER_DISCARD);glDisable(GL_COLOR_LOGIC_OP);
 for(unsigned i=0;i<8;i++)glDisable(GL_CLIP_DISTANCE0+i);glDisable(GL_SAMPLE_COVERAGE);glDisable(GL_SAMPLE_ALPHA_TO_COVERAGE);glDisable(GL_SAMPLE_ALPHA_TO_ONE);glDisable(GL_SAMPLE_MASK);
 glDrawElements(GL_TRIANGLES,6,GL_UNSIGNED_SHORT,NULL);reaverGLRestore(&saved);return true;
}
