// SPDX-License-Identifier: GPL-3.0-or-later
#pragma once
#include "local-native59-proof.h"
enum {LOCAL_NATIVE59_NONE,LOCAL_NATIVE59_BELL,LOCAL_NATIVE59_LIMB,LOCAL_NATIVE59_BODY,LOCAL_NATIVE59_KAIN};
static bool localNativeReady59[5];
static bool localNativeProofs59(const LocalNativeProof59 *proof,unsigned count){
 for(unsigned i=0;i<count;i++)if(!verifyDrawBlock(proof[i].rva,proof[i].size,proof[i].hash))return false;return true;
}
static bool localMonsterMessage59(uintptr_t callback,const char name[9]){
 if(callback==base+contactPolicy->monsterMessageRva)return true;
 if(callback==base+C2_WALL_CRAWLER_MESSAGE_RVA&&!memcmp(name,C2_WALL_CRAWLER_NAME,9)){
  static const unsigned char expected[]=C2_WALL_CRAWLER_MESSAGE_BRANCH;unsigned char actual[sizeof expected];
  return readAt(callback,actual,sizeof actual)&&!memcmp(actual,expected,sizeof actual);
 }
 if(callback==base+C2_ALUKA_MESSAGE_RVA&&!memcmp(name,C2_ALUKA_NAME,9)){
  static const unsigned char expected[]=C2_ALUKA_MESSAGE_BYTES;unsigned char actual[sizeof expected];
  return readAt(callback,actual,sizeof actual)&&!memcmp(actual,expected,sizeof actual);
 }return false;
}
static bool localWallFlight59(uintptr_t actor,const uintptr_t flight[2]){
 if(flight[0]!=base+C3_WALL_FLIGHT_ENTRY||flight[1]!=base+C3_WALL_FLIGHT_UPDATE)return false;
 uintptr_t callback=0;static const unsigned char entry[]=C3_WALL_FLIGHT_ENTRY_BYTES,update[]=C3_WALL_FLIGHT_UPDATE_BYTES;
 unsigned char actual[sizeof update];return readAt(actor+0x1b8,&callback,8)&&callback==base+C2_WALL_CRAWLER_MESSAGE_RVA&&
  readAt(flight[0],actual,sizeof entry)&&!memcmp(actual,entry,sizeof entry)&&readAt(flight[1],actual,sizeof update)&&!memcmp(actual,update,sizeof update);
}
static unsigned localNativeIdentity59(uintptr_t target,uint32_t world){
 uintptr_t object=0,at=0,collision=0,message=0,data=0,parent=0;uint32_t room=0,intro=0,flags=0,magic=0,type=0;char name[9];
 if(!generation(target)||!readAt(target+0x60,&room,4)||room!=world||!readAt(target+0x28,&flags,4)||(flags&0x24040000u)||
  !readAt(target+host->parentOffset,&parent,8)||parent||!readAt(target+0x30,&object,8)||!object||
  !readAt(object+0x30,&at,8)||!at||!readAt(at,name,9)||!readAt(target+0x1a0,&collision,8)||!readAt(target+0x1b8,&message,8)||
  !readAt(target+0x64,&intro,4))return 0;
 if(localNativeReady59[LOCAL_NATIVE59_BELL]&&world==(uint32_t)CATHEDRAL_BELL_STREAM&&intro==CATHEDRAL_BELL_INTRO&&
  !memcmp(name,CATHEDRAL_BELL_NAME,9)&&collision==base+CATHEDRAL_BELL_COLLISION_RVA&&message==base+CATHEDRAL_BELL_MESSAGE_RVA)return LOCAL_NATIVE59_BELL;
 if(!readAt(target+0x40,&data,8)||!data||!readAt(data,&magic,4)||magic!=contactPolicy->monsterMagic||!readAt(data+0x20,&type,4))return 0;
 if(localNativeReady59[LOCAL_NATIVE59_LIMB]&&world==(uint32_t)ZEPHON_LIMB_STREAM&&intro>=ZEPHON_LIMB_FIRST_INTRO&&intro<=ZEPHON_LIMB_LAST_INTRO&&
  !memcmp(name,ZEPHON_LIMB_NAME,9)&&type==0x410002u&&collision==base+ZEPHON_LIMB_COLLISION_RVA&&message==base+ZEPHON_LIMB_MESSAGE_RVA)return LOCAL_NATIVE59_LIMB;
 if(localNativeReady59[LOCAL_NATIVE59_BODY]&&world==(uint32_t)ZEPHON_BODY_STREAM&&intro==ZEPHON_BODY_INTRO&&
  !memcmp(name,ZEPHON_BODY_NAME,9)&&type==ZEPHON_BODY_TYPE&&collision==base+ZEPHON_BODY_COLLISION&&message==base+ZEPHON_BODY_MESSAGE)return LOCAL_NATIVE59_BODY;
 if(localNativeReady59[LOCAL_NATIVE59_KAIN]&&world==(uint32_t)CHRONO_KAIN_STREAM&&intro==CHRONO_KAIN_INTRO&&
  !memcmp(name,CHRONO_KAIN_NAME,9)&&type==CHRONO_KAIN_TYPE&&collision==base+CHRONO_KAIN_COLLISION&&message==base+CHRONO_KAIN_MESSAGE)return LOCAL_NATIVE59_KAIN;
#ifdef SR1_LOCAL_COMBAT70
 const Sheet_sr1KainReaver70 *throne=&sheet_sr1KainReaver70_throne_and_reaver;
 if(localNativeReady59[LOCAL_NATIVE59_KAIN]&&
  (world==(uint32_t)throne->throneStream||world==(uint32_t)throne->authoredStream)&&intro==(uint32_t)throne->intro&&
  !memcmp(name,CHRONO_KAIN_NAME,9)&&type==(uint32_t)throne->monsterType&&
  collision==base+throne->collisionRva&&message==base+throne->messageRva)return LOCAL_NATIVE59_KAIN;
#endif
 return 0;
}
static bool localNativeTarget59(uintptr_t target,uint32_t world,LocalTarget *out){
 const unsigned kind=localNativeIdentity59(target,world);if(!kind)return false;
 LocalTarget read={.actor=target,.generation=generation(target),.nativeKind=kind};
 if(kind!=LOCAL_NATIVE59_BELL&&(!readAt(target+0x2c0,&read.state,8)||!read.state||!readAt(target+contactPolicy->stateOffset,&read.mainState,4)||
  !readAt(read.state+contactPolicy->healthOffset,&read.hp,2)))return false;
 *out=read;return true;
}
static bool localZephonLimbs59(uint32_t world){
 uintptr_t list=0,node=0,previous=0;uint32_t count=0,mask=0;
 if(!readAt(base+contactPolicy->listRva,&list,8)||!list||!readAt(list,&count,4)||count>512||!readAt(list+8,&node,8))return false;
 while(count--){uintptr_t next=0,back=0;uint32_t intro=0,state=0;
  if(!node||!readAt(node+0x10,&next,8)||!readAt(node+0x18,&back,8)||back!=previous)return false;
  if(localNativeIdentity59(node,world)==LOCAL_NATIVE59_LIMB&&readAt(node+0x64,&intro,4)&&readAt(node+contactPolicy->stateOffset,&state,4)&&state==ZEPHON_BODY_LIMB_EXHAUSTED)mask|=1u<<(intro-ZEPHON_LIMB_FIRST_INTRO);
  previous=node;node=next;
 }return !node&&mask==ZEPHON_BODY_LIMB_MASK;
}
static bool localNativeWindow59(const LocalTarget *target,const LocalStrikeDraw *draw){
 if(draw->owner.realm!=SR1_LOCAL_MATERIAL||draw->attack!=LOCAL_VICTIM_NO_ACTION)return false;
 const Sr1LocalFrame frame=readFrame();if((!frame.grounded
#ifdef SR1_LOCAL_COMBAT69
    &&!(frame.groundStrike&&frame.groundContact48)
#endif
    )||frame.airState!=SR1_AIR_NONE)return false;
 switch(target->nativeKind){
 case LOCAL_NATIVE59_BELL:return true;
 case LOCAL_NATIVE59_LIMB:return target->mainState==ZEPHON_LIMB_LIVE_STATE&&target->hp>0;
 case LOCAL_NATIVE59_KAIN:return target->mainState==CHRONO_KAIN_STATE_A||target->mainState==CHRONO_KAIN_STATE_B;
 case LOCAL_NATIVE59_BODY:{uintptr_t data=0;uint32_t flags=0;int16_t counter=0;return target->mainState==ZEPHON_BODY_LIVE_STATE&&
  readAt(target->state+ZEPHON_BODY_FLAGS_OFFSET,&flags,4)&&!(flags&ZEPHON_BODY_BUSY_FLAGS)&&
  readAt(target->state+ZEPHON_BODY_DATA_OFFSET,&data,8)&&data&&readAt(data+ZEPHON_BODY_COUNTER_OFFSET,&counter,2)&&counter>0&&localZephonLimbs59(draw->owner.world);}
 default:return false;
 }
}
static bool localNativeSphere59(uintptr_t actor,uint32_t world,const unsigned char entry[16],const unsigned char sphere[16]){
 const unsigned kind=localNativeIdentity59(actor,world);if(kind==LOCAL_NATIVE59_BELL){uint16_t radius=0;memcpy(&radius,sphere+14,2);return entry[3]==0&&sphere[4]<=1&&radius==CATHEDRAL_BELL_RADIUS;}
 return sphere[4]==8&&(kind!=LOCAL_NATIVE59_BODY||entry[3]==ZEPHON_BODY_SEGMENT_A||entry[3]==ZEPHON_BODY_SEGMENT_B);
}
static bool prepareLocalNative59(void){
 localNativeReady59[1]=localNativeProofs59(localbellProof59,ARRAYSIZE(localbellProof59))&&localNativeProofs59(localbellMessageProof59,ARRAYSIZE(localbellMessageProof59));
 localNativeReady59[2]=localNativeProofs59(localzephonProof59,ARRAYSIZE(localzephonProof59));
 localNativeReady59[3]=localNativeProofs59(localabdomenProof59,ARRAYSIZE(localabdomenProof59));
 localNativeReady59[4]=localNativeProofs59(localkainProof59,ARRAYSIZE(localkainProof59));
 record("defiance-native-coverage bell=%u zephon-limb=%u zephon-body=%u kain=%u wrappers=wallcr/aluka native-puzzles=1",localNativeReady59[1],localNativeReady59[2],localNativeReady59[3],localNativeReady59[4]);
 return localNativeReady59[1]&&localNativeReady59[2]&&localNativeReady59[3]&&localNativeReady59[4];
}
