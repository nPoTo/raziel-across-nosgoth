// SPDX-License-Identifier: GPL-3.0-or-later
#pragma once

// Reuse the native SR1 flight-state eligibility, hold lease and landing bounds.
#include "air-combat.h"

static inline bool localAirEnemy85(uint32_t realm,uint32_t monsterClass){
#ifdef SR1_LOCAL_COMBAT85
    return airMaterialEnemy(realm==2?1:realm,monsterClass);
#else
    return airMaterialEnemy(realm,monsterClass);
#endif
}

static inline bool localVictimWindow(uint64_t launch,uint64_t now) {
#ifdef SR1_LOCAL_LOCK47
    return launch && now>=launch && now-launch<(uint64_t)sheet_sr1Lock47_locked_combat.flightLimitMs;
#else
    return airFlightWindow(launch,now);
#endif
}
static inline bool localVictimHoldHit(AirVictimHold *hold,uint64_t launch,uint64_t now,uint64_t marker,bool confirmed) {
#ifdef SR1_LOCAL_LOCK47
    if (!confirmed || !marker || marker<=hold->hitMarker || !localVictimWindow(launch,now)) return false;
    hold->hitMarker=marker;
    const uint64_t until=now+
#ifdef SR1_LOCAL_COMBAT51
        sheet_sr1Combat51_aerial_charged_fx.hitHoldMs;
#else
        sheet_sr1Lock47_locked_combat.hitHoldMs;
#endif
    if (until>hold->until) hold->until=until;
    return true;
#else
    return airVictimHoldHit(hold,launch,now,marker,confirmed);
#endif
}
static inline bool localVictimHeld(const AirVictimHold *hold,uint64_t launch,uint64_t now) {
    return localVictimWindow(launch,now) && now<hold->until;
}


typedef enum {
    LOCAL_VICTIM_NO_ACTION, LOCAL_VICTIM_LIFT_HIT, LOCAL_VICTIM_AIR_X_HIT,
    LOCAL_VICTIM_SLAM_HIT, LOCAL_VICTIM_REBOUNDING_SLAM_HIT
} LocalVictimAttack;

typedef enum {
    LOCAL_VICTIM_UNCHANGED, LOCAL_VICTIM_START_FLIGHT, LOCAL_VICTIM_EXTEND_FLIGHT,
    LOCAL_VICTIM_START_FALL, LOCAL_VICTIM_LANDED, LOCAL_VICTIM_REBOUND
} LocalVictimCommand;
#ifdef SR1_LOCAL_COMBAT49
static inline int32_t localVictimDescent49(int32_t playerVelocity,bool falling){
    if(!falling)return 0;
    const int32_t speed=playerVelocity<0?playerVelocity:-48;
    return speed < -AIR_SLAM_MAX_SPEED ? -AIR_SLAM_MAX_SPEED : speed;
}
#endif

typedef struct {
    uint64_t session;
    uint32_t stream, realm, player, target;
} LocalVictimIdentity;

typedef struct {
    LocalVictimIdentity identity;
    uint64_t sequence, tick;
    uint32_t monsterClass, stateBefore, stateAfter;
    bool nativeApplied;
    LocalVictimAttack attack;
} LocalVictimHit;

typedef struct {
    LocalVictimIdentity identity;
    uint64_t sequence, lastHit, launch, slam;
    AirVictimHold hold;
    bool reboundRequested;
#ifdef SR1_LOCAL_COMBAT51
    int16_t hopOrigin51;uint64_t hopUntil51;bool apexSeen51;
#endif
#ifdef SR1_LOCAL_COMBAT50
    int16_t playerFloor50,victimFloor50;bool haveFloors50,descent50,rollPose50;
#endif
#ifdef SR1_LOCAL_COMBAT48
    bool apexPassed;uint64_t apexUntil;
#endif
} LocalVictimFlight;
#ifdef SR1_LOCAL_COMBAT50
static inline int32_t localVictimSlamVelocity50(bool descending,bool floors,bool landed,int playerHeight,int victimHeight,int32_t speed){
    if(!descending)return 0;
    if(floors)return airSlamVelocity(landed?0:playerHeight,victimHeight,speed<0?speed:0);
    return localVictimDescent49(speed,true);
}
#endif
#ifdef SR1_LOCAL_COMBAT48
static inline bool localVictimApex48(LocalVictimFlight *flight,int32_t velocity,uint64_t now){
    if(!flight->launch||flight->slam||flight->apexPassed||now<flight->launch+200||
       !localVictimWindow(flight->launch,now)||velocity>0)return false;
    flight->apexPassed=true;flight->apexUntil=now+sheet_sr1Combat48_combat_charge.initialApexHoldMs;
    if(flight->apexUntil>flight->hold.until)flight->hold.until=flight->apexUntil;
    return true;
}
#endif

static inline bool localVictimSame(LocalVictimIdentity a, LocalVictimIdentity b) {
    return a.session && a.session==b.session && a.stream==b.stream && a.realm==b.realm &&
        a.player && a.player==b.player && a.target && a.target==b.target;
}

// The boundary supplies a receipt from the native damage route. Input,
// proximity, engagement and pose never create a receipt by themselves.
static inline LocalVictimCommand localVictimHit(LocalVictimFlight *flight, LocalVictimHit hit) {
    if (!hit.nativeApplied || !hit.sequence || !hit.tick || !hit.identity.session || !hit.identity.player || !hit.identity.target ||
        !localAirEnemy85(hit.identity.realm,hit.monsterClass)) return LOCAL_VICTIM_UNCHANGED;

    const bool same = localVictimSame(flight->identity,hit.identity);
    if (same && (hit.sequence<=flight->sequence || hit.tick<flight->lastHit)) return LOCAL_VICTIM_UNCHANGED;

    if (hit.attack==LOCAL_VICTIM_LIFT_HIT &&
        (airVictimReaction(AIR_STRIKE_LIFT,hit.stateBefore,hit.stateAfter)==AIR_VICTIM_VERTICAL
#ifdef SR1_LOCAL_COMBAT56
        ||((hit.stateBefore==AIR_FLIGHT_STATE||hit.stateBefore==AIR_SLAM_ROLL_STATE)&&
           (hit.stateAfter==4||hit.stateAfter==8||hit.stateAfter==9||hit.stateAfter==AIR_FLIGHT_STATE||hit.stateAfter==AIR_SLAM_ROLL_STATE))
#endif
        )) {
        *flight=(LocalVictimFlight){.identity=hit.identity,.sequence=hit.sequence,.lastHit=hit.tick,.launch=hit.tick};
        return LOCAL_VICTIM_START_FLIGHT;
    }
#ifdef SR1_LOCAL_COMBAT49
    if((hit.attack==LOCAL_VICTIM_SLAM_HIT||hit.attack==LOCAL_VICTIM_REBOUNDING_SLAM_HIT)&&
       hit.stateBefore==AIR_FLIGHT_STATE&&hit.stateAfter==AIR_FLIGHT_STATE&&(!same||!flight->launch)){
        *flight=(LocalVictimFlight){.identity=hit.identity,.sequence=hit.sequence,.lastHit=hit.tick,.launch=hit.tick,.slam=hit.tick,
            .reboundRequested=hit.attack==LOCAL_VICTIM_REBOUNDING_SLAM_HIT};
        return LOCAL_VICTIM_START_FALL;
    }
#endif
    if (!same || !flight->launch || flight->slam || !localVictimWindow(flight->launch,hit.tick) ||
        airVictimReaction(AIR_STRIKE_REAVER,hit.stateBefore,hit.stateAfter)!=AIR_VICTIM_FLINCH)
        return LOCAL_VICTIM_UNCHANGED;

    switch (hit.attack) {
    case LOCAL_VICTIM_AIR_X_HIT:
        if (!localVictimHoldHit(&flight->hold,flight->launch,hit.tick,hit.sequence,true))
            return LOCAL_VICTIM_UNCHANGED;
        flight->sequence=hit.sequence;
        flight->lastHit=hit.tick;
        return LOCAL_VICTIM_EXTEND_FLIGHT;
    case LOCAL_VICTIM_SLAM_HIT:
    case LOCAL_VICTIM_REBOUNDING_SLAM_HIT:
        flight->sequence=hit.sequence;
        flight->lastHit=hit.tick;
        flight->slam=hit.tick;
        flight->reboundRequested=hit.attack==LOCAL_VICTIM_REBOUNDING_SLAM_HIT;
        return LOCAL_VICTIM_START_FALL;
    default:
        return LOCAL_VICTIM_UNCHANGED;
    }
}

static inline LocalVictimCommand localVictimLand(LocalVictimFlight *flight, LocalVictimIdentity identity,
    uint64_t victimContact, uint64_t playerContact, uint64_t now, bool nativeReboundAllowed) {
    if (!localVictimSame(flight->identity,identity) ||
        !airSlamContactsMatch(flight->slam,victimContact,playerContact,now)) return LOCAL_VICTIM_UNCHANGED;
#ifdef SR1_LOCAL_COMBAT50
    const bool rebound=nativeReboundAllowed; // Released0.2 small roll-state bounce on ordinary and special slam.
#else
    const bool rebound=flight->reboundRequested && nativeReboundAllowed;
#endif
    // Retain the consumed sequence so an old native receipt cannot open a new flight after landing.
    flight->launch=flight->slam=0;
    flight->hold=(AirVictimHold){0};
    flight->reboundRequested=false;
    return rebound ? LOCAL_VICTIM_REBOUND : LOCAL_VICTIM_LANDED;
}
