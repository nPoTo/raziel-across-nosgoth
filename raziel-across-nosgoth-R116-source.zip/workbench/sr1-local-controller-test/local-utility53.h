// SPDX-License-Identifier: GPL-3.0-or-later
#pragma once
// Standalone adapters to released0.2 C6 and C4 native operations. No fabricated deaths/souls/rewards.
typedef struct {LocalActionOwner owner;uintptr_t target;uint32_t gen;uint64_t start;} LocalDrainHold53;
static _Thread_local LocalDrainHold53 localDrainHold53;
static _Thread_local bool localDrainDown53,localDrainConsumed53,localTkDown53;
static bool localFinishTarget53(const Sr1LocalFrame*f,uintptr_t target,uint32_t gen,LocalTarget*out){
 int16_t from[3],to[3];
 const bool ground=f->grounded||(f->airState==SR1_AIR_NONE&&f->groundStrike&&f->groundContact48);
 if(!f->ready||!f->renderBlend||!ground||
#ifdef SR1_LOCAL_COMBAT55
   (f->nativeControl&&!(f->groundStrike&&f->groundContact48))||
#else
   f->nativeControl||
#endif
   f->realm!=SR1_LOCAL_MATERIAL||localPhysicalCarry(player)||
   !localAirStrikeEquipped()||!localReadContactTarget(target,f->worldGeneration,out)||out->generation!=gen||out->hp!=0||out->mainState!=9||
#ifndef SR1_LOCAL_COMBAT55
   !(((QueryInstance)(base+signals->queryRva))(target,0)&(uintptr_t)signals->stunnedMask)||
#endif
   !readAt(player+0x9c,from,6)||!readAt(target+0x9c,to,6)||to[2]>INT16_MAX-128)return false;
#ifdef SR1_LOCAL_COMBAT55
 uintptr_t blade=0,parent=0;uint32_t stateFlags=0;
 if(!readAt(base+host->reaverRva,&blade,8)||!blade||!readAt(blade+host->parentOffset,&parent,8)||parent!=player||
   !readAt(out->state,&stateFlags,4)||(stateFlags&0x40u))return false;
#endif
 int64_t distance=0;for(unsigned i=0;i<3;i++){const int64_t d=(int)from[i]-to[i];distance+=d*d;}
 const int64_t range=sheet_sr1Combat53_fast_force_held_soul.finishRadius;if(distance>range*range)return false;
 const float origin[3]={from[0],from[1],from[2]+128.f};to[2]+=128;return localNativeLineClear(player,f->worldGeneration,origin,to);
}
static bool localFindFinish53(const Sr1LocalFrame*f,uintptr_t*out,uint32_t*gen){
 uintptr_t list=0,node=0,prior=0;uint32_t count=0;int16_t root[3];
 if(!readAt(player+0x9c,root,6)||!readAt(base+contactPolicy->listRva,&list,8)||!list||!readAt(list,&count,4)||!count||count>512||!readAt(list+8,&node,8))return false;
 uintptr_t chosen=0;uint32_t chosenGen=0;int64_t best=INT64_MAX;bool source=false;
 while(count--){uintptr_t next=0,back=0;if(!node||!readAt(node+0x10,&next,8)||!readAt(node+0x18,&back,8)||back!=prior)return false;
  if(node==player)source=true;else{LocalTarget target;int16_t p[3];const uint32_t g=generation(node);
   if(localFinishTarget53(f,node,g,&target)&&readAt(node+0x9c,p,6)){int64_t d=0;for(unsigned k=0;k<3;k++){int64_t a=(int)p[k]-root[k];d+=a*a;}
    if(d<best||(d==best&&g<chosenGen)){best=d;chosen=node;chosenGen=g;}}
  }prior=node;node=next;
 }
 if(node||!source||!chosen)return false;*out=chosen;*gen=chosenGen;return true;
}
static void localUtilityBlock53(NativePad*p){
 uint32_t attack=0,face=0;readAt(base+signals->attackMaskRva,&attack,4);readAt(base+sheet_sr1StandaloneBlade_standalone_default_blade.combatMaskRva,&face,4);
 const uint32_t mask=attack|face|(uint32_t)inputBoundary->liftNativeMask|0x80u|0xfu|(uint32_t)localStasisPolicy->aimMask
#ifdef SR1_LOCAL_COMBAT54
 |(uint32_t)sheet_sr1Combat54_utility_aim_hud.feedNative
#endif
 ;
 p->held&=~mask;p->pressed&=~mask;p->released&=~mask;p->x=p->y=0;
}
static bool localUtilityInput53(NativePad*p,const Sr1LocalFrame*f,uint64_t now){
#ifdef SR1_LOCAL_COMBAT54
 const uint32_t feed=(uint32_t)sheet_sr1Combat54_utility_aim_hud.feedNative;
 const bool down=((p->held|p->pressed)&feed)!=0,edge=(p->pressed&feed)||(down&&!localDrainDown53);localDrainDown53=down;
 if(localFinishActive53(f,player,now)){localUtilityBlock53(p);return true;}
 if(!down&&!localDrainHold53.owner.tick){localDrainConsumed53=false;return false;}
 if(edge&&!localDrainConsumed53&&!localDrainHold53.owner.tick){
  const LocalFinish53 active=localFinishRead53();uintptr_t target=0;uint32_t gen=0;
  if((!active.owner.tick||active.absorbed||now<active.start||now-active.start>5000)&&localFindFinish53(f,&target,&gen)){
   localDrainHold53=(LocalDrainHold53){.owner=localActionOwner(f,player,now),.target=target,.gen=gen,.start=now};localDrainConsumed53=true;
   record("defiance-soul-feed-press target=%u",gen);
  }
#ifdef SR1_LOCAL_COMBAT55
  else record("defiance-soul-feed-refused realm=%u grounded=%u native=%u strike=%u contact=%u held=%x pressed=%x",f->realm,f->grounded,f->nativeControl,f->groundStrike,f->groundContact48,p->held,p->pressed);
#endif
 }
 if(localDrainHold53.owner.tick){
  const LocalDrainHold53 press=localDrainHold53;LocalTarget target;
  if(!sameLocalAction(&press.owner,f,player,now,2000)||!localFinishTarget53(f,press.target,press.gen,&target)){
   localDrainHold53=(LocalDrainHold53){0};record("defiance-soul-feed-cancel target=%u",press.gen);
  }else if(!f->groundStrike&&!f->strikePending){
   uint32_t intro=0;if(readAt(target.actor+C4_NATIVE_INTRO_ID_OFFSET,&intro,4)&&intro){
    LocalFinish53 next={.owner=localActionOwner(f,player,now),.target=target.actor,.targetGen=target.generation,.intro=intro,.form=localCurrentForm(f->realm),.start=now};
#ifdef SR1_LOCAL_COMBAT56
    int16_t root[3];if(!readAt(player+0x9c,root,6)||!readAt(target.actor+0x9c,next.aim,6)||next.aim[2]>INT16_MAX-128)return false;
    next.aim[2]+=128;next.yaw=(uint16_t)localTargetYaw47(root,next.aim);next.facing=true;
    localDodgeCancelOthers56();SIZE_T written=0;WriteProcessMemory(GetCurrentProcess(),(void*)(player+sheet_sr1GroundSteering_camera_relative_start.yawOffset),&next.yaw,2,&written);
    record("defiance-soul-facing target=%u yaw=%u point=%d,%d,%d",target.generation,next.yaw,next.aim[0],next.aim[1],next.aim[2]);
#endif
    localFinishStore53(next);
    record("defiance-soul-start target=%u intro=%u feed=1 latency=%llu",target.generation,intro,(unsigned long long)(now-press.start));
   }localDrainHold53=(LocalDrainHold53){0};
  }
  localUtilityBlock53(p);return true;
 }
 if(localDrainConsumed53){p->held&=~feed;p->pressed&=~feed;p->released&=~feed;return false;}
 return false; // No eligible stunned victim: ordinary native feeding and all Y inputs pass unchanged.
#else
 const uint32_t lift=(uint32_t)inputBoundary->liftNativeMask;const bool down=(p->held&lift)!=0,edge=down&&!localDrainDown53;localDrainDown53=down;
 if(localFinishActive53(f,player,now)){if(!down)localDrainConsumed53=false;localUtilityBlock53(p);return true;}
 if(!down&&localDrainConsumed53){localDrainConsumed53=false;return false;}
 if(down&&localDrainConsumed53){p->held&=~lift;p->pressed&=~lift;p->released&=~lift;return true;}
 const LocalFinish53 active=localFinishRead53();
 if(edge&&!localDrainHold53.owner.tick&&
   (!active.owner.tick||active.absorbed||now<active.start||now-active.start>5000)){
  uintptr_t target=0;uint32_t gen=0;if(localFindFinish53(f,&target,&gen)){
   localDrainHold53=(LocalDrainHold53){.owner=localActionOwner(f,player,now),.target=target,.gen=gen,.start=now};
   record("defiance-soul-hold target=%u",gen);
  }
 }
 if(!localDrainHold53.owner.tick)return false;
 LocalTarget target;const LocalDrainHold53 hold=localDrainHold53;
 if(!sameLocalAction(&hold.owner,f,player,now,2000)||!localFinishTarget53(f,hold.target,hold.gen,&target)){
  localDrainHold53=(LocalDrainHold53){0};localDrainConsumed53=down;localUtilityBlock53(p);record("defiance-soul-hold-cancel target=%u",hold.gen);return true;
 }
 if(!down){localDrainHold53=(LocalDrainHold53){0};p->held|=lift;p->pressed|=lift;p->released&=~lift;record("defiance-soul-short-tap target=%u",hold.gen);return false;}
 if(now-hold.start>=(uint64_t)sheet_sr1Combat53_fast_force_held_soul.holdMs){
  if(f->groundStrike||f->strikePending){localUtilityBlock53(p);return true;} // Retain hold through the strike that stunned this target.
  uint32_t intro=0;if(readAt(target.actor+C4_NATIVE_INTRO_ID_OFFSET,&intro,4)&&intro){
   LocalFinish53 finish={.owner=localActionOwner(f,player,now),.target=target.actor,.targetGen=target.generation,.intro=intro,.form=localCurrentForm(f->realm),.start=now};
   localFinishStore53(finish);record("defiance-soul-start target=%u intro=%u hold=%llu",target.generation,intro,(unsigned long long)(now-hold.start));
  }
  localDrainHold53=(LocalDrainHold53){0};localDrainConsumed53=true;
 }
 localUtilityBlock53(p);return true;
#endif
}
static void localTkInput53(NativePad*p,const Sr1LocalFrame*f,uint64_t now){
 const uint32_t aim=(uint32_t)localStasisPolicy->aimMask;const bool down=((p->held|p->pressed)&aim)!=0,edge=(p->pressed&aim)||(down&&!localTkDown53);localTkDown53=down;
#ifdef SR1_LOCAL_COMBAT55
 if(!f->ready||!f->renderBlend||f->realm==SR1_LOCAL_UNKNOWN||localPhysicalCarry(player)||!localAirStrikeEquipped())return;
 p->held&=~aim;p->pressed&=~aim;p->released&=~aim; // Owned TK never falls through to the old contextual Reaver finisher.
 uint32_t abilities=0,mirror=0;
 if(!readAt(base+acquisition->abilitiesRva,&abilities,4)||!readAt(base+acquisition->mirrorRva,&mirror,4)||abilities!=mirror||!(abilities&AIR_FORCE_ABILITY)){
  if(edge)record("defiance-force-refused reason=locked-or-mirror abilities=%x mirror=%x",abilities,mirror);return;
 }
#else
 uint32_t abilities=0,mirror=0;if(!f->ready||!f->renderBlend||f->realm==SR1_LOCAL_UNKNOWN||localPhysicalCarry(player)||!localAirStrikeEquipped()||
  !readAt(base+acquisition->abilitiesRva,&abilities,4)||!readAt(base+acquisition->mirrorRva,&mirror,4)||abilities!=mirror||!(abilities&AIR_FORCE_ABILITY))return;
#endif
#ifdef SR1_LOCAL_COMBAT75
 static _Thread_local unsigned priorDirection75;
 static _Thread_local uint64_t priorSession75;
 static _Thread_local LocalActionOwner directionSample75, directionTap75;
 const unsigned direction75=localSpecialDirection(p->x,p->y);
 if(priorSession75!=f->session||!sameLocalAction(&directionSample75,f,player,now,(uint64_t)groundPolicy->maxGapMs)) {
  directionTap75=(LocalActionOwner){0};priorDirection75=direction75;priorSession75=f->session;
 }
 if(direction75 && direction75!=priorDirection75)directionTap75=localActionOwner(f,player,now);
 priorDirection75=direction75;
 directionSample75=localActionOwner(f,player,now);
#endif
 if(edge){const C6CooldownOwner owner={f->session,player,f->playerGeneration};const uint32_t remaining=c6CooldownRemaining(&localForceCooldown53,owner,now);
  if(!remaining&&!localStasisPress.tick){localStasisPress=localActionOwner(f,player,now);
#ifdef SR1_LOCAL_COMBAT75
   uint32_t normalMask=0;
   localStasisChord75=readAt(base+signals->attackMaskRva,&normalMask,4) && normalMask &&
    !(p->pressed&(normalMask|(uint32_t)inputBoundary->liftNativeMask)) && direction75 && (localSpecialPhase(LOCAL_SPECIAL_PERFORATE,f)||localSlamAirborne(f)) &&
    !localReadSpecial(f,player,now).move && sameLocalAction(&directionTap75,f,player,now,(uint64_t)localStasisPolicy->inputChordMs);
   directionTap75=(LocalActionOwner){0};
#endif
   record("defiance-force-press realm=%u",f->realm);}
  else record("defiance-force-cooldown-block remaining=%u",remaining);
 }
 if(down||(p->released&aim)){p->held&=~aim;p->pressed&=~aim;p->released&=~aim;}
}
static bool localSoulIdentity53(uintptr_t soul,const LocalFinish53*f,uint32_t*gen){
 uintptr_t object=0,name=0,state=0,handler=0;uint32_t room=0,lineage=0,flags=0;char text[9];
 return soul&&readAt(soul+0x30,&object,8)&&object&&readAt(object+0x30,&name,8)&&name&&readAt(name,text,9)&&!memcmp(text,"soul____",9)&&
  readAt(soul+0x1b8,&handler,8)&&handler==base+contactPolicy->monsterMessageRva&&readAt(soul+0x28,&flags,4)&&!(flags&0x04040000u)&&
  readAt(soul+0x60,&room,4)&&room==f->owner.world&&readAt(soul+0x2c0,&state,8)&&state&&
  readAt(state+C4_NATIVE_SOUL_PARENT_OFFSET,&lineage,4)&&lineage==f->intro&&(*gen=generation(soul))!=0;
}
static bool localFindSoul53(const LocalFinish53*f,uintptr_t*out,uint32_t*gen){
 uintptr_t list=0,node=0;uint32_t count=0;if(!readAt(base+contactPolicy->listRva,&list,8)||!list||!readAt(list,&count,4)||count>512||!readAt(list+8,&node,8))return false;
 uintptr_t found=0;uint32_t foundGen=0;while(count--){uintptr_t next=0;if(!node||!readAt(node+0x10,&next,8)||next==node)return false;uint32_t g=0;
  if(localSoulIdentity53(node,f,&g)){if(found)return false;found=node;foundGen=g;}node=next;
 }if(node)return false;*out=found;*gen=foundGen;return true;
}
static void localUtilityTick53(const Sr1LocalFrame*f,uint64_t now){
 LocalFinish53 finish=localFinishRead53();if(!finish.owner.tick)return;int32_t hp=0;
 if(finish.absorbed&&now>=finish.start&&now-finish.start>(uint64_t)sheet_sr1Combat53_fast_force_held_soul.finishMs+100u){localFinishStore53((LocalFinish53){0});record("defiance-soul-complete target=%u",finish.targetGen);return;}
 if(!f->ready||!f->renderBlend||f->realm!=SR1_LOCAL_MATERIAL||!sameLocalAction(&finish.owner,f,player,now,5000)||
   localPhysicalCarry(player)||!readAt(base+0x2a88cd0,&hp,4)||hp<=0){localFinishStore53((LocalFinish53){0});localDrainHold53=(LocalDrainHold53){0};record("defiance-soul-cancel target=%u",finish.targetGen);return;}
 const uint64_t age=now-finish.start;
 if(age<(uint64_t)sheet_sr1Combat53_fast_force_held_soul.finishMs
#ifdef SR1_LOCAL_COMBAT56
 +100u
#endif
 ){int16_t from[3],to[3];
  if(readAt(player+0x9c,from,6)&&generation(finish.target)==finish.targetGen&&readAt(finish.target+0x9c,to,6)){
   const uint16_t yaw=
#if defined(SR1_LOCAL_COMBAT56) && !defined(SR1_LOCAL_COMBAT58)
    finish.facing?finish.yaw:
#endif
    (uint16_t)localTargetYaw47(from,to);SIZE_T written=0;WriteProcessMemory(GetCurrentProcess(),(void*)(player+sheet_sr1GroundSteering_camera_relative_start.yawOffset),&yaw,2,&written);
  }
 }
 if(!finish.posted&&age>=(uint64_t)sheet_sr1Combat53_fast_force_held_soul.reachMs){
  LocalTarget target;uintptr_t soul=0;uint32_t gen=0;
  if(!localFinishTarget53(f,finish.target,finish.targetGen,&target)||!localFindSoul53(&finish,&soul,&gen)||soul){localFinishStore53((LocalFinish53){0});record("defiance-soul-finish-refused target=%u",finish.targetGen);return;}
  finish.posted=true;localFinishStore53(finish);originalComboPost(finish.target,C4_NATIVE_FINISH_POST,C4_NATIVE_FINISH_PAYLOAD);record("defiance-soul-native-finish target=%u",finish.targetGen);return;
 }
 if(!finish.posted||finish.absorbed)return;
 uint32_t state=0;if(!finish.death&&generation(finish.target)==finish.targetGen&&readAt(finish.target+contactPolicy->stateOffset,&state,4)&&state==C4_NATIVE_DEATH_STATE){finish.death=true;record("defiance-soul-native-death target=%u",finish.targetGen);}
 if(!finish.death||age<(uint64_t)sheet_sr1Combat53_fast_force_held_soul.pullMs||(finish.lastPull&&now-finish.lastPull<30)){localFinishStore53(finish);return;}
 uintptr_t soul=0;uint32_t gen=0;if(!localFindSoul53(&finish,&soul,&gen)||!soul||(finish.soul&&(soul!=finish.soul||gen!=finish.soulGen))){localFinishStore53(finish);return;}
 finish.soul=soul;finish.soulGen=gen;finish.lastPull=now;int16_t point[3];if(!readAt(player+0x9c,point,6)||point[2]>INT16_MAX-128)return;point[2]+=128;
 LocalFinishPoint53 bladePoint;AcquireSRWLockShared(&localFinishPointLock53);bladePoint=localFinishPoint53;ReleaseSRWLockShared(&localFinishPointLock53);
 if(sameLocalAction(&bladePoint.owner,f,player,now,128))memcpy(point,bladePoint.point,6);
 localFinishStore53(finish);
 const uintptr_t payload=((uintptr_t(*)(uintptr_t,int32_t,int32_t,int32_t))(base+C4_NATIVE_SOUL_PAYLOAD_RVA))(player,point[0],point[1],point[2]);
 if(payload){originalComboPost(soul,C4_NATIVE_SOUL_INTAKE_POST,payload);record("defiance-soul-native-pull target=%u soul=%u",finish.targetGen,gen);}
}
static bool localFinishReward53(const Sr1LocalFrame*f,uintptr_t soul,uint32_t gen,uintptr_t energy){
 LocalFinish53 finish=localFinishRead53();if(!finish.posted||!finish.death||finish.soul!=soul||finish.soulGen!=gen||!sameLocalAction(&finish.owner,f,player,GetTickCount64(),5000))return false;
 if(finish.absorbed)return true; // Own matching duplicate native receipt without healing/credit again.
 int32_t before=0,after=0,cap=0;int16_t scale=0;uint32_t checked=0;
 if(!localSoulIdentity53(soul,&finish,&checked)||checked!=gen||!readAt(base+0x2a88cd0,&before,4)||!readAt(base+C4_NATIVE_HEALTH_SCALE_RVA,&scale,2)||!c4MaterialReward(before,scale,energy,&after,&cap))return false;
 SIZE_T written=0;if(before!=after&&(!WriteProcessMemory(GetCurrentProcess(),(void*)(base+0x2a88cd0),&after,4,&written)||written!=4))return false;
 finish.absorbed=true;localFinishStore53(finish);record("defiance-soul-native-reward soul=%u before=%ld after=%ld",gen,(long)before,(long)after);return true;
}
