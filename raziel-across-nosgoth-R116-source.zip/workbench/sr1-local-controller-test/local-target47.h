// SPDX-License-Identifier: GPL-3.0-or-later
#pragma once
#include <math.h>
static bool localLockReadTarget47(uintptr_t,const Sr1LocalFrame *,uint32_t *,int16_t[3]);
#ifdef SR1_LOCAL_COMBAT49
static bool localNearestTarget49(const Sr1LocalFrame *,uintptr_t,uintptr_t *,uint32_t *);
#endif
typedef struct {LocalActionOwner owner;uintptr_t target;uint32_t generation;bool held;} LocalTargetLock47;
static SRWLOCK localTargetLock47=SRWLOCK_INIT;
static LocalTargetLock47 localLocked47,localAirFocus47;
#ifdef SR1_LOCAL_COMBAT72
static LocalActionOwner localUnlock72;
#endif
static unsigned localTargetYaw47(const int16_t from[3],const int16_t to[3]) {
 // Equivalent to KAIN2 MATH3D_AngleFromPosToPos: atan2(from.y-to.y,from.x-to.x)+3072.
 return (unsigned)(int)lroundf(atan2f((float)((int)to[0]-from[0]),(float)((int)from[1]-to[1]))*(4096.f/6.2831853071795864769f))&4095u;
}
static LocalTargetLock47 localTargetSnapshot47(bool air) {
 AcquireSRWLockShared(&localTargetLock47);LocalTargetLock47 target=air?localAirFocus47:localLocked47;ReleaseSRWLockShared(&localTargetLock47);return target;
}
static bool localTargetValid47(const LocalTargetLock47 *lock,const Sr1LocalFrame *frame,uintptr_t actor,uint64_t now,int16_t pos[3]) {
 uint32_t generation=0;return lock->target&&sameLocalAction(&lock->owner,frame,actor,now,
#ifdef SR1_LOCAL_COMBAT72
 lock->held?(uint64_t)sheet_sr1Unlock72_explicit_release.heldFreshMs:
#endif
 UINT64_MAX)&&
  localLockReadTarget47(lock->target,frame,&generation,pos)&&generation==lock->generation;
}
static void localTargetInput47(const Sr1LocalFrame *frame,uintptr_t actor,bool held,uint64_t now) {
 LocalTargetLock47 next=localTargetSnapshot47(false);int16_t position[3];
#ifdef SR1_LOCAL_COMBAT49
 (void)position;
#endif
 if(!frame->ready||!frame->renderBlend||localPhysicalCarry(actor)||!held)next=(LocalTargetLock47){0};
 else {
#ifdef SR1_LOCAL_COMBAT49
   next=(LocalTargetLock47){.owner=localActionOwner(frame,actor,now),.held=true};
   localNearestTarget49(frame,actor,&next.target,&next.generation);
#else
  if(!next.held||!localTargetValid47(&next,frame,actor,now,position)){
   next=(LocalTargetLock47){.owner=localActionOwner(frame,actor,now),.held=true};
   uint32_t flags=0;uintptr_t slots=0,target=0;
   if(readAt(base+host->interactionFlagsRva,&flags,4)&&(flags&signals->finishEngagementMask)&&
    readAt(base+host->targetsRva,&slots,8)&&slots&&readAt(slots+signals->finishTargetOffset,&target,8)&&target!=actor&&
    localLockReadTarget47(target,frame,&next.generation,position))next.target=target;
  }
#endif
 }
 AcquireSRWLockExclusive(&localTargetLock47);
#ifdef SR1_LOCAL_COMBAT72
 if(next.held)localUnlock72=(LocalActionOwner){0};
 else if(localLocked47.held){localUnlock72=localActionOwner(frame,actor,now);localAirFocus47=(LocalTargetLock47){0};}
 if(!frame->ready||!frame->renderBlend||localPhysicalCarry(actor))localAirFocus47=(LocalTargetLock47){0};
#endif
 if(next.target!=localLocked47.target||next.generation!=localLocked47.generation||next.held!=localLocked47.held)
  record("defiance-target-lock held=%u target=%u realm=%u",next.held,next.target?next.generation:0,frame->realm);
 localLocked47=next;ReleaseSRWLockExclusive(&localTargetLock47);
}
static void localTargetHit47(LocalActionOwner owner,uintptr_t target,uint32_t generation) {
 AcquireSRWLockExclusive(&localTargetLock47);localAirFocus47=(LocalTargetLock47){.owner=owner,.target=target,.generation=generation};ReleaseSRWLockExclusive(&localTargetLock47);
}
static bool localTargetPosition47(const Sr1LocalFrame *frame,uintptr_t actor,uint64_t now,int16_t pos[3]) {
 const LocalTargetLock47 locked=localTargetSnapshot47(false);
 if(locked.held&&localTargetValid47(&locked,frame,actor,now,pos))return true;
#if defined(SR1_LOCAL_COMBAT49) || defined(SR1_LOCAL_COMBAT72)
 if(locked.held)return false; // No stale out-of-range air focus while nearest-target LB is active.
#endif
 if(frame->airState!=SR1_AIR_JUMP&&frame->airState!=SR1_AIR_FALL)return false;
#ifdef SR1_LOCAL_COMBAT72
 AcquireSRWLockShared(&localTargetLock47);const LocalActionOwner unlock72=localUnlock72;ReleaseSRWLockShared(&localTargetLock47);
 if(sameLocalAction(&unlock72,frame,actor,now,UINT64_MAX))return false;
#endif
 const LocalTargetLock47 air=localTargetSnapshot47(true);
 return now>=air.owner.tick&&now-air.owner.tick<=(uint64_t)sheet_sr1Lock47_locked_combat.flightLimitMs&&localTargetValid47(&air,frame,actor,now,pos);
}
#ifdef SR1_LOCAL_COMBAT48
static bool localRotorYaw48(const Sr1LocalFrame *,uintptr_t,uint64_t,unsigned *);
#endif
static bool localTargetFace47(const Sr1LocalFrame *frame,uintptr_t actor,uint64_t now,unsigned *yaw) {
#ifdef SR1_LOCAL_COMBAT48
 if(frame->ready&&frame->renderBlend&&localRotorYaw48(frame,actor,now,yaw))return true;
#endif
 int16_t target[3],position[3];
 if(!frame->ready||!frame->renderBlend||!localTargetPosition47(frame,actor,now,target)||!readAt(actor+0x9c,position,sizeof(position)))return false;
 if(position[0]==target[0]&&position[1]==target[1])return false;
 *yaw=localTargetYaw47(position,target);return true;
}
static bool localTargetApply47(const Sr1LocalFrame *frame,uintptr_t actor,uint64_t now) {
 unsigned yaw;if(!localTargetFace47(frame,actor,now,&yaw))return false;
 uint16_t angle=(uint16_t)yaw;SIZE_T written=0;
 return WriteProcessMemory(GetCurrentProcess(),(void *)(actor+sheet_sr1GroundSteering_camera_relative_start.yawOffset),&angle,2,&written)&&written==2;
}
