// SPDX-License-Identifier: GPL-3.0-or-later
#pragma once
#ifdef SR1_LOCAL_COMBAT70
#include "local-reaver-toggle70.h"
#endif
// F10 changes are applied on the native pad/game thread. RAM banks and hooks stay
// allocated between sessions; off disables owned gameplay hooks and restores owned fields.
static HANDLE portableToggleEvent60;
static volatile LONG64 portableDebugQueued65;
static bool portableDebugResume65;
static void portableDebugNotice65(const char *text){
 wchar_t file[1200];swprintf(file,ARRAYSIZE(file),L"%ls/shortcuts.txt",portableReports60);
 HANDLE f=CreateFileW(file,GENERIC_WRITE,FILE_SHARE_READ|FILE_SHARE_WRITE,NULL,CREATE_ALWAYS,FILE_ATTRIBUTE_NORMAL,NULL);
 if(f!=INVALID_HANDLE_VALUE){DWORD written=0;WriteFile(f,text,(DWORD)strlen(text),&written,NULL);CloseHandle(f);}
}
static void portableQueueDebug65(LONG command){
 InterlockedExchange64(&portableDebugQueued65,(LONG64)GetTickCount64());InterlockedOr(&portableDebugCommand60,command);
 portableDebugNotice65(command==1?"F6 queued: stand on the ground with gameplay focused.":"F9 queued: stand on the ground with gameplay focused.");
}
static bool portableMenuChord65(void){
 DWORD focus=0;GetWindowThreadProcessId(GetForegroundWindow(),&focus);
 if(focus!=GetCurrentProcessId())return false;
 XINPUT_STATE s={0};const bool padChord=localFormsPad&&localFormsPad(0,&s)==ERROR_SUCCESS&&(s.Gamepad.wButtons&0x6000u)==0x6000u;
 const bool keys=(GetAsyncKeyState('E')&0x8000)&&(GetAsyncKeyState(VK_LBUTTON)&0x8000);
 const bool chord=keys||padChord;static bool held;
 const bool edge=chord&&!held;
#ifdef SR1_BOSS_KAIN93
 if(edge&&kainDebugBusy113()){held=chord;record("kain113 debug-chord ignored-during-encounter=1 mod-kept-on=1");return false;}
#endif
 if(edge){portableDebugResume65=false;portableDebugNotice65("Native Debug requested: mod Off. Use E + left click / B + X to close; F10 resumes the mod.");record("portable-debug-menu native-chord=1 mod-off=1");}
 held=chord;
#ifdef SR1_LOCAL_COMBAT70
 return edge;
#else
 return chord;
#endif
}
static void portableStatus60(const char *text){
 wchar_t file[1200];swprintf(file,ARRAYSIZE(file),L"%ls/status.txt",portableReports60);
 HANDLE f=CreateFileW(file,GENERIC_WRITE,FILE_SHARE_READ|FILE_SHARE_WRITE,NULL,CREATE_ALWAYS,FILE_ATTRIBUTE_NORMAL,NULL);
 if(f!=INVALID_HANDLE_VALUE){DWORD written=0;WriteFile(f,text,(DWORD)strlen(text),&written,NULL);CloseHandle(f);}
}
static bool portableMkdir60(wchar_t *path){
 for(wchar_t *p=path+3;*p;p++)if(*p==L'\\'||*p==L'/'){const wchar_t c=*p;*p=0;CreateDirectoryW(path,NULL);*p=c;}
 return CreateDirectoryW(path,NULL)||GetLastError()==ERROR_ALREADY_EXISTS;
}
static DWORD WINAPI portableKeys60(void *unused){
 (void)unused;bool held=false,reaver=false,powers=false;
#ifdef SR1_LOCAL_COMBAT66
 bool arenaHeld=false;
#endif
 while(true){
  DWORD foreground=0;GetWindowThreadProcessId(GetForegroundWindow(),&foreground);
  const bool focused=foreground==GetCurrentProcessId();
  const bool down=(GetAsyncKeyState(VK_F10)&0x8000)!=0;
  if((focused&&down&&!held)||(portableToggleEvent60&&WaitForSingleObject(portableToggleEvent60,0)==WAIT_OBJECT_0)){
   const LONG wanted=!InterlockedCompareExchange(&portableWanted60,0,0);InterlockedExchange(&portableWanted60,wanted);
   if(!InterlockedCompareExchange(&portableReady60,0,0))portableStatus60(wanted?"Loading resources — activation queued":"Loading resources — mod off");
  }
  const bool r=(GetAsyncKeyState(VK_F6)&0x8000)!=0,p=(GetAsyncKeyState(VK_F9)&0x8000)!=0;
  if(focused&&r&&!reaver)portableQueueDebug65(1);
  if(focused&&p&&!powers)portableQueueDebug65(2);
#ifdef SR1_LOCAL_COMBAT66
  const bool arenaKey=(GetAsyncKeyState(VK_F11)&0x8000)!=0;
  if(focused&&arenaKey&&!arenaHeld)InterlockedExchange(&arenaCommand66,(GetAsyncKeyState(VK_SHIFT)&0x8000)?3:(GetAsyncKeyState(VK_CONTROL)&0x8000)?2:1);
  for(unsigned i=0;focused&&i<3;i++)if(arenaSignals66[i]&&WaitForSingleObject(arenaSignals66[i],0)==WAIT_OBJECT_0)InterlockedExchange(&arenaCommand66,(LONG)i+1);
  arenaHeld=arenaKey;
#endif
  held=down;reaver=r;powers=p;
  // Same SRX -dev flag consumed by its native debug input route. Only the pinned
  // executable is admitted by portableStart60; no on-disk executable is patched.
  const uintptr_t exe=(uintptr_t)GetModuleHandleW(NULL);LONG value=0;
  if(readAt(exe+0x426d3c,&value,4)&&(value==0||value==1))InterlockedCompareExchange((volatile LONG*)(exe+0x426d3c),1,0);
  Sleep(20);
 }
 return 0;
}
static bool portableStart60(void){
 wchar_t exe[1024],module[1024],local[1024],helper[1200],command[3600];char digest[65];
 if(!GetModuleFileNameW(NULL,exe,ARRAYSIZE(exe))||!hashFile(exe,digest)||strcmp(digest,"0fb3aef0530ebf0510191f934dc371b69b43574331d3623eda694b72f060db93"))return false;
 if(!GetModuleFileNameW(portableModule60,module,ARRAYSIZE(module)))return false;
 wchar_t *slash=wcsrchr(module,L'\\');if(!slash)return false;*slash=0;slash=wcsrchr(module,L'\\');if(!slash)return false;*slash=0;
 swprintf(portableRoot60,ARRAYSIZE(portableRoot60),L"%ls\\RazielR60",module);
 if(!GetEnvironmentVariableW(L"LOCALAPPDATA",local,ARRAYSIZE(local)))return false;
 swprintf(portableReports60,ARRAYSIZE(portableReports60),L"%ls\\RazielAcrossNosgoth\\R60\\run-%lu-%llu",local,(unsigned long)GetCurrentProcessId(),(unsigned long long)GetTickCount64());
 if(!portableMkdir60(portableReports60))return false;portableStatus60("Loading resources — mod off");
 swprintf(helper,ARRAYSIZE(helper),L"%ls\\RazielBootstrap.exe",portableRoot60);
 swprintf(command,ARRAYSIZE(command),L"\"%ls\" --pid %lu --root \"%ls\" --data \"%ls\"",helper,(unsigned long)GetCurrentProcessId(),portableRoot60,portableReports60);
 STARTUPINFOW startup={.cb=sizeof startup,.dwFlags=STARTF_USESHOWWINDOW,.wShowWindow=SW_HIDE};PROCESS_INFORMATION process={0};
 if(!CreateProcessW(helper,command,NULL,NULL,FALSE,CREATE_NO_WINDOW,NULL,portableRoot60,&startup,&process)){portableStatus60("Failed: missing or blocked RazielBootstrap.exe");return false;}
 CloseHandle(process.hThread);CloseHandle(process.hProcess);
 wchar_t event[96];swprintf(event,ARRAYSIZE(event),L"Local\\RazielR60Toggle-%lu",(unsigned long)GetCurrentProcessId());portableToggleEvent60=CreateEventW(NULL,FALSE,FALSE,event);
#ifdef SR1_LOCAL_COMBAT66
 for(unsigned i=0;i<3;i++){swprintf(event,ARRAYSIZE(event),L"Local\\RazielArena66-%lu-%u",(unsigned long)GetCurrentProcessId(),i+1);arenaSignals66[i]=CreateEventW(NULL,FALSE,FALSE,event);}
#endif
 HANDLE worker=CreateThread(NULL,0,portableKeys60,NULL,0,NULL);if(worker)CloseHandle(worker);return worker!=NULL;
}
static bool portableFormsProof60(void){
 static const struct{uintptr_t start;unsigned offset,size;unsigned char bytes[16];}patches[]=LOCAL_FORMS_HEALTH_BRANCHES;
 for(unsigned i=0;i<ARRAYSIZE(patches);i++)if(!matches(patches[i].start,patches[i].bytes,patches[i].size))return false;return true;
}
static void portableFormsRestore60(void){
 static const struct{uintptr_t start;unsigned offset,size;unsigned char bytes[16];}patches[]=LOCAL_FORMS_HEALTH_BRANCHES;
 for(unsigned i=0;i<ARRAYSIZE(patches);i++){DWORD flags=0,ignored=0;const uintptr_t at=base+patches[i].start+patches[i].offset;
  if(VirtualProtect((void*)at,1,PAGE_EXECUTE_READWRITE,&flags)){unsigned char expected=0xeb;atomic_compare_exchange_strong((_Atomic unsigned char*)at,&expected,patches[i].bytes[patches[i].offset]);VirtualProtect((void*)at,1,flags,&ignored);FlushInstructionCache(GetCurrentProcess(),(void*)at,1);}
 }
}
static void portableBindingsRestore60(void){
 if(portableBindingsOwned60){const uintptr_t at=(uintptr_t)GetModuleHandleW(NULL)+inputBoundary->tableRva;LocalBinding rows[BINDING_COUNT];
  if(readAt(at,rows,sizeof rows)){for(unsigned i=0;i<BINDING_COUNT;i++){
   if(rows[i].action!=portableBindingsAfter60[i].action)continue;
   if(rows[i].key==portableBindingsAfter60[i].key)rows[i].key=portableBindingsBefore60[i].key;
   if(rows[i].pad==portableBindingsAfter60[i].pad)rows[i].pad=portableBindingsBefore60[i].pad;
  }SIZE_T written=0;WriteProcessMemory(GetCurrentProcess(),(void*)at,rows,sizeof rows,&written);}
 }portableBindingsOwned60=false;InterlockedExchange(&localBindingsReady,0);
}
typedef struct{uint32_t abilities,mirror;int16_t level,fragments;int32_t health;uint16_t mana,capacity;uint32_t gates;}PortablePowers60;
typedef struct{PortablePowers60 before,applied;uintptr_t actor;uint32_t gen,world;bool grant;}PortablePowerState114;
static PortablePowerState114 portablePowerState114;
static bool portablePowerRead60(PortablePowers60 *p){return readAt(base+0x2a88cdc,&p->abilities,4)&&readAt(base+0x3b0d480,&p->mirror,4)&&readAt(base+0x2a88ccc,&p->level,8)&&readAt(base+0x2a88ce8,&p->mana,4)&&readAt(base+44602640u,&p->gates,4);}
static bool portablePowerWrite60(const PortablePowers60 *p){SIZE_T n;return WriteProcessMemory(GetCurrentProcess(),(void*)(base+0x2a88cdc),&p->abilities,4,&n)&&WriteProcessMemory(GetCurrentProcess(),(void*)(base+0x3b0d480),&p->mirror,4,&n)&&WriteProcessMemory(GetCurrentProcess(),(void*)(base+0x2a88ccc),&p->level,8,&n)&&WriteProcessMemory(GetCurrentProcess(),(void*)(base+0x2a88ce8),&p->mana,4,&n)&&WriteProcessMemory(GetCurrentProcess(),(void*)(base+44602640u),&p->gates,4,&n);}
static bool portableDebug60(LONG command){
 if(!command)return true;portableProbe60=true;const Sr1LocalFrame f=readLocalFrame(true);portableProbe60=false;
 PortablePowers60 current={0};bool presentation=f.renderBlend;
#ifdef SR1_BOSS_KAIN93
 presentation|=kainGameplayReady113(&f);
#endif
 if(!f.ready||!f.grounded||!presentation||f.realm==SR1_LOCAL_UNKNOWN||localPhysicalCarry(player)||!portablePowerRead60(&current)||current.health<=0)return false;
 PortablePowers60 desired=current,before=portablePowerState114.before,applied=portablePowerState114.applied;uintptr_t actor=portablePowerState114.actor;uint32_t gen=portablePowerState114.gen,world=portablePowerState114.world;bool grant=portablePowerState114.grant;
#ifdef SR1_LOCAL_COMBAT79
 const Sheet_sr1Services79 *policy79=&sheet_sr1Services79_desktop_services;
#ifdef SR1_BOSS_KAIN93
#include "health96-policy.h"
 policy79=&portableHealthPolicy96;
#endif
 const PortablePowers60 oldBefore79=before,oldApplied79=applied;const uintptr_t oldActor79=actor;const uint32_t oldGen79=gen,oldWorld79=world;const bool oldGrant79=grant;
#endif
 if(command&1){
#ifdef SR1_LOCAL_COMBAT70
  if(current.abilities!=current.mirror)return false;
  desired.abilities=localReaverToggleBits70(current.abilities);desired.mirror=desired.abilities;
#else
  desired.abilities|=0xc08u;desired.mirror|=0xc08u;
#endif
 }
 if((command&2)&&!InterlockedCompareExchange(&portableActive60,0,0)){
  if(grant
#ifdef SR1_LOCAL_COMBAT79
 // The session snapshot survives scene/actor/room changes. Never replace it
 // merely because a granted player was reloaded from another save.
#else
 &&actor==player&&gen==f.playerGeneration&&world==f.worldGeneration&&current.abilities==applied.abilities&&current.mirror==applied.mirror
#endif
 ){desired=before;
#ifndef SR1_LOCAL_COMBAT79
 desired.health=current.health<before.health?current.health:before.health;
#endif
 grant=false;}
  else{before=current;actor=player;gen=f.playerGeneration;world=f.worldGeneration;grant=true;desired.abilities|=33553471u;desired.mirror|=33553471u;
#ifdef SR1_LOCAL_COMBAT79
 desired.level=(int16_t)policy79->maxLevel;desired.fragments=(int16_t)policy79->maxFragments;desired.health=(int32_t)(f.realm==SR1_LOCAL_MATERIAL?policy79->maxMaterialHealth:policy79->maxSpectralHealth);desired.mana=desired.capacity=(uint16_t)policy79->maxMana;
#else
 desired.level=13;desired.fragments=60;desired.health=(f.realm==SR1_LOCAL_MATERIAL?14:1)*100000;desired.mana=desired.capacity=52;
#endif
desired.gates|=4194304u;applied=desired;}
 }
 if((command&2)&&InterlockedCompareExchange(&portableActive60,0,0))return false;
 if(memcmp(&current,&desired,sizeof current)&&!portablePowerWrite60(&desired)){portablePowerWrite60(&current);
#ifdef SR1_LOCAL_COMBAT79
  before=oldBefore79;applied=oldApplied79;actor=oldActor79;gen=oldGen79;world=oldWorld79;grant=oldGrant79;
#endif
  portableDebugNotice65("Shortcut failed: native progress write refused.");return true;}
 uintptr_t blade=0;if(readAt(base+host->reaverRva,&blade,8)&&!localPhysicalCarry(player)&&(!blade||!(desired.abilities&8u))){((void(*)(uintptr_t))(base+0xe77f0))(player);portablePowerWrite60(&desired);}
 #ifdef SR1_LOCAL_COMBAT79
 PortablePowers60 actual79={0};
 if(!portablePowerRead60(&actual79)||memcmp(&actual79,&desired,sizeof desired)){portablePowerWrite60(&current);before=oldBefore79;applied=oldApplied79;actor=oldActor79;gen=oldGen79;world=oldWorld79;grant=oldGrant79;portableDebugNotice65("Shortcut failed: values did not verify.");return true;}
 record("portable-powers79 command=%ld health=%ld level=%d fragments=%d mana=%u capacity=%u realm=%u",command,(long)actual79.health,actual79.level,actual79.fragments,actual79.mana,actual79.capacity,f.realm);
 record("portable-powers97 grant=%u snapshot-hp=%ld snapshot-level=%d snapshot-mana=%u actual-hp=%ld actual-level=%d actual-mana=%u",grant,(long)before.health,before.level,before.mana,(long)actual79.health,actual79.level,actual79.mana);
#endif
 portablePowerState114=(PortablePowerState114){before,applied,actor,gen,world,grant};
 portableDebugNotice65((command&2)?(grant?"F9 On: all powers, maximum HP and mana filled. Press F9 again to restore.":"F9: previous progress restored for this session."):
#ifdef SR1_LOCAL_COMBAT70
  (desired.abilities&0x800u?"F6: Reaver On.":"F6: Reaver Off - native unarmed combat available.")
#else
  "F6: base Reaver unlocked (including native acquisition flags)."
#endif
 );
 record("portable-debug reaver=%u powers=%u abilities=%x",(command&1)!=0,(command&2)!=0,desired.abilities);
 return true;
}
static void portableCleanup60(void){
#ifdef SR1_SLUAGH_TEST80
 sluaghCleanup80();
#endif
#ifdef SR1_LOCAL_COMBAT66
 arenaCleanup66();
#endif
 localReleaseStuns62();memset(localForceThrows62,0,sizeof localForceThrows62);
 // Called only on the same thread that owns the authored movement/controllers.
 releaseStrikeMotion();maintainingStrikeVector=false;guardRoot=(LocalActionOwner){0};memset(&strikeCursor,0,sizeof strikeCursor);memset(&specialDrive,0,sizeof specialDrive);memset(&dodgeMotion,0,sizeof dodgeMotion);
 localCameraRestore50();localCancelCombo57();cancelLocalDodge();
 AcquireSRWLockExclusive(&localCombatInputLock);memset(&combatInput,0,sizeof combatInput);ReleaseSRWLockExclusive(&localCombatInputLock);
 AcquireSRWLockExclusive(&localSpecialLock);memset(&localSpecial,0,sizeof localSpecial);memset(&specialRecovery,0,sizeof specialRecovery);specialFollowup=(LocalActionOwner){0};ReleaseSRWLockExclusive(&localSpecialLock);
 AcquireSRWLockExclusive(&localAirStrikeLock);memset(&localAirStrike,0,sizeof localAirStrike);ReleaseSRWLockExclusive(&localAirStrikeLock);
 AcquireSRWLockExclusive(&localAirSlamLock);memset(&localAirSlam,0,sizeof localAirSlam);ReleaseSRWLockExclusive(&localAirSlamLock);
 AcquireSRWLockExclusive(&localTargetLock47);memset(&localLocked47,0,sizeof localLocked47);memset(&localAirFocus47,0,sizeof localAirFocus47);ReleaseSRWLockExclusive(&localTargetLock47);
#ifdef SR1_LOCAL_COMBAT72
 AcquireSRWLockExclusive(&localTargetLock47);localUnlock72=(LocalActionOwner){0};ReleaseSRWLockExclusive(&localTargetLock47);
#endif
 AcquireSRWLockExclusive(&localContactDrawLock);memset(&localContactDraw,0,sizeof localContactDraw);memset(&localPreviousDraw48,0,sizeof localPreviousDraw48);ReleaseSRWLockExclusive(&localContactDrawLock);
 memset(localTickets,0,sizeof localTickets);memset(localHitReceipts48,0,sizeof localHitReceipts48);memset(localForceShots53,0,sizeof localForceShots53);memset(&localFlight,0,sizeof localFlight);memset(&localFlightTicket,0,sizeof localFlightTicket);memset(&localRoll50,0,sizeof localRoll50);
 localFinishStore53((LocalFinish53){0});localDrainHold53=(LocalDrainHold53){0};localDodgeQueue56=(LocalDodgeQueue56){0};localDodgeRequest56=(LocalDodgeQueue56){0};localHold48=(C5XHold){0};localCast48=(LocalChargeView48){0};
 AcquireSRWLockExclusive(&localChargeLock48);localChargeView48=(LocalChargeView48){0};ReleaseSRWLockExclusive(&localChargeLock48);
 AcquireSRWLockExclusive(&localAudioLock);localAudioRead=localAudioWrite;ReleaseSRWLockExclusive(&localAudioLock);InterlockedExchange64(&localAudioHeartbeat,0);
 InterlockedExchange64(&groundIntentTick,0);InterlockedExchange64(&groundStartRequested,0);InterlockedExchange(&fullGroundIntent,0);guardFacing=(LocalActionOwner){0};groundAim=(LocalActionOwner){0};
 portableBindingsRestore60();portableFormsRestore60();
}
static void portableFrame60(void){
 if(!InterlockedCompareExchange(&portableReady60,0,0))return;
 LONG debug=InterlockedCompareExchange(&portableDebugCommand60,0,0);
 if(debug&&GetTickCount64()-(uint64_t)InterlockedCompareExchange64(&portableDebugQueued65,0,0)>5000){
  InterlockedExchange(&portableDebugCommand60,0);debug=0;portableDebugNotice65("Shortcut expired: close menus, stand on the ground and press F6/F9 again.");
  if(portableDebugResume65){InterlockedExchange(&portableWanted60,1);portableDebugResume65=false;}
 }
 if((debug&
#ifdef SR1_LOCAL_COMBAT70
  3
#else
  2
#endif
  )&&InterlockedCompareExchange(&portableActive60,0,0)){
  portableDebugResume65=InterlockedCompareExchange(&portableWanted60,0,0)!=0;InterlockedExchange(&portableWanted60,0);
 }
 const bool wanted=InterlockedCompareExchange(&portableWanted60,0,0)!=0,active=InterlockedCompareExchange(&portableActive60,0,0)!=0;
 if(active&&!wanted){
#ifdef SR1_BOSS_KAIN93
  const bool keep113=debug&&portableDebugResume65&&kainShortcutBegin113();
#endif
  portableCleanup60();InterlockedExchange(&portableActive60,0);
#ifdef SR1_BOSS_KAIN93
  if(keep113)kainShortcutEnd113();
#endif
  MH_QueueDisableHook(MH_ALL_HOOKS);MH_QueueEnableHook((void*)(base+pad->composerRva));const MH_STATUS result=MH_ApplyQueued();
  portableStatus60(result==MH_OK?"Off — native SR1":"Failed: hook suspension");record("portable-toggle active=0 native=1 result=%u",(unsigned)result);
 }else if(wanted&&!active){
  if(!localFormsPrepare()){InterlockedExchange(&portableWanted60,0);portableStatus60("Failed: owned health boundary");return;}
  MH_QueueEnableHook(MH_ALL_HOOKS);const MH_STATUS result=MH_ApplyQueued();
  if(result==MH_OK){InterlockedExchange(&portableActive60,1);portableStatus60("On — F10 to disable");record("portable-toggle active=1 result=0");}
  else{portableFormsRestore60();InterlockedExchange(&portableWanted60,0);portableStatus60("Failed: hook activation");}
 }
 if(debug&&portableDebug60(debug)){
  InterlockedAnd(&portableDebugCommand60,~debug);
  if(portableDebugResume65){InterlockedExchange(&portableWanted60,1);portableDebugResume65=false;}
 }
}
