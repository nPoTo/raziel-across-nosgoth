// SPDX-License-Identifier: GPL-3.0-or-later
#pragma once
#define LOCAL_DEBUG70_SHA "83c5ac94e92119622e56add1f166a8a718f22957d081f91ba964029dfeafdb8c"
