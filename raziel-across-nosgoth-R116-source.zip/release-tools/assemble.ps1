param([switch]$Refresh)
$ErrorActionPreference='Stop'
Add-Type -AssemblyName System.IO.Compression.FileSystem
$releaseRoot116=Split-Path (Split-Path $PSScriptRoot)
$stage116=Join-Path $PSScriptRoot 'build'
$source116=Join-Path $stage116 'source'
$payload116=Join-Path $stage116 'payload'
$publish116=Join-Path $releaseRoot116 'output/R116'
function Hash116([string]$file){(Get-FileHash -LiteralPath $file).Hash.ToLowerInvariant()}
function Zip116([string]$directory,[string]$destination,[switch]$Sources){
 if(Test-Path -LiteralPath $destination){throw "Archive already exists $destination"}
 $zip116=[IO.Compression.ZipFile]::Open($destination,[IO.Compression.ZipArchiveMode]::Create)
 try{foreach($file116 in Get-ChildItem -LiteralPath $directory -Recurse -File){
  $relative116=[IO.Path]::GetRelativePath($directory,$file116.FullName).Replace('\','/')
  if($Sources -and ($relative116.StartsWith('rebuilt-helpers/') -or $file116.Extension -in '.exe','.asi','.dll','.pdb','.d')){continue}
  [IO.Compression.ZipFileExtensions]::CreateEntryFromFile($zip116,$file116.FullName,$relative116,[IO.Compression.CompressionLevel]::Optimal)|Out-Null
 }}finally{$zip116.Dispose()}
}
$native116=Join-Path $source116 'workbench/defiance-kain-r1/build/gameplay80/SR1LocalController.asi'
Copy-Item -LiteralPath $native116 -Destination (Join-Path $payload116 'scripts/SR1LocalController.asi')
foreach($name116 in 'RazielBootstrap.exe','RazielUpdater.exe','Uninstall R60.exe'){
 Copy-Item -LiteralPath (Join-Path $source116 "rebuilt-helpers/$name116") -Destination (Join-Path $payload116 "RazielR60/$name116")
}
$runtimeManifest116='RazielR60/runtime/workbench/sr1-local-controller-test/build/defiance-combat-r60/host-manifest.json'
$manifest116=Get-Content -LiteralPath (Join-Path $payload116 $runtimeManifest116) -Raw|ConvertFrom-Json
$manifest116.sha256=Hash116 $native116
$manifest116|Add-Member -NotePropertyName release -NotePropertyValue 'R116' -Force
$manifest116|ConvertTo-Json -Depth 20 -Compress|Set-Content -LiteralPath (Join-Path $payload116 $runtimeManifest116) -Encoding utf8NoBOM
Copy-Item -LiteralPath (Join-Path $payload116 $runtimeManifest116) -Destination (Join-Path $source116 'runtime/workbench/sr1-local-controller-test/build/defiance-combat-r60/host-manifest.json')
$credits116=Join-Path $payload116 'RazielR60/licenses/CREDITS.txt'
[IO.File]::WriteAllText($credits116,[IO.File]::ReadAllText($credits116).Replace('R79','R116'))
foreach($file116 in 'prepare.mjs','assemble.ps1','serve-release116.mjs','scope.json'){
 $tools116=Join-Path $source116 'release-tools'
 New-Item -ItemType Directory -Force -Path $tools116|Out-Null
 Copy-Item -LiteralPath (Join-Path $PSScriptRoot $file116) -Destination (Join-Path $tools116 $file116)
}
Copy-Item -LiteralPath (Join-Path $publish116 '03-GitHub/repository/README.txt') -Destination (Join-Path $payload116 'RazielR60/README.txt')
$sourceZip116=Join-Path $publish116 '03-GitHub/raziel-across-nosgoth-R116-source.zip'
Zip116 $source116 $sourceZip116 -Sources
Copy-Item -LiteralPath $sourceZip116 -Destination (Join-Path $payload116 'RazielR60/SOURCE.zip') -Force
$inventory116=@(Get-ChildItem -LiteralPath $payload116 -Recurse -File|Where-Object FullName -ne (Join-Path $payload116 'RazielR60/package.json')|ForEach-Object{
 @{path=[IO.Path]::GetRelativePath($payload116,$_.FullName).Replace('\','/');sha256=Hash116 $_.FullName}
})
@{version='R116';files=$inventory116}|ConvertTo-Json -Depth 8|Set-Content -LiteralPath (Join-Path $payload116 'RazielR60/package.json') -Encoding utf8NoBOM
$payloadZip116=Join-Path $publish116 '01-Copy-Paste/R116-Copy-Paste.zip'
Zip116 $payload116 $payloadZip116
& (Join-Path $source116 'Build-Helpers.ps1') -PayloadZip $payloadZip116
if($LASTEXITCODE -ne 0){throw 'Setup rebuild failed'}
$installer116=Join-Path $publish116 '02-Installer/Raziel R116 Setup.exe'
Copy-Item -LiteralPath (Join-Path $source116 'rebuilt-helpers/Raziel R116 Setup.exe') -Destination $installer116
Copy-Item -LiteralPath $installer116 -Destination (Join-Path $publish116 '03-GitHub/Raziel.R116.Setup.exe')
$wrapper116=Join-Path $stage116 'installer-wrapper'
New-Item -ItemType Directory -Force -Path $wrapper116|Out-Null
Copy-Item -LiteralPath $installer116 -Destination $wrapper116
Copy-Item -LiteralPath (Join-Path $publish116 '02-Installer/README.txt') -Destination $wrapper116
Zip116 $wrapper116 (Join-Path $publish116 '03-GitHub/Raziel-R116-Installer.zip')
$checks116=@('Raziel-R116-Installer.zip','Raziel.R116.Setup.exe','raziel-across-nosgoth-R116-source.zip')|ForEach-Object{
 (Hash116 (Join-Path $publish116 "03-GitHub/$_"))+'  '+$_
}
$checks116|Set-Content -LiteralPath (Join-Path $publish116 '03-GitHub/SHA256SUMS.txt') -Encoding utf8NoBOM
Copy-Item -LiteralPath $sourceZip116 -Destination (Join-Path $publish116 '03-GitHub/repository/raziel-across-nosgoth-R116-source.zip')
Copy-Item -LiteralPath (Join-Path $publish116 '03-GitHub/SHA256SUMS.txt') -Destination (Join-Path $publish116 '03-GitHub/repository/SHA256SUMS.txt')
@{release='R116';nativeSHA256=(Hash116 $native116);packageFiles=$inventory116.Count;directInstallerBytes=(Get-Item $installer116).Length;sourceSHA256=(Hash116 $sourceZip116)}|ConvertTo-Json|Set-Content -LiteralPath (Join-Path $releaseRoot116 'reports/release116/assembled.json')
Get-Content -LiteralPath (Join-Path $releaseRoot116 'reports/release116/assembled.json')
