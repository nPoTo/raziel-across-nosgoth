// SPDX-License-Identifier: GPL-3.0-or-later
import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import assert from 'node:assert/strict';
import {checkSheets} from '../../tools/preflight-sheets.mjs';
const root=path.resolve(import.meta.dirname,'../..'),local=root+'/workbench/sr1-local-controller-test';
const legacy=local+'/build/defiance-combat-r60',boss=root+'/workbench/defiance-kain-r1/build/gameplay80';
const stage=root+'/workbench/release116/build',payload=stage+'/payload',source=stage+'/source',runtime=payload+'/RazielR60/runtime';
const hash=f=>crypto.createHash('sha256').update(fs.readFileSync(f)).digest('hex');
const copy=(a,b)=>{fs.mkdirSync(path.dirname(b),{recursive:true});fs.copyFileSync(a,b);};
const text=(f,s)=>{fs.mkdirSync(path.dirname(f),{recursive:true});fs.writeFileSync(f,s);};
const walk=d=>fs.readdirSync(d,{withFileTypes:true}).flatMap(e=>e.isDirectory()?walk(d+'/'+e.name):[d+'/'+e.name]);
assert.deepEqual(checkSheets(JSON.parse(fs.readFileSync(root+'/workbench/release116/scope.json'))),[]);
fs.mkdirSync(stage);
// Read the verified previous complete public payload and retain its layout.
fs.cpSync(legacy+'/package79/payload',payload,{recursive:true});
fs.cpSync(legacy+'/package79/source',source,{recursive:true});
fs.mkdirSync(stage+'/baseline');
copy(boss+'/manifest.json',stage+'/baseline/manifest.json');copy(boss+'/SR1LocalController.asi',stage+'/baseline/SR1LocalController.asi');
const includes=[],args=JSON.parse(fs.readFileSync(boss+'/compile-args.json'));
for(let i=0;i<args.length;i++)if(args[i]==='-I')includes.push(path.resolve(root,args[++i]));
const collected=new Set();
function collect(f){
 f=path.resolve(f);if(collected.has(f))return;assert(f.startsWith(root+path.sep));collected.add(f);
 let content=fs.readFileSync(f,'utf8');
 if(f.endsWith('host-proof.h'))content=content.replace(/^#define REPORT_PATH .*$/m,'#define REPORT_PATH L"."');
 text(source+'/'+path.relative(root,f),content);
 for(const m of content.matchAll(/^\s*#\s*include\s*"([^"]+)"/gm)){
  const found=[path.dirname(f),...includes].map(d=>path.join(d,m[1])).find(p=>fs.existsSync(p));
  if(found)collect(found);
 }
}
for(const f of args.filter(a=>/\.(c|S)$/.test(a)))collect(root+'/'+f);
for(const f of ['resource-scope.json','gameplay-scope.json'])copy(root+'/workbench/defiance-kain-r1/'+f,source+'/workbench/defiance-kain-r1/'+f);
// The complete old source archive supplies helper artwork and licenses.
for(const name of ['Version79.cs','UpdateCore79.cs','Updater79.cs','UpdateInstall79.cs','PortableCore60.cs','Bootstrap60.cs','InstallEngine60.cs','Setup60.cs','Uninstall60.cs']){
 let content=fs.readFileSync(local+'/'+name,'utf8');
 if(name==='Version79.cs')content=content.replace('Number=79','Number=116').replace('"R79"','"R116"');
 if(['Bootstrap60.cs','Setup60.cs','InstallEngine60.cs'].includes(name))content=content.replaceAll('R79','R116');
 if(name==='Bootstrap60.cs'){
  const anchor='PortableCore60.SaveDonor(donor);';
  assert(content.includes(anchor));
  content=content.replace(anchor,anchor+'File.WriteAllText(Path.Combine(data,"defiance-exe.txt"),Path.Combine(donor,"defiance.exe"),Encoding.Unicode);');
  content=content.replace('"sr1-local-controller-test","serve-ground-poses.mjs"','"release116","serve-release116.mjs"');
 }
 text(source+'/portable/'+name,content);
}
// The native AI must use the exact executable selected by the installer.
const nativeFile=source+'/workbench/defiance-kain-r1/gameplay80.h';
let native=fs.readFileSync(nativeFile,'utf8');
const oldLine=native.split('\n').find(l=>l.includes('const wchar_t *exe='));
assert(oldLine&&oldLine.includes('defiance.exe'));
native=native.replace(oldLine,` wchar_t configPath[1400],exeBuffer[1025]={0};char digest[65];
 swprintf(configPath,ARRAYSIZE(configPath),L"%ls/defiance-exe.txt",portableReports60);
 HANDLE pathFile=CreateFileW(configPath,GENERIC_READ,FILE_SHARE_READ,NULL,OPEN_EXISTING,FILE_ATTRIBUTE_NORMAL,NULL);
 if(pathFile==INVALID_HANDLE_VALUE)return 0;
 const DWORD pathBytes=GetFileSize(pathFile,NULL);DWORD pathRead=0;
 const bool pathValid=pathBytes>=4&&pathBytes<=2048&&!(pathBytes&1)&&ReadFile(pathFile,exeBuffer,pathBytes,&pathRead,NULL)&&pathRead==pathBytes;
 CloseHandle(pathFile);if(!pathValid)return 0;
 const wchar_t *exe=exeBuffer[0]==0xfeff?exeBuffer+1:exeBuffer;
 if(!*exe||wcslen(exe)!=(size_t)(pathBytes/2-(exe!=exeBuffer)))return 0;`);
text(nativeFile,native);
// Runtime JS closure. Do not include research scripts, captures or decoded assets.
const modules=new Set();
function js(f){
 f=path.resolve(f);if(modules.has(f))return;modules.add(f);assert(f.startsWith(root+path.sep));
 const content=fs.readFileSync(f,'utf8');const rel=path.relative(root,f).replaceAll('\\','/');
 text(runtime+'/'+rel,content);
 for(const m of content.matchAll(/(?:from\s*|import\s*\()(['"])([^'"]+)\1/g)){
  if(!m[2].startsWith('.'))continue;const next=path.resolve(path.dirname(f),m[2]);if(next.endsWith('.mjs'))js(next);
 }
}
js(root+'/workbench/release116/serve-release116.mjs');
for(const name of ['resource-scope.json','gameplay-scope.json'])copy(root+'/workbench/defiance-kain-r1/'+name,runtime+'/workbench/defiance-kain-r1/'+name);
// Replace evidence links to private reports with a scalar provenance ledger.
const ledger=[];
for(const file of walk(runtime).filter(f=>f.endsWith('.json'))){
 let d;try{d=JSON.parse(fs.readFileSync(file));}catch{continue;}
 if(d.schemaVersion!==2||!d.tables)continue;
 for(const [table,t]of Object.entries(d.tables))for(const [index,row]of t.rows.entries())for(const [column,cell]of Object.entries(row.cells||{})){
  if(!cell.artifact)continue;ledger.push({sheet:path.relative(runtime,file),table,row:index,column,artifact:cell.artifact,evidence:cell.evidence});
  cell.artifact='config/r116-provenance.json';
 }
 text(file,JSON.stringify(d));
}
text(runtime+'/config/r116-provenance.json',JSON.stringify({scope:'Scalar policy provenance; gameplay acceptance is limited to documented creator tests.',cells:ledger}));
// Runtime configuration remains relative and receives selected installation paths.
text(payload+'/RazielR60/version.txt','R116\n');
text(payload+'/RazielR60/GUIDE.txt',fs.readFileSync(local+'/R79-GUIDE.txt','utf8').replaceAll('R79','R116')+'\nKain encounter: the first Pillars fight uses the new Kain while F10 is On. The original scenes and story continue. During this fight your hidden HP capacity is 500,000; the visible spiral keeps its previous size. Your pre-door status returns before the ending scene. Debug shortcuts are unavailable during the replacement fight.\n');
for(const f of walk(runtime)){const rel=path.relative(runtime,f);copy(f,source+'/runtime/'+rel);}
const cleanArgs=[];for(let i=0;i<args.length;i++){if(args[i]==='-MMD')continue;if(args[i]==='-MF'){i++;continue;}cleanArgs.push(args[i]);}
text(source+'/compile-args.json',JSON.stringify(cleanArgs,null,2));
let recipe=fs.readFileSync(source+'/Build-Native.ps1','utf8').replace("try {","try {\n New-Item -ItemType Directory -Force -Path (Join-Path $PSScriptRoot 'workbench/defiance-kain-r1/build/gameplay80') | Out-Null");
text(source+'/Build-Native.ps1',recipe);
text(source+'/Build-Helpers.ps1',fs.readFileSync(source+'/Build-Helpers.ps1','utf8').replaceAll('R79','R116'));
text(stage+'/preparation.json',JSON.stringify({nativeFiles:collected.size,runtimeModules:modules.size,baselineNative:hash(boss+'/SR1LocalController.asi'),sourceRoot:source,payloadRoot:payload},null,2));
console.log(JSON.stringify({stage,nativeFiles:collected.size,runtimeModules:modules.size}));
