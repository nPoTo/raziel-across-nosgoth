param([string]$Compiler='clang.exe')
$ErrorActionPreference='Stop'
Push-Location $PSScriptRoot
try {
 New-Item -ItemType Directory -Force -Path (Join-Path $PSScriptRoot 'workbench/defiance-kain-r1/build/gameplay80') | Out-Null
 New-Item -ItemType Directory -Force -Path (Join-Path $PSScriptRoot 'workbench/sr1-local-controller-test/build/defiance-combat-r60') | Out-Null
 $compileArgs=Get-Content -LiteralPath (Join-Path $PSScriptRoot 'compile-args.json') -Raw | ConvertFrom-Json
 & $Compiler @compileArgs
 if($LASTEXITCODE -ne 0){throw 'Native compilation failed'}
} finally { Pop-Location }
