// SPDX-License-Identifier: GPL-3.0-or-later
#pragma once
// Independent read-only loader: never relies on retired overlay initialization.
typedef struct {GLuint program,shader;GLint type;GLsizei length;char *source;} ShaderRecord;
static PFNGLGETATTACHEDSHADERSPROC shaderAttached;
static PFNGLGETSHADERSOURCEPROC shaderSource;
static PFNGLGETSHADERIVPROC shaderQuery;
static bool shaderAttempted,shaderReady;
static void shaderInit(void) {
    if(shaderAttempted)return;shaderAttempted=true;
    PROC attached=wglGetProcAddress("glGetAttachedShaders"),source=wglGetProcAddress("glGetShaderSource"),query=wglGetProcAddress("glGetShaderiv");
    if(!query||(uintptr_t)query<=3||(uintptr_t)query==UINTPTR_MAX||!attached||!source||(uintptr_t)attached<=3||(uintptr_t)source<=3||(uintptr_t)attached==UINTPTR_MAX||(uintptr_t)source==UINTPTR_MAX)return;
    shaderQuery=(PFNGLGETSHADERIVPROC)query;shaderAttached=(PFNGLGETATTACHEDSHADERSPROC)attached;shaderSource=(PFNGLGETSHADERSOURCEPROC)source;shaderReady=true;
}
static bool shaderRead(GLuint program,GLuint shader,ShaderRecord *record) {
    if(!record||!shaderReady||!shaderQuery||!shaderSource)return false;
    GLint size=0,type=0;shaderQuery(shader,GL_SHADER_SOURCE_LENGTH,&size);shaderQuery(shader,GL_SHADER_TYPE,&type);
    if(size<2||size>65536||(type!=GL_VERTEX_SHADER&&type!=GL_FRAGMENT_SHADER&&type!=GL_GEOMETRY_SHADER))return false;
    char *source=HeapAlloc(GetProcessHeap(),HEAP_ZERO_MEMORY,(SIZE_T)size);if(!source)return false;
    GLsizei length=0;shaderSource(shader,size,&length,source);
    if(length<=0||length>=size||source[length]||memchr(source,0,(size_t)length)){HeapFree(GetProcessHeap(),0,source);return false;}
    *record=(ShaderRecord){program,shader,type,length,source};return true;
}
