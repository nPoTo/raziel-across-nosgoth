// SPDX-License-Identifier: GPL-3.0-or-later
import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import assert from 'node:assert/strict';
import {parseSr1Srm} from '../../tools/sr1-srm.mjs';
import {decodeMip} from '../../tools/memory-render-packets.mjs';

// Decoded original geometry and texture stay in the RAM resource stream.
export function buildEyes76(host){
 const mesh=parseSr1Srm(fs.readFileSync(path.join(host,'1/OBJECT/RAZIEL_1.SRM')));
 const dds=fs.readFileSync(path.join(host,'1/TEX/RAZIEL_4_E.DDS'));
 const pixels=decodeMip({format:'DXT1',side:512,bytes:dds.subarray(128,128+512*512/2)});
 const mask=Buffer.alloc(pixels.length);let lit=0;
 for(let i=0;i<pixels.length;i+=4){
  mask[i]=mask[i+1]=mask[i+2]=255;
  mask[i+3]=Math.max(...pixels.subarray(i,i+3))>=24?255:0;
  if(mask[i+3])lit++;
 }
 const head=i=>mesh.materials[i]===2&&mesh.weights[i].some((w,k)=>w===255&&mesh.palette[mesh.joints[i][k]]===18);
 const triangles=[];
 for(let i=0;i<mesh.indices.length;i+=3){
  const tri=mesh.indices.slice(i,i+3);if(tri.every(head))triangles.push(...tri);
 }
 const unique=[...new Set(triangles)],map=new Map(unique.map((id,i)=>[id,i]));
 assert(unique.length>100&&unique.length<=2048&&triangles.length<16384&&lit>0);
 const packet=Buffer.alloc(8+unique.length*36+triangles.length*2+mask.length);
 packet.writeUInt32LE(unique.length);packet.writeUInt32LE(triangles.length,4);
 for(const [index,id] of unique.entries()){
  const p=mesh.positions[id].map((v,k)=>v+mesh.bindOffsets[18][k]);
  // Separate from the original surface without changing the silhouette appreciably.
  p[1]-=.2;
  const values=[...p,...mesh.uvs[id],1,1,1,1];
  for(const [k,value] of values.entries())packet.writeFloatLE(value,8+index*36+k*4);
 }
 triangles.forEach((id,i)=>packet.writeUInt16LE(map.get(id),8+unique.length*36+i*2));
 mask.copy(packet,8+unique.length*36+triangles.length*2);
 return {packet,hash:crypto.createHash('sha256').update(packet).digest('hex'),vertices:unique.length,indices:triangles.length,lit};
}
