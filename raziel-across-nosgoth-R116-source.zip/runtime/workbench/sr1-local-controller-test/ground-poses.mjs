// SPDX-License-Identifier: GPL-3.0-or-later
import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import { composeRig } from '../../tools/retarget-pose.mjs';
import { checkSheets } from '../../tools/preflight-sheets.mjs';
import { parseSr1Srm } from '../../tools/sr1-srm.mjs';
import { readInstalledSr1Rig } from '../../tools/sr1-offline-rig.mjs';
import { compileSr1MotionControls } from '../../tools/sr1-motion-controls.mjs';
import { compileSkeletonAlignment, alignSr1Skeleton } from '../../tools/sr1-skeleton-alignment.mjs';
import * as releaseAlignment from '../reaver-force-on-r20/tools/sr1-skeleton-alignment.mjs';
import {compilePelvisTrajectory} from '../reaver-force-on-r20/tools/skeleton-pelvis-trajectory.mjs';
import {skeletonSoleReference} from '../reaver-force-on-r20/tools/sr1-skeleton-ground.mjs';
import {groundSoleCoefficients, prepareGroundSupport} from './ground-calibration.mjs';
import { decodeDefianceClip, readDefianceMotion, sampleDefiancePose } from './defiance-motion.mjs';
import { combatPelvisTwist, restoreCombatTwist } from '../reaver-force-on-r20/tools/combat-body-frame.mjs';

export const groundPosePipe = pid => `\\\\.\\pipe\\RazielSR1GroundMotion-${pid}`;

const root = path.resolve(import.meta.dirname, '../..');
const read = file => JSON.parse(fs.readFileSync(path.join(root, file), 'utf8'));
function sheet(file) {
    const document = read(file);
    assert.deepEqual(checkSheets(document), [], file);
    return document.tables;
}
const values = table => table.rows.map(row => row.values);

export function buildGroundPoses({blend = false, calibrated = false, authored = false, responsive = false,
    jumping = false, combat = false, combatTravel = false, combatCombo = false, combatPresentation = false,
    authoredBladeSocket = false, measuredGroundCombo = false, nativeCombatControls = false,
    guardDirections = false, groundActions = false, airStrikes = false, calibratedCombat = false, specialCombat = false, repairCombat = false,
    bodyAxis = false, separateRotor = false, charged = false,utility53=false,utility57=false,contextOpeners=[]} = {}) {
    const profile = values(sheet('workbench/sr1-local-controller-test/defiance-motion-scope.json').defianceLocalMotion)[0];
    const idles = groundActions
        ? values(sheet('workbench/sr1-local-controller-test/local-ground-actions-scope.json').sr1LocalIdleClips)
            .sort((a, b) => a.ordinal - b.ordinal)
        : [];
    const games = Object.fromEntries(read('config/games.json').games.map(game => [game.id, game.directory]));
    const combatPolicy = combat ? values(sheet('workbench/sr1-local-controller-test/local-combat-scope.json').sr1LocalCombat)[0] : null;
    const air = airStrikes ? values(sheet('workbench/sr1-local-controller-test/local-air-strike-scope.json').sr1LocalAirStrikeClip)
        .sort((a, b) => a.ordinal - b.ordinal) : [];
    if (combat && combatTravel) {
        combatPolicy.travel = values(sheet('workbench/sr1-local-controller-test/local-strike-travel-scope.json').sr1LocalStrikeTravel)[0];
    }
    if (combat && combatCombo) {
        combatPolicy.combo = [...values(sheet('workbench/sr1-local-controller-test/local-strike-combo-scope.json').sr1LocalStrikeCombo),
            ...air];
    }
    const directions = guardDirections ?
        values(sheet('workbench/sr1-local-controller-test/local-guard-direction-scope.json').sr1LocalGuardDirection) : [];
    const dodges = calibratedCombat ?
        values(sheet(repairCombat ? 'workbench/sr1-local-controller-test/local-combat-repair-scope.json' :
            'workbench/sr1-local-controller-test/local-combat-calibration-scope.json').sr1CombatDodgeReference) : [];
    const specials = specialCombat ?
        values(sheet('workbench/sr1-local-controller-test/local-special-banks-scope.json').sr1LocalSpecialBanks) : [];
    const chargeClips=charged?values(sheet("workbench/sr1-local-controller-test/local-combat-r48-scope.json").sr1ChargeClip48):[];
    if(utility53){const p=values(sheet('workbench/sr1-local-controller-test/local-combat-r53-scope.json').sr1Combat53)[0];chargeClips.push({runtimeClip:p.runtimeClip,archiveKey:p.archiveKey,clipKeys:p.clipKeys});}
    if(utility57)chargeClips.push(...values(sheet("workbench/sr1-local-controller-test/local-combat-r57-scope.json").sr1ExtraClips57));
    chargeClips.push(...contextOpeners);
    const {clips, rig, strikeKey, strikeTravel, strikeCombo} = readDefianceMotion(games.defiance, profile, combatPolicy,
        [...directions, ...idles, ...dodges, ...specials,...chargeClips]);
    const mesh = parseSr1Srm(fs.readFileSync(path.join(games['soul-reaver'], '1/OBJECT/RAZIEL_1.SRM')));
    const host = readInstalledSr1Rig(games['soul-reaver'], values(sheet('config/sheets/retarget-rig.json').retargetOfflineRig)[0], mesh);
    const source = composeRig({parents: rig.parents, local: rig.rest}, {position: [0,0,0], rotation: [0,0,0,1]});
    const controlsSheet = sheet('config/sheets/retarget-motion-controls.json');
    const alignmentSheet = sheet('config/sheets/skeleton-alignment.json');
    const rigs = {hostParents: host.parents, hostBind: host.positions, sourceParents: rig.parents,
        sourceBind: source.map(bone => bone.position)};
    const {controls} = compileSr1MotionControls({...rigs, rows: values(controlsSheet.motionControls),
        chains: values(controlsSheet.motionControlChains), policy: values(controlsSheet.motionControlPolicy)[0]});
    const frameRows = values(alignmentSheet.skeletonAlignmentFrames);
    const alignment = blend ? releaseAlignment : {compileSkeletonAlignment, alignSr1Skeleton};
    if (blend) {
        const file = 'workbench/sr1-local-controller-test/ground-transition-scope.json';
        const {neckFirst, neckLast, neckSourceFirst} = values(sheet(file).sr1GroundTransition)[0];
        assert.equal(host.parents[0], -1);
        assert(host.parents.slice(1).every((parent, index) => parent >= 0 && parent <= index), 'Expected parent-first rig');
        for (let bone = neckFirst; bone <= neckLast; bone++) {
            assert.equal(controls[bone].a, neckSourceFirst + bone - neckFirst);
            assert.equal(controls[bone].b, controls[bone].a);
            frameRows[bone] = {...frameRows[bone], method: 'source_frame', child: -1};
        }
    }
    if (authoredBladeSocket) {
        const file = 'workbench/sr1-local-controller-test/local-blade-scope.json';
        const {handBone, handParent, sourceSocket, sourceParent} = values(sheet(file).sr1StandaloneBlade)[0];
        assert.equal(host.parents[handBone], handParent);
        assert(!host.parents.includes(handBone) && !mesh.palette.includes(handBone));
        assert.equal(rig.parents[sourceSocket], sourceParent);
        assert.deepEqual([controls[handBone].a, controls[handBone].b, controls[handBone].t], [sourceSocket, sourceSocket, 0]);
        assert.deepEqual([controls[handParent].a, controls[handParent].b, controls[handParent].t], [sourceParent, sourceParent, 0]);
        frameRows[handBone] = {...frameRows[handBone], method: 'source_frame', child: -1};
    }
    const compiled = alignment.compileSkeletonAlignment({...rigs, controls,
        rows: frameRows, policy: values(alignmentSheet.skeletonAlignmentPolicy)[0]});
    const hostRender = host.positions.map(position => [1,0,0,0,1,0,0,0,1,0,...position]);
    const authoredScope = authored ? values(sheet('workbench/sr1-local-controller-test/ground-authored-scope.json').sr1GroundAuthored)[0] : null;
    const responseScope = responsive ? values(sheet('workbench/sr1-local-controller-test/ground-responsive-scope.json').sr1GroundResponsiveness)[0] : null;
    const jumpScope = jumping ? values(sheet('workbench/sr1-local-controller-test/local-defiance-jump-scope.json').sr1LocalDefianceJump)[0] : null;
    const feet = calibrated ? skeletonSoleReference(mesh, values(sheet('config/sheets/retarget-presentation.json').groundSolePolicy)[0]) : null;
    const trajectory = feet ? compilePelvisTrajectory(compiled, rigs.sourceBind,
        values(sheet('config/sheets/skeleton-pelvis-trajectory.json').skeletonPelvisPolicy)[0]) : null;
    const support = trajectory ? prepareGroundSupport(trajectory, feet, hostRender, authoredScope, responseScope) : null;
    const guard = nativeCombatControls ?
        values(sheet('workbench/sr1-local-controller-test/local-controls-scope.json').sr1LocalGuardClips)[0] : null;
    function sampleBank(key, bank, settledIdle = false) {
        const options = clips.get(key);
        assert.equal(options?.length, 1, `Ambiguous archive key ${key}`);
        const clip = decodeDefianceClip(options[0], profile.skeletonBones);
        assert.equal(clip.timePerKey, 100, 'Unexpected Defiance ground clip rate');
        const preserveRootStep = combatPresentation && !measuredGroundCombo && bank >= 5 &&
            strikeCombo?.[bank - 5]?.mode === 0;
        const stepOrigin = preserveRootStep ? sampleDefiancePose(clip, rig, 0, false).rootMatrix : null;
        return Array.from({length: clip.keyCount * 2}, (_, i) => {
            const donorPose = sampleDefiancePose(clip, rig, i * clip.timePerKey / 2,
                !authored || bank === 1 || (settledIdle && key === idles[0].archiveKey));
            const result = alignment.alignSr1Skeleton({compiled, hostRender, donorPose, groundAllowed: true,
                experimental: 'sr1-absolute-skeleton-offline-v1'});
            assert(result.allow, `Ground pose ${key}:${i} rejected: ${result.detail}`);
            const plant = settledIdle ? Number(key === idles[0].archiveKey) : authored && bank === 0 ?
                Math.max(0, Math.min(1, (i * 1000 / 60 - authoredScope.plantAfterMs) / authoredScope.startupBlendMs)) : 0;
            if (support) {
                const frame = support.sample(donorPose, result, plant * plant * (3 - 2 * plant));
                if (combat && bank >= 5) frame.combatTwist = combatPelvisTwist(donorPose);
                if (stepOrigin) {
                    frame.step = [12, 13].map(axis => (donorPose.rootMatrix[axis] - stepOrigin[axis]) * trajectory.scale);
                    const limit = trajectory.hostLeg * trajectory.policy.maxTravelLegPermille / 1000;
                    assert(Math.hypot(...frame.step) <= limit, 'Combat root step outside the calibrated rig envelope');
                }
                return frame;
            }
            return result.actorLocalMatrices.flat();
        });
    }
    const banks = [authoredScope?.stopAndIdleArchiveKey ?? profile.idleArchiveKey,
        authoredScope?.runEntryArchiveKey ?? profile.moveArchiveKey,
        ...(jumpScope ? [jumpScope.jumpArchiveKey, jumpScope.fallArchiveKey, jumpScope.landArchiveKey] : []),
        ...(strikeCombo?.map(row => row.archiveKey) ?? (combatPolicy ? [strikeKey] : [])),
        ...(guard ? [guard.guardArchive, guard.guardEntryArchive, guard.guardExitArchive,
            guard.liftArchive, guard.airWindupArchive, guard.airStrikeArchive] : []),
        ...directions.map(row => row.archiveKey),
        ...air.map(row => row.archiveKey),
        ...dodges.map(row => row.archiveKey),
        ...specials.map(row => row.archiveKey)
    ].map((key, bank) => sampleBank(key, bank));
    const chargeBanks=chargeClips.map(row=>sampleBank(row.archiveKey,35));
    const idleBanks = idles.map(({archiveKey}) => sampleBank(archiveKey, 0, true));
    const stopPoseCount = banks[0].length;
    banks[0] = banks[0].concat(...idleBanks);
    const {samples: frames, metrics} = support ? support.finish(banks, stopPoseCount) : {samples: banks};
    const bodyPolicy=bodyAxis?values(sheet('workbench/sr1-local-controller-test/local-body-axis-scope.json').sr1BodyAxis43)[0]:null;
    const bodyTwist=bodyPolicy?banks[bodyPolicy.airBank].map(frame=>2*Math.atan2(frame.combatTwist[2],frame.combatTwist[3])):[];
    for (let i=1;i<bodyTwist.length;++i) {
        while (bodyTwist[i]-bodyTwist[i-1]>Math.PI) bodyTwist[i]-=2*Math.PI;
        while (bodyTwist[i]-bodyTwist[i-1]<-Math.PI) bodyTwist[i]+=2*Math.PI;
    }
    if (bodyPolicy) assert.equal(bodyTwist.length,bodyPolicy.samples);
    const rotorFrames=separateRotor?frames[bodyPolicy.airBank].map(frame=>frame.slice()):[];
    for (let bank = 5; combat && bank < frames.length; ++bank) {
        frames[bank] = frames[bank].map((frame, index) => {
            const {combatTwist, step} = banks[bank][index];
            const bones=host.parents.map((_, bone) => frame.slice(bone * 13, (bone + 1) * 13));
            const pose = bodyPolicy && !separateRotor && bank===bodyPolicy.airBank ? bones : restoreCombatTwist(bones,
                [0, 0, 0, 1], combatTwist);
            if (step) for (let bone = 1; bone < pose.length; ++bone) {
                pose[bone][10] += step[0];
                pose[bone][11] += step[1];
            }
            return pose.flat();
        });
    }
    const sampleCounts = frames.map(bank => bank.length);
    if (air.length) {
        const offset = sampleCounts.length - specials.length - dodges.length - air.length;
        assert.deepEqual(sampleCounts.slice(offset, offset + air.length), air.map(row => row.clipKeys * 2));
    }
    const boneSamples = frames.flat(2);
    const poses = Buffer.alloc(boneSamples.length * 4);
    boneSamples.forEach((value, i) => poses.writeFloatLE(value, i * 4));
    const rotation=Buffer.alloc(bodyTwist.length*4);
    bodyTwist.forEach((value,i)=>rotation.writeFloatLE(value,i*4));
    const rotor=Buffer.alloc(rotorFrames.length*66*13*4);
    rotorFrames.flat().forEach((value,i)=>rotor.writeFloatLE(value,i*4));
    const calibratedCharges=support&&chargeBanks.length?support.finish(chargeBanks,chargeBanks[0].length).samples:chargeBanks;
    const chargePacket=Buffer.alloc(chargeBanks.reduce((n,b)=>n+b.length,0)*66*52);
    let chargeAt=0;for(const [index,bank] of calibratedCharges.entries())for(const [sample,frame] of bank.entries()){
        let matrices=frame;
        if(index>=calibratedCharges.length-contextOpeners.length){
            const bones=host.parents.map((_,bone)=>frame.slice(13*bone,13*(bone+1)));
            matrices=restoreCombatTwist(bones,[0,0,0,1],chargeBanks[index][sample].combatTwist).flat();
        }
        for(const value of matrices){
        // Ground support.finish supplies plain matrices separately below.
        if(typeof value!=="number")throw Error("Unexpected charged pose representation");
        chargePacket.writeFloatLE(value,chargeAt);chargeAt+=4;
    }
    }
    const packet = Buffer.concat([poses,...(feet?[groundSoleCoefficients(feet)]:[]),rotation,rotor,chargePacket]);
    const idlePoseCounts = idles.length ? [stopPoseCount, ...idleBanks.map(bank => bank.length)] : undefined;
    return {chargeCounts:chargeBanks.map(b=>b.length),sampleCounts, packet, parents: host.parents, metrics, strikeTravel, strikeCombo, idlePoseCounts,bodyTwistSamples:bodyTwist.length,
        soleCount: feet?.positions.length ?? 0};
}
