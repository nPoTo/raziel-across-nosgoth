// SPDX-License-Identifier: GPL-3.0-or-later
// Original body and physical Reaver stay in RAM; bind to original contact bone65.
import path from 'node:path';
import crypto from 'node:crypto';
import assert from 'node:assert/strict';
import {EnemyResource,selectSquareMip} from '../defiance-sluagh-r1/enemy-resources.mjs';
import {DefianceArchive} from '../../tools/defiance-archive.mjs';
import {parseDefianceSrm} from '../../tools/inspect-defiance-srm.mjs';
import {decodeMip} from '../../tools/memory-render-packets.mjs';
export function loadInstalledSluagh(folder,policy){
 const archive=new DefianceArchive(path.join(folder,'bigfilehd.dat'));
 try{
  const body=parseDefianceSrm(archive.read(policy.meshKey,policy.maxResourceBytes),policy.meshKey);
  assert.equal(body.sha256,policy.meshSha256);const lod=structuredClone(body.lods[1]);assert.equal(lod.vertexCount,30023);assert.equal(lod.textures.length,16);
  const sword=parseDefianceSrm(archive.read('object/mreaver_1.srm',policy.maxResourceBytes),'object/mreaver_1.srm');
  assert.equal(sword.sha256,'98fb01633a6472aa4376a6c9081c69216a078d705e626f624c0c35fb2ceb4129');const weapon=sword.lods[0];
  assert.equal(weapon.bonePalette.length,1);assert.equal(weapon.textures.length,2);const bone=65,base=lod.vertexCount,palette=lod.bonePalette.length,material=lod.textures.length;
  assert(lod.bindOffsets[bone]&&palette<255);lod.bonePalette.push(bone);
  for(let i=0;i<weapon.vertexCount;i++){
   const point=weapon.positions[i].map((v,k)=>v+weapon.bindOffsets[weapon.bonePalette[0]][k]-lod.bindOffsets[bone][k]);
   lod.positions.push(point);lod.uvs.push(weapon.uvs[i]);lod.materials.push(material+weapon.materials[i]);lod.joints.push([palette,0,0,0]);lod.weights.push([255,0,0,0]);
  }
  lod.indices.push(...weapon.indices.map(i=>base+i));lod.textures.push(...weapon.textures);lod.vertexCount+=weapon.vertexCount;lod.indexCount=lod.indices.length;
  assert(lod.vertexCount<=65535);const textures=lod.textures.map(({name})=>{
   assert(/^(KAIN_[0-9]+|KAIN_HEALED_[23]|KAIN_HEARTWOUND|KAIN_BLOODYMOUTH1|EK_MREAVER[12])$/.test(name));
   const key='tex_hd/'+name.toLowerCase()+'_d.dds',raw=archive.read(key,policy.maxResourceBytes),mip=selectSquareMip(raw,policy.mipSide);
   return {key,sha256:crypto.createHash('sha256').update(raw).digest('hex'),side:mip.side,pixels:decodeMip(mip)};
  });
  return new EnemyResource({...body,lods:[lod]},textures,policy,0);
 }finally{archive.close();}
}
