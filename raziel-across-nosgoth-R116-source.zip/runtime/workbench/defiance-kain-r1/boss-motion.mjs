// SPDX-License-Identifier: GPL-3.0-or-later
// Original boss rig, animations and attributes remain in RAM.
import assert from 'node:assert/strict';
import crypto from 'node:crypto';
import {archiveResource,drmSections} from '../sr1-local-controller-test/inspect-audio-resources.mjs';
import {decodeDefianceClip,sampleDefiancePose} from '../sr1-local-controller-test/defiance-motion.mjs';
import {validateRig} from '../../tools/retarget-pose.mjs';
export function loadBossMotion(){
 const resource=archiveResource('pcenglish\\evilkain.x64.drm');
 assert.equal(crypto.createHash('sha256').update(resource.data).digest('hex'),'c21b237e7dc3644601cade8209ed4f1f5256d877414cfd0ac1e90250c17599b6');
 const parts=drmSections(resource.data);
 function follow(section,offset,length){const part=parts[section];assert(part&&part.relocs.includes(offset)&&offset+8<=part.size);assert.equal(resource.data.readUInt32LE(part.start+offset+4),0);const encoded=resource.data.readUInt32LE(part.start+offset),s=encoded>>>22,o=encoded&0x3fffff;assert(parts[s]&&o+length<=parts[s].size);return {section:s,offset:o,start:parts[s].start+o};}
 const models=follow(0,0x28,8),model=follow(models.section,models.offset,24),bones=resource.data.readUInt32LE(model.start+4);assert.equal(bones,79);
 const segments=follow(model.section,model.offset+16,bones*40),rig={parents:[],rest:[]};
 for(let bone=0;bone<bones;bone++){const at=segments.start+bone*40;assert.equal(resource.data.readFloatLE(at+12),1);rig.parents.push(resource.data.readInt32LE(at+24));rig.rest.push({position:[0,4,8].map(k=>resource.data.readFloatLE(at+k)),rotation:[0,0,0,1]});}
 validateRig(rig);const count=resource.data.readUInt16LE(parts[0].start+0x22);assert.equal(count,48);const references=follow(0,0x30,count*4),byKey=new Map();
 for(const part of parts.filter(p=>p.type===2)){assert(!byKey.has(part.key));const clip=resource.data.subarray(part.start,part.start+part.size);assert.equal(clip.readUInt16LE(),part.key);byKey.set(part.key,decodeDefianceClip(clip,bones));}
 const clips=Array.from({length:count},(_,i)=>{const ref=resource.data.readUInt32LE(references.start+i*4);assert.equal(ref>>>16,65535);const c=byKey.get(ref&65535);assert(c);return c;});
 const attributes=follow(0,0x48,12448);assert.equal(attributes.section,61);assert.equal(attributes.offset,0);assert.equal(parts[61].size,12448);assert.equal(parts[61].relocs.length,71);
 return {rig,bones,clips,attributes:Buffer.from(resource.data.subarray(parts[61].start,parts[61].start+parts[61].size)),relocations:[...parts[61].relocs],sample(runtime,time,loop=false){assert(Number.isInteger(runtime)&&runtime>=0&&runtime<clips.length);return sampleDefiancePose(clips[runtime],rig,time,loop);}};
}
