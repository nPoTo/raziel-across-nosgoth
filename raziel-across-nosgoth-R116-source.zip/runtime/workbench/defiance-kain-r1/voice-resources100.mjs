// SPDX-License-Identifier: GPL-3.0-or-later
// MUL block/Crystal Dynamics IMA algorithm checked against vgmstream meta/mul.c,
// layout/blocked_mul.c and coding/ima_decoder.c. PCM remains in RAM only.
import assert from 'node:assert/strict';
import fs from 'node:fs';
import {archiveResource,smfSamples} from '../sr1-local-controller-test/inspect-audio-resources.mjs';
const steps=[28,32,36,40,44,48,52,56,64,68,76,84,92,100,112,124,136,148,164,180,200,220,240,264,292,320,352,388,428,472,520,572,628,692,760,836,920,1012,1116,1228,1348,1484,1632,1796,1976,2176,2392,2632,2896,3184,3504,3852,4240,4664,5128,5644,6208,6828,7512,8264,9088,9996,10996,12096,13308,14640,16104,17712,19484,21432,23576,25936,28528,31380,...Array(15).fill(32764)];
const indices=[-1,-1,-1,-1,2,4,6,8,-1,-1,-1,-1,2,4,6,8];
export function decodeVoice100(name,{allowTailSilence=false}={}){
 const r=archiveResource('pcenglish\\'+name.toLowerCase()+'.x64.mul'),b=r.data,rate=b.readUInt32LE(),samples=b.readUInt32LE(8),channels=b.readUInt32LE(12);assert(rate>=8000&&rate<=48000&&channels>=1&&channels<=2&&samples>0&&samples<48000*300);
 const output=Buffer.alloc(samples*2);let written=0,blocks=0;
 for(let at=0x800;at+16<=b.length&&written<samples;){const type=b.readUInt32LE(at),size=b.readUInt32LE(at+4);assert(size<=b.length-at-16);if(type===0&&size){const bytes=b.readUInt32LE(at+16);assert(bytes<=size-16&&bytes%(36*channels)===0);const channelBytes=bytes/channels,count=Math.min(samples-written,channelBytes/36*64),mix=new Int32Array(count);
 for(let ch=0;ch<channels;ch++){let q=0;for(let p=at+32+ch*channelBytes;p<at+32+(ch+1)*channelBytes&&q<count;p+=36){let history=b.readInt16LE(p),index=b[p+2];assert(index<=88&&b[p+3]===0);mix[q++]+=history;for(let i=1;i<64&&q<count;i++){const code=(b[p+4+(i>>1)]>>((i&1)*4))&15,delta=(steps[index]*((code&8)?-1:1)*(0x800+(code&7)*0x1000))>>16;history=Math.max(-32768,Math.min(32767,history+delta));index=Math.max(0,Math.min(88,index+indices[code]));mix[q++]+=history;}}}
 for(let q=0;q<count;q++)output.writeInt16LE(Math.round(mix[q]/channels),(written+q)*2);written+=count;blocks++;}at+=16+size;}
 if(allowTailSilence)assert(written>rate);else assert.equal(written,samples);return {pcm:output,rate,metadata:{name:r.name,key:r.key,archiveOffset:r.offset,archiveBytes:r.size,samples,decodedSamples:written,rate,channels,blocks,durationMs:samples*1000/rate,assetsWrittenToDisk:false}};
}

export function buildBossVoices100(){
 const speech=[{name:'kvm_misc_15',text:'Vae victis!',kind:0},{name:'avernus1_11_2',text:"Don't be a fool.",kind:1,start:139.30,end:141.10},{name:'kvm_misc_62_a',text:'Kain mocking laugh',kind:2}];
 const decoded=speech.map(row=>{const v=decodeVoice100(row.name,{allowTailSilence:row.kind===1});let pcm=v.pcm;if(row.start!==undefined)pcm=pcm.subarray(Math.floor(row.start*v.rate)*2,Math.floor(row.end*v.rate)*2);
 else{let first=pcm.length/2,last=0;for(let i=0;i<pcm.length/2;i++)if(Math.abs(pcm.readInt16LE(i*2))>400){first=Math.min(first,i);last=i;}assert(first<last);pcm=pcm.subarray(Math.max(0,first-Math.floor(v.rate*.08))*2,Math.min(pcm.length/2,last+Math.floor(v.rate*.12))*2);}
 return {...row,pcm,rate:v.rate,source:v.metadata,durationMs:pcm.length*500/v.rate};});
 const guardId=JSON.parse(fs.readFileSync(new URL('./gameplay-scope.json',import.meta.url))).tables.kain102.rows[0].values.guardSoundId;
 const impact=archiveResource('pcenglish\\generalbank.smf'),wave=smfSamples(impact.data).find(s=>s.id===guardId);assert(wave&&wave.bytes>0);
 decoded.push({kind:3,text:'Original Defiance contact impact for guard',pcm:impact.data.subarray(wave.offset,wave.offset+wave.bytes),rate:wave.rate,source:{name:impact.name,id:wave.id,key:impact.key,archiveOffset:impact.offset,sampleOffset:wave.offset,bytes:wave.bytes,exactBlockSelectorFound:false,assetsWrittenToDisk:false},durationMs:wave.durationMs});
 const head=Buffer.alloc(72);head.writeUInt32LE(0x3031564b);head.writeUInt32LE(4,4);let cursor=0;decoded.forEach((v,i)=>{const p=8+i*16;head.writeUInt32LE(v.rate,p);head.writeUInt32LE(v.pcm.length,p+4);head.writeUInt32LE(cursor,p+8);head.writeUInt32LE(i,p+12);cursor+=v.pcm.length;});
 return {packet:Buffer.concat([head,...decoded.map(x=>x.pcm)]),metadata:decoded.map(({pcm,...x})=>x)};
}
