// SPDX-License-Identifier: GPL-3.0-or-later
// Prepare the enemy in RAM. Never write the returned payload to a file.
import fs from 'node:fs';
import assert from 'node:assert/strict';
import {checkSheets} from '../../tools/preflight-sheets.mjs';
import {loadInstalledSluagh} from './enemy-resources.mjs';
import {loadBossMotion} from './boss-motion.mjs';
import {buildBossVoices100} from './voice-resources100.mjs';
const bytes=a=>Buffer.from(a.buffer,a.byteOffset,a.byteLength);
export function gameplayResource() {
    const scope=JSON.parse(fs.readFileSync(new URL('./resource-scope.json',import.meta.url)));
    assert.deepEqual(checkSheets(scope),[]);
    const games=JSON.parse(fs.readFileSync(new URL('../../config/games.json',import.meta.url))).games;
    const motion=loadBossMotion(),resource=loadInstalledSluagh(games.find(g=>g.id==='defiance').directory,scope.tables.enemyResource.rows[0].values,0);
    const mesh=resource.meshCopy(),clips=[],poses=[],roots=[];
    let frames=0;
    for(let clip=0;clip<motion.clips.length;clip++) {
        const source=motion.clips[clip];if(source.unsupportedBones){clips.push(frames,0,0,100);continue;}const count=Math.max(1,(source.keyCount-1)*2+1),first=frames;
        for(let frame=0;frame<count;frame++) {
            const pose=motion.sample(clip,frame*source.timePerKey/2,false);
            const native=new Float32Array(pose.matrices.flat().slice(0,motion.bones*16));
            const adapted=resource.adaptNativeBind(native,motion.rig.parents,motion.rig.rest.map(b=>b.position)).matrices;
            const root=[pose.rootMatrix[12],pose.rootMatrix[13],pose.rootMatrix[14]];
            // Translation is applied once by the SR1 movement adapter.
            for(let bone=0;bone<motion.bones;bone++) for(let k=0;k<3;k++) adapted[bone*16+12+k]-=root[k];
            poses.push(bytes(adapted));roots.push(...root);frames++;
        }
        clips.push(first,count,source.keyCount,source.timePerKey);
    }
    const header=Buffer.alloc(48),values=[0x324e414b,1,mesh.positions.length/3,mesh.indices.length,resource.metadata.textures,motion.bones,motion.clips.length,frames,motion.attributes.length,motion.relocations.length,mesh.palette.length,mesh.bindOffsets.length/3];
    values.forEach((v,i)=>header.writeUInt32LE(v,i*4));
    const voices=buildBossVoices100();
    const payload=Buffer.concat([header,bytes(mesh.positions),bytes(mesh.uvs),Buffer.from(mesh.joints),Buffer.from(mesh.weights),Buffer.from(mesh.materials),bytes(mesh.indices),bytes(mesh.palette),bytes(mesh.bindOffsets),...Array.from({length:resource.metadata.textures},(_,i)=>resource.textureCopy(i).pixels),bytes(new Uint32Array(clips)),bytes(new Float32Array(roots)),...poses,bytes(new Uint32Array(motion.relocations)),motion.attributes,voices.packet]);
    assert(payload.length<32*1024*1024);
    return {payload,metadata:{...resource.metadata,clips:motion.clips.map((clip,runtime)=>({runtime,key:clip.key,keys:clip.keyCount,timePerKey:clip.timePerKey})),frames,voices:voices.metadata,payloadBytes:payload.length,assetsWrittenToDisk:false}};
}
