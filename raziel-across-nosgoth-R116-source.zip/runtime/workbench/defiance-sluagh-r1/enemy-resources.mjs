// SPDX-License-Identifier: GPL-3.0-or-later
// Installed resources are decoded in RAM only. No filesystem cache or game writes.
import path from 'node:path';
import crypto from 'node:crypto';
import {DefianceArchive} from '../../tools/defiance-archive.mjs';
import {parseDefianceSrm} from '../../tools/inspect-defiance-srm.mjs';
import {decodeMip} from '../../tools/memory-render-packets.mjs';

const sha=b=>crypto.createHash('sha256').update(b).digest('hex');
const finite=(v,bound)=>Number.isFinite(v)&&Math.abs(v)<=bound;
function requireThat(ok,message){if(!ok)throw new Error(message);}

export function selectSquareMip(bytes,side) {
  requireThat(Buffer.isBuffer(bytes)&&bytes.length>=128,'Invalid DDS');
  requireThat(bytes.toString('ascii',0,4)==='DDS '&&bytes.readUInt32LE(4)===124&&bytes.readUInt32LE(76)===32,'Invalid DDS header');
  const width=bytes.readUInt32LE(16),height=bytes.readUInt32LE(12),mips=bytes.readUInt32LE(28),format=bytes.toString('ascii',84,88),stride={DXT1:8,DXT5:16}[format];
  requireThat(stride&&width===height&&width>=4&&width<=2048&&(width&(width-1))===0,'Unsupported DDS shape');
  requireThat(bytes.readUInt32LE(24)<=1&&bytes.readUInt32LE(112)===0,'Unsupported cube or volume');
  requireThat(mips===Math.log2(width)+1&&Number.isInteger(side)&&side>=4&&side<=width&&(side&(side-1))===0,'Invalid mip selection');
  let at=128,selected;
  for(let level=0;level<mips;level++){
    const size=Math.max(1,width>>level),length=Math.ceil(size/4)**2*stride;
    requireThat(at+length<=bytes.length,'Truncated DDS');
    if(size===side)selected={side,level,format,bytes:bytes.subarray(at,at+length)};
    at+=length;
  }
  requireThat(at===bytes.length&&selected,'DDS length mismatch');
  return selected;
}

// Owns private immutable resource arrays. Every exposed byte/array copy belongs
// to the caller; actor poses can never overwrite the shared mesh or textures.
export class EnemyResource {
  #lod;#textures;#policy;
  constructor(mesh,textures,policy,lodIndex=0){
    const lod=mesh?.lods?.[lodIndex];
    requireThat(lod&&mesh.sha256===policy.meshSha256,'Unapproved resource');
    requireThat(Number.isInteger(lod.vertexCount)&&lod.vertexCount>0&&lod.vertexCount<=policy.maxVertices,'Vertex bound');
    requireThat(lod.indexCount>0&&lod.indexCount<=policy.maxIndices&&lod.indexCount%3===0,'Index bound');
    requireThat(lod.bonePalette.length>0&&lod.bindOffsets.length<=policy.maxBones,'Bone bound');
    requireThat(textures.length===lod.textures.length&&textures.length>0&&textures.length<=policy.maxTextures,'Texture bound');
    const n=lod.vertexCount;
    for(const field of ['positions','uvs','materials','joints','weights'])requireThat(lod[field]?.length===n,'Vertex array mismatch');
    requireThat(lod.indices.length===lod.indexCount,'Index array mismatch');
    const textureBytes=textures.reduce((sum,t)=>sum+t.pixels.length,0);
    const allocated=n*(12+8+1+4+4)+lod.indexCount*2+lod.bindOffsets.length*12+lod.bonePalette.length*2+textureBytes;
    requireThat(allocated<=policy.maxResourceBytes,'Resource RAM budget');
    for(const [i,p] of lod.positions.entries()){
      requireThat(p.length===3&&p.every(v=>finite(v,policy.maxCoordinate)),'Invalid vertex');
      requireThat(lod.uvs[i].length===2&&lod.uvs[i].every(v=>finite(v,128)),'Invalid UV');
      requireThat(Number.isInteger(lod.materials[i])&&lod.materials[i]>=0&&lod.materials[i]<textures.length,'Invalid material');
      requireThat(lod.weights[i].length===4&&lod.joints[i].length===4&&lod.weights[i].every(v=>Number.isInteger(v)&&v>=0&&v<=255)&&lod.weights[i].reduce((a,b)=>a+b,0)===255,'Invalid weights');
      for(let k=0;k<4;k++)if(lod.weights[i][k])requireThat(Number.isInteger(lod.joints[i][k])&&lod.joints[i][k]>=0&&lod.joints[i][k]<lod.bonePalette.length,'Invalid palette index');
    }
    for(const bone of lod.bonePalette)requireThat(Number.isInteger(bone)&&bone>=0&&bone<lod.bindOffsets.length,'Invalid bone');
    for(const b of lod.bindOffsets)requireThat(b.length===3&&b.every(v=>finite(v,policy.maxCoordinate)),'Invalid bind offset');
    for(let i=0;i<lod.indices.length;i+=3){
      const triangle=lod.indices.slice(i,i+3);
      requireThat(triangle.every(v=>Number.isInteger(v)&&v>=0&&v<n),'Invalid index');
      requireThat(triangle.every(v=>lod.materials[v]===lod.materials[triangle[0]]),'Mixed triangle material');
    }
    textures.forEach(t=>requireThat(t.side===policy.mipSide&&Buffer.isBuffer(t.pixels)&&t.pixels.length===t.side*t.side*4,'Texture byte layout'));
    this.#lod=structuredClone(lod);this.#textures=textures.map(t=>({...t,pixels:Buffer.from(t.pixels)}));this.#policy=Object.freeze({...policy});
    this.metadata=Object.freeze({id:mesh.sha256+':'+lodIndex,meshSha256:mesh.sha256,lod:lodIndex,vertices:n,indices:lod.indexCount,bones:Math.max(...lod.bonePalette)+1,bindOffsets:lod.bindOffsets.length,paletteBones:lod.bonePalette.length,textures:textures.length,packedBytes:allocated});
    Object.freeze(this);
  }
  meshCopy(){const l=this.#lod;return {positions:new Float32Array(l.positions.flat()),indices:new Uint16Array(l.indices),uvs:new Float32Array(l.uvs.flat()),materials:new Uint8Array(l.materials),joints:new Uint8Array(l.joints.flat()),weights:new Uint8Array(l.weights.flat()),palette:new Uint16Array(l.bonePalette),bindOffsets:new Float32Array(l.bindOffsets.flat())};}
  textureCopy(index){requireThat(Number.isInteger(index)&&index>=0&&index<this.#textures.length,'Texture index');const t=this.#textures[index];return {...t,pixels:Buffer.from(t.pixels)};}
  adaptNativeBind(matrices,parents,localBind){
    const count=this.metadata.bones,l=this.#lod;
    requireThat(matrices instanceof Float32Array&&matrices.length>=count*16&&parents.length>=count&&localBind.length>=count,'Native bind layout');
    const output=new Float32Array(matrices.slice(0,count*16)),done=new Set(),active=new Set(),global=[];
    const nativeBind=i=>{if(global[i])return global[i];requireThat(!active.has(i),'Native parent cycle');active.add(i);const p=parents[i];requireThat(Number.isInteger(p)&&p>=-1&&p<count&&p!==i,'Native parent bound');const base=p<0?[0,0,0]:nativeBind(p);requireThat(localBind[i]?.length===3&&localBind[i].every(Number.isFinite),'Native bind point');global[i]=localBind[i].map((v,k)=>v+base[k]);active.delete(i);return global[i];};
    let maxCorrection=0;
    for(let b=0;b<count;b++)for(let k=0;k<3;k++)maxCorrection=Math.max(maxCorrection,Math.abs(nativeBind(b)[k]+l.bindOffsets[b][k]));
    requireThat(maxCorrection<=this.#policy.maxBindCorrection,'Native bind correction bound');
    const solve=b=>{
      if(done.has(b))return;const p=parents[b];if(p>=0)solve(p);
      for(let k=0;k<3;k++){
        if(p<0){output[b*16+12+k]=matrices[b*16+12+k]-l.bindOffsets[b][k]-global[b][k];continue;}
        let delta=0;for(let c=0;c<3;c++){
          const desired=-l.bindOffsets[b][c]+l.bindOffsets[p][c],correction=desired-localBind[b][c];
          delta+=matrices[p*16+c*4+k]*correction;
        }
        output[b*16+12+k]=output[p*16+12+k]+matrices[b*16+12+k]-matrices[p*16+12+k]+delta;
      }
      done.add(b);
    };
    for(let b=0;b<count;b++)solve(b);return {matrices:output,maxCorrection};
  }
  skin(matrices){
    const l=this.#lod,bound=this.#policy.maxCoordinate;
    requireThat(matrices instanceof Float32Array&&matrices.length===this.metadata.bones*16,'Matrix layout');
    requireThat(matrices.every(v=>finite(v,bound)),'Non-finite or unbounded matrix');
    for(let b=0;b<this.metadata.bones;b++)requireThat(Math.abs(matrices[b*16+3])<0.0001&&Math.abs(matrices[b*16+7])<0.0001&&Math.abs(matrices[b*16+11])<0.0001&&Math.abs(matrices[b*16+15]-1)<0.0001,'Non-affine matrix');
    const positions=new Float32Array(l.vertexCount*3);
    for(let i=0;i<l.vertexCount;i++)for(let j=0;j<4;j++)if(l.weights[i][j]){
      const bone=l.bonePalette[l.joints[i][j]],offset=l.bindOffsets[bone],weight=l.weights[i][j]/255,at=bone*16;
      const local=l.positions[i].map((v,k)=>v+offset[k]);
      for(let k=0;k<3;k++)positions[i*3+k]+=weight*(local.reduce((sum,v,c)=>sum+v*matrices[at+c*4+k],0)+matrices[at+12+k]);
    }
    requireThat(positions.every(v=>finite(v,bound)),'Skinned position bound');
    return positions;
  }
}

export function loadInstalledSluagh(folder,policy,lodIndex=0){
  requireThat(typeof folder==='string'&&path.isAbsolute(folder),'Absolute installed folder required');
  requireThat(Number.isInteger(lodIndex)&&lodIndex>=0&&lodIndex<policy.lodCount,'Invalid LOD');
  const archive=new DefianceArchive(path.join(folder,'bigfilehd.dat'));
  try{
    const bytes=archive.read(policy.meshKey,policy.maxResourceBytes);
    requireThat(sha(bytes)===policy.meshSha256,'Installed mesh hash mismatch');
    const mesh=parseDefianceSrm(bytes,policy.meshKey),lod=mesh.lods[lodIndex];
    requireThat(mesh.lods.length===policy.lodCount&&mesh.lods[0].vertexCount===policy.topVertices&&mesh.lods[0].indexCount===policy.topIndices,'Installed mesh layout mismatch');
    const textures=lod.textures.map(({name})=>{
      requireThat(/^sluagh_[1-4]$/i.test(name),'Unapproved texture');
      const key='tex_hd/'+name.toLowerCase()+'_d.dds',bytes=archive.read(key,policy.maxResourceBytes),mip=selectSquareMip(bytes,policy.mipSide);
      return {key,sha256:sha(bytes),side:mip.side,pixels:decodeMip(mip)};
    });
    requireThat(new Set(textures.map(t=>t.key)).size===textures.length,'Duplicate material');
    return new EnemyResource(mesh,textures,policy,lodIndex);
  }finally{archive.close();}
}

// Offline transport preparation only. Actual native generation/host identity
// must be supplied by a future measured registry; an address is not an identity.
export class EnemyPoseSlots {
  #slots=new Map();#retired=new Map();#policy;#session;
  constructor(policy,session){requireThat(typeof session==='string'&&session.length>0&&session.length<=128,'Session required');this.#policy={...policy};this.#session=session;}
  admit(key,generation,resource){
    requireThat(typeof key==='string'&&key.length>0&&key.length<=128&&Number.isSafeInteger(generation)&&generation>0&&resource instanceof EnemyResource,'Invalid actor identity');
    requireThat(!this.#slots.has(key)&&generation>(this.#retired.get(key)??0)&&this.#slots.size<this.#policy.maxActors,'Actor slot unavailable');
    const known=new Set([...this.#retired.keys(),...this.#slots.keys()]);
    requireThat(known.has(key)||known.size<this.#policy.maxActors,'Logical slot identity bound');
    this.#slots.set(key,{generation,resource,sequence:0,sample:null});
  }
  update(key,generation,{session,sequence,capturedMs,realm,matrices},now){
    const s=this.#slots.get(key);
    requireThat(s&&s.generation===generation&&session===this.#session,'Stale actor or session');
    requireThat(Number.isSafeInteger(sequence)&&sequence>s.sequence&&finite(now,Number.MAX_SAFE_INTEGER)&&now>=0&&finite(capturedMs,Number.MAX_SAFE_INTEGER)&&capturedMs>=0&&capturedMs<=now&&now-capturedMs<=this.#policy.maxPoseAgeMs,'Stale or invalid pose');
    requireThat(realm===1||realm===2,'Invalid realm');
    const positions=s.resource.skin(matrices); // Validate everything before commit.
    s.sample={capturedMs,realm,positions};s.sequence=sequence;
  }
  copy(key,generation,now,realm){
    const s=this.#slots.get(key);
    if(!s||s.generation!==generation||!s.sample||!Number.isFinite(now)||now<s.sample.capturedMs||now-s.sample.capturedMs>this.#policy.maxPoseAgeMs||s.sample.realm!==realm)return null;
    return {resource:s.resource,sequence:s.sequence,positions:new Float32Array(s.sample.positions)};
  }
  remove(key,generation){const s=this.#slots.get(key);if(!s||s.generation!==generation)return false;this.#retired.set(key,generation);this.#slots.delete(key);return true;}
  clear(){for(const [key,s] of this.#slots)this.remove(key,s.generation);}
}
