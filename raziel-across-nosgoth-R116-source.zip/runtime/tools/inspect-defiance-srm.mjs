// Bounded SRM inspection, informed by io_scene_xrm; no Blender dependency.
import fs from 'node:fs';
import crypto from 'node:crypto';
import path from 'node:path';
import {pathToFileURL} from 'node:url';
export function parseDefianceSrm(bytes,source='installed-game-memory') {
if(!Buffer.isBuffer(bytes)||bytes.length>64*1024*1024)throw new Error('Invalid SRM buffer');
let at=0;
function take(n) { if(!Number.isSafeInteger(n)||n<0||at+n>bytes.length) throw new Error(`Truncated SRM at ${at}, need ${n}`); const p=at; at+=n; return p; }
const u32=()=>bytes.readUInt32LE(take(4));
const f32=()=> {const v=bytes.readFloatLE(take(4)); if(!Number.isFinite(v)) throw new Error('Non-finite SRM float'); return v;};
const vector=n=>Array.from({length:n},f32);
function bounded(value,max,label) { if(!Number.isInteger(value)||value<0||value>max) throw new Error(`Unsupported ${label}: ${value}`); return value; }
const magic=bytes.subarray(take(4),4).toString('hex');
if(magic!=='53524d08') throw new Error(`Unsupported SRM version ${magic}`);
const lodCount=bounded(u32(),8,'LOD count'); if(!lodCount) throw new Error('No LODs');
const bounds=vector(4),lods=[];
for(let lod=0;lod<lodCount;++lod) {
  const start=at,shaderCount=bounded(u32(),256,'shader count'),shaders=[];
  for(let i=0;i<shaderCount;++i) {
    const type=u32(); take(88);
    shaders.push({type,opaqueOffset:u32(),opaqueLength:u32(),alphaOffset:u32(),alphaLength:u32(),additiveOffset:u32(),additiveLength:u32()});
  }
  const textureCount=bounded(u32(),256,'texture count'),textures=[];
  for(let i=0;i<textureCount;++i) {
    const p=take(32);
    const name=bytes.subarray(p,p+31).toString('ascii').replace(/\0.*$/s,'');
    if(!/^[\x20-\x7e]*$/.test(name)) throw new Error('Invalid texture name');
    textures.push({name,flag:bytes[p+31]});
  }
  const bindOffsetGroupCount=32+bounded(u32(),224,'extra bind offset group count');
  // Four vec3 offsets per group, NOT a 4x3 transform matrix.
  const bindOffsets=Array.from({length:bindOffsetGroupCount*4},()=>vector(3));
  // Reference parser's optional negative-zero marker: validate against counts below.
  if(at+4<=bytes.length && bytes.readUInt32LE(at)===0x80000000) take(4);
  const flagsAt=take(128),boneFlags=Array.from(bytes.subarray(flagsAt,flagsAt+128));
  if(boneFlags.some(v=>v!==0 && v!==1)) throw new Error('Unsupported bone flag values');
  const bonePalette=boneFlags.flatMap((v,i)=>v?[i]:[]);
  const vertexCount=bounded(u32(),1000000,'vertex count'),indexCount=bounded(u32(),3000000,'index count');
  if(indexCount%3) throw new Error('Triangle index count not divisible by 3');
  const positions=[],tangents=[],normals=[],materials=[],joints=[],weights=[],uvs=[];
  for(let i=0;i<vertexCount;++i) {
    positions.push(vector(3));
    const p=take(24);
    tangents.push(Array.from({length:4},(_,j)=>bytes.readInt8(p+j)));
    normals.push(Array.from({length:3},(_,j)=>bytes.readInt8(p+4+j)));
    materials.push(bytes[p+7]); joints.push(Array.from(bytes.subarray(p+8,p+12)));
    weights.push(Array.from(bytes.subarray(p+12,p+16))); uvs.push([bytes.readFloatLE(p+16),bytes.readFloatLE(p+20)]);
    if(!uvs.at(-1).every(Number.isFinite)) throw new Error('Non-finite UV');
  }
  const indices=Array.from({length:indexCount},()=>bytes.readUInt16LE(take(2)));
  if(indices.some(i=>i>=vertexCount)) throw new Error(`LOD ${lod}: triangle index outside vertex array`);
  const sums=weights.map(v=>v.reduce((a,b)=>a+b,0));
  const weightedJoints=new Set(); let invalidWeightedJoints=0;
  for(let i=0;i<vertexCount;++i) for(let j=0;j<4;++j) if(weights[i][j]) {
    weightedJoints.add(joints[i][j]); if(joints[i][j]>=bonePalette.length || bonePalette[joints[i][j]]>=bindOffsets.length) ++invalidWeightedJoints;
  }
  const weightedJointList=[...weightedJoints].sort((a,b)=>a-b);
  if(invalidWeightedJoints || sums.some(v=>v!==255)) throw new Error('Invalid palette index or weight sum');
  lods.push({lod,start,end:at,shaderCount,shaders,textureCount,textures,bindOffsetGroupCount,bindOffsets,boneFlags,bonePalette,
    vertexCount,indexCount,triangleCount:indexCount/3,positions,tangents,normals,materials,joints,weights,uvs,indices,
    validation:{weightSums:[...new Set(sums)].sort((a,b)=>a-b),invalidWeightedJoints,
      invalidMaterialVertices:materials.filter(i=>i>=shaderCount).length,weightedJoints:weightedJointList,
      positionBounds:[0,1,2].map(i=>positions.reduce(([low,high],v)=>[Math.min(low,v[i]),Math.max(high,v[i])],[Infinity,-Infinity]))}});
}
if(at!==bytes.length) throw new Error(`Unparsed SRM bytes: ${bytes.length-at}`);
const sha256=crypto.createHash('sha256').update(bytes).digest('hex');
return {source,sha256,magic,bounds,lods};
}
if(process.argv[1]&&pathToFileURL(path.resolve(process.argv[1])).href===import.meta.url) {
const source=process.argv[2] ?? 'reports/assets/defiance-raziel.srm';
const bytes=fs.readFileSync(source);
const mesh=parseDefianceSrm(bytes,source);
const {sha256,magic,bounds,lods}=mesh;
fs.writeFileSync('reports/assets/defiance-raziel-mesh.json',JSON.stringify(mesh)+'\n');
const summary={source,sha256,magic,bounds,consumed:bytes.length,fileSize:bytes.length,
  lods:lods.map(({lod,shaderCount,textureCount,textures,bindOffsets,bonePalette,vertexCount,indexCount,triangleCount,validation})=>
    ({lod,shaderCount,textureCount,textures,bindOffsetCount:bindOffsets.length,activeBoneCount:bonePalette.length,vertexCount,indexCount,triangleCount,validation}))};
fs.writeFileSync('reports/defiance-mesh-inspection.json',JSON.stringify(summary,null,2)+'\n');
console.log(JSON.stringify(summary,null,2));
}
