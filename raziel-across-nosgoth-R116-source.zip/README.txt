R116 corresponding mod source, GPL-3.0-or-later. See BUILD.md.
