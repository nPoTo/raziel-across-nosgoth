// SPDX-License-Identifier: GPL-3.0-or-later
import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import {createHash} from 'node:crypto';
import {spawnSync} from 'node:child_process';

const [compiler, outputDirectory] = process.argv.slice(2);
assert(compiler && outputDirectory, 'Usage: node release/build-native.mjs <clang.exe> <output-directory>');
const source = path.resolve(import.meta.dirname, '..');
const output = path.resolve(outputDirectory);
assert(!fs.existsSync(output), 'Choose a new output directory.');
const sourceToken = '@RAZIEL_' + 'SOURCE_ROOT@';
const release = path.join(output, 'native');
const build = path.join(output, 'compile-work');
const portableRoot = build.replaceAll('\\', '/');
const hash = file => createHash('sha256').update(fs.readFileSync(file)).digest('hex');
fs.mkdirSync(build, {recursive:true});
fs.mkdirSync(release);

for(const item of ['build','dependencies/minhook','native','workbench']){
    fs.cpSync(path.join(source,item),path.join(build,item),{recursive:true});
}
for(const file of fs.readdirSync(build,{recursive:true})){
    if(!/\.(?:c|h|json)$/i.test(file))continue;
    const target=path.join(build,file);
    const before=fs.readFileSync(target,'utf8');
    if(before.includes(sourceToken))fs.writeFileSync(target,before.replaceAll(sourceToken,portableRoot));
}

const run=args=>{
    const result=spawnSync(path.resolve(compiler),args,{cwd:build,encoding:'utf8',stdio:'inherit',windowsHide:true});
    assert.equal(result.status,0,'Compiler failed: '+(result.error?.message??result.signal??result.status));
};
const commands=JSON.parse(fs.readFileSync(path.join(import.meta.dirname,'native-commands.json'),'utf8'));
const objectPaths=commands[0].args.filter(arg=>arg.endsWith('.o'));
for(const outputFile of objectPaths){
    const object=path.basename(outputFile);
    const minhookC=object==='hde64.o'?'hde/hde64.c':object.replace(/\.o$/,'.c');
    fs.mkdirSync(path.dirname(path.join(build,outputFile)),{recursive:true});
    run(['-std=c11','-O2','-c','dependencies/minhook/src/'+minhookC,'-o',outputFile]);
}

let probeHash;
for(const command of commands){
    const basename=path.basename(command.output);
    if(basename==='quick-world-observer.exe'){
        assert(probeHash,'Build the probe before its observer.');
        const observer=command.args.find(arg=>arg.endsWith('/quick-world-observer.c'));
        assert(observer);
        const file=path.join(build,observer);
        const original=fs.readFileSync(file,'utf8');
        const pin=/if\(hashFile\(q\.szExePath,h\)&&!strcmp\(h,"([0-9a-f]{64})"\)\)/;
        assert(pin.test(original),'The observer no longer contains a probe pin.');
        fs.writeFileSync(file,original.replace(pin,(_,previous)=>_.replace(previous,probeHash)));
    }
    const target=path.join(build,command.output);
    fs.mkdirSync(path.dirname(target),{recursive:true});
    run(command.args.map(arg=>arg.replaceAll(sourceToken,portableRoot)));
    const destination=path.join(release,basename==='LOKMemoryProbe.asi'?'LOKProbe.asi':basename);
    fs.copyFileSync(target,destination);
    if(basename==='LOKMemoryProbe.asi')probeHash=hash(destination);
    console.log(hash(destination),path.basename(destination));
}
