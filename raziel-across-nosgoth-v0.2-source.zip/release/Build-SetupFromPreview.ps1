# SPDX-License-Identifier: GPL-3.0-or-later
param(
    [Parameter(Mandatory)][string]$PreviewInstaller,
    [Parameter(Mandatory)][string]$NativeOutput,
    [Parameter(Mandatory)][string]$OutputDirectory,
    [ValidatePattern('^\d{1,4}\.\d{1,4}$')][string]$Version='0.2'
)
$ErrorActionPreference='Stop'
Set-StrictMode -Version Latest
$preview=(Resolve-Path -LiteralPath $PreviewInstaller).Path
$native=(Resolve-Path -LiteralPath $NativeOutput).Path
$output=[IO.Path]::GetFullPath($OutputDirectory)
if((Get-FileHash -LiteralPath $preview).Hash -cne 'B1E24604642BE44AD6D81A5299F8AA7C9A36645F217AD19331C0DFB4A5E6A311'){
    throw 'Use the original published 0.2 installer.'
}
if([IO.Directory]::Exists($output)){throw 'Choose a new output directory.'}
$source=(Resolve-Path -LiteralPath (Join-Path $PSScriptRoot '..')).Path
$isolated=Join-Path $output 'setup-work'
$runtime=Join-Path $output 'runtime'
[void][IO.Directory]::CreateDirectory($isolated)
$archive=Join-Path $isolated 'Runtime.zip'
$save=Join-Path $isolated 'CompanionSave.dat'
$loader=Join-Path $isolated 'dependencies/asi-loader/dinput8.dll'
[void][IO.Directory]::CreateDirectory((Split-Path $loader))
$original=[Reflection.Assembly]::Load([IO.File]::ReadAllBytes($preview))
$resources=@{'Runtime.zip'=$archive;'CompanionSave.dat'=$save;'Loader.dll'=$loader}
foreach($resource in $resources.GetEnumerator()){
    $stream=$original.GetManifestResourceStream($resource.Key)
    $file=[IO.File]::Create($resource.Value)
    try{$stream.CopyTo($file)}finally{$file.Dispose();$stream.Dispose()}
}
Add-Type -AssemblyName System.IO.Compression.FileSystem
[IO.Compression.ZipFile]::ExtractToDirectory($archive,$runtime)

foreach($item in @('workbench/raziel-windows-setup','dependencies/minhook/LICENSE.txt','deploy/winmm.ini')){
    $destination=Join-Path $isolated $item
    [void][IO.Directory]::CreateDirectory((Split-Path $destination))
    Copy-Item -LiteralPath (Join-Path $source $item) -Destination $destination -Recurse
}
$relativeIcon='workbench/desktop-sr1-linked-r1/assets/reaver-light.ico'
$buildIcon=Join-Path $isolated $relativeIcon
[void][IO.Directory]::CreateDirectory((Split-Path $buildIcon))
Copy-Item -LiteralPath (Join-Path $runtime $relativeIcon) -Destination $buildIcon

& node (Join-Path $PSScriptRoot 'repack-runtime.mjs') $runtime (Join-Path $native 'native')
if($LASTEXITCODE){throw 'The reconstructed runtime did not pass verification.'}
$env:RAZIEL_PACKAGED_RUNTIME_SHA256=(Get-FileHash -LiteralPath (Join-Path $runtime 'runtime-manifest.json')).Hash.ToLowerInvariant()
& (Join-Path $runtime 'runtime/node.exe') (Join-Path $runtime 'runtime/check.mjs')
if($LASTEXITCODE){throw 'The reconstructed runner failed its offline check.'}
$builder=Join-Path $isolated 'workbench/raziel-windows-setup/tools/build-setup.ps1'
& $builder -RuntimeStage $runtime -Version $Version -CompanionSave $save -OutputDirectory (Join-Path $output 'installer')
