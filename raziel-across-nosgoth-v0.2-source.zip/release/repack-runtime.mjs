// SPDX-License-Identifier: GPL-3.0-or-later
import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import {createHash} from 'node:crypto';

const [extractedRuntime, nativeDirectory] = process.argv.slice(2);
assert(extractedRuntime && nativeDirectory);
const fromRepository = path.resolve(import.meta.dirname,'../runtime-source');
const hash = file => createHash('sha256').update(fs.readFileSync(file)).digest('hex');
const root = path.resolve(extractedRuntime);
const manifestFile = path.join(root,'runtime-manifest.json');
const manifest = JSON.parse(fs.readFileSync(manifestFile,'utf8'));
assert.equal(manifest.kind,'standalone-desktop-runtime');
for(const [relative,digest] of Object.entries(manifest.files)){
    const existing = path.resolve(root,relative);
    assert(existing.startsWith(root+path.sep));
    assert.equal(hash(existing),digest,relative);
    const replacement = path.join(fromRepository,relative);
    if(fs.existsSync(replacement)) fs.copyFileSync(replacement,existing);
}

for(const name of ['LOKProbe.asi','Chapter10AutoLoad.asi','Chapter10SpawnPortal.asi','quick-world-observer.exe']){
    fs.copyFileSync(path.join(nativeDirectory,name),path.join(root,'runtime/native',name));
}
const installed = Object.fromEntries(Object.entries({
    probe:'LOKProbe.asi',start:'Chapter10AutoLoad.asi',portal:'Chapter10SpawnPortal.asi'
}).map(([key,file])=>[key,hash(path.join(root,'runtime/native',file))]));
const moduleFile = path.join(root,'runtime/native/modules.json');
const old = JSON.parse(fs.readFileSync(moduleFile,'utf8'));
fs.writeFileSync(moduleFile,JSON.stringify(installed,null,2)+'\n');

const config = path.join(root,'runtime/desktop.json');
const desktop = JSON.parse(fs.readFileSync(config,'utf8'));
assert.equal(desktop.hostProbeSha256,old.probe);
assert.equal(desktop.moduleSha256,old.start);
assert.equal(desktop.portalSha256,old.portal);
Object.assign(desktop,{hostProbeSha256:installed.probe,moduleSha256:installed.start,portalSha256:installed.portal});
fs.writeFileSync(config,JSON.stringify(desktop,null,2)+'\n');

const entry = path.join(root,manifest.entry);
const runner = fs.readFileSync(entry,'utf8');
const oldPin = '"module":"'+old.probe.toUpperCase()+'"';
assert.equal(runner.split(oldPin).length,2);
fs.writeFileSync(entry,runner.replace(oldPin,'"module":"'+installed.probe.toUpperCase()+'"')
    .replace(/"manifestSha256":"[0-9a-f]{64}"/,'"manifestSha256":"'+hash(moduleFile)+'"'));

for(const file of Object.keys(manifest.files)) manifest.files[file]=hash(path.join(root,file));
fs.writeFileSync(manifestFile,JSON.stringify(manifest,null,2)+'\n');
