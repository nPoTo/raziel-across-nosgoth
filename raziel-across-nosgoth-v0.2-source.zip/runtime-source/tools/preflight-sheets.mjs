import {checkCompiledSheet} from "../runtime/check-payload.mjs";
// SPDX-License-Identifier: GPL-3.0-or-later
import fs from 'node:fs';
import path from 'node:path';
import {pathToFileURL} from 'node:url';
import crypto from 'node:crypto';
import {checkV2} from './sheet-schema.mjs';
const root=path.resolve(import.meta.dirname,'..');
const canonical=v=>Array.isArray(v)?v.map(canonical):v&&typeof v==='object'?Object.fromEntries(Object.keys(v).sort().map(k=>[k,canonical(v[k])])):v;
export const sheetContentHash=document=>crypto.createHash('sha256').update(JSON.stringify(canonical(document))).digest('hex');
const orderedTables=document=>Object.entries(document.tables).sort(([a],[b])=>a.localeCompare(b,'en'));
function generationNames(document){
 const seen=new Set(['sheetMetadata','sheetRow','deepFreeze']);
 const reserve=name=>{if(!/^[A-Za-z_]\w*$/.test(name)||seen.has(name))throw new Error(`Generated identifier collision: ${name}`);seen.add(name);};
 const keywords=new Set('auto break case char const continue default do double else enum extern float for goto if inline int long register restrict return short signed sizeof static struct switch typedef union unsigned void volatile while _Bool _Atomic'.split(' '));
 for(const [table,t] of orderedTables(document)){reserve(table);for(const column of Object.keys(t.columns))if(keywords.has(column))throw new Error('Reserved C field identifier: '+column);for(const row of t.rows)reserve(table+'_'+row.values.id.replaceAll('-','_'));}
}
export function checkSheets(document) {
  if(document?.schemaVersion===2)return checkCompiledSheet(document);
  const errors=[];
  if(document?.schemaVersion!==1||!document.tables||typeof document.tables!=='object')return ['Invalid sheet schema'];
  const tables=document.tables, ids={};
  for(const [name,table] of Object.entries(tables)) {
    ids[name]=new Set();
    if(!table.columns||!Array.isArray(table.rows)){errors.push(`${name}: missing columns/rows`);continue;}
    for(const [index,row] of table.rows.entries()) {
      const label=`${name}[${index}]`, values=row.values??{};
      if(ids[name].has(values.id))errors.push(`${label}: duplicate id ${values.id}`);
      ids[name].add(values.id);
      if(typeof row.evidence!=='string'||!row.evidence.trim())errors.push(`${label}: missing evidence`);
      for(const [column,type] of Object.entries(table.columns)) {
        const value=values[column];
        if(value===undefined||value===null||value==='')errors.push(`${label}.${column}: unfilled`);
        else if(type==='integer'?!Number.isSafeInteger(value):type.startsWith('ref:')?typeof value!=='string':typeof value!==type)errors.push(`${label}.${column}: invalid ${type}`);
        if(!Array.isArray(row.checked)||!row.checked.includes(column))errors.push(`${label}.${column}: unverified`);
      }
      for(const column of Object.keys(values))if(!(column in table.columns))errors.push(`${label}.${column}: undeclared column`);
    }
  }
  for(const [name,table] of Object.entries(tables))for(const [index,row] of (table.rows??[]).entries())for(const [column,type] of Object.entries(table.columns??{})) {
    if(type.startsWith('ref:')&&!ids[type.slice(4)]?.has(row.values?.[column]))errors.push(`${name}[${index}].${column}: unresolved ${type} ${row.values?.[column]}`);
  }
  return errors;
}
export function generateSheets(document) {
  const errors=checkSheets(document);if(errors.length)throw new Error(errors.join('\n'));
  generationNames(document);
  let output='// Generated from config/sheets/exploration.json; do not edit.\n';
  for(const [table,{rows}] of orderedTables(document)) {
    for(const {values} of rows) {
      const name=`${table}_${values.id.replaceAll('-','_')}`;
      if(!/^[A-Za-z_]\w*$/.test(name))throw new Error('Invalid generated identifier');
      output+=`export const ${name}=deepFreeze(${JSON.stringify(values)});\n`;
    }
    output+=`export const ${table}=Object.freeze([${rows.map(r=>`${table}_${r.values.id.replaceAll('-','_')}`).join(',')}]);\n`;
  }
  const entries=orderedTables(document).map(([table,t],tableIndex)=>[table,Object.fromEntries([...t.rows].sort((a,b)=>a.values.id.localeCompare(b.values.id,'en')).map((row,rowIndex)=>[row.values.id,{table,tableIndex,rowIndex,id:row.values.id}]))]);
  output+=`export const sheetMetadata=deepFreeze(${JSON.stringify({sourceHash:sheetContentHash(document),tables:Object.fromEntries(entries)})});\n`;
  output+='export function sheetRow(table,id){return Object.hasOwn(sheetMetadata.tables,table)&&Object.hasOwn(sheetMetadata.tables[table],id)?sheetMetadata.tables[table][id]:null;}\n';
  return 'const deepFreeze=o=>{if(o&&typeof o==="object"){Object.values(o).forEach(deepFreeze);Object.freeze(o);}return o;};\n'+output;
}
export function generateNativeSheets(document) {
  const errors=checkSheets(document);if(errors.length)throw new Error(errors.join('\n'));
  generationNames(document);
  const identifier=s=>s.replaceAll('-','_');
  const used=new Set();
  const unique=name=>{if(!/^[A-Za-z_]\w*$/.test(name)||used.has(name))throw new Error(`Generated identifier collision: ${name}`);used.add(name);return name;};
  let output='// Generated active sheet records; do not edit.\n#pragma once\n#include <stdint.h>\n#include <stdbool.h>\n#include <wchar.h>\n';
  output+='typedef struct {bool available;const wchar_t *id,*reason;} SheetOptionalRef;\ntypedef struct {const wchar_t *const *items;size_t count;} SheetRefList;\n';
  output+=`#define EXPLORATION_SHEET_SHA256 "${sheetContentHash(document)}"\n`;
  const identities=[];
  for(const [table,t] of orderedTables(document)) {
    const columns=Object.fromEntries(Object.entries(t.columns).sort(([a],[b])=>a.localeCompare(b,'en'))),rows=t.rows;
    const type=unique(`Sheet_${identifier(table)}`);
    output+=`typedef struct {${Object.entries(columns).map(([column,t])=>`${t==='integer'?'int64_t':t==='boolean'?'bool':typeof t==='string'&&t.startsWith('optional-ref:')?'SheetOptionalRef':typeof t==='string'&&t.startsWith('list-ref:')?'SheetRefList':'const wchar_t *'} ${identifier(column)};`).join('')}} ${type};\n`;
    const names=[];
    for(const {values} of rows) {
      const name=unique(`sheet_${identifier(table)}_${identifier(values.id)}`);names.push(name);
      for(const [column,t] of Object.entries(columns))if(typeof t==='string'&&t.startsWith('list-ref:'))output+=`static const wchar_t *const ${unique(name+'_'+column+'_items')}[]={${values[column].length?values[column].map(v=>'L'+JSON.stringify(v)).join(','):'NULL'}};\n`;
      output+=`static const ${type} ${name}={${Object.entries(columns).map(([column,t])=>t==='integer'||t==='boolean'?JSON.stringify(values[column]):typeof t==='string'&&t.startsWith('optional-ref:')?`{${values[column].kind==='ref'?'true,L'+JSON.stringify(values[column].id)+',NULL':'false,NULL,L'+JSON.stringify(values[column].reason)}}`:typeof t==='string'&&t.startsWith('list-ref:')?`{${name}_${column}_items,${values[column].length}}`:'L'+JSON.stringify(values[column])).join(',')}};\n`;
    }
    output+=`static const ${type} *const ${unique(`sheet_${identifier(table)}_rows`)}[]={${names.length?names.map(n=>'&'+n).join(','):'NULL'}};\n`;
    output+=`static const size_t ${unique(`sheet_${identifier(table)}_count`)}=${rows.length};\n`;
    for(const [rowIndex,row] of [...rows].sort((a,b)=>a.values.id.localeCompare(b.values.id,'en')).entries())identities.push(`{L${JSON.stringify(table)},L${JSON.stringify(row.values.id)},${orderedTables(document).findIndex(([n])=>n===table)},${rowIndex},&sheet_${identifier(table)}_${identifier(row.values.id)}}`);
  }
  output+='typedef struct {const wchar_t *table,*id;size_t tableIndex,rowIndex;const void *value;} SheetRowIdentity;\n';
  output+=`static const SheetRowIdentity sheet_identities[]={${identities.length?identities.join(','):'{NULL,NULL,0,0,NULL}'}};\n`;
  output+=`static inline const SheetRowIdentity *sheetRowFind(const wchar_t *table,const wchar_t *id){if(!table||!id)return NULL;for(size_t i=0;i<${identities.length};i++)if(!wcscmp(table,sheet_identities[i].table)&&!wcscmp(id,sheet_identities[i].id))return &sheet_identities[i];return NULL;}\n`;
  return output;
}
export function publishSheets(document,output,{beforeCommit}={}){
 // Immutable snapshot plus one atomic commit pointer. Canonical consumers never
 // read the two compatibility files while a new pair is being published.
  const js=generateSheets(document),native=generateNativeSheets(document),sourceHash=sheetContentHash(document);
 fs.mkdirSync(output,{recursive:true});
 const lockPath=path.join(output,'sheet-generation.lock'),lock=fs.openSync(lockPath,'wx');
 let staging;
 try{
  const parent=path.join(output,'sheets');fs.mkdirSync(parent,{recursive:true});
  staging=fs.mkdtempSync(path.join(parent,'.staging-'));
  const files={'exploration-sheets.mjs':js,'exploration-sheets.h':native};
  for(const [name,data] of Object.entries(files))fs.writeFileSync(path.join(staging,name),data);
  const fileHashes=Object.fromEntries(Object.entries(files).map(([name,data])=>[name,crypto.createHash('sha256').update(data).digest('hex')]));
  const generationId=crypto.createHash('sha256').update(JSON.stringify({sourceHash,files:fileHashes})).digest('hex');
  const directory=path.join(parent,generationId);
  if(fs.existsSync(directory)){for(const [name,data] of Object.entries(files))if(fs.readFileSync(path.join(directory,name),'utf8')!==data)throw new Error('Immutable sheet snapshot differs; generator version/content hash collision');}
  else {fs.renameSync(staging,directory);staging=null;}
  const manifest={schemaVersion:1,sourceHash,generationId,directory:'sheets/'+generationId,files:fileHashes};
  for(const [name,data] of Object.entries(files)){const temp=path.join(output,name+'.tmp');fs.writeFileSync(temp,data);fs.renameSync(temp,path.join(output,name));}
  beforeCommit?.();
  const pointer=path.join(output,'sheet-generation.json');fs.writeFileSync(pointer+'.tmp',JSON.stringify(manifest,null,2)+'\n');fs.renameSync(pointer+'.tmp',pointer);
  return manifest;
 }finally{
  if(staging){for(const name of ['exploration-sheets.mjs','exploration-sheets.h']){const file=path.join(staging,name);if(fs.existsSync(file))fs.unlinkSync(file);}fs.rmdirSync(staging);}
  fs.closeSync(lock);fs.unlinkSync(lockPath);
 }
}
if(process.argv[1]&&pathToFileURL(path.resolve(process.argv[1])).href===import.meta.url) {
  const document=JSON.parse(fs.readFileSync(path.join(root,'config/sheets/exploration.json'),'utf8'));
  const errors=checkSheets(document);
  if(errors.length){console.error(errors.join('\n'));process.exitCode=1;}
  else {
    if(process.argv.includes('--generate')) {
      const outIndex=process.argv.indexOf('--out-dir');
      const output=outIndex>=0?path.resolve(process.argv[outIndex+1]):path.join(root,'build');
      publishSheets(document,output);
    }
    console.log('Sheet preflight: active cells have valid typed evidence; all references resolve. This does not certify a release.');
    for(const {values} of document.tables.systems.rows)if(values.releaseState!=='verified')console.log(`Release remains blocked: ${values.id}: ${values.releaseState}`);
  }
}
