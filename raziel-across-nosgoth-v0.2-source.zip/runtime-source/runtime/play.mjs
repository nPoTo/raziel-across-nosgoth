// SPDX-License-Identifier: GPL-3.0-or-later
import assert from 'node:assert/strict';
import path from 'node:path';
import {pathToFileURL} from 'node:url';
import {markPortableStartupFailed,packagedPath,userRuntimePath,verifyCompiledRuntime} from './check-payload.mjs';

const [host,hostBirth,donor,donorBirth,stopToken,mode]=process.argv.slice(2);
assert([host,hostBirth,donor,donorBirth].every(value=>/^[1-9]\d*$/.test(value??'')));
assert.equal(mode,'--prewarm');
assert.equal(path.dirname(path.resolve(stopToken)).toLowerCase(),userRuntimePath().toLowerCase());
assert.match(path.basename(stopToken),/^cancel-[a-f0-9]{32}\.stop$/);
const {entry}=verifyCompiledRuntime();
process.env.RAZIEL_DESKTOP_PAIR_BIRTHS=hostBirth+','+donorBirth;
process.env.RAZIEL_DESKTOP_CANCEL_PATH=stopToken;
process.env.RAZIEL_DESKTOP_PREWARM='1';
process.argv.splice(2,process.argv.length-2,host,donor,'--device=controller');
const {closePreparedDesktopHud}=await import('../workbench/desktop-sr1-linked-r1/tools/pause-receipt.mjs');
try {
    await import(pathToFileURL(packagedPath(entry)).href);
} catch(error) {
    markPortableStartupFailed();
    throw error;
} finally {
    await closePreparedDesktopHud();
}
