// SPDX-License-Identifier: GPL-3.0-or-later
import assert from 'node:assert/strict';
import {parentPort,workerData} from 'node:worker_threads';
import {AtomicSessionLease} from '../workbench/reaver-force-on-r20/tools/atomic-session-lease.mjs';

const {file,temporary,identity,leaseAgeMs,tick,qpcNs}=workerData;
assert(parentPort&&Number.isSafeInteger(tick)&&typeof qpcNs==='bigint');
const lease=new AtomicSessionLease(file,temporary,Buffer.from(identity),leaseAgeMs);
assert(lease.matches(file),'Session lease changed before the renewal worker started');
lease.owned=true;
function renew() {
    const elapsedMs=Number((process.hrtime.bigint()-qpcNs)/1000000n);
    lease.update(tick+elapsedMs);
}
renew();
const timer=setInterval(renew,100);
parentPort.once('message',message=>{
    assert.equal(message,'close');
    clearInterval(timer);
    // The creating process removes the owned files after joining this worker.
    parentPort.close();
});
