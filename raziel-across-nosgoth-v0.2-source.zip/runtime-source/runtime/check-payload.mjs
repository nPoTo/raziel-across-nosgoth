// SPDX-License-Identifier: GPL-3.0-or-later
import assert from 'node:assert/strict';
import {createHash} from 'node:crypto';
import fs from 'node:fs';
import path from 'node:path';

const root=path.resolve(import.meta.dirname,'..');
const hash=bytes=>createHash('sha256').update(bytes).digest('hex');
let validated;

export function packagedPath(name) {
    assert(typeof name==='string'&&!path.isAbsolute(name)&&!name.includes('\\')&&
        name.split('/').every(part=>part&&part!=='.'&&part!=='..'&&!part.includes(':')),'Invalid package path');
    return path.join(root,name);
}

export function verifyCompiledRuntime(_root,{installed=false}={}) {
    if(validated) return validated;
    const bytes=fs.readFileSync(packagedPath('runtime-manifest.json'));
    assert.equal(hash(bytes),process.env.RAZIEL_PACKAGED_RUNTIME_SHA256,'Unrecognized runtime manifest');
    const manifest=JSON.parse(bytes);
    assert.equal(manifest.kind,'standalone-desktop-runtime');
    for(const [file,expected] of Object.entries(manifest.files)){
        assert.equal(hash(fs.readFileSync(packagedPath(file))),expected,file);
    }
    validated={verified:true,version:manifest.kind,files:Object.keys(manifest.files).length,
        entry:manifest.entry,sheets:new Set(manifest.sheets)};
    return validated;
}

export function userRuntimePath(...parts) {
    const local=process.env.LOCALAPPDATA;
    assert(local&&path.win32.isAbsolute(local),'Windows Local AppData is unavailable');
    return path.join(local,'RazielAcrossNosgoth','runtime',...parts);
}

export function markPortableStartupFailed() {
    const stop=process.env.RAZIEL_DESKTOP_CANCEL_PATH;
    if(!stop||fs.existsSync(stop)||fs.existsSync(stop+'.ready')) return;
    try {fs.writeFileSync(stop+'.failed','',{flag:'wx'});}
    catch(error) {
        if(error.code!=='EEXIST') console.error('Could not notify the launcher of startup failure:',error.message);
    }
}

export function checkCompiledSheet(document) {
    const digest=hash(JSON.stringify(document));
    return verifyCompiledRuntime().sheets.has(digest)?[]:['This policy was not verified when the runtime was built'];
}
