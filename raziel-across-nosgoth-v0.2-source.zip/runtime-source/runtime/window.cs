// SPDX-License-Identifier: GPL-3.0-or-later
using System;
using System.Runtime.InteropServices;
using System.Text;

public static class RazielDesktopWindow
{
    private delegate bool EnumWindow(IntPtr window, IntPtr arg);
    [DllImport("user32.dll")] private static extern bool EnumWindows(EnumWindow cb, IntPtr arg);
    [DllImport("user32.dll")] private static extern uint GetWindowThreadProcessId(IntPtr h, out uint id);
    [DllImport("user32.dll")] private static extern int GetWindowTextLengthW(IntPtr h);
    [DllImport("user32.dll")] private static extern bool GetWindowRect(IntPtr h, out Rect rect);
    [DllImport("user32.dll")] public static extern bool IsWindowVisible(IntPtr h);
    [DllImport("user32.dll")] private static extern bool ShowWindowAsync(IntPtr h, int command);
    [DllImport("user32.dll")] private static extern bool PostMessageW(IntPtr h, uint msg, UIntPtr w, IntPtr l);
    [DllImport("user32.dll")] public static extern IntPtr GetForegroundWindow();
    [DllImport("user32.dll")] private static extern short GetAsyncKeyState(int key);
    [DllImport("user32.dll")] public static extern bool SetForegroundWindow(IntPtr h);
    [DllImport("kernel32.dll")] private static extern IntPtr OpenProcess(uint access, bool inheritHandle, int processId);
    [DllImport("kernel32.dll")] private static extern bool CloseHandle(IntPtr handle);
    [DllImport("kernel32.dll", CharSet = CharSet.Unicode, ExactSpelling = true)]
    private static extern bool QueryFullProcessImageNameW(IntPtr process, uint flags, StringBuilder image, ref int size);

    [StructLayout(LayoutKind.Sequential)]
    private struct Rect { public int L, T, R, B; }

    public static string ProcessImage(int pid)
    {
        const uint queryLimitedInformation = 0x1000;
        IntPtr process = OpenProcess(queryLimitedInformation, false, pid);
        if (process == IntPtr.Zero) return null;
        try
        {
            int length = 32768;
            var image = new StringBuilder(length);
            return QueryFullProcessImageNameW(process, 0, image, ref length) ? image.ToString() : null;
        }
        finally { CloseHandle(process); }
    }

    public static IntPtr Find(int pid)
    {
        IntPtr result = IntPtr.Zero;
        long biggest = 0;
        EnumWindows((h, arg) => {
            uint actual;
            GetWindowThreadProcessId(h, out actual);
            Rect rect;
            if (actual != pid || GetWindowTextLengthW(h) == 0 || !GetWindowRect(h, out rect)) return true;
            long area = (long)(rect.R - rect.L) * (rect.B - rect.T);
            if (area > biggest) { result = h; biggest = area; }
            return true;
        }, IntPtr.Zero);
        return result;
    }

    public static bool IsForeground(int pid)
    {
        uint actual;
        GetWindowThreadProcessId(GetForegroundWindow(), out actual);
        return actual == pid;
    }

    public static int ModKeyState() { return GetAsyncKeyState(0x79) & 0x8001; }
    public static int GuideKeyState() { return GetAsyncKeyState(0x76) & 0x8001; }

    public static void SetVisible(IntPtr window, bool visible)
    {
        if (window != IntPtr.Zero) ShowWindowAsync(window, visible ? 4 : 0);
    }

    public static void Close(IntPtr window, int pid)
    {
        uint actual;
        if (window != IntPtr.Zero && GetWindowThreadProcessId(window, out actual) != 0 && actual == pid)
            PostMessageW(window, 0x10, UIntPtr.Zero, IntPtr.Zero);
    }
}
