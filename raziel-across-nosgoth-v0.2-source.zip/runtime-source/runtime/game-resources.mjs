// SPDX-License-Identifier: GPL-3.0-or-later
import assert from 'node:assert/strict';
import {spawn} from 'node:child_process';
import {createHash} from 'node:crypto';
import fs from 'node:fs';
import path from 'node:path';
import {createInterface} from 'node:readline';

const defianceSha256='fc6a406ff7ac9b5eb7788dc7a65d335e1c1aad9236618112671975b71d2daddc';
const digest=buffer=>createHash('sha256').update(buffer).digest('hex');

export function openDefianceImage(file=process.env.RAZIEL_DEFIANCE_EXE) {
    assert(typeof file==='string'&&path.win32.isAbsolute(file)&&path.win32.basename(file).toLowerCase()==='defiance.exe',
        'The selected Defiance executable is required');
    const image=fs.readFileSync(file);
    assert.equal(digest(image),defianceSha256,'Unrecognized Defiance executable');
    assert(image.length>=64&&image.readUInt16LE(0)===0x5a4d);
    const pe=image.readUInt32LE(0x3c);
    assert(pe>=64&&pe<=image.length-26&&image.readUInt32LE(pe)===0x4550);
    const count=image.readUInt16LE(pe+6);
    const optional=image.readUInt16LE(pe+20);
    assert(count>=1&&count<=96&&optional>=2&&image.readUInt16LE(pe+24)===0x20b);
    const table=pe+24+optional;
    assert(table<=image.length-40*count);
    const sections=Array.from({length:count},(_,i)=>{
        const at=table+i*40;
        const rva=image.readUInt32LE(at+12);
        const rawSize=image.readUInt32LE(at+16);
        const rawOffset=image.readUInt32LE(at+20);
        assert(rawSize===0||rawOffset<=image.length-rawSize,'Invalid PE section data range');
        return {rva,rawSize,rawOffset};
    });
    return {file,image,sections};
}

export function checkedBindPose(pose,bindOffsets) {
    const hierarchy=pose?.baseHierarchyCandidate;
    assert(pose?.valid===true&&hierarchy?.valid===true);
    const {parents,bindLocalPositions:local}=hierarchy;
    assert(Array.isArray(parents)&&parents.length===85&&Array.isArray(local)&&local.length===85);
    assert(parents.every((p,i)=>Number.isInteger(p)&&p>=-1&&p<85&&p!==i));
    assert(Array.isArray(bindOffsets)&&bindOffsets.length>=85);
    assert(local.every(v=>Array.isArray(v)&&v.length===3&&v.every(Number.isFinite)));
    const positions=new Array(85),active=new Set();
    const resolve=i=>{
        if(positions[i]) return positions[i];
        assert(!active.has(i),'Defiance hierarchy cycle');
        active.add(i);
        const parent=parents[i]>=0?resolve(parents[i]):[0,0,0];
        const position=local[i].map((v,k)=>v+parent[k]);
        assert(position.every((v,k)=>Math.abs(v+bindOffsets[i][k])<0.01),'Defiance live rig differs from the installed mesh');
        active.delete(i);
        return positions[i]=position;
    };
    parents.forEach((_,i)=>resolve(i));
    return {parents,positions};
}

// The selected donor process is read in place. No capture or game resource is saved.
export async function readLiveDonorPose({pid,image,helper,sha256,timeout=3000}) {
    assert(Number.isSafeInteger(pid)&&pid>0&&pid<=0xffffffff);
    assert(/^[0-9a-f]{64}$/i.test(sha256)&&digest(fs.readFileSync(helper))===sha256.toLowerCase(),
        'The Defiance observer is missing or changed');
    const child=spawn(helper,[String(pid),'12','20','-','--pose'],{
        windowsHide:true,stdio:['ignore','pipe','ignore'],env:{...process.env,RAZIEL_DEFIANCE_EXE:image}
    });
    const closed=new Promise(resolve=>{
        child.once('error',()=>resolve(-1));
        child.once('close',resolve);
    });
    const deadline=setTimeout(()=>child.kill(),timeout);
    try{
        let session=false;
        for await(const line of createInterface({input:child.stdout,crlfDelay:Infinity})){
            assert(line.length<=65536,'Unbounded Defiance observer output');
            const row=JSON.parse(line);
            if(!session){
                assert(row.type==='session'&&row.mode==='read-only'&&row.pid===pid&&row.sha256===defianceSha256,
                    'Unexpected Defiance observer session');
                session=true;
            }else if(row.type==='sample'&&row.valid===true&&row.poseCandidate?.valid===true&&
                row.poseCandidate.baseHierarchyCandidate?.valid===true){
                return row.poseCandidate;
            }
        }
        throw new Error('The active Defiance rig did not become readable');
    }finally{
        clearTimeout(deadline);
        if(child.exitCode===null) child.kill();
        await closed;
    }
}
