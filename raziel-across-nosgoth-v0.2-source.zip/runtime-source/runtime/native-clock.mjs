// SPDX-License-Identifier: GPL-3.0-or-later
import assert from 'node:assert/strict';
import {performance} from 'node:perf_hooks';
import {captureStartupComparisonClock} from '../workbench/c0-startup-clock-r17/tools/inspect-startup-realms.mjs';

export async function calibrateSessionClock() {
    const {witness}=await captureStartupComparisonClock();
    const {tick,qpcBefore,qpcFrequency}=witness.observerClock;
    const qpcNs=BigInt(qpcBefore)*1000000000n/BigInt(qpcFrequency);
    const wallAtSample=performance.now()-Number(process.hrtime.bigint()-qpcNs)/1e6;
    assert(Number.isFinite(wallAtSample)&&wallAtSample>0);
    return {tick,wallAtSample,qpcNs};
}
