﻿#requires -Version 5.1
# SPDX-License-Identifier: GPL-3.0-or-later
param([Parameter(Mandatory)][string]$GameSelectionPath,[switch]$Validate)
$ErrorActionPreference='Stop'
Set-StrictMode -Version Latest
$workspace=[IO.Path]::GetFullPath((Join-Path $PSScriptRoot '..'))
$root=Join-Path $workspace 'workbench/desktop-sr1-linked-r1'
$reports=Join-Path $env:LOCALAPPDATA 'RazielAcrossNosgoth/runtime'
[void][IO.Directory]::CreateDirectory($reports)
$portalReports=$reports
$env:RAZIEL_RUNTIME_DIR=$reports
$env:RAZIEL_DESKTOP_PWSH=Join-Path $PSHOME 'powershell.exe'
$guideImagePath=Join-Path $root 'assets/launch-tutorial.png'
$darkIconPath=Join-Path $root 'assets/reaver-dark.ico'
$lightIconPath=Join-Path $root 'assets/reaver-light.ico'
$realmWorker=Join-Path $root 'tools/off-realm-follow.mjs'
Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing
function Digest([string]$Path) {
    $stream=[IO.File]::OpenRead($Path)
    try {
        $sha=[Security.Cryptography.SHA256]::Create()
        try { return [BitConverter]::ToString($sha.ComputeHash($stream)).Replace('-','').ToLowerInvariant() }
        finally { $sha.Dispose() }
    } finally { $stream.Dispose() }
}
function Log-LauncherError([string]$message) {
    Add-Content -LiteralPath (Join-Path $reports 'launcher-errors.log') -Value "[$([DateTimeOffset]::Now)] $message"
}
function Start-SelectedGame([string]$Image,[string]$SteamClient,[string]$App,[string]$GameArgument) {
    if($SteamClient){
        $launchArguments=@('-applaunch',$App)
        if($GameArgument){$launchArguments+=$GameArgument}
        Start-Process -FilePath $SteamClient -WorkingDirectory ([IO.Path]::GetDirectoryName($SteamClient)) -ArgumentList $launchArguments
    }else{
        $launchOptions=@{FilePath=$Image;WorkingDirectory=[IO.Path]::GetDirectoryName($Image)}
        if($GameArgument){$launchOptions.ArgumentList=$GameArgument}
        Start-Process @launchOptions
    }
}
function Test-SelectedProcess($Game,[string]$Image) {
    if(!$GameSelectionPath){return $true}
    $actual=[RazielDesktopWindow]::ProcessImage($Game.Id)
    if(!$actual){return $false}
    if([IO.Path]::GetFullPath($actual) -ine $Image){
        throw "The running game comes from a different installation. Expected $Image. Found $actual."
    }
    return $true
}
try {
    $timingPath=Join-Path $root 'config/sheets/desktop-startup-timing.json'
    if ((Digest $timingPath) -ne '05b3a26c0139898c7ccdfc70c419122528ad5cfb0f519710f00cc6dee2b10b02') {
        throw 'The desktop startup timing configuration has changed.'
    }
    $timing=(Get-Content -LiteralPath $timingPath -Raw | ConvertFrom-Json).tables.desktopStartupTiming.rows[0].values
    $manifest=Get-Content -LiteralPath (Join-Path $PSScriptRoot 'desktop.json') -Raw | ConvertFrom-Json
    $steamStart=$manifest
    $selection=Get-Content -LiteralPath $GameSelectionPath -Raw | ConvertFrom-Json
    $sr1=[IO.Path]::GetFullPath($selection.host)
    $defiance=[IO.Path]::GetFullPath($selection.donor)
    if($sr1 -ieq $defiance){throw 'The games must be in separate folders.'}
    $hostSteam=[string]$selection.hostSteam
    $donorSteam=[string]$selection.donorSteam
    foreach($client in @($hostSteam,$donorSteam)){
        if($client -and ([IO.Path]::GetFileName($client) -ine 'steam.exe' -or ![IO.File]::Exists($client))){
            throw 'The selected Steam installation has moved. Run Setup again.'
        }
    }
    $env:RAZIEL_SELECTED_GAME_DIRS=@{host=$sr1;donor=$defiance}|ConvertTo-Json -Compress
    $defExe=Join-Path $defiance 'defiance.exe'
    $srExe=Join-Path $sr1 'SRX.exe'
    $env:RAZIEL_SR1_EXE=$srExe
    $env:RAZIEL_DEFIANCE_EXE=$defExe
    $save=Join-Path $selection.save $steamStart.save
    if ((Digest $srExe) -ne '0fb3aef0530ebf0510191f934dc371b69b43574331d3623eda694b72f060db93' -or
        (Digest (Join-Path $sr1 '1/sr1.dll')) -ne 'c006dea45509cdc3fbfab3a4230b47869c306ecdd7df8b4fd2499fd3654a2205' -or
        (Digest $defExe) -ne $manifest.defianceSha256 -or
        (Digest (Join-Path $defiance 'scripts/Chapter10AutoLoad.asi')) -ne $manifest.moduleSha256 -or
        (Digest (Join-Path $defiance 'scripts/Chapter10SpawnPortal.asi')) -ne $manifest.portalSha256 -or
        (Digest (Join-Path $defiance 'scripts/LOKProbe.asi')) -ne $manifest.hostProbeSha256 -or
        (Digest (Join-Path $sr1 'scripts/LOKProbe.asi')) -ne $manifest.hostProbeSha256 -or
        (Digest $save) -ne $manifest.saveSha256) { throw 'The installed games, modules or Chapter 10 save have changed. Run Setup again.' }
    $node=Join-Path $PSScriptRoot 'node.exe'
    if ($manifest.debugArgument -cne '-dev') { throw 'Unexpected SR1 launch argument.' }
    Add-Type -Path (Join-Path $PSScriptRoot 'window.cs')
    if ($Validate) {
        $art=[Drawing.Image]::FromFile($guideImagePath)
        try {
            if ($art.Width -ne 1440 -or $art.Height -ne 900) { throw 'Unexpected guide image dimensions.' }
        } finally { $art.Dispose() }
        foreach($path in @($darkIconPath,$lightIconPath)) {
            $icon=[Drawing.Icon]::new($path,16,16)
            try {
                if ($icon.Width -ne 16 -or $icon.Height -ne 16) { throw 'Unexpected tray icon dimensions.' }
            } finally { $icon.Dispose() }
        }
        $hostRoute=if($hostSteam){'Steam'}else{'direct'}
        $donorRoute=if($donorSteam){'Steam'}else{'direct'}
        Write-Output "Verified shortcut and payload. Launch routes: Soul Reaver $hostRoute, Defiance $donorRoute."
        return
    }
} catch {
    if ($Validate) { throw }
    Log-LauncherError $_.Exception.Message
    return
}

$created=$false
$mutex=[Threading.Mutex]::new($true,'LocalRazielSR1DesktopLinked',$([ref]$created))
if (!$created) { $mutex.Dispose(); return }
$observer=Join-Path $workspace 'runtime/native/portal-placement-reader.exe'
$state=@{Donor=$null; HostGame=$null; Runner=$null; SteamRequest=$null; OwnDonor=$false;
    Enabled=$false; Cancel=$null; Exiting=$false; KeyDown=$false; PortalReady=$false; StartingHost=$false;
    Tick=0; First=[Diagnostics.Stopwatch]::StartNew(); Splash=$null; Guide=$null; GuideKeyDown=$false;
    StartupHold=$null; DebugProgress=$null; Ready=$null; Running=$false; PrepareNext=$true; Requested=$false;
    RealmFollower=$null; RealmStop=$null}
$darkIcon=[Drawing.Icon]::new($darkIconPath)
$lightIcon=[Drawing.Icon]::new($lightIconPath)
$tray=[Windows.Forms.NotifyIcon]::new()
$tray.Icon=$darkIcon
$menu=[Windows.Forms.ContextMenuStrip]::new()
$mode=$menu.Items.Add('Mod: Off')
$helpItem=$menu.Items.Add('Field Guide (F7)')
$toggle=$menu.Items.Add('Show Defiance')
$hideDonor=$menu.Items.Add('Hide Defiance')
$exit=$menu.Items.Add('Exit Launcher')
$tray.ContextMenuStrip=$menu
$tray.Text='Soul Reaver 1 — Mod: Off'
$tray.Visible=$true

function Birth($process) { $process.StartTime.ToUniversalTime().ToFileTimeUtc().ToString() }
function Alive($process) { $null -ne $process -and !$process.HasExited }
function Set-ModeStatus([string]$status) {
    $mode.Text="Mod: $status"
    $tray.Text="Soul Reaver 1 — Mod: $status"
    $tray.Icon=if($status -ceq 'On'){$lightIcon}else{$darkIcon}
}
function Close-LoadingImage {
    if ($state.Splash) {
        $state.Splash.Dispose()
        $state.Splash=$null
    }
}
function New-GuideWindow([switch]$Startup) {
    $form=[Windows.Forms.Form]::new()
    $art=[Drawing.Image]::FromFile($guideImagePath)
    $form.Tag=$art
    $form.add_Disposed({ param($sender,$eventArgs) $sender.Tag.Dispose() })
    $form.Text=if($Startup){'Loading Soul Reaver 1'}else{'Soul Reaver 1 — Field Guide (F7)'}
    $form.FormBorderStyle=if($Startup){'None'}else{'FixedDialog'}
    $form.MinimizeBox=$false
    $form.MaximizeBox=$false
    $form.ShowInTaskbar=$false
    $form.TopMost=$true
    $screen=[Windows.Forms.Screen]::FromPoint([Windows.Forms.Cursor]::Position)
    $area=$screen.WorkingArea
    $scale=[Math]::Min(1,[Math]::Min(($area.Width-32)/$art.Width,($area.Height-60)/$art.Height))
    $form.StartPosition=[Windows.Forms.FormStartPosition]::Manual
    $form.ClientSize=[Drawing.Size]::new([int]($art.Width*$scale),[int]($art.Height*$scale))
    $form.Location=[Drawing.Point]::new(
        [int]($area.Left+($area.Width-$form.Width)/2),
        [int]($area.Top+($area.Height-$form.Height)/2))
    $picture=[Windows.Forms.PictureBox]::new()
    $picture.Dock=[Windows.Forms.DockStyle]::Fill
    $picture.SizeMode=[Windows.Forms.PictureBoxSizeMode]::Zoom
    $picture.Image=$art
    if ($Startup) {
        $imageSize=$form.ClientSize
        $bounds=[Windows.Forms.SystemInformation]::VirtualScreen
        $form.BackColor=[Drawing.Color]::Black
        $form.Bounds=$bounds
        $picture.Dock=[Windows.Forms.DockStyle]::None
        $picture.Size=$imageSize
        $picture.Location=[Drawing.Point]::new(
            [int]($area.Left-$bounds.Left+($area.Width-$imageSize.Width)/2),
            [int]($area.Top-$bounds.Top+($area.Height-$imageSize.Height)/2))
    }
    $form.Controls.Add($picture)
    return $form
}
function Show-LoadingImage {
    $state.Splash=New-GuideWindow -Startup
    $state.Splash.Show()
    $state.Splash.Refresh()
}
function Switch-Guide {
    if ($state.Guide -and !$state.Guide.IsDisposed) { $state.Guide.Close(); return }
    if ($state.Exiting -or $state.Splash -or !(Alive $state.HostGame)) { return }
    $state.Guide=New-GuideWindow
    $state.Guide.KeyPreview=$true
    $state.Guide.add_KeyDown({
        param($sender,$eventArgs)
        if ($eventArgs.KeyCode -eq [Windows.Forms.Keys]::Escape) { $sender.Close() }
    })
    $state.Guide.add_FormClosed({
        $state.Guide=$null
        if (!$state.Exiting -and (Alive $state.HostGame)) {
            [void][RazielDesktopWindow]::SetForegroundWindow([RazielDesktopWindow]::Find($state.HostGame.Id))
        }
    })
    $state.Guide.Show()
}
function DonorSceneReady {
    if ($state.OwnDonor) {
        $log=Join-Path $reports ('autoload-'+$state.Donor.Id+'.log')
        if (![IO.File]::Exists($log) -or
            !(Select-String -LiteralPath $log -SimpleMatch 'Chapter 10 request returned' -Quiet)) { return $false }
    }
    $portalLog=Join-Path $portalReports ('portal-'+$state.Donor.Id+'.log')
    if (![IO.File]::Exists($portalLog) -or
        !(Select-String -LiteralPath $portalLog -SimpleMatch 'CHAPTER10 test slot verified' -Quiet) -or
        !(Select-String -LiteralPath $portalLog -SimpleMatch 'PORTAL native resource stream complete' -Quiet)) { return $false }
    $reply= & $observer $state.Donor.Id (Birth $state.Donor) 5 2>$null
    if ($LASTEXITCODE -ne 0) { return $false }
    $samples=@($reply | ForEach-Object {ConvertFrom-Json -InputObject $_} | Where-Object {
        $_.type -eq 'sample' -and $_.valid -and $_.realm -eq 2 -and !$_.mode -and $_.phase -in 0,1 -and
        $_.nativePortal -and $_.portalEligible -and $_.previewEligible -and
        [Math]::Abs($_.portalPosition[0]-$steamStart.portalPosition[0]) -lt 1 -and
        [Math]::Abs($_.portalPosition[1]-$steamStart.portalPosition[1]) -lt 1 -and
        [Math]::Abs($_.portalPosition[2]-$steamStart.portalPosition[2]) -lt 1
    })
    return $samples.Count -eq 5
}
function End-DesktopSession([switch]$KeepDonor) {
    if (Alive $state.Donor) {
        $window=[RazielDesktopWindow]::Find($state.Donor.Id)
        if ($state.OwnDonor -and !$KeepDonor) { [RazielDesktopWindow]::Close($window,$state.Donor.Id) }
        else { [RazielDesktopWindow]::SetVisible($window,$true) }
    }
    [Windows.Forms.Application]::ExitThread()
}
function Stop-DesktopMod {
    if ($state.StartupHold) { [void]$state.StartupHold.Reset() }
    if ((Alive $state.Runner) -and ![IO.File]::Exists($state.Cancel)) {
        $file=[IO.File]::Open($state.Cancel,[IO.FileMode]::CreateNew)
        $file.Dispose()
    }
}
function Start-RealmFollower {
    $id=[Guid]::NewGuid().ToString('N')
    $state.RealmStop=Join-Path $reports "realm-$id.stop"
    $workerArgs="`"$realmWorker`" $($state.HostGame.Id) $(Birth $state.HostGame) $($state.Donor.Id) $(Birth $state.Donor) $PID `"$($state.RealmStop)`""
    $state.RealmFollower=Start-Process -FilePath $node -ArgumentList $workerArgs -WorkingDirectory $workspace `
        -WindowStyle Hidden -RedirectStandardOutput (Join-Path $reports "realm-$id.jsonl") `
        -RedirectStandardError (Join-Path $reports "realm-$id.err") -PassThru
}
function Reset-FailedStartup {
    if(!$state.Requested -or $state.Running -or ![IO.File]::Exists($state.Cancel+'.failed')){return $false}
    [void]$state.StartupHold.Reset()
    $state.Enabled=$false
    [void]$state.DebugProgress.Set()
    Set-ModeStatus 'Off'
    return $true
}
function Switch-DesktopMod {
    if(Reset-FailedStartup){return}
    if ($state.Exiting -or !$state.DebugProgress) { return }
    $state.Enabled=!$state.Enabled
    if ($state.Enabled) { Set-ModeStatus 'Starting' } else { Set-ModeStatus 'Off' }
    if ($state.Enabled) {
        [void]$state.DebugProgress.Reset()
        [void]$state.StartupHold.Set()
    }
    else { Stop-DesktopMod }
}
function Start-Sr1 {
    $running=@(Get-Process SRX -ErrorAction SilentlyContinue)
    if ($running.Count -gt 1) { throw 'More than one SR1 instance is running.' }
    if (!$running.Count) {
        if (!$state.StartingHost) {
            Start-SelectedGame $srExe $hostSteam '2521380' $manifest.debugArgument
            $state.StartingHost=$true
            $state.First.Restart()
        }
        if ($state.First.Elapsed.TotalSeconds -gt 60) { throw 'Soul Reaver did not start.' }
        return
    }
    if(!(Test-SelectedProcess $running[0] $srExe)){
        if($state.First.Elapsed.TotalSeconds -gt 60){throw 'Windows did not confirm the Soul Reaver executable.'}
        return
    }
    $state.HostGame=$running[0]
    $info=Get-CimInstance Win32_Process -Filter ('ProcessId='+$state.HostGame.Id)
    if ($info.CommandLine -notmatch '(?i)(^|[\s"])\-dev([\s"]|$)') { throw 'Open SR1 from this shortcut to enable Debug mode.' }
    $created=$false
    $holdName="Local\RazielSR1Startup-$($state.HostGame.Id)-$(Birth $state.HostGame)"
    $state.StartupHold=[Threading.EventWaitHandle]::new($false,[Threading.EventResetMode]::ManualReset,$holdName,[ref]$created)
    if (!$created) { throw 'Another launcher owns the SR1 startup input hold.' }
    $debugName="Local\RazielSR1DebugProgress-$($state.HostGame.Id)-$(Birth $state.HostGame)"
    $state.DebugProgress=[Threading.EventWaitHandle]::new($true,[Threading.EventResetMode]::ManualReset,$debugName,[ref]$created)
    if (!$created) { throw 'Another launcher owns the SR1 debug progression switch.' }
}
function Start-LinkedRuntime {
    $id=[Guid]::NewGuid().ToString('N')
    $state.Cancel=Join-Path $reports "cancel-$id.stop"
    $state.Ready=$state.Cancel+'.ready'
    $state.Running=$false
    $state.Requested=$false
    $state.PrepareNext=$false
    $out=Join-Path $reports "runner-$id.jsonl"
    $err=Join-Path $reports "runner-$id.err"
    $entry=Join-Path $PSScriptRoot 'play.mjs'
    $args="`"$entry`" $($state.HostGame.Id) $(Birth $state.HostGame) $($state.Donor.Id) $(Birth $state.Donor) `"$($state.Cancel)`" --prewarm"
    $state.Runner=Start-Process -FilePath $node -ArgumentList $args -WorkingDirectory $workspace -WindowStyle Hidden -RedirectStandardOutput $out -RedirectStandardError $err -PassThru
}
$toggle.add_Click({
    if (Alive $state.Donor) {
        [RazielDesktopWindow]::SetVisible([RazielDesktopWindow]::Find($state.Donor.Id),$true)
    }
})
$hideDonor.add_Click({
    if ($state.PortalReady -and (Alive $state.Donor)) {
        [RazielDesktopWindow]::SetVisible([RazielDesktopWindow]::Find($state.Donor.Id),$false)
    }
})
$mode.add_Click({ Switch-DesktopMod })
$helpItem.add_Click({ Switch-Guide })
$exit.add_Click({ $state.Exiting=$true; Stop-DesktopMod })
$timer=[Windows.Forms.Timer]::new()
$timer.Interval=$timing.launcherTickMs
$portalPollTicks=[int][Math]::Ceiling(880/$timer.Interval)
$realmRetryTicks=[int][Math]::Ceiling(2000/$timer.Interval)
$timer.add_Tick({
    try {
        $state.Tick++
        if (!$state.Donor) {
            $arrivals=@(Get-Process defiance -ErrorAction SilentlyContinue)
            if ($arrivals.Count -gt 1) { throw 'More than one Defiance instance is running.' }
            if (!$arrivals.Count) {
                if ($state.First.Elapsed.TotalSeconds -gt 95) { throw 'Defiance did not start.' }
                return
            }
            if(!(Test-SelectedProcess $arrivals[0] $defExe)){
                if($state.First.Elapsed.TotalSeconds -gt 95){throw 'Windows did not confirm the Defiance executable.'}
                return
            }
            $state.Donor=$arrivals[0]
        }
        if ($state.Exiting -or !(Alive $state.Donor) -or ($state.HostGame -and !(Alive $state.HostGame))) {
            if (Alive $state.Runner) { Stop-DesktopMod; return }
            End-DesktopSession
            return
        }
        if (!$state.PortalReady) {
            $window=[IntPtr]::Zero
            if ($state.OwnDonor) {
                $window=[RazielDesktopWindow]::Find($state.Donor.Id)
                if ($window -ne [IntPtr]::Zero -and [RazielDesktopWindow]::IsWindowVisible($window)) {
                    [RazielDesktopWindow]::SetVisible($window,$false)
                }
            }
            if (($state.Tick % $portalPollTicks) -eq 0 -and (DonorSceneReady)) {
                if ($state.OwnDonor) {
                    if ($window -eq [IntPtr]::Zero) {
                        if ($state.First.Elapsed.TotalSeconds -gt 95) { throw 'The Defiance window could not be found after loading Chapter 10.' }
                        return
                    }
                    if ([RazielDesktopWindow]::IsWindowVisible($window)) {
                        if ($state.First.Elapsed.TotalSeconds -gt 95) { throw 'The Defiance window did not stay hidden.' }
                        return
                    }
                }
                $state.PortalReady=$true
                if ($state.SteamRequest) { $state.SteamRequest.Dispose(); $state.SteamRequest=$null }
            } elseif ($state.First.Elapsed.TotalSeconds -gt 95) {
                throw 'Defiance did not confirm Chapter 10 in the Spectral Realm at the portal.'
            }
            return
        }
        if (!$state.HostGame) { Start-Sr1; return }
        if (!$state.RealmFollower) {
            Start-RealmFollower
        } elseif ($state.RealmFollower.HasExited -and ($state.Tick % $realmRetryTicks) -eq 0) {
            $state.RealmFollower.Dispose()
            $state.RealmFollower=$null
        }
        if ($state.Splash) {
            $hostWindow=[RazielDesktopWindow]::Find($state.HostGame.Id)
            if ($hostWindow -ne [IntPtr]::Zero -and [RazielDesktopWindow]::IsWindowVisible($hostWindow)) {
                Close-LoadingImage
            } elseif ($state.StartingHost -and $state.First.Elapsed.TotalSeconds -gt 60) {
                throw 'SR1 started without opening its game window.'
            }
        }
        [void](Reset-FailedStartup)
        $keyState=[RazielDesktopWindow]::ModKeyState()
        if ($keyState -ne 0 -and !$state.KeyDown -and [RazielDesktopWindow]::IsForeground($state.HostGame.Id)) {
            Switch-DesktopMod
        }
        $state.KeyDown=($keyState -band 0x8000) -ne 0
        $guideKey=[RazielDesktopWindow]::GuideKeyState()
        if ($guideKey -ne 0 -and !$state.GuideKeyDown -and
            ([RazielDesktopWindow]::IsForeground($state.HostGame.Id) -or
             ($state.Guide -and [RazielDesktopWindow]::GetForegroundWindow() -eq $state.Guide.Handle))) {
            Switch-Guide
        }
        $state.GuideKeyDown=($guideKey -band 0x8000) -ne 0
        if ($state.Runner -and $state.Runner.HasExited) {
            [void]$state.StartupHold.Reset()
            $state.PrepareNext=$state.Requested
            if ($state.Requested -and $state.Runner.ExitCode -ne 0 -and ![IO.File]::Exists($state.Cancel)) {
                if ($state.Enabled -and [IO.File]::Exists($state.Cancel+'.recover')) {
                    Set-ModeStatus 'Resuming'
                } else {
                    $state.Enabled=$false
                    Set-ModeStatus 'Off'
                }
            }
            [IO.File]::Delete($state.Cancel+'.recover')
            [IO.File]::Delete($state.Cancel+'.arm')
            [IO.File]::Delete($state.Cancel+'.failed')
            [IO.File]::Delete($state.Cancel+'.activate')
            [IO.File]::Delete($state.Cancel)
            [IO.File]::Delete($state.Ready)
            $state.Cancel=$null
            $state.Ready=$null
            $state.Runner.Dispose()
            $state.Runner=$null
            $state.Running=$false
            $state.Requested=$false
        }
        if ($state.Enabled -and $state.Runner -and !$state.Running -and ![IO.File]::Exists($state.Cancel)) {
            if ([IO.File]::Exists($state.Ready)) {
                [void]$state.StartupHold.Reset()
                $state.Running=$true
                Set-ModeStatus 'On'
            } elseif ([IO.File]::Exists($state.Cancel+'.arm')) {
                [void]$state.StartupHold.Set()
            }
        }
        $focused=[RazielDesktopWindow]::IsForeground($state.HostGame.Id)
        if (!$state.Runner -and ($state.PrepareNext -or ($state.Enabled -and $focused))) {
            Start-LinkedRuntime
        }
        if ($state.Enabled -and $focused -and (Alive $state.Runner) -and !$state.Requested) {
            $file=[IO.File]::Open($state.Cancel+'.activate',[IO.FileMode]::CreateNew)
            $file.Dispose()
            $state.Requested=$true
        }
        if (!$state.Enabled -and !$state.Exiting -and !$state.Requested) { [void]$state.DebugProgress.Set() }
    } catch {
        $timer.Stop()
        Stop-DesktopMod
        Log-LauncherError $_.Exception.Message
        End-DesktopSession -KeepDonor
    }
})
try {
    $existing=@(Get-Process defiance -ErrorAction SilentlyContinue)
    if ($existing.Count -gt 1) { throw 'More than one Defiance instance is running.' }
    if (!$existing.Count -or !(Get-Process SRX -ErrorAction SilentlyContinue)) { Show-LoadingImage }
    if (!$existing.Count) {
        $newEvent=$false
        $state.SteamRequest=[Threading.EventWaitHandle]::new($false,[Threading.EventResetMode]::AutoReset,$steamStart.event,[ref]$newEvent)
        if (!$newEvent) { throw 'A Defiance launch request already exists.' }
        [void]$state.SteamRequest.Set()
        if($GameSelectionPath){Start-SelectedGame $defExe $donorSteam ([string]$steamStart.app) ''}
        else{Start-Process -FilePath ('steam://rungameid/'+$steamStart.app) -WindowStyle Hidden}
        $state.OwnDonor=$true
    }
    $timer.Start()
    [Windows.Forms.Application]::Run()
} catch {
    Log-LauncherError $_.Exception.Message
} finally {
    Close-LoadingImage
    if ($state.RealmFollower) {
        if (Alive $state.RealmFollower) {
            [IO.File]::WriteAllBytes($state.RealmStop,[byte[]]@())
            [void]$state.RealmFollower.WaitForExit(1100)
        }
        if ($state.RealmFollower.HasExited) { [IO.File]::Delete($state.RealmStop) }
        $state.RealmFollower.Dispose()
    }
    if ($state.Guide) { $state.Guide.Dispose() }
    if ($state.StartupHold) { $state.StartupHold.Dispose() }
    if ($state.DebugProgress) { $state.DebugProgress.Dispose() }
    $timer.Dispose()
    $tray.Visible=$false
    $tray.Dispose()
    $lightIcon.Dispose()
    $darkIcon.Dispose()
    $menu.Dispose()
    if ($state.SteamRequest) { $state.SteamRequest.Dispose() }
    if ($state.Cancel -and !(Alive $state.Runner)) {
        [IO.File]::Delete($state.Cancel)
        [IO.File]::Delete($state.Ready)
        [IO.File]::Delete($state.Cancel+'.recover')
        [IO.File]::Delete($state.Cancel+'.arm')
        [IO.File]::Delete($state.Cancel+'.failed')
        [IO.File]::Delete($state.Cancel+'.activate')
    }
    $mutex.ReleaseMutex()
    $mutex.Dispose()
}
