// SPDX-License-Identifier: GPL-3.0-or-later
import {pathToFileURL} from 'node:url';
import path from 'node:path';
import {packagedPath,verifyCompiledRuntime} from './check-payload.mjs';

const {entry}=verifyCompiledRuntime();
const {captureStartupComparisonClock}=await import('../workbench/c0-startup-clock-r17/tools/inspect-startup-realms.mjs');
await captureStartupComparisonClock();
process.argv.splice(2,process.argv.length-2,'--offline-check');
process.chdir(path.dirname(packagedPath('runtime')));
await import(pathToFileURL(packagedPath(entry)).href);
