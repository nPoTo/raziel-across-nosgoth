// SPDX-License-Identifier: GPL-3.0-or-later
#include <stdio.h>
#include <MinHook.h>
#include "host-transition-observer.h"
static HostTransitionObserver observer;static DonorMessageObserverThread tls;
static struct {DonorMessageLease lease;unsigned calls,wholeCalls,errors,reads,nesting,wanted;int status;bool afterFails,changeSession,actorChange;uintptr_t payload;} f;
static bool lease(void *c,DonorMessageLease *out){(void)c;*out=f.lease;SetLastError(0xaaaa);return true;}
static int snapshot(void *c,void *state,uintptr_t requested,HostTransitionMetadata *m){(void)c;f.reads++;if(state!=(void *)0x1000||requested!=0xf4490)f.errors++;*m=(HostTransitionMetadata){.opaqueActor=f.actorChange&&f.reads>1?0x3000:0x2000,.requestedRva=0xf4490,.handlers={0xf2180,0xf2180,0xeeb40},.clips={0,117,22}};if(f.calls)m->handlers[1]=0xf4490;SetLastError(0xbbbb);return f.afterFails&&f.reads>1?-1:f.status;}
static uintptr_t __fastcall sectionOriginal(void *state,int32_t section,uintptr_t requested,uintptr_t payload){
 f.calls++;if(state!=(void *)0x1000||section!=1||requested!=0xf4490||payload!=f.payload||GetLastError()!=0x12345678)f.errors++;
 if(++f.nesting<f.wanted){SetLastError(0x12345678);uintptr_t r=hostSectionTransitionForward(&observer,&tls,sectionOriginal,state,section,requested,payload,0xf469b);if(r!=UINT64_C(0xfedcba9876543210))f.errors++;}f.nesting--;if(f.changeSession)f.lease.session++;SetLastError(0x87654321);return UINT64_C(0xfedcba9876543210);
}
static uintptr_t __fastcall wholeOriginal(void *state,uintptr_t requested,uintptr_t payload){f.wholeCalls++;if(GetLastError()!=0x12345678)f.errors++;SetLastError(0x12345678);HostSectionTransition volatile target=sectionOriginal;return target(state,1,requested,payload);}
static void setup(void){memset(&f,0,sizeof(f));memset(&tls,0,sizeof(tls));f.lease=(DonorMessageLease){true,17,1000,1000,1000};f.wanted=1;f.status=1;f.payload=UINT64_C(0xabcdef0123456789);hostTransitionInit(&observer,NULL,lease,snapshot);}
static bool run(void){SetLastError(0x12345678);uintptr_t r=hostSectionTransitionForward(&observer,&tls,sectionOriginal,(void *)0x1000,1,0xf4490,f.payload,0xf469b);return r==UINT64_C(0xfedcba9876543210)&&GetLastError()==0x87654321&&!f.errors;}
static HostSectionTransition sectionTrampoline;static HostWholeTransition wholeTrampoline;
static uintptr_t __fastcall sectionHook(void *s,int32_t i,uintptr_t r,uintptr_t p){return hostSectionTransitionForward(&observer,&tls,sectionTrampoline,s,i,r,p,0xf469b);}
static uintptr_t __fastcall wholeHook(void *s,uintptr_t r,uintptr_t p){return hostWholeTransitionForward(&observer,&tls,wholeTrampoline,s,r,p,0xe4a00);}
static DWORD WINAPI producer(LPVOID unused){(void)unused;for(uint64_t i=1;i<=4000;i++){HostTransitionEvent e={0};e.callId=i;e.clips[2]=(uint32_t)(i^0x55aa);while(!hostTransitionPush(&observer,&e))SwitchToThread();}return 0;}
#define CHECK(c,n) do{if(!(c)){printf("FAIL %u\n",(unsigned)n);return n;}}while(0)
int main(void){
 HostTransitionEvent e;setup();CHECK(run()&&f.calls==1&&observer.published==2&&tls.depth==0,1);CHECK(hostTransitionPop(&observer,&e)&&e.phase==1&&e.kind==1&&e.section==1&&!e.payloadZero&&e.clips[1]==117,2);CHECK(hostTransitionPop(&observer,&e)&&e.phase==2&&e.afterValid&&e.sameActor&&e.handlers[1]==0xf4490,3);
 setup();f.status=0;CHECK(run()&&!observer.published&&observer.unrelated==1&&!observer.dropped,4);
 setup();f.status=-1;CHECK(run()&&observer.metadataDrops==1&&!observer.published,5);
 setup();f.lease.nowTick=f.lease.heartbeatTick=61000;CHECK(run()&&observer.boundaryRejected==1&&!observer.dropped,6);
 setup();f.lease.nowTick=2500;CHECK(run()&&observer.leaseDrops==1,7);
 setup();f.changeSession=true;CHECK(run()&&observer.leaseDrops==1&&observer.published==1,8);
 setup();f.afterFails=true;CHECK(run()&&hostTransitionPop(&observer,&e)&&hostTransitionPop(&observer,&e)&&!e.afterValid&&!e.sameActor&&!e.handlers[0]&&!e.clips[1],9);
 setup();f.actorChange=true;CHECK(run()&&hostTransitionPop(&observer,&e)&&hostTransitionPop(&observer,&e)&&e.afterValid&&!e.sameActor,10);
 setup();f.wanted=3;CHECK(run()&&f.calls==3&&observer.published==6&&tls.depth==0,11);
 setup();observer.producerThread=(LONG)GetCurrentThreadId()+1;CHECK(run()&&observer.producerDrops==1,12);
 setup();observer.writeCursor=512;CHECK(run()&&observer.queueDrops==1,13);
 setup();observer.published=4096;CHECK(run()&&observer.budgetDrops==1,14);
 setup();tls.depth=UINT32_MAX;CHECK(run()&&observer.depthDrops==1&&tls.depth==UINT32_MAX,15);
 setup();f.lease.enabled=false;CHECK(run()&&!observer.published&&!observer.dropped,16);
 setup();CHECK(MH_Initialize()==MH_OK&&MH_CreateHook((PVOID)sectionOriginal,(PVOID)sectionHook,(PVOID *)&sectionTrampoline)==MH_OK&&MH_CreateHook((PVOID)wholeOriginal,(PVOID)wholeHook,(PVOID *)&wholeTrampoline)==MH_OK&&MH_EnableHook((PVOID)sectionOriginal)==MH_OK&&MH_EnableHook((PVOID)wholeOriginal)==MH_OK,17);
 HostWholeTransition volatile target=wholeOriginal;SetLastError(0x12345678);uintptr_t r=target((void *)0x1000,0xf4490,f.payload);DWORD last=GetLastError();CHECK(MH_DisableHook((PVOID)wholeOriginal)==MH_OK&&MH_DisableHook((PVOID)sectionOriginal)==MH_OK&&MH_RemoveHook((PVOID)wholeOriginal)==MH_OK&&MH_RemoveHook((PVOID)sectionOriginal)==MH_OK&&MH_Uninitialize()==MH_OK,18);CHECK(r==UINT64_C(0xfedcba9876543210)&&last==0x87654321&&f.calls==1&&f.wholeCalls==1&&!f.errors&&observer.published==4&&tls.depth==0,19);
 CHECK(hostTransitionPop(&observer,&e)&&e.kind==2&&e.section==UINT32_MAX&&e.depth==1&&hostTransitionPop(&observer,&e)&&e.kind==1&&e.depth==2,20);
 setup();HANDLE t=CreateThread(NULL,0,producer,NULL,0,NULL);CHECK(t,21);uint64_t wanted=1,deadline=GetTickCount64()+5000;while(wanted<=4000&&GetTickCount64()<deadline){if(hostTransitionPop(&observer,&e)){CHECK(e.callId==wanted&&e.clips[2]==(uint32_t)(wanted^0x55aa),22);wanted++;}else SwitchToThread();}CHECK(wanted==4001&&WaitForSingleObject(t,1000)==WAIT_OBJECT_0&&CloseHandle(t)&&observer.published==4000,23);
 puts("PASS: production local4arg/whole3arg forwarding opaque64 args, RAX/LastError; actual two-hook nested MinHook fixture; lease/identity/metadata/depth/producer/queue/budget; concurrent4000 SPSC records");return 0;
}
