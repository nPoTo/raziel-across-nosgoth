// SPDX-License-Identifier: GPL-3.0-or-later
// Receives already validated packets on stdin; holds them only in pagefile RAM.
#define WIN32_LEAN_AND_MEAN
#include "render-memory.h"
#include <stdlib.h>
#include <string.h>
#include <io.h>
#include <fcntl.h>
static bool readExact(void *bytes,size_t size){return fread(bytes,1,size,stdin)==size;}
int main(int argc,char **argv) {
    char *end=NULL;unsigned long pid=argc==2?strtoul(argv[1],&end,10):0;
    if(!pid||!end||*end){fprintf(stderr,"Usage: render-memory-writer HOST_PID\n");return 1;}
    HANDLE host=OpenProcess(SYNCHRONIZE,FALSE,pid);if(!host)return 2;
    wchar_t name[96],lockName[96];renderMemoryNames(pid,name,lockName);
    SetLastError(0);HANDLE lock=CreateMutexW(NULL,FALSE,lockName);bool existing=GetLastError()==ERROR_ALREADY_EXISTS;
    if(!lock||existing){if(lock)CloseHandle(lock);CloseHandle(host);return 3;}
    SetLastError(0);HANDLE mapping=CreateFileMappingW(INVALID_HANDLE_VALUE,NULL,PAGE_READWRITE,0,sizeof(RenderMemory),name);existing=GetLastError()==ERROR_ALREADY_EXISTS;
    RenderMemory *view=mapping&&!existing?MapViewOfFile(mapping,FILE_MAP_WRITE|FILE_MAP_READ,0,0,sizeof(RenderMemory)):NULL;
    if(!view){if(mapping)CloseHandle(mapping);CloseHandle(lock);CloseHandle(host);return 4;}
    _setmode(_fileno(stdin),_O_BINARY);
    uint32_t header[4];unsigned char *live=malloc(RM_LIVE_BYTES);unsigned frames=0;int result=5;
    if(!live||!readExact(header,sizeof(header))||header[0]!=RM_MAGIC||header[1]!=RM_GEOMETRY_BYTES||header[2]!=RM_APPEARANCE_BYTES||header[3]!=RM_LIVE_BYTES)goto done;
    if(!readExact(view->geometry,RM_GEOMETRY_BYTES)||!readExact(view->appearance,RM_APPEARANCE_BYTES))goto done;
    // Static buffers are immutable once online becomes visible under the mutex.
    size_t received;unsigned char movement[RM_MOVEMENT_BYTES];
    while((received=fread(live,1,RM_LIVE_BYTES,stdin))==RM_LIVE_BYTES) {
        if(!readExact(movement,sizeof(movement))){result=8;goto done;}
        if(WaitForSingleObject(host,0)!=WAIT_TIMEOUT){result=6;goto done;}
        if(WaitForSingleObject(lock,1000)!=WAIT_OBJECT_0){result=7;goto done;}
        memcpy(view->live,live,RM_LIVE_BYTES);
        memcpy(view->movement,movement,sizeof(movement));
        view->magic=RM_MAGIC;view->version=RM_VERSION;view->hostPid=pid;view->writerPid=GetCurrentProcessId();
        view->geometryBytes=RM_GEOMETRY_BYTES;view->appearanceBytes=RM_APPEARANCE_BYTES;view->liveBytes=RM_LIVE_BYTES;view->online=1;
        ReleaseMutex(lock);frames++;
    }
    result=received==0&&feof(stdin)&&!ferror(stdin)&&frames?0:8;
done:
    if(WaitForSingleObject(lock,1000)==WAIT_OBJECT_0){view->online=0;ReleaseMutex(lock);}
    fprintf(stderr,"Memory packets published: %u; exit=%d\n",frames,result);
    free(live);UnmapViewOfFile(view);CloseHandle(mapping);CloseHandle(lock);CloseHandle(host);return result;
}
