// SPDX-License-Identifier: GPL-3.0-or-later
#pragma once
#include "host-rig-reader.h"
#include "sr1-retarget-gate.h"
// A matrix read race is not a native-action transition. Reuse only a complete
// coherent receipt, never the raced matrices or a refreshed timestamp.
typedef struct{bool ready;HostRig rig;uint64_t tick;unsigned kind;uint32_t callbacks[3];} HostRigContinuity;
static inline bool hostRigContinuitySelect(HostRigContinuity *cache,const HostRig *observed,bool coherent,bool matrixRace,unsigned reason,bool currentContext,const Sr1RetargetContext *context,uint64_t now,HostRig *out,uint64_t *tick,bool *held){
 const Sheet_nativeHandoffContinuityPolicy *p=&sheet_nativeHandoffContinuityPolicy_coherent_host;
 if(held)*held=false;
 if(!cache||!out||!tick||!held||!observed||!currentContext||!context||p->readFailure!=14||p->maxAgeMs!=150||!p->preserveRigTick||!p->requireCurrentContext||!p->requireSameIdentity||p->identityWrites||p->enabled){if(cache)cache->ready=false;return false;}
 unsigned kind=sr1RetargetContextAllowed(context)?2:0;
#ifdef SR1_NATIVE_JUMP_POSE
 if(sr1RetargetJumpContextAllowed(context))kind=3;
#endif
 // A real native boundary is never bridged by an old pose. Coherent native
 // observations can still report identity/context, but do not seed continuity.
 if(coherent&&reason==0){cache->ready=kind!=0;if(cache->ready){cache->rig=*observed;cache->tick=now;cache->kind=kind;memcpy(cache->callbacks,context->callbacks,sizeof(cache->callbacks));}*out=*observed;*tick=now;return true;}
 if(!coherent&&matrixRace&&reason==(unsigned)p->readFailure&&cache->ready&&kind&&kind==cache->kind&&!memcmp(cache->callbacks,context->callbacks,sizeof(cache->callbacks))&&now>=cache->tick&&now-cache->tick<=(uint64_t)p->maxAgeMs&&rigSameIdentity(observed,&cache->rig)){*out=cache->rig;*tick=cache->tick;*held=true;return true;}
 cache->ready=false;return false;
}
