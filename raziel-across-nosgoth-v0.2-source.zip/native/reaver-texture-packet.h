// SPDX-License-Identifier: GPL-3.0-or-later
#pragma once
#include "reaver-presentation-packet.h"
#define REAVER_TEXTURE_PACKET_CAPACITY (128u+128u*32u+134217728u)
static bool reaverTexturePacket(const unsigned char *b,size_t n,const ReaverPacketSession *s){
 const Sheet_reaverTextureGeneration *p=&sheet_reaverTextureGeneration_atomic_selected_textures;
 if(!b||!s||n<128||n>REAVER_TEXTURE_PACKET_CAPACITY||p->nativeIntegrationEnabled||p->maxTextures!=128||p->maxBytes!=134217728||p->maxDimension!=2048)return false;
 if(reaverPacketU32(b)!=0x31545752||reaverPacketU32(b+4)!=1||reaverPacketU32(b+8)!=n||reaverPacketU32(b+12)||reaverPacketU32(b+28)||reaverPacketU64(b+112)||reaverPacketU64(b+120))return false;
 if(!s->hostPid||!s->writerPid||!s->donorPid||!s->hostCreation||!s->writerCreation||!s->donorCreation||!s->actor||!s->weapon||!s->model||!s->textureGeneration||
 reaverPacketU32(b+16)!=s->hostPid||reaverPacketU32(b+20)!=s->writerPid||reaverPacketU32(b+24)!=s->donorPid||
 reaverPacketU64(b+32)!=s->hostCreation||reaverPacketU64(b+40)!=s->writerCreation||reaverPacketU64(b+48)!=s->donorCreation||
 !reaverPacketU64(b+56)||!reaverPacketU64(b+64)||reaverPacketU64(b+72)!=s->actor||reaverPacketU64(b+80)!=s->weapon||reaverPacketU64(b+88)!=s->model||reaverPacketU64(b+96)!=s->textureGeneration)return false;
 unsigned count=reaverPacketU32(b+104),bytes=reaverPacketU32(b+108);if(!count||count>(unsigned)p->maxTextures||bytes>(unsigned)p->maxBytes||n!=128+(size_t)count*32+bytes)return false;
 size_t end=128+count*32;bool slots[128]={0};unsigned ids[128]={0};
 for(unsigned i=0;i<count;i++){const unsigned char *a=b+128+i*32;unsigned slot=reaverPacketU32(a),id=reaverPacketU32(a+4),w=reaverPacketU32(a+8),h=reaverPacketU32(a+12),at=reaverPacketU32(a+16),size=reaverPacketU32(a+20);
  if(slot>=(unsigned)p->maxTextures||slots[slot]||!id||id>65535||!w||!h||w>(unsigned)p->maxDimension||h>(unsigned)p->maxDimension||at!=end||size!=(size_t)w*h*4||size>n-end||reaverPacketU32(a+24)>1||reaverPacketU32(a+28)>1)return false;
  for(unsigned j=0;j<i;j++)if(ids[j]==id&&reaverPacketU32(b+128+j*32+24)==reaverPacketU32(a+24)&&reaverPacketU32(b+128+j*32+28)==reaverPacketU32(a+28))return false;slots[slot]=true;ids[i]=id;end+=size;
 }
 return end==n;
}
