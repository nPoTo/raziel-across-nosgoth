// SPDX-License-Identifier: GPL-3.0-or-later
#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <stdint.h>
#include <stdbool.h>
#include <stdio.h>
#define PROBE_REPORT_DIR L"@RAZIEL_SOURCE_ROOT@\\reports\\runtime"
#include "report-path.h"
#include "render-memory-reader.h"
static PVOID volatile verifiedSr1Module;
static unsigned worldActorFailure;
static bool worldActorRead(uintptr_t base,uintptr_t *actor){(void)base;(void)actor;return false;}
static bool hashFile(const wchar_t *file,char out[65]){(void)file;(void)out;return false;}
static void logLine(const char *fmt,...){(void)fmt;}
#include "session-runtime.h"
#define CHECK(x) do{if(!(x)){printf("FAIL runtime line%d\n",__LINE__);return 1;}}while(0)
static bool enabled(void){return true;}
int main(void){
 unsigned char movement[80],*pose=malloc(RM_LIVE_BYTES);CHECK(pose);sessionRuntimeMode=enabled;
 memset(&sessionCache,0,sizeof(sessionCache));sessionCache.active=true;sessionCache.resources=true;sessionCache.movementReady=true;sessionCache.tick=GetTickCount64();sessionCache.generation=7;
 sessionHealthyTick=(LONG64)sessionCache.tick;
 memset(sessionCache.pose,0x3c,RM_LIVE_BYTES);memset(sessionCache.movement,0x69,80);
 CHECK(!sessionRuntimeMovement(movement));CHECK(sessionRuntimeCopy(2,pose,RM_LIVE_BYTES)&&pose[0]==0x3c);CHECK(sessionRuntimeMovement(movement)&&movement[0]==0x69);
 sessionCache.generation=8;CHECK(!sessionRuntimeMovement(movement));CHECK(sessionRuntimeCopy(2,pose,RM_LIVE_BYTES)&&sessionRuntimeMovement(movement));
 AcquireSRWLockExclusive(&sessionCacheLock);CHECK(sessionRuntimeHealthy()&&!sessionRuntimeMovement(movement)&&!sessionRuntimeCopy(2,pose,RM_LIVE_BYTES));ReleaseSRWLockExclusive(&sessionCacheLock);
 sessionCache.tick=GetTickCount64()-151;CHECK(!sessionRuntimeMovement(movement)&&sessionRuntimeHealthy());sessionCache.tick=GetTickCount64()-501;sessionHealthyTick=(LONG64)sessionCache.tick;CHECK(!sessionRuntimeHealthy()&&!sessionRuntimeCopy(2,pose,RM_LIVE_BYTES));
 sessionRuntimeInvalidate();CHECK(!sessionRuntimeHealthy()&&!sessionRuntimeMovement(movement));
 DWORD before=0,after=0;CHECK(GetProcessHandleCount(GetCurrentProcess(),&before));
 sessionRuntimeStopRequested=1;CHECK(sessionRuntimeWorker(NULL)==0);CHECK(GetProcessHandleCount(GetCurrentProcess(),&after)&&before==after);CHECK(!sessionRuntimeThread);
 renderMemoryAlternateCopy=NULL;renderMemoryAlternateIsActive=NULL;renderMemoryAlternateReady=NULL;CHECK(!renderMemoryCopy(4,pose,RM_LIVE_BYTES));renderMemoryClose();
 free(pose);puts("PASS: actual native runtime callback cache, rendered-generation control gate, zero-wait lock contention, pose/control expiry, invalidation and stopped worker cleanup");return 0;
}
