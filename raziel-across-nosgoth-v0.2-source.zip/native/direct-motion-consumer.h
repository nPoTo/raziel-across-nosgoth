typedef struct {uint32_t pid,samples;uint64_t epoch,instance,tick;double xy[2];} DirectMotionCursor;
// 0 rejected,1 new-source baseline,2 fresh delta,3 repeated snapshot.
static inline unsigned directMotionDelta(DirectMotionCursor *cursor,const DirectMotionSnapshot *s,uint32_t pid,uint64_t now,double delta[2]){
 delta[0]=delta[1]=0;
 if(!directMotionValid(s,pid,now))return 0;
 if(cursor->pid!=pid||cursor->epoch!=s->epoch||cursor->instance!=s->instance){
  *cursor=(DirectMotionCursor){pid,s->samples,s->epoch,s->instance,s->tick,{s->xy[0],s->xy[1]}};return 1;
 }
 if(s->samples<cursor->samples||s->tick<cursor->tick)return 0;
 if(s->samples==cursor->samples)return s->tick==cursor->tick&&s->xy[0]==cursor->xy[0]&&s->xy[1]==cursor->xy[1]?3:0;
 if(s->tick-cursor->tick>150)return 0;
 for(unsigned k=0;k<2;k++){delta[k]=s->xy[k]-cursor->xy[k];if(!isfinite(delta[k])||fabs(delta[k])>512){delta[0]=delta[1]=0;return 0;}}
 cursor->samples=s->samples;cursor->tick=s->tick;memcpy(cursor->xy,s->xy,sizeof(cursor->xy));return 2;
}
