// SPDX-License-Identifier: GPL-3.0-or-later
#include <stdio.h>
#include <stdlib.h>
#include <fcntl.h>
#include <io.h>
#include "exploration-sheets.h"
#include "reaver-texture-packet.h"
int main(void){_setmode(_fileno(stdin),_O_BINARY);ReaverPacketSession s={10,20,30,100,200,300,400,500,600,700};uint32_t size;
 while(fread(&size,4,1,stdin)==1){if(size>100000)return 2;unsigned char *b=malloc(size?size:1);if(!b||fread(b,1,size,stdin)!=size)return 3;printf("%u\n",reaverTexturePacket(b,size,&s)?1:0);free(b);}return 0;}
