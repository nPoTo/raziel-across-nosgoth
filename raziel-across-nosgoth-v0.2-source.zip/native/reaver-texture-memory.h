// SPDX-License-Identifier: GPL-3.0-or-later
#pragma once
#include "reaver-presentation-memory.h"
#include "reaver-texture-packet.h"
typedef struct {uint32_t magic,version,online,size;unsigned char packet[REAVER_TEXTURE_PACKET_CAPACITY];} ReaverTextureMemory;
static void reaverTextureMemoryName(const ReaverPacketSession *s,wchar_t name[192]){wchar_t base[160],mutex[160];reaverPresentationNames(s,base,mutex);swprintf(name,192,L"%ls-textures",base);}
// Caller owns/free()s the returned immutable RAM copy; never retains map pointers.
static unsigned char *reaverTextureMemoryCopy(const ReaverPacketSession *s,size_t *size){
 if(!s||!size)return NULL;*size=0;
 if(s->hostPid!=GetCurrentProcessId()||!reaverPresentationProcess(s->hostPid,s->hostCreation)||!reaverPresentationProcess(s->writerPid,s->writerCreation)||!reaverPresentationProcess(s->donorPid,s->donorCreation))return NULL;
 wchar_t name[192],base[160],lockName[160];reaverTextureMemoryName(s,name);reaverPresentationNames(s,base,lockName);
 HANDLE map=OpenFileMappingW(FILE_MAP_READ,FALSE,name),lock=NULL;const ReaverTextureMemory *view=NULL;unsigned char *copy=NULL;
 if(map){lock=OpenMutexW(SYNCHRONIZE|MUTEX_MODIFY_STATE,FALSE,lockName);if(lock)view=MapViewOfFile(map,FILE_MAP_READ,0,0,sizeof(*view));}
 if(view){DWORD wait=WaitForSingleObject(lock,0);if(wait==WAIT_OBJECT_0){
  if(view->magic==0x314d5452&&view->version==1&&view->online==1&&view->size>=128&&view->size<=REAVER_TEXTURE_PACKET_CAPACITY){*size=view->size;copy=malloc(*size);if(copy)memcpy(copy,view->packet,*size);}
  ReleaseMutex(lock);
 }else if(wait==WAIT_ABANDONED)ReleaseMutex(lock);}
 if(view)UnmapViewOfFile(view);if(lock)CloseHandle(lock);if(map)CloseHandle(map);
 if(!copy||!reaverTexturePacket(copy,*size,s)){free(copy);*size=0;return NULL;}return copy;
}
