// SPDX-License-Identifier: GPL-3.0-or-later
#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <stdint.h>
#include <stdbool.h>
#include <string.h>
#include <stdio.h>
#include "donor-action-state.h"
static uintptr_t base=0x10000000,actor=0x20000000,state=0x30000000,currentAddress=0x40000000;
static unsigned reads;static int corrupt;static unsigned char prefix[32];
static bool readFixture(void *unused,uintptr_t address,void *out,SIZE_T size){
 (void)unused;reads++;if(corrupt==1)return false;
 if(address==currentAddress&&size==8){uintptr_t v=(corrupt==2||(corrupt==6&&reads>=6))?actor+8:actor;memcpy(out,&v,8);return true;}
 if(address==actor+0x3f8&&size==8){uintptr_t v=(corrupt==3||(corrupt==7&&reads>=5))?state+8:state;memcpy(out,&v,8);return true;}
 if(address==state&&size==32){memcpy(out,prefix,32);if(corrupt==4&&reads>=4)((unsigned char *)out)[0]^=1;return true;}return false;
}
static bool codeFixture(void *unused,uintptr_t address,uintptr_t module){(void)unused;return module==base&&address>=base&&address<base+0x100000&&corrupt!=5;}
#define CHECK(c,n) do{if(!(c)){printf("FAIL %d\n",n);return n;}}while(0)
int main(void){
 uintptr_t first=base+0x12340,second=base+0x56780;memcpy(prefix+16,&first,8);memcpy(prefix+24,&second,8);
 DonorActionState result=donorActionStateRead(NULL,readFixture,codeFixture,base,0x100000,actor,currentAddress);CHECK(result.valid&&result.secondValid&&result.firstRva==0x12340&&result.secondRva==0x56780,1);
 for(corrupt=1;corrupt<=7;corrupt++){reads=0;result=donorActionStateRead(NULL,readFixture,codeFixture,base,0x100000,actor,currentAddress);CHECK(!result.valid,10+corrupt);}corrupt=0;
 second=0;memcpy(prefix+24,&second,8);reads=0;result=donorActionStateRead(NULL,readFixture,codeFixture,base,0x100000,actor,currentAddress);CHECK(result.valid&&!result.secondValid&&result.secondRva==0,20);
 first=base+0x100000;memcpy(prefix+16,&first,8);reads=0;CHECK(!donorActionStateRead(NULL,readFixture,codeFixture,base,0x100000,actor,currentAddress).valid,21);
 CHECK(!donorActionStateRead(NULL,readFixture,codeFixture,base,0x100000,actor+1,currentAddress).valid,22);CHECK(!donorActionStateRead(NULL,readFixture,codeFixture,UINTPTR_MAX-10,0x100000,actor,currentAddress).valid,23);
 puts("PASS: exact native state reader, executable-image callback bounds, current actor/state/prefix race rejection, optional secondary identity and no pointer serialization");return 0;
}
