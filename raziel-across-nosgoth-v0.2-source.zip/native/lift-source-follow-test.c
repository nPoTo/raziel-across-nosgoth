#include <assert.h>
#include <stdio.h>
#include "lift-source-follow.h"
int main(void){LiftSourceFollow s={0};
 assert(liftSourceButtons(&s,1000,1,true,true,false,true,0x8000,0)==0);
 liftSourceButtons(&s,1010,1,true,true,false,false,0,0);
 assert(liftSourceButtons(&s,1020,1,true,true,false,false,0x8000,0)==0);
 assert(liftSourceButtons(&s,1030,1,true,true,false,true,0x8000,0)==0x1000);
 assert(liftSourceButtons(&s,1040,1,true,false,true,true,0x8000,0)==0x1000);
 assert(liftSourceButtons(&s,1050,1,true,false,false,true,0x8000,0)==0);
 assert(liftSourceButtons(&s,1100,1,true,true,false,true,0x8000,0)==0);
 liftSourceButtons(&s,1110,1,true,true,false,false,0,0);
 assert(liftSourceButtons(&s,1120,1,true,true,false,false,0x8000,0)==0);
 liftSourceButtons(&s,1130,1,true,true,false,false,0,0); // short Y never jumps
 assert(liftSourceButtons(&s,1140,1,true,true,false,true,0x9000,0x1000)==0x1000);
 assert(liftSourceButtons(&s,1150,1,true,true,false,true,0x8000,0)==0);
 liftSourceButtons(&s,1160,1,false,true,false,true,0x8000,0);
 assert(liftSourceButtons(&s,1170,1,true,true,false,true,0x8000,0)==0);
 liftSourceButtons(&s,1180,1,true,true,false,false,0,0);
 assert(liftSourceButtons(&s,1190,2,true,true,false,true,0x8000,0)==0);
 puts("PASS source-driven Y launch: neutral arm, real rise only, one pulse, no air/glide, no repeat/physical-A duplication, scope and identity reset");}
