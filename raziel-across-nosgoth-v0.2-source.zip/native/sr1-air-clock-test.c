// SPDX-License-Identifier: GPL-3.0-or-later
#include <assert.h>
#include <stdio.h>
#include "host-contact-source.h"
#include "sr1-skeleton-shared.h"
static HostContactSource hostContactSource;
static PVOID verifiedSr1Module=(PVOID)0x10000,sr1SkeletonView;
static volatile LONG probeBoundedComplete;
static bool contextAllowed=true;static uintptr_t callback=0xf2ae0;
static bool hostGroundPlayer(uintptr_t base,uintptr_t actor){return base==0x10000&&actor==0x123400;}
static bool sr1SkeletonContextKind(uintptr_t base,uintptr_t actor,unsigned kind){return hostGroundPlayer(base,actor)&&kind==3&&contextAllowed;}
static bool worldRead(uintptr_t address,void *out,SIZE_T n){
 const Sheet_hostContactFrameObserver *p=&sheet_hostContactFrameObserver_completed_collision;
 for(unsigned i=0;i<3;i++)if(address==0x10000+(uintptr_t)p->callbackRva+i*(uintptr_t)p->callbackStride&&n==8){uintptr_t cb=0x10000+callback;memcpy(out,&cb,8);return true;}return false;
}
#include "sr1-air-clock.h"
int main(void){
 uint64_t now=GetTickCount64();assert(hostContactSourceOpen(&hostContactSource,now));
 HostContactSnapshot h={.tick=now,.sequence=1,.actor=0x123400,.phase=2,.control=0x511,.coherent=1};hostContactSourcePublish(&hostContactSource,h);
 SkeletonShared skeleton={0};sr1SkeletonView=&skeleton;
 SkeletonSnapshot s={.magic=SKELETON_MAGIC,.version=1,.hostPid=GetCurrentProcessId(),.sourcePid=991,.writerPid=992,.mode=3,.epoch=now,.tick=now,.hostTick=now,.sourceTick=now,.sequence=1,.actor=h.actor,.object=1,.model=2};
 memcpy(s.policyHash,skeletonPolicyHash,32);for(unsigned i=0;i<66;i++)s.bones[i][0]=s.bones[i][4]=s.bones[i][8]=1;skeletonStore(&skeleton,&s);
 AirClockShared clock={0};srAirClockView=&clock;
 AirClockPacket a={.magic=0x314b4341,.version=1,.hostPid=GetCurrentProcessId(),.donorPid=991,.hostCreation=hostContactSource.creation,.epoch=now,.tick=now,.actor=h.actor,.sequence=1,.scalar=50,.active=1};airClockStore(&clock,&a);
 assert(srAirClockTime(h.actor,0,4096,0)==50);
 assert(srAirClockTime(h.actor+1,0,4096,0)==4096&&srAirClock.active);
 assert(srAirClockTime(h.actor,1,4096,0)==4096&&srAirClock.active);
 callback=0xdead;assert(srAirClockTime(h.actor,0,4096,0)==4096&&!srAirClock.active);callback=0xf2ae0;
 a.donorPid=993;airClockStore(&clock,&a);assert(srAirClockTime(h.actor,0,4096,0)==4096);
 a.donorPid=991;a.active=0;airClockStore(&clock,&a);assert(srAirClockTime(h.actor,0,4096,0)==4096);
 a.active=1;airClockStore(&clock,&a);assert(srAirClockTime(h.actor,0,4096,0)==50);
 contextAllowed=false;assert(srAirClockTime(h.actor,0,4096,0)==4096);contextAllowed=true;
 InterlockedExchange(&clock.revoked,1);assert(srAirClockTime(h.actor,0,4096,0)==4096);
 hostContactSourceStop(&hostContactSource);(void)srAirClockTick;
 puts("PASS host clock real shared receipt: identity/pose/contact/current callbacks, foreign calls, native release and revocation; no gameplay claim");
}
