#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <stdint.h>
#include <stdbool.h>
#include <stdio.h>
#include <string.h>
#include <math.h>
#include "MinHook.h"
#include "source-camera-shared.h"
#define PROBE_REPORT_DIR L"."
static uint32_t overlayLivePid=4242;static uintptr_t directHostPlayer=11,srInputMainBase=0x40000000;
static uint64_t overlayLiveTick;
static void (*worldFrameAudit)(const float[16],const float[16],uintptr_t);
static void (*worldCameraModel)(float[16],uintptr_t);
static uint64_t directHostAlignmentInstance=22;static float directHostCos=1,directHostSin;
static bool enabled,available=true,authority=true;static SourceCameraSnapshot fixture;
static unsigned nativeCalls,writeCalls,failWrite;
static bool directHostInputScope(ULONGLONG now,uintptr_t caller,DWORD foreground){(void)now;(void)caller;return authority&&foreground==GetCurrentProcessId();}
static bool worldRead(uintptr_t at,void *out,SIZE_T n){SIZE_T actual=0;return ReadProcessMemory(GetCurrentProcess(),(void *)at,out,n,&actual)&&actual==n;}
static bool worldRoot(float root[16],uintptr_t *player){memset(root,0,64);root[0]=root[5]=root[10]=root[15]=1;root[12]=100;root[13]=200;root[14]=300;*player=11;return true;}
static bool worldRenderRoot(float root[16],uintptr_t *player){return worldRoot(root,player);}
static bool hashBytes(const void *p,ULONG n,char *out){(void)p;(void)n;(void)out;return false;}
static void logLine(const char *format,...){(void)format;}
static DWORD flag(const wchar_t *p){(void)p;return enabled?FILE_ATTRIBUTE_NORMAL:INVALID_FILE_ATTRIBUTES;}
static DWORD mockCameraForeground(HWND window,LPDWORD pid){(void)window;*pid=GetCurrentProcessId();return 1;}
static BOOL writeFixture(HANDLE p,LPVOID at,LPCVOID in,SIZE_T n,SIZE_T *written){if(++writeCalls==failWrite)return FALSE;return WriteProcessMemory(p,at,in,n,written);}
#define GetFileAttributesW flag
#define GetWindowThreadProcessId mockCameraForeground
#define WriteProcessMemory writeFixture
#include "host-camera-authority.h"
#undef WriteProcessMemory
static bool source(SourceCameraSnapshot *out){if(!available)return false;fixture.tick=GetTickCount64();*out=fixture;return true;}
static uintptr_t __fastcall native(uintptr_t camera,int32_t factor){(void)camera;(void)factor;++nativeCalls;return 0xfedcba;}
static unsigned buildCalls;
static uintptr_t __fastcall nativeBuild(uintptr_t camera){(void)camera;++buildCalls;return 0xabcdef;}
static unsigned regionCalls;static uintptr_t regionFixture[2]={17,0x1234};
static uintptr_t __fastcall nativeRegion(void){++regionCalls;return (uintptr_t)regionFixture;}
#define CHECK(x) do{if(!(x)){printf("FAIL line %d\n",__LINE__);return 1;}}while(0)
int main(void){
 CHECK(worldFrameAudit==NULL&&worldCameraModel==NULL);
 uint64_t now=GetTickCount64();fixture=(SourceCameraSnapshot){0};fixture.magic=0x31435a52;fixture.version=1;fixture.pid=4242;fixture.instance=22;fixture.epoch=now-10;fixture.tick=now;memcpy(fixture.hash,directMotionHash,32);
 // Zero native camera pitch/yaw: right +X, down -Z, forward +Y.
 fixture.view[0]=fixture.inverse[0]=fixture.view[15]=fixture.inverse[15]=1;
 fixture.view[6]=fixture.inverse[9]=1;fixture.view[9]=fixture.inverse[6]=-1;
 fixture.inverse[12]=20;fixture.inverse[13]=-50;fixture.inverse[14]=10;
 fixture.view[12]=-20;fixture.view[13]=10;fixture.view[14]=50;
 CHECK(sourceCameraValid(&fixture,4242,now));CHECK(!sourceCameraValid(&fixture,4243,now));CHECK(!sourceCameraValid(&fixture,4242,now+151));
 SourceCameraSnapshot bad=fixture;bad.hash[0]^=1;CHECK(!sourceCameraValid(&bad,4242,now));bad=fixture;bad.view[12]++;CHECK(!sourceCameraValid(&bad,4242,now));bad=fixture;bad.actor[0]=NAN;CHECK(!sourceCameraValid(&bad,4242,now));
 float root[16],position[3],rotation[3];uintptr_t player;worldRoot(root,&player);
 CHECK(sourceCameraHostPose(&fixture,4242,now,root,1,0,position,rotation));CHECK(position[0]==120&&position[1]==150&&position[2]==310&&rotation[0]==0&&rotation[2]==0);
 float framed[3]={120,150,310},framingAngles[3]={0,0,0};
 CHECK(sourceCameraFrameActor(root,framed,framingAngles)&&fabsf(framed[0]-100)<.001f&&framed[1]<150&&framed[2]==317);
 float turned[3]={150,220,310};framingAngles[2]=1024;
 CHECK(sourceCameraFrameActor(root,turned,framingAngles)&&fabsf(turned[1]-200)<.001f&&turned[0]>150&&turned[2]==317);
 float invalid[3]={NAN,150,310};CHECK(!sourceCameraFrameActor(root,invalid,framingAngles)&&invalid[1]==150);
 CHECK(sourceCameraHostPose(&fixture,4242,now,root,0,1,position,rotation));CHECK(position[0]==150&&position[1]==220&&fabsf(rotation[2]-1024)<.01f);
 SourceCameraBlend blend={0};CHECK(sourceCameraBlendPose(&blend,&fixture,4242,now,root,1,0,position,rotation)&&position[0]==120);
 SourceCameraSnapshot moved=fixture;moved.tick=now+40;moved.inverse[12]=60;moved.view[12]=-60;
 CHECK(sourceCameraBlendPose(&blend,&moved,4242,now+40,root,1,0,position,rotation)&&position[0]==120);
 root[12]=200;CHECK(sourceCameraBlendPose(&blend,&moved,4242,now+60,root,1,0,position,rotation)&&fabsf(position[0]-240)<.001f); // Half offset interpolation, current host position.
 CHECK(sourceCameraBlendPose(&blend,&moved,4242,now+80,root,1,0,position,rotation)&&position[0]==260);
 CHECK(!sourceCameraBlendPose(&blend,&moved,4242,moved.tick+151,root,1,0,position,rotation)&&!blend.ready);root[12]=100;
 blend=(SourceCameraBlend){0};blend.ready=true;blend.start=now;blend.duration=40;blend.from[5]=4090;blend.target[5]=6;sourceCameraBlendStep(&blend,now+20);CHECK(fabsf(blend.display[5])<.001f); // Cross the angle seam by 12 units, not a full turn.
 wchar_t name[96];_snwprintf(name,96,L"Local\\CameraTest-%lu",GetCurrentProcessId());HANDLE map=CreateFileMappingW(INVALID_HANDLE_VALUE,NULL,PAGE_READWRITE,0,sizeof(SourceCameraShared),name);CHECK(map);
 SourceCameraShared *write=MapViewOfFile(map,FILE_MAP_WRITE,0,0,sizeof(*write));const SourceCameraShared *read=MapViewOfFile(map,FILE_MAP_READ,0,0,sizeof(*read));CHECK(write&&read);SourceCameraSnapshot copied;
 sourceCameraStore(write,&fixture);CHECK(sourceCameraCopy(read,&copied)&&copied.instance==22);write->sequence|=1;CHECK(!sourceCameraCopy(read,&copied));write->sequence++;UnmapViewOfFile(write);UnmapViewOfFile(read);CloseHandle(map);
 void *space=VirtualAlloc(NULL,HOST_CAMERA_LEGACY_RVA+0x1000,MEM_RESERVE,PAGE_READWRITE);CHECK(space);hostCameraModule=(uintptr_t)space;
 CHECK(VirtualAlloc((void *)(hostCameraModule+0x3b0d000),0x2000,MEM_COMMIT,PAGE_READWRITE));
 HostCameraPose before={0};before.hdPosition[0]=12;before.hdRotation[2]=25;before.position[0]=12;before.rotation[2]=25;CHECK(hostCameraWritePose(&before));
 originalHostCameraInterp=native;hostCameraRead=source;
 CHECK(hostCameraObserve(hostCameraModule+HOST_CAMERA_HD_RVA,4096,hostCameraModule+HOST_CAMERA_INTERP_CALLER)==0xfedcba&&nativeCalls==1&&!hostCameraOwned);
 enabled=true;CHECK(hostCameraObserve(hostCameraModule+HOST_CAMERA_HD_RVA,4096,hostCameraModule+HOST_CAMERA_INTERP_CALLER)==0xfedcba&&hostCameraOwned&&hostCameraFrames==1);
 HostCameraPose actual;CHECK(hostCameraReadPose(&actual)&&actual.hdPosition[0]==100&&actual.position[1]<150);
 originalHostCameraRegion=nativeRegion;unsigned previousWrites=writeCalls;
 for(unsigned k=0;k<4;k++)CHECK(hostCameraRegionObserve(hostCameraModule+0x6cf59)==(uintptr_t)regionFixture);
 CHECK(regionCalls==4&&hostCameraRegionSamples==1&&writeCalls==previousWrites);
 CHECK(hostCameraReadPose(&actual)&&actual.hdPosition[0]==100&&actual.position[1]<150);
 enabled=false;for(unsigned k=0;k<4;k++)CHECK(hostCameraRegionObserve(hostCameraModule+0x6cf59)==(uintptr_t)regionFixture);
 CHECK(regionCalls==8&&hostCameraRegionSamples==1&&writeCalls==previousWrites);enabled=true;
 CHECK(hostCameraRegionObserve(hostCameraModule+0x123)==(uintptr_t)regionFixture&&hostCameraRegionSamples==1);
 float drawn[16];memcpy(drawn,root,sizeof(drawn));drawn[12]=430;
 CHECK(hostCameraDisplayRoot(drawn,11,hostCameraRootTick)&&drawn[12]==100&&drawn[13]==200&&drawn[14]==300);
 CHECK(drawn[0]==root[0]&&drawn[5]==root[5]&&drawn[10]==root[10]);
 drawn[12]=430;CHECK(!hostCameraDisplayRoot(drawn,12,hostCameraRootTick)&&drawn[12]==430);
 CHECK(!hostCameraDisplayRoot(drawn,11,hostCameraRootTick+101)&&drawn[12]==430);
 authority=false;CHECK(!hostCameraDisplayRoot(drawn,11,hostCameraRootTick)&&drawn[12]==430);authority=true;
 enabled=false;hostCameraObserve(hostCameraModule+HOST_CAMERA_HD_RVA,4096,hostCameraModule+HOST_CAMERA_INTERP_CALLER);CHECK(!hostCameraOwned&&hostCameraReadPose(&actual)&&!memcmp(&actual,&before,sizeof(actual)));
 enabled=true;available=false;unsigned frames=hostCameraFrames;hostCameraObserve(hostCameraModule+HOST_CAMERA_HD_RVA,4096,hostCameraModule+HOST_CAMERA_INTERP_CALLER);CHECK(!hostCameraOwned&&hostCameraFrames==frames);available=true;
 authority=false;hostCameraObserve(hostCameraModule+HOST_CAMERA_HD_RVA,4096,hostCameraModule+HOST_CAMERA_INTERP_CALLER);CHECK(!hostCameraOwned);authority=true;
 hostCameraObserve(hostCameraModule+HOST_CAMERA_HD_RVA,4096,hostCameraModule+HOST_CAMERA_INTERP_CALLER);CHECK(hostCameraOwned);
 float externalPosition[3]={77,88,99};CHECK(hostCameraWriteAt(hostCameraModule+HOST_CAMERA_HD_RVA,externalPosition,12));
 enabled=false;hostCameraObserve(hostCameraModule+HOST_CAMERA_HD_RVA,4096,hostCameraModule+HOST_CAMERA_INTERP_CALLER);CHECK(!hostCameraOwned&&hostCameraReadPose(&actual)&&!memcmp(actual.hdPosition,externalPosition,12));
 CHECK(hostCameraWritePose(&before));enabled=true;
 hostCameraObserve(hostCameraModule+HOST_CAMERA_HD_RVA,4096,hostCameraModule+HOST_CAMERA_INTERP_CALLER+1);CHECK(!hostCameraOwned);
 originalHostCameraBuild=nativeBuild;
 for(unsigned lane=0;lane<2;lane++){
  enabled=true;CHECK(hostCameraBuildObserve(hostCameraModule+HOST_CAMERA_LEGACY_RVA,hostCameraModule+(lane?0x6f6c4:0x6f559))==0xabcdef&&hostCameraOwned);
  CHECK(hostCameraReadPose(&actual)&&actual.hdPosition[0]==100&&actual.position[1]<150);
  enabled=false;hostCameraBuildObserve(hostCameraModule+HOST_CAMERA_LEGACY_RVA,hostCameraModule+(lane?0x6f6c4:0x6f559));
  CHECK(!hostCameraOwned&&hostCameraReadPose(&actual)&&!memcmp(&actual,&before,sizeof(actual)));
 }
 CHECK(buildCalls==4);enabled=true;previousWrites=writeCalls;
 CHECK(hostCameraBuildObserve(hostCameraModule+HOST_CAMERA_LEGACY_RVA,hostCameraModule+0x123)==0xabcdef&&writeCalls==previousWrites);
 available=false;hostCameraBuildObserve(hostCameraModule+HOST_CAMERA_LEGACY_RVA,hostCameraModule+0x6f559);CHECK(!hostCameraOwned&&writeCalls==previousWrites);available=true;
 failWrite=writeCalls+2;hostCameraObserve(hostCameraModule+HOST_CAMERA_HD_RVA,4096,hostCameraModule+HOST_CAMERA_INTERP_CALLER);CHECK(hostCameraFailed&&!hostCameraOwned&&hostCameraReadPose(&actual)&&!memcmp(&actual,&before,sizeof(actual)));
 hostCameraInstall(NULL);hostCameraStop();VirtualFree(space,0,MEM_RELEASE);
 puts("Camera: native convention/rebase/world alignment, freshness/hash/matrix rejection, read-only IPC, original forwarding, scope/default-off, paired restore and partial-write rollback PASS");return 0;
}
