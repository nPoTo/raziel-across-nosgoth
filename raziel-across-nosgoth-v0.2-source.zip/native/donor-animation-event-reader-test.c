// SPDX-License-Identifier: GPL-3.0-or-later
#define DONOR_SELECTION_TEST_NAME selectionTestMain
#include "donor-animation-selection-reader-test.c"
#undef DONOR_SELECTION_TEST_NAME
#include "donor-animation-event-reader.h"
static unsigned eventDefect,eventReads,objectReads;
static bool eventRead(void *c,uintptr_t address,void *out,SIZE_T n){
 if(address==actor+0x88&&n==8){uintptr_t obj=0x12345678;objectReads++;if(eventDefect==7&&objectReads>1)obj++;memcpy(out,&obj,8);return true;}
 for(unsigned i=0;i<3;i++)for(unsigned j=0;j<6;j++)if(address==actor+0x1d0+i*0x68+0x30+j*8&&n==8){
  if(eventDefect==6)return false;
  uintptr_t value=j==0?base+0x100:j==2?0x12345678:0xfeedface;
  if(eventDefect==1&&++eventReads>18)value++;
  if(eventDefect==2&&j==0)value=0;
  if(eventDefect==3&&j==0)value=base+0x3000000;
  if(eventDefect==4&&j==2)value=0x12345680;
  if(eventDefect==5&&j!=0)value=0;
  memcpy(out,&value,8);return true;
 }
 return selectionRead(c,address,out,n);
}
static DonorAnimationEventContext events(void){memset(prefixReads,0,sizeof(prefixReads));actorReads=stateReads=selectionReads=eventReads=objectReads=0;return donorAnimationEventRead(NULL,eventRead,fixtureCode,base,0x2000000,actor);}
int main(void){
 CHECK(selectionTestMain()==0,101);defect=selectionDefect=eventDefect=0;
 DonorAnimationEventContext r=events();CHECK(r.valid&&r.selection.valid&&r.sections[0].callbackRva==0x100&&r.sections[0].sourceObjectMatchesActor,102);
 eventDefect=1;CHECK(!events().valid,103);
 eventDefect=2;r=events();CHECK(r.valid&&!r.sections[0].callbackPresent&&!r.sections[0].callbackKnown&&!r.sections[0].callbackRva,104);
 eventDefect=3;r=events();CHECK(r.valid&&r.sections[0].callbackPresent&&!r.sections[0].callbackKnown&&!r.sections[0].callbackRva,105);
 eventDefect=4;r=events();CHECK(r.valid&&r.sections[0].sourceObjectPresent&&!r.sections[0].sourceObjectMatchesActor,106);
 eventDefect=5;r=events();CHECK(r.valid&&!r.sections[0].contextPresent&&!r.sections[0].sourceObjectMatchesActor&&!r.sections[0].clipResourcePresent,107);
 eventDefect=6;CHECK(!events().valid,108);eventDefect=7;CHECK(!events().valid,109);eventDefect=0;
 for(selectionDefect=1;selectionDefect<=4;selectionDefect++)CHECK(!events().valid,110+selectionDefect);selectionDefect=0;
 for(defect=1;defect<=7;defect++)CHECK(!events().valid,120+defect);defect=0;
 CHECK(!donorAnimationEventRead(NULL,eventRead,fixtureCode,UINTPTR_MAX-2,0x2000000,actor).valid,130);
 CHECK(!donorAnimationEventRead(NULL,eventRead,fixtureCode,base,0x1000,actor).valid,131);
 puts("PASS: production event callback/context scalar reader; races/code/actor/owner/object guards; opaque resources never dereferenced");return 0;
}
