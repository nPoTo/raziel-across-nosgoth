// SPDX-License-Identifier: GPL-3.0-or-later
#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <wchar.h>
static DWORD (WINAPI *realAttrs)(LPCWSTR)=GetFileAttributesW;
static DWORD WINAPI testAttrs(LPCWSTR p){return wcsstr(p,L"free-attack-sr1.enable")?FILE_ATTRIBUTE_NORMAL:realAttrs(p);}
#define GetFileAttributesW testAttrs
#define SR1_GROUND_DRIVER_TEST_ENTRY legacyGroundDriverFixture
#include "sr1-skeleton-ground-driver-test.c"
static void total(float value,unsigned serial){fixtureGround.packet.active=3;fixtureGround.packet.forwardPerFactor=value;fixtureGround.packet.sequence=serial;fixtureGround.packet.sourceTick=GetTickCount64();fixtureGround.packet.tick=fixtureGround.packet.sourceTick;fixtureGround.packet.hostTick=fixtureGround.packet.sourceTick;}
int main(void){setup();srCombatCursor=(CombatTravelCursor){0};fixtureInput=false;total(0,1);rootStationary((uintptr_t)fixtureState,0,0);CHECK(sets==2&&sr1GroundLease.pending==3);total(10,2);rootStationary((uintptr_t)fixtureState,0,0);CHECK(sets==4&&sr1GroundLease.pending==3);RootController c;CHECK(rootControllerRead(instantRootModule,fixturePlayer+0x448,1,&c)&&((float *)c.vector)[1]==-10);rootMoving((uintptr_t)fixtureState,0,0);CHECK(sets==6&&sr1GroundLease.pending==3);total(5,3);rootMoving((uintptr_t)fixtureState,0,0);CHECK(rootControllerRead(instantRootModule,fixturePlayer+0x448,1,&c)&&((float *)c.vector)[1]==5);fixtureContext=false;total(20,4);rootMoving((uintptr_t)fixtureState,0,0);CHECK(!sr1GroundLease.pending);fixtureContext=true;total(22,5);rootMoving((uintptr_t)fixtureState,0,0);CHECK(rootControllerRead(instantRootModule,fixturePlayer+0x448,1,&c)&&((float *)c.vector)[1]==-2);sr1GroundEnabled=0;rootMoving((uintptr_t)fixtureState,0,0);CHECK(!sr1GroundLease.pending);// Held stick cannot add native walking to either a new or repeated zero step.
 setup();srCombatCursor=(CombatTravelCursor){0};nativeActive=true;fixtureInput=true;total(0,1);rootMoving((uintptr_t)fixtureState,0,0);CHECK(rootControllerRead(instantRootModule,fixturePlayer+0x448,1,&c)&&((float *)c.vector)[1]==0&&sr1GroundLease.pending==3);
 rootMoving((uintptr_t)fixtureState,0,0);CHECK(rootControllerRead(instantRootModule,fixturePlayer+0x448,1,&c)&&((float *)c.vector)[1]==0&&sr1GroundLease.pending==3);
 // Explicit end of attack releases zero ownership and preserves native movement.
 total(0,2);fixtureGround.packet.active=2;rootMoving((uintptr_t)fixtureState,0,0);CHECK(!sr1GroundLease.pending&&rootControllerRead(instantRootModule,fixturePlayer+0x448,1,&c)&&((float *)c.vector)[1]==-35);
 for(unsigned reason=0;reason<4;reason++){setup();srCombatCursor=(CombatTravelCursor){0};nativeActive=true;total(0,1);rootMoving((uintptr_t)fixtureState,0,0);CHECK(sr1GroundLease.pending==3);if(reason==0)fixtureContext=false;if(reason==1)fixtureBones.snapshot.mode=3;if(reason==2)fixtureGround.packet.tick-=500;if(reason==3)wrongForeground=true;rootMoving((uintptr_t)fixtureState,0,0);CHECK(!sr1GroundLease.pending);}
 puts("PASS zero attack ownership with stick, duplicate receipt zero, explicit release, air/native/stale/focus exit; original controllers signed action step without stick, no duplicate, native discard and release; no XYZ or heading writes");return 0;}

