// SPDX-License-Identifier: GPL-3.0-or-later
// Exercises the actual read helper with scalar synthetic memory only.
#define SR1_NATIVE_JUMP_POSE 1
#include <assert.h>
#include <stdio.h>
#include "sr1-retarget-context-reader.h"
#include "sr1-free-attack-owner.h"
#include "sr1-native-exit-reader.h"

enum { OWNER, MODE, FLAGS, VELOCITY, CALLBACK0, CALLBACK1, CALLBACK2,
#ifdef SR1_NATIVE_CROUCH_HOLD
 COMMAND_POINTER, CROUCH_MASK, COMMAND,
#endif
 FIELDS };
typedef struct {uintptr_t address;SIZE_T bytes;uint64_t value;unsigned reads;} Field;
typedef struct {Field fields[FIELDS];int mutate,unreadable;unsigned unreadableRead;} Fixture;
static const uintptr_t base=0x100000,actor=0x50000;

static void setup(Fixture *f){
 memset(f,0,sizeof(*f));f->mutate=f->unreadable=-1;
 f->fields[OWNER]=(Field){base+0x2a88588,8,actor,0};
 f->fields[MODE]=(Field){base+0x2a89536,2,0,0};
 f->fields[FLAGS]=(Field){base+0x2a8950c,4,0,0};
 f->fields[VELOCITY]=(Field){actor+0x2d4,4,0,0};
 for(unsigned i=0;i<3;i++)f->fields[CALLBACK0+i]=(Field){base+0x2a88598+i*0x228,8,base+0xf2180,0};
#ifdef SR1_NATIVE_CROUCH_HOLD
 f->fields[COMMAND_POINTER]=(Field){base+0xd6b388,8,0x90000,0};
 f->fields[CROUCH_MASK]=(Field){base+0x22acd0,4,0x800,0};
 f->fields[COMMAND]=(Field){0x90000,4,0,0};
#endif
}
static bool readFixture(void *opaque,uintptr_t address,void *out,SIZE_T bytes){
 Fixture *f=opaque;
 for(unsigned i=0;i<FIELDS;i++)if(address==f->fields[i].address&&bytes==f->fields[i].bytes){
  Field *field=&f->fields[i];unsigned read=++field->reads;
  if((int)i==f->unreadable&&read==f->unreadableRead)return false;
  uint64_t value=field->value;
  if((int)i==f->mutate&&read==2)value^=1;
  memcpy(out,&value,bytes);return true;
 }
 return false;
}
static bool observe(Fixture *f,bool foreground,Sr1RetargetContext *c){
 memset(c,0xa5,sizeof(*c));
 return sr1RetargetReadContext(f,readFixture,base,actor,foreground,c);
}
static void callbacks(Fixture *f,uint32_t rva){
 for(unsigned i=0;i<3;i++)f->fields[CALLBACK0+i].value=base+rva;
}
static void requireNative(Fixture *f){
 Sr1RetargetContext c;assert(observe(f,true,&c)&&c.identity&&c.verticalVelocityKnown);
 assert(!sr1RetargetContextAllowed(&c)&&!sr1RetargetJumpContextAllowed(&c));
}
int main(void){
 Fixture f;Sr1RetargetContext c;
 setup(&f);assert(observe(&f,true,&c)&&c.identity&&c.foreground&&c.verticalVelocityKnown);
 assert(sr1RetargetContextAllowed(&c)&&!sr1RetargetJumpContextAllowed(&c));
 for(unsigned i=0;i<FIELDS;i++)assert(f.fields[i].reads==2);

 // Every independently checked scalar must be stable through the second read,
 // including all three callbacks rather than only their surrounding owner.
 for(unsigned i=0;i<FIELDS;i++){
  setup(&f);f.mutate=(int)i;assert(!observe(&f,true,&c));
  assert(!c.identity&&!c.verticalVelocityKnown);
 }
 for(unsigned i=0;i<FIELDS;i++)for(unsigned pass=1;pass<=2;pass++){
  setup(&f);f.unreadable=(int)i;f.unreadableRead=pass;
  assert(!observe(&f,true,&c)&&!c.identity&&!c.verticalVelocityKnown);
 }

 // Invalid callback pointers are refused before reducing them to RVAs.
 for(unsigned i=0;i<3;i++){
  setup(&f);f.fields[CALLBACK0+i].value=base-1;assert(!observe(&f,true,&c));
  setup(&f);f.fields[CALLBACK0+i].value=(uint64_t)base+UINT32_MAX+1ull;assert(!observe(&f,true,&c));
 }
 setup(&f);f.fields[OWNER].value=actor+8;assert(!observe(&f,true,&c));

 // A known current context is not the same thing as an admitted mod context.
 setup(&f);assert(observe(&f,false,&c)&&c.identity&&!c.foreground&&c.verticalVelocityKnown);
 assert(!sr1RetargetContextAllowed(&c)&&!sr1RetargetJumpContextAllowed(&c));
 setup(&f);f.fields[MODE].value=1;requireNative(&f);
 setup(&f);f.fields[FLAGS].value=0x10000000;requireNative(&f);
 setup(&f);f.fields[VELOCITY].value=1;requireNative(&f);
 setup(&f);callbacks(&f,0xf5340);assert(observe(&f,true,&c)&&sr1RetargetContextAllowed(&c)); // proved StartTurn, not Compression
 // Reproduce r8: ordinary stop must neither latch a native interaction nor
 // release X into native combat during the stop animation.
 SrFreeAttackOwner attackOwner={0};Sr1NativeExitLatch exitLatch={0};Sr1NativeExitSample pose={0};
 const uint32_t chain[]={0xf2180,0xf3280,0xf54d0,0xf2180};
 for(unsigned i=0;i<4;i++){
  setup(&f);callbacks(&f,chain[i]);assert(observe(&f,true,&c));bool allowed=sr1RetargetContextAllowed(&c);
  assert(allowed&&sr1NativeExitAdmit(&exitLatch,true,allowed,sr1NativeActionActive(&c),true,&pose)&&!exitLatch.nativeOwned);
  uint16_t x=i==2?0x4000:0;assert(srFreeAttackStep(&attackOwner,100+i,actor,true,allowed,x,x,0x4000)==0);
 }
 const uint32_t nativeCallbacks[]={0xedb40,0xefb50,0xef480,0xf4490,0xf48e0};
 for(unsigned i=0;i<sizeof(nativeCallbacks)/sizeof(*nativeCallbacks);i++){
  // Compression/crouch, Glide, Fall and unsupported action remain native.
  setup(&f);callbacks(&f,nativeCallbacks[i]);requireNative(&f);
 }
 setup(&f);f.fields[CALLBACK1].value=base+0xefb50;requireNative(&f);

 setup(&f);callbacks(&f,0xf2ae0);f.fields[VELOCITY].value=138;
 assert(observe(&f,true,&c)&&!sr1RetargetContextAllowed(&c)&&sr1RetargetJumpContextAllowed(&c));
 setup(&f);callbacks(&f,0xf2ae0);f.fields[VELOCITY].value=2049;requireNative(&f);
#ifdef SR1_NATIVE_CROUCH_HOLD
 // Held crouch wins even when callback classification alone says Run/Jump.
 for(unsigned i=0;i<3;i++){
  setup(&f);callbacks(&f,(uint32_t[]){0xf2180,0xf3280,0xf2ae0}[i]);
  f.fields[COMMAND].value=0x801;requireNative(&f);
 }
 setup(&f);f.fields[CROUCH_MASK].value=0;assert(!observe(&f,true,&c));
 setup(&f);f.fields[COMMAND_POINTER].value=0;assert(!observe(&f,true,&c));
 setup(&f);f.fields[COMMAND].value=1;assert(observe(&f,true,&c)&&!c.crouchHeld&&sr1RetargetContextAllowed(&c));
#endif
 puts("PASS actual host context helper: all scalar/callback rereads, unreadable/malformed pointers, foreground/native-action refusal. Fixtures, not gameplay.");
 return 0;
}
