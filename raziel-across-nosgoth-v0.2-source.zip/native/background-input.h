// SPDX-License-Identifier: GPL-3.0-or-later
// Reversible SDL hint in the actual game process, independent of Steam relaunch.
typedef const char *(__cdecl *BackgroundGetFn)(const char *);
typedef bool (__cdecl *BackgroundSetFn)(const char *,const char *);
typedef bool (__cdecl *BackgroundResetFn)(const char *);
static BackgroundGetFn backgroundGet;
static BackgroundSetFn backgroundSet;
static BackgroundResetFn backgroundReset;
static bool backgroundOwned,backgroundHadValue,backgroundAttempted;
static char backgroundPrevious[256];
static const char *backgroundKey="SDL_JOYSTICK_ALLOW_BACKGROUND_EVENTS";
static void backgroundInit(void) {
    HMODULE sdl=GetModuleHandleW(L"SDL3.dll");if(!sdl)return;
    backgroundGet=(BackgroundGetFn)GetProcAddress(sdl,"SDL_GetHint");
    backgroundSet=(BackgroundSetFn)GetProcAddress(sdl,"SDL_SetHint");
    backgroundReset=(BackgroundResetFn)GetProcAddress(sdl,"SDL_ResetHint");
    if(!backgroundGet||!backgroundSet||!backgroundReset) backgroundGet=NULL;
}
static void backgroundRestore(void) {
    if(!backgroundOwned)return;
    const char *current=backgroundGet(backgroundKey);
    bool unchanged=current&&!strcmp(current,"1"),restored=false;
    if(unchanged) restored=backgroundHadValue?backgroundSet(backgroundKey,backgroundPrevious):backgroundReset(backgroundKey);
    const char *after=backgroundGet(backgroundKey);
    bool verified=restored&&(backgroundHadValue?(after&&!strcmp(after,backgroundPrevious)):(!after));
    logLine("BACKGROUND_INPUT restore attempted=%d verified=%d; external hint changes preserved",unchanged,verified);
    backgroundOwned=false;
}
static void backgroundTick(bool enabled) {
    if(!backgroundGet)return;
    if(!enabled) {backgroundRestore();backgroundAttempted=false;return;}
    if(backgroundAttempted)return;
    backgroundAttempted=true;
    const char *previous=backgroundGet(backgroundKey);
    if(previous&&strlen(previous)>=sizeof(backgroundPrevious)) {logLine("BACKGROUND_INPUT hint too long; disabled");return;}
    backgroundHadValue=previous!=NULL;
    if(previous) strcpy(backgroundPrevious,previous);
    if(previous&&!strcmp(previous,"1")) {logLine("BACKGROUND_INPUT already enabled verified=1; no hint ownership");return;}
    bool applied=backgroundSet(backgroundKey,"1");
    const char *after=backgroundGet(backgroundKey);
    bool verified=applied&&after&&!strcmp(after,"1");
    backgroundOwned=applied;
    logLine("BACKGROUND_INPUT enable applied=%d verified=%d; actual_pid=%lu gameplay_bridge=0",applied,verified,GetCurrentProcessId());
    if(!verified)backgroundRestore();
}
