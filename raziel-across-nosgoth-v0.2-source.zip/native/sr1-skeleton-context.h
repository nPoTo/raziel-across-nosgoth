// SPDX-License-Identifier: GPL-3.0-or-later
#pragma once
#include "sr1-retarget-context-reader.h"

// The draw consumer and the external observer must classify the same complete
// context, including the ordinary legacy+HD Compression/Landing clip proof.
static bool sr1SkeletonContextKind(uintptr_t base,uintptr_t actor,unsigned kind){
 DWORD front=0;GetWindowThreadProcessId(GetForegroundWindow(),&front);
 bool foreground=front==GetCurrentProcessId();Sr1RetargetContext c={0};
 if(!sr1RetargetReadContext(NULL,sr1SkeletonRead,base,actor,foreground,&c))return false;
#ifdef SR1_NATIVE_EXIT_GUARD
 uintptr_t object=0,objectAfter=0,list=0,model=0,listAfter=0,modelAfter=0;Sr1NativeExitSample exitPose={0};
 if(!worldRead(actor+0x30,&object,8)||!object||!worldRead(object+0x10,&list,8)||!list||!worldRead(list,&model,8)||!model)return false;
 if(sr1ExitActor!=actor||sr1ExitObject!=object||sr1ExitModel!=model){sr1ExitActor=actor;sr1ExitObject=object;sr1ExitModel=model;sr1ExitLatch.nativeOwned=true;}
 bool actionAllowed=sr1RetargetContextAllowed(&c);
#ifdef SR1_NATIVE_JUMP_POSE
 actionAllowed=actionAllowed||sr1RetargetJumpContextAllowed(&c);
#endif
 bool exitKnown=sr1NativeExitRead(NULL,sr1SkeletonRead,actor,&exitPose);
 // Recheck resource ownership and the complete shared classification after
 // the exit read. A racing clip/crouch/scalar cannot rearm the draw consumer.
 if(!worldRead(actor+0x30,&objectAfter,8)||objectAfter!=object)return false;
 if(!worldRead(object+0x10,&listAfter,8)||listAfter!=list||!worldRead(listAfter,&modelAfter,8)||modelAfter!=model)return false;
 Sr1RetargetContext after={0};
 if(!sr1RetargetReadContext(NULL,sr1SkeletonRead,base,actor,foreground,&after)||memcmp(&c,&after,sizeof(c)))return false;
 bool wasOwned=sr1ExitLatch.nativeOwned;
 if(!exitKnown)InterlockedIncrement(&sr1ExitReadRefused);
 if(!sr1NativeExitAdmit(&sr1ExitLatch,true,actionAllowed,sr1NativeActionActive(&c),exitKnown,&exitPose)){if(actionAllowed&&sr1ExitLatch.nativeOwned)InterlockedIncrement(&sr1ExitHeld);return false;}
 if(wasOwned)InterlockedIncrement(&sr1ExitReleased);
#endif
#ifdef SR1_NATIVE_JUMP_POSE
 if(kind==3)return sr1RetargetJumpContextAllowed(&c);
#else
 (void)kind;
#endif
 return kind==2&&sr1RetargetContextAllowed(&c);
}
