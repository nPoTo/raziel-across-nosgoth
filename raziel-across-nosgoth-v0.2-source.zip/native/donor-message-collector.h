// SPDX-License-Identifier: GPL-3.0-or-later
// One collector-thread owner. Scalar metadata only; no native calls or I/O.
#pragma once
#include "donor-message-sampling.h"

#define DONOR_MESSAGE_PENDING_STORAGE 128U
typedef void (*DonorMessageCollectorSink)(void *,const DonorMessageEvent *);
typedef struct {bool used;DonorMessageEvent entry;} DonorMessagePendingPair;
typedef struct {
 DonorMessageSampler sampler;
 DonorMessagePendingPair pending[DONOR_MESSAGE_PENDING_STORAGE];
 void *context;
 DonorMessageCollectorSink sink;
 uint64_t seen,logged,sampled,discarded,orphanEntries;
 uint32_t pendingCount,maxRecords;
 bool configured,finished;
} DonorMessageCollector;

static inline void donorMessageCollectorInit(DonorMessageCollector *c,void *context,DonorMessageCollectorSink sink){
 if(!c)return;memset(c,0,sizeof(*c));donorMessageSamplerInit(&c->sampler);c->context=context;c->sink=sink;
 c->maxRecords=(uint32_t)sheet_donorMessageObservationPolicy_bounded.maxRecords;
 c->configured=sink&&c->sampler.configured&&sheet_donorMessageObservationPolicy_bounded.pendingPairs==DONOR_MESSAGE_PENDING_STORAGE;
}
static inline bool donorMessageCollectorKeyEqual(const DonorMessageEvent *a,const DonorMessageEvent *b){
 return a->callId==b->callId&&a->threadId==b->threadId&&a->session==b->session;
}
// Count attempted wire rows. The sink owns actual write acknowledgement; the
// checked reader compares its wire-row total with END to detect failed writes.
static inline void donorMessageCollectorEmit(DonorMessageCollector *c,const DonorMessageEvent *event){
 if(!c->configured||!c->sink||c->logged>=c->maxRecords){c->discarded++;return;}
 c->logged++;c->sink(c->context,event);
}
static inline void donorMessageCollectorAccept(DonorMessageCollector *c,const DonorMessageEvent *event){
 if(!c||!event)return;c->seen++;
 if(c->finished||!c->configured){c->discarded++;return;}
 if(event->phase==DONOR_MESSAGE_ENTER){
  DonorMessagePendingPair *freeSlot=NULL;
  for(unsigned i=0;i<DONOR_MESSAGE_PENDING_STORAGE;i++){
   DonorMessagePendingPair *p=&c->pending[i];
   if(p->used&&donorMessageCollectorKeyEqual(&p->entry,event)){c->discarded++;return;}
   if(!p->used&&!freeSlot)freeSlot=p;
  }
  if(freeSlot){freeSlot->entry=*event;freeSlot->used=true;c->pendingCount++;return;}
  // A full pending table does not evict a live entry. Emit this row immediately;
  // its later unmatched exit also passes through without pair sampling.
  donorMessageCollectorEmit(c,event);return;
 }
 if(event->phase!=DONOR_MESSAGE_EXIT){c->discarded++;return;}
 for(unsigned i=0;i<DONOR_MESSAGE_PENDING_STORAGE;i++){
  DonorMessagePendingPair *p=&c->pending[i];if(!p->used||!donorMessageCollectorKeyEqual(&p->entry,event))continue;
  DonorMessageEvent entry=p->entry;memset(p,0,sizeof(*p));c->pendingCount--;
  if(!donorMessagePairKeep(&c->sampler,&entry,event,(uint32_t)sheet_donorMessageObservationPolicy_bounded.sampleMs)){c->sampled+=2;return;}
  // Reserve both rows before calling the sink. A wire limit can never retain
  // only the entry of a completed pair handled by this table.
  if(c->logged>c->maxRecords||c->maxRecords-c->logged<2){c->discarded+=2;return;}
  donorMessageCollectorEmit(c,&entry);donorMessageCollectorEmit(c,event);return;
 }
 donorMessageCollectorEmit(c,event);
}
static inline void donorMessageCollectorFinish(DonorMessageCollector *c){
 if(!c||c->finished)return;c->finished=true;
 for(unsigned i=0;i<DONOR_MESSAGE_PENDING_STORAGE;i++){
  DonorMessagePendingPair *p=&c->pending[i];if(!p->used)continue;
  c->orphanEntries++;donorMessageCollectorEmit(c,&p->entry);memset(p,0,sizeof(*p));
 }
 c->pendingCount=0;
 // Once all pending rows have been flushed: seen=logged+sampled+discarded.
 // orphanEntries is a separate completeness diagnostic, never double-counted
 // as discarded when its entry was successfully sent to the sink.
}
