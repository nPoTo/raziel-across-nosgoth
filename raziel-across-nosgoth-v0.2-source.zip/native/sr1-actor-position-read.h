// SPDX-License-Identifier: GPL-3.0-or-later
#pragma once
#include "sr1-combat-input-identity.h"
static inline bool srActorPositionRead(void *ctx,CombatIdentityRead read,uintptr_t base,uintptr_t actor,uintptr_t object,int16_t out[3]){
 uintptr_t a=0,o=0;int16_t before[3],after[3];
 if(!actor||!object||!srCombatInputIdentity(ctx,read,base,&a,&o)||a!=actor||o!=object||
    !read(ctx,actor+0x9c,before,sizeof(before))||!read(ctx,actor+0x9c,after,sizeof(after))||memcmp(before,after,sizeof(before))||
    !read(ctx,base+0x2a89310,&a,8)||a!=actor||!read(ctx,actor+0x30,&o,8)||o!=object)return false;
 memcpy(out,before,sizeof(before));return true;
}
