// SPDX-License-Identifier: GPL-3.0-or-later
#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <stdbool.h>
#include <stdint.h>
#include <stdio.h>
#include <string.h>
#include "donor-message-sampling.h"

#define CHECK(c) do{if(!(c)){printf("FAIL message sampling line%u\n",(unsigned)__LINE__);return 1;}}while(0)
static void pair(DonorMessageEvent *entry,DonorMessageEvent *exit,uint64_t tick){
 memset(entry,0,sizeof(*entry));entry->session=17;entry->callId=1;entry->tickMs=tick;entry->threadId=3;entry->depth=1;entry->phase=DONOR_MESSAGE_ENTER;entry->section=0;entry->messageId=0x4010402;entry->payloadZero=1;entry->beforeSecondMask=7;
 for(unsigned i=0;i<3;i++){entry->beforeFirstRva[i]=0x1000+i*0x10;entry->beforeSecondRva[i]=0x2000+i*0x10;}
 *exit=*entry;exit->phase=DONOR_MESSAGE_EXIT;exit->afterValid=1;exit->afterSecondMask=entry->beforeSecondMask;memcpy(exit->afterFirstRva,entry->beforeFirstRva,sizeof(exit->afterFirstRva));memcpy(exit->afterSecondRva,entry->beforeSecondRva,sizeof(exit->afterSecondRva));
}
static bool keep(DonorMessageSampler *s,DonorMessageEvent *entry,DonorMessageEvent *exit,uint64_t tick){entry->tickMs=exit->tickMs=tick;entry->callId++;exit->callId=entry->callId;return donorMessagePairKeep(s,entry,exit,100);}
int main(void){
 DonorMessageSampler sampler;DonorMessageEvent entry,exit;pair(&entry,&exit,1000);donorMessageSamplerInit(&sampler);CHECK(sampler.configured&&sampler.used==0);
 DonorMessageEvent beforeEntry=entry,beforeExit=exit;CHECK(donorMessagePairKeep(&sampler,&entry,&exit,100));CHECK(!memcmp(&entry,&beforeEntry,sizeof(entry))&&!memcmp(&exit,&beforeExit,sizeof(exit))&&sampler.used==1);
 CHECK(!keep(&sampler,&entry,&exit,1000));CHECK(!keep(&sampler,&entry,&exit,1099));CHECK(keep(&sampler,&entry,&exit,1100));CHECK(!keep(&sampler,&entry,&exit,1199));CHECK(keep(&sampler,&entry,&exit,1200));
 CHECK(keep(&sampler,&entry,&exit,1198));CHECK(keep(&sampler,&entry,&exit,1199));CHECK(!keep(&sampler,&entry,&exit,1200));CHECK(keep(&sampler,&entry,&exit,1300));
 // A distinct call ID alone is not a new state key. Clock equal is redundant.
 CHECK(!keep(&sampler,&entry,&exit,1300));
 for(unsigned which=0;which<3;which++){
  DonorMessageEvent changed=exit;changed.afterFirstRva[which]++;CHECK(donorMessagePairKeep(&sampler,&entry,&changed,100));
  changed=exit;changed.afterSecondRva[which]++;CHECK(donorMessagePairKeep(&sampler,&entry,&changed,100));
  changed=exit;changed.afterSecondMask^=1U<<which;changed.afterSecondRva[which]=0;CHECK(donorMessagePairKeep(&sampler,&entry,&changed,100));
 }
 entry.depth=exit.depth=2;CHECK(donorMessagePairKeep(&sampler,&entry,&exit,100));CHECK(donorMessagePairKeep(&sampler,&entry,&exit,100));entry.depth=exit.depth=1;
 for(unsigned i=0;i<4;i++){entry.messageId=exit.messageId=(uint32_t[]){0x100001,0x100004,0x10000000,0x200009}[i];CHECK(donorMessagePairKeep(&sampler,&entry,&exit,100));CHECK(donorMessagePairKeep(&sampler,&entry,&exit,100));}
 const uint32_t floods[]={0,0x4010402,0x4010008,0x4010080,0x4020000,0x4010400};
 for(unsigned i=0;i<ARRAYSIZE(floods);i++){donorMessageSamplerInit(&sampler);pair(&entry,&exit,5000);entry.messageId=exit.messageId=floods[i];CHECK(donorMessagePairKeep(&sampler,&entry,&exit,100));CHECK(!donorMessagePairKeep(&sampler,&entry,&exit,100));}
 // Every scalar identity and every before-state component distinguishes keys.
 donorMessageSamplerInit(&sampler);pair(&entry,&exit,6000);CHECK(donorMessagePairKeep(&sampler,&entry,&exit,100));
 for(unsigned which=0;which<11;which++){
  DonorMessageEvent a=entry,b=exit;
  if(which==0)a.session=b.session=18;else if(which==1)a.threadId=b.threadId=4;else if(which==2)a.section=b.section=1;else if(which==3)a.payloadZero=b.payloadZero=0;else if(which<7){unsigned i=which-4;a.beforeFirstRva[i]++;b.beforeFirstRva[i]++;b.afterFirstRva[i]++;}else if(which<10){unsigned i=which-7;a.beforeSecondRva[i]++;b.beforeSecondRva[i]++;b.afterSecondRva[i]++;}else{a.beforeSecondMask=b.beforeSecondMask=b.afterSecondMask=3;a.beforeSecondRva[2]=b.beforeSecondRva[2]=b.afterSecondRva[2]=0;}
  CHECK(donorMessagePairKeep(&sampler,&a,&b,100));CHECK(!donorMessagePairKeep(&sampler,&a,&b,100));
 }
 CHECK(sampler.used==12);
 // A clock reversal across DISTINCT keys also conservatively passes through.
 DonorMessageEvent laterEntry=entry,laterExit=exit;laterEntry.messageId=laterExit.messageId=0x100001;laterEntry.tickMs=laterExit.tickMs=6050;CHECK(donorMessagePairKeep(&sampler,&laterEntry,&laterExit,100));
 CHECK(keep(&sampler,&entry,&exit,6049));CHECK(keep(&sampler,&entry,&exit,6048));CHECK(!keep(&sampler,&entry,&exit,6050));
 // Invalid pair/policy cannot authorize dropping anything.
 CHECK(donorMessagePairKeep(NULL,&entry,&exit,100));CHECK(donorMessagePairKeep(&sampler,NULL,&exit,100));CHECK(donorMessagePairKeep(&sampler,&entry,NULL,100));CHECK(donorMessagePairKeep(&sampler,&entry,&exit,0));CHECK(donorMessagePairKeep(&sampler,&entry,&exit,101));
 for(unsigned which=0;which<14;which++){
  DonorMessageEvent a=entry,b=exit;
  switch(which){case 0:b.callId++;break;case 1:b.session++;break;case 2:b.threadId++;break;case 3:b.section++;break;case 4:b.messageId++;break;case 5:b.payloadZero=0;break;case 6:b.beforeFirstRva[0]++;break;case 7:b.afterValid=0;break;case 8:b.tickMs=a.tickMs-1;break;case 9:a.phase=2;break;case 10:a.afterValid=1;break;case 11:a.section=b.section=3;break;case 12:a.depth=b.depth=0;break;case 13:a.beforeSecondMask=b.beforeSecondMask=0;break;}
  CHECK(donorMessagePairKeep(&sampler,&a,&b,100));
 }
 Sheet_donorMessageObservationPolicy bad=sheet_donorMessageObservationPolicy_bounded;
 CHECK(donorMessageSamplerPolicyValid(&bad));bad.sampleKeys=129;CHECK(!donorMessageSamplerPolicyValid(&bad));bad=sheet_donorMessageObservationPolicy_bounded;bad.sampleMs=0;CHECK(!donorMessageSamplerPolicyValid(&bad));bad=sheet_donorMessageObservationPolicy_bounded;bad.rawMaxRecords=1;CHECK(!donorMessageSamplerPolicyValid(&bad));bad=sheet_donorMessageObservationPolicy_bounded;bad.pendingPairs=0;CHECK(!donorMessageSamplerPolicyValid(&bad));CHECK(!donorMessageSamplerPolicyValid(NULL));
 sampler.configured=false;CHECK(donorMessagePairKeep(&sampler,&entry,&exit,100));sampler.configured=true;sampler.used=129;CHECK(donorMessagePairKeep(&sampler,&entry,&exit,100));
 // Capacity is fixed and never evicts earlier keys; later unseen keys pass.
 donorMessageSamplerInit(&sampler);pair(&entry,&exit,9000);
 for(unsigned i=0;i<128;i++){entry.session=exit.session=i+1;CHECK(donorMessagePairKeep(&sampler,&entry,&exit,100));}
 CHECK(sampler.used==128);entry.session=exit.session=129;CHECK(donorMessagePairKeep(&sampler,&entry,&exit,100));CHECK(donorMessagePairKeep(&sampler,&entry,&exit,100));CHECK(sampler.used==128);
 entry.session=exit.session=1;CHECK(!donorMessagePairKeep(&sampler,&entry,&exit,100));CHECK(keep(&sampler,&entry,&exit,9100));CHECK(sampler.used==128);
 // Large clocks use64-bit deltas without rollover or unsigned-underflow drops.
 donorMessageSamplerInit(&sampler);pair(&entry,&exit,UINT64_MAX-100);CHECK(donorMessagePairKeep(&sampler,&entry,&exit,100));CHECK(!keep(&sampler,&entry,&exit,UINT64_MAX-1));CHECK(keep(&sampler,&entry,&exit,UINT64_MAX));CHECK(keep(&sampler,&entry,&exit,1));
 puts("PASS: production scalar-pair sampler first/100ms boundaries, full state/session/thread/section/payload keys, five flood IDs, all changed/nested/rare/invalid pairs kept, nonmonotonic64-bit clocks, bad-policy conservative fallback and fixed cache full with no eviction; no native dispatch or game access");return 0;
}
