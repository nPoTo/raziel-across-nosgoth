// SPDX-License-Identifier: GPL-3.0-or-later
// RZB2 paired transport. Open/close on an owning worker; snapshot calls never wait.
// Separate handles per consumer. Caller verifies supported games and supplies identity.
#ifndef BRIDGE_MEMORY_H
#define BRIDGE_MEMORY_H
#include "bridge-protocol.h"
#include "bridge-process-identity.h"
#include "render-memory.h"
enum {BRIDGE_MEMORY_PREFIX=24};
typedef enum {BM_REJECTED,BM_OK,BM_BUSY,BM_ABANDONED,BM_PEER_LOST} BridgeMemoryStatus;
#define BM_BYTES ((size_t)BRIDGE_MEMORY_PREFIX+4*BRIDGE_HEADER_BYTES+RM_GEOMETRY_BYTES+RM_APPEARANCE_BYTES+RM_LIVE_BYTES+RM_MOVEMENT_BYTES)
typedef struct {
 HANDLE map,mutex,writer,source,host;
 unsigned char *view;
 BridgeIdentity identity;
 bool producer;
 BridgeMemoryStatus status;
} BridgeMemory;
static inline size_t bridgeMemoryPayload(unsigned type){return type==BRIDGE_GEOMETRY?RM_GEOMETRY_BYTES:type==BRIDGE_APPEARANCE?RM_APPEARANCE_BYTES:type==BRIDGE_POSE?RM_LIVE_BYTES:type==BRIDGE_MOVEMENT?RM_MOVEMENT_BYTES:0;}
static inline size_t bridgeMemoryOffset(unsigned type){
 size_t offset=BRIDGE_MEMORY_PREFIX;for(unsigned t=BRIDGE_GEOMETRY;t<type;t++)offset+=BRIDGE_HEADER_BYTES+bridgeMemoryPayload(t);return offset;
}
static inline void bridgeMemoryNames(const BridgeIdentity *i,wchar_t map[160],wchar_t mutex[160]){
 swprintf(map,160,L"Local\\LOKRZB2-%lu-%llu-%llu",(unsigned long)i->hostPid,(unsigned long long)i->hostCreation,(unsigned long long)i->sessionGeneration);
 swprintf(mutex,160,L"Local\\LOKRZB2Lock-%lu-%llu-%llu",(unsigned long)i->hostPid,(unsigned long long)i->hostCreation,(unsigned long long)i->sessionGeneration);
}
static inline void bridgeMemoryClose(BridgeMemory *m){
 if(m->view)UnmapViewOfFile(m->view);if(m->map)CloseHandle(m->map);if(m->mutex)CloseHandle(m->mutex);if(m->writer)CloseHandle(m->writer);if(m->source)CloseHandle(m->source);if(m->host)CloseHandle(m->host);memset(m,0,sizeof(*m));
}
static inline bool bridgeMemoryProcess(HANDLE h,uint64_t expected){uint64_t creation=0;return h&&WaitForSingleObject(h,0)==WAIT_TIMEOUT&&bridgeProcessCreation(h,&creation)&&creation==expected;}
static inline bool bridgeMemoryOpen(BridgeMemory *m,const BridgeIdentity *i,bool producer){
 memset(m,0,sizeof(*m));if(!bridgePolicyValid()||!bridgeIdentityValid(i))return false;
 m->host=OpenProcess(SYNCHRONIZE|PROCESS_QUERY_LIMITED_INFORMATION,FALSE,i->hostPid);
 if(!bridgeMemoryProcess(m->host,i->hostCreation))goto fail;
 m->source=OpenProcess(SYNCHRONIZE|PROCESS_QUERY_LIMITED_INFORMATION,FALSE,i->sourcePid);if(!bridgeMemoryProcess(m->source,i->sourceCreation))goto fail;
 wchar_t name[160],lock[160];bridgeMemoryNames(i,name,lock);m->identity=*i;m->producer=producer;
 if(producer){
  SetLastError(0);m->mutex=CreateMutexW(NULL,FALSE,lock);if(!m->mutex||GetLastError()==ERROR_ALREADY_EXISTS)goto fail;
  SetLastError(0);m->map=CreateFileMappingW(INVALID_HANDLE_VALUE,NULL,PAGE_READWRITE,0,(DWORD)BM_BYTES,name);if(!m->map||GetLastError()==ERROR_ALREADY_EXISTS)goto fail;
 }else {m->map=OpenFileMappingW(FILE_MAP_READ,FALSE,name);m->mutex=OpenMutexW(SYNCHRONIZE|MUTEX_MODIFY_STATE,FALSE,lock);}
 if(!m->map||!m->mutex)goto fail;
 m->view=MapViewOfFile(m->map,producer?FILE_MAP_WRITE|FILE_MAP_READ:FILE_MAP_READ,0,0,BM_BYTES);if(!m->view)goto fail;
 if(producer){uint64_t creation=0;if(!bridgeProcessCreation(GetCurrentProcess(),&creation))goto fail;bridgePut(m->view,BRIDGE_MAGIC,4);bridgePut(m->view+4,GetCurrentProcessId(),4);bridgePut(m->view+8,creation,8);}
 else {
  DWORD result=WaitForSingleObject(m->mutex,0);
  if(result==WAIT_ABANDONED){ReleaseMutex(m->mutex);goto fail;}if(result!=WAIT_OBJECT_0)goto fail;
  bool prefixValid=bridgeU32(m->view)==BRIDGE_MAGIC;DWORD writerPid=bridgeU32(m->view+4);uint64_t writerCreation=bridgeU64(m->view+8);ReleaseMutex(m->mutex);
  if(!prefixValid)goto fail;m->writer=OpenProcess(SYNCHRONIZE|PROCESS_QUERY_LIMITED_INFORMATION,FALSE,writerPid);if(!bridgeMemoryProcess(m->writer,writerCreation))goto fail;
 }
 return true;
fail:bridgeMemoryClose(m);return false;
}
// Returns false on contention or abandoned lock; abandoned ownership is released.
static inline bool bridgeMemoryTryLock(BridgeMemory *m){
 if(!m||!m->view)return false;DWORD result=WaitForSingleObject(m->mutex,0);
 if(result==WAIT_ABANDONED){m->status=BM_ABANDONED;ReleaseMutex(m->mutex);return false;}
 m->status=result==WAIT_OBJECT_0?BM_OK:result==WAIT_TIMEOUT?BM_BUSY:BM_REJECTED;return result==WAIT_OBJECT_0;
}
static inline bool bridgeMemoryPublishFrame(BridgeMemory *m,const BridgeHeader *p,const unsigned char *pose,const BridgeHeader *c,const unsigned char *command){
 if(!m||!m->producer||!p||!c||!pose||!command||p->type!=BRIDGE_POSE||c->type!=BRIDGE_MOVEMENT||p->payloadBytes!=RM_LIVE_BYTES||c->payloadBytes!=RM_MOVEMENT_BYTES||p->sequence!=c->sequence||p->tick!=c->tick||!bridgeSameIdentity(&m->identity,&p->identity)||!bridgeSameIdentity(&m->identity,&c->identity))return false;
 unsigned char ph[BRIDGE_HEADER_BYTES],ch[BRIDGE_HEADER_BYTES];
 if(WaitForSingleObject(m->host,0)!=WAIT_TIMEOUT||WaitForSingleObject(m->source,0)!=WAIT_TIMEOUT||!bridgeEncodeHeader(ph,sizeof(ph),p)||!bridgeEncodeHeader(ch,sizeof(ch),c)||!bridgeMemoryTryLock(m))return false;
 size_t po=bridgeMemoryOffset(BRIDGE_POSE),co=bridgeMemoryOffset(BRIDGE_MOVEMENT);
 memcpy(m->view+po,ph,sizeof(ph));memcpy(m->view+po+sizeof(ph),pose,RM_LIVE_BYTES);memcpy(m->view+co,ch,sizeof(ch));memcpy(m->view+co+sizeof(ch),command,RM_MOVEMENT_BYTES);ReleaseMutex(m->mutex);return true;
}
static inline bool bridgeMemoryPublish(BridgeMemory *m,const BridgeHeader *h,const unsigned char *payload){
 if(!m||!m->producer||!h||!payload||!bridgeSameIdentity(&m->identity,&h->identity)||h->payloadBytes!=bridgeMemoryPayload(h->type)||!h->payloadBytes)return false;
 unsigned char header[BRIDGE_HEADER_BYTES];if(WaitForSingleObject(m->host,0)!=WAIT_TIMEOUT||WaitForSingleObject(m->source,0)!=WAIT_TIMEOUT||!bridgeEncodeHeader(header,sizeof(header),h)||!bridgeMemoryTryLock(m))return false;
 size_t offset=bridgeMemoryOffset(h->type);memcpy(m->view+offset,header,sizeof(header));memcpy(m->view+offset+sizeof(header),payload,h->payloadBytes);ReleaseMutex(m->mutex);return true;
}
static inline bool bridgeMemoryCopy(BridgeMemory *m,unsigned type,unsigned char *output,size_t bytes,uint64_t now,BridgeHeader *header){
 if(m)m->status=BM_REJECTED;
 if(!m||m->producer||!output||!header||!bytes||bytes!=bridgeMemoryPayload(type)||!bridgeMemoryTryLock(m))return false;
 bool ok=false;size_t offset=bridgeMemoryOffset(type);m->status=BM_REJECTED;
 if(bridgeU32(m->view)!=BRIDGE_MAGIC)goto done;
 if(WaitForSingleObject(m->source,0)!=WAIT_TIMEOUT||WaitForSingleObject(m->host,0)!=WAIT_TIMEOUT||WaitForSingleObject(m->writer,0)!=WAIT_TIMEOUT){m->status=BM_PEER_LOST;goto done;}
 BridgeHeader h;if(!bridgeDecode(m->view+offset,BRIDGE_HEADER_BYTES,BRIDGE_HEADER_BYTES+bytes,now,&m->identity,&h)||h.type!=type)goto done;
 memcpy(output,m->view+offset+BRIDGE_HEADER_BYTES,bytes);*header=h;ok=true;m->status=BM_OK;
done:ReleaseMutex(m->mutex);return ok;
}
// One lock covers both slots. A producer's incomplete pair can never be used
// for control. Caller owns fixed scratch buffers and validates inner payloads.
static inline bool bridgeMemoryFrame(BridgeMemory *m,unsigned char pose[RM_LIVE_BYTES],unsigned char movement[RM_MOVEMENT_BYTES],uint64_t now,BridgeHeader *poseHeader,BridgeHeader *movementHeader){
 if(m)m->status=BM_REJECTED;
 if(!m||m->producer||!pose||!movement||!poseHeader||!movementHeader||!bridgeMemoryTryLock(m))return false;
 bool ok=false;m->status=BM_REJECTED;
 if(bridgeU32(m->view)!=BRIDGE_MAGIC)goto done;
 if(WaitForSingleObject(m->source,0)!=WAIT_TIMEOUT||WaitForSingleObject(m->host,0)!=WAIT_TIMEOUT||WaitForSingleObject(m->writer,0)!=WAIT_TIMEOUT){m->status=BM_PEER_LOST;goto done;}
 BridgeHeader p,c;size_t po=bridgeMemoryOffset(BRIDGE_POSE),co=bridgeMemoryOffset(BRIDGE_MOVEMENT);
 if(!bridgeDecode(m->view+po,BRIDGE_HEADER_BYTES,BRIDGE_HEADER_BYTES+RM_LIVE_BYTES,now,&m->identity,&p)||p.type!=BRIDGE_POSE||
    !bridgeDecode(m->view+co,BRIDGE_HEADER_BYTES,BRIDGE_HEADER_BYTES+RM_MOVEMENT_BYTES,now,&m->identity,&c)||c.type!=BRIDGE_MOVEMENT||p.tick!=c.tick||p.sequence!=c.sequence)goto done;
 memcpy(pose,m->view+po+BRIDGE_HEADER_BYTES,RM_LIVE_BYTES);memcpy(movement,m->view+co+BRIDGE_HEADER_BYTES,RM_MOVEMENT_BYTES);*poseHeader=p;*movementHeader=c;ok=true;m->status=BM_OK;
done:ReleaseMutex(m->mutex);return ok;
}
// Static data is immutable in a validated session. Its publication may predate
// attachment; require a current pose heartbeat in the same context instead.
static inline bool bridgeMemoryResource(BridgeMemory *m,unsigned type,unsigned char *output,size_t bytes,uint64_t now){
 if(!m||m->producer||!output||(type!=BRIDGE_GEOMETRY&&type!=BRIDGE_APPEARANCE)||bytes!=bridgeMemoryPayload(type)||!bridgeMemoryTryLock(m))return false;
 bool ok=false;BridgeHeader resource,pose;size_t offset=bridgeMemoryOffset(type),po=bridgeMemoryOffset(BRIDGE_POSE);uint64_t tick=bridgeU64(m->view+offset+72);
 if(WaitForSingleObject(m->source,0)!=WAIT_TIMEOUT||WaitForSingleObject(m->host,0)!=WAIT_TIMEOUT||WaitForSingleObject(m->writer,0)!=WAIT_TIMEOUT||tick>now)goto done;
 if(!bridgeDecode(m->view+po,BRIDGE_HEADER_BYTES,BRIDGE_HEADER_BYTES+RM_LIVE_BYTES,now,&m->identity,&pose)||pose.type!=BRIDGE_POSE||
    !bridgeDecode(m->view+offset,BRIDGE_HEADER_BYTES,BRIDGE_HEADER_BYTES+bytes,tick,&m->identity,&resource)||resource.type!=type)goto done;
 memcpy(output,m->view+offset+BRIDGE_HEADER_BYTES,bytes);ok=true;
done:ReleaseMutex(m->mutex);return ok;
}
#endif
