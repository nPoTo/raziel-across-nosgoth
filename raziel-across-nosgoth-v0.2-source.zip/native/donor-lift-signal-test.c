#include <assert.h>
#include <stdio.h>
#include <math.h>
#include "host-contact-reader.h"
static uintptr_t donorProcessBase=0x100000,actor=0x200000;
static bool allowed=true;static unsigned mode=10;static float vz=120;static uintptr_t jump=0x10f1d0;
static bool donorProcessIdentity(uintptr_t a){return allowed&&a==actor;}
static bool worldRead(uintptr_t a,void *out,size_t n){
 uintptr_t value=0;
 if(a==donorProcessBase+0x113fff4&&n==4){memcpy(out,&mode,4);return true;}
 if(a==actor+0x170&&n==4){memcpy(out,&vz,4);return true;}
 if(a==actor+0x3f8)value=0x500000;
 else if(a==0x500000)value=actor;
 else {for(unsigned i=0;i<3;i++)if(a==0x500010+i*0x250&&n==16){uintptr_t pair[2]={donorProcessBase+jump,donorProcessBase+0x10f220};memcpy(out,pair,16);return true;}return false;}
 if(n!=8)return false;memcpy(out,&value,8);return true;
}
#include "donor-lift-signal.h"
int main(void){
 HostContactLease lease={.pid=GetCurrentProcessId(),.creation=123,.epoch=GetTickCount64(),.actor=0x600000};AirClockPacket p;
 assert(donorLiftOpen(lease));donorLiftPublish(&lease,actor,true);assert(airClockCopy(donorLiftView,&p)&&p.active&&p.actor==lease.actor&&p.magic==0x314c4341);
 vz=0;donorLiftPublish(&lease,actor,true);assert(airClockCopy(donorLiftView,&p)&&!p.active);
 vz=-2;donorLiftPublish(&lease,actor,true);assert(airClockCopy(donorLiftView,&p)&&!p.active);
 vz=NAN;donorLiftPublish(&lease,actor,true);assert(airClockCopy(donorLiftView,&p)&&!p.active);vz=120;
 mode=3;donorLiftPublish(&lease,actor,true);assert(airClockCopy(donorLiftView,&p)&&!p.active);mode=10;
 jump=0x111a00;donorLiftPublish(&lease,actor,true);assert(airClockCopy(donorLiftView,&p)&&!p.active);jump=0x10f1d0;
 allowed=false;donorLiftPublish(&lease,actor,true);assert(airClockCopy(donorLiftView,&p)&&!p.active);allowed=true;
 donorLiftPublish(&lease,actor,false);assert(airClockCopy(donorLiftView,&p)&&!p.active);
 donorLiftPublish(&lease,actor,true);assert(airClockCopy(donorLiftView,&p)&&p.active);donorLiftRevoke();assert(!airClockCopy(donorLiftView,&p));
 puts("PASS donor launch RAM receipt: actual rise, mode, sections, identity, scope and revocation");
}
