// SPDX-License-Identifier: GPL-3.0-or-later
#pragma once
#include "host-transition-observer.h"
#include "host-transition-proof.h"
static HostTransitionObserver hostTransitionObserver;
static _Thread_local DonorMessageObserverThread hostTransitionThread;
static HostSectionTransition hostSectionOriginal;static HostWholeTransition hostWholeOriginal;
static PVOID hostTransitionTargets[2];static HMODULE hostTransitionModule;
static uintptr_t hostTransitionBase;static uint32_t hostTransitionImageSize;
static HANDLE hostTransitionWorker;static bool hostTransitionAttempted;
static volatile LONG hostTransitionStopping,hostTransitionEnabled,hostTransitionActive;
static volatile LONG64 hostTransitionSession,hostTransitionStart,hostTransitionHeartbeat;
static bool hostTransitionReadLease(void *unused,DonorMessageLease *out){
 (void)unused;if(InterlockedCompareExchange(&hostTransitionStopping,0,0)||!InterlockedCompareExchange(&hostTransitionEnabled,0,0))return false;
 out->session=(uint64_t)InterlockedCompareExchange64(&hostTransitionSession,0,0);out->startTick=(uint64_t)InterlockedCompareExchange64(&hostTransitionStart,0,0);out->heartbeatTick=(uint64_t)InterlockedCompareExchange64(&hostTransitionHeartbeat,0,0);out->nowTick=GetTickCount64();out->enabled=!InterlockedCompareExchange(&hostTransitionStopping,0,0)&&InterlockedCompareExchange(&hostTransitionEnabled,0,0);return true;
}
static int hostTransitionSnapshot(void *unused,void *state,uintptr_t requested,HostTransitionMetadata *out){
 (void)unused;if((uintptr_t)InterlockedCompareExchangePointer(&verifiedSr1Module,NULL,NULL)!=hostTransitionBase)return -1;
 int status=hostTransitionRead(NULL,donorMessageRead,donorMessageCode,hostTransitionBase,hostTransitionImageSize,(uintptr_t)state,requested,out);
 if(status==1){float root[16];uintptr_t actor=0;if(!worldRoot(root,&actor)||actor!=out->opaqueActor)return -1;}return status;
}
static uint32_t hostTransitionCaller(uintptr_t caller){return caller>=hostTransitionBase&&caller-hostTransitionBase<hostTransitionImageSize?(uint32_t)(caller-hostTransitionBase):0;}
static uintptr_t __fastcall hostSectionHook(void *state,int32_t section,uintptr_t requested,uintptr_t payload){
 DWORD incoming=GetLastError();InterlockedIncrement(&hostTransitionActive);uint32_t caller=hostTransitionCaller((uintptr_t)__builtin_return_address(0));SetLastError(incoming);
 uintptr_t r=hostSectionTransitionForward(&hostTransitionObserver,&hostTransitionThread,hostSectionOriginal,state,section,requested,payload,caller);DWORD outgoing=GetLastError();InterlockedDecrement(&hostTransitionActive);SetLastError(outgoing);return r;
}
static uintptr_t __fastcall hostWholeHook(void *state,uintptr_t requested,uintptr_t payload){
 DWORD incoming=GetLastError();InterlockedIncrement(&hostTransitionActive);uint32_t caller=hostTransitionCaller((uintptr_t)__builtin_return_address(0));SetLastError(incoming);
 uintptr_t r=hostWholeTransitionForward(&hostTransitionObserver,&hostTransitionThread,hostWholeOriginal,state,requested,payload,caller);DWORD outgoing=GetLastError();InterlockedDecrement(&hostTransitionActive);SetLastError(outgoing);return r;
}
static void hostTransitionDrain(void){
 HostTransitionEvent e;unsigned n=0;while(n++<512&&hostTransitionPop(&hostTransitionObserver,&e))logLine("HOST_TRANSITION {\"session\":\"%llu\",\"callId\":%llu,\"tickMs\":%llu,\"phase\":%u,\"threadId\":%u,\"depth\":%u,\"callerRva\":%u,\"kind\":%u,\"section\":%u,\"requestedRva\":%u,\"payloadZero\":%u,\"handlers\":[%u,%u,%u],\"clips\":[%u,%u,%u],\"afterValid\":%u,\"sameActor\":%u}",(unsigned long long)e.session,(unsigned long long)e.callId,(unsigned long long)e.tickMs,e.phase,e.threadId,e.depth,e.callerRva,e.kind,e.section,e.requestedRva,e.payloadZero,e.handlers[0],e.handlers[1],e.handlers[2],e.clips[0],e.clips[1],e.clips[2],e.afterValid,e.sameActor);
}
static DWORD WINAPI hostTransitionCollect(LPVOID unused){
 (void)unused;DonorMessageSessionLease lease={0};uint64_t revoke=0;
 for(;;){RecordingStatus hb={0};GuidanceDescriptor d={0};uint64_t now=GetTickCount64();bool stopped=InterlockedCompareExchange(&hostTransitionStopping,0,0)!=0;
  bool files=!stopped&&recordingReadStatus(GetCurrentProcessId(),&hb)&&recordingStatusValid(&hb,GetCurrentProcessId(),now)&&donorMessageReadGuidance(&d)&&guidanceDescriptorValid(&d,GetCurrentProcessId(),hb.writerPid,hb.total)&&d.plan==(uint32_t)sheet_hostNativeTransitionPolicy_bounded.plan;
  uint64_t previous=lease.session;bool ready=donorMessageSessionAccept(&lease,files,d.session,d.writerPid,hb.tick,now,(uint64_t)sheet_hostNativeTransitionPolicy_bounded.seconds*1000,(uint64_t)sheet_donorMessageObservationPolicy_bounded.leaseMs);
  if(ready){if(!previous){InterlockedExchange64(&hostTransitionSession,(LONG64)lease.session);InterlockedExchange64(&hostTransitionStart,(LONG64)lease.startTick);logLine("HOST_TRANSITION_SESSION session=%llu start=%llu; original calls only",(unsigned long long)lease.session,(unsigned long long)lease.startTick);}InterlockedExchange64(&hostTransitionHeartbeat,(LONG64)lease.heartbeatTick);InterlockedExchange(&hostTransitionEnabled,1);}else InterlockedExchange(&hostTransitionEnabled,0);
  hostTransitionDrain();if(lease.terminal||stopped){if(!revoke)revoke=now;if(!InterlockedCompareExchange(&hostTransitionActive,0,0)){hostTransitionDrain();logLine("HOST_TRANSITION_END session=%llu published=%llu dropped=%llu forwarded=%llu unrelated=%llu boundary=%llu lease=%llu metadata=%llu depth=%llu producer=%llu queue=%llu budget=%llu; synthetic_calls=0",(unsigned long long)lease.session,(unsigned long long)hostTransitionObserver.published,(unsigned long long)hostTransitionObserver.dropped,(unsigned long long)hostTransitionObserver.forwarded,(unsigned long long)hostTransitionObserver.unrelated,(unsigned long long)hostTransitionObserver.boundaryRejected,(unsigned long long)hostTransitionObserver.leaseDrops,(unsigned long long)hostTransitionObserver.metadataDrops,(unsigned long long)hostTransitionObserver.depthDrops,(unsigned long long)hostTransitionObserver.producerDrops,(unsigned long long)hostTransitionObserver.queueDrops,(unsigned long long)hostTransitionObserver.budgetDrops);return 0;}if(now-revoke>=3000){logLine("HOST_TRANSITION_SHUTDOWN active calls; END withheld");return 1;}}Sleep(50);
 }
}
static bool hostTransitionInstall(HMODULE module){
 if(hostTransitionAttempted)return false;hostTransitionAttempted=true;
 IMAGE_DOS_HEADER dos={0};IMAGE_NT_HEADERS64 nt={0};uintptr_t base=(uintptr_t)module;unsigned char body[256];char digest[65];
 if(!worldRead(base,&dos,sizeof(dos))||dos.e_magic!=IMAGE_DOS_SIGNATURE||dos.e_lfanew<=0||dos.e_lfanew>0x100000||!worldRead(base+(uintptr_t)dos.e_lfanew,&nt,sizeof(nt))||nt.Signature!=IMAGE_NT_SIGNATURE||nt.OptionalHeader.Magic!=IMAGE_NT_OPTIONAL_HDR64_MAGIC||nt.OptionalHeader.SizeOfImage<0x2a89318)return false;
 for(unsigned i=0;i<2;i++){const HostTransitionProof *p=&hostTransitionProofs[i];if(p->bytes>sizeof(body)||!worldRead(base+p->rva,body,p->bytes)||!hashBytes(body,p->bytes,digest)||strcmp(digest,p->sha256))return false;}
 hostTransitionBase=base;hostTransitionImageSize=nt.OptionalHeader.SizeOfImage;if(!GetModuleHandleExW(GET_MODULE_HANDLE_EX_FLAG_FROM_ADDRESS,(LPCWSTR)(base+hostTransitionProofs[0].rva),&hostTransitionModule)||hostTransitionModule!=module)return false;
 hostTransitionInit(&hostTransitionObserver,NULL,hostTransitionReadLease,hostTransitionSnapshot);if(!hostTransitionObserver.configured)return false;
 MH_STATUS init=MH_Initialize();if(init!=MH_OK&&init!=MH_ERROR_ALREADY_INITIALIZED)return false;
 PVOID targets[2]={(PVOID)(base+hostTransitionProofs[0].rva),(PVOID)(base+hostTransitionProofs[1].rva)};
 if(MH_CreateHook(targets[0],(PVOID)hostSectionHook,(PVOID *)&hostSectionOriginal)!=MH_OK||!hostSectionOriginal)return false;
 if(MH_CreateHook(targets[1],(PVOID)hostWholeHook,(PVOID *)&hostWholeOriginal)!=MH_OK||!hostWholeOriginal)return false;
 for(unsigned i=0;i<2;i++){if(MH_EnableHook(targets[i])!=MH_OK){for(unsigned j=0;j<i;j++)MH_DisableHook(targets[j]);return false;}hostTransitionTargets[i]=targets[i];}
 hostTransitionWorker=CreateThread(NULL,0,hostTransitionCollect,NULL,0,NULL);if(!hostTransitionWorker){for(unsigned i=0;i<2;i++)MH_DisableHook(targets[i]);return false;}
 logLine("CAPABILITY host_native_transition_observation=1; current player native switches only; synthetic_calls=0");return true;
}
static bool hostTransitionStop(void){
 bool complete=true;InterlockedExchange(&hostTransitionStopping,1);InterlockedExchange(&hostTransitionEnabled,0);
 for(unsigned i=0;i<2;i++)if(hostTransitionTargets[i]){MH_STATUS s=MH_DisableHook(hostTransitionTargets[i]);if(s==MH_OK||s==MH_ERROR_DISABLED)hostTransitionTargets[i]=NULL;else complete=false;}
 if(hostTransitionWorker){DWORD waited=WaitForSingleObject(hostTransitionWorker,5000);if(waited==WAIT_OBJECT_0){DWORD code=1;if(!GetExitCodeThread(hostTransitionWorker,&code)||code)complete=false;if(CloseHandle(hostTransitionWorker))hostTransitionWorker=NULL;else complete=false;}else complete=false;}
 if(InterlockedCompareExchange(&hostTransitionActive,0,0))complete=false;
 // Retain trampolines and SR1 module reference until exit: no portable unload claim.
 logLine("HOST_TRANSITION_SHUTDOWN complete=%d; module reference/trampolines retained until process exit",complete);return complete;
}
