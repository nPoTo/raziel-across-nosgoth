// SPDX-License-Identifier: GPL-3.0-or-later
#include <stdio.h>
#include <limits.h>
#include <MinHook.h>
#include "donor-initialization-observer.h"
static DonorInitializationObserver observer;static _Thread_local uint32_t depth;
static struct {unsigned calls,reads,errors,nesting,wanted;bool fail,race;HANDLE entered,release;} f;
static uintptr_t __fastcall original(uintptr_t actor);
static DonorNativeInitialization trampoline;
static uintptr_t invoke(uintptr_t actor){return donorInitializationForward(&observer,&depth,original,actor,0x157784);}
static bool snapshot(void *unused,uintptr_t actor,DonorAnimationContextObservation *m){
 (void)unused;f.reads++;if(actor!=UINT64_C(0xfedcba9876543210))f.errors++;SetLastError(17);if(f.race)InterlockedIncrement64(&observer.epoch);
 *m=(DonorAnimationContextObservation){.valid=true,.availableMask=63,.cachedMatchMask=7,.selectionKeys={53,53,53}};return !f.fail;
}
static uintptr_t __fastcall original(uintptr_t actor){
 f.calls++;if(actor!=UINT64_C(0xfedcba9876543210)||GetLastError()!=0x12345678)f.errors++;
 if(f.entered){SetEvent(f.entered);WaitForSingleObject(f.release,2000);}
 if(++f.nesting<f.wanted){SetLastError(0x12345678);uintptr_t r=invoke(actor);if(r!=UINT64_C(0xabcdef0123456789))f.errors++;}f.nesting--;SetLastError(0x87654321);return UINT64_C(0xabcdef0123456789);
}
static uintptr_t __fastcall hook(uintptr_t a){return donorInitializationForward(&observer,&depth,trampoline,a,0x157784);}
static void setup(void){memset(&f,0,sizeof(f));depth=0;f.wanted=1;donorInitializationInit(&observer,GetTickCount64(),NULL,snapshot);}
static bool run(void){SetLastError(0x12345678);uintptr_t r=invoke(UINT64_C(0xfedcba9876543210));return r==UINT64_C(0xabcdef0123456789)&&GetLastError()==0x87654321&&!f.errors;}
static DWORD WINAPI parallel(LPVOID unused){(void)unused;return run()?0:1;}
static uintptr_t __fastcall secondOriginal(uintptr_t actor){f.calls++;if(actor!=UINT64_C(0xfedcba9876543210)||GetLastError()!=0x12345678)f.errors++;SetLastError(0x87654321);return UINT64_C(0xabcdef0123456789);}
#define CHECK(c,n) do{if(!(c)){printf("FAIL %u\n",(unsigned)n);return n;}}while(0)
int main(void){
 DonorInitializationEvent e;setup();CHECK(run()&&f.calls==1&&f.reads==1&&!depth&&!observer.active&&observer.epoch==1,1);CHECK(donorInitializationPop(&observer,&e)&&e.phase==1&&e.active==1&&!e.current&&!e.valid,2);CHECK(donorInitializationPop(&observer,&e)&&e.phase==2&&e.valid&&e.current&&e.cachedMatchMask==7&&e.keys[2]==53,3);
 // Same actor pointer and identical context metadata still revoke an old token.
 CHECK(run()&&observer.epoch==2&&!donorInitializationCurrent(&observer,1,GetTickCount64())&&donorInitializationCurrent(&observer,2,GetTickCount64()),4);
 setup();f.fail=true;CHECK(run()&&donorInitializationPop(&observer,&e)&&donorInitializationPop(&observer,&e)&&!e.valid&&!e.keys[0],5);
 setup();f.race=true;CHECK(run()&&donorInitializationPop(&observer,&e)&&donorInitializationPop(&observer,&e)&&!e.valid&&!e.current,6);
 setup();f.wanted=3;CHECK(run()&&f.calls==3&&observer.epoch==3&&observer.published==6&&!f.reads&&!observer.active&&!depth,7);
 setup();AcquireSRWLockExclusive(&observer.queueLock);CHECK(run()&&f.calls==1&&observer.dropped==2&&!observer.published,8);ReleaseSRWLockExclusive(&observer.queueLock);
 setup();observer.head=63;CHECK(run()&&f.calls==1&&observer.dropped==2,9);
 setup();observer.start-=600000;CHECK(run()&&f.calls==1&&observer.stopped&&!observer.epoch&&!f.reads&&!observer.published,10);
 setup();observer.calls=128;CHECK(run()&&f.calls==1&&observer.stopped&&!observer.active&&!f.reads&&!observer.published,11);
 setup();observer.epoch=LLONG_MAX;CHECK(run()&&f.calls==1&&observer.stopped&&!observer.active&&!f.reads,12);
 setup();depth=32;CHECK(run()&&f.calls==1&&observer.stopped&&depth==32&&!observer.active,13);depth=0;
 setup();observer.configured=false;CHECK(run()&&f.calls==1&&!observer.calls,14);
 setup();CHECK(MH_Initialize()==MH_OK&&MH_CreateHook((PVOID)original,(PVOID)hook,(PVOID *)&trampoline)==MH_OK&&MH_EnableHook((PVOID)original)==MH_OK,15);
 DonorNativeInitialization volatile target=original;SetLastError(0x12345678);uintptr_t r=target(UINT64_C(0xfedcba9876543210));DWORD last=GetLastError();CHECK(MH_DisableHook((PVOID)original)==MH_OK&&MH_RemoveHook((PVOID)original)==MH_OK&&MH_Uninitialize()==MH_OK,16);CHECK(r==UINT64_C(0xabcdef0123456789)&&last==0x87654321&&!f.errors&&f.calls==1&&observer.published==2,17);
 setup();f.entered=CreateEventW(NULL,TRUE,FALSE,NULL);f.release=CreateEventW(NULL,TRUE,FALSE,NULL);HANDLE t=CreateThread(NULL,0,parallel,NULL,0,NULL);CHECK(t&&WaitForSingleObject(f.entered,1000)==WAIT_OBJECT_0,18);uint64_t epoch=(uint64_t)observer.epoch;CHECK(epoch==1&&observer.active==1&&!donorInitializationCurrent(&observer,epoch,GetTickCount64()),19);
 SetLastError(0x12345678);r=donorInitializationForward(&observer,&depth,secondOriginal,UINT64_C(0xfedcba9876543210),0x157784);CHECK(r==UINT64_C(0xabcdef0123456789)&&GetLastError()==0x87654321&&observer.epoch==2&&observer.active==1&&!f.reads,20);
 SetEvent(f.release);CHECK(WaitForSingleObject(t,2000)==WAIT_OBJECT_0,21);DWORD code=1;CHECK(GetExitCodeThread(t,&code)&&code==0&&!observer.active&&f.calls==2&&!f.reads&&!donorInitializationCurrent(&observer,epoch,GetTickCount64())&&donorInitializationCurrent(&observer,2,GetTickCount64()),22);CHECK(CloseHandle(t)&&CloseHandle(f.entered)&&CloseHandle(f.release),23);
 puts("PASS: original1arg opaque64 forwarding/RAX/LastError; real MinHook; same-address epoch revocation, nested and cross-thread active rejection, raced/failed fresh metadata, nonblocking queue overflow/contention, time/call/depth/epoch limits");return 0;
}
