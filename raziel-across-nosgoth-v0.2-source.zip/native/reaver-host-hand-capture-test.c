// SPDX-License-Identifier: GPL-3.0-or-later
#include <windows.h>
#include <stdbool.h>
#include <stdint.h>
#include <string.h>
#include <math.h>
#include <assert.h>
#include <stdio.h>
#include "exploration-sheets.h"
#include "host-transform.h"
// Exercise the actual adapter-side capture with controlled engine reads.
typedef struct {uintptr_t actor,model,render;unsigned char renderBytes[66][52];} HostRig;
static HostRig live;
static float submitted[66][13];
static HGLRC context=(HGLRC)(uintptr_t)1;
static uint64_t hostDrawCreation=11;
static LONG sr1SkeletonFailed;
static bool readable=true,identityReadable=true;
#ifdef SR1_REAVER_GPU_RECEIPT
static unsigned paletteCount=66,paletteReads;
static float palette[96*12];static bool paletteTorn,paletteUnreadable;
#endif
static HGLRC testContext(void){return context;}
static bool worldRead(uintptr_t address,void *out,SIZE_T bytes){
#ifdef SR1_REAVER_GPU_RECEIPT
 if(address==123+0x5aa3264){if(paletteUnreadable||bytes!=4)return false;memcpy(out,&paletteCount,4);return true;}
 if(address==123+0x5aa3300){if(paletteUnreadable||bytes>sizeof(palette))return false;memcpy(out,palette,bytes);if(paletteTorn&&++paletteReads%2==0)((float *)out)[0]+=1;return true;}
#endif
 if(!readable||bytes!=sizeof(submitted))return false;
 if(address==live.render)memcpy(out,live.renderBytes,bytes);
 else if(address==(uintptr_t)submitted)memcpy(out,submitted,bytes);
 else return false;
 return true;
}
static bool sr1SkeletonRead(void *unused,uintptr_t address,void *out,SIZE_T bytes){(void)unused;return worldRead(address,out,bytes);}
static bool rigIdentitySnapshot(void *unused,bool (*read)(void *,uintptr_t,void *,SIZE_T),uintptr_t base,HostRig *out){
 (void)unused;(void)read;if(!identityReadable||base!=123)return false;*out=live;return true;
}
static bool rigSameIdentity(const HostRig *a,const HostRig *b){return a->actor==b->actor&&a->model==b->model&&a->render==b->render;}
#define SR1_NATIVE_DRAW_RECEIPT 1
#define wglGetCurrentContext testContext
#include "reaver-host-hand-capture.h"
int main(void){
 (void)decodeHostRoot;(void)hostMultiply;
 for(unsigned b=0;b<66;b++)submitted[b][0]=submitted[b][4]=submitted[b][8]=1;
 submitted[42][12]=10;submitted[44][10]=10;
 live.actor=4;live.model=8;live.render=12;memcpy(live.renderBytes,submitted,sizeof(submitted));HostRig before=live;
 submitted[49][10]=90;float expected[66][13],hand[16];memcpy(expected,submitted,sizeof(expected));
 reaverHostCapture(&before,expected,(uintptr_t)submitted,123,7,1);
 assert(reaverHostCurrentHand(hand,4,8,7,context)&&hand[12]==90);
 assert(reaverHostPalm.valid&&reaverHostPalm.matrix[12]==90&&reaverHostPalm.matrix[10]==1);
 assert(!memcmp(expected,submitted,sizeof(expected)));
#ifdef SR1_REAVER_GPU_RECEIPT
 assert(reaverHostPalette.valid&&reaverHostPalette.joints==66&&reaverHostPalette.hand.matrix[12]==90);
 paletteCount=97;reaverHostCapture(&before,expected,(uintptr_t)submitted,123,7,1);assert(!reaverHostPalette.valid);paletteCount=66;
 paletteTorn=true;reaverHostCapture(&before,expected,(uintptr_t)submitted,123,7,1);assert(!reaverHostPalette.valid);paletteTorn=false;
 paletteUnreadable=true;reaverHostCapture(&before,expected,(uintptr_t)submitted,123,7,1);assert(!reaverHostPalette.valid);paletteUnreadable=false;
 reaverHostCapture(&before,expected,(uintptr_t)submitted,123,7,1);assert(reaverHostPalette.valid);
#endif
 assert(!reaverHostCurrentHand(hand,4,8,8,context));
 assert(!reaverHostCurrentHand(hand,4,8,7,(HGLRC)(uintptr_t)2));
 hostDrawCreation++;assert(!reaverHostCurrentHand(hand,4,8,7,context));hostDrawCreation--;
 // Native handoff replaces adapted position in the same context/frame.
 memcpy(expected,before.renderBytes,sizeof(expected));reaverHostCapture(&before,expected,live.render,123,8,1);
 assert(reaverHostCurrentHand(hand,4,8,8,context)&&hand[12]==0);
 assert(reaverHostPalm.valid&&reaverHostPalm.matrix[12]==0);
 // Rejection must erase, not retain a previous admitted hand.
 readable=false;reaverHostCapture(&before,expected,live.render,123,9,1);assert(!reaverHostHand.valid&&!reaverHostContext);readable=true;
 live.renderBytes[0][0]^=1;reaverHostCapture(&before,expected,live.render,123,9,1);assert(!reaverHostHand.valid);live=before;
 live.model++;reaverHostCapture(&before,expected,live.render,123,9,1);assert(!reaverHostHand.valid);live=before;
 memcpy(expected,submitted,sizeof(expected));submitted[3][12]=5;reaverHostCapture(&before,expected,(uintptr_t)submitted,123,9,1);assert(!reaverHostHand.valid);submitted[3][12]=0;
 sr1SkeletonFailed=1;reaverHostCapture(&before,expected,(uintptr_t)submitted,123,9,1);assert(!reaverHostHand.valid);sr1SkeletonFailed=0;
 context=NULL;reaverHostCapture(&before,expected,(uintptr_t)submitted,123,9,1);assert(!reaverHostHand.valid);context=(HGLRC)(uintptr_t)1;
 reaverHostCapture(&before,expected,(uintptr_t)submitted,123,9,2);assert(!reaverHostHand.valid);
 identityReadable=false;reaverHostCapture(&before,expected,(uintptr_t)submitted,123,9,1);assert(!reaverHostHand.valid);
 puts("PASS actual hand capture: forwarded/native poses, current GL context/frame/session, torn or changed identity/input clears receipt. Fixtures, not gameplay.");return 0;
}
