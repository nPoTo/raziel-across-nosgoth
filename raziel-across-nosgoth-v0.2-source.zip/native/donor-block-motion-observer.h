// SPDX-License-Identifier: GPL-3.0-or-later
#pragma once
#include "donor-message-observer.h"
#include "donor-block-motion-reader.h"
typedef uintptr_t (__fastcall *DonorBlockMotionNative)(uintptr_t);
typedef int (*DonorBlockMotionSnapshot)(void *,uintptr_t,DonorBlockMotionMetadata *);
typedef struct {uint64_t session,id,tickMs;uint32_t phase,thread,depth,kind,callerRva,handler,flags,selector,result,afterValid,sameBinding;float direction[2],position[3];} DonorBlockMotionEvent;
typedef struct {DonorBlockMotionEvent queue[512];volatile LONG64 readCursor,writeCursor,published,forwarded,nextId,dropped,leaseDrops,metadataDrops,depthDrops,producerDrops,queueDrops,budgetDrops;volatile LONG producer;void *context;DonorMessageLeaseRead lease;DonorBlockMotionSnapshot snapshot;bool configured;} DonorBlockMotionObserver;
static inline void donorBlockMotionInit(DonorBlockMotionObserver *o,void *c,DonorMessageLeaseRead l,DonorBlockMotionSnapshot s){memset(o,0,sizeof(*o));o->context=c;o->lease=l;o->snapshot=s;const Sheet_donorBlockMotionPolicy *p=&sheet_donorBlockMotionPolicy_bounded;o->configured=l&&s&&p->startRva==0xcee90&&p->startBytes==1566&&p->finishRva==0xcea50&&p->finishBytes==547&&p->seconds==60&&p->plan==11&&p->queueCapacity==512&&p->maxRecords==4096&&p->maxDepth==32&&!p->serializePointers&&!p->serializeFinishReturn&&!p->syntheticCalls;}
static inline bool donorBlockMotionPush(DonorBlockMotionObserver *o,const DonorBlockMotionEvent *e){
 uint64_t w=(uint64_t)InterlockedCompareExchange64(&o->writeCursor,0,0),r=(uint64_t)InterlockedCompareExchange64(&o->readCursor,0,0);if(w-r>=512){InterlockedIncrement64(&o->queueDrops);InterlockedIncrement64(&o->dropped);return false;}if((uint64_t)InterlockedCompareExchange64(&o->published,0,0)>=4096){InterlockedIncrement64(&o->budgetDrops);InterlockedIncrement64(&o->dropped);return false;}
 o->queue[w%512]=*e;InterlockedExchange64(&o->writeCursor,(LONG64)(w+1));InterlockedIncrement64(&o->published);return true;
}
static inline bool donorBlockMotionPop(DonorBlockMotionObserver *o,DonorBlockMotionEvent *e){uint64_t r=(uint64_t)InterlockedCompareExchange64(&o->readCursor,0,0),w=(uint64_t)InterlockedCompareExchange64(&o->writeCursor,0,0);if(r==w)return false;*e=o->queue[r%512];InterlockedExchange64(&o->readCursor,(LONG64)(r+1));return true;}
static inline bool donorBlockMotionLease(DonorBlockMotionObserver *o,const DonorMessageLease *start,DonorMessageLease *now){return o->lease(o->context,now)&&donorMessageLeaseValid(now)&&now->session==start->session&&now->startTick==start->startTick&&now->nowTick>=start->nowTick&&now->heartbeatTick>=start->heartbeatTick;}
static inline void donorBlockMotionFields(DonorBlockMotionEvent *e,const DonorBlockMotionMetadata *m){e->handler=m->handler;e->flags=m->flags;e->selector=m->selector;memcpy(e->direction,m->direction,8);memcpy(e->position,m->position,12);}
static inline uintptr_t donorBlockMotionForward(DonorBlockMotionObserver *o,uint32_t *depth,DonorBlockMotionNative original,uintptr_t target,uint32_t kind,uint32_t caller){
 DWORD incoming=GetLastError(),thread=GetCurrentThreadId();uint32_t old=*depth;if(old<UINT32_MAX)++*depth;InterlockedIncrement64(&o->forwarded);DonorMessageLease start={0},now={0};DonorBlockMotionMetadata before={0};DonorBlockMotionEvent e={0};bool entered=false;
 if(o->configured&&o->lease(o->context,&start)&&start.enabled){
  if(!donorMessageLeaseValid(&start)){InterlockedIncrement64(&o->leaseDrops);InterlockedIncrement64(&o->dropped);}else if(old>=32){InterlockedIncrement64(&o->depthDrops);InterlockedIncrement64(&o->dropped);}else{
   int s=o->snapshot(o->context,target,&before);if(s<0){InterlockedIncrement64(&o->metadataDrops);InterlockedIncrement64(&o->dropped);}else if(s>0){LONG producer=InterlockedCompareExchange(&o->producer,(LONG)thread,0);if(producer&&(DWORD)producer!=thread){InterlockedIncrement64(&o->producerDrops);InterlockedIncrement64(&o->dropped);}else if(!donorBlockMotionLease(o,&start,&now)){InterlockedIncrement64(&o->leaseDrops);InterlockedIncrement64(&o->dropped);}else{e=(DonorBlockMotionEvent){.session=start.session,.id=(uint64_t)InterlockedIncrement64(&o->nextId),.tickMs=now.nowTick,.phase=1,.thread=thread,.depth=old+1,.kind=kind,.callerRva=caller};donorBlockMotionFields(&e,&before);entered=donorBlockMotionPush(o,&e);}}
  }
 }
 SetLastError(incoming);uintptr_t result=original(target);DWORD outgoing=GetLastError();
 if(entered){DonorBlockMotionMetadata after={0};if(donorBlockMotionLease(o,&start,&now)){bool valid=o->snapshot(o->context,target,&after)==1;bool same=valid&&before.opaqueActor==after.opaqueActor&&before.opaqueState==after.opaqueState&&before.opaqueUserdata==after.opaqueUserdata;if(donorBlockMotionLease(o,&start,&now)){e.phase=2;e.tickMs=now.nowTick;e.afterValid=valid;e.sameBinding=same;e.result=kind==1?(uint32_t)result:0;DonorBlockMotionMetadata empty={0};donorBlockMotionFields(&e,valid?&after:&empty);donorBlockMotionPush(o,&e);}else{InterlockedIncrement64(&o->leaseDrops);InterlockedIncrement64(&o->dropped);}}else{InterlockedIncrement64(&o->leaseDrops);InterlockedIncrement64(&o->dropped);}}
 *depth=old;SetLastError(outgoing);return result;
}
