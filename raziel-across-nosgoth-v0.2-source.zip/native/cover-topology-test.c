#include <stdint.h>
#include <stdbool.h>
#include <stdio.h>
#include <string.h>
#include "cover-topology.h"
int main(void){
 CoverRange ranges[3];if(coverRanges(false,false,ranges))return 1;
 unsigned char seen[125790];
 for(unsigned open=0;open<2;open++){
  memset(seen,0,sizeof(seen));unsigned count=coverRanges(true,open!=0,ranges),total=0;if(count!=3)return 2;
  for(unsigned i=0;i<count;i++){if(ranges[i].count%3||ranges[i].offset%3||ranges[i].offset+ranges[i].count>125790)return 3;for(unsigned j=ranges[i].offset;j<ranges[i].offset+ranges[i].count;j++)if(seen[j]++)return 4;total+=ranges[i].count;}
  if(total!=119832)return 5;
  for(unsigned i=0;i<125790;i++){bool removed=open?(i>=7830&&i<13788):(i>=1872&&i<7830);if(seen[i]!=(unsigned char)!removed)return 6;}
 }
 puts("Cover topology: exclusive open/closed ranges, unchanged common body, bounds/hash scope PASS");return 0;
}
