// SPDX-License-Identifier: GPL-3.0-or-later
#include <stdio.h>
#include <MinHook.h>
#include "donor-animation-marker-observer.h"
static DonorAnimationMarkerObserver observer;
static DonorMessageObserverThread tls;
static struct {DonorMessageLease lease;bool beforeFails,afterFails,changeSession;unsigned calls,errors,reads,nested,wanted;void *root,*payload,*context;int32_t section;uint32_t type,data;} f;
static bool lease(void *unused,DonorMessageLease *out){(void)unused;*out=f.lease;SetLastError(0xaaaaaaaa);return true;}
static bool snapshot(void *unused,void *root,int32_t section,DonorAnimationMarkerMetadata *out){
 (void)unused;f.reads++;if(root!=f.root||section!=f.section)f.errors++;
 if(f.beforeFails||(f.afterFails&&f.reads%2==0))return false;
 *out=(DonorAnimationMarkerMetadata){67,83,0x12345678};SetLastError(0xbbbbbbbb);return true;
}
static uintptr_t __fastcall original(void *root,int32_t section,uint32_t type,uint32_t data,void *payload,void *context){
 f.calls++;if(root!=f.root||section!=f.section||type!=f.type||data!=f.data||payload!=f.payload||context!=f.context||GetLastError()!=0x12345678)f.errors++;
 if(++f.nested<f.wanted){SetLastError(0x12345678);uintptr_t r=donorAnimationMarkerForward(&observer,&tls,original,root,section,type,data,payload,context,0x5d5f8,2,1);if(r!=UINT64_C(0xfedcba9876543210)||GetLastError()!=0x87654321)f.errors++;}f.nested--;
 if(f.changeSession)f.lease.session++;
 SetLastError(0x87654321);return UINT64_C(0xfedcba9876543210);
}
static void setup(void){memset(&f,0,sizeof(f));memset(&tls,0,sizeof(tls));f.lease=(DonorMessageLease){true,17,1000,1000,1000};f.wanted=1;f.root=(void *)0x1000;f.payload=(void *)UINT64_C(0xfedcba9876500000);f.context=(void *)UINT64_C(0xabcdef0012340000);f.section=2;f.type=6;f.data=UINT32_MAX;donorAnimationMarkerInit(&observer,NULL,lease,snapshot);}
static bool run(void){SetLastError(0x12345678);uintptr_t r=donorAnimationMarkerForward(&observer,&tls,original,f.root,f.section,f.type,f.data,f.payload,f.context,0x5d5f8,2,1);return r==UINT64_C(0xfedcba9876543210)&&GetLastError()==0x87654321&&!f.errors;}
static DonorNativeAnimationMarker trampoline;
static uintptr_t __fastcall hook(void *root,int32_t section,uint32_t type,uint32_t data,void *payload,void *context){return donorAnimationMarkerForward(&observer,&tls,trampoline,root,section,type,data,payload,context,0x5d5f8,2,1);}
#define CHECK(c,n) do{if(!(c)){printf("FAIL %u\n",(unsigned)(n));return n;}}while(0)
static DWORD WINAPI produce(LPVOID unused){
 (void)unused;for(uint64_t i=1;i<=4000;i++){
  DonorAnimationMarkerEvent e={0};e.callId=i;e.session=17;e.key=(uint32_t)(i^0x55aa);e.clip=(uint32_t)(i^0xaa55);
  // Test harness may yield on a full queue; production publication never waits.
  while(!donorAnimationMarkerPush(&observer,&e))SwitchToThread();
 }return 0;
}
int main(void){
 DonorAnimationMarkerEvent e;
 setup();CHECK(run()&&f.calls==1&&observer.published==2&&tls.depth==0,1);CHECK(donorAnimationMarkerPop(&observer,&e)&&e.phase==1&&e.eventType==6&&e.eventData==UINT32_MAX&&e.messageDepth==2&&e.selectorDepth==1,2);CHECK(donorAnimationMarkerPop(&observer,&e)&&e.phase==2&&e.afterValid&&e.sameState,3);
 setup();f.lease.enabled=false;CHECK(run()&&f.calls==1&&!observer.published,4);
 setup();f.lease.nowTick=2500;CHECK(run()&&f.calls==1&&!observer.published&&observer.leaseDrops==1,5);
 setup();f.beforeFails=true;CHECK(run()&&f.calls==1&&!observer.published&&observer.metadataDrops==1,6);
 setup();f.afterFails=true;CHECK(run()&&f.calls==1&&observer.published==2,7);CHECK(donorAnimationMarkerPop(&observer,&e)&&donorAnimationMarkerPop(&observer,&e)&&!e.afterValid&&!e.key&&!e.sameState,8);
 setup();f.changeSession=true;CHECK(run()&&f.calls==1&&observer.published==1&&observer.leaseDrops==1,9);
 setup();f.wanted=3;CHECK(run()&&f.calls==3&&observer.published==6&&!observer.dropped&&tls.depth==0,10);
 setup();observer.producerThread=(LONG)GetCurrentThreadId()+1;CHECK(run()&&f.calls==1&&!observer.published&&observer.producerDrops==1,11);
 setup();observer.published=8192;CHECK(run()&&f.calls==1&&observer.published==8192&&observer.budgetDrops==1,12);
 setup();f.root=NULL;f.section=-1;CHECK(run()&&f.calls==1&&!observer.published&&observer.metadataDrops==1,13);
 setup();tls.depth=UINT32_MAX;CHECK(run()&&f.calls==1&&tls.depth==UINT32_MAX&&!observer.published&&observer.depthDrops==1,14);
 setup();tls.ownerThread=(LONG)GetCurrentThreadId()+1;CHECK(run()&&f.calls==1&&!observer.published,15);
 setup();f.payload=NULL;f.context=NULL;CHECK(run()&&f.calls==1&&observer.published==2,16);
 setup();observer.writeCursor=512;CHECK(run()&&f.calls==1&&!observer.published&&observer.queueDrops==1,17);
 // Exercise actual stack argument forwarding in this owned fixture EXE only.
 setup();CHECK(MH_Initialize()==MH_OK,18);CHECK(MH_CreateHook((PVOID)original,(PVOID)hook,(PVOID *)&trampoline)==MH_OK,19);CHECK(MH_EnableHook((PVOID)original)==MH_OK,20);
 DonorNativeAnimationMarker volatile target=original;SetLastError(0x12345678);uintptr_t result=target(f.root,f.section,f.type,f.data,f.payload,f.context);DWORD last=GetLastError();
 CHECK(MH_DisableHook((PVOID)original)==MH_OK,21);CHECK(MH_RemoveHook((PVOID)original)==MH_OK&&MH_Uninitialize()==MH_OK,22);
 CHECK(result==UINT64_C(0xfedcba9876543210)&&last==0x87654321&&f.calls==1&&!f.errors&&observer.published==2,23);
 // Real concurrent producer/consumer crosses the ring wrap repeatedly. Each
 // consumer row must be complete and ordered, with no shared queue lock.
 setup();HANDLE thread=CreateThread(NULL,0,produce,NULL,0,NULL);CHECK(thread,24);uint64_t wanted=1,deadline=GetTickCount64()+5000;
 while(wanted<=4000&&GetTickCount64()<deadline){if(donorAnimationMarkerPop(&observer,&e)){CHECK(e.callId==wanted&&e.session==17&&e.key==(uint32_t)(wanted^0x55aa)&&e.clip==(uint32_t)(wanted^0xaa55),25);wanted++;}else SwitchToThread();}
 CHECK(wanted==4001&&WaitForSingleObject(thread,1000)==WAIT_OBJECT_0&&CloseHandle(thread),26);
 CHECK(observer.published==4000&&observer.readCursor==4000&&observer.writeCursor==4000&&!observer.producerDrops&&!observer.leaseDrops,27);
 setup();observer.consumerThread=(LONG)GetCurrentThreadId()+1;CHECK(!donorAnimationMarkerPop(&observer,&e),28);
 puts("PASS: marker original six args/opaque stack payloads/64-bit result/LastError, real MinHook fixture; recursion and per-reason failure counters; concurrent4000-row bounded SPSC publication/order/wrap and wrong-producer/consumer rejection; no queue locks or payload reads");return 0;
}
