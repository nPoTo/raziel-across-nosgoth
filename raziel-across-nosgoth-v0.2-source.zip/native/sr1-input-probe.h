#include "session-budget.h"
#include "report-path.h"
// XInput observation plus explicit, bounded host jump experiment (default off).
#include <xinput.h>
#include "sr1-input-channels.h"
#include "sr1-jump-bridge.h"
#include "exploration-sheets.h"
static SrJumpBridge srJumpPads[4];
static volatile LONG srJumpEnabled,srJumpLock;
static ULONGLONG srJumpBegin;
static uintptr_t srInputMainBase;
static bool srJumpRequested;
static volatile LONG srCombatEnabled;
static ULONGLONG srCombatBegin;
static bool srCombatRequested;
static uintptr_t srJumpPlayer;
static float srJumpBaseZ;
static ULONGLONG srJumpLaunch;
typedef DWORD (WINAPI *SrInputFn)(DWORD,XINPUT_STATE *);
static SrInputFn originalSrInput;
// Installed only by the separately admitted completed-frame adapter. It is
// never a fake XInput device and cannot change XInput's return status.
static bool (*srUnifiedInput)(XINPUT_STATE *);
static _Thread_local bool srUnifiedFrame;
static bool (*srAuthorityInputScope)(ULONGLONG,uintptr_t,DWORD);
// Gate optional root corrections from one unambiguous physical device. SDL
// can assign the gamepad to any XInput slot; slot zero is not guaranteed.
static inline bool srPhysicalInput(XINPUT_STATE *state){
 if(srUnifiedInput&&state&&srUnifiedInput(state))return true;
 if(!originalSrInput||!state||!sheet_hostInputDevice_physical.requireUnique||sheet_hostInputDevice_physical.maxPads!=XUSER_MAX_COUNT)return false;
 unsigned connected=0;XINPUT_STATE selected={0};
 for(DWORD index=0;index<XUSER_MAX_COUNT;index++){
  XINPUT_STATE candidate={0};DWORD result=originalSrInput(index,&candidate);
  if(result==ERROR_SUCCESS){if(++connected>1)return false;selected=candidate;}
  else if(result!=ERROR_DEVICE_NOT_CONNECTED)return false;
 }
 if(connected!=1)return false;*state=selected;return true;
}
static inline bool srGroundMovementInput(void){
 XINPUT_STATE state={0};return srPhysicalInput(&state)&&state.Gamepad.wButtons==0&&state.Gamepad.bLeftTrigger<sheet_hostInputDevice_physical.triggerLimit&&state.Gamepad.bRightTrigger<sheet_hostInputDevice_physical.triggerLimit;
}
static inline bool srGroundMovingInput(void){
 XINPUT_STATE state={0};if(!srPhysicalInput(&state)||state.Gamepad.wButtons||state.Gamepad.bLeftTrigger>=sheet_hostInputDevice_physical.triggerLimit||state.Gamepad.bRightTrigger>=sheet_hostInputDevice_physical.triggerLimit)return false;
 int64_t x=state.Gamepad.sThumbLX,y=state.Gamepad.sThumbLY,d=sheet_hostInputDevice_physical.leftDeadzone;return x*x+y*y>d*d;
}
#ifdef SR1_REPEAT_JUMP_INPUT
#include "sr1-repeat-jump-input.h"
#endif
#if defined(SR1_FREE_ATTACK_INPUT) && defined(SR1_NATIVE_SKELETON_ADAPTER)
#include "sr1-free-attack-input.h"
#endif
static PVOID srInputTarget;
static bool srInputAttempted;
static volatile LONG srInputEnabled,srInputLock,srInputDrops;
static ULONGLONG srInputBegin,srInputLast[4],srInputLastRecord;
static unsigned int srInputHead,srInputTail,srInputRecords;
typedef struct {ULONGLONG tick;uintptr_t caller;DWORD index,result,foreground;WORD delivered;BYTE deliveredLt;XINPUT_STATE state;} SrInputEvent;
static SrInputEvent srInputQueue[512];
static bool srCombatScope(ULONGLONG now,uintptr_t caller,DWORD foreground,bool actorValid,uintptr_t player){
 return InterlockedCompareExchange(&srCombatEnabled,0,0)&&srCombatBegin&&now>=srCombatBegin&&sessionBudget(srCombatBegin,now,(uint64_t)sheet_diagnosticLimits_controls.durationMs)&&
 foreground==GetCurrentProcessId()&&(caller==srInputMainBase+0x5bc9||caller==srInputMainBase+0x5047)&&
 worldLastDraw&&now>=worldLastDraw&&now-worldLastDraw<250&&actorValid&&player&&player==worldLastInstance;
}
static WORD srCombatButtons(WORD delivered,WORD hardware,bool eligible){
 if(!eligible)return delivered;
 // Physical Defiance controls -> native host actions: B telekinesis(Y),
 // RB feed(B), LB face enemy(RB). Clear source bits before constructing
 // destinations so simultaneous chords cannot cascade into each other.
 delivered=(WORD)(delivered&~(XINPUT_GAMEPAD_LEFT_SHOULDER|XINPUT_GAMEPAD_RIGHT_SHOULDER|XINPUT_GAMEPAD_B));
 if(hardware&XINPUT_GAMEPAD_B)delivered|=XINPUT_GAMEPAD_Y;
 if(hardware&XINPUT_GAMEPAD_RIGHT_SHOULDER)delivered|=XINPUT_GAMEPAD_B;
 if(hardware&XINPUT_GAMEPAD_LEFT_SHOULDER)delivered|=XINPUT_GAMEPAD_RIGHT_SHOULDER;
 // Defiance LB+A is evasion. Consume the hardware A only while LB is
 // held; standalone A and the separately generated Y lift pulse survive.
 if((hardware&(XINPUT_GAMEPAD_LEFT_SHOULDER|XINPUT_GAMEPAD_A))==(XINPUT_GAMEPAD_LEFT_SHOULDER|XINPUT_GAMEPAD_A))
  delivered=(WORD)(delivered&~XINPUT_GAMEPAD_A);
 return delivered;
}
static DWORD WINAPI observeSrInput(DWORD index,XINPUT_STATE *state) {
    DWORD result=originalSrInput(index,state);
    if(srUnifiedFrame)return result; // Completed frame applies the common policy once.
    ULONGLONG now=GetTickCount64();uintptr_t caller=(uintptr_t)__builtin_return_address(0);
    XINPUT_STATE raw={0};bool readable=result==ERROR_SUCCESS&&index<4&&worldRead((uintptr_t)state,&raw,sizeof(raw));
    DWORD foreground=0;GetWindowThreadProcessId(GetForegroundWindow(),&foreground);
    WORD delivered=readable?raw.Gamepad.wButtons:0;
    BYTE deliveredLt=readable?raw.Gamepad.bLeftTrigger:0;
    if(readable&&!InterlockedCompareExchange(&srJumpLock,1,0)){
        bool active=InterlockedCompareExchange(&srJumpEnabled,0,0)&&srJumpBegin&&now>=srJumpBegin&&sessionBudget(srJumpBegin,now,(uint64_t)sheet_diagnosticLimits_controls.durationMs);
        uintptr_t player=0;float root[16];
        bool eligible=active&&foreground==GetCurrentProcessId()&&
            (caller==srInputMainBase+0x5bc9||caller==srInputMainBase+0x5047)&&
            worldLastDraw&&now>=worldLastDraw&&now-worldLastDraw<250&&worldRoot(root,&player)&&player==worldLastInstance;
        bool wasFired=srJumpPads[index].fired;
        delivered=srJumpButtons(&srJumpPads[index],raw.Gamepad.wButtons,now,player,eligible);
        if(eligible&&!wasFired&&srJumpPads[index].fired&&srJumpPads[index].pulseUntil){srJumpPlayer=player;srJumpBaseZ=root[14];srJumpLaunch=now;}
        deliveredLt=srJumpLeftTrigger(&srJumpPads[index],raw.Gamepad.bLeftTrigger,now,eligible);
        bool combatActor=worldRoot(root,&player);
        delivered=srCombatButtons(delivered,raw.Gamepad.wButtons,srCombatScope(now,caller,foreground,combatActor,player));
        // Combat mode translates B/RB/LB and consumes hardware LB+A jump;
        // raw hardware input remains unchanged for the separate donor process.
        if(delivered!=raw.Gamepad.wButtons)state->Gamepad.wButtons=delivered;
        if(deliveredLt!=raw.Gamepad.bLeftTrigger)state->Gamepad.bLeftTrigger=deliveredLt;
        InterlockedExchange(&srJumpLock,0);
    }
    bool authorityInput=false;
    if(readable&&srAuthorityInputScope&&(authorityInput=srAuthorityInputScope(now,caller,foreground))){
        // Preserve pause/back so the test remains navigable. Donor still sees
        // the original physical controller in its own process.
        WORD navigation=raw.Gamepad.wButtons&(XINPUT_GAMEPAD_START|XINPUT_GAMEPAD_BACK);
        memset(&state->Gamepad,0,sizeof(state->Gamepad));state->Gamepad.wButtons=navigation;
        delivered=navigation;deliveredLt=0;
    }
#ifdef SR1_REPEAT_JUMP_INPUT
    if(readable&&!InterlockedCompareExchange(&srJumpEnabled,0,0)&&!InterlockedCompareExchange(&srCombatEnabled,0,0)&&!authorityInput){
        delivered=srRepeatApply(index,now,caller,foreground,&raw,state);state->Gamepad.wButtons=delivered;
    }
#endif
#if defined(SR1_FREE_ATTACK_INPUT) && defined(SR1_NATIVE_SKELETON_ADAPTER)
    if(readable&&!authorityInput&&!InterlockedCompareExchange(&srCombatEnabled,0,0)&&!InterlockedCompareExchange(&srJumpEnabled,0,0)){
        delivered=srFreeApply(index,now,caller,foreground,&raw,state);state->Gamepad.wButtons=delivered;
    }
#endif
    if(!InterlockedCompareExchange(&srInputEnabled,0,0)||index>=4)return result;
    if(result!=ERROR_SUCCESS&&index!=0)return result; // Do not fill the log with three absent controllers.
    if(InterlockedCompareExchange(&srInputLock,1,0)){InterlockedIncrement(&srInputDrops);return result;}
    if(!srInputBegin)srInputBegin=now;
    if(now-srInputBegin<180000&&now-srInputLast[index]>=16&&srInputRecords<12000){
        srInputLast[index]=now;unsigned int next=(srInputHead+1)%ARRAYSIZE(srInputQueue);
        if(next==srInputTail)InterlockedIncrement(&srInputDrops);
        else {
            SrInputEvent e={0};e.tick=now;e.index=index;e.result=result;e.caller=caller;e.foreground=foreground;e.delivered=delivered;e.deliveredLt=deliveredLt;
            // Success means XInput filled this buffer; use guarded read anyway.
            if(result!=ERROR_SUCCESS||readable){
                e.state=raw;
                srInputQueue[srInputHead]=e;srInputHead=next;++srInputRecords;srInputLastRecord=now;
            }
        }
    }
    InterlockedExchange(&srInputLock,0);return result;
}
static void srInputFlush(void) {
    SrInputEvent local[512];unsigned int count=0;
    if(InterlockedCompareExchange(&srInputLock,1,0))return;
    while(srInputTail!=srInputHead){local[count++]=srInputQueue[srInputTail];srInputTail=(srInputTail+1)%ARRAYSIZE(srInputQueue);}
    InterlockedExchange(&srInputLock,0);
    for(unsigned int i=0;i<count;++i){SrInputEvent *e=&local[i];
        logLine("SR1_INPUT tick=%llu index=%lu result=%lu caller=%p foreground=%lu packet=%lu buttons=%u lt=%u rt=%u lx=%d ly=%d rx=%d ry=%d delivered=%u delivered_lt=%u",
            e->tick,e->index,e->result,(void *)e->caller,e->foreground,e->state.dwPacketNumber,e->state.Gamepad.wButtons,
            e->state.Gamepad.bLeftTrigger,e->state.Gamepad.bRightTrigger,e->state.Gamepad.sThumbLX,e->state.Gamepad.sThumbLY,e->state.Gamepad.sThumbRX,e->state.Gamepad.sThumbRY,e->delivered,e->deliveredLt);
    }
}
static void srInputInstall(void) {
    if(srInputAttempted)return;
    HMODULE module=GetModuleHandleW(L"xinput1_3.dll");if(!module)return;
    PVOID target=(PVOID)GetProcAddress(module,"XInputGetState");if(!target)return;
    srInputAttempted=true;
    srInputMainBase=(uintptr_t)GetModuleHandleW(NULL);
    HMODULE pinned;if(!GetModuleHandleExW(GET_MODULE_HANDLE_EX_FLAG_FROM_ADDRESS|GET_MODULE_HANDLE_EX_FLAG_PIN,(LPCWSTR)target,&pinned))return;
    MH_STATUS init=MH_Initialize();if(init!=MH_OK&&init!=MH_ERROR_ALREADY_INITIALIZED)return;
    MH_STATUS create=MH_CreateHook(target,(PVOID)&observeSrInput,(PVOID *)&originalSrInput);
    MH_STATUS enable=create==MH_OK?MH_EnableHook(target):create;
    if(enable==MH_OK)srInputTarget=target;
    logLine("SR1_INPUT observer create=%d enable=%d target=%p; original call/result/state unchanged",create,enable,target);
}
static void srInputTick(void) {
#if defined(SR1_FREE_ATTACK_INPUT) && defined(SR1_NATIVE_SKELETON_ADAPTER)
    srFreeTick();
#endif
#ifdef SR1_REPEAT_JUMP_INPUT
    srRepeatTick();
#endif
    bool combat=GetFileAttributesW(PROBE_PATH(L"\\combat-input-sr1.enable"))!=INVALID_FILE_ATTRIBUTES&&
        GetFileAttributesW(PROBE_PATH(L"\\world-sr1.enable"))!=INVALID_FILE_ATTRIBUTES&&
        GetFileAttributesW(PROBE_PATH(L"\\replace-sr1.enable"))!=INVALID_FILE_ATTRIBUTES;
    if(combat!=srCombatRequested){srCombatRequested=combat;srCombatBegin=combat?GetTickCount64():0;InterlockedExchange(&srCombatEnabled,combat);logLine("SR1_COMBAT_INPUT enabled=%u; B->hostY TK, RB->hostB feed, LB->hostRB face; host map and hardware LB+A jump suppressed; standalone A and donor raw unchanged; bounded75s",combat);}
    bool jump=GetFileAttributesW(PROBE_PATH(L"\\jump-y-sr1.enable"))!=INVALID_FILE_ATTRIBUTES&&
        GetFileAttributesW(PROBE_PATH(L"\\world-sr1.enable"))!=INVALID_FILE_ATTRIBUTES&&
        GetFileAttributesW(PROBE_PATH(L"\\replace-sr1.enable"))!=INVALID_FILE_ATTRIBUTES;
    if(jump!=srJumpRequested&&!InterlockedCompareExchange(&srJumpLock,1,0)){
        srJumpRequested=jump;srJumpBegin=jump?GetTickCount64():0;memset(srJumpPads,0,sizeof(srJumpPads));
        srJumpPlayer=0;srJumpLaunch=0;
        InterlockedExchange(&srJumpEnabled,jump);InterlockedExchange(&srJumpLock,0);
        logLine("SR1_JUMP_BRIDGE enabled=%d; Y LT=255 preparation300ms -> single A hold600ms, LT release80ms; bounded75s",jump);
    }
    bool requested=GetFileAttributesW(PROBE_PATH(L"\\input-sr1.enable"))!=INVALID_FILE_ATTRIBUTES;
    if(!requested)InterlockedExchange(&srInputEnabled,0);
    else if(!InterlockedCompareExchange(&srInputEnabled,0,0)){
        // Rearm only on an explicit flag transition, within the outer worker lifetime.
        srInputFlush();
        if(!InterlockedCompareExchange(&srInputLock,1,0)){
            srInputBegin=srInputLastRecord=0;srInputRecords=0;
            memset(srInputLast,0,sizeof(srInputLast));
            InterlockedExchange(&srInputEnabled,1);
            InterlockedExchange(&srInputLock,0);
        }
    }
    srInputFlush();
}
static bool srInputRecording(ULONGLONG now) {
    return InterlockedCompareExchange(&srInputEnabled,0,0)&&srInputBegin&&now>=srInputBegin&&now-srInputBegin<180000&&srInputRecords<12000&&
        now>=srInputLastRecord&&now-srInputLastRecord<500;
}
static void srInputStop(void) {
#if defined(SR1_FREE_ATTACK_INPUT) && defined(SR1_NATIVE_SKELETON_ADAPTER)
    srFreeStop();
#endif
#ifdef SR1_REPEAT_JUMP_INPUT
    srRepeatStop();
#endif
    InterlockedExchange(&srCombatEnabled,0);
    InterlockedExchange(&srJumpEnabled,0);
    InterlockedExchange(&srInputEnabled,0);
    if(srInputTarget)logLine("SR1_INPUT disabled=%d dropped=%ld",MH_DisableHook(srInputTarget)==MH_OK,InterlockedCompareExchange(&srInputDrops,0,0));
    srInputFlush(); // trampoline remains pinned for in-flight calls
}

