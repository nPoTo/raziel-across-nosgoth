// SPDX-License-Identifier: GPL-3.0-or-later
#pragma once
#include "donor-message-observer.h"

// Windows x64: root,section,type,data plus two opaque stack arguments.
// Keep the full integer return register without interpreting native return data.
typedef uintptr_t (__fastcall *DonorNativeAnimationMarker)(void *,int32_t,uint32_t,uint32_t,void *,void *);
typedef struct {uint32_t key,clip;uintptr_t opaqueState;} DonorAnimationMarkerMetadata;
typedef bool (*DonorAnimationMarkerRead)(void *,void *,int32_t,DonorAnimationMarkerMetadata *);
typedef struct {
 uint64_t session,callId,tickMs;
 uint32_t phase,threadId,depth,callerRva,messageDepth,selectorDepth,section,eventType,eventData,key,clip,afterValid,sameState;
} DonorAnimationMarkerEvent;
_Static_assert(sizeof(DonorAnimationMarkerEvent)==80,"Scalar callback record; no native pointers");
typedef struct {
 DonorAnimationMarkerEvent queue[512];
 volatile LONG readCursor,writeCursor,producerThread,consumerThread;
 volatile LONG64 forwarded,published,dropped,nextCallId;
 volatile LONG64 leaseDrops,metadataDrops,depthDrops,producerDrops,queueDrops,budgetDrops;
 void *context;DonorMessageLeaseRead lease;DonorAnimationMarkerRead snapshot;bool configured;
} DonorAnimationMarkerObserver;
static inline void donorAnimationMarkerInit(DonorAnimationMarkerObserver *o,void *c,DonorMessageLeaseRead l,DonorAnimationMarkerRead r){
 memset(o,0,sizeof(*o));o->context=c;o->lease=l;o->snapshot=r;
 const Sheet_donorAnimationMarkerPolicy *p=&sheet_donorAnimationMarkerPolicy_bounded;
 o->configured=l&&r&&p->rva==0x14f600&&p->spanBytes==2112&&p->rootOffset==0x1a8&&p->plan==11&&p->seconds==60&&p->queueCapacity==512&&p->maxRecords==8192&&p->maxDepth==32&&p->requireSingleProducer&&p->recordDropReasons&&!p->serializePointers&&!p->dereferencePayloads&&!p->syntheticCalls;
}
static inline void donorAnimationMarkerDrop(DonorAnimationMarkerObserver *o,volatile LONG64 *reason){InterlockedIncrement64(reason);InterlockedIncrement64(&o->dropped);}
// One registered producer and one registered consumer. Interlocked operations
// provide acquire/release barriers on Windows. Cursor values cannot wrap in
// this one-session8192-record observer. No native code is called inside publish.
static inline bool donorAnimationMarkerPush(DonorAnimationMarkerObserver *o,const DonorAnimationMarkerEvent *e){
 DWORD tid=GetCurrentThreadId();LONG owner=InterlockedCompareExchange(&o->producerThread,(LONG)tid,0);
 if(owner&&(DWORD)owner!=tid){donorAnimationMarkerDrop(o,&o->producerDrops);return false;}
 uint32_t write=(uint32_t)InterlockedCompareExchange(&o->writeCursor,0,0),read=(uint32_t)InterlockedCompareExchange(&o->readCursor,0,0);
 if((uint64_t)InterlockedCompareExchange64(&o->published,0,0)>=(uint64_t)sheet_donorAnimationMarkerPolicy_bounded.maxRecords){donorAnimationMarkerDrop(o,&o->budgetDrops);return false;}
 if(write<read||write-read>=512){donorAnimationMarkerDrop(o,&o->queueDrops);return false;}
 o->queue[write%512]=*e;InterlockedIncrement64(&o->published);InterlockedExchange(&o->writeCursor,(LONG)(write+1));return true;
}
static inline bool donorAnimationMarkerPop(DonorAnimationMarkerObserver *o,DonorAnimationMarkerEvent *e){
 DWORD tid=GetCurrentThreadId();LONG owner=InterlockedCompareExchange(&o->consumerThread,(LONG)tid,0);if(owner&&(DWORD)owner!=tid)return false;
 uint32_t read=(uint32_t)InterlockedCompareExchange(&o->readCursor,0,0),write=(uint32_t)InterlockedCompareExchange(&o->writeCursor,0,0);
 if(write<=read||write-read>512)return false;
 *e=o->queue[read%512];InterlockedExchange(&o->readCursor,(LONG)(read+1));return true;
}
static inline bool donorAnimationMarkerLease(DonorAnimationMarkerObserver *o,const DonorMessageLease *start,DonorMessageLease *now){
 return o->lease(o->context,now)&&donorMessageLeaseValid(now)&&now->session==start->session&&now->startTick==start->startTick&&now->heartbeatTick>=start->heartbeatTick&&now->nowTick>=start->nowTick;
}
static inline uintptr_t donorAnimationMarkerForward(DonorAnimationMarkerObserver *o,DonorMessageObserverThread *tls,DonorNativeAnimationMarker original,void *root,int32_t section,uint32_t type,uint32_t data,void *payload,void *context,uint32_t callerRva,uint32_t messageDepth,uint32_t selectorDepth){
 DWORD incoming=GetLastError(),tid=GetCurrentThreadId();uint32_t depth=0;bool tracked=false,entered=false;
 DonorMessageLease start={0},now={0};DonorAnimationMarkerMetadata before={0};DonorAnimationMarkerEvent e={0};
 if(tls){LONG owner=InterlockedCompareExchange(&tls->ownerThread,(LONG)tid,0);tracked=owner==0||(DWORD)owner==tid;if(tracked){depth=tls->depth;tls->depth=depth<UINT32_MAX?depth+1:UINT32_MAX;}}
 if(o)InterlockedIncrement64(&o->forwarded);
 if(o&&o->configured&&tracked&&o->lease(o->context,&start)&&start.enabled){
  if(!donorMessageLeaseValid(&start))donorAnimationMarkerDrop(o,&o->leaseDrops);
  else if(depth>=(uint32_t)sheet_donorAnimationMarkerPolicy_bounded.maxDepth)donorAnimationMarkerDrop(o,&o->depthDrops);
  else if(!root||section<0||section>2||!o->snapshot(o->context,root,section,&before))donorAnimationMarkerDrop(o,&o->metadataDrops);
  else if(!donorAnimationMarkerLease(o,&start,&now))donorAnimationMarkerDrop(o,&o->leaseDrops);
  else{e.session=start.session;e.callId=(uint64_t)InterlockedIncrement64(&o->nextCallId);e.tickMs=now.nowTick;e.phase=1;e.threadId=tid;e.depth=depth+1;e.callerRva=callerRva;e.messageDepth=messageDepth;e.selectorDepth=selectorDepth;e.section=(uint32_t)section;e.eventType=type;e.eventData=data;e.key=before.key;e.clip=before.clip;entered=donorAnimationMarkerPush(o,&e);}
 }
 // Neither opaque argument is read or retained by the observer.
 SetLastError(incoming);uintptr_t result=original(root,section,type,data,payload,context);DWORD outgoing=GetLastError();
 if(entered){
  DonorAnimationMarkerMetadata after={0};
  if(donorAnimationMarkerLease(o,&start,&now)){
   bool valid=o->snapshot(o->context,root,section,&after);
   if(donorAnimationMarkerLease(o,&start,&now)){e.phase=2;e.tickMs=now.nowTick;e.afterValid=valid;e.sameState=valid&&before.opaqueState==after.opaqueState;e.key=valid?after.key:0;e.clip=valid?after.clip:0;donorAnimationMarkerPush(o,&e);}
   else donorAnimationMarkerDrop(o,&o->leaseDrops);
  }else donorAnimationMarkerDrop(o,&o->leaseDrops);
 }
 if(tracked)tls->depth=depth;SetLastError(outgoing);return result;
}
