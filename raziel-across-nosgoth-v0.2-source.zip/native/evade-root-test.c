// Reuse the existing native-controller fixtures, independently exercise evasion.
#define main walkingHarnessMain
#include "instant-root-test.c"
#undef main
#include <xinput.h>
typedef DWORD (WINAPI *SrInputFn)(DWORD,XINPUT_STATE *);
static SrInputFn originalSrInput;static volatile LONG srCombatEnabled;
#include "evade-root.h"
static unsigned char evadePacket[96];static WORD hardware=XINPUT_GAMEPAD_LEFT_SHOULDER;
static DWORD WINAPI mockInput(DWORD index,XINPUT_STATE *state){(void)index;memset(state,0,sizeof(*state));state->Gamepad.wButtons=hardware;return ERROR_SUCCESS;}
static bool mockPacket(unsigned char out[96]){if(!packetAvailable)return false;memcpy(out,evadePacket,96);uint64_t tick=GetTickCount64()-(stalePacket?500:0),episode=tick-50;memcpy(out+16,&tick,8);memcpy(out+24,&episode,8);return true;}
static void resetEvade(void){
 rootOtherRelease=NULL;rootOtherAfter=NULL;reset();evadeModule=instantRootModule;uintptr_t p=evadeModule+HOST_LOCK_RVA;memcpy(fixtureState+0x10,&p,8);
 originalEvadeState=mockState;originalSrInput=mockInput;evadeReadPacket=mockPacket;srCombatEnabled=1;evadeEnabled=1;evadeBegin=GetTickCount64();
 evadeLastTick=evadeBegin-20;evadeLastPlayer=fixturePlayer;evadeOwned=evadeFailed=false;evadeBusy=0;evadeFrames=evadeCalls=0;evadeLastEpisode=evadeLastSource=0;hardware=XINPUT_GAMEPAD_LEFT_SHOULDER;
}
int main(int argc,char **argv){
 CHECK(argc==2);FILE *in=fopen(argv[1],"rb");CHECK(in&&fread(evadePacket,96,1,in)==1);fclose(in);
 float v[2];uint64_t tick,episode;CHECK(evadePacketVelocity(evadePacket,96,1050,4242,1050,v,&tick,&episode)&&v[0]==-2&&v[1]==1);
 CHECK(!evadePacketVelocity(evadePacket,95,1050,4242,1050,v,&tick,&episode));CHECK(!evadePacketVelocity(evadePacket,96,1250,4242,1050,v,&tick,&episode));CHECK(!evadePacketVelocity(evadePacket,96,1050,4243,1050,v,&tick,&episode));
 unsigned char invalid[96];memcpy(invalid,evadePacket,96);invalid[64]^=1;CHECK(!evadePacketVelocity(invalid,96,1050,4242,1050,v,&tick,&episode));
 memcpy(invalid,evadePacket,96);float nan=NAN;memcpy(invalid+32,&nan,4);CHECK(!evadePacketVelocity(invalid,96,1050,4242,1050,v,&tick,&episode));
 CHECK(!evadePacketVelocity(evadePacket,96,1049,4242,1050,v,&tick,&episode));
 resetEvade();evadeEnabled=0;CHECK(observeEvadeState((uintptr_t)fixtureState,0,0x55)==0xabcd&&calls==1&&sets==0&&lastArgs[2]==0x55);
 resetEvade();CHECK(observeEvadeState((uintptr_t)fixtureState,0,0x1234)==0xabcd&&calls==1&&sets==2&&evadeOwned&&evadeFrames==1);
 RootController c;CHECK(rootControllerRead(evadeModule,fixturePlayer+0x448,1,&c)&&c.active&&((float *)c.vector)[0]<-35&&((float *)c.vector)[1]>17);
 // Disabling the profile restores controllers before native handling resumes.
 evadeEnabled=0;observeEvadeState((uintptr_t)fixtureState,0,0);CHECK(!evadeOwned&&disables==2&&sets==4);
 int16_t pos[3];memcpy(pos,fixtureActor+0x9c,6);CHECK(pos[0]==11&&pos[1]==22&&pos[2]==-4828);
 resetEvade();nativeActive=true;observeEvadeState((uintptr_t)fixtureState,0,0);CHECK(evadeOwned&&evadeSaved[0].active);evadeEnabled=0;evadeRelease((uintptr_t)fixtureState);CHECK(!disables&&rootControllerRead(evadeModule,fixturePlayer+0x448,1,&c)&&((float *)c.vector)[1]==-35);
 resetEvade();failSet=true;observeEvadeState((uintptr_t)fixtureState,0,0);CHECK(evadeFailed&&!evadeOwned&&disables==2);CHECK(rootControllerRead(evadeModule,fixturePlayer+0x328,0,&c)&&!c.active&&((int16_t *)c.vector)[0]==0);
 resetEvade();failEnable=true;observeEvadeState((uintptr_t)fixtureState,0,0);CHECK(evadeFailed&&!evadeOwned&&disables==1);
 resetEvade();packetAvailable=false;observeEvadeState((uintptr_t)fixtureState,0,0);CHECK(!sets&&!evadeOwned);
 resetEvade();stalePacket=true;observeEvadeState((uintptr_t)fixtureState,0,0);CHECK(!sets);
 resetEvade();hardware=XINPUT_GAMEPAD_LEFT_SHOULDER|XINPUT_GAMEPAD_X;observeEvadeState((uintptr_t)fixtureState,0,0);CHECK(!sets);
 resetEvade();wrongForeground=true;observeEvadeState((uintptr_t)fixtureState,0,0);CHECK(!sets);
 resetEvade();*(int32_t *)(fixtureActor+0x2d4)=10;observeEvadeState((uintptr_t)fixtureState,0,0);CHECK(!sets);
 resetEvade();fixtureNextProcess=instantRootModule+0xedb40;observeEvadeState((uintptr_t)fixtureState,0,0);CHECK(!sets&&!switches);
 resetEvade();observeEvadeState((uintptr_t)fixtureState,1,0);CHECK(calls==1&&!sets);
 for(unsigned k=0;k<4;k++){resetEvade();uintptr_t p=instantRootModule+rootStateRvas[k];memcpy(fixtureState+0x10,&p,8);fixtureInput=false;rootOtherRelease=evadeReleaseOnTransition;rootOtherAfter=evadeAfterState;rootStateObserve(k,(uintptr_t)fixtureState,0,0);CHECK(evadeFrames==1&&sets==2&&!switches);evadeEnabled=0;rootStateObserve(k,(uintptr_t)fixtureState,0,0);CHECK(!evadeOwned&&disables==2);}
 resetEvade();evadeBegin=GetTickCount64()-76000;observeEvadeState((uintptr_t)fixtureState,0,0);CHECK(!sets);
 resetEvade();observeEvadeState((uintptr_t)fixtureState,0,0);rootOtherRelease=evadeReleaseOnTransition;evadeEnabled=0;fixtureInput=false;rootStationary((uintptr_t)fixtureState,0,0);CHECK(!evadeOwned&&disables==2);
 resetEvade();observeEvadeState((uintptr_t)fixtureState,0,0);unsigned char otherState[1024]={0};CHECK(!evadeRelease((uintptr_t)otherState)&&evadeOwned);CHECK(evadeRelease((uintptr_t)fixtureState)&&!evadeOwned&&disables==2);
 resetEvade();observeEvadeState((uintptr_t)fixtureState,0,0);float native[3]={1,2,3};mockSet(fixturePlayer+0x448,0,34,(uintptr_t)native);evadeRelease((uintptr_t)fixtureState);CHECK(rootControllerRead(evadeModule,fixturePlayer+0x448,1,&c)&&c.active&&((float *)c.vector)[0]==1); // Native modifications win.
 evadeTick();evadeStop();evadeInstall(NULL);puts("Evade native callback forwarding, controller rollback/ownership, scope/freshness and transitions PASS");return 0;
}
