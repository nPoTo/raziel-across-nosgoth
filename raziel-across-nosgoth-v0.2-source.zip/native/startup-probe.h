#include "report-path.h"
// Read-only observation of the earlier ground-motion decision, before setters.
#include "startup-code-proof.h"
typedef int32_t (__fastcall *SrApplyMotionFn)(uintptr_t,int32_t);
static SrApplyMotionFn originalStartup;static PVOID startupTarget;static bool startupAttempted;
static volatile LONG startupEnabled,startupLock;static unsigned startupHead,startupTail,startupRecords;static ULONGLONG startupBegin;
typedef struct {ULONGLONG tick,source;uintptr_t player,state,caller,key;int32_t section,result,time,adjustment,velocity;int16_t position[3];uint16_t active,disabled;float target;bool ready;} StartupEvent;
static StartupEvent startupQueue[512];
static int32_t startupObserve(uintptr_t state,int32_t section,uintptr_t caller){
    StartupEvent e={0};uintptr_t player=0,instance=0;float root[16];
    uintptr_t module=(uintptr_t)InterlockedCompareExchangePointer(&verifiedSr1Module,NULL,NULL);
    bool valid=InterlockedCompareExchange(&startupEnabled,0,0)&&section==0&&module&&
      (caller==module+0xf36ba||caller==module+0xf3a15||caller==module+0xf3e75)&&worldRoot(root,&player)&&worldRead(state,&instance,8)&&instance==player;
    if(valid){e.tick=GetTickCount64();e.player=player;e.state=state;e.caller=caller;e.section=section;
      valid=worldRead(player+0x9c,e.position,6)&&worldRead(player+0x370,&e.adjustment,4)&&worldRead(player+0x2d4,&e.velocity,4)&&worldRead(player+0x390,&e.key,8)&&worldRead(player+0x32a,&e.active,2)&&worldRead(player+0x32c,&e.disabled,2)&&worldRead(module+0x2a89628,&e.time,4);
      unsigned char packet[80];if(valid&&movementReadPacket(packet))e.ready=movementPacketTarget(packet,sizeof(packet),e.tick,overlayLivePid,overlayLiveTick,e.time,&e.target,&e.source);
    }
    int32_t result=originalStartup(state,section);e.result=result;
    if(!valid||!worldRead(state,&instance,8)||instance!=player)return result;
    if(!InterlockedCompareExchange(&startupLock,1,0)){
      if(!startupBegin)startupBegin=e.tick;unsigned next=(startupHead+1)%ARRAYSIZE(startupQueue);
      if(e.tick>=startupBegin&&e.tick-startupBegin<90000&&startupRecords<4000&&next!=startupTail){startupQueue[startupHead]=e;startupHead=next;++startupRecords;}
      InterlockedExchange(&startupLock,0);
    }
    return result;
}
static int32_t __fastcall observeStartup(uintptr_t state,int32_t section){return startupObserve(state,section,(uintptr_t)__builtin_return_address(0));}
static void startupFlush(void){
    StartupEvent local[512];unsigned n=0;if(InterlockedCompareExchange(&startupLock,1,0))return;
    while(startupTail!=startupHead){local[n++]=startupQueue[startupTail];startupTail=(startupTail+1)%ARRAYSIZE(startupQueue);}InterlockedExchange(&startupLock,0);
    for(unsigned i=0;i<n;i++){StartupEvent *e=&local[i];logLine("SR1_STARTUP tick=%llu player=%p state=%p caller=%p section=%d result=%d adjustment=%d time=%d velocityZ=%d position=%d,%d,%d key=%p active_head=%u disabled_head=%u donor_ready=%u targetY=%.9g sourceTick=%llu; read-only",
      e->tick,(void *)e->player,(void *)e->state,(void *)e->caller,e->section,e->result,e->adjustment,e->time,e->velocity,e->position[0],e->position[1],e->position[2],(void *)e->key,e->active,e->disabled,e->ready,e->target,e->source);}
}
static void startupInstall(HMODULE module){
    if(!module||startupAttempted)return;startupAttempted=true;unsigned char bytes[STARTUP_SIZE];char sha[65];PVOID target=(void *)((uintptr_t)module+STARTUP_RVA);
    if(!worldRead((uintptr_t)target,bytes,sizeof(bytes))||!hashBytes(bytes,sizeof(bytes),sha)||strcmp(sha,STARTUP_SHA)){logLine("SR1_STARTUP full-code gate failed");return;}
    MH_STATUS init=MH_Initialize();if(init!=MH_OK&&init!=MH_ERROR_ALREADY_INITIALIZED)return;
    MH_STATUS create=MH_CreateHook(target,(void *)&observeStartup,(void **)&originalStartup),enable=create==MH_OK?MH_EnableHook(target):create;
    if(enable==MH_OK)startupTarget=target;logLine("SR1_STARTUP create=%d enable=%d full-code proof=1; read-only",create,enable);
}
static void startupTick(void){
    bool requested=startupTarget&&GetFileAttributesW(PROBE_PATH(L"\\startup-sr1.enable"))!=INVALID_FILE_ATTRIBUTES;
    if(!requested)InterlockedExchange(&startupEnabled,0);
    else if(!InterlockedCompareExchange(&startupEnabled,0,0)&&!InterlockedCompareExchange(&startupLock,1,0)){startupBegin=0;startupRecords=0;InterlockedExchange(&startupEnabled,1);InterlockedExchange(&startupLock,0);}
    startupFlush();
}
static void startupStop(void){InterlockedExchange(&startupEnabled,0);if(startupTarget)MH_DisableHook(startupTarget);startupFlush();}
