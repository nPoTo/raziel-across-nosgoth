// SPDX-License-Identifier: GPL-3.0-or-later
#pragma once
#include <stdint.h>
#include <stdbool.h>
#include <string.h>
typedef struct {uintptr_t actor;uint64_t begin;bool waiting,completed;} RepeatJumpAdvance;
// Only a queued landing press can shorten ordinary landing and its immediately
// following compression. Native handlers still perform every exit/init/launch.
static inline bool repeatJumpAdvanceStep(RepeatJumpAdvance *s,uint64_t now,uintptr_t actor,bool scope,unsigned kind,bool pending,uint32_t mode,int clip,bool empty){
 if(!scope||!actor||(s->actor&&(s->actor!=actor||now<s->begin||now-s->begin>350))){memset(s,0,sizeof(*s));return false;}
 if(!empty)return false;
 if(kind==0){
  if(s->waiting||!pending||(mode!=0x1008&&mode!=0x1010)||(clip!=0x1d&&clip!=0x25))return false;
  *s=(RepeatJumpAdvance){.actor=actor,.begin=now,.waiting=true};return true;
 }
 if(kind==1&&s->waiting&&!s->completed&&(mode==8||mode==0x10)&&(clip==0x1a||clip==0x22)){
  s->completed=true;return true;
 }
 return false;
}
