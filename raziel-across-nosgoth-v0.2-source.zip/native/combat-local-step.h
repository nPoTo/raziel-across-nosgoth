// SPDX-License-Identifier: GPL-3.0-or-later
#pragma once
// Pure local projection. The donor root is evidence, never a host-facing write.
static bool combatLocalStep(const float root[16],const float current[3],const float anchor[2],double local[2]){
 for(unsigned i=0;i<16;i++)if(!isfinite(root[i]))return false;
 for(unsigned i=0;i<3;i++)for(unsigned j=i;j<3;j++){double dot=0;for(unsigned k=0;k<3;k++)dot+=(double)root[i*4+k]*root[j*4+k];if(fabs(dot-(i==j?1:0))>.03)return false;}
 double dx=(double)current[0]-anchor[0],dy=(double)current[1]-anchor[1];if(!isfinite(dx)||!isfinite(dy)||fabs(dx)>256||fabs(dy)>256)return false;
 // Project EACH native delta before accumulation; never rotate a world sum by a later heading.
 local[0]=dx*root[0]+dy*root[1];local[1]=-(dx*root[4]+dy*root[5]);return isfinite(local[0])&&isfinite(local[1]);
}
