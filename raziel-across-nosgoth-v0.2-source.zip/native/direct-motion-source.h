#include "report-path.h"
// Called after a successful native anchor update. The anchor consumed the
// observed displacement; accumulating it reconstructs travel without drift.
#include "direct-motion-shared.h"
static HANDLE directMotionMapping;static DirectMotionShared *directMotionView;
static DirectMotionSnapshot directMotionCurrent;static bool directMotionRequested;
static volatile LONG directMotionEnabled,directMotionLock;
static void directMotionSample(uintptr_t instance,const float current[3],const float anchor[2],uint64_t tick){
 if(!InterlockedCompareExchange(&directMotionEnabled,0,0)||!directMotionView||InterlockedCompareExchange(&directMotionLock,1,0))return;
 float root[16],factor=0;uintptr_t buffer=0;bool valid=donorProcessIdentity(instance)&&donorProcessMotion(instance,&factor,root,&buffer);
 if(valid){
  DirectMotionSnapshot *s=&directMotionCurrent;
  if(!s->epoch){memset(s,0,sizeof(*s));s->magic=0x31445a52;s->version=1;s->pid=GetCurrentProcessId();s->epoch=tick;s->instance=instance;s->baseZ=current[2];memcpy(s->moduleHash,directMotionHash,32);}
  valid=s->instance==instance&&tick>=s->tick&&tick>=s->epoch&&tick-s->epoch<180000;
  double delta[2]={(double)current[0]-anchor[0],(double)current[1]-anchor[1]};
  for(unsigned j=0;j<2;j++)if(!isfinite(delta[j])||fabs(delta[j])>256)valid=false;
  if(valid){s->tick=tick;s->z=current[2];for(unsigned j=0;j<2;j++)s->xy[j]+=delta[j];
   for(unsigned c=0;c<3;c++)for(unsigned r=0;r<3;r++)s->root[c*3+r]=root[c*4+r];++s->samples;
   valid=directMotionValid(s,s->pid,tick);if(valid)directMotionStore(directMotionView,s);
  }
 }
 if(!valid){InterlockedExchange(&directMotionEnabled,0);DirectMotionSnapshot empty={0};directMotionStore(directMotionView,&empty);}
 InterlockedExchange(&directMotionLock,0);
}
static void directMotionSourceTick(void){
 bool requested=GetFileAttributesW(PROBE_PATH(L"\\direct-motion-donor.enable"))!=INVALID_FILE_ATTRIBUTES&&GetFileAttributesW(PROBE_PATH(L"\\donor-anchor.enable"))!=INVALID_FILE_ATTRIBUTES;
 if(requested==directMotionRequested)return;directMotionRequested=requested;
 if(InterlockedCompareExchange(&directMotionLock,1,0)){directMotionRequested=!requested;return;}
 InterlockedExchange(&directMotionEnabled,0);memset(&directMotionCurrent,0,sizeof(directMotionCurrent));
 if(requested&&!directMotionView){wchar_t name[96];directMotionName(name,GetCurrentProcessId());SetLastError(0);
  directMotionMapping=CreateFileMappingW(INVALID_HANDLE_VALUE,NULL,PAGE_READWRITE,0,sizeof(DirectMotionShared),name);
  bool existing=GetLastError()==ERROR_ALREADY_EXISTS;
  if(directMotionMapping&&!existing)directMotionView=MapViewOfFile(directMotionMapping,FILE_MAP_WRITE|FILE_MAP_READ,0,0,sizeof(DirectMotionShared));
  if(!directMotionView&&directMotionMapping){CloseHandle(directMotionMapping);directMotionMapping=NULL;}
 }
 if(directMotionView){DirectMotionSnapshot empty={0};directMotionStore(directMotionView,&empty);}
 InterlockedExchange(&directMotionEnabled,requested&&directMotionView!=NULL);InterlockedExchange(&directMotionLock,0);
 logLine("DONOR_DIRECT_MOTION enabled=%u; cumulative world XY, actual Z/root; no factor normalization, bounded180s",requested&&directMotionView!=NULL);
}
static void directMotionSourceStop(void){
 InterlockedExchange(&directMotionEnabled,0);
 // Mapping and view retained until process exit for in-flight reader safety.
 if(directMotionView&&!InterlockedCompareExchange(&directMotionLock,1,0)){DirectMotionSnapshot empty={0};directMotionStore(directMotionView,&empty);InterlockedExchange(&directMotionLock,0);}
}
