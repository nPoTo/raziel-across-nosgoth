// SPDX-License-Identifier: GPL-3.0-or-later
#include <stdio.h>
#include "donor-animation-context-reader.h"
static const uintptr_t base=0x10000000,actor=0x20000000,state=0x30000000,context=0x40000000,map=0x50000000,descriptors=0x60000000,model=0x70000000;
static unsigned reads,actorReads;static int defect;
static bool fixture(void *c,uintptr_t address,void *out,SIZE_T n){(void)c;reads++;uintptr_t v=0;
 if(address==base+0xc5aa78&&n==8){v=actor;if(defect==1&&++actorReads>1)v+=8;}
 else if(address==actor+0x88&&n==8)v=defect==2?model+8:model;
 else if(address==actor+0x3f8&&n==8)v=state;
 else if(address==state&&n==8)v=defect==3?actor+8:actor;
 else if(address==actor+0x310&&n==8)v=context;
 else if(address==base+0x1140490&&n==8)v=defect==4?context+8:context;
 else if(address==context+0xd0&&n==8)v=map;
 else if(address==context+0x78&&n==8)v=descriptors;
 else{for(unsigned i=0;i<6;i++){if(address==map+(uintptr_t)sheet_donorAnimationContextKeys_rows[i]->key*2&&n==2){int16_t index=(int16_t)i;if(defect==5&&i==0)index=-1;if(defect==6&&i==0)index=4096;memcpy(out,&index,2);return true;}if(address==descriptors+i*16&&n==16){if(defect==7&&i==0)return false;memset(out,0,n);return true;}}
  for(unsigned i=0;i<3;i++){if(address==state+0x248+i*0x250&&n==4){uint32_t key=defect==8?999:(uint32_t)sheet_donorAnimationContextKeys_rows[i]->key;memcpy(out,&key,4);return true;}if(address==state+0x250+i*0x250&&n==8){v=descriptors+i*16;if(defect==9&&i==0)v+=16;memcpy(out,&v,8);return true;}}return false;
 }memcpy(out,&v,n);return true;
}
static DonorAnimationContextObservation observe(void){reads=actorReads=0;return donorAnimationContextRead(NULL,fixture,base,0x2000000,model);}
#define CHECK(c,n) do{if(!(c)){printf("FAIL %u\n",(unsigned)n);return n;}}while(0)
int main(void){DonorAnimationContextObservation r=observe();CHECK(r.valid&&reads>0&&r.availableMask==63&&r.supportedMask==7&&r.cachedMatchMask==7,1);
 for(defect=1;defect<=4;defect++)CHECK(!observe().valid,2+defect);defect=5;r=observe();CHECK(r.valid&&r.availableMask==62&&r.cachedMatchMask==6,7);defect=6;r=observe();CHECK(r.valid&&r.availableMask==62,8);defect=7;r=observe();CHECK(r.valid&&r.availableMask==62,9);defect=8;r=observe();CHECK(r.valid&&!r.supportedMask&&!r.cachedMatchMask,10);defect=9;r=observe();CHECK(r.valid&&r.cachedMatchMask==6,11);defect=0;
 defect=2;r=observe();CHECK(!r.valid&&!r.contextMatches&&!r.stateOwned&&reads==2,15);defect=0;
 CHECK(!donorAnimationContextRead(NULL,fixture,UINTPTR_MAX-4,0x2000000,model).valid,12);CHECK(!donorAnimationContextRead(NULL,fixture,base,0x1000000,model).valid,13);CHECK(!donorAnimationContextRead(NULL,fixture,base,0x2000000,0).valid,14);
 puts("PASS: production fresh actor/state/context/key/cached-descriptor relation; actor race/wrong model/owner/context, signed index sentinel/bound/read refusal, unsupported key and cache mismatch; pointers/content not serialized");return 0;}
