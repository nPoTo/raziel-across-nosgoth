// SPDX-License-Identifier: GPL-3.0-or-later
#pragma once
#include "host-contact-shared.h"
// Mapping remains pinned until process exit: game callbacks may race worker teardown.
typedef struct {HANDLE mapping;HostContactShared *view;volatile LONG lock;uint64_t creation,epoch;bool attempted;} HostContactSource;
static inline bool hostContactSourceOpen(HostContactSource *s,uint64_t epoch){
 if(s->attempted)return false;s->attempted=true;
 FILETIME c,e,k,u;if(!epoch||!GetProcessTimes(GetCurrentProcess(),&c,&e,&k,&u))return false;
 s->creation=((uint64_t)c.dwHighDateTime<<32)|c.dwLowDateTime;s->epoch=epoch;
 wchar_t name[96];hostContactMappingName(name,GetCurrentProcessId());SetLastError(0);
 s->mapping=CreateFileMappingW(INVALID_HANDLE_VALUE,NULL,PAGE_READWRITE,0,sizeof(HostContactShared),name);
 bool exists=GetLastError()==ERROR_ALREADY_EXISTS;
 if(!s->mapping)return false;
 if(exists){CloseHandle(s->mapping);s->mapping=NULL;return false;}
 s->view=MapViewOfFile(s->mapping,FILE_MAP_READ|FILE_MAP_WRITE,0,0,sizeof(HostContactShared));
 if(!s->view){CloseHandle(s->mapping);s->mapping=NULL;return false;}
 return true;
}
static inline void hostContactSourcePublish(HostContactSource *s,HostContactSnapshot value){
 if(!s->view||InterlockedCompareExchange(&s->lock,1,0))return;
 if(!s->view->revoked){
  value.magic=HOST_CONTACT_MAGIC;value.version=HOST_CONTACT_VERSION;value.pid=GetCurrentProcessId();value.creation=s->creation;value.epoch=s->epoch;
  hostContactStore(s->view,&value);
 }
 InterlockedExchange(&s->lock,0);
}
static inline void hostContactSourceStop(HostContactSource *s){if(s->view)InterlockedExchange(&s->view->revoked,1);}
