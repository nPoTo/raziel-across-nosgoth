// SPDX-License-Identifier: GPL-3.0-or-later
// RZB2 bytes are explicitly little-endian. These structs are local decoded data,
// never a wire layout. The legacy RAM renderer remains active until migration.
#ifndef BRIDGE_PROTOCOL_H
#define BRIDGE_PROTOCOL_H
#include <stdint.h>
#include <stdbool.h>
#include <string.h>
#include "exploration-sheets.h"
#define BRIDGE_HEADER_BYTES 152u
#define BRIDGE_VERSION 2u
#define BRIDGE_MAGIC 0x32425a52u
enum {BRIDGE_HELLO=1,BRIDGE_GEOMETRY=2,BRIDGE_APPEARANCE=3,BRIDGE_POSE=4,BRIDGE_MOVEMENT=5,BRIDGE_STREAMS=6};
enum {BRIDGE_VISUAL=1,BRIDGE_GROUND=2,BRIDGE_AIR_HINT=4,BRIDGE_COVER=8};
typedef struct {
 uint32_t sourcePid,hostPid,actorId,actorGeneration,capabilities;
 uint64_t sourceCreation,hostCreation,sessionGeneration,levelGeneration;
 unsigned char sourceBuild[32],hostBuild[32];
} BridgeIdentity;
typedef struct {BridgeIdentity identity;uint16_t type;uint32_t payloadBytes;uint64_t sequence,tick;} BridgeHeader;
typedef struct {BridgeIdentity identity;uint64_t sequence[BRIDGE_STREAMS];} BridgeLedger;
static inline uint16_t bridgeU16(const unsigned char *b){return (uint16_t)b[0]|(uint16_t)b[1]<<8;}
static inline uint32_t bridgeU32(const unsigned char *b){uint32_t n=0;for(unsigned i=0;i<4;i++)n|=(uint32_t)b[i]<<(8*i);return n;}
static inline uint64_t bridgeU64(const unsigned char *b){uint64_t n=0;for(unsigned i=0;i<8;i++)n|=(uint64_t)b[i]<<(8*i);return n;}
static inline bool bridgeHex(const wchar_t *s,unsigned char out[32]){
 if(!s||wcslen(s)!=64)return false;
 for(unsigned i=0;i<32;i++){unsigned n=0;for(unsigned j=0;j<2;j++){wchar_t c=s[i*2+j];int v=c>=L'0'&&c<=L'9'?c-L'0':c>=L'a'&&c<=L'f'?c-L'a'+10:c>=L'A'&&c<=L'F'?c-L'A'+10:-1;if(v<0)return false;n=n*16+(unsigned)v;}out[i]=(unsigned char)n;}return true;
}
static inline bool bridgePolicyValid(void){return sheet_bridgeProtocol_session_v2.version==BRIDGE_VERSION&&sheet_bridgeProtocol_session_v2.headerBytes==BRIDGE_HEADER_BYTES&&sheet_bridgeProtocol_session_v2.maxPayloadBytes>0&&sheet_bridgeProtocol_session_v2.maxPayloadBytes<=UINT32_MAX&&sheet_bridgeProtocol_session_v2.maxAgeMs>0&&sheet_bridgeProtocol_session_v2.capabilityMask==15;}
static inline bool bridgeNegotiate(uint32_t local,uint32_t peer,uint32_t *accepted){
 if(!accepted||!bridgePolicyValid()||((local|peer)&~(uint32_t)sheet_bridgeProtocol_session_v2.capabilityMask))return false;
 *accepted=local&peer;return true;
}
static inline bool bridgeIdentityValid(const BridgeIdentity *i){
 unsigned char source[32],host[32];
 return i&&i->sourcePid&&i->hostPid&&i->sourcePid!=i->hostPid&&i->sourceCreation&&i->hostCreation&&i->sessionGeneration&&i->levelGeneration&&i->actorId&&i->actorGeneration&&!(i->capabilities&~15u)&&bridgeHex(sheet_bridgeProtocol_session_v2.sourceBuild,source)&&bridgeHex(sheet_bridgeProtocol_session_v2.hostBuild,host)&&!memcmp(i->sourceBuild,source,32)&&!memcmp(i->hostBuild,host,32);
}
static inline bool bridgeSameIdentity(const BridgeIdentity *a,const BridgeIdentity *b){
 return a->sourcePid==b->sourcePid&&a->hostPid==b->hostPid&&a->sourceCreation==b->sourceCreation&&a->hostCreation==b->hostCreation&&a->sessionGeneration==b->sessionGeneration&&a->levelGeneration==b->levelGeneration&&a->actorId==b->actorId&&a->actorGeneration==b->actorGeneration&&a->capabilities==b->capabilities&&!memcmp(a->sourceBuild,b->sourceBuild,32)&&!memcmp(a->hostBuild,b->hostBuild,32);
}
static inline bool bridgeDecode(const unsigned char *b,size_t headerBytes,uint64_t totalBytes,uint64_t now,const BridgeIdentity *expected,BridgeHeader *out){
 if(!b||!out||headerBytes!=BRIDGE_HEADER_BYTES||totalBytes<BRIDGE_HEADER_BYTES||!bridgePolicyValid()||!bridgeIdentityValid(expected))return false;
 if(bridgeU32(b)!=BRIDGE_MAGIC||bridgeU16(b+4)!=BRIDGE_VERSION||bridgeU32(b+8)!=BRIDGE_HEADER_BYTES||bridgeU32(b+84))return false;
 BridgeHeader h={0};h.type=bridgeU16(b+6);h.payloadBytes=bridgeU32(b+12);
 if(h.type<BRIDGE_HELLO||h.type>=BRIDGE_STREAMS||h.payloadBytes>(uint64_t)sheet_bridgeProtocol_session_v2.maxPayloadBytes||totalBytes!=(uint64_t)BRIDGE_HEADER_BYTES+h.payloadBytes||(h.type==BRIDGE_HELLO&&h.payloadBytes)||(h.type!=BRIDGE_HELLO&&!h.payloadBytes)||(h.type==BRIDGE_MOVEMENT&&h.payloadBytes!=80))return false;
 BridgeIdentity *i=&h.identity;i->sourcePid=bridgeU32(b+16);i->hostPid=bridgeU32(b+20);i->sourceCreation=bridgeU64(b+24);i->hostCreation=bridgeU64(b+32);i->sessionGeneration=bridgeU64(b+40);i->levelGeneration=bridgeU64(b+48);i->actorId=bridgeU32(b+56);i->actorGeneration=bridgeU32(b+60);h.sequence=bridgeU64(b+64);h.tick=bridgeU64(b+72);i->capabilities=bridgeU32(b+80);memcpy(i->sourceBuild,b+88,32);memcpy(i->hostBuild,b+120,32);
 uint32_t needed=h.type==BRIDGE_HELLO?0:h.type==BRIDGE_MOVEMENT?BRIDGE_GROUND:BRIDGE_VISUAL;
 if(!bridgeIdentityValid(i)||!bridgeSameIdentity(i,expected)||!h.sequence||!h.tick||h.tick>now||now-h.tick>(uint64_t)sheet_bridgeProtocol_session_v2.maxAgeMs||(i->capabilities&needed)!=needed)return false;
 *out=h;return true;
}
static inline void bridgeLedgerBegin(BridgeLedger *ledger,const BridgeIdentity *identity){memset(ledger,0,sizeof(*ledger));ledger->identity=*identity;}
static inline void bridgePut(unsigned char *b,uint64_t value,unsigned bytes){for(unsigned i=0;i<bytes;i++)b[i]=(unsigned char)(value>>(i*8));}
static inline bool bridgeEncodeHeader(unsigned char *out,size_t bytes,const BridgeHeader *h){
 if(!out||!h||bytes!=BRIDGE_HEADER_BYTES)return false;
 unsigned char b[BRIDGE_HEADER_BYTES]={0};const BridgeIdentity *i=&h->identity;
 bridgePut(b,BRIDGE_MAGIC,4);bridgePut(b+4,BRIDGE_VERSION,2);bridgePut(b+6,h->type,2);bridgePut(b+8,BRIDGE_HEADER_BYTES,4);bridgePut(b+12,h->payloadBytes,4);bridgePut(b+16,i->sourcePid,4);bridgePut(b+20,i->hostPid,4);bridgePut(b+24,i->sourceCreation,8);bridgePut(b+32,i->hostCreation,8);bridgePut(b+40,i->sessionGeneration,8);bridgePut(b+48,i->levelGeneration,8);bridgePut(b+56,i->actorId,4);bridgePut(b+60,i->actorGeneration,4);bridgePut(b+64,h->sequence,8);bridgePut(b+72,h->tick,8);bridgePut(b+80,i->capabilities,4);memcpy(b+88,i->sourceBuild,32);memcpy(b+120,i->hostBuild,32);
 BridgeHeader check;if(!bridgeDecode(b,sizeof(b),(uint64_t)sizeof(b)+h->payloadBytes,h->tick,i,&check))return false;memcpy(out,b,sizeof(b));return true;
}
static inline bool bridgeAccept(BridgeLedger *ledger,const BridgeHeader *h){
 if(!ledger||!h||h->type<BRIDGE_HELLO||h->type>=BRIDGE_STREAMS||!bridgeSameIdentity(&ledger->identity,&h->identity)||h->sequence<=ledger->sequence[h->type])return false;
 ledger->sequence[h->type]=h->sequence;return true;
}
#endif
