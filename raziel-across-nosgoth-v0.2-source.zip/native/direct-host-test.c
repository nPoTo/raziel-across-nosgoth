#define main walkingHarnessMain
#include "instant-root-test.c"
#undef main
#include <xinput.h>
typedef DWORD (WINAPI *SrInputFn)(DWORD,XINPUT_STATE *);
static SrInputFn originalSrInput;static volatile LONG srCombatEnabled;
static uintptr_t srInputMainBase=0x40000000;
static bool (*srAuthorityInputScope)(ULONGLONG,uintptr_t,DWORD);
static void (*worldAuthorityModel)(float[16],uintptr_t);
#include "evade-root.h"
#include "direct-host.h"
static DirectMotionSnapshot snapshot;static bool sourceAvailable;
static bool mockSource(DirectMotionSnapshot *out){if(!sourceAvailable)return false;*out=snapshot;return directMotionValid(out,4242,GetTickCount64());}
static void setupDirect(void){
 rootOtherRelease=NULL;rootOtherAfter=NULL;reset();instantRootEnabled=0;evadeModule=instantRootModule;directHostRead=mockSource;sourceAvailable=true;
 uint64_t now=GetTickCount64();snapshot=(DirectMotionSnapshot){0};snapshot.magic=0x31445a52;snapshot.version=1;snapshot.pid=4242;snapshot.epoch=now-10;snapshot.tick=now;snapshot.instance=0x1234;snapshot.samples=1;snapshot.root[0]=snapshot.root[4]=snapshot.root[8]=1;memcpy(snapshot.moduleHash,directMotionHash,32);
 directHostBegin=worldLastDraw=overlayLiveTick=now;directHostEnabled=1;directHostBusy=0;directHostReadyTick=0;directHostFrames=0;directHostFailed=directHostHasSource=false;memset(&directHostCursor,0,sizeof(directHostCursor));directHostPlayer=0;directHostCos=1;directHostSin=0;
 directHostAlignmentPid=0;directHostAlignmentEpoch=directHostAlignmentInstance=0;directHostInstall();
}
static void frame(void){worldLastDraw=overlayLiveTick=GetTickCount64();snapshot.tick=GetTickCount64();rootMoving((uintptr_t)fixtureState,0,0);}
int main(void){
 setupDirect();frame();CHECK(directHostFrames==1&&directHostReadyTick&&switches==1&&evadeOwned);
 snapshot.xy[0]=30;snapshot.xy[1]=-15;snapshot.samples++;frame();CHECK(directHostFrames==2);
 RootController c;CHECK(rootControllerRead(evadeModule,fixturePlayer+0x448,1,&c)&&((float *)c.vector)[0]==30&&((float *)c.vector)[1]==-15);
 frame();CHECK(rootControllerRead(evadeModule,fixturePlayer+0x448,1,&c)&&((float *)c.vector)[0]==0&&((float *)c.vector)[1]==0); // Same snapshot cannot move twice.
 CHECK(directHostInputScope(GetTickCount64(),srInputMainBase+0x5bc9,GetCurrentProcessId()));CHECK(!directHostInputScope(GetTickCount64(),srInputMainBase+0x1234,GetCurrentProcessId()));CHECK(!directHostInputScope(GetTickCount64(),srInputMainBase+0x5bc9,0));
 snapshot.root[0]=snapshot.root[4]=0;snapshot.root[1]=1;snapshot.root[3]=-1;float model[16]={0};model[12]=11;model[13]=22;model[14]=-4828;directHostModel(model,fixturePlayer);CHECK(model[0]==0&&model[1]==1&&model[4]==-1&&model[12]==11&&model[14]==-4828);
 sourceAvailable=false;frame();CHECK(!directHostReadyTick&&!evadeOwned&&directHostInputScope(GetTickCount64(),srInputMainBase+0x5bc9,GetCurrentProcessId())); // Lost packet cannot leak map/stick/camera commands during authority.
 sourceAvailable=true;snapshot.samples++;frame();CHECK(fabsf(directHostCos-1)<.001f&&fabsf(directHostSin)<.001f); // Turned source after a gap must not rotate the world alignment.
 snapshot.xy[0]+=20;snapshot.samples++;frame();CHECK(rootControllerRead(evadeModule,fixturePlayer+0x448,1,&c)&&fabsf(((float *)c.vector)[0]-20)<.01f&&fabsf(((float *)c.vector)[1])<.01f);
 snapshot.epoch++;snapshot.samples++;frame();CHECK(fabsf(directHostCos)<.001f&&fabsf(directHostSin+1)<.001f); // A genuinely new source session establishes a new alignment.
 directHostEnabled=0;CHECK(!directHostInputScope(GetTickCount64(),srInputMainBase+0x5bc9,GetCurrentProcessId()));
 setupDirect();snapshot.root[0]=snapshot.root[4]=0;snapshot.root[1]=1;snapshot.root[3]=-1;frame();snapshot.xy[1]=30;snapshot.samples++;frame();CHECK(rootControllerRead(evadeModule,fixturePlayer+0x448,1,&c)&&fabsf(((float *)c.vector)[0]-30)<.01f&&fabsf(((float *)c.vector)[1])<.01f);
 setupDirect();frame();directHostEnabled=0;frame();CHECK(!evadeOwned);
 setupDirect();snapshot.z=100;frame();CHECK(!directHostReadyTick&&!sets); // Air application deliberately excluded in first pilot.
 setupDirect();wrongForeground=true;frame();CHECK(!sets);setupDirect();*(int32_t *)(fixtureActor+0x2d4)=10;frame();CHECK(!sets);
 setupDirect();frame();failSet=true;snapshot.xy[0]=30;snapshot.samples++;frame();CHECK(directHostFailed&&!directHostEnabled&&!evadeOwned);
 setupDirect();frame();snapshot.xy[0]=1000;snapshot.samples++;frame();CHECK(!directHostReadyTick&&!evadeOwned);
 setupDirect();directHostBegin=GetTickCount64()-139000;frame();CHECK(!sets);
 int16_t pos[3];memcpy(pos,fixtureActor+0x9c,6);CHECK(pos[0]==11&&pos[1]==22&&pos[2]==-4828);
 CHECK(srAuthorityInputScope==directHostInputScope&&worldAuthorityModel==directHostModel);
 directHostTick();directHostStop();evadeTick();evadeStop();evadeInstall(NULL);puts("Direct host pilot: cumulative XY once, world alignment/local conversion, render heading, fresh authority/caller/focus/air bounds, paired rollback and original position preservation PASS");return 0;
}
