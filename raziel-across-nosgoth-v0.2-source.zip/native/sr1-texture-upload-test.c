// SPDX-License-Identifier: GPL-3.0-or-later
// Exercise the actual preview texture loader in a hidden, owned GL context.
// Installed resource packet arrives on an anonymous pipe and is never saved.
#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <GL/gl.h>
#include <GL/glext.h>
#include <stdint.h>
#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <io.h>
#include <fcntl.h>
#include "render-memory.h"
#include "live-packet.h"
static unsigned char *input;
static bool renderMemoryCopy(unsigned kind,void *out,size_t n){if(kind!=1||n!=RM_APPEARANCE_BYTES)return false;memcpy(out,input,n);return true;}
static void logLine(const char *format,...){(void)format;}
static PFNGLGENBUFFERSPROC pglGenBuffers;static PFNGLBINDBUFFERPROC pglBindBuffer;static PFNGLBUFFERDATAPROC pglBufferData;static PFNGLENABLEVERTEXATTRIBARRAYPROC pglEnableVertexAttribArray;static PFNGLVERTEXATTRIBPOINTERPROC pglVertexAttribPointer;static PFNGLTEXIMAGE3DPROC pglTexImage3D;static PFNGLUNIFORM1IPROC pglUniform1i;static PFNGLGETUNIFORMLOCATIONPROC pglGetUniformLocation;static PFNGLBINDSAMPLERPROC overlayBindSampler;static GLuint overlayProgram;
#include "texture-overlay.h"
#define LOAD(type,var,name) do{PROC address=wglGetProcAddress(name);if(!address||(uintptr_t)address<=3||(uintptr_t)address==UINTPTR_MAX)return 5;var=(type)address;}while(0)
int main(void){
 if(GetFileType(GetStdHandle(STD_INPUT_HANDLE))!=FILE_TYPE_PIPE)return 1;_setmode(_fileno(stdin),_O_BINARY);input=malloc(RM_APPEARANCE_BYTES);if(!input||fread(input,1,RM_APPEARANCE_BYTES,stdin)!=RM_APPEARANCE_BYTES||fgetc(stdin)!=EOF)return 2;
 WNDCLASSW wc={0};wc.lpfnWndProc=DefWindowProcW;wc.hInstance=GetModuleHandleW(NULL);wc.lpszClassName=L"Sr1TextureUploadTest";if(!RegisterClassW(&wc))return 3;
 HWND w=CreateWindowW(wc.lpszClassName,L"Hidden original SR1 texture test",WS_POPUP,0,0,64,64,NULL,NULL,wc.hInstance,NULL);if(!w)return 3;HDC dc=GetDC(w);PIXELFORMATDESCRIPTOR fmt={0};fmt.nSize=sizeof(fmt);fmt.nVersion=1;fmt.dwFlags=PFD_DRAW_TO_WINDOW|PFD_SUPPORT_OPENGL|PFD_DOUBLEBUFFER;fmt.iPixelType=PFD_TYPE_RGBA;fmt.cColorBits=32;int pixel=ChoosePixelFormat(dc,&fmt);if(!pixel||!SetPixelFormat(dc,pixel,&fmt))return 4;HGLRC c=wglCreateContext(dc);if(!c||!wglMakeCurrent(dc,c))return 4;
 LOAD(PFNGLGENBUFFERSPROC,pglGenBuffers,"glGenBuffers");LOAD(PFNGLBINDBUFFERPROC,pglBindBuffer,"glBindBuffer");LOAD(PFNGLBUFFERDATAPROC,pglBufferData,"glBufferData");LOAD(PFNGLENABLEVERTEXATTRIBARRAYPROC,pglEnableVertexAttribArray,"glEnableVertexAttribArray");LOAD(PFNGLVERTEXATTRIBPOINTERPROC,pglVertexAttribPointer,"glVertexAttribPointer");LOAD(PFNGLTEXIMAGE3DPROC,pglTexImage3D,"glTexImage3D");LOAD(PFNGLUNIFORM1IPROC,pglUniform1i,"glUniform1i");LOAD(PFNGLGETUNIFORMLOCATIONPROC,pglGetUniformLocation,"glGetUniformLocation");
 PFNGLGENVERTEXARRAYSPROC gen;PFNGLBINDVERTEXARRAYPROC bind;LOAD(PFNGLGENVERTEXARRAYSPROC,gen,"glGenVertexArrays");LOAD(PFNGLBINDVERTEXARRAYPROC,bind,"glBindVertexArray");GLuint vao=0;gen(1,&vao);bind(vao);
 const GLenum states[]={GL_UNPACK_ALIGNMENT,GL_UNPACK_ROW_LENGTH,GL_UNPACK_IMAGE_HEIGHT,GL_UNPACK_SKIP_PIXELS,GL_UNPACK_SKIP_ROWS,GL_UNPACK_SKIP_IMAGES};const GLint sentinel[]={8,12,16,4,8,2};for(unsigned i=0;i<6;i++)glPixelStorei(states[i],sentinel[i]);
 overlayTextured=overlayLoadTextures(SR1_PROFILE_VERTICES);if(!overlayTextured||glGetError()!=GL_NO_ERROR)return 6;
 for(unsigned i=0;i<6;i++){GLint value=0;glGetIntegerv(states[i],&value);if(value!=sentinel[i])return 7;}
 GLint format=0,compressed=0,bytes=0;glGetTexLevelParameteriv(GL_TEXTURE_2D_ARRAY,0,GL_TEXTURE_INTERNAL_FORMAT,&format);glGetTexLevelParameteriv(GL_TEXTURE_2D_ARRAY,0,GL_TEXTURE_COMPRESSED,&compressed);glGetTexLevelParameteriv(GL_TEXTURE_2D_ARRAY,0,GL_TEXTURE_COMPRESSED_IMAGE_SIZE,&bytes);if(format!=GL_COMPRESSED_RGBA_BPTC_UNORM||!compressed||bytes!=12*512*512)return 8;
 (void)&overlayAppearance;(void)&pglTexImage3D;(void)&liveHeaderValid;(void)&livePoseFresh;free(input);wglMakeCurrent(NULL,NULL);wglDeleteContext(c);ReleaseDC(w,dc);DestroyWindow(w);puts("Installed12-layer BC7 upload through actual preview loader PASS; unpack sentinel restoration PASS; RAM only, no game involved");return 0;
}
