#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <stdint.h>
#include <stdbool.h>
#include <stdio.h>
#include <string.h>
#include <math.h>
#include "MinHook.h"
#define PROBE_REPORT_DIR L"."
#include "movement-packet.h"
static volatile LONG movementEnabled;static ULONGLONG worldLastDraw,overlayLiveTick;static uintptr_t worldLastInstance,fixturePlayer;
static uint32_t overlayLivePid=4242;static int32_t fixtureTime=4096;static float fixtureUp=1;
static bool fixtureInput=true,packetAvailable=true,stalePacket,wrongForeground,changeNativeProcess,failSwitch;
static unsigned char packetBytes[80];static unsigned originalCalls,switchCalls;static uintptr_t lastArgs[3],lastTarget;
static bool srGroundMovementInput(void){return fixtureInput;}
static DWORD foregroundFixture(HWND window,LPDWORD pid){(void)window;*pid=wrongForeground?0:GetCurrentProcessId();return 1;}
#define GetWindowThreadProcessId foregroundFixture
static bool worldRoot(float root[16],uintptr_t *player){memset(root,0,64);root[10]=fixtureUp;*player=fixturePlayer;return true;}
static bool worldRead(uintptr_t at,void *out,size_t size){if(at==0x10000000+0x2a89628&&size==4){memcpy(out,&fixtureTime,4);return true;}if(at<0x100000000)return false;memcpy(out,(void *)at,size);return true;}
static bool movementReadPacket(unsigned char out[80]){if(!packetAvailable)return false;memcpy(out,packetBytes,80);uint64_t tick=GetTickCount64()-(stalePacket?500:0);memcpy(out+16,&tick,8);return true;}
static bool hashBytes(const void *p,ULONG n,char *out){(void)p;(void)n;(void)out;return false;}
static void logLine(const char *fmt,...){(void)fmt;}
#include "instant-start.h"
static uintptr_t __fastcall mockStart(uintptr_t state,int32_t section,uintptr_t data){
 ++originalCalls;lastArgs[0]=state;lastArgs[1]=(uintptr_t)section;lastArgs[2]=data;
 if(changeNativeProcess){uintptr_t other=0x10000000+0x1234;memcpy((void *)(state+0x10),&other,8);}return 0xabcd;
}
static uintptr_t __fastcall mockSwitch(uintptr_t state,uintptr_t target,uintptr_t data){
 ++switchCalls;lastTarget=target;if(data)return 0;
 // Simulate old-handler exit calls during the native all-section transition.
 for(int section=0;section<3;section++)instantStartMove(state,section,0);
 if(!failSwitch)memcpy((void *)(state+0x10),&target,8);return 0xfedc;
}
#define CHECK(x) do{if(!(x)){printf("FAIL line %d\n",__LINE__);return 1;}}while(0)
static void resetProcess(unsigned char *state){uintptr_t process=0x10000000+0xf48e0;memcpy(state+0x10,&process,8);instantStartBegin=worldLastDraw=overlayLiveTick=GetTickCount64();}
int main(int argc,char **argv){
 CHECK(argc==2);FILE *in=fopen(argv[1],"rb");CHECK(in&&fread(packetBytes,80,1,in)==1);fclose(in);
 unsigned char actor[1400]={0},state[1024]={0},actorCopy[1400];fixturePlayer=(uintptr_t)actor;worldLastInstance=fixturePlayer;memcpy(state,&fixturePlayer,8);memcpy(actorCopy,actor,sizeof(actor));
 instantStartModule=0x10000000;originalStartMove=mockStart;instantCharacterSwitch=mockSwitch;resetProcess(state);
 CHECK(instantStartMove((uintptr_t)state,0,0x9876)==0xabcd&&originalCalls==1&&switchCalls==0&&lastArgs[2]==0x9876);
 instantStartEnabled=movementEnabled=1;
 CHECK(instantStartMove((uintptr_t)state,0,0x9876)==0xabcd&&switchCalls==1&&originalCalls==5&&lastTarget==instantStartModule+0xf3280&&!instantStartBusy);
 CHECK(!memcmp(actorCopy,actor,sizeof(actor)));unsigned before=switchCalls;
 resetProcess(state);fixtureInput=false;instantStartMove((uintptr_t)state,0,7);CHECK(switchCalls==before);fixtureInput=true;
 resetProcess(state);*(int32_t *)(actor+0x2d4)=1;instantStartMove((uintptr_t)state,0,7);CHECK(switchCalls==before);*(int32_t *)(actor+0x2d4)=0;
 resetProcess(state);packetAvailable=false;instantStartMove((uintptr_t)state,0,7);CHECK(switchCalls==before);packetAvailable=true;
 resetProcess(state);stalePacket=true;instantStartMove((uintptr_t)state,0,7);CHECK(switchCalls==before);stalePacket=false;
 resetProcess(state);packetBytes[48]^=1;instantStartMove((uintptr_t)state,0,7);CHECK(switchCalls==before);packetBytes[48]^=1;
 resetProcess(state);wrongForeground=true;instantStartMove((uintptr_t)state,0,7);CHECK(switchCalls==before);wrongForeground=false;
 resetProcess(state);fixtureUp=.5f;instantStartMove((uintptr_t)state,0,7);CHECK(switchCalls==before);fixtureUp=1;
 resetProcess(state);instantStartMove((uintptr_t)state,1,7);CHECK(switchCalls==before);
 resetProcess(state);fixtureTime=0;instantStartMove((uintptr_t)state,0,7);CHECK(switchCalls==before);fixtureTime=4096;
 resetProcess(state);changeNativeProcess=true;instantStartMove((uintptr_t)state,0,7);CHECK(switchCalls==before);changeNativeProcess=false;
 resetProcess(state);instantStartBegin=GetTickCount64()-75001;instantStartMove((uintptr_t)state,0,7);CHECK(switchCalls==before);
 resetProcess(state);float savedY,y=0;memcpy(&savedY,packetBytes+32,4);memcpy(packetBytes+32,&y,4);instantStartMove((uintptr_t)state,0,7);CHECK(switchCalls==before);memcpy(packetBytes+32,&savedY,4);
 resetProcess(state);uintptr_t wrong=fixturePlayer+4;memcpy(state,&wrong,8);instantStartMove((uintptr_t)state,0,7);CHECK(switchCalls==before);memcpy(state,&fixturePlayer,8);
 resetProcess(state);movementEnabled=0;instantStartMove((uintptr_t)state,0,7);CHECK(switchCalls==before);movementEnabled=1;
 resetProcess(state);failSwitch=true;instantStartMove((uintptr_t)state,0,7);CHECK(switchCalls==before+1&&!instantStartEnabled&&!instantStartBusy);failSwitch=false;
 instantStartStop();instantStartTick();instantStartInstall(NULL);CHECK(!memcmp(actorCopy,actor,sizeof(actor)));
 puts("Instant start: original entry/result, native all-section transition, recursion guard, missing/stale/invalid/idle/action/air/focus/actor/expiry fallback and failed-transition stop PASS");return 0;
}
