// Temporary host high jump: Y prepares LT crouch, then one A hold. Default off.
typedef struct {uint64_t lastTick,pressTick,pulseUntil;uintptr_t player;bool armed,held,fired;} SrJumpBridge;
static uint16_t srJumpButtons(SrJumpBridge *s,uint16_t raw,uint64_t now,uintptr_t player,bool eligible){
    const uint16_t a=0x1000,y=0x8000;
    if(!eligible||!player){memset(s,0,sizeof(*s));return raw;}
    if(s->player!=player||now<s->lastTick||(s->lastTick&&now-s->lastTick>250)){
        memset(s,0,sizeof(*s));s->player=player;
    }
    s->lastTick=now;
    if(!(raw&y)){s->armed=true;s->held=s->fired=false;s->pulseUntil=0;return raw;}
    uint16_t delivered=raw&~y;
    if(!s->armed)return delivered;
    if(!s->held){s->held=true;s->pressTick=now;}
    if(raw&a){s->fired=true;s->pulseUntil=0;return delivered;}
    if(!s->fired&&now-s->pressTick>=300){s->fired=true;s->pulseUntil=now+600;}
    if(s->pulseUntil&&now<s->pulseUntil)delivered|=a;
    return delivered;
}
static uint8_t srJumpLeftTrigger(const SrJumpBridge *s,uint8_t raw,uint64_t now,bool eligible){
    // Recorded crouch+A uses LT=255 before takeoff; release crouch after 80ms of A.
    if(eligible&&s->armed&&s->held&&(!s->fired||(s->pulseUntil&&now<s->pulseUntil-520)))return 255;
    return raw;
}
