// SPDX-License-Identifier: GPL-3.0-or-later
#pragma once
#include "sr1-free-attack-owner.h"
// Source and destination masks are generated from the reviewed sheet. Build
// destinations separately: RB->B and B->Y must never cascade within a poll.
typedef struct {uint16_t source,target;} DefianceHostRoute;
static inline uint16_t defianceHostControls(SrFreeAttackOwner owners[16],const DefianceHostRoute *routes,unsigned count,uint64_t tick,uint64_t identity,bool alive,bool eligible,bool menu,uint16_t physical,uint16_t delivered){
 uint16_t consumed=0,destinations=0;
 for(unsigned i=0;i<count&&i<16;i++){
  uint16_t source=routes[i].source;
  if(source==0x10||source==0x20||source==0x1000||source==0x4000)continue;
  uint16_t filtered=srFreeAttackStep(&owners[i],tick,identity,alive&&!menu,eligible&&!menu,physical,physical,source);
  if((physical&source)&&!(filtered&source)){consumed|=source;destinations|=routes[i].target;}
 }
 return (uint16_t)((delivered&~consumed)|destinations);
}
