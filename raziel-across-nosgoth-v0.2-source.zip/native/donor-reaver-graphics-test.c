// SPDX-License-Identifier: GPL-3.0-or-later
#define main reaverReaderBaseTests
#include "donor-reaver-reader-test.c"
#undef main
#include "donor-reaver-graphics.h"
static void u32(uintptr_t at,uint32_t v){memcpy(memory+at,&v,4);}
static void u16(uintptr_t at,uint16_t v){memcpy(memory+at,&v,2);}
static unsigned palmReads,poseReads,handReads,colorModeReads,realmReads,scrollReads,textureFlagReads;static bool tearPalm,tear,tearHand,tearColorMode,tearRealm,tearScroll,tearTexture;
static bool graphicsFake(void *c,uintptr_t at,void *out,SIZE_T n){
 if(!readFake(c,at,out,n))return false;
 if(tearPalm&&at==0x114000+40*64+48&&++palmReads==2)((float *)out)[0]+=1;
 if(tear&&at==0x10e000&&++poseReads==2)((float *)out)[12]+=1;
 if(tearHand&&at==0x114c80&&++handReads==2)((float *)out)[12]+=1;
 if(tearColorMode&&at==0x105401&&++colorModeReads==2)*(unsigned char *)out=1;
 if(tearRealm&&at==0x100000+0xc5aa50&&++realmReads==2)*(float *)out=.5f;
 if(tearScroll&&at==0x10f00c&&++scrollReads==2)*(float *)out=.75f;
 if(tearTexture&&at==0x100000+0x128a478+5*256&&++textureFlagReads==2)*(unsigned char *)out=0;
 return true;
}
int main(void){
 CHECK(reaverReaderBaseTests()==0);
 const uintptr_t base=0x100000;ptr(0x33f8,base+0x5000);
 float realm=1;memcpy(memory+0xc5aa50,&realm,4);
 u32(0x9254,50);u16(0x50c0,50);ptr(0x1060,base+0x14000);
 float hand[16]={1,0,0,0,0,1,0,0,0,0,1,0,3,4,5,1};memcpy(memory+0x14c80,hand,64);
 float finger[3]={0,0,10},thumb[3]={10,0,0};memcpy(memory+0x14000+41*64+48,finger,12);memcpy(memory+0x14000+47*64+48,thumb,12);
 ptr(0x51c0,base+0xb000);ptr(0x5060,base+0xe000);
 u16(0x6020,2);ptr(0x6028,base+0x11000);ptr(0x11000,base+0xb000);ptr(0x11008,base+0x13000);
 u32(0x6000,0x0500103d);u32(0x541c,4);u32(0x5420,32);
 u32(0xb000,0x04c2042f);u32(0xb004,10);u32(0xb028,1046);ptr(0xb0a0,base+0xc000);
 for(unsigned i=0;i<10;i++){float m[16]={0};m[0]=m[5]=m[10]=m[15]=1;memcpy(memory+0xe000+i*64,m,64);}
 ptr(0xb090,base+0xf000);u16(0xf000,318);u16(0xf002,2);u32(0xf004,5);ptr(0xf010,base+0x10000);
 ptr(0x6080,base+0x12000);u16(0x12000,670);u16(0x12002,5);
 float scroll=.25f;memcpy(memory+0xf00c,&scroll,4);memory[0x128a478+5*256]=16;
 ReaverGraphics out={0};CHECK(reaverGraphicsRead(NULL,graphicsFake,base,sizeof(memory),base+0x2000,&out));
 CHECK(out.vertices==1046&&out.bones==10&&out.batchCount==1&&out.batch[0].textureId==670);
 CHECK(out.indexCount==318&&out.hand[12]==3);
 CHECK(out.palm[5]==10&&out.palm[6]==10);
 CHECK(out.realmBlend==1&&out.partMode==0);
 CHECK(out.batch[0].scroll==.25f&&out.batch[0].textureFlags==16);
 CHECK(out.objectFlags==0x0500103d&&out.partMask2==4&&out.partMask3==32&&out.colorMode==0);
 tearPalm=true;CHECK(!reaverGraphicsRead(NULL,graphicsFake,base,sizeof(memory),base+0x2000,&out));CHECK(out.failureStage==8);tearPalm=false;
 tearScroll=true;CHECK(!reaverGraphicsRead(NULL,graphicsFake,base,sizeof(memory),base+0x2000,&out));CHECK(out.failureStage==8);tearScroll=false;
 tearTexture=true;CHECK(!reaverGraphicsRead(NULL,graphicsFake,base,sizeof(memory),base+0x2000,&out));CHECK(out.failureStage==8);tearTexture=false;
 tearRealm=true;CHECK(!reaverGraphicsRead(NULL,graphicsFake,base,sizeof(memory),base+0x2000,&out));CHECK(out.failureStage==8);tearRealm=false;
 tearColorMode=true;CHECK(!reaverGraphicsRead(NULL,graphicsFake,base,sizeof(memory),base+0x2000,&out));CHECK(out.failureStage==8);tearColorMode=false;
 tearHand=true;CHECK(!reaverGraphicsRead(NULL,graphicsFake,base,sizeof(memory),base+0x2000,&out));CHECK(out.failureStage==8);tearHand=false;
 u16(0xf018,1046);CHECK(!reaverGraphicsRead(NULL,graphicsFake,base,sizeof(memory),base+0x2000,&out));u16(0xf018,0);
 u16(0xf000,8193);CHECK(!reaverGraphicsRead(NULL,graphicsFake,base,sizeof(memory),base+0x2000,&out));u16(0xf000,318);
 tear=true;CHECK(!reaverGraphicsRead(NULL,graphicsFake,base,sizeof(memory),base+0x2000,&out));tear=false;
 ptr(0xf010,base+0xf000);CHECK(!reaverGraphicsRead(NULL,graphicsFake,base,sizeof(memory),base+0x2000,&out));ptr(0xf010,base+0x10000);
 u32(0xf004,6);CHECK(!reaverGraphicsRead(NULL,graphicsFake,base,sizeof(memory),base+0x2000,&out));u32(0xf004,5);
 u16(0x12004,671);u16(0x12006,5);CHECK(!reaverGraphicsRead(NULL,graphicsFake,base,sizeof(memory),base+0x2000,&out));u16(0x12004,0);
 u32(0xb028,1000000);CHECK(!reaverGraphicsRead(NULL,graphicsFake,base,sizeof(memory),base+0x2000,&out));u32(0xb028,1046);
 float invalid=NAN;memcpy(memory+0xe000,&invalid,4);CHECK(!reaverGraphicsRead(NULL,graphicsFake,base,sizeof(memory),base+0x2000,&out));
 puts("PASS bounded Reaver graphics: complete snapshot, torn matrices, cycles, texture ambiguity, oversized/nonfinite rejection. No live proof.");return 0;
}
