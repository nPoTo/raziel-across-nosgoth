// Exact supported callback; caller loop ABI verified at7c7c4.
#define DONOR_PROCESS_RVA 0x157170
#define DONOR_PROCESS_SIZE 33
#define DONOR_PROCESS_SHA "a9d2a52bfb1106103aeca2eb49562669e1a0a1a097e9abd2a3e6f34c54f7dadc"
