// SPDX-License-Identifier: GPL-3.0-or-later
#define wmain legacyTelemetryEntryUnused
#include "raziel-telemetry.c"
#undef wmain
#include "donor-animation-context-reader.h"
int wmain(int argc,wchar_t **argv){
 unsigned long pid=0;if(argc!=2||!number(argv[1],0xffffffffUL,&pid))return 1;HANDLE p=OpenProcess(PROCESS_VM_READ|PROCESS_QUERY_LIMITED_INFORMATION,FALSE,pid);if(!p)return 2;
 wchar_t exe[32768],expected[32768];DWORD length=ARRAYSIZE(exe),n=GetEnvironmentVariableW(L"RAZIEL_DEFIANCE_EXE",expected,ARRAYSIZE(expected));char digest[65];if(!n||n>=ARRAYSIZE(expected)||!QueryFullProcessImageNameW(p,0,exe,&length)||_wcsicmp(exe,expected)||!hashFile(exe,digest)||strcmp(digest,supportedHash)){CloseHandle(p);return 3;}
 HANDLE modules=CreateToolhelp32Snapshot(TH32CS_SNAPMODULE,pid);MODULEENTRY32W m={0};m.dwSize=sizeof(m);uintptr_t base=0;DWORD imageSize=0;if(modules!=INVALID_HANDLE_VALUE){if(Module32FirstW(modules,&m))do{if(!_wcsicmp(m.szExePath,exe)){base=(uintptr_t)m.modBaseAddr;imageSize=m.modBaseSize;break;}}while(Module32NextW(modules,&m));CloseHandle(modules);}
 FILETIME created,exited,kernel,user;if(!base||imageSize<0x1140498||!GetProcessTimes(p,&created,&exited,&kernel,&user)){CloseHandle(p);return 4;}
 printf("{\"type\":\"session\",\"pid\":%lu,\"sha256\":\"%s\",\"processCreation\":\"%llu\",\"mode\":\"read-only-animation-context\"}\n",pid,digest,(unsigned long long)(((uint64_t)created.dwHighDateTime<<32)|created.dwLowDateTime));
 for(unsigned i=0;i<(unsigned)sheet_donorAnimationContextProbe_current.samples;i++){
  uintptr_t registry=findContext(p,base),model=0,again=0;if(registry&&!razielModel(p,registry,&model))model=0;DonorAnimationContextObservation r=donorAnimationContextRead(p,donorStateRead,base,imageSize,model);if(registry&&(!razielModel(p,registry,&again)||again!=model))r=(DonorAnimationContextObservation){0};
  printf("{\"type\":\"sample\",\"sequence\":%u,\"valid\":%s,\"registryAvailable\":%s,\"actorMatchesRaziel\":%s,\"stateOwned\":%s,\"contextMatches\":%s,\"availableMask\":%u,\"supportedMask\":%u,\"cachedMatchMask\":%u,\"selectionKeys\":[%u,%u,%u]}\n",i,r.valid?"true":"false",r.registryAvailable?"true":"false",r.actorMatchesRaziel?"true":"false",r.stateOwned?"true":"false",r.contextMatches?"true":"false",r.availableMask,r.supportedMask,r.cachedMatchMask,r.selectionKeys[0],r.selectionKeys[1],r.selectionKeys[2]);fflush(stdout);if(i+1<(unsigned)sheet_donorAnimationContextProbe_current.samples)Sleep((DWORD)sheet_donorAnimationContextProbe_current.intervalMs);
 }CloseHandle(p);return 0;
}
