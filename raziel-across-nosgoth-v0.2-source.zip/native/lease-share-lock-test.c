// SPDX-License-Identifier: GPL-3.0-or-later
// Synthetic scalar fixture lock, never targets a game or native runtime lease.
#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <stdio.h>
#include <stdlib.h>
#include <wchar.h>
int wmain(int argc,wchar_t **argv){
 if(argc!=3)return 1;
 wchar_t *end;unsigned long ms=wcstoul(argv[2],&end,10);if(!ms||*end||ms>2000)return 1;
 HANDLE file=CreateFileW(argv[1],GENERIC_READ,FILE_SHARE_READ|FILE_SHARE_WRITE,NULL,OPEN_EXISTING,0,NULL);if(file==INVALID_HANDLE_VALUE)return 2;
 puts("locked");fflush(stdout);Sleep((DWORD)ms);CloseHandle(file);return 0;
}
