#include "general-test-budget.h"
// SPDX-License-Identifier: GPL-3.0-or-later
#pragma once
#include "reaver-texture-memory.h"
#include "reaver-texture-upload.h"
#include "reaver-presentation-draw.h"
static _Thread_local ReaverPresentationLease reaverRenderLease;
static _Thread_local ReaverTextureGeneration reaverRenderTextures;
static _Thread_local unsigned char reaverRenderScratch[REAVER_PRESENTATION_CAPACITY];
static _Thread_local bool reaverRenderBusy;
static _Thread_local uint64_t reaverRenderStart,reaverRenderFrame;
static _Thread_local unsigned reaverRenderDraws,reaverRenderRefusals;
static _Thread_local bool reaverScenePending;
static _Thread_local float reaverSceneMvp[16];
static _Thread_local HGLRC reaverSceneContext;
static _Thread_local uint64_t reaverSceneActor,reaverSceneModel,reaverSceneFrame;
static bool reaverRenderSession(ReaverPacketSession *s){
 unsigned char descriptor[88];FILE *f=_wfopen(PROBE_PATH(L"\\reaver-presentation-sr1.enable"),L"rb");if(!f)return false;
 bool ok=fread(descriptor,1,sizeof(descriptor),f)==sizeof(descriptor)&&fgetc(f)==EOF;fclose(f);
 _Static_assert(sizeof(ReaverPacketSession)==72,"session descriptor layout");
 if(!ok||reaverPacketU32(descriptor)!=0x31535752||reaverPacketU32(descriptor+4)!=1||reaverPacketU32(descriptor+8)!=88||reaverPacketU32(descriptor+12)!=GetCurrentProcessId())return false;
 memcpy(s,descriptor+16,sizeof(*s));return s->hostPid==GetCurrentProcessId()&&s->hostCreation==hostDrawCreation;
}
static void reaverRenderClear(void){
 reaverScenePending=false;
 reaverPresentationClear(&reaverRenderLease);
 if(!reaverRenderTextures.gl.context||reaverTexturesDestroy(&reaverRenderTextures)){memset(&reaverRenderLease,0,sizeof(reaverRenderLease));reaverRenderStart=0;reaverRenderFrame=0;}
}
// Runs AFTER original body draw. Owned blade draw reentry immediately returns.
static void reaverHostPresentation(GLenum mode,GLsizei count,GLenum type,const void *indices){
 if(reaverRenderBusy)return;
 ReaverPacketSession session={0};if(!reaverRenderSession(&session)){reaverRenderClear();return;}
 if(mode!=GL_TRIANGLES||count!=102720||type!=GL_UNSIGNED_SHORT)return;
 uint64_t now=GetTickCount64(),frame=(uint64_t)InterlockedCompareExchange64(&swapCalls,0,0)+1;
 if(reaverRenderStart&&now-reaverRenderStart>GENERAL_OR_SHORT_MS(sheet_reaverPresentationPacket_weapon_frame_v1.maxLifetimeMs)){reaverPresentationClear(&reaverRenderLease);return;}
 if(reaverRenderFrame==frame)return;
 HGLRC context=wglGetCurrentContext();GLint fbo=0,ebo=0,program=0;glGetIntegerv(GL_DRAW_FRAMEBUFFER_BINDING,&fbo);if(fbo||!reaverHostGpuCameraInit(context))return;
 glGetIntegerv(GL_ELEMENT_ARRAY_BUFFER_BINDING,&ebo);if(!drawIdentity(mode,count,type,indices,ebo))return;
 glGetIntegerv(GL_CURRENT_PROGRAM,&program);
 HostRig current={0};uintptr_t base=(uintptr_t)GetModuleHandleW(L"sr1.dll");
 if(!base||!rigIdentitySnapshot(NULL,sr1SkeletonRead,base,&current)||!reaverHostHand.valid||!reaverHostPalette.valid||reaverHostHand.draw!=reaverHostPalette.hand.draw||
 !reaverGpuPaletteMatches(&reaverHostPalette,context,(GLuint)program,current.actor,current.model,hostDrawCreation,frame))return;
 float mvp[16];if(!reaverHostPalm.valid||reaverHostPalm.draw!=reaverHostPalette.hand.draw||!reaverHostCameraMvp(mvp,&reaverHostPalm,reaverHostContext,current.actor,current.model,hostDrawCreation,frame,(GLuint)program,true))return;
 if(reaverRenderLease.session.hostPid&&memcmp(&session,&reaverRenderLease.session,sizeof(session))){reaverRenderClear();if(reaverRenderTextures.gl.context)return;}
 reaverRenderLease.session=session;if(!reaverRenderStart)reaverRenderStart=now;
 if(!reaverPresentationRead(&reaverRenderLease,reaverRenderScratch,now))return;
 reaverRenderBusy=true;
 if(!reaverRenderTextures.generation){size_t size=0;unsigned char *pixels=reaverTextureMemoryCopy(&session,&size);
  bool loaded=pixels&&reaverTexturePacketUpload(&reaverRenderTextures,pixels,size,&session);free(pixels);if(!loaded){reaverRenderBusy=false;reaverRenderRefusals++;return;}
 }
 // Stage during the visible preparation, while the packet is hidden. The
 // first requested strike must not pay the entire texture upload cost.
 if(!reaverPresentationCurrent(&reaverRenderLease,GetTickCount64())){reaverRenderBusy=false;return;}
 // Scene depth is incomplete here. Preserve this frame's admitted transform;
 // do not let later opaque draws overwrite a translucent weapon drawn early.
 memcpy(reaverSceneMvp,mvp,sizeof(mvp));reaverSceneContext=context;
 reaverSceneActor=current.actor;reaverSceneModel=current.model;reaverSceneFrame=frame;
 reaverScenePending=true;reaverRenderBusy=false;reaverRenderFrame=frame;
}
static void reaverHostPresentationFlush(HDC dc){
 if(!reaverScenePending||reaverRenderBusy)return;
 reaverScenePending=false;
 uint64_t frame=(uint64_t)InterlockedCompareExchange64(&swapCalls,0,0)+1;
 if(InterlockedCompareExchange(&probeBoundedComplete,0,0)||frame!=reaverSceneFrame||
 wglGetCurrentDC()!=dc||wglGetCurrentContext()!=reaverSceneContext)return;
 GLint fbo=0;glGetIntegerv(GL_DRAW_FRAMEBUFFER_BINDING,&fbo);if(fbo)return;
 ReaverPacketSession session={0};HostRig current={0};uintptr_t base=(uintptr_t)GetModuleHandleW(L"sr1.dll");
 if(!reaverRenderSession(&session)||memcmp(&session,&reaverRenderLease.session,sizeof(session))||
 !base||!rigIdentitySnapshot(NULL,sr1SkeletonRead,base,&current)||
 current.actor!=reaverSceneActor||current.model!=reaverSceneModel||
 !reaverPresentationCurrent(&reaverRenderLease,GetTickCount64()))return;
 reaverRenderBusy=true;
 bool drawn=reaverPresentationDraw(&reaverRenderLease,&reaverRenderTextures,GetTickCount64(),reaverSceneMvp);
 reaverRenderBusy=false;
 if(drawn){reaverRenderDraws++;if(reaverRenderDraws==1||reaverRenderDraws%120==0)logLine("REAVER_PRESENTATION draws=%u frame=%llu generation=%llu hand=49 original_body=1",reaverRenderDraws,(unsigned long long)frame,(unsigned long long)session.textureGeneration);}
 else reaverRenderRefusals++;
}
