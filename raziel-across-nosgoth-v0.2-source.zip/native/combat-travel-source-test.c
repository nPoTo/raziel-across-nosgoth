// SPDX-License-Identifier: GPL-3.0-or-later
#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <stdint.h>
#include <stdbool.h>
#include <stdio.h>
#include <string.h>
#include <math.h>
#include "exploration-sheets.h"
#define PROBE_PATH(x) x
static unsigned char actorBytes[0x500],stateBytes[0x600];
static uintptr_t donorProcessBase=0x140000000;
static volatile LONG donorAnchorEnabled,probeBoundedComplete;
static float basis[16];
static bool donorProcessIdentity(uintptr_t actor){return actor==(uintptr_t)actorBytes;}
static bool worldRead(uintptr_t p,void *out,SIZE_T n){if((p>=(uintptr_t)actorBytes&&p+n<=(uintptr_t)actorBytes+sizeof(actorBytes))||(p>=(uintptr_t)stateBytes&&p+n<=(uintptr_t)stateBytes+sizeof(stateBytes))){memcpy(out,(void *)p,n);return true;}return false;}
static bool donorProcessMotion(uintptr_t a,float *f,float r[16],uintptr_t *b){(void)a;*f=1;*b=1;memcpy(r,basis,sizeof(basis));return true;}
static void directMotionSample(uintptr_t a,const float c[3],const float b[2],uint64_t t){(void)a;(void)c;(void)b;(void)t;}
#include "combat-travel-source.h"
#define CHECK(x) do{if(!(x)){printf("FAIL line%d\n",__LINE__);return 1;}}while(0)
int main(void){
 CombatTravelShared shared={0};combatTravelView=&shared;combatTravelEnabled=1;uintptr_t state=(uintptr_t)stateBytes;memcpy(actorBytes+0x3f8,&state,8);
 for(unsigned i=0;i<3;i++){uintptr_t p[2]={donorProcessBase+0x125340,donorProcessBase+0x125620};memcpy(stateBytes+i*0x250+0x10,p,sizeof(p));}
 basis[0]=basis[5]=basis[10]=basis[15]=1;const float anchor[2]={0,0};float c[3]={0,-10,0};
 combatTravelSample((uintptr_t)actorBytes,c,anchor,1000);CHECK(shared.value.valid&&shared.value.forward==10);
 c[1]=5;combatTravelSample((uintptr_t)actorBytes,c,anchor,1008);CHECK(shared.value.forward==5);
 uintptr_t other=donorProcessBase+0x1319c0;memcpy(stateBytes+0x10,&other,8);combatTravelSample((uintptr_t)actorBytes,c,anchor,1016);CHECK(shared.value.valid&&shared.value.forward==5);
 combatTravelSample((uintptr_t)actorBytes+8,c,anchor,1024);CHECK(!shared.value.valid&&!combatTravelEnabled);
 // No invalid-source rearm or subsequent cumulative publication.
 unsigned long long seq=shared.value.sequence;combatTravelSample((uintptr_t)actorBytes,c,anchor,1032);CHECK(shared.value.sequence==seq);
 combatTravelSourceTick();CHECK(!shared.value.valid);
 puts("PASS source uses exact three ground sections, preserves signed displacement, refuses identity, latches off and clears on stop");return 0;
}
