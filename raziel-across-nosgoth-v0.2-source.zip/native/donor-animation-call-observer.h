// SPDX-License-Identifier: GPL-3.0-or-later
#pragma once
#include "donor-message-observer.h"
typedef uintptr_t (__fastcall *DonorNativeAnimationSelect)(void *,int32_t,void *,int32_t,int32_t,int32_t);
typedef struct {uint32_t key,clip;uintptr_t opaqueState;bool descriptorMatches;} DonorAnimationCallMetadata;
typedef bool (*DonorAnimationCallRead)(void *,void *,int32_t,void *,DonorAnimationCallMetadata *);
typedef struct {
 uint64_t session,callId,tickMs;
 uint32_t phase,threadId,depth,callerRva,messageDepth,section;
 int32_t overrides[3];
 uint32_t key,clip,afterValid,sameState,descriptorMatches;
} DonorAnimationCallEvent;
_Static_assert(sizeof(DonorAnimationCallEvent)==80,"No native pointers in call event");
typedef struct {
 SRWLOCK lock;DonorAnimationCallEvent queue[512];uint32_t head,tail,count;
 volatile LONG64 forwarded,published,dropped,nextCallId;
 void *context;DonorMessageLeaseRead lease;DonorAnimationCallRead snapshot;bool configured;
} DonorAnimationCallObserver;
static inline void donorAnimationCallInit(DonorAnimationCallObserver *o,void *c,DonorMessageLeaseRead l,DonorAnimationCallRead r){
 memset(o,0,sizeof(*o));InitializeSRWLock(&o->lock);o->context=c;o->lease=l;o->snapshot=r;
 const Sheet_donorAnimationCallPolicy *p=&sheet_donorAnimationCallPolicy_bounded;
 o->configured=l&&r&&p->rva==0x149790&&p->bodyBytes==291&&p->plan==11&&p->seconds==60&&p->queueCapacity==512&&p->maxRecords==4096&&p->maxDepth==32&&!p->serializePointers&&!p->syntheticCalls;
}
static inline bool donorAnimationCallPush(DonorAnimationCallObserver *o,const DonorAnimationCallEvent *e){
 bool accepted=false;if(TryAcquireSRWLockExclusive(&o->lock)){
  if(o->count<512&&(uint64_t)InterlockedCompareExchange64(&o->published,0,0)<(uint64_t)sheet_donorAnimationCallPolicy_bounded.maxRecords){o->queue[o->tail]=*e;o->tail=(o->tail+1)%512;o->count++;InterlockedIncrement64(&o->published);accepted=true;}
  ReleaseSRWLockExclusive(&o->lock);
 }if(!accepted)InterlockedIncrement64(&o->dropped);return accepted;
}
static inline bool donorAnimationCallPop(DonorAnimationCallObserver *o,DonorAnimationCallEvent *e){
 if(!TryAcquireSRWLockExclusive(&o->lock))return false;bool ok=o->count!=0;
 if(ok){*e=o->queue[o->head];o->head=(o->head+1)%512;o->count--;}ReleaseSRWLockExclusive(&o->lock);return ok;
}
static inline bool donorAnimationCallLease(DonorAnimationCallObserver *o,const DonorMessageLease *start,DonorMessageLease *now){
 return o->lease(o->context,now)&&donorMessageLeaseValid(now)&&now->session==start->session&&now->startTick==start->startTick&&now->heartbeatTick>=start->heartbeatTick&&now->nowTick>=start->nowTick;
}
// Original trampoline is non-null and retained while any call is in flight.
// Observation failures never suppress, change or retry a native invocation.
static inline uintptr_t donorAnimationCallForward(DonorAnimationCallObserver *o,DonorMessageObserverThread *tls,DonorNativeAnimationSelect original,void *actor,int32_t section,void *descriptor,int32_t a,int32_t b,int32_t c,uint32_t callerRva,uint32_t messageDepth){
 DWORD incoming=GetLastError(),tid=GetCurrentThreadId();uint32_t depth=0;bool tracked=false,entered=false;
 DonorMessageLease start={0},now={0};DonorAnimationCallMetadata before={0};DonorAnimationCallEvent e={0};
 if(tls){LONG owner=InterlockedCompareExchange(&tls->ownerThread,(LONG)tid,0);tracked=owner==0||(DWORD)owner==tid;if(tracked){depth=tls->depth;tls->depth=depth<UINT32_MAX?depth+1:UINT32_MAX;}}
 if(o)InterlockedIncrement64(&o->forwarded);
 if(o&&o->configured&&tracked&&o->lease(o->context,&start)&&start.enabled){
  if(!donorMessageLeaseValid(&start)||depth>=(uint32_t)sheet_donorAnimationCallPolicy_bounded.maxDepth||!actor||section<0||section>2||!descriptor||!o->snapshot(o->context,actor,section,descriptor,&before)||!donorAnimationCallLease(o,&start,&now))InterlockedIncrement64(&o->dropped);
  else{e.session=start.session;e.callId=(uint64_t)InterlockedIncrement64(&o->nextCallId);e.tickMs=now.nowTick;e.phase=1;e.threadId=tid;e.depth=depth+1;e.callerRva=callerRva;e.messageDepth=messageDepth;e.section=(uint32_t)section;e.overrides[0]=a;e.overrides[1]=b;e.overrides[2]=c;e.key=before.key;e.clip=before.clip;e.descriptorMatches=before.descriptorMatches;entered=donorAnimationCallPush(o,&e);}
 }
 SetLastError(incoming);uintptr_t result=original(actor,section,descriptor,a,b,c);DWORD outgoing=GetLastError();
 if(entered){
  DonorAnimationCallMetadata after={0};
  if(donorAnimationCallLease(o,&start,&now)){
   bool valid=o->snapshot(o->context,actor,section,descriptor,&after);
   if(donorAnimationCallLease(o,&start,&now)){e.phase=2;e.tickMs=now.nowTick;e.afterValid=valid;e.sameState=valid&&before.opaqueState==after.opaqueState;e.key=valid?after.key:0;e.clip=valid?after.clip:0;e.descriptorMatches=valid&&after.descriptorMatches;donorAnimationCallPush(o,&e);}
   else InterlockedIncrement64(&o->dropped);
  }else InterlockedIncrement64(&o->dropped);
 }
 if(tracked)tls->depth=depth;SetLastError(outgoing);return result;
}
