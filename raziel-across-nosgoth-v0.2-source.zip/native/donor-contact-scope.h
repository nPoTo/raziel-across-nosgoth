// SPDX-License-Identifier: GPL-3.0-or-later
#pragma once
#include "donor-contact-projection.h"
typedef uint32_t (*DonorGroundOriginal)(uintptr_t,float *,uint16_t,uint32_t);
// The installed hook supplies a thread-local slot. Borrowed native payloads
// are forwarded exactly once and are never retained or copied to a new queue.
static inline uint32_t donorContactForwardGround(DonorGroundOriginal original,
 DonorContactProjection **threadScope,uintptr_t caller,uintptr_t actor,float *payload,
 uint16_t flags,uint32_t opaque,DonorContactProjection *candidate,bool *matched){
 if(matched)*matched=false;
 DonorContactProjection *previous=*threadScope;
 if(previous)previous->poisoned=true;
 bool own=!previous&&candidate&&candidate->admitted&&!candidate->poisoned&&candidate->actor==actor&&
  caller==0x1563be&&flags==7&&(candidate->phase==1||candidate->phase==2);
 *threadScope=own?candidate:NULL;
 uint32_t result=original(actor,payload,flags,opaque);
 *threadScope=previous;
 if(own&&matched)*matched=!candidate->poisoned&&candidate->lineCalls==1&&
  ((result&1)!=0)==(candidate->phase==1);
 return result;
}
