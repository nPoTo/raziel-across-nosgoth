// SPDX-License-Identifier: GPL-3.0-or-later
#include <windows.h>
#include <stdint.h>
#include <stdbool.h>
#include <stdio.h>
#include <string.h>
#define PROBE_REPORT_DIR L"@RAZIEL_SOURCE_ROOT@\\build\\agent-visibility-v21"
#define SR1_NATIVE_SKELETON_ADAPTER 1
#include "sr1-weapon-guidance.h"
#define CHECK(x,n) do{if(!(x)){printf("guidance lease failed %d\n",n);return n;}}while(0)
static Sr1WeaponGuidance lease;
static Sr1WeaponGuidanceObservation o;
static void reset(void){
 memset(&lease,0,sizeof(lease));memset(&o,0,sizeof(o));
 o=(Sr1WeaponGuidanceObservation){.descriptorRead=true,.statusRead=true,.hudActive=true,.pid=2,.hudWriter=3,.hudPlan=13,.now=1100,.hudSession=4,.hudBegin=1000,
  .status={0x31434552,1,2,3,1090,1,1000},.descriptor={0x31445548,1,2,3,13,100,1000,0,4,{0}}};
 o.descriptor.seconds=guidanceSeconds(13);o.descriptor.total=o.status.total=o.descriptor.seconds*10;
 for(unsigned i=0;i<32;i++)o.descriptor.sheetHash[i]=(unsigned char)(guidanceHex(EXPLORATION_SHEET_SHA256[i*2])*16+guidanceHex(EXPLORATION_SHEET_SHA256[i*2+1]));
}
int main(void){
 reset();CHECK(sr1WeaponGuidanceStep(&lease,&o)&&lease.heartbeat==1090&&lease.writer==3&&lease.session==4,1);
 // Reproduce a HUD poll clearing active on a concurrent32byte read. The last
 // exact validated heartbeat remains usable, without moving its timestamp.
 o.descriptorRead=o.statusRead=o.hudActive=false;o.now=2589;CHECK(sr1WeaponGuidanceStep(&lease,&o)&&lease.heartbeat==1090,2);
 o.now=2590;CHECK(!sr1WeaponGuidanceStep(&lease,&o)&&lease.revoked&&lease.heartbeat==1090,3);
 o.descriptorRead=o.statusRead=o.hudActive=true;o.status.tick=o.now;CHECK(!sr1WeaponGuidanceStep(&lease,&o),4);
 reset();CHECK(sr1WeaponGuidanceStep(&lease,&o),5);o.now=2000;o.status.tick=1990;o.descriptorRead=false;CHECK(sr1WeaponGuidanceStep(&lease,&o)&&lease.heartbeat==1090,6);
 o.descriptorRead=true;CHECK(sr1WeaponGuidanceStep(&lease,&o)&&lease.heartbeat==1990,7);
 o.now=2050;o.statusRead=false;CHECK(sr1WeaponGuidanceStep(&lease,&o)&&lease.heartbeat==1990,8);
 reset();CHECK(sr1WeaponGuidanceStep(&lease,&o),9);o.missing=true;CHECK(!sr1WeaponGuidanceStep(&lease,&o)&&lease.revoked,10);
 reset();CHECK(sr1WeaponGuidanceStep(&lease,&o),11);o.invalidShape=true;CHECK(!sr1WeaponGuidanceStep(&lease,&o),12);
 for(unsigned change=0;change<10;change++){
  reset();CHECK(sr1WeaponGuidanceStep(&lease,&o),13);
  switch(change){case 0:o.descriptor.sheetHash[0]^=1;break;case 1:o.descriptor.writerPid++;break;case 2:o.descriptor.session++;break;case 3:o.descriptor.plan=12;break;case 4:o.descriptor.seconds=99;break;case 5:o.status.writerPid++;break;case 6:o.status.gamePid++;break;case 7:o.status.total--;break;case 8:o.status.completed=o.status.total;break;default:o.hudSession++;break;}
  CHECK(!sr1WeaponGuidanceStep(&lease,&o)&&lease.revoked,14);
 }
 reset();o.hudActive=false;CHECK(!sr1WeaponGuidanceStep(&lease,&o)&&!lease.pinned,15);o.hudActive=true;CHECK(sr1WeaponGuidanceStep(&lease,&o),16);
 o.now=1099;CHECK(!sr1WeaponGuidanceStep(&lease,&o)&&lease.revoked,17);
 reset();CHECK(sr1WeaponGuidanceStep(&lease,&o),18);o.now=1200;o.status.tick=99999;CHECK(sr1WeaponGuidanceStep(&lease,&o)&&lease.heartbeat==1090,19);
 reset();CHECK(sr1WeaponGuidanceStep(&lease,&o),20);o.now=o.hudBegin+o.descriptor.seconds*1000-1;o.status.tick=o.now-9;o.status.completed=o.status.total-1;CHECK(sr1WeaponGuidanceStep(&lease,&o),21);
 // First-visible-ack can trail guidanceBegin. The existing HUD wall margin
 // must not reveal the blade before the100s action timeline actually ends.
 o.now+=101;CHECK(sr1WeaponGuidanceStep(&lease,&o),22);o.status.completed=o.status.total;CHECK(!sr1WeaponGuidanceStep(&lease,&o)&&lease.revoked,23);
 reset();CHECK(sr1WeaponGuidanceStep(&lease,&o),24);o.now=o.hudBegin+tutorialWallBudgetMs(o.descriptor.seconds)-1;o.status.tick=o.now-9;o.status.completed=o.status.total-1;CHECK(sr1WeaponGuidanceStep(&lease,&o),25);o.now++;CHECK(!sr1WeaponGuidanceStep(&lease,&o),26);
 CHECK(!sr1WeaponGuidanceStep(NULL,&o)&&!sr1WeaponGuidanceStep(&lease,NULL),27);
#ifdef SR1_REPEAT_JUMP_HUD
 reset();o.hudPlan=o.descriptor.plan=14;o.descriptor.seconds=guidanceSeconds(14);o.descriptor.total=o.status.total=o.descriptor.seconds*10;
 CHECK(sr1WeaponGuidanceStep(&lease,&o)&&lease.plan==14,28);
 o.now=23000;o.status.tick=22990;o.status.completed=220;
 CHECK(sr1WeaponGuidanceStep(&lease,&o),29);
 o.hudPlan=13;CHECK(!sr1WeaponGuidanceStep(&lease,&o)&&lease.revoked,30);
 reset();o.hudPlan=o.descriptor.plan=14;o.descriptor.seconds=guidanceSeconds(14);o.descriptor.total=o.status.total=o.descriptor.seconds*10;
 CHECK(sr1WeaponGuidanceStep(&lease,&o),31);o.status.completed=o.status.total;
 CHECK(!sr1WeaponGuidanceStep(&lease,&o)&&lease.revoked,32);
#endif
 puts("PASS: existing real descriptor/hash/heartbeat validators, transient32byte read retains ONLY old1500ms deadline; foreign/missing/100s heartbeat end revoke, failed reads never renew, existing115s HUD hardwall, no source/pose dependence");return 0;
}
