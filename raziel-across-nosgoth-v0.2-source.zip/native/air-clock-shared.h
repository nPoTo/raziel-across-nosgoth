// SPDX-License-Identifier: GPL-3.0-or-later
#pragma once
#include <windows.h>
#include "air-physics-clock.h"
typedef struct {
 uint32_t magic,version,hostPid,donorPid;
 uint64_t hostCreation,epoch,tick,actor,sequence;
 int32_t scalar;uint32_t active;
} AirClockPacket;
typedef struct {volatile LONG guard,revoked;AirClockPacket value;} AirClockShared;
_Static_assert(sizeof(AirClockPacket)==64,"Air clock ABI");
static inline void airClockName(wchar_t n[96],DWORD pid){_snwprintf(n,96,L"Local\\LOKAirClock-v1-%lu",pid);}
static inline void airClockStore(AirClockShared *m,const AirClockPacket *s){InterlockedIncrement(&m->guard);MemoryBarrier();m->value=*s;MemoryBarrier();InterlockedIncrement(&m->guard);}
static inline bool airClockCopy(const AirClockShared *m,AirClockPacket *s){
 if(!m||m->revoked)return false;
 for(unsigned i=0;i<3;i++){LONG g=m->guard;if(g&1)continue;MemoryBarrier();*s=m->value;MemoryBarrier();if(g==m->guard&&!m->revoked)return true;}return false;
}
