// Bounded, read-only snapshots of the two configured game executables.
#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include <wchar.h>
#include <stdbool.h>
#include <string.h>
int wmain(int argc, wchar_t **argv) {
    bool namesMode = argc == 6 && !wcscmp(argv[1], L"--names");
    bool pointerMode = argc == 6 && !wcscmp(argv[1], L"--find-pointer");
    bool mode = namesMode || pointerMode;
    if (argc != 7 && !mode) { fprintf(stderr, "Usage: read-game-memory PID HEX_ADDRESS LENGTH SAMPLES INTERVAL_MS OUTPUT_JSON\n       read-game-memory --names PID HEX_ADDRESS COUNT OUTPUT_JSON\n       read-game-memory --find-pointer PID HEX_VALUE MAX_MIB OUTPUT_JSON\n"); return 1; }
    DWORD pid = (DWORD)wcstoul(argv[mode ? 2 : 1], NULL, 10);
    uintptr_t address = (uintptr_t)wcstoull(argv[mode ? 3 : 2], NULL, 16);
    size_t length = mode ? 64 : (size_t)wcstoull(argv[3], NULL, 10);
    unsigned int samples = (unsigned int)wcstoul(argv[4], NULL, 10);
    DWORD interval = mode ? 0 : (DWORD)wcstoul(argv[5], NULL, 10);
    if (!pid || !address || !length || length > 4096 || !samples || samples > (mode ? 512u : 120u) || interval > 1000) return 2;
    HANDLE process = OpenProcess(PROCESS_VM_READ | (pointerMode ? PROCESS_QUERY_INFORMATION : PROCESS_QUERY_LIMITED_INFORMATION), FALSE, pid);
    if (!process) { fprintf(stderr, "OpenProcess failed: %lu\n", GetLastError()); return 3; }
    wchar_t executable[32768]; DWORD executableLength = ARRAYSIZE(executable);
    if (!QueryFullProcessImageNameW(process, 0, executable, &executableLength)) { CloseHandle(process); return 4; }
    if (_wcsicmp(executable, L"C:\\Program Files (x86)\\Steam\\steamapps\\common\\Legacy of Kain Defiance Remastered\\defiance.exe") &&
        _wcsicmp(executable, L"C:\\Program Files (x86)\\Steam\\steamapps\\common\\Soul Reaver I-II\\SRX.exe")) {
        fprintf(stderr, "Refusing a process outside the configured game paths.\n"); CloseHandle(process); return 5;
    }
    FILE *out = _wfopen(argv[mode ? 5 : 6], L"wb");
    if (!out) { CloseHandle(process); return 6; }
    unsigned char bytes[4096];
    if (pointerMode) {
        const size_t chunkSize = 65536;
        unsigned char *chunk = HeapAlloc(GetProcessHeap(), 0, chunkSize);
        if (!chunk) { fclose(out); CloseHandle(process); return 8; }
        uintptr_t cursor = 0; SIZE_T scanned = 0, budget = (SIZE_T)samples * 1024 * 1024;
        unsigned int found = 0; MEMORY_BASIC_INFORMATION region;
        fprintf(out, "{\"pid\":%lu,\"pointerValue\":\"0x%llx\",\"references\":[", pid, (unsigned long long)address);
        while (scanned < budget && found < 256 && VirtualQueryEx(process, (LPCVOID)cursor, &region, sizeof(region))) {
            uintptr_t base = (uintptr_t)region.BaseAddress, next = base + region.RegionSize;
            if (next <= cursor) break;
            DWORD protection = region.Protect & 0xff;
            if (region.State == MEM_COMMIT && region.Type == MEM_PRIVATE && !(region.Protect & PAGE_GUARD) &&
                (protection == PAGE_READWRITE || protection == PAGE_WRITECOPY || protection == PAGE_EXECUTE_READWRITE)) {
                for (uintptr_t at = base; at < next && scanned < budget && found < 256; ) {
                    SIZE_T amount = next - at, read = 0;
                    if (amount > chunkSize) amount = chunkSize;
                    if (amount > budget - scanned) amount = budget - scanned;
                    BOOL ok = ReadProcessMemory(process, (LPCVOID)at, chunk, amount, &read);
                    scanned += amount;
                    if (ok) for (SIZE_T j = 0; j + 8 <= read && found < 256; j += 8) {
                        uintptr_t value; memcpy(&value, chunk + j, 8);
                        if (value == address) {
                            if (found++) fputc(',', out);
                            fprintf(out, "{\"address\":\"0x%llx\",\"allocationBase\":\"0x%llx\"}",
                                (unsigned long long)(at+j), (unsigned long long)(uintptr_t)region.AllocationBase);
                        }
                    }
                    at += amount;
                }
            }
            cursor = next;
        }
        fprintf(out, "],\"scannedBytes\":%llu,\"limitReached\":%s}\n", (unsigned long long)scanned, scanned >= budget || found >= 256 ? "true" : "false");
        HeapFree(GetProcessHeap(), 0, chunk); fclose(out); CloseHandle(process);
        printf("Pointer references: %u, scanned %llu MiB (bounded private writable regions only)\n", found, (unsigned long long)scanned/1024/1024);
        return 0;
    }
    if (namesMode) {
        fprintf(out, "{\"pid\":%lu,\"hypothesis\":\"model-contexts-stride-64\",\"entries\":[", pid);
        unsigned int valid = 0;
        for (unsigned int i = 0; i < samples; ++i) {
            uintptr_t at = address + i * 64; SIZE_T read = 0;
            if (!ReadProcessMemory(process, (LPCVOID)at, bytes, 64, &read)) continue;
            uintptr_t namePointer = 0, objectPointer = 0;
            memcpy(&namePointer, bytes, 8); memcpy(&objectPointer, bytes + 8, 8);
            char name[64];
            if (!namePointer || !ReadProcessMemory(process, (LPCVOID)namePointer, name, sizeof(name), &read)) continue;
            size_t n = 0; bool printable = true;
            for (; n < sizeof(name) && name[n]; ++n) {
                unsigned char ch = (unsigned char)name[n];
                if (!((ch >= 'a' && ch <= 'z') || (ch >= 'A' && ch <= 'Z') || (ch >= '0' && ch <= '9') || ch == '_' || ch == '-')) printable = false;
            }
            if (!printable || !n || n == sizeof(name)) continue;
            if (valid++) fputc(',', out);
            fprintf(out, "{\"context\":\"0x%llx\",\"object\":\"0x%llx\",\"name\":\"%s\"}", (unsigned long long)at, (unsigned long long)objectPointer, name);
        }
        fprintf(out, "]}\n"); fclose(out); CloseHandle(process);
        printf("Readable candidate model contexts: %u\n", valid); return 0;
    }
    fprintf(out, "{\"pid\":%lu,\"address\":\"0x%llx\",\"length\":%zu,\"samples\":[", pid, (unsigned long long)address, length);
    unsigned int successful = 0;
    for (unsigned int i = 0; i < samples; ++i) {
        SIZE_T read = 0;
        BOOL ok = ReadProcessMemory(process, (LPCVOID)address, bytes, length, &read);
        if (i) fputc(',', out);
        fprintf(out, "{\"tick\":%llu,\"readable\":%s,\"hex\":\"", (unsigned long long)GetTickCount64(), ok ? "true" : "false");
        if (ok) { ++successful; for (SIZE_T j = 0; j < read; ++j) fprintf(out, "%02x", bytes[j]); }
        fprintf(out, "\"}"); fflush(out);
        if (i + 1 < samples) Sleep(interval);
    }
    fprintf(out, "]}\n"); fclose(out); CloseHandle(process);
    printf("Read-only samples: %u/%u, %zu bytes per sample\n", successful, samples, length);
    return successful == samples ? 0 : 7;
}
