#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <stdint.h>
#include <stdbool.h>
#include <stdio.h>
#include <string.h>
#include <math.h>
#include "MinHook.h"
#define PROBE_REPORT_DIR L"."
static uintptr_t fixturePlayer,fixtureObject=0x12345678;static unsigned calls;static float fixtureFactor=.125f;static bool changeFactor;
static bool worldRead(uintptr_t at,void *out,size_t size){
 if(at==0x10000000+0xc5aa78&&size==8){memcpy(out,&fixturePlayer,8);return true;}
 if(at==0x10000000+0xc5abbc&&size==4){memcpy(out,&fixtureFactor,4);return true;}
 if(at<0x100000000)return false;memcpy(out,(void *)at,size);return true;
}
static bool hashBytes(const void *p,ULONG n,char *out){(void)p;(void)n;(void)out;return false;}
static void logLine(const char *fmt,...){(void)fmt;}
#include "donor-process-probe.h"
#include "donor-animation-probe.h"
static uintptr_t __fastcall mockProcess(uintptr_t instance,uintptr_t tracker){++calls;(void)tracker;float *position=(float *)(instance+0x20);position[0]+=30;if(changeFactor)fixtureFactor=.25f;return 0xfedcba;}
static uintptr_t __fastcall mockMatrix(uintptr_t instance){return mockProcess(instance,0);}
#define CHECK(x) do{if(!(x)){printf("FAIL line %d\n",__LINE__);return 1;}}while(0)
int main(void){
 unsigned char instance[1024]={0};fixturePlayer=(uintptr_t)instance;
 memcpy(instance+0x88,&fixtureObject,8);donorProcessBase=0x10000000;donorRazielObject=(PVOID)fixtureObject;originalDonorProcess=mockProcess;
 CHECK(observeDonorProcess(fixturePlayer,donorProcessBase+0xc5aa50)==0xfedcba&&calls==1&&donorProcessHead==0&&*(float *)(instance+0x20)==30);
 donorProcessEnabled=1;
 CHECK(observeDonorProcess(fixturePlayer,donorProcessBase+0xc5aa50)==0xfedcba&&calls==2&&*(float *)(instance+0x20)==60);
 CHECK(donorProcessHead==1&&donorProcessQueue[0].before[0]==30&&donorProcessQueue[0].after[0]==60&&donorProcessQueue[0].state==fixturePlayer);
 donorRazielObject=NULL;observeDonorProcess(fixturePlayer,donorProcessBase+0xc5aa50);CHECK(calls==3&&donorProcessHead==1);donorRazielObject=(PVOID)fixtureObject;
 observeDonorProcess(fixturePlayer,donorProcessBase+0xc5aa51);CHECK(calls==4&&donorProcessHead==1);
 float root[16]={1,0,0,0,0,1,0,0,0,0,1,0,0,0,0,1};uintptr_t rootBuffer=(uintptr_t)root;memcpy(instance+0x70,&rootBuffer,8);
 observeDonorProcess(fixturePlayer,donorProcessBase+0xc5aa50);CHECK(calls==5&&donorProcessHead==2&&donorProcessQueue[1].motionValid&&donorProcessQueue[1].factor==.125f&&donorProcessQueue[1].after[0]-donorProcessQueue[1].before[0]==30);
 root[4]=1;observeDonorProcess(fixturePlayer,donorProcessBase+0xc5aa50);CHECK(calls==6&&donorProcessHead==3&&!donorProcessQueue[2].motionValid);root[4]=0;
 fixtureFactor=NAN;observeDonorProcess(fixturePlayer,donorProcessBase+0xc5aa50);CHECK(calls==7&&!donorProcessQueue[3].motionValid);fixtureFactor=.125f;
 changeFactor=true;observeDonorProcess(fixturePlayer,donorProcessBase+0xc5aa50);CHECK(calls==8&&!donorProcessQueue[4].motionValid);changeFactor=false;fixtureFactor=.125f;
 donorProcessRecords=12000;unsigned beforeHead=donorProcessHead;observeDonorProcess(fixturePlayer,donorProcessBase+0xc5aa50);CHECK(calls==9&&donorProcessHead==beforeHead);
 donorFrameMotion.wanted=true;donorFrameMotion.instance=fixturePlayer;donorFrameMotion.thread=GetCurrentThreadId();
 observeDonorProcess(fixturePlayer,donorProcessBase+0xc5aa50);
 CHECK(calls==10&&donorFrameMotion.callbacks==1&&donorFrameMotion.valid&&donorFrameMotion.factor==.125f&&donorProcessHead==beforeHead);
 donorFrameMotion.thread++;observeDonorProcess(fixturePlayer,donorProcessBase+0xc5aa50);CHECK(calls==11&&donorFrameMotion.callbacks==1);
 donorFrameMotion.thread=GetCurrentThreadId();donorFrameMotion.instance++;observeDonorProcess(fixturePlayer,donorProcessBase+0xc5aa50);CHECK(calls==12&&donorFrameMotion.callbacks==1);
 donorFrameMotion.instance=fixturePlayer;donorFrameMotion.wanted=false;observeDonorProcess(fixturePlayer,donorProcessBase+0xc5aa50);CHECK(calls==13&&donorFrameMotion.callbacks==1);
 donorProcessStop();donorProcessTick();donorProcessInstall(NULL);CHECK(!donorProcessEnabled);
 calls=0;originalDonorAnimation=mockProcess;donorAnimationTarget=(PVOID)0x10001234;
 uintptr_t callback=(uintptr_t)donorAnimationTarget;memcpy(instance+0x398,&callback,8);
 CHECK(observeDonorAnimation(fixturePlayer,donorProcessBase+0xc5aa50)==0xfedcba&&calls==1&&donorAnimationHead==0);
 donorProcessEnabled=1;float before=*(float *)(instance+0x20);
 CHECK(observeDonorAnimation(fixturePlayer,donorProcessBase+0xc5aa50)==0xfedcba&&calls==2&&*(float *)(instance+0x20)==before+30);
 CHECK(donorAnimationHead==1&&donorAnimationQueue[0].motionValid&&donorAnimationQueue[0].factor==.125f&&donorAnimationQueue[0].after[0]-donorAnimationQueue[0].before[0]==30);
 observeDonorAnimation(fixturePlayer,donorProcessBase+0xc5aa51);CHECK(calls==3&&donorAnimationHead==1);
 callback++;memcpy(instance+0x398,&callback,8);observeDonorAnimation(fixturePlayer,donorProcessBase+0xc5aa50);CHECK(calls==4&&donorAnimationHead==1);
 callback--;memcpy(instance+0x398,&callback,8);donorRazielObject=NULL;observeDonorAnimation(fixturePlayer,donorProcessBase+0xc5aa50);CHECK(calls==5&&donorAnimationHead==1);donorRazielObject=(PVOID)fixtureObject;
 changeFactor=true;observeDonorAnimation(fixturePlayer,donorProcessBase+0xc5aa50);CHECK(calls==6&&donorAnimationHead==2&&!donorAnimationQueue[1].motionValid);changeFactor=false;fixtureFactor=.125f;
 root[4]=1;observeDonorAnimation(fixturePlayer,donorProcessBase+0xc5aa50);CHECK(calls==7&&!donorAnimationQueue[2].motionValid);root[4]=0;
 donorAnimationRecords=48000;beforeHead=donorAnimationHead;observeDonorAnimation(fixturePlayer,donorProcessBase+0xc5aa50);CHECK(calls==8&&donorAnimationHead==beforeHead);
 donorAnimationRecords=0;donorAnimationLock=1;observeDonorAnimation(fixturePlayer,donorProcessBase+0xc5aa50);CHECK(calls==9&&donorAnimationHead==beforeHead);donorAnimationLock=0;
 donorAnimationBegin=GetTickCount64()-90001;observeDonorAnimation(fixturePlayer,donorProcessBase+0xc5aa50);CHECK(calls==10&&donorAnimationHead==beforeHead);
 donorAnimationTarget=NULL;donorProcessEnabled=0;donorAnimationTick();donorAnimationStop();donorAnimationInstall(NULL);CHECK(!donorAnimationBegin&&!donorAnimationRecords);
 originalDonorMatrix=mockMatrix;calls=0;beforeHead=donorAnimationHead;
 CHECK(observeDonorMatrix(fixturePlayer)==0xfedcba&&calls==1&&donorAnimationHead==beforeHead);
 donorProcessEnabled=1;before=*(float *)(instance+0x20);
 CHECK(observeDonorMatrix(fixturePlayer)==0xfedcba&&calls==2&&*(float *)(instance+0x20)==before+30);
 CHECK(donorAnimationQueue[beforeHead].state==1&&donorAnimationQueue[beforeHead].motionValid&&donorAnimationQueue[beforeHead].after[0]-donorAnimationQueue[beforeHead].before[0]==30);
 beforeHead=donorAnimationHead;donorRazielObject=NULL;observeDonorMatrix(fixturePlayer);CHECK(calls==3&&donorAnimationHead==beforeHead);donorRazielObject=(PVOID)fixtureObject;
 donorAnimationRecords=48000;observeDonorMatrix(fixturePlayer);CHECK(calls==4&&donorAnimationHead==beforeHead);
 donorProcessEnabled=0;donorAnimationTick();donorAnimationStop();
 puts("Donor matrix observer: single-argument original once/result/effects, valid delta, actor/disabled/cap fallback, no factor normalization PASS");
 puts("Donor animation observer: original once/result/effects, current callback identity, unchanged factor/buffer, invalid basis, disabled/expiry/cap/contention fallback PASS");
 puts("Donor process observer: original effects/return preserved, identity/tracker scope, recording limits, callback delta/factor/orthonormal rotation and race/NaN rejection, no observer writes PASS");return 0;
}

