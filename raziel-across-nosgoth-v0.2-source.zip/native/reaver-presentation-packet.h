// SPDX-License-Identifier: GPL-3.0-or-later
#pragma once
#include <stdint.h>
#include <stdbool.h>
#include <string.h>
#include <math.h>
// Validate an OWNED immutable copy, never an asynchronously changing map.
// No GPU handles or root transforms are accepted from the writer.
typedef struct {uint32_t hostPid,writerPid,donorPid;uint64_t hostCreation,writerCreation,donorCreation,actor,weapon,model,textureGeneration;} ReaverPacketSession;
typedef struct {uint64_t sequence,tick;uint32_t vertices,indices,batches;bool visible;} ReaverPacketView;
static uint32_t reaverPacketU32(const unsigned char *p){uint32_t x;memcpy(&x,p,4);return x;}
static uint64_t reaverPacketU64(const unsigned char *p){uint64_t x;memcpy(&x,p,8);return x;}
static float reaverPacketFloat(const unsigned char *p){float x;memcpy(&x,p,4);return x;}
static bool reaverPacketValidate(const unsigned char *b,size_t n,const ReaverPacketSession *s,uint64_t now,uint64_t minimumSequence,ReaverPacketView *out){
 if(!out)return false;memset(out,0,sizeof(*out));
 const Sheet_reaverPresentationPacket *p=&sheet_reaverPresentationPacket_weapon_frame_v1;
 if(!b||!s||n<128||p->nativeIntegrationEnabled||p->version!=1||p->headerBytes!=128||p->vertexBytes!=36||p->batchBytes!=32)return false;
 if(!s->hostPid||!s->writerPid||!s->donorPid||!s->hostCreation||!s->writerCreation||!s->donorCreation||!s->actor||!s->weapon||!s->model||!s->textureGeneration)return false;
 if(reaverPacketU32(b)!=0x31565752||reaverPacketU32(b+4)!=(uint32_t)p->version||reaverPacketU32(b+8)!=n||reaverPacketU32(b+12)>1||reaverPacketU32(b+28)||reaverPacketU64(b+120))return false;
 if(reaverPacketU32(b+16)!=s->hostPid||reaverPacketU32(b+20)!=s->writerPid||reaverPacketU32(b+24)!=s->donorPid||
 reaverPacketU64(b+32)!=s->hostCreation||reaverPacketU64(b+40)!=s->writerCreation||reaverPacketU64(b+48)!=s->donorCreation||
 reaverPacketU64(b+72)!=s->actor||reaverPacketU64(b+80)!=s->weapon||reaverPacketU64(b+88)!=s->model||reaverPacketU64(b+96)!=s->textureGeneration)return false;
 uint64_t seq=reaverPacketU64(b+56),tick=reaverPacketU64(b+64);
 if(!seq||seq<minimumSequence||!tick||tick>now||now-tick>(uint64_t)p->maxAgeMs)return false;
 uint32_t nv=reaverPacketU32(b+104),ni=reaverPacketU32(b+108),nb=reaverPacketU32(b+112);bool visible=reaverPacketU32(b+12)==1;
 if(reaverPacketU32(b+116)!=(uint32_t)p->targetHand||nv>(uint32_t)p->maxVertices||ni>(uint32_t)p->maxIndices||nb>(uint32_t)p->maxBatches||
 n!=128+(size_t)nv*36+(size_t)ni*2+(size_t)nb*32)return false;
 if(visible?(!nv||!ni||!nb||ni%3):(nv||ni||nb))return false;
 for(uint32_t i=0;i<nv;i++)for(unsigned k=0;k<9;k++){float v=reaverPacketFloat(b+128+i*36+k*4);if(!isfinite(v)||(k<5?fabsf(v)>1e6f:(v<0||v>2)))return false;}
 const unsigned char *indices=b+128+nv*36,*batches=indices+ni*2;
 for(uint32_t i=0;i<ni;i++){uint16_t v;memcpy(&v,indices+i*2,2);if(v>=nv)return false;}
 uint32_t end=0;for(uint32_t i=0;i<nb;i++){
  const unsigned char *a=batches+i*32;uint32_t start=reaverPacketU32(a),count=reaverPacketU32(a+4),slot=reaverPacketU32(a+8),blend=reaverPacketU32(a+12);
  float scroll=reaverPacketFloat(a+16),alpha=reaverPacketFloat(a+20);
  if(start!=end||!count||count%3||count>ni-end||slot>=(uint32_t)p->maxTextures||(blend!=1&&blend!=2)||!isfinite(scroll)||fabsf(scroll)>1e6f||!isfinite(alpha)||alpha < -1||alpha>1||reaverPacketU64(a+24))return false;
  end+=count;
 }
 if(end!=ni)return false;
 *out=(ReaverPacketView){seq,tick,nv,ni,nb,visible};return true;
}
