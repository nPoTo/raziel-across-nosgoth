// SPDX-License-Identifier: GPL-3.0-or-later
#pragma once
#include <windows.h>
#include <stdint.h>
#include <stdbool.h>
#include <string.h>
#define DUAL_INPUT_MAGIC 0x31494b44u
typedef struct {uint32_t magic,version,host,donor,writer,reserved;uint64_t hostCreation,donorCreation,epoch;} DualInputSession;
typedef struct {uint64_t sequence,tick;uint32_t held,keys;int16_t x,y,rx,ry;uint8_t lt,rt,valid,reserved;} DualInputWire;
typedef struct {volatile LONG guard,revoked;DualInputSession session;DualInputWire sample;volatile LONG64 donorReady;volatile LONG64 hostFrames,donorFrames;} DualInputShared;
static inline void dualInputName(wchar_t name[96],uint32_t host){_snwprintf(name,96,L"Local\\LOKDualInput-v1-%lu",host);}
static inline void dualInputStore(DualInputShared *m,const DualInputWire *s){InterlockedIncrement(&m->guard);MemoryBarrier();m->sample=*s;MemoryBarrier();InterlockedIncrement(&m->guard);}
static inline bool dualInputCopy(const DualInputShared *m,DualInputWire *s){
 if(!m||m->revoked)return false;for(unsigned i=0;i<3;i++){LONG g=m->guard;if(g&1)continue;MemoryBarrier();*s=m->sample;MemoryBarrier();if(g==m->guard&&!m->revoked)return true;}return false;
}
