// Supported engine instance update loop, eight contiguous unwind fragments.
#define DONOR_FRAME_RVA 0x7c570
#define DONOR_FRAME_SIZE 1225
#define DONOR_FRAME_SHA "8da8304244329ad809dc1a67ef30a2e625b93c8067ba5ecffa046ad34856a49c"
