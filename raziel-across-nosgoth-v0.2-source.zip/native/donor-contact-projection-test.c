// SPDX-License-Identifier: GPL-3.0-or-later
#include "donor-contact-projection.h"
#include <assert.h>
#include <stdio.h>
static DonorContactLine ray(const float p[3]){
 DonorContactLine q={.kind=3,.segment=99,.primitive=0x1111,.owner=0x2222,.flags=0x3f,.actor=0x1234};
 for(unsigned i=0;i<3;i++){q.start[i]=p[i];q.end[i]=p[i];}
 q.start[2]+=48;q.end[2]-=96;return q;
}
int main(void){
 for(int height=-1000;height<=1000;height++){
  float p[3]={15,-27,(float)height};
  for(unsigned phase=1;phase<=2;phase++){
   DonorContactProjection scope={.actor=0x1234,.phase=phase,.admitted=true};
   DonorContactLine q=ray(p),original=q;
   assert(donorContactSkipCached(&scope,0x103b4d)&&scope.cachedCalls==1);
   assert(donorContactProjectLine(&scope,phase==1?0x103bf5:0x103c47,0x1234,&q,p)&&scope.lineCalls==1);
   assert(q.owner==0&&q.primitive==0&&q.actor==original.actor&&q.flags==original.flags);
   assert(!memcmp(q.start,original.start,sizeof(q.start)));
   if(phase==1){
    assert(q.kind==2&&q.normal[2]==1&&q.end[2]-p[2]==0);
    assert(q.start[2]-q.end[2]<=48+96); // native near-support branch
   }else assert(q.kind==0&&!memcmp(q.end,original.end,sizeof(q.end)));
  }
 }
 for(unsigned fault=0;fault<12;fault++){
  float p[3]={0,0,100};DonorContactLine q=ray(p);
  DonorContactProjection scope={.actor=0x1234,.phase=1,.admitted=true};uintptr_t caller=0x103bf5,actor=0x1234;
  if(fault==0)scope.admitted=false;if(fault==1)scope.poisoned=true;if(fault==2)scope.phase=3;
  if(fault==3)scope.phase=0;if(fault==4)actor++;if(fault==5)caller=0x1031f7;
  if(fault==6)q.flags=1;if(fault==7)q.start[0]++;if(fault==8)q.end[1]++;
  if(fault==9)q.start[2]=99;if(fault==10)q.end[2]=101;if(fault==11)q.end[2]=NAN;
  DonorContactLine before=q;assert(!donorContactProjectLine(&scope,caller,actor,&q,p));
  assert(!memcmp(&q,&before,sizeof(q))&&scope.lineCalls==0);
 }
 DonorContactProjection scope={.actor=0x1234,.phase=1,.admitted=true};
 assert(!donorContactSkipCached(&scope,0x103b4e));scope.poisoned=true;
 assert(!donorContactSkipCached(&scope,0x103b4d));
 puts("PASS scoped donor contact projection: ground zero correction, airborne no donor floor, foreign/compression/invalid rays unchanged; not runtime integrated");
 return 0;
}
