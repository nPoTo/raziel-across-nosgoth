// Windows creation FILETIME is an identity token, not the monotonic packet clock.
#ifndef BRIDGE_PROCESS_IDENTITY_H
#define BRIDGE_PROCESS_IDENTITY_H
#include <windows.h>
static inline bool bridgeProcessCreation(HANDLE process,uint64_t *identity){
 FILETIME creation,exit,kernel,user;
 if(!identity||!GetProcessTimes(process,&creation,&exit,&kernel,&user))return false;
 *identity=(uint64_t)creation.dwLowDateTime|((uint64_t)creation.dwHighDateTime<<32);return *identity!=0;
}
#endif
