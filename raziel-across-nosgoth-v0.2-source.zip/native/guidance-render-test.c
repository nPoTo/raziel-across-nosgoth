// SPDX-License-Identifier: GPL-3.0-or-later
#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <stdint.h>
#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <wchar.h>
#include "guidance-render.h"
int main(int argc,char **argv){
#ifdef SR1_REPEAT_JUMP_HUD
#if defined(GENERAL_FREE_HUD)
 if(guidanceSeconds(14)!=170||guidanceStageAt(14,20)->end!=170||guidanceStageAt(14,170))return 60;
 for(unsigned t=20;t<170;t++)if(!wcsstr(guidanceStageAt(14,t)->detail,L"X")||!wcsstr(guidanceStageAt(14,t)->detail,L"Y"))return 62;
#elif defined(ROUTE_COMBAT_TEST)
 if(guidanceSeconds(14)!=170||guidanceStageAt(14,19)->begin!=0||guidanceStageAt(14,20)->end!=120||guidanceStageAt(14,120)->end!=140||guidanceStageAt(14,169)->end!=170||guidanceStageAt(14,170))return 60;
 for(unsigned t=0;t<170;t++)if(!guidanceStageAt(14,t))return 63;
 if(!wcsstr(guidanceStageAt(14,140)->detail,L"X")||!wcsstr(guidanceStageAt(14,148)->detail,L"A")||!wcsstr(guidanceStageAt(14,156)->detail,L"Y"))return 62;
#else
 if(guidanceSeconds(14)!=50||guidanceStageAt(14,19)->begin!=0||guidanceStageAt(14,20)->begin!=20||guidanceStageAt(14,49)->end!=50||guidanceStageAt(14,50))return 60;
#ifdef SR1_FREE_ATTACK_INPUT
 if(!wcsstr(guidanceStageAt(14,20)->title,L"SR1")||!wcsstr(guidanceStageAt(14,0)->detail,L"SR1"))return 61;
 if(sheet_repeatJumpObservationStages_count==4){
#if defined(SR1_LIFT_FOLLOW)
  if(!wcsstr(guidanceStageAt(14,20)->title,L"Y")||guidanceStageAt(14,29)->end!=30||!wcsstr(guidanceStageAt(14,30)->title,L"Y")||!wcsstr(guidanceStageAt(14,30)->detail,L"X"))return 62;
#elif defined(SR1_AIR_COMBAT_POSE)
  if(!wcsstr(guidanceStageAt(14,20)->detail,L"X")||guidanceStageAt(14,24)->end!=25||!wcsstr(guidanceStageAt(14,25)->detail,L"A")||!wcsstr(guidanceStageAt(14,25)->detail,L"X"))return 62;
#else
  if(!wcsstr(guidanceStageAt(14,20)->detail,L"LB")||guidanceStageAt(14,24)->end!=25||!wcsstr(guidanceStageAt(14,25)->detail,L"X"))return 62;
#endif
 }else if(!wcsstr(guidanceStageAt(14,20)->detail,L"X"))return 61;
 for(unsigned t=0;t<50;t++)if(!guidanceStageAt(14,t))return 63;
#elif defined(REAVER_VISUAL_SCENARIO_TEST)
 if(!wcsstr(guidanceStageAt(14,20)->detail,L"X")||!wcsstr(guidanceStageAt(14,20)->title,L"REAVER"))return 61;
#else
 if(!wcsstr(guidanceStageAt(14,20)->detail,L"A")||!wcsstr(guidanceStageAt(14,20)->title,L"СКОКОВЕ"))return 61;
#endif
#endif
#endif
 GuidanceDescriptor d={0x31445548,1,7,8,1,300,3000,0,9,{0}};
 for(unsigned i=0;i<32;i++)d.sheetHash[i]=(unsigned char)(guidanceHex(EXPLORATION_SHEET_SHA256[i*2])*16+guidanceHex(EXPLORATION_SHEET_SHA256[i*2+1]));
 if(!guidanceDescriptorValid(&d,7,8,3000)||guidanceDescriptorValid(&d,8,8,3000)||guidanceDescriptorValid(&d,7,9,3000))return 1;
 d.sheetHash[0]^=1;if(guidanceDescriptorValid(&d,7,8,3000))return 2;d.sheetHash[0]^=1;
 if(!guidanceWithinBudget(314999,0,300)||guidanceWithinBudget(315000,0,300)||guidanceWithinBudget(1,2,300))return 3;
 GuidanceDescriptor shortPlan=d;shortPlan.plan=11;shortPlan.seconds=60;shortPlan.total=600;
 if(!guidanceDescriptorValid(&shortPlan,7,8,600)||guidanceDescriptorValid(&shortPlan,7,8,3000)||guidanceStageAt(11,60)||guidanceStageAt(11,UINT32_MAX))return 30;
 for(unsigned k=0;k<60;k++){const TutorialStage *s=guidanceStageAt(11,k);if(!s||k<s->begin||k>=s->end||!s->title[0]||!s->detail[0])return 31;}
 if(guidanceStageAt(11,9)->end!=10||guidanceStageAt(11,10)->begin!=10||!wcsstr(guidanceStageAt(11,10)->detail,L"X"))return 32;
 if(argc==2){FILE *f=fopen(argv[1],"rb");GuidanceDescriptor fixture={0};if(!f||fread(&fixture,sizeof(fixture),1,f)!=1||fgetc(f)!=EOF)return 4;fclose(f);if(!guidanceDescriptorValid(&fixture,7,fixture.writerPid,3000))return 5;}
 WNDCLASSW wc={0};wc.lpfnWndProc=DefWindowProcW;wc.hInstance=GetModuleHandleW(NULL);wc.lpszClassName=L"GuidanceRenderTest";if(!RegisterClassW(&wc))return 6;
 HWND window=CreateWindowW(wc.lpszClassName,L"Hidden guidance renderer test",WS_POPUP,0,0,1280,720,NULL,NULL,wc.hInstance,NULL);if(!window)return 7;
 HDC dc=GetDC(window);PIXELFORMATDESCRIPTOR format={0};format.nSize=sizeof(format);format.nVersion=1;format.dwFlags=PFD_DRAW_TO_WINDOW|PFD_SUPPORT_OPENGL|PFD_DOUBLEBUFFER;format.iPixelType=PFD_TYPE_RGBA;format.cColorBits=32;format.cDepthBits=24;
 int pixel=ChoosePixelFormat(dc,&format);if(!pixel||!SetPixelFormat(dc,pixel,&format))return 8;HGLRC context=wglCreateContext(dc);if(!context||!wglMakeCurrent(dc,context)||!guidanceLoadGL())return 9;
 glViewport(0,0,1280,720);glClearColor(.1f,.2f,.4f,1);glClear(GL_COLOR_BUFFER_BIT|GL_DEPTH_BUFFER_BIT);
 glEnable(GL_DEPTH_TEST);glEnable(GL_STENCIL_TEST);glEnable(GL_CULL_FACE);glEnable(GL_SCISSOR_TEST);glScissor(3,4,10,11);glEnable(GL_COLOR_LOGIC_OP);glEnable(GL_RASTERIZER_DISCARD);ghEnablei(GL_BLEND,0);ghColorMaski(0,GL_FALSE,GL_TRUE,GL_FALSE,GL_TRUE);glPolygonMode(GL_FRONT_AND_BACK,GL_LINE);ghActiveTexture(GL_TEXTURE3);
 glPixelStorei(GL_UNPACK_ALIGNMENT,8);glPixelStorei(GL_UNPACK_ROW_LENGTH,17);glPixelStorei(GL_UNPACK_SKIP_ROWS,2);glPixelStorei(GL_UNPACK_SKIP_PIXELS,3);glPixelStorei(GL_UNPACK_SWAP_BYTES,1);glPixelStorei(GL_UNPACK_LSB_FIRST,1);
 glEnable(GL_CLIP_DISTANCE0);glEnable(GL_SAMPLE_COVERAGE);glEnable(GL_SAMPLE_ALPHA_TO_COVERAGE);glEnable(GL_SAMPLE_ALPHA_TO_ONE);glEnable(GL_SAMPLE_MASK);
 GuidanceGLState before={0},after={0};guidanceSaveGL(&before);
 if(!guidanceRender(context,1,21))return 10;guidanceSaveGL(&after);if(memcmp(&before,&after,sizeof(before)))return 11;
#ifdef SR1_REPEAT_JUMP_HUD
 if(!guidanceRender(context,14,0)||!guidanceRender(context,14,20)||!guidanceRender(context,14,49))return 62;
#if defined(GENERAL_FREE_HUD)
 if(guidanceSeconds(14)!=170||guidanceStageAt(14,20)->end!=170||guidanceStageAt(14,170))return 60;
 for(unsigned t=20;t<170;t++)if(!wcsstr(guidanceStageAt(14,t)->detail,L"X")||!wcsstr(guidanceStageAt(14,t)->detail,L"Y"))return 62;
#elif defined(ROUTE_COMBAT_TEST)
 for(unsigned t=120;t<170;t++)if(!guidanceRender(context,14,t))return 62;
#endif
 guidanceSaveGL(&after);if(memcmp(&before,&after,sizeof(before)))return 63;
#endif
 if(glGetError()!=GL_NO_ERROR)return 12;
 unsigned char outside[4]={0};glReadPixels(2,2,1,1,GL_RGBA,GL_UNSIGNED_BYTE,outside);if(outside[0]<24||outside[0]>27||outside[1]!=51||outside[2]!=102)return 13;
 unsigned char *pixels=calloc(1280*720,4);if(!pixels)return 14;glReadPixels(0,0,1280,720,GL_BGRA,GL_UNSIGNED_BYTE,pixels);unsigned white=0;
 for(unsigned i=0;i<1280*720;i++)if(pixels[i*4]>220&&pixels[i*4+1]>220&&pixels[i*4+2]>220)white++;
 if(white<200)return 15;
 // An empty point INSIDE the former panel must preserve the game framebuffer.
 unsigned char panelCorner[4]={0};glReadPixels(20,680,1,1,GL_RGBA,GL_UNSIGNED_BYTE,panelCorner);
 if(panelCorner[0]<24||panelCorner[0]>27||panelCorner[1]!=51||panelCorner[2]!=102)return 39;
 if(!guidanceRender(context,1,216)||guidanceRenderedSecond!=216)return 16;guidanceSaveGL(&after);if(memcmp(&before,&after,sizeof(before)))return 17;
 if(!guidanceRender(context,11,11))return 33;guidanceSaveGL(&after);if(memcmp(&before,&after,sizeof(before)))return 34;
#if defined(SR1_RETARGET_PREVIEW) || defined(SR1_NATIVE_SKELETON_ADAPTER)
 const unsigned checks[]={0,21,50,72,80,98};for(unsigned i=0;i<ARRAYSIZE(checks);i++){if(!guidanceRender(context,13,checks[i]))return 36;guidanceSaveGL(&after);if(memcmp(&before,&after,sizeof(before)))return 37;}if(!guidanceRender(context,13,guidanceSeconds(13)-1)||guidanceRender(context,13,guidanceSeconds(13)))return 38;
#endif
 if(guidanceRender(context,1,300)||guidanceRender(NULL,1,21)||guidanceStageAt(10,20))return 18;
 FILE *out=fopen("reports/build-tasks/native-guidance-render-preview.bmp","wb");if(!out)return 19;BITMAPFILEHEADER bh={0};BITMAPINFOHEADER bi={0};bh.bfType=0x4d42;bh.bfOffBits=sizeof(bh)+sizeof(bi);bh.bfSize=bh.bfOffBits+1280*720*4;bi.biSize=sizeof(bi);bi.biWidth=1280;bi.biHeight=720;bi.biPlanes=1;bi.biBitCount=32;fwrite(&bh,sizeof(bh),1,out);fwrite(&bi,sizeof(bi),1,out);fwrite(pixels,1280*720*4,1,out);fclose(out);
 // Separate owned synthetic preview of the actual60s plan, never a game capture.
 glReadPixels(0,0,1280,720,GL_BGRA,GL_UNSIGNED_BYTE,pixels);out=fopen("reports/build-tasks/donor-message-guidance-preview.bmp","wb");if(!out)return 35;fwrite(&bh,sizeof(bh),1,out);fwrite(&bi,sizeof(bi),1,out);fwrite(pixels,1280*720*4,1,out);fclose(out);free(pixels);
 wglMakeCurrent(NULL,NULL);wglDeleteContext(context);ReleaseDC(window,dc);DestroyWindow(window);
 printf("PASS: descriptor identity/hash/expiry, native GL text pixels=%u, exact touched-state restoration, outside pixels unchanged, timer/stage update\n",white);return 0;
}
