#include <stdint.h>
#include <stdbool.h>
#include <stdio.h>
#include <string.h>
#include <math.h>
#include "movement-packet.h"
#define CHECK(x) do{if(!(x)){printf("FAIL line %d\n",__LINE__);return 1;}}while(0)
int main(int argc,char **argv){
 CHECK(argc==2);FILE *f=fopen(argv[1],"rb");CHECK(f);unsigned char b[80],original[80];CHECK(fread(b,1,80,f)==80);fclose(f);memcpy(original,b,80);
 float target=1;uint64_t tick=0;
 CHECK(movementPacketTarget(b,80,1050,4242,1000,4096,&target,&tick)&&target==-60&&tick==1000);
 CHECK(movementPacketTarget(b,80,1050,4242,1000,2048,&target,&tick)&&target==-30);
 CHECK(!movementPacketTarget(b,79,1050,4242,1000,4096,&target,&tick));
 CHECK(!movementPacketTarget(b,80,1200,4242,1000,4096,&target,&tick));
 CHECK(!movementPacketTarget(b,80,999,4242,1000,4096,&target,&tick));
 CHECK(!movementPacketTarget(b,80,1050,4243,1000,4096,&target,&tick));
 CHECK(!movementPacketTarget(b,80,1050,4242,1000,0,&target,&tick));
 b[48]^=1;CHECK(!movementPacketTarget(b,80,1050,4242,1000,4096,&target,&tick));memcpy(b,original,80);
 float bad=NAN;memcpy(b+24,&bad,4);CHECK(!movementPacketTarget(b,80,1050,4242,1000,4096,&target,&tick));memcpy(b,original,80);
 uint32_t idle=2;memcpy(b+40,&idle,4);CHECK(!movementPacketTarget(b,80,1050,4242,1000,4096,&target,&tick));
 memset(b+28,0,12);CHECK(movementPacketTarget(b,80,1050,4242,1000,4096,&target,&tick)&&target==0);
 puts("Cross-language movement packet: native timing, freshness/identity/bounds/hash, idle release PASS");return 0;
}
