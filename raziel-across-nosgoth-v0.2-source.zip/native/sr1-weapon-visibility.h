// SPDX-License-Identifier: GPL-3.0-or-later
#pragma once
#include <stdint.h>
#include <stdbool.h>
typedef struct {
 bool requested,healthyLease,complete,originalModel;
 uintptr_t actor,object,model,expectedActor,expectedObject,expectedModel;
} Sr1WeaponVisibility;
static inline bool sr1WeaponVisibilityAllowed(const Sr1WeaponVisibility *s){
 return s&&s->requested&&s->healthyLease&&!s->complete&&s->originalModel&&s->actor&&s->object&&s->model&&
  s->actor==s->expectedActor&&s->object==s->expectedObject&&s->model==s->expectedModel;
}
