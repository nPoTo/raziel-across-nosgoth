// SPDX-License-Identifier: GPL-3.0-or-later
// One owned observation per process. Revocation is terminal, never suspension.
#pragma once
#include <stdbool.h>
#include <stdint.h>
typedef struct {
 uint64_t session,startTick,heartbeatTick;
 uint32_t writer;
 bool terminal;
} DonorMessageSessionLease;
static inline bool donorMessageSessionAccept(DonorMessageSessionLease *s,bool filesValid,uint64_t session,uint32_t writer,uint64_t heartbeat,uint64_t now,uint64_t duration,uint64_t freshness){
 if(!s||s->terminal)return false;
 bool valid=filesValid&&session&&writer&&heartbeat&&duration&&freshness&&now>=heartbeat&&now-heartbeat<freshness;
 if(s->session)valid=valid&&session==s->session&&writer==s->writer&&heartbeat>=s->heartbeatTick&&now>=s->startTick&&now-s->startTick<duration;
 if(!valid){if(s->session)s->terminal=true;return false;}
 if(!s->session){s->session=session;s->writer=writer;s->startTick=heartbeat;}
 // The first sample must also fit the total capture deadline.
 if(now-s->startTick>=duration){s->terminal=true;return false;}
 s->heartbeatTick=heartbeat;return true;
}
