// SPDX-License-Identifier: GPL-3.0-or-later
#include "air-clock-shared.h"
static HANDLE srAirClockMap;static const AirClockShared *srAirClockView;
static AirPhysicsClock srAirClock;static uint64_t srAirClockPackets;static unsigned srAirClockScaled;
static DWORD srAirClockThread;
static void srAirClockTick(void){
 if(srAirClockView||!hostContactSource.view)return;
 wchar_t name[96];airClockName(name,GetCurrentProcessId());
 HANDLE m=OpenFileMappingW(FILE_MAP_READ,FALSE,name);if(!m)return;
 const AirClockShared *v=MapViewOfFile(m,FILE_MAP_READ,0,0,sizeof(*v));
 if(!v){CloseHandle(m);return;}srAirClockMap=m;MemoryBarrier();InterlockedExchangePointer((PVOID volatile *)&srAirClockView,(PVOID)v);
}
static int32_t srAirClockTime(uintptr_t actor,int32_t segment,int32_t time,int32_t clamp){
 uint64_t now=GetTickCount64();AirPhysicsClockInput input={.now=now,.time=time,.segment=segment,.clamp=clamp};
 AirClockPacket p={0};SkeletonSnapshot pose={0};HostContactSnapshot contact={0};
 uintptr_t base=(uintptr_t)InterlockedCompareExchangePointer(&verifiedSr1Module,NULL,NULL);
 if(!hostGroundPlayer(base,actor)||segment!=0)return time;
 DWORD thread=GetCurrentThreadId();if(srAirClockThread&&thread!=srAirClockThread)return time;
 const Sheet_airPhysicsClock *policy=&sheet_airPhysicsClock_bounded;
 bool valid=!policy->enabled&&policy->denominator==4096&&policy->freshMs==100&&policy->durationMs==50000&&policy->maxContinuousMs==3000&&
  !policy->coordinateWrites&&!policy->velocityWrites&&policy->nativeExceptions&&
  !InterlockedCompareExchange(&probeBoundedComplete,0,0)&&airClockCopy(srAirClockView,&p)&&
  hostContactCopy(hostContactSource.view,&contact)&&contact.phase==2&&contact.actor==actor&&contact.tick<=now&&now-contact.tick<=100&&
  skeletonCopy(sr1SkeletonView,&pose)&&skeletonPacketValid(&pose,GetCurrentProcessId(),now)&&pose.mode==3&&pose.actor==actor&&
  p.magic==0x314b4341&&p.version==1&&p.hostPid==GetCurrentProcessId()&&p.donorPid==pose.sourcePid&&
  p.hostCreation==hostContactSource.creation&&p.epoch==hostContactSource.epoch&&p.actor==actor&&p.sequence>=srAirClockPackets&&
  hostGroundPlayer(base,actor)&&sr1SkeletonContextKind(base,actor,3);
 // Current native callbacks, not yesterday's contact, decide handoff.
 for(unsigned i=0;valid&&i<3;i++){uintptr_t cb=0;const Sheet_hostContactFrameObserver *h=&sheet_hostContactFrameObserver_completed_collision;
  valid=worldRead(base+h->callbackRva+i*h->callbackStride,&cb,8)&&(cb==base+0xf2ae0||cb==base+0xef480);}
 if(valid){if(!srAirClockThread)srAirClockThread=thread;srAirClockPackets=p.sequence;input.enabled=true;input.identity=true;input.hostAir=true;input.donorAttack=p.active==1;input.epoch=p.epoch;input.sourceTick=p.tick;input.scalar=p.scalar;}
 int32_t next=airPhysicsClockStep(&srAirClock,&input);if(next!=time)++srAirClockScaled;return next;
}
