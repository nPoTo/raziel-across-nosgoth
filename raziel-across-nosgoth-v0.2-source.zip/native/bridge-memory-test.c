// SPDX-License-Identifier: GPL-3.0-or-later
#include <stdlib.h>
#include "bridge-memory.h"
#include "bridge-session.h"
#define CHECK(x) do{if(!(x)){fprintf(stderr,"FAIL paired memory line%d\n",__LINE__);result=1;goto done;}}while(0)
static void identity(BridgeIdentity *i,DWORD host,uint64_t creation,uint64_t generation,DWORD source,uint64_t sourceCreation){
 *i=(BridgeIdentity){.sourcePid=source,.hostPid=host,.sourceCreation=sourceCreation,.hostCreation=creation,.sessionGeneration=generation,.levelGeneration=1,.actorId=1,.actorGeneration=1,.capabilities=15};
 bridgeHex(sheet_bridgeProtocol_session_v2.sourceBuild,i->sourceBuild);bridgeHex(sheet_bridgeProtocol_session_v2.hostBuild,i->hostBuild);
}
static void eventNames(DWORD host,uint64_t generation,wchar_t stop[160],wchar_t hold[160],wchar_t held[160]){
 swprintf(stop,160,L"Local\\RZB2TestStop-%lu-%llu",host,(unsigned long long)generation);
 swprintf(hold,160,L"Local\\RZB2TestHold-%lu-%llu",host,(unsigned long long)generation);
 swprintf(held,160,L"Local\\RZB2TestHeld-%lu-%llu",host,(unsigned long long)generation);
}
static int publisher(DWORD host,uint64_t creation,uint64_t generation){
 int result=0;BridgeMemory m={0};uint64_t ownCreation=0;unsigned char *payload=malloc(RM_APPEARANCE_BYTES),*pose=malloc(RM_LIVE_BYTES),movement[80];HANDLE stop=NULL,hold=NULL,held=NULL;
 wchar_t stopName[160],holdName[160],heldName[160];eventNames(host,generation,stopName,holdName,heldName);
 stop=OpenEventW(SYNCHRONIZE,FALSE,stopName);hold=OpenEventW(SYNCHRONIZE,FALSE,holdName);held=OpenEventW(EVENT_MODIFY_STATE,FALSE,heldName);
 CHECK(payload&&pose&&stop&&hold&&held&&bridgeProcessCreation(GetCurrentProcess(),&ownCreation));
 BridgeIdentity i;identity(&i,host,creation,generation,GetCurrentProcessId(),ownCreation);CHECK(bridgeMemoryOpen(&m,&i,true));
 uint64_t deadline=GetTickCount64()+10000,sequence=0;
 while(GetTickCount64()<deadline&&WaitForSingleObject(stop,0)==WAIT_TIMEOUT){
  if(WaitForSingleObject(hold,0)==WAIT_OBJECT_0){CHECK(WaitForSingleObject(m.mutex,1000)==WAIT_OBJECT_0);SetEvent(held);WaitForSingleObject(stop,5000);ReleaseMutex(m.mutex);break;}
  uint64_t tick=GetTickCount64();sequence++;
  for(unsigned type=BRIDGE_GEOMETRY;type<=BRIDGE_APPEARANCE;type++){
   size_t bytes=bridgeMemoryPayload(type);memset(payload,(int)(0xa0+type),bytes);
   BridgeHeader h={.identity=i,.type=(uint16_t)type,.payloadBytes=(uint32_t)bytes,.sequence=sequence,.tick=tick};bridgeMemoryPublish(&m,&h,payload);
  }
  memset(pose,0xa4,RM_LIVE_BYTES);memset(movement,0xa5,80);BridgeHeader p={.identity=i,.type=BRIDGE_POSE,.payloadBytes=RM_LIVE_BYTES,.sequence=sequence,.tick=tick},c=p;c.type=BRIDGE_MOVEMENT;c.payloadBytes=80;
  bridgeMemoryPublishFrame(&m,&p,pose,&c,movement);
  Sleep(10);
 }
done:bridgeMemoryClose(&m);free(payload);free(pose);if(stop)CloseHandle(stop);if(hold)CloseHandle(hold);if(held)CloseHandle(held);return result;
}
int main(int argc,char **argv){
 if(argc==5&&!strcmp(argv[1],"--publisher"))return publisher((DWORD)strtoul(argv[2],NULL,10),strtoull(argv[3],NULL,10),strtoull(argv[4],NULL,10));
 int result=0;BridgeMemory m={0},wrong={0};PROCESS_INFORMATION child={0};HANDLE stop=NULL,hold=NULL,held=NULL;unsigned char *payload=malloc(RM_APPEARANCE_BYTES);uint64_t hostCreation=0,sourceCreation=0;DWORD handlesBefore=0,handlesAfter=0;
 bool graceful=argc==2&&!strcmp(argv[1],"--graceful");CHECK(GetProcessHandleCount(GetCurrentProcess(),&handlesBefore));
 CHECK(payload&&bridgeProcessCreation(GetCurrentProcess(),&hostCreation));
 uint64_t generation=GetTickCount64();wchar_t stopName[160],holdName[160],heldName[160],exe[MAX_PATH],command[1024];eventNames(GetCurrentProcessId(),generation,stopName,holdName,heldName);
 stop=CreateEventW(NULL,TRUE,FALSE,stopName);hold=CreateEventW(NULL,TRUE,FALSE,holdName);held=CreateEventW(NULL,TRUE,FALSE,heldName);CHECK(stop&&hold&&held);
 CHECK(GetModuleFileNameW(NULL,exe,MAX_PATH));swprintf(command,1024,L"\"%ls\" --publisher %lu %llu %llu",exe,GetCurrentProcessId(),(unsigned long long)hostCreation,(unsigned long long)generation);
 STARTUPINFOW startup={.cb=sizeof(startup)};CHECK(CreateProcessW(exe,command,NULL,NULL,FALSE,CREATE_NO_WINDOW,NULL,NULL,&startup,&child));
 // Measure after Windows has initialized process-launch machinery. Exclude the
 // three owned events and the process/thread handles that cleanup will close.
 CHECK(GetProcessHandleCount(GetCurrentProcess(),&handlesBefore)&&handlesBefore>=5);handlesBefore-=5;
 CHECK(bridgeProcessCreation(child.hProcess,&sourceCreation));BridgeIdentity i;identity(&i,GetCurrentProcessId(),hostCreation,generation,child.dwProcessId,sourceCreation);
 uint64_t deadline=GetTickCount64()+5000;while(GetTickCount64()<deadline&&!bridgeMemoryOpen(&m,&i,false))Sleep(5);CHECK(m.view);
 BridgeHeader h;for(unsigned type=BRIDGE_GEOMETRY;type<=BRIDGE_MOVEMENT;type++){
  size_t bytes=bridgeMemoryPayload(type);bool copied=false;deadline=GetTickCount64()+2000;
  while(GetTickCount64()<deadline&&!(copied=bridgeMemoryCopy(&m,type,payload,bytes,GetTickCount64(),&h)))Sleep(5);CHECK(copied);
  for(size_t n=0;n<bytes;n++)CHECK(payload[n]==0xa0+type);
  CHECK(!bridgeMemoryCopy(&m,type,payload,bytes-1,GetTickCount64(),&h));
 }
 unsigned char pairedMovement[80];BridgeHeader pairedPose,pairedCommand;bool paired=false;deadline=GetTickCount64()+2000;
 while(GetTickCount64()<deadline&&!(paired=bridgeMemoryFrame(&m,payload,pairedMovement,GetTickCount64(),&pairedPose,&pairedCommand)))Sleep(5);
 CHECK(paired&&pairedPose.sequence==pairedCommand.sequence&&pairedPose.tick==pairedCommand.tick);
 for(size_t n=0;n<RM_LIVE_BYTES;n++)CHECK(payload[n]==0xa4);for(unsigned n=0;n<80;n++)CHECK(pairedMovement[n]==0xa5);
 memset(pairedMovement,0x17,80);CHECK(!bridgeMemoryFrame(&m,payload,pairedMovement,GetTickCount64()+1000,&pairedPose,&pairedCommand)&&pairedMovement[0]==0x17);
 memset(payload,0x17,RM_MOVEMENT_BYTES);CHECK(!bridgeMemoryCopy(&m,BRIDGE_MOVEMENT,payload,RM_MOVEMENT_BYTES,GetTickCount64()+1000,&h)&&payload[0]==0x17);
 CHECK(!bridgeMemoryCopy(&m,BRIDGE_MOVEMENT,payload,RM_MOVEMENT_BYTES,0,&h)&&payload[0]==0x17);
 BridgeMemory duplicate={0};CHECK(!bridgeMemoryOpen(&duplicate,&i,true));
 BridgeIdentity mismatch=i;mismatch.hostCreation++;CHECK(!bridgeMemoryOpen(&wrong,&mismatch,false));mismatch=i;mismatch.sourceCreation++;CHECK(!bridgeMemoryOpen(&wrong,&mismatch,false));
 mismatch=i;mismatch.sessionGeneration++;CHECK(!bridgeMemoryOpen(&wrong,&mismatch,false));
 mismatch=i;mismatch.levelGeneration++;deadline=GetTickCount64()+2000;while(GetTickCount64()<deadline&&!bridgeMemoryOpen(&wrong,&mismatch,false))Sleep(5);CHECK(wrong.view);
 CHECK(!bridgeMemoryCopy(&wrong,BRIDGE_MOVEMENT,payload,RM_MOVEMENT_BYTES,GetTickCount64(),&h));bridgeMemoryClose(&wrong);
 if(graceful){SetEvent(stop);CHECK(WaitForSingleObject(child.hProcess,2000)==WAIT_OBJECT_0);DWORD exitCode=1;CHECK(GetExitCodeProcess(child.hProcess,&exitCode)&&exitCode==0);}
 else {
  SetEvent(hold);CHECK(WaitForSingleObject(held,2000)==WAIT_OBJECT_0);
  CHECK(!bridgeMemoryCopy(&m,BRIDGE_POSE,payload,RM_LIVE_BYTES,GetTickCount64(),&h)&&m.status==BM_BUSY); // zero-wait contention
  CHECK(TerminateProcess(child.hProcess,77));CHECK(WaitForSingleObject(child.hProcess,2000)==WAIT_OBJECT_0);
 }
 CHECK(!bridgeMemoryCopy(&m,BRIDGE_POSE,payload,RM_LIVE_BYTES,GetTickCount64(),&h)); // abandoned lock released
 CHECK(m.status==(graceful?BM_PEER_LOST:BM_ABANDONED));
 CHECK(!bridgeMemoryCopy(&m,BRIDGE_MOVEMENT,payload,RM_MOVEMENT_BYTES,GetTickCount64(),&h)&&m.status==BM_PEER_LOST); // dead producer
 // Run the same identity through the coordinator: old owned effects must release.
 BridgeSession s;bridgeSessionBegin(&s);BridgeSessionObservation o={.hostAlive=true,.donorAlive=true,.identified=true,.contractValid=true,.actorReady=true,.activate=true,.identity=i,.requestedOwnership=BRIDGE_OWN_BODY|BRIDGE_OWN_INPUT,.now=1000,.heartbeat=1000};
 for(unsigned step=0;step<4;step++)bridgeSessionStep(&s,&o);CHECK(s.state==BRIDGE_ACTIVE&&bridgeSessionAcknowledge(&s,0,s.desired));
 o.donorAlive=false;BridgeSessionEffects effects=bridgeSessionStep(&s,&o);CHECK(effects.state==BRIDGE_RECOVERING&&effects.release==s.owned&&!effects.acquire);
 puts(graceful?"PASS: RZB2 paired normal exit, exact streams, stale/future/generation rejection and coordinator cleanup decision":"PASS: RZB2 paired crash, exact streams, stale/future/generation rejection, zero-wait contention, abandoned mutex/dead producer and coordinator cleanup decision");
done:
 if(stop)SetEvent(stop);if(child.hProcess){if(WaitForSingleObject(child.hProcess,1000)==WAIT_TIMEOUT){TerminateProcess(child.hProcess,78);WaitForSingleObject(child.hProcess,1000);}CloseHandle(child.hProcess);}if(child.hThread)CloseHandle(child.hThread);
 bridgeMemoryClose(&wrong);bridgeMemoryClose(&m);free(payload);if(stop)CloseHandle(stop);if(hold)CloseHandle(hold);if(held)CloseHandle(held);
 if(!result&&(!GetProcessHandleCount(GetCurrentProcess(),&handlesAfter)||handlesBefore!=handlesAfter)){fprintf(stderr,"FAIL handle cleanup %lu -> %lu\n",handlesBefore,handlesAfter);result=1;}
 if(!result)puts("PASS: parent process handle count restored after paired transport close");return result;
}
