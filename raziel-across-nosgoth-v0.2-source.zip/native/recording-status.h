#pragma once
#include "report-path.h"
#include "exploration-sheets.h"
// Small, bounded heartbeat for the recording indicator. Runtime-owned file.
typedef struct {
    uint32_t magic,version,gamePid,writerPid;
    uint64_t tick;
    uint32_t completed,total;
} RecordingStatus;
_Static_assert(sizeof(RecordingStatus)==32,"Recording heartbeat layout");
static inline bool recordingStatusValid(const RecordingStatus *s,DWORD gamePid,uint64_t now) {
    return s->magic==0x31434552&&s->version==1&&s->gamePid==gamePid&&s->writerPid&&s->tick&&now>=s->tick&&now-s->tick<1500&&
        s->completed&&s->total&&(s->total<=3600||s->total==(uint32_t)sheet_sessionLifetime_session.testSeconds*10)&&s->completed<=s->total;
}
static inline void recordingStatusPath(wchar_t path[512],DWORD gamePid) {
    _snwprintf(path,512,PROBE_PATH(L"\\recording-status-%lu.bin"),gamePid);
}
static inline bool recordingReadStatus(DWORD gamePid,RecordingStatus *status) {
    wchar_t path[512];recordingStatusPath(path,gamePid);
    HANDLE file=CreateFileW(path,GENERIC_READ,FILE_SHARE_READ|FILE_SHARE_WRITE|FILE_SHARE_DELETE,NULL,OPEN_EXISTING,FILE_ATTRIBUTE_NORMAL,NULL);
    if(file==INVALID_HANDLE_VALUE)return false;
    LARGE_INTEGER size;DWORD bytes=0;bool ok=GetFileSizeEx(file,&size)&&size.QuadPart==sizeof(*status)&&ReadFile(file,status,sizeof(*status),&bytes,NULL)&&bytes==sizeof(*status);
    CloseHandle(file);return ok;
}
static inline void recordingWriteStatus(DWORD gamePid,uint32_t completed,uint32_t total) {
    wchar_t path[512];recordingStatusPath(path,gamePid);
    RecordingStatus status={0x31434552,1,gamePid,GetCurrentProcessId(),GetTickCount64(),completed,total};
    HANDLE file=CreateFileW(path,GENERIC_WRITE,FILE_SHARE_READ|FILE_SHARE_WRITE|FILE_SHARE_DELETE,NULL,CREATE_ALWAYS,FILE_ATTRIBUTE_NORMAL,NULL);
    if(file==INVALID_HANDLE_VALUE)return;
    DWORD bytes=0;WriteFile(file,&status,sizeof(status),&bytes,NULL);CloseHandle(file);
}
static inline void recordingStopStatus(DWORD gamePid) {
    RecordingStatus status={0};
    if(recordingReadStatus(gamePid,&status)&&status.writerPid==GetCurrentProcessId()){
        wchar_t path[512];recordingStatusPath(path,gamePid);DeleteFileW(path);
    }
}
