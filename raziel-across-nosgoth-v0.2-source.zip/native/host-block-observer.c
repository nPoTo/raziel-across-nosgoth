// SPDX-License-Identifier: GPL-3.0-or-later
// Standalone external read-only scalar stream. No output-file/asset/pose mode.
#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <tlhelp32.h>
#include <bcrypt.h>
#include <stdio.h>
#include <stdlib.h>
#include <wchar.h>
#include "host-block-state-reader.h"
#ifdef HOST_BLOCK_ANIMATION_OBSERVER
#include "host-block-animation-reader.h"
#define HOST_BLOCK_OBSERVATION_SCHEMA 2
#else
#define HOST_BLOCK_OBSERVATION_SCHEMA 1
#endif
#include "reader-hash.h"
static bool readMemory(void *context,uintptr_t address,void *out,SIZE_T bytes){SIZE_T n=0;return address&&ReadProcessMemory((HANDLE)context,(LPCVOID)address,out,bytes,&n)&&n==bytes;}
static bool executable(void *context,uintptr_t address,uintptr_t base){MEMORY_BASIC_INFORMATION m={0};return VirtualQueryEx((HANDLE)context,(LPCVOID)address,&m,sizeof(m))==sizeof(m)&&m.State==MEM_COMMIT&&m.Type==MEM_IMAGE&&(uintptr_t)m.AllocationBase==base&&!(m.Protect&(PAGE_GUARD|PAGE_NOACCESS))&&(m.Protect&(PAGE_EXECUTE|PAGE_EXECUTE_READ|PAGE_EXECUTE_READWRITE|PAGE_EXECUTE_WRITECOPY));}
static bool hashMatches(const char *value,const wchar_t *expected){if(strlen(value)!=64||wcslen(expected)!=64)return false;for(unsigned i=0;i<64;i++)if((unsigned char)value[i]!=(unsigned)expected[i])return false;return true;}
static bool number(const wchar_t *text,unsigned long max,unsigned long *out){wchar_t *end;if(!text[0]||text[0]<L'0'||text[0]>L'9')return false;*out=wcstoul(text,&end,10);return !*end&&*out>0&&*out<=max;}
static bool actorIdentity(HANDLE process,uintptr_t actor){uintptr_t object=0,name=0,again=0;char value[9];return actor&&actor%8==0&&hostBlockField(process,readMemory,actor,0x30,&object,8)&&object&&object%8==0&&hostBlockField(process,readMemory,object,0x30,&name,8)&&name&&readMemory(process,name,value,9)&&!memcmp(value,"raziel__",9)&&hostBlockField(process,readMemory,actor,0x30,&again,8)&&again==object;}
int wmain(int argc,wchar_t **argv){
 const Sheet_hostBlockStateProbe *p=&sheet_hostBlockStateProbe_current;unsigned long pid,count,interval;
 if(argc!=4||!number(argv[1],0xffffffffUL,&pid)||!number(argv[2],(unsigned long)p->maxSamples,&count)||!number(argv[3],1000,&interval)||interval!=(unsigned long)p->intervalMs){fputs("Usage: host-block-observer PID SAMPLES INTERVAL_MS; bounded stdout scalar stream only\n",stderr);return 1;}
 HANDLE process=OpenProcess(PROCESS_VM_READ|PROCESS_QUERY_LIMITED_INFORMATION,FALSE,pid);if(!process){fprintf(stderr,"Read-only OpenProcess failed:%lu\n",GetLastError());return 2;}
 int result=3;wchar_t path[32768],expected[32768],modulePath[32768];DWORD length=ARRAYSIZE(path);char hash[65];
 DWORD expectedLength=GetEnvironmentVariableW(L"RAZIEL_SR1_EXE",expected,ARRAYSIZE(expected));
 if(!expectedLength||expectedLength>=ARRAYSIZE(expected)||!QueryFullProcessImageNameW(process,0,path,&length)||_wcsicmp(path,expected)||!wcsrchr(path,L'\\')||_wcsicmp(wcsrchr(path,L'\\')+1,L"SRX.exe")||length+12>=ARRAYSIZE(path)||!hashFile(path,hash)||!hashMatches(hash,p->executableSha256)){fputs("Refusing unsupported SRX path or hash\n",stderr);goto done;}
 wcscpy(modulePath,path);wcscpy(wcsrchr(modulePath,L'\\')+1,L"1\\sr1.dll");if(!hashFile(modulePath,hash)||!hashMatches(hash,p->moduleSha256)){fputs("Refusing unsupported SR1 module hash\n",stderr);goto done;}
 uintptr_t base=0;DWORD imageSize=0;HANDLE snapshot=CreateToolhelp32Snapshot(TH32CS_SNAPMODULE,pid);MODULEENTRY32W m={0};m.dwSize=sizeof(m);
 if(snapshot!=INVALID_HANDLE_VALUE){if(Module32FirstW(snapshot,&m))do{if(!_wcsicmp(m.szExePath,modulePath)){base=(uintptr_t)m.modBaseAddr;imageSize=m.modBaseSize;break;}}while(Module32NextW(snapshot,&m));CloseHandle(snapshot);}
 if(!base||imageSize<0x2a89318){fputs("Supported SR1 module not loaded\n",stderr);result=4;goto done;}
 FILETIME created,exited,kernel,user;if(!GetProcessTimes(process,&created,&exited,&kernel,&user)){fputs("Cannot bind process creation identity\n",stderr);goto done;}
 const unsigned long long identity=((unsigned long long)created.dwHighDateTime<<32)|created.dwLowDateTime;
 printf("{\"type\":\"session\",\"schemaVersion\":%u,\"pid\":%lu,\"moduleHash\":\"%s\",\"processCreatedFiletime\":\"%llu\",\"sheetSourceHash\":\"%s\",\"mode\":\"read-only-host-block\"}\n",HOST_BLOCK_OBSERVATION_SCHEMA,pid,hash,identity,EXPLORATION_SHEET_SHA256);
 unsigned valid=0;
 for(unsigned long i=0;i<count;i++){
  uintptr_t actor=0,again=0;HostBlockState state={0};
#ifdef HOST_BLOCK_ANIMATION_OBSERVER
  uint16_t animationIds[3]={0};
  if(readMemory(process,base+(uintptr_t)p->currentActorRva,&actor,8)&&actorIdentity(process,actor))state=hostBlockAnimationStateRead(process,readMemory,executable,base,imageSize,actor,animationIds);
#else
  if(readMemory(process,base+(uintptr_t)p->currentActorRva,&actor,8)&&actorIdentity(process,actor))state=hostBlockStateRead(process,readMemory,executable,base,imageSize,actor);
#endif
  if(state.valid&&(!actorIdentity(process,actor)||!readMemory(process,base+(uintptr_t)p->currentActorRva,&again,8)||again!=actor))state=(HostBlockState){0};
  printf("{\"type\":\"sample\",\"sequence\":%lu,\"tickMs\":%llu,\"valid\":%s",i,(unsigned long long)GetTickCount64(),state.valid?"true":"false");
  if(state.valid){valid++;printf(",\"flagsMask\":%u,\"engagementPresent\":%s,\"entryPresent\":%s,\"heldPresent\":%s,\"slotsEqual\":%s,\"relationKnown\":%s,\"relationEqual\":%s,\"ownerRelationZero\":%s,\"targetRelationZero\":%s,\"sections\":[",state.flagsMask,state.engagementPresent?"true":"false",state.entryPresent?"true":"false",state.heldPresent?"true":"false",state.slotsEqual?"true":"false",state.relationKnown?"true":"false",state.relationEqual?"true":"false",state.ownerRelationZero?"true":"false",state.targetRelationZero?"true":"false");
   for(unsigned k=0;k<3;k++){HostBlockSection *s=&state.sections[k];if(k)putchar(',');printf("{\"section\":%u,\"callbackRva\":%u,\"readIndex\":%u,\"writeIndex\":%u,\"pending\":%s",k,s->callbackRva,s->readIndex,s->writeIndex,s->pending?"true":"false");if(s->pending)printf(",\"messageId\":%u,\"payloadZero\":%s",s->messageId,s->payloadZero?"true":"false");
#ifdef HOST_BLOCK_ANIMATION_OBSERVER
    printf(",\"animationId\":%u",(unsigned)animationIds[k]);
#endif
    putchar('}');}putchar(']');
  }
  puts("}");fflush(stdout);if(i+1<count)Sleep(interval);
 }
 result=valid?0:6;
done:
 CloseHandle(process);return result;
}
