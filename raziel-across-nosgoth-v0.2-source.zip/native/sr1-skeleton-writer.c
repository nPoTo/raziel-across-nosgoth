// SPDX-License-Identifier: GPL-3.0-or-later
// Private one-writer RAM mapping. Only skeleton snapshots arrive via stdin.
#define WIN32_LEAN_AND_MEAN
#include "sr1-skeleton-shared.h"
#include <stdio.h>
#include <stdlib.h>
#include <io.h>
#include <fcntl.h>
int main(int argc,char **argv){
 char *end=NULL;unsigned long pid=argc==2?strtoul(argv[1],&end,10):0;
 if(!pid||!end||*end||GetFileType(GetStdHandle(STD_INPUT_HANDLE))!=FILE_TYPE_PIPE)return 1;
 HANDLE host=OpenProcess(SYNCHRONIZE,FALSE,pid);if(!host)return 2;wchar_t name[96];skeletonNames(name,pid);
 SetLastError(0);HANDLE map=CreateFileMappingW(INVALID_HANDLE_VALUE,NULL,PAGE_READWRITE,0,sizeof(SkeletonShared),name);bool exists=GetLastError()==ERROR_ALREADY_EXISTS;
 SkeletonShared *view=map&&!exists?MapViewOfFile(map,FILE_MAP_WRITE|FILE_MAP_READ,0,0,sizeof(SkeletonShared)):NULL;
 if(!view){if(map)CloseHandle(map);CloseHandle(host);return 3;}
 _setmode(_fileno(stdin),_O_BINARY);SkeletonSnapshot s={0};unsigned frames=0;uint64_t sequence=0,epoch=0;int result=4;size_t got;
#ifdef SR1_SKELETON_CADENCE60
 uint64_t first=0,last=0,reported=0;unsigned maxGap=0,adapted=0;
#endif
 while((got=fread(&s,1,sizeof(s),stdin))==sizeof(s)){
  if(WaitForSingleObject(host,0)!=WAIT_TIMEOUT||s.writerPid!=GetCurrentProcessId()||!skeletonPacketValid(&s,pid,GetTickCount64())||s.sequence<=sequence||(epoch&&s.epoch!=epoch))goto done;
  sequence=s.sequence;epoch=s.epoch;skeletonStore(view,&s);frames++;
#ifdef SR1_SKELETON_CADENCE60
  uint64_t stamp=GetTickCount64();if(!first)first=stamp;if(last&&stamp-last>maxGap)maxGap=(unsigned)(stamp-last);last=stamp;adapted+=s.mode==2;
  if(!reported||stamp-reported>=1000){printf("{\"type\":\"published\",\"count\":%u,\"adapted\":%u,\"firstTick\":%llu,\"lastTick\":%llu,\"maxGapMs\":%u}\n",frames,adapted,(unsigned long long)first,(unsigned long long)last,maxGap);fflush(stdout);reported=stamp;}
#endif
 }
 result=got==0&&feof(stdin)&&!ferror(stdin)&&frames?0:5;
done:memset(&s,0,sizeof(s));skeletonStore(view,&s);
#ifdef SR1_SKELETON_CADENCE60
 printf("{\"type\":\"published\",\"final\":true,\"count\":%u,\"adapted\":%u,\"firstTick\":%llu,\"lastTick\":%llu,\"maxGapMs\":%u}\n",frames,adapted,(unsigned long long)first,(unsigned long long)last,maxGap);fflush(stdout);
#endif
 fprintf(stderr,"Skeleton RAM snapshots=%u exit=%d; mapping cleared\n",frames,result);UnmapViewOfFile(view);CloseHandle(map);CloseHandle(host);return result;
}
