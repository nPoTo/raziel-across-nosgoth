// SPDX-License-Identifier: GPL-3.0-or-later
#pragma once
typedef struct {uint32_t magic,pid;uint64_t epoch,tick,actor,sequence;double forward;uint32_t valid,reserved;} CombatTravelSnapshot;
typedef struct {volatile LONG sequence;CombatTravelSnapshot value;} CombatTravelShared;
static inline void combatTravelName(wchar_t name[96],DWORD pid){_snwprintf(name,96,L"Local\\LOKCombatTravel-%lu",pid);}
static inline bool combatTravelCopy(const CombatTravelShared *m,CombatTravelSnapshot *s){if(!m)return false;for(unsigned i=0;i<3;i++){LONG a=m->sequence;if(a&1)continue;MemoryBarrier();memcpy(s,&m->value,sizeof(*s));MemoryBarrier();if(a==m->sequence)return true;}return false;}
static inline void combatTravelStore(CombatTravelShared *m,const CombatTravelSnapshot *s){InterlockedIncrement(&m->sequence);MemoryBarrier();memcpy(&m->value,s,sizeof(*s));MemoryBarrier();InterlockedIncrement(&m->sequence);}
