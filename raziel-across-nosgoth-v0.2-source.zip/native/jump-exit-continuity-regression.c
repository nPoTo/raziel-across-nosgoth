// SPDX-License-Identifier: GPL-3.0-or-later
#include <assert.h>
#include <stdio.h>
#define SR1_JUMP_EXIT_CONTINUOUS 1
#include "sr1-jump-exit-blend.h"
int main(void){
 const float pi=3.14159265358979323846f,a[3]={1,0,0};float old[2][3],fixed[2][3];JumpArc arc={0};
 for(unsigned i=0;i<2;i++){float angle=(179+2*i)*pi/180,b[3]={cosf(angle),sinf(angle),0};jumpEdge(a,b,.5f,old[i]);assert(jumpArcEdge(a,b,.5f,&arc,fixed[i]));}
 float oldStep=0,newStep=0;for(unsigned k=0;k<3;k++){oldStep+=(old[1][k]-old[0][k])*(old[1][k]-old[0][k]);newStep+=(fixed[1][k]-fixed[0][k])*(fixed[1][k]-fixed[0][k]);}
 oldStep=sqrtf(oldStep);newStep=sqrtf(newStep);assert(oldStep>1.99f&&newStep<.018f);
 printf("PASS actual native exit edge regression: old step %.6f, continuous step %.6f for unit edge,179->181deg; numerical proof only.\n",oldStep,newStep);return 0;
}
