// Exact supported AutoFace code, offline module/unwind/semantic checks.
#define HOST_LOCK_RVA 0xec860
#define HOST_LOCK_SIZE 1799
#define HOST_LOCK_SHA "9d1e0ee587c3d845b3a1e38741a0f5e82f722ad71693453476b387a11dcb3ebb"
