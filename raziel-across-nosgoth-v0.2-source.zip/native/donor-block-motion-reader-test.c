// SPDX-License-Identifier: GPL-3.0-or-later
#define main targetFixtureUnused
#include "donor-block-targets-test.c"
#undef main
#include "donor-block-motion-reader.h"
static unsigned positionReads;
static bool motionRead(void *c,uintptr_t address,void *out,SIZE_T n){uintptr_t u=0x70000000;
 if(address==u+8&&n==8){uintptr_t h=base+(defect==16?0xce4c8:0xce4c0);memcpy(out,&h,8);return true;}
 if(address==u&&n==4){uint32_t f=5;memcpy(out,&f,4);return true;}if(address==u+0x78&&n==4){uint32_t s=3;memcpy(out,&s,4);return true;}
 if(address==u+0x70&&n==8){float d[2]={1,0};if(defect==18)d[1]=NAN;memcpy(out,d,8);return true;}
 if(address==target+0x20&&n==12){float p[3]={20,30,0};if(defect==17&&++positionReads>1)p[0]++;memcpy(out,p,12);return true;}return readFixture(c,address,out,n);
}
static bool motionCode(void *c,uintptr_t a,uintptr_t b){return a==base+0xce4c0||a==base+0xce4c8||codeFixture(c,a,b);}
static int inspect(uintptr_t t,DonorBlockMotionMetadata *m){roots=ctxReads=entryReads=callbackReads=userdataReads=positionReads=0;return donorBlockMotionRead(NULL,motionRead,motionCode,base,0x2000000,actor,t,m);}
int main(void){DonorBlockMotionMetadata m;CHECK(inspect(target,&m)==1&&m.opaqueActor==actor&&m.opaqueState==state&&m.opaqueUserdata==0x70000000&&m.handler==0xce4c0&&m.flags==5&&m.selector==3&&m.direction[0]==1&&m.position[1]==30,1);CHECK(inspect(target+8,&m)==0,2);for(defect=1;defect<=5;defect++)CHECK(inspect(target,&m)==-1,defect+2);for(defect=16;defect<=18;defect++)CHECK(inspect(target,&m)==-1,defect);defect=0;idle=true;CHECK(inspect(target,&m)==0,19);idle=false;CHECK(inspect(target+1,&m)==-1,20);puts("PASS: production exact current-slot target motion metadata, actor/context/slot/userdata races, code whitelist, unrelated target, changed field double-read and nonfinite refusal");return 0;}
