#include <stdbool.h>
#include <stdint.h>
#include <string.h>
#include <math.h>
#include <stdio.h>
#include "host-transform.h"
int main(void) {
    unsigned char raw[32]={0}; int16_t rotation[9]={0,-4096,0,4096,0,0,0,0,4096}; int32_t position[3]={100,200,-300};
    memcpy(raw,rotation,18); memcpy(raw+20,position,12); float root[16];
    if(!decodeHostRoot(raw,root)||root[1]!=1||root[4]!=-1||root[12]!=100||root[14]!=-300) return 1;
    float identity[16]={1,0,0,0,0,1,0,0,0,0,1,0,0,0,0,1},product[16]; hostMultiply(root,identity,product);
    if(memcmp(root,product,sizeof(root))) return 2;
    hostMultiply(identity,root,identity); if(memcmp(root,identity,sizeof(root))) return 3; // alias-safe
    rotation[8]=-4096; memcpy(raw,rotation,18); if(decodeHostRoot(raw,root)) return 4;
    rotation[8]=4096; rotation[1]=-2048; memcpy(raw,rotation,18); if(decodeHostRoot(raw,root)) return 5;
    memcpy(raw,(int16_t[9]){4096,0,0,0,4096,0,0,0,4096},18); position[0]=1000001; memcpy(raw+20,position,12); if(decodeHostRoot(raw,root)) return 6;
    unsigned char hd[52]={0};float hdRotation[9]={0,-1,0,1,0,0,0,0,1},hdPosition[3]={100.25f,200.5f,-300.75f};memcpy(hd,hdRotation,36);memcpy(hd+40,hdPosition,12);
    if(!decodeHostRenderRoot(hd,root)||root[1]!=1||root[4]!=-1||root[12]!=100.25f||root[14]!=-300.75f)return 7;
    hdPosition[0]=NAN;memcpy(hd+40,hdPosition,12);if(decodeHostRenderRoot(hd,root))return 8;
    hdPosition[0]=100.25f;memcpy(hd+40,hdPosition,12);hdRotation[8]=-1;memcpy(hd,hdRotation,36);if(decodeHostRenderRoot(hd,root))return 9;
    puts("Host transform test: PASS (legacy and renderer HD layout, fractional translation, rotation, multiplication, aliasing, malformed rejection)"); return 0;
}
