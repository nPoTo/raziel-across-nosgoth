#include "general-test-budget.h"
// SPDX-License-Identifier: GPL-3.0-or-later
#include "combat-local-step.h"
#include "combat-travel-shared.h"
static volatile LONG combatTravelLock;
static CombatTravelShared *combatTravelView;static HANDLE combatTravelMapping;static volatile LONG combatTravelEnabled;static CombatTravelSnapshot combatTravelCurrent;
static void combatTravelSample(uintptr_t actor,const float current[3],const float anchor[2],uint64_t tick){
 directMotionSample(actor,current,anchor,tick);
 if(!InterlockedCompareExchange(&combatTravelEnabled,0,0)||!combatTravelView||InterlockedCompareExchange(&combatTravelLock,1,0))return;
 uintptr_t state=0,buffer=0;float factor=0,root[16];double local[2];bool ground=true;
 bool ok=donorProcessIdentity(actor)&&worldRead(actor+0x3f8,&state,8)&&state&&state%8==0&&state<=UINTPTR_MAX-0x500&&donorProcessMotion(actor,&factor,root,&buffer)&&combatLocalStep(root,current,anchor,local);
 for(unsigned i=0;i<3&&ok;i++){uintptr_t p[2];ok=worldRead(state+i*0x250+0x10,p,sizeof(p));if(ok&&(p[0]!=donorProcessBase+0x125340||p[1]!=donorProcessBase+0x125620))ground=false;}
 CombatTravelSnapshot *s=&combatTravelCurrent;
 if(!s->epoch){*s=(CombatTravelSnapshot){.magic=0x31545a52,.pid=GetCurrentProcessId(),.epoch=tick,.actor=actor};}
 ok=ok&&s->actor==actor&&tick>=s->tick&&tick>=s->epoch&&tick-s->epoch<GENERAL_OR_SHORT_MS(140000);
 if(ok&&ground)s->forward+=local[1];
 ok=ok&&isfinite(s->forward)&&fabs(s->forward)<=100000;s->tick=tick;s->sequence++;s->valid=ok;combatTravelStore(combatTravelView,s);
 if(!ok)InterlockedExchange(&combatTravelEnabled,0);InterlockedExchange(&combatTravelLock,0);
}
static void combatTravelSourceTick(void){
 const Sheet_combatTravelPolicy *policy=&sheet_combatTravelPolicy_bounded;
 if(policy->enabled||policy->primaryRva!=0x125340||policy->secondaryRva!=0x125620||policy->freshMs!=150||policy->maxStep!=240||policy->maxCumulative!=100000||policy->hostPositionWrites||policy->hostFacingWrites||!policy->groundOnly){InterlockedExchange(&combatTravelEnabled,0);return;}
 bool requested=GetFileAttributesW(PROBE_PATH(L"\\combat-travel-donor.enable"))!=INVALID_FILE_ATTRIBUTES&&InterlockedCompareExchange(&donorAnchorEnabled,0,0)&&!InterlockedCompareExchange(&probeBoundedComplete,0,0);
 if(requested&&!combatTravelView){wchar_t name[96];combatTravelName(name,GetCurrentProcessId());SetLastError(0);combatTravelMapping=CreateFileMappingW(INVALID_HANDLE_VALUE,NULL,PAGE_READWRITE,0,sizeof(CombatTravelShared),name);bool exists=GetLastError()==ERROR_ALREADY_EXISTS;if(combatTravelMapping&&!exists)combatTravelView=MapViewOfFile(combatTravelMapping,FILE_MAP_WRITE|FILE_MAP_READ,0,0,sizeof(CombatTravelShared));}
 // No rearming after a live invalid source. New process required for a new epoch.
 if(requested&&combatTravelView&&!combatTravelCurrent.epoch)InterlockedExchange(&combatTravelEnabled,1);
 if(!requested){InterlockedExchange(&combatTravelEnabled,0);if(combatTravelView&&!InterlockedCompareExchange(&combatTravelLock,1,0)){CombatTravelSnapshot empty={0};combatTravelStore(combatTravelView,&empty);InterlockedExchange(&combatTravelLock,0);}}
}
