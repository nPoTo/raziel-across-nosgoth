// SPDX-License-Identifier: GPL-3.0-or-later
#pragma once
#include "donor-contact-scope.h"
typedef void (*DonorLineOriginal)(uintptr_t,DonorContactLine *,uint32_t);
typedef int32_t (*DonorCachedOriginal)(uintptr_t,uintptr_t,float *,float *,uintptr_t);
// Used by the real detours and the ABI forwarding test. The caller has already
// pinned actor identity and copied its position at the owning frame boundary.
static inline bool donorContactDispatchLine(DonorLineOriginal original,DonorContactProjection *scope,
 uintptr_t caller,uintptr_t actor,DonorContactLine *line,uint32_t opaque,const float position[3]){
 if(donorContactProjectLine(scope,caller,actor,line,position))return true;
 if(scope&&(caller==0x103bf5||caller==0x103c47))scope->poisoned=true;
 original(actor,line,opaque);return false;
}
static inline int32_t donorContactDispatchCached(DonorCachedOriginal original,DonorContactProjection *scope,
 uintptr_t caller,uintptr_t level,uintptr_t segment,float *end,float *start,uintptr_t triangle){
 if(donorContactSkipCached(scope,caller))return 0;
 return original(level,segment,end,start,triangle);
}
