// SPDX-License-Identifier: GPL-3.0-or-later
#pragma once
#include <windows.h>
#include <wchar.h>
#include "reaver-presentation-lease.h"
typedef struct {uint32_t magic,version,online,size;unsigned char packet[REAVER_PRESENTATION_CAPACITY];} ReaverPresentationMemory;
static void reaverPresentationNames(const ReaverPacketSession *s,wchar_t map[160],wchar_t mutex[160]){
 swprintf(map,160,L"Local\\LOKWeaponFrame-v1-%lu-%llu-%lu-%llu",(unsigned long)s->hostPid,(unsigned long long)s->hostCreation,(unsigned long)s->writerPid,(unsigned long long)s->writerCreation);
 swprintf(mutex,160,L"%ls-lock",map);
}
static bool reaverPresentationProcess(uint32_t pid,uint64_t creation){
 HANDLE h=OpenProcess(PROCESS_QUERY_LIMITED_INFORMATION|SYNCHRONIZE,FALSE,pid);if(!h)return false;
 FILETIME born,exit,kernel,user;bool ok=false;
 if(GetProcessTimes(h,&born,&exit,&kernel,&user)&&WaitForSingleObject(h,0)==WAIT_TIMEOUT){uint64_t got=((uint64_t)born.dwHighDateTime<<32)|born.dwLowDateTime;ok=got==creation;}
 CloseHandle(h);return ok;
}
// Called with a pre-admitted session. All waits are zero-time, mappings read-only,
// and copied data is validated AFTER the lock is released. Never call GL here.
static bool reaverPresentationRead(ReaverPresentationLease *l,unsigned char scratch[REAVER_PRESENTATION_CAPACITY],uint64_t now){
 if(!l||!scratch)return false;bool ok=false;size_t size=0;
 if(l->session.hostPid!=GetCurrentProcessId()||!reaverPresentationProcess(l->session.hostPid,l->session.hostCreation)||
 !reaverPresentationProcess(l->session.writerPid,l->session.writerCreation)||!reaverPresentationProcess(l->session.donorPid,l->session.donorCreation)){reaverPresentationClear(l);return false;}
 wchar_t name[160],lockName[160];reaverPresentationNames(&l->session,name,lockName);
 HANDLE map=OpenFileMappingW(FILE_MAP_READ,FALSE,name),lock=NULL;const ReaverPresentationMemory *view=NULL;
 if(map){lock=OpenMutexW(SYNCHRONIZE|MUTEX_MODIFY_STATE,FALSE,lockName);if(lock)view=MapViewOfFile(map,FILE_MAP_READ,0,0,sizeof(*view));}
 if(view){DWORD wait=WaitForSingleObject(lock,0);
  if(wait==WAIT_OBJECT_0){
   if(view->magic==0x314d5752&&view->version==1&&view->online==1&&view->size>=128&&view->size<=REAVER_PRESENTATION_CAPACITY){size=view->size;memcpy(scratch,view->packet,size);ok=true;}
   ReleaseMutex(lock);
  }else if(wait==WAIT_ABANDONED)ReleaseMutex(lock);
 }
 if(view)UnmapViewOfFile(view);if(lock)CloseHandle(lock);if(map)CloseHandle(map);
 if(!ok){reaverPresentationClear(l);return false;}
 return reaverPresentationAccept(l,scratch,size,now);
}
