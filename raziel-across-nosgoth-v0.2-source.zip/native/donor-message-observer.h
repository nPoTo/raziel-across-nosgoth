// SPDX-License-Identifier: GPL-3.0-or-later
#pragma once
#ifndef WIN32_LEAN_AND_MEAN
#define WIN32_LEAN_AND_MEAN
#endif
#include <windows.h>
#include <stdbool.h>
#include <stdint.h>
#include <string.h>
#include "exploration-sheets.h"
#include "donor-message-dispatch-proof.h"

#define DONOR_MESSAGE_OBSERVER_CAPACITY 512U
enum { DONOR_MESSAGE_ENTER=1,DONOR_MESSAGE_EXIT=2 };
typedef struct {
 bool enabled;
 uint64_t session,startTick,heartbeatTick,nowTick;
} DonorMessageLease;
typedef struct {
 uint32_t messageId;
 bool payloadZero;
 uint32_t firstRva[3],secondRva[3],secondValidMask;
} DonorMessageMetadata;
typedef bool (*DonorMessageLeaseRead)(void *,DonorMessageLease *);
// Called with after=false before native dispatch. Read only guarded state/message
// metadata. after=true MUST NOT dereference message: it may have been consumed;
// return only the current guarded callback RVAs. Message ID/payloadZero are retained.
// Both callbacks must be bounded/nonblocking: no locks, allocation, handles or I/O.
typedef bool (*DonorMessageSnapshotRead)(void *,void *,int32_t,void *,bool,DonorMessageMetadata *);
typedef struct {
 uint64_t session,callId,tickMs;
 uint32_t threadId,depth,phase,section,messageId,payloadZero,afterValid;
 uint32_t beforeFirstRva[3],beforeSecondRva[3],beforeSecondMask;
 uint32_t afterFirstRva[3],afterSecondRva[3],afterSecondMask;
} DonorMessageEvent;
_Static_assert(sizeof(DonorMessageEvent)==112,"Scalar-only message event shape");
// Caller owns zero-initialized, nonallocating per-native-thread storage. Keep it
// alive through all recursive calls. Do not share or reset it on active threads.
typedef struct {volatile LONG ownerThread;uint32_t depth;} DonorMessageObserverThread;
typedef struct {
 uint64_t forwarded,dropped,published,contentionDrops,queueFullDrops,budgetDrops,metadataDrops,leaseDrops,depthDrops;
} DonorMessageObserverStats;
typedef struct {
 SRWLOCK queueLock;
 DonorMessageEvent queue[DONOR_MESSAGE_OBSERVER_CAPACITY];
 uint32_t head,tail,count;
 volatile LONG64 forwarded,dropped,published,nextCallId,contentionDrops,queueFullDrops,budgetDrops,metadataDrops,leaseDrops,depthDrops;
 void *context;
 DonorMessageLeaseRead readLease;
 DonorMessageSnapshotRead readSnapshot;
 bool configured;
} DonorMessageObserver;

// Initialization/reset is permitted only before hook activation or after all hook
// invocations and the collector have quiesced. The raw-row budget spans one init;
// a lease/session change never resets counters or the queue under active writers.
static inline void donorMessageObserverInit(DonorMessageObserver *o,void *context,DonorMessageLeaseRead lease,DonorMessageSnapshotRead snapshot){
 const Sheet_donorMessageObservationPolicy *p=&sheet_donorMessageObservationPolicy_bounded;
 memset(o,0,sizeof(*o));InitializeSRWLock(&o->queueLock);o->context=context;o->readLease=lease;o->readSnapshot=snapshot;
 o->configured=lease&&snapshot&&p->plan==11&&p->seconds==60&&p->maxRecords==20000&&p->rawMaxRecords==120000&&p->queueCapacity==DONOR_MESSAGE_OBSERVER_CAPACITY&&p->maxDepth==32&&p->leaseMs==1500&&p->skipTick==0x100000&&p->skipBefore==0x100017&&p->skipAfter==0x100018;
}
static inline void donorMessageObserverDrop(DonorMessageObserver *o,volatile LONG64 *reason){InterlockedIncrement64(&o->dropped);InterlockedIncrement64(reason);}
static inline bool donorMessageLeaseValid(const DonorMessageLease *l){
 const Sheet_donorMessageObservationPolicy *p=&sheet_donorMessageObservationPolicy_bounded;
 return l->enabled&&l->session&&l->nowTick>=l->startTick&&l->heartbeatTick>=l->startTick&&l->heartbeatTick<=l->nowTick&&l->nowTick-l->heartbeatTick<(uint64_t)p->leaseMs&&l->nowTick-l->startTick<(uint64_t)p->seconds*1000;
}
static inline bool donorMessageLeaseMatches(DonorMessageObserver *o,const DonorMessageLease *start,DonorMessageLease *now){
 return o->readLease(o->context,now)&&donorMessageLeaseValid(now)&&now->session==start->session&&now->startTick==start->startTick&&now->nowTick>=start->nowTick&&now->heartbeatTick>=start->heartbeatTick;
}
static inline bool donorMessageMetadataValid(const DonorMessageMetadata *m){
 if(m->secondValidMask>7)return false;
 for(unsigned i=0;i<3;i++)if(!m->firstRva[i]||((m->secondValidMask&(1U<<i))&&!m->secondRva[i]))return false;
 return true;
}
static inline void donorMessageEventState(DonorMessageEvent *e,const DonorMessageMetadata *m,bool after){
 uint32_t *first=after?e->afterFirstRva:e->beforeFirstRva,*second=after?e->afterSecondRva:e->beforeSecondRva;
 for(unsigned i=0;i<3;i++){first[i]=m->firstRva[i];second[i]=(m->secondValidMask&(1U<<i))?m->secondRva[i]:0;}
 if(after)e->afterSecondMask=m->secondValidMask;else e->beforeSecondMask=m->secondValidMask;
}
static inline bool donorMessageObserverPublish(DonorMessageObserver *o,const DonorMessageEvent *event){
 if(!TryAcquireSRWLockExclusive(&o->queueLock)){donorMessageObserverDrop(o,&o->contentionDrops);return false;}
 bool accepted=false;
 if(o->count>=DONOR_MESSAGE_OBSERVER_CAPACITY)donorMessageObserverDrop(o,&o->queueFullDrops);
 else if((uint64_t)InterlockedCompareExchange64(&o->published,0,0)>=(uint64_t)sheet_donorMessageObservationPolicy_bounded.rawMaxRecords)donorMessageObserverDrop(o,&o->budgetDrops);
 else{o->queue[o->tail]=*event;o->tail=(o->tail+1)%DONOR_MESSAGE_OBSERVER_CAPACITY;o->count++;InterlockedIncrement64(&o->published);accepted=true;}
 ReleaseSRWLockExclusive(&o->queueLock);return accepted;
}
// Nonblocking worker drain. False means empty OR currently busy, never wait/retry
// here. Event rows contain only scalar policy/session/call/clock/ID/RVA metadata.
static inline bool donorMessageObserverPop(DonorMessageObserver *o,DonorMessageEvent *event){
 if(!o||!event||!TryAcquireSRWLockExclusive(&o->queueLock))return false;
 bool available=o->count!=0;if(available){*event=o->queue[o->head];memset(&o->queue[o->head],0,sizeof(o->queue[o->head]));o->head=(o->head+1)%DONOR_MESSAGE_OBSERVER_CAPACITY;o->count--;}
 ReleaseSRWLockExclusive(&o->queueLock);return available;
}
// Each counter is atomic; the set is an approximate concurrent diagnostic view.
static inline DonorMessageObserverStats donorMessageObserverStatsRead(DonorMessageObserver *o){
 DonorMessageObserverStats s={0};if(!o)return s;
#define DMO_COUNT(name) s.name=(uint64_t)InterlockedCompareExchange64(&o->name,0,0)
 DMO_COUNT(forwarded);DMO_COUNT(dropped);DMO_COUNT(published);DMO_COUNT(contentionDrops);DMO_COUNT(queueFullDrops);DMO_COUNT(budgetDrops);DMO_COUNT(metadataDrops);DMO_COUNT(leaseDrops);DMO_COUNT(depthDrops);
#undef DMO_COUNT
 return s;
}
// PRECONDITION: original is the verified NON-NULL trampoline and remains alive
// throughout the invocation. This core never installs, resolves or changes hooks.
// Metadata/lease/queue failures suppress observation ONLY. Every call, including
// NULL/invalid observation arguments, forwards the exact three arguments once.
static inline uintptr_t donorMessageObserverForward(DonorMessageObserver *o,DonorMessageObserverThread *thread,DonorNativeMessageDispatch original,void *state,int32_t section,void *message){
 DWORD incomingError=GetLastError(),threadId=GetCurrentThreadId();uint32_t priorDepth=0;bool track=false,entered=false;
 DonorMessageLease begin={0},current={0};DonorMessageMetadata before={0};DonorMessageEvent event={0};
 if(thread){LONG owner=InterlockedCompareExchange(&thread->ownerThread,(LONG)threadId,0);track=owner==0||(DWORD)owner==threadId;if(track){priorDepth=thread->depth;thread->depth=priorDepth<UINT32_MAX?priorDepth+1:UINT32_MAX;}}
 if(o)InterlockedIncrement64(&o->forwarded);
 if(o&&o->configured&&track&&o->readLease(o->context,&begin)&&begin.enabled){
  if(!donorMessageLeaseValid(&begin))donorMessageObserverDrop(o,&o->leaseDrops);
  else if(priorDepth>=(uint32_t)sheet_donorMessageObservationPolicy_bounded.maxDepth)donorMessageObserverDrop(o,&o->depthDrops);
  else if(!state||!message||section<0||section>2||!o->readSnapshot(o->context,state,section,message,false,&before)||!donorMessageMetadataValid(&before))donorMessageObserverDrop(o,&o->metadataDrops);
  else if(before.messageId!=(uint32_t)sheet_donorMessageObservationPolicy_bounded.skipTick&&before.messageId!=(uint32_t)sheet_donorMessageObservationPolicy_bounded.skipBefore&&before.messageId!=(uint32_t)sheet_donorMessageObservationPolicy_bounded.skipAfter){
   if(!donorMessageLeaseMatches(o,&begin,&current))donorMessageObserverDrop(o,&o->leaseDrops);
   else{event.session=begin.session;event.callId=(uint64_t)InterlockedIncrement64(&o->nextCallId);event.tickMs=current.nowTick;event.threadId=threadId;event.depth=priorDepth+1;event.phase=DONOR_MESSAGE_ENTER;event.section=(uint32_t)section;event.messageId=before.messageId;event.payloadZero=before.payloadZero?1U:0U;donorMessageEventState(&event,&before,false);entered=donorMessageObserverPublish(o,&event);}
  }
 }
 // Restore the error presented by the native caller after all observer activity.
 SetLastError(incomingError);uintptr_t result=original(state,section,message);DWORD resultError=GetLastError();
 if(entered){
  DonorMessageMetadata after={0};
  if(!donorMessageLeaseMatches(o,&begin,&current))donorMessageObserverDrop(o,&o->leaseDrops);
  else if(!o->readSnapshot(o->context,state,section,message,true,&after)||!donorMessageMetadataValid(&after))donorMessageObserverDrop(o,&o->metadataDrops);
  else if(!donorMessageLeaseMatches(o,&begin,&current))donorMessageObserverDrop(o,&o->leaseDrops);
  else{event.tickMs=current.nowTick;event.phase=DONOR_MESSAGE_EXIT;event.afterValid=1;donorMessageEventState(&event,&after,true);donorMessageObserverPublish(o,&event);}
 }
 if(track)thread->depth=priorDepth;
 SetLastError(resultError);return result;
}
