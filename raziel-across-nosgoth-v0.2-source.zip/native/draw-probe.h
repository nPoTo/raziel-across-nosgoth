#include "report-path.h"
// SPDX-License-Identifier: GPL-3.0-or-later
// Host IAT draw observer; explicit bounded replacement may suppress verified mesh draws.
typedef void (WINAPI *DrawFn)(GLenum,GLsizei,GLenum,const void *);
static DrawFn originalDraw;
static PVOID *drawSlot;
static HGLRC drawContext;
static ULONGLONG drawBegin,drawLastFrame;
static unsigned int drawBudget,drawRecords,drawFrames,drawHidden;
static bool drawReplacementRequested;
static bool drawVisibilityRequested;
static volatile LONG drawQueueLock,drawDrops;
typedef struct {
    uint64_t tick;unsigned int frame;
    GLint program,vao,fbo,ebo,texture;
    GLenum mode,type;GLsizei count;
    bool modelValid,rootValid,restored,indexMatch,viewValid,projectionValid;
    uint64_t indexOffset;
    float model[16],root[16],view[16],projection[16];uintptr_t instance;
} DrawRecord;
static DrawRecord drawQueue[1024];
static unsigned int drawHead,drawTail;
static FILE *drawFile;
static unsigned char drawCanonicalIndices[216000],drawGpuIndices[205440];
static bool drawCanonicalReady;
#ifdef SR1_RETARGET_PREVIEW
static uint64_t retargetReplacedFrame=UINT64_MAX;
static uintptr_t retargetReplacedActor;
#endif
static void drawArm(HGLRC context) {
    drawBudget=0;
    ULONGLONG now=GetTickCount64();
    drawVisibilityRequested=GetFileAttributesW(PROBE_PATH(L"\\visibility-draw-sr1.enable"))!=INVALID_FILE_ATTRIBUTES;
    drawReplacementRequested=context&&context==overlayContext&&cameraReady&&overlayReady&&worldLastDraw&&now-worldLastDraw<250&&
        GetFileAttributesW(PROBE_PATH(L"\\replace-sr1.enable"))!=INVALID_FILE_ATTRIBUTES&&
        GetFileAttributesW(PROBE_PATH(L"\\world-sr1.enable"))!=INVALID_FILE_ATTRIBUTES;
    if(!context||!cameraReady||!originalDraw||drawRecords>=(drawVisibilityRequested?16384u:4096u)||
       GetFileAttributesW(PROBE_PATH(L"\\draw-sr1.enable"))==INVALID_FILE_ATTRIBUTES)return;
    if(!drawBegin) {drawBegin=now;drawContext=context;}
    if(context!=drawContext||now-drawBegin>(drawVisibilityRequested?150000u:60000u)||now-drawLastFrame<500)return;
    drawLastFrame=now;++drawFrames;drawBudget=drawVisibilityRequested?32:128;
}
static bool drawIdentity(GLenum mode,GLsizei count,GLenum type,const void *indices,GLint ebo) {
    if(!drawCanonicalReady||!cameraReady||mode!=GL_TRIANGLES||type!=GL_UNSIGNED_SHORT||!ebo||(count!=102720&&count!=5280))return false;
    GLint bufferSize=0;cglGetBufferParameteriv(GL_ELEMENT_ARRAY_BUFFER,GL_BUFFER_SIZE,&bufferSize);
    uint64_t offset=(uint64_t)(uintptr_t)indices,bytes=(uint64_t)count*2;
    if(bufferSize<=0||bufferSize>16777216||offset>16777216||offset+bytes>(uint64_t)bufferSize)return false;
    size_t canonicalOffset=count==102720?0:205440;
    for(size_t i=0;i<(size_t)bytes;++i)drawGpuIndices[i]=(unsigned char)(drawCanonicalIndices[canonicalOffset+i]^0xff);
    cglGetBufferSubData(GL_ELEMENT_ARRAY_BUFFER,(GLintptr)offset,(GLsizeiptr)bytes,drawGpuIndices);
    return !memcmp(drawGpuIndices,drawCanonicalIndices+canonicalOffset,(size_t)bytes);
}
static void drawObserve(GLenum mode,GLsizei count,GLenum type,const void *indices) {
    if(!drawBudget||drawRecords>=(drawVisibilityRequested?16384u:4096u)||wglGetCurrentContext()!=drawContext||count<=0||count>6000000||mode!=GL_TRIANGLES)return;
    --drawBudget;
    DrawRecord record={0};record.tick=GetTickCount64();record.frame=drawFrames;record.mode=mode;record.type=type;record.count=count;
    glGetIntegerv(GL_CURRENT_PROGRAM,&record.program);
    if(record.program==(GLint)overlayProgram)return;
    glGetIntegerv(GL_VERTEX_ARRAY_BINDING,&record.vao);glGetIntegerv(GL_DRAW_FRAMEBUFFER_BINDING,&record.fbo);
    glGetIntegerv(GL_ELEMENT_ARRAY_BUFFER_BINDING,&record.ebo);glGetIntegerv(GL_TEXTURE_BINDING_2D,&record.texture);
    record.indexOffset=(uint64_t)(uintptr_t)indices;
    record.indexMatch=drawIdentity(mode,count,type,indices,record.ebo);
    GLint savedBuffer=0;glGetIntegerv(GL_UNIFORM_BUFFER_BINDING,&savedBuffer);
    for(unsigned int i=0;i<cameraFieldCount;++i) {
        CameraField *f=&cameraFields[i];
        if(f->program!=(GLuint)record.program)continue;
        float *matrix=NULL;bool *valid=NULL;
        if(!strcmp(f->field,"uModelMatrix")){matrix=record.model;valid=&record.modelValid;}
        else if(drawVisibilityRequested&&!strcmp(f->field,"uViewMatrix")){matrix=record.view;valid=&record.viewValid;}
        else if(drawVisibilityRequested&&!strcmp(f->field,"uProjMatrix")){matrix=record.projection;valid=&record.projectionValid;}
        if(!matrix)continue;
        GLint buffer=0;*valid=cameraRead(f,matrix,&buffer);
        if(*valid&&f->rowMajor){float copy[16];memcpy(copy,matrix,sizeof(copy));for(int row=0;row<4;++row)for(int col=0;col<4;++col)matrix[col*4+row]=copy[row*4+col];}
    }
    pglBindBuffer(GL_UNIFORM_BUFFER,(GLuint)savedBuffer);
    GLint after=0;glGetIntegerv(GL_UNIFORM_BUFFER_BINDING,&after);record.restored=after==savedBuffer;
    record.rootValid=worldRoot(record.root,&record.instance);
    if(InterlockedCompareExchange(&drawQueueLock,1,0)){InterlockedIncrement(&drawDrops);return;}
    unsigned int next=(drawHead+1)%ARRAYSIZE(drawQueue);
    if(next==drawTail)InterlockedIncrement(&drawDrops);
    else {drawQueue[drawHead]=record;drawHead=next;++drawRecords;}
    InterlockedExchange(&drawQueueLock,0);
    if(!record.restored)drawBudget=0;
}
#ifdef SR1_REAVER_GPU_RECEIPT
#include "reaver-host-gpu-observe.h"
#ifdef SR1_REAVER_PRESENTATION
#include "reaver-host-presentation.h"
#endif
#endif
static void WINAPI observeDraw(GLenum mode,GLsizei count,GLenum type,const void *indices) {
#ifdef SR1_REAVER_GPU_RECEIPT
    reaverHostGpuObserve(mode,count,type,indices);
#endif
    lightDrawObserve(mode,count,type,indices);
    drawObserve(mode,count,type,indices);
#ifdef SR1_RETARGET_PREVIEW
    // Present at the original opaque draw, not a later SwapBuffers clone.
    // Original is skipped only AFTER replacement succeeded in this call.
    // Thus native entry/failure has no queued suppression or double-body frame.
    if(overlayReady&&drawCanonicalReady&&wglGetCurrentContext()==overlayContext&&mode==GL_TRIANGLES&&type==GL_UNSIGNED_SHORT&&(count==102720||count==5280)&&
       GetFileAttributesW(PROBE_PATH(L"\\replace-sr1.enable"))!=INVALID_FILE_ATTRIBUTES){
        uintptr_t actor=0;float root[16];GLint ebo=0,fbo=0;glGetIntegerv(GL_DRAW_FRAMEBUFFER_BINDING,&fbo);glGetIntegerv(GL_ELEMENT_ARRAY_BUFFER_BINDING,&ebo);
        if(!fbo&&worldRoot(root,&actor)&&sr1RetargetAllowed(actor)&&drawIdentity(mode,count,type,indices,ebo)){
            uint64_t frame=(uint64_t)InterlockedCompareExchange64(&swapCalls,0,0);
            if(count==102720){unsigned before=worldDraws;OverlayState saved;overlaySave(&saved);overlayUpdateLive();overlayRestore(&saved);worldDraw(overlayContext);if(worldDraws!=before&&worldLastInstance==actor){retargetReplacedFrame=frame;retargetReplacedActor=actor;++drawHidden;return;}}
            else if(retargetReplacedFrame==frame&&retargetReplacedActor==actor){++drawHidden;return;}
        }
    }
#else
    if(drawReplacementRequested&&wglGetCurrentContext()==overlayContext&&GetTickCount64()-worldLastDraw<250) {
        float root[16];uintptr_t instance=0;GLint ebo=0;
        glGetIntegerv(GL_ELEMENT_ARRAY_BUFFER_BINDING,&ebo);
        if(worldRoot(root,&instance)&&instance==worldLastInstance&&drawIdentity(mode,count,type,indices,ebo)) {
            ++drawHidden;
            if(drawHidden==1||drawHidden%600==0)logLine("REPLACE_SR1 hidden_draws=%u exact_index_match=1 source=%p; visual preview only",drawHidden,(void *)instance);
            return;
        }
    }
#endif
    if(!lightDrawReplace(mode,count,type,indices))originalDraw(mode,count,type,indices);
#ifdef SR1_REAVER_PRESENTATION
    reaverHostPresentation(mode,count,type,indices);
#endif
}
static void drawInit(void) {
    const wchar_t *asset=L"C:\\Program Files (x86)\\Steam\\steamapps\\common\\Soul Reaver I-II\\1\\OBJECT\\RAZIEL_1.SRM";
    char digest[65];
    if(hashFile(asset,digest)&&!strcmp(digest,"e51ad998a9b4e5693c491cd7343d6391c3e568a9929a46a4bbf51722b4417812")) {
        FILE *mesh=_wfopen(asset,L"rb");
        if(mesh){drawCanonicalReady=!fseek(mesh,649764,SEEK_SET)&&fread(drawCanonicalIndices,sizeof(drawCanonicalIndices),1,mesh)==1&&fgetc(mesh)==EOF;fclose(mesh);}
    }
    logLine("DRAW_OBSERVER canonical SR1 Raziel index identity ready=%d; no suppression",drawCanonicalReady);
    wchar_t path[32768];_snwprintf(path,ARRAYSIZE(path),PROBE_PATH(L"\\sr1-draws-%lu.jsonl"),GetCurrentProcessId());
    drawFile=_wfopen(path,L"wb");
    if(drawFile){fprintf(drawFile,"{\"type\":\"session\",\"schema\":2,\"pid\":%lu,\"mode\":\"observe-only\",\"limit\":4096,\"visibilityLimit\":16384}\n",GetCurrentProcessId());fflush(drawFile);}
}
static void drawMatrix(FILE *out,const float matrix[16]) {
    fputc('[',out);for(int i=0;i<16;++i){if(i)fputc(',',out);fprintf(out,"%.9g",matrix[i]);}fputc(']',out);
}
static void drawFlush(void) {
    if(!drawFile)return;
    DrawRecord records[1024];unsigned int count=0;
    if(InterlockedCompareExchange(&drawQueueLock,1,0))return;
    while(drawTail!=drawHead){records[count++]=drawQueue[drawTail];drawTail=(drawTail+1)%ARRAYSIZE(drawQueue);}
    InterlockedExchange(&drawQueueLock,0);
    for(unsigned int i=0;i<count;++i){DrawRecord *r=&records[i];
        fprintf(drawFile,"{\"type\":\"draw\",\"tickMs\":%llu,\"frame\":%u,\"program\":%d,\"vao\":%d,\"fbo\":%d,\"ebo\":%d,\"texture\":%d,\"primitive\":%u,\"indexType\":%u,\"count\":%d,\"restored\":%s,\"instance\":\"0x%llx\",\"model\":",
            (unsigned long long)r->tick,r->frame,r->program,r->vao,r->fbo,r->ebo,r->texture,r->mode,r->type,r->count,r->restored?"true":"false",(unsigned long long)r->instance);
        if(r->modelValid)drawMatrix(drawFile,r->model);else fprintf(drawFile,"null");
        fprintf(drawFile,",\"indexOffset\":%llu,\"canonicalIndexMatch\":%s,\"root\":",(unsigned long long)r->indexOffset,r->indexMatch?"true":"false");if(r->rootValid)drawMatrix(drawFile,r->root);else fprintf(drawFile,"null");
        fprintf(drawFile,",\"view\":");if(r->viewValid)drawMatrix(drawFile,r->view);else fprintf(drawFile,"null");
        fprintf(drawFile,",\"projection\":");if(r->projectionValid)drawMatrix(drawFile,r->projection);else fprintf(drawFile,"null");fprintf(drawFile,"}\n");
    }
    if(count)fflush(drawFile);
}
