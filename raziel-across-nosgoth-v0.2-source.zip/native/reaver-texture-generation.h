// SPDX-License-Identifier: GPL-3.0-or-later
#pragma once
#include "reaver-gl-render.h"
#ifndef REAVER_TEXTURE_GENERATION_UPLOAD
#define REAVER_TEXTURE_GENERATION_UPLOAD reaverGLTexture
#endif
typedef struct {unsigned slot,sourceId,width,height;size_t bytes;const unsigned char *pixels;bool linear,repeat;} ReaverTextureView;
typedef struct {ReaverGL gl;uint64_t generation;unsigned sourceIds[128];} ReaverTextureGeneration;
static bool reaverTexturesPrivate(const ReaverGL *r){
 if(!r->context)return true;if(r->context!=wglGetCurrentContext())return false;
 GLint program=0,vao=0,array=0,element=0,units=0,active=0;
 glGetIntegerv(GL_CURRENT_PROGRAM,&program);glGetIntegerv(GL_VERTEX_ARRAY_BINDING,&vao);glGetIntegerv(GL_ARRAY_BUFFER_BINDING,&array);glGetIntegerv(GL_ELEMENT_ARRAY_BUFFER_BINDING,&element);
 if((GLuint)program==r->program||(GLuint)vao==r->vao||(GLuint)array==r->vbo||(GLuint)array==r->ebo||(GLuint)element==r->vbo||(GLuint)element==r->ebo)return false;
 glGetIntegerv(GL_MAX_COMBINED_TEXTURE_IMAGE_UNITS,&units);glGetIntegerv(GL_ACTIVE_TEXTURE,&active);if(units<=0||units>1024)return false;
 bool private=true;for(GLint i=0;i<units&&private;i++){GLint binding=0;ghActiveTexture(GL_TEXTURE0+i);glGetIntegerv(GL_TEXTURE_BINDING_2D,&binding);if(binding)for(unsigned j=0;j<128;j++)if(r->textures[j]==(GLuint)binding){private=false;break;}}
 ghActiveTexture((GLenum)active);return private;
}
static bool reaverTexturesMatch(const ReaverTextureGeneration *r,uint64_t generation,unsigned slot,unsigned sourceId){
 return r&&generation&&r->generation==generation&&r->gl.context==wglGetCurrentContext()&&slot<128&&sourceId&&r->sourceIds[slot]==sourceId&&r->gl.textures[slot];
}
static bool reaverTexturesCommit(ReaverTextureGeneration *r,uint64_t generation,const ReaverTextureView *views,unsigned count){
 const Sheet_reaverTextureGeneration *p=&sheet_reaverTextureGeneration_atomic_selected_textures;
 if(!r||!views||!generation||generation<=r->generation||!count||count>(unsigned)p->maxTextures||p->maxTextures!=128||p->maxDimension!=2048||p->nativeIntegrationEnabled||!p->requireUniqueIdSamplerPairs||!p->requireIncreasingGeneration||!reaverTexturesPrivate(&r->gl))return false;
 size_t bytes=0;for(unsigned i=0;i<count;i++){
  const ReaverTextureView *v=views+i;
  if(v->slot>=(unsigned)p->maxTextures||!v->sourceId||v->sourceId>65535||!v->width||!v->height||v->width>(unsigned)p->maxDimension||v->height>(unsigned)p->maxDimension||!v->pixels||v->bytes!=(size_t)v->width*v->height*4||v->bytes>(size_t)p->maxBytes-bytes)return false;
  for(unsigned j=0;j<i;j++)if(views[j].slot==v->slot||(views[j].sourceId==v->sourceId&&views[j].linear==v->linear&&views[j].repeat==v->repeat))return false;
  bytes+=v->bytes;
 }
 ReaverTextureGeneration next={0};if(!reaverGLInit(&next.gl))return false;
 for(unsigned i=0;i<count;i++){const ReaverTextureView *v=views+i;
  if(!REAVER_TEXTURE_GENERATION_UPLOAD(&next.gl,v->slot,v->width,v->height,v->pixels,v->linear,v->repeat)){reaverGLDestroy(&next.gl);return false;}
  next.sourceIds[v->slot]=v->sourceId;
 }
 next.generation=generation;
 if(!reaverTexturesPrivate(&r->gl)||!reaverGLDestroy(&r->gl)){reaverGLDestroy(&next.gl);return false;}
 *r=next;return true;
}
static bool reaverTexturesDestroy(ReaverTextureGeneration *r){
 if(!r||!reaverTexturesPrivate(&r->gl)||!reaverGLDestroy(&r->gl))return false;
 memset(r,0,sizeof(*r));return true;
}
