// SPDX-License-Identifier: GPL-3.0-or-later
// Current supported SR1 identity fields already used by worldRoot. Session
// existence is independent of the changing physics transform's orthogonality.
static unsigned worldActorFailure;
static bool worldActorRead(uintptr_t base,uintptr_t *out){
 uintptr_t actor=0,after=0,object=0,name=0,matrix=0,check=0;char label[9];unsigned char readable[32];
 worldActorFailure=0;
#define ACTOR_GATE(condition,reason) do{if(!(condition)){worldActorFailure=reason;return false;}}while(0)
 ACTOR_GATE(base&&out,1);
 ACTOR_GATE(worldRead(base+0x2a89310,&actor,8)&&actor,2);
 ACTOR_GATE(worldRead(actor+0x30,&object,8)&&object,3);
 ACTOR_GATE(worldRead(object+0x30,&name,8),4);
 ACTOR_GATE(worldRead(name,label,9)&&!memcmp(label,"raziel__",9),5);
 ACTOR_GATE(worldRead(actor+0x68,&matrix,8)&&matrix,6);
 ACTOR_GATE(worldRead(matrix,readable,sizeof(readable)),7);
 ACTOR_GATE(worldRead(base+0x2a89310,&after,8)&&after==actor,8);
 ACTOR_GATE(worldRead(actor+0x30,&check,8)&&check==object,9);
 ACTOR_GATE(worldRead(object+0x30,&check,8)&&check==name,10);
 // SR1 can advance the matrix buffer while this worker reads. That is not an
 // actor replacement. The renderer/controller still validate their actual
 // transform snapshot separately; no matrix from this identity probe is used.
#undef ACTOR_GATE
 *out=actor;return true;
}
