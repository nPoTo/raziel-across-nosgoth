// SPDX-License-Identifier: GPL-3.0-or-later
#pragma once
#include "donor-animation-context-reader.h"
typedef uintptr_t (__fastcall *DonorNativeInitialization)(uintptr_t);
typedef bool (*DonorInitializationSnapshot)(void *,uintptr_t,DonorAnimationContextObservation *);
typedef struct {uint64_t epoch,tick;uint32_t phase,thread,depth,callerRva,active,current,valid,availableMask,cachedMatchMask,keys[3];} DonorInitializationEvent;
typedef struct {volatile LONG64 epoch,calls,published,dropped;volatile LONG active,stopped;uint64_t start;bool configured;SRWLOCK queueLock;unsigned head,tail;DonorInitializationEvent queue[64];void *context;DonorInitializationSnapshot snapshot;} DonorInitializationObserver;
static inline void donorInitializationInit(DonorInitializationObserver *o,uint64_t now,void *c,DonorInitializationSnapshot snapshot){
 memset(o,0,sizeof(*o));InitializeSRWLock(&o->queueLock);o->start=now;o->context=c;o->snapshot=snapshot;
 const Sheet_donorInitializationPolicy *p=&sheet_donorInitializationPolicy_bounded;
 o->configured=snapshot&&p->rva==0x14e930&&p->bodyBytes==3267&&p->seconds==600&&p->maxCalls==128&&p->queueCapacity==64&&!p->serializePointers&&!p->retainDescriptors&&!p->syntheticCalls;
}
static inline bool donorInitializationOpen(DonorInitializationObserver *o,uint64_t now){
 if(!o->configured||InterlockedCompareExchange(&o->stopped,0,0))return false;
 if(now<o->start||now-o->start>=600000){InterlockedExchange(&o->stopped,1);return false;}return true;
}
static inline bool donorInitializationCurrent(DonorInitializationObserver *o,uint64_t epoch,uint64_t now){
 return epoch&&donorInitializationOpen(o,now)&&!InterlockedCompareExchange(&o->active,0,0)&&(uint64_t)InterlockedCompareExchange64(&o->epoch,0,0)==epoch;
}
static inline bool donorInitializationPush(DonorInitializationObserver *o,const DonorInitializationEvent *e){
 if(!TryAcquireSRWLockExclusive(&o->queueLock)){InterlockedIncrement64(&o->dropped);return false;}
 unsigned next=(o->head+1)%64;bool ok=next!=o->tail;if(ok){o->queue[o->head]=*e;o->head=next;InterlockedIncrement64(&o->published);}else InterlockedIncrement64(&o->dropped);ReleaseSRWLockExclusive(&o->queueLock);return ok;
}
static inline bool donorInitializationPop(DonorInitializationObserver *o,DonorInitializationEvent *e){
 if(!TryAcquireSRWLockExclusive(&o->queueLock))return false;bool ok=o->head!=o->tail;if(ok){*e=o->queue[o->tail];o->tail=(o->tail+1)%64;}ReleaseSRWLockExclusive(&o->queueLock);return ok;
}
// No lock is held across the native call. Epochs revoke on every admitted entry,
// even for identical actor addresses or invalid metadata. They describe only
// observed initialization boundaries, never the complete resource lifetime.
static inline uintptr_t donorInitializationForward(DonorInitializationObserver *o,uint32_t *depth,DonorNativeInitialization original,uintptr_t actor,uint32_t caller){
 DWORD incoming=GetLastError();uint64_t now=GetTickCount64();bool admit=donorInitializationOpen(o,now);uint64_t epoch=0;
 if(admit){
  InterlockedIncrement(&o->active);LONG64 call=InterlockedIncrement64(&o->calls),next=InterlockedIncrement64(&o->epoch);epoch=(uint64_t)next;
  if(call>128||next<=0||*depth>=32){InterlockedExchange(&o->stopped,1);admit=false;InterlockedDecrement(&o->active);}else ++*depth;
 }
 if(admit){DonorInitializationEvent e={.epoch=epoch,.tick=now,.phase=1,.thread=GetCurrentThreadId(),.depth=*depth,.callerRva=caller,.active=(uint32_t)InterlockedCompareExchange(&o->active,0,0)};donorInitializationPush(o,&e);}
 SetLastError(incoming);uintptr_t result=original(actor);DWORD outgoing=GetLastError();
 if(admit){
  uint32_t recordedDepth=*depth;--*depth;InterlockedDecrement(&o->active);
  DonorAnimationContextObservation m={0};bool current=donorInitializationCurrent(o,epoch,GetTickCount64());bool valid=current&&o->snapshot(o->context,actor,&m)&&m.valid&&donorInitializationCurrent(o,epoch,GetTickCount64());
  DonorInitializationEvent e={.epoch=epoch,.tick=GetTickCount64(),.phase=2,.thread=GetCurrentThreadId(),.depth=recordedDepth,.callerRva=caller,.active=(uint32_t)InterlockedCompareExchange(&o->active,0,0),.current=donorInitializationCurrent(o,epoch,GetTickCount64()),.valid=valid};
  if(valid){e.availableMask=m.availableMask;e.cachedMatchMask=m.cachedMatchMask;memcpy(e.keys,m.selectionKeys,sizeof(e.keys));}donorInitializationPush(o,&e);
 }
 SetLastError(outgoing);return result;
}
