// Depends on the read-only current-player and factor/basis validators above.
#include "donor-animation-proof.h"
static DonorProcessFn originalDonorAnimation;static PVOID donorAnimationTarget;
typedef uintptr_t (__fastcall *DonorMatrixFn)(uintptr_t);
static DonorMatrixFn originalDonorMatrix;static PVOID donorMatrixTarget;
static volatile LONG donorAnimationLock;static ULONGLONG donorAnimationBegin;
static unsigned donorAnimationHead,donorAnimationTail,donorAnimationRecords;
static DonorProcessEvent donorAnimationQueue[1024];
static uintptr_t __fastcall observeDonorMatrix(uintptr_t instance){
 DonorProcessEvent e={0};uintptr_t buffer=0;
 bool recording=InterlockedCompareExchange(&donorProcessEnabled,0,0)&&donorProcessIdentity(instance);
 if(recording){e.tick=GetTickCount64();e.instance=instance;e.state=1;
  recording=worldRead(instance+0x20,e.before,12);
  if(recording)e.motionValid=donorProcessMotion(instance,&e.factor,e.root,&buffer);}
 uintptr_t result=originalDonorMatrix(instance);e.result=result;
 if(!recording||!donorProcessIdentity(instance)||!worldRead(instance+0x20,e.after,12))return result;
 for(unsigned i=0;i<3;i++)if(!isfinite(e.before[i])||!isfinite(e.after[i]))return result;
 if(e.motionValid){uintptr_t afterBuffer=0;
  e.motionValid=worldRead(instance+0x70,&afterBuffer,8)&&afterBuffer==buffer;
  for(unsigned i=0;i<3;i++)if(fabsf(e.after[i]-e.before[i])>256)e.motionValid=false;
 }
 if(!InterlockedCompareExchange(&donorAnimationLock,1,0)){
  if(!donorAnimationBegin)donorAnimationBegin=e.tick;unsigned next=(donorAnimationHead+1)%ARRAYSIZE(donorAnimationQueue);
  if(e.tick>=donorAnimationBegin&&e.tick-donorAnimationBegin<90000&&donorAnimationRecords<48000&&next!=donorAnimationTail){donorAnimationQueue[donorAnimationHead]=e;donorAnimationHead=next;++donorAnimationRecords;}
  InterlockedExchange(&donorAnimationLock,0);
 }
 return result;
}
static bool donorAnimationIdentity(uintptr_t instance,uintptr_t tracker){
 uintptr_t callback=0,player=0;
 return tracker==donorProcessBase+0xc5aa50&&donorProcessIdentity(instance)&&
  worldRead(tracker+0x28,&player,8)&&player==instance&&worldRead(instance+0x398,&callback,8)&&callback==(uintptr_t)donorAnimationTarget;
}
static uintptr_t __fastcall observeDonorAnimation(uintptr_t instance,uintptr_t tracker){
 DonorProcessEvent e={0};uintptr_t buffer=0;
 bool recording=InterlockedCompareExchange(&donorProcessEnabled,0,0)&&donorAnimationIdentity(instance,tracker);
 if(recording){e.tick=GetTickCount64();e.instance=instance;e.tracker=tracker;
  recording=worldRead(instance+0x20,e.before,12);
  if(recording)e.motionValid=donorProcessMotion(instance,&e.factor,e.root,&buffer);}
 uintptr_t result=originalDonorAnimation(instance,tracker);e.result=result;
 if(!recording||!donorAnimationIdentity(instance,tracker)||!worldRead(instance+0x20,e.after,12))return result;
 for(unsigned i=0;i<3;i++)if(!isfinite(e.before[i])||!isfinite(e.after[i]))return result;
 if(e.motionValid){float factor=0;uintptr_t afterBuffer=0;
  e.motionValid=worldRead(donorProcessBase+0xc5abbc,&factor,4)&&factor==e.factor&&worldRead(instance+0x70,&afterBuffer,8)&&afterBuffer==buffer;
  for(unsigned i=0;i<3;i++)if(fabsf(e.after[i]-e.before[i])>256)e.motionValid=false;
 }
 if(!InterlockedCompareExchange(&donorAnimationLock,1,0)){
  if(!donorAnimationBegin)donorAnimationBegin=e.tick;unsigned next=(donorAnimationHead+1)%ARRAYSIZE(donorAnimationQueue);
  if(e.tick>=donorAnimationBegin&&e.tick-donorAnimationBegin<90000&&donorAnimationRecords<48000&&next!=donorAnimationTail){donorAnimationQueue[donorAnimationHead]=e;donorAnimationHead=next;++donorAnimationRecords;}
  InterlockedExchange(&donorAnimationLock,0);
 }
 return result;
}
static void donorAnimationFlush(void){
 DonorProcessEvent local[1024];unsigned count=0;if(InterlockedCompareExchange(&donorAnimationLock,1,0))return;
 while(donorAnimationTail!=donorAnimationHead){local[count++]=donorAnimationQueue[donorAnimationTail];donorAnimationTail=(donorAnimationTail+1)%ARRAYSIZE(donorAnimationQueue);}InterlockedExchange(&donorAnimationLock,0);
 for(unsigned i=0;i<count;i++){DonorProcessEvent *e=&local[i];logLine("%s tick=%llu instance=%p valid=%u factor=%.9g delta=%.9g,%.9g,%.9g rotation=%.9g,%.9g,%.9g,%.9g,%.9g,%.9g,%.9g,%.9g,%.9g; %s",
  e->state?"DONOR_MATRIX_STEP":"DONOR_ANIMATION_STEP",e->tick,(void *)e->instance,e->motionValid,e->motionValid?e->factor:0,e->after[0]-e->before[0],e->after[1]-e->before[1],e->after[2]-e->before[2],e->root[0],e->root[1],e->root[2],e->root[4],e->root[5],e->root[6],e->root[8],e->root[9],e->root[10],
  e->state?"read-only matrix-update displacement; global factor contextual only, not proved animation time":"read-only instance+398 callback displacement, includes native collision/physics");}
}
static void donorAnimationInstall(HMODULE module){
 if(!module)return;unsigned char code[DONOR_ANIMATION_SIZE];char hash[65];PVOID target=(PVOID)((uintptr_t)module+DONOR_ANIMATION_RVA);
 if(!worldRead((uintptr_t)target,code,sizeof(code))||!hashBytes(code,sizeof(code),hash)||strcmp(hash,DONOR_ANIMATION_SHA)){logLine("DONOR_ANIMATION code proof failed");return;}
 MH_STATUS init=MH_Initialize();if(init!=MH_OK&&init!=MH_ERROR_ALREADY_INITIALIZED)return;
 MH_STATUS create=MH_CreateHook(target,(PVOID)&observeDonorAnimation,(PVOID *)&originalDonorAnimation),enable=create==MH_OK?MH_EnableHook(target):create;
 if(enable==MH_OK)donorAnimationTarget=target;logLine("DONOR_ANIMATION create=%d enable=%d full-code proof=1; read-only",create,enable);
 unsigned char matrixCode[DONOR_MATRIX_SIZE];target=(PVOID)((uintptr_t)module+DONOR_MATRIX_RVA);
 if(!worldRead((uintptr_t)target,matrixCode,sizeof(matrixCode))||!hashBytes(matrixCode,sizeof(matrixCode),hash)||strcmp(hash,DONOR_MATRIX_SHA)){logLine("DONOR_MATRIX code proof failed");return;}
 create=MH_CreateHook(target,(PVOID)&observeDonorMatrix,(PVOID *)&originalDonorMatrix);enable=create==MH_OK?MH_EnableHook(target):create;
 if(enable==MH_OK)donorMatrixTarget=target;logLine("DONOR_MATRIX create=%d enable=%d full-code proof=1; read-only",create,enable);
}
static void donorAnimationTick(void){
 if(!InterlockedCompareExchange(&donorProcessEnabled,0,0)&&!InterlockedCompareExchange(&donorAnimationLock,1,0)){
  donorAnimationBegin=0;donorAnimationRecords=0;InterlockedExchange(&donorAnimationLock,0);
 }
 donorAnimationFlush();
}
static void donorAnimationStop(void){if(donorAnimationTarget)MH_DisableHook(donorAnimationTarget);if(donorMatrixTarget)MH_DisableHook(donorMatrixTarget);donorAnimationFlush();}

