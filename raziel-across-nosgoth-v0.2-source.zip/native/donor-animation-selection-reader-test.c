// SPDX-License-Identifier: GPL-3.0-or-later
#define main baseStateTestMain
#include "donor-state-sections-test.c"
#undef main
#include "donor-animation-selection-reader.h"
static int selectionDefect;static unsigned selectionReads;
static bool selectionRead(void *c,uintptr_t address,void *out,SIZE_T n){
 if(address==base+0xc5aa78)return fixtureRead(c,currentAddress,out,n);
 for(unsigned i=0;i<3;i++){
  if(address==state+i*0x250+0x248&&n==4){uint32_t key=i==2?UINT32_MAX:65;if(selectionDefect==1&&++selectionReads>3)key++;memcpy(out,&key,4);return true;}
  if(address==state+i*0x250+0x250&&n==8){uintptr_t d=i==2?0:0xdeadface;if(selectionDefect==2&&++selectionReads>3)d+=16;memcpy(out,&d,8);return true;}
  if(address==actor+i*0x68+0x1f4&&n==2){uint16_t id=i==2?0:82;if(selectionDefect==3&&++selectionReads>3)id++;if(selectionDefect==4)return false;memcpy(out,&id,2);return true;}
 }
 return fixtureRead(c,address,out,n);
}
static DonorAnimationSelection selection(void){memset(prefixReads,0,sizeof(prefixReads));actorReads=stateReads=selectionReads=0;return donorAnimationSelectionRead(NULL,selectionRead,fixtureCode,base,0x2000000,actor);}
#ifndef DONOR_SELECTION_TEST_NAME
#define DONOR_SELECTION_TEST_NAME main
#endif
int DONOR_SELECTION_TEST_NAME(void){
 CHECK(baseStateTestMain()==0,60);defect=0;memset(data,0,sizeof(data));memcpy(data[0],&actor,8);for(unsigned i=0;i<3;i++){uintptr_t v=base+0x100+i*16;memcpy(data[i]+16,&v,8);}
 DonorAnimationSelection r=selection();CHECK(r.valid&&r.sections[0].selectionKeyRaw==65&&r.sections[0].animationId==82&&r.sections[0].descriptorPresent,61);CHECK(r.sections[2].selectionKeyRaw==UINT32_MAX&&r.sections[2].animationId==0&&!r.sections[2].descriptorPresent,62);
 for(selectionDefect=1;selectionDefect<=4;selectionDefect++)CHECK(!selection().valid,70+selectionDefect);selectionDefect=0;
 for(defect=1;defect<=7;defect++)CHECK(!selection().valid,80+defect);defect=0;
 uintptr_t other=actor+8;memcpy(data[0],&other,8);CHECK(!selection().valid,90);memcpy(data[0],&actor,8);
 CHECK(!donorAnimationSelectionRead(NULL,selectionRead,fixtureCode,UINTPTR_MAX-4,0x2000000,actor).valid,91);CHECK(!donorAnimationSelectionRead(NULL,selectionRead,fixtureCode,base,0x1000,actor).valid,92);
 puts("PASS: production donor scalar selection/clip/presence reader; key/descriptor/ID races, actor/state/owner/code/bounds rejected; opaque descriptors never dereferenced");return 0;
}
