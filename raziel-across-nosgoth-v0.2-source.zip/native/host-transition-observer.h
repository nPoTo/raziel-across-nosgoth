// SPDX-License-Identifier: GPL-3.0-or-later
#pragma once
#include "donor-message-observer.h"
#include "host-transition-reader.h"
typedef uintptr_t (__fastcall *HostSectionTransition)(void *,int32_t,uintptr_t,uintptr_t);
typedef uintptr_t (__fastcall *HostWholeTransition)(void *,uintptr_t,uintptr_t);
typedef int (*HostTransitionSnapshot)(void *,void *,uintptr_t,HostTransitionMetadata *);
typedef struct {uint64_t session,callId,tickMs;uint32_t phase,threadId,depth,callerRva,kind,section,requestedRva,payloadZero,handlers[3],clips[3],afterValid,sameActor;} HostTransitionEvent;
_Static_assert(sizeof(HostTransitionEvent)==88,"Bounded scalar transition event without native pointers");
typedef struct {
 HostTransitionEvent queue[512];volatile LONG readCursor,writeCursor,producerThread,consumerThread;
 volatile LONG64 forwarded,published,dropped,nextCallId,unrelated,boundaryRejected,leaseDrops,metadataDrops,depthDrops,producerDrops,queueDrops,budgetDrops;
 void *context;DonorMessageLeaseRead lease;HostTransitionSnapshot snapshot;bool configured;
} HostTransitionObserver;
typedef struct {DonorMessageLease lease;HostTransitionMetadata before;HostTransitionEvent event;uint32_t depth;bool tracked,entered;} HostTransitionToken;
static inline void hostTransitionInit(HostTransitionObserver *o,void *c,DonorMessageLeaseRead l,HostTransitionSnapshot s){
 memset(o,0,sizeof(*o));o->context=c;o->lease=l;o->snapshot=s;const Sheet_hostNativeTransitionPolicy *p=&sheet_hostNativeTransitionPolicy_bounded;
 o->configured=l&&s&&p->sectionRva==0x1100f0&&p->sectionBytes==158&&p->wholeRva==0x10ffc0&&p->wholeBytes==163&&p->plan==11&&p->seconds==60&&p->queueCapacity==512&&p->maxRecords==4096&&p->maxDepth==32&&p->requireSingleProducer&&!p->serializePointers&&!p->serializePayloads&&!p->syntheticCalls;
}
static inline void hostTransitionDrop(HostTransitionObserver *o,volatile LONG64 *reason){InterlockedIncrement64(reason);InterlockedIncrement64(&o->dropped);}
static inline bool hostTransitionPush(HostTransitionObserver *o,const HostTransitionEvent *e){
 DWORD tid=GetCurrentThreadId();LONG owner=InterlockedCompareExchange(&o->producerThread,(LONG)tid,0);if(owner&&(DWORD)owner!=tid){hostTransitionDrop(o,&o->producerDrops);return false;}
 uint32_t w=(uint32_t)InterlockedCompareExchange(&o->writeCursor,0,0),r=(uint32_t)InterlockedCompareExchange(&o->readCursor,0,0);
 if(InterlockedCompareExchange64(&o->published,0,0)>=sheet_hostNativeTransitionPolicy_bounded.maxRecords){hostTransitionDrop(o,&o->budgetDrops);return false;}
 if(w<r||w-r>=512){hostTransitionDrop(o,&o->queueDrops);return false;}o->queue[w%512]=*e;InterlockedIncrement64(&o->published);InterlockedExchange(&o->writeCursor,(LONG)(w+1));return true;
}
static inline bool hostTransitionPop(HostTransitionObserver *o,HostTransitionEvent *e){
 DWORD tid=GetCurrentThreadId();LONG owner=InterlockedCompareExchange(&o->consumerThread,(LONG)tid,0);if(owner&&(DWORD)owner!=tid)return false;
 uint32_t r=(uint32_t)InterlockedCompareExchange(&o->readCursor,0,0),w=(uint32_t)InterlockedCompareExchange(&o->writeCursor,0,0);if(w<=r||w-r>512)return false;*e=o->queue[r%512];InterlockedExchange(&o->readCursor,(LONG)(r+1));return true;
}
static inline bool hostTransitionOutside(const DonorMessageLease *l){return l->enabled&&l->session&&l->startTick&&l->nowTick>=l->startTick&&l->nowTick-l->startTick>=(uint64_t)sheet_hostNativeTransitionPolicy_bounded.seconds*1000;}
static inline bool hostTransitionLease(HostTransitionObserver *o,const DonorMessageLease *start,DonorMessageLease *now){return o->lease(o->context,now)&&donorMessageLeaseValid(now)&&now->session==start->session&&now->startTick==start->startTick&&now->heartbeatTick>=start->heartbeatTick&&now->nowTick>=start->nowTick;}
static inline HostTransitionToken hostTransitionBegin(HostTransitionObserver *o,DonorMessageObserverThread *tls,void *state,uint32_t kind,int32_t section,uintptr_t requested,uintptr_t payload,uint32_t caller){
 HostTransitionToken t={0};DWORD tid=GetCurrentThreadId();DonorMessageLease now={0};
 if(tls){LONG owner=InterlockedCompareExchange(&tls->ownerThread,(LONG)tid,0);t.tracked=owner==0||(DWORD)owner==tid;if(t.tracked){t.depth=tls->depth;tls->depth=t.depth<UINT32_MAX?t.depth+1:UINT32_MAX;}}
 if(o)InterlockedIncrement64(&o->forwarded);
 if(o&&o->configured&&t.tracked&&o->lease(o->context,&t.lease)&&t.lease.enabled){
  if(hostTransitionOutside(&t.lease))InterlockedIncrement64(&o->boundaryRejected);
  else if(!donorMessageLeaseValid(&t.lease))hostTransitionDrop(o,&o->leaseDrops);
  else if(t.depth>=(uint32_t)sheet_hostNativeTransitionPolicy_bounded.maxDepth)hostTransitionDrop(o,&o->depthDrops);
  else if((kind!=1&&kind!=2)||(kind==1&&(section<0||section>2)))hostTransitionDrop(o,&o->metadataDrops);
  else{int status=o->snapshot(o->context,state,requested,&t.before);
   if(status==0)InterlockedIncrement64(&o->unrelated);
   else if(status!=1)hostTransitionDrop(o,&o->metadataDrops);
   else if(!hostTransitionLease(o,&t.lease,&now)){if(hostTransitionOutside(&now))InterlockedIncrement64(&o->boundaryRejected);else hostTransitionDrop(o,&o->leaseDrops);}
   else{t.event=(HostTransitionEvent){.session=t.lease.session,.callId=(uint64_t)InterlockedIncrement64(&o->nextCallId),.tickMs=now.nowTick,.phase=1,.threadId=tid,.depth=t.depth+1,.callerRva=caller,.kind=kind,.section=kind==1?(uint32_t)section:UINT32_MAX,.requestedRva=t.before.requestedRva,.payloadZero=payload==0};memcpy(t.event.handlers,t.before.handlers,sizeof(t.event.handlers));memcpy(t.event.clips,t.before.clips,sizeof(t.event.clips));t.entered=hostTransitionPush(o,&t.event);}
  }
 }return t;
}
static inline void hostTransitionEnd(HostTransitionObserver *o,DonorMessageObserverThread *tls,HostTransitionToken *t,void *state,uintptr_t requested){
 if(t->entered){DonorMessageLease now={0};HostTransitionMetadata after={0};
  if(hostTransitionLease(o,&t->lease,&now)){int status=o->snapshot(o->context,state,requested,&after);
   if(hostTransitionLease(o,&t->lease,&now)){t->event.phase=2;t->event.tickMs=now.nowTick;t->event.afterValid=status==1;t->event.sameActor=status==1&&after.opaqueActor==t->before.opaqueActor;
    memset(t->event.handlers,0,sizeof(t->event.handlers));memset(t->event.clips,0,sizeof(t->event.clips));if(status==1){memcpy(t->event.handlers,after.handlers,sizeof(t->event.handlers));memcpy(t->event.clips,after.clips,sizeof(t->event.clips));}hostTransitionPush(o,&t->event);
   }else hostTransitionDrop(o,&o->leaseDrops);
  }else hostTransitionDrop(o,&o->leaseDrops);
 }if(t->tracked)tls->depth=t->depth;
}
static inline uintptr_t hostSectionTransitionForward(HostTransitionObserver *o,DonorMessageObserverThread *tls,HostSectionTransition original,void *state,int32_t section,uintptr_t requested,uintptr_t payload,uint32_t caller){
 DWORD incoming=GetLastError();HostTransitionToken t=hostTransitionBegin(o,tls,state,1,section,requested,payload,caller);SetLastError(incoming);uintptr_t r=original(state,section,requested,payload);DWORD outgoing=GetLastError();hostTransitionEnd(o,tls,&t,state,requested);SetLastError(outgoing);return r;
}
static inline uintptr_t hostWholeTransitionForward(HostTransitionObserver *o,DonorMessageObserverThread *tls,HostWholeTransition original,void *state,uintptr_t requested,uintptr_t payload,uint32_t caller){
 DWORD incoming=GetLastError();HostTransitionToken t=hostTransitionBegin(o,tls,state,2,0,requested,payload,caller);SetLastError(incoming);uintptr_t r=original(state,requested,payload);DWORD outgoing=GetLastError();hostTransitionEnd(o,tls,&t,state,requested);SetLastError(outgoing);return r;
}
