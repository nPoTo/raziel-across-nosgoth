#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <stdint.h>
#include <stdbool.h>
#include <stdio.h>
#include <string.h>
#include <math.h>
#include "MinHook.h"
#define PROBE_REPORT_DIR L"."
static uintptr_t testPlayer;
static PVOID volatile verifiedSr1Module=(PVOID)0x10000000;
static int32_t fixtureTime=4096;static bool failTime;
static ULONGLONG worldLastDraw,overlayLiveTick;static uintptr_t worldLastInstance;static uint32_t overlayLivePid=4242;
static bool fixtureInput=true;
static bool srGroundMovementInput(void){return fixtureInput;}
static DWORD fixtureForeground(HWND h,LPDWORD out){(void)h;*out=GetCurrentProcessId();return 1;}
#define GetWindowThreadProcessId fixtureForeground
static void logLine(const char *fmt,...){(void)fmt;}
static bool worldRead(uintptr_t p,void *out,size_t n){if(p==0x10000000+0x2a89628&&n==4){if(failTime)return false;memcpy(out,&fixtureTime,n);return true;}if(p<0x100000)return false;memcpy(out,(void *)p,n);return true;}
static bool worldRoot(float *root,uintptr_t *player){memset(root,0,64);root[10]=1;*player=testPlayer;return true;}
static bool hashBytes(const void *p,ULONG n,char *out){(void)p;(void)n;(void)out;return false;}
#include "motion-probe.h"
static unsigned calls;static uintptr_t lastArgs[4];static float lastY;static unsigned char fixturePacket[80];static bool fixturePacketAvailable=true;
static bool fixturePacketRead(unsigned char out[80]){if(!fixturePacketAvailable)return false;memcpy(out,fixturePacket,80);uint64_t now=GetTickCount64();memcpy(out+16,&now,8);return true;}
static uintptr_t __fastcall mockVector(uintptr_t anim,int32_t section,int32_t type,uintptr_t vector){++calls;lastArgs[0]=anim;lastArgs[1]=section;lastArgs[2]=type;lastArgs[3]=vector;lastY=anim==testPlayer+0x448?((float *)vector)[1]:((int16_t *)vector)[1];return 0xabc123;}
#define CHECK(x) do{if(!(x)){printf("FAIL line %d\n",__LINE__);return 1;}}while(0)
int main(int argc,char **argv){
 CHECK(argc==2);FILE *packet=fopen(argv[1],"rb");CHECK(packet&&fread(fixturePacket,1,80,packet)==80);fclose(packet);
 unsigned char fixture[1400]={0};testPlayer=(uintptr_t)fixture;*(int32_t *)(fixture+0x370)=4096;
 int16_t small[3]={0,-60,0},copy[3];memcpy(copy,small,sizeof(copy));float wide[3]={0,-60,0};
 originalMotion[0]=originalMotion[1]=mockVector;
 CHECK(observeMotionShort(testPlayer+0x328,0,34,(uintptr_t)small)==0xabc123&&calls==1&&motionHead==0&&!memcmp(copy,small,sizeof(copy)));
 motionEnabled=1;CHECK(observeMotionShort(testPlayer+0x328,0,34,(uintptr_t)small)==0xabc123&&calls==2&&motionHead==1);
 CHECK(lastArgs[0]==testPlayer+0x328&&lastArgs[1]==0&&lastArgs[2]==34&&lastArgs[3]==(uintptr_t)small&&motionQueue[0].vector[1]==-60&&motionQueue[0].adjustment==4096);
 CHECK(observeMotionFloat(testPlayer+0x448,0,34,(uintptr_t)wide)==0xabc123&&calls==3&&motionHead==2&&motionQueue[1].kind==1&&motionQueue[1].vector[1]==-60);
 CHECK(motionQueue[1].timeValid&&motionQueue[1].timeRaw==4096);
 observeMotionShort(testPlayer+0x329,0,34,(uintptr_t)small);observeMotionShort(testPlayer+0x328,1,34,(uintptr_t)small);CHECK(calls==5&&motionHead==2);
 wide[1]=NAN;observeMotionFloat(testPlayer+0x448,0,34,(uintptr_t)wide);CHECK(calls==6&&motionHead==2&&isnan(wide[1]));
 motionLock=1;observeMotionShort(testPlayer+0x328,0,34,(uintptr_t)small);motionLock=0;CHECK(calls==7&&motionDrops==1);
 motionRecords=4000;observeMotionShort(testPlayer+0x328,0,34,(uintptr_t)small);CHECK(calls==8&&motionHead==2&&!memcmp(copy,small,sizeof(copy)));
 motionRecords=0;failTime=true;observeMotionShort(testPlayer+0x328,0,34,(uintptr_t)small);CHECK(calls==9&&motionHead==3&&!motionQueue[2].timeValid&&!memcmp(copy,small,sizeof(copy)));failTime=false;
 fixtureTime=0;observeMotionShort(testPlayer+0x328,0,34,(uintptr_t)small);CHECK(calls==10&&motionHead==4&&!motionQueue[3].timeValid);
 fixtureTime=4096;movementEnabled=1;movementBegin=worldLastDraw=overlayLiveTick=GetTickCount64();worldLastInstance=testPlayer;movementReadPacket=fixturePacketRead;
 float donorY=-15;memcpy(fixturePacket+32,&donorY,4);
 CHECK(motionObserve(0,testPlayer+0x328,0,34,(uintptr_t)small,0x10000000+0xfc864)==0xabc123&&calls==11&&lastY==-30&&lastArgs[3]!=(uintptr_t)small&&!memcmp(copy,small,sizeof(copy)));
 wide[1]=-35;CHECK(motionObserve(1,testPlayer+0x448,0,34,(uintptr_t)wide,0x10000000+0xfc880)==0xabc123&&calls==12&&lastY==-30&&wide[1]==-35);
 fixtureInput=false;motionObserve(0,testPlayer+0x328,0,34,(uintptr_t)small,0x10000000+0xfc864);CHECK(calls==13&&lastY==-60&&lastArgs[3]==(uintptr_t)small);
 fixtureInput=true;*(int32_t *)(fixture+0x2d4)=-16;motionObserve(0,testPlayer+0x328,0,34,(uintptr_t)small,0x10000000+0xfc864);CHECK(calls==14&&lastY==-60);*(int32_t *)(fixture+0x2d4)=0;
 movementEnabled=0;motionObserve(0,testPlayer+0x328,0,34,(uintptr_t)small,0x10000000+0xfc864);CHECK(calls==15&&lastY==-60&&lastArgs[3]==(uintptr_t)small);
 movementEnabled=1;fixturePacketAvailable=false;motionObserve(0,testPlayer+0x328,0,34,(uintptr_t)small,0x10000000+0xfc864);CHECK(calls==16&&lastY==-60&&lastArgs[3]==(uintptr_t)small);fixturePacketAvailable=true;
 fixturePacket[48]^=1;motionObserve(0,testPlayer+0x328,0,34,(uintptr_t)small,0x10000000+0xfc864);CHECK(calls==17&&lastY==-60);fixturePacket[48]^=1;
 motionObserve(0,testPlayer+0x328,0,34,(uintptr_t)small,0x10000000+0x12345);CHECK(calls==18&&lastY==-60);
 movementBegin=GetTickCount64()-(uint64_t)sheet_diagnosticLimits_controls.durationMs-1;motionObserve(0,testPlayer+0x328,0,34,(uintptr_t)small,0x10000000+0xfc864);CHECK(calls==19&&lastY==-60&&movementForwarded==2&&!memcmp(copy,small,sizeof(copy)));
 motionTick();motionStop();motionInstall(NULL);
 puts("Motion observer: original forwarding; explicit short/float movement conversion, input/air/caller/time/packet scope, native fallback and unchanged caller buffers PASS");return 0;
}

