#include <stdint.h>
#include <stdbool.h>
#include <string.h>
#include <stdio.h>
#include "air-hold.h"
#define CHECK(x) do{if(!(x)){printf("FAIL line %d\n",__LINE__);return 1;}}while(0)
int main(void){
 AirHoldScope s={true,true,true,1000,900,980,980,950,1,1,1,400,1,0,4096,0,-50,-16};AirHoldTimer timer={0};
 CHECK(airScopeValid(&s)&&airHoldStep(&timer,&s));
 AirHoldScope bad=s;bad.hint=false;CHECK(!airScopeValid(&bad));bad=s;bad.height=0;CHECK(!airScopeValid(&bad));
 bad=s;bad.packet=500;CHECK(!airScopeValid(&bad));bad=s;bad.player=2;CHECK(!airScopeValid(&bad));
 bad=s;bad.segment=1;CHECK(!airScopeValid(&bad));bad=s;bad.clamp=1;CHECK(!airScopeValid(&bad));
 bad=s;bad.focused=false;CHECK(!airScopeValid(&bad));bad=s;bad.now=899;CHECK(!airScopeValid(&bad));
 s.now=3000;s.packet=s.draw=2990;CHECK(!airHoldStep(&timer,&s));
 s.now=3050;s.packet=s.draw=3040;CHECK(!airHoldStep(&timer,&s));
 s.hint=false;CHECK(!airHoldStep(&timer,&s));s.hint=true;CHECK(airHoldStep(&timer,&s));
 puts("Air hold scope: explicit mode, donor freshness, player/ground/focus, physics args, timeouts and release PASS");return 0;
}
