// SPDX-License-Identifier: GPL-3.0-or-later
#pragma once
#ifdef GENERAL_FREE_TEST
#include "exploration-sheets.h"
// New compiled candidate only. Existing short builds retain their bounds.
#define GENERAL_OR_SHORT_MS(shortMs) ((uint64_t)sheet_generalTestPolicy_general.sessionMs)
#define GENERAL_OR_SHORT_SAMPLES(shortSamples) ((unsigned long)sheet_generalTestPolicy_general.maxSamples)
#else
#define GENERAL_OR_SHORT_MS(shortMs) (shortMs)
#define GENERAL_OR_SHORT_SAMPLES(shortSamples) (shortSamples)
#endif
