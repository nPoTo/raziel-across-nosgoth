// SPDX-License-Identifier: GPL-3.0-or-later
// Bounded stdin envelope adapter. Resource bytes remain in pipes/pagefile RAM.
#include <stdlib.h>
#include <io.h>
#include <fcntl.h>
#include "bridge-memory.h"
static bool exact(void *out,size_t bytes){return fread(out,1,bytes,stdin)==bytes;}
int main(int argc,char **argv){
 if(argc!=3&&argc!=4)return 1;char *end=NULL;unsigned long source=strtoul(argv[1],&end,10);if(!source||*end||source>UINT32_MAX)return 1;
 unsigned long host=strtoul(argv[2],&end,10);if(!host||*end||host>UINT32_MAX||source==host)return 1;
 int result=2;BridgeMemory memory={0};unsigned char *payload=NULL,*pendingPose=NULL;bool pending=false;BridgeHeader pendingHeader={0};HANDLE sourceHandle=NULL,hostHandle=NULL;BridgeIdentity identity={.sourcePid=(uint32_t)source,.hostPid=(uint32_t)host,.levelGeneration=1,.actorId=1,.actorGeneration=1,.capabilities=15};
 sourceHandle=OpenProcess(SYNCHRONIZE|PROCESS_QUERY_LIMITED_INFORMATION,FALSE,source);hostHandle=OpenProcess(SYNCHRONIZE|PROCESS_QUERY_LIMITED_INFORMATION,FALSE,host);
 if(!bridgeProcessCreation(sourceHandle,&identity.sourceCreation)||!bridgeProcessCreation(hostHandle,&identity.hostCreation)||!bridgeProcessCreation(GetCurrentProcess(),&identity.sessionGeneration))goto done;
 if(!bridgeHex(sheet_bridgeProtocol_session_v2.sourceBuild,identity.sourceBuild)||!bridgeHex(sheet_bridgeProtocol_session_v2.hostBuild,identity.hostBuild))goto done;
 uint64_t ownerCreation=0;if(argc==4){unsigned long owner=strtoul(argv[3],&end,10);if(!owner||*end)goto done;HANDLE ownerHandle=OpenProcess(PROCESS_QUERY_LIMITED_INFORMATION,FALSE,owner);bool ownerValid=bridgeProcessCreation(ownerHandle,&ownerCreation);if(ownerHandle)CloseHandle(ownerHandle);if(!ownerValid)goto done;}
 printf("{\"sourcePid\":%lu,\"hostPid\":%lu,\"sourceCreation\":\"%llu\",\"hostCreation\":\"%llu\",\"ownerCreation\":\"%llu\",\"sessionGeneration\":\"%llu\",\"tick\":\"%llu\"}\n",source,host,(unsigned long long)identity.sourceCreation,(unsigned long long)identity.hostCreation,(unsigned long long)ownerCreation,(unsigned long long)identity.sessionGeneration,(unsigned long long)GetTickCount64());fflush(stdout);
 _setmode(_fileno(stdin),_O_BINARY);unsigned char bytes[BRIDGE_HEADER_BYTES];BridgeHeader header;
 if(!exact(bytes,sizeof(bytes)))goto done;
 // The peer selects a subset only; actor/level binding is fixed for this bounded
 // diagnostic session. Native lifecycle negotiation is a later adapter.
 identity.capabilities=bridgeU32(bytes+80);
 if(!bridgeDecode(bytes,sizeof(bytes),sizeof(bytes),GetTickCount64(),&identity,&header)||header.type!=BRIDGE_HELLO)goto done;
 BridgeLedger ledger;bridgeLedgerBegin(&ledger,&identity);if(!bridgeAccept(&ledger,&header)||!bridgeMemoryOpen(&memory,&identity,true))goto done;
 payload=malloc(RM_APPEARANCE_BYTES);pendingPose=malloc(RM_LIVE_BYTES);if(!payload||!pendingPose)goto done;
 unsigned frames=0;size_t readBytes;
 while((readBytes=fread(bytes,1,sizeof(bytes),stdin))==sizeof(bytes)){
  uint32_t count=bridgeU32(bytes+12);if(count>RM_APPEARANCE_BYTES||!bridgeDecode(bytes,sizeof(bytes),(uint64_t)sizeof(bytes)+count,GetTickCount64(),&identity,&header)||header.payloadBytes!=bridgeMemoryPayload(header.type)||!header.payloadBytes||!bridgeAccept(&ledger,&header)||!exact(payload,count))goto done;
  if(identity.capabilities&BRIDGE_GROUND){
   if(header.type==BRIDGE_POSE){if(pending)goto done;memcpy(pendingPose,payload,RM_LIVE_BYTES);pendingHeader=header;pending=true;continue;}
   if(header.type==BRIDGE_MOVEMENT){if(!pending||header.sequence!=pendingHeader.sequence||header.tick!=pendingHeader.tick)goto done;}
   else if(pending)goto done;
  }
  // Helper worker may retry contention within a bounded deadline. Game callbacks never do.
  uint64_t deadline=GetTickCount64()+100;bool published=false;
  do{published=header.type==BRIDGE_MOVEMENT?bridgeMemoryPublishFrame(&memory,&pendingHeader,pendingPose,&header,payload):bridgeMemoryPublish(&memory,&header,payload);if(!published&&memory.status==BM_BUSY)Sleep(1);else break;}while(GetTickCount64()<deadline);
  if(!published)goto done;pending=false;frames++;
 }
 if(!readBytes&&feof(stdin)&&!ferror(stdin)&&frames&&!pending)result=0;
 fprintf(stderr,"RZB2 packets published: %u; exit=%d\n",frames,result);
done:free(payload);free(pendingPose);bridgeMemoryClose(&memory);if(sourceHandle)CloseHandle(sourceHandle);if(hostHandle)CloseHandle(hostHandle);return result;
}
