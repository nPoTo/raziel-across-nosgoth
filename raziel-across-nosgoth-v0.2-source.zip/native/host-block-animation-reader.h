// SPDX-License-Identifier: GPL-3.0-or-later
#pragma once
#include "host-block-state-reader.h"
// Bracket the production state snapshot with exactly three native scalar IDs.
// No animation resource pointers, frames, clips or payloads are followed.
static inline HostBlockState hostBlockAnimationStateRead(void *context,HostBlockRead read,HostBlockCode code,uintptr_t base,uint32_t imageSize,uintptr_t actor,uint16_t ids[3]){
 HostBlockState invalid={0};if(!ids)return invalid;memset(ids,0,3*sizeof(*ids));
 const Sheet_hostAnimationIndexProbe *p=&sheet_hostAnimationIndexProbe_current;
 if(!read||!code||!base||!actor||actor%8||base>UINTPTR_MAX-imageSize||imageSize<0x2a89318||p->actorAnimationIdOffset!=0x374||p->actorAnimationSectionStride!=0x50||p->sectionCount!=3||p->animationIdBytes!=2||p->stableReads!=2||!p->requireSameHostStateSnapshot||p->serializeAnimationResources)return invalid;
 uint16_t before[3],after[3];
 for(unsigned i=0;i<3;i++)if(!hostBlockField(context,read,actor,(uintptr_t)p->actorAnimationIdOffset+i*(uintptr_t)p->actorAnimationSectionStride,&before[i],2))return invalid;
 HostBlockState state=hostBlockStateRead(context,read,code,base,imageSize,actor);if(!state.valid)return invalid;
 for(unsigned i=0;i<3;i++)if(!hostBlockField(context,read,actor,(uintptr_t)p->actorAnimationIdOffset+i*(uintptr_t)p->actorAnimationSectionStride,&after[i],2))return invalid;
 uintptr_t again=0;
 if(memcmp(before,after,sizeof(before))||!read(context,base+0x2a89310,&again,8)||again!=actor||!read(context,base+0x2a88588,&again,8)||again!=actor)return invalid;
 memcpy(ids,before,sizeof(before));return state;
}
