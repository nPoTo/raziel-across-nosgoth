// SPDX-License-Identifier: GPL-3.0-or-later
#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <stdio.h>
#include "donor-animation-step-reader.h"
static const uintptr_t base=0x10000000,actor=0x20000000,state=0x30000000,resource=0x40000000;
static unsigned char data[0x400];static int defect;static unsigned roots,states,sections,slots,cursors,resources,callbacks,counts;
static bool readFixture(void *c,uintptr_t a,void *out,SIZE_T n){(void)c;uintptr_t v=0;
 if(defect==1)return false;
 if(a==base+0xc5aa78&&n==8){v=actor;if(defect==2&&++roots>1)v+=8;}
 else if(a==actor+0x3f8&&n==8){v=state;if(defect==3&&++states>1)v+=8;}
 else if(a==state&&n==8)v=defect==4?actor+8:actor;
 else if(a==actor+0x1b8&&n==1){uint8_t count=3;if(defect==5||(defect==15&&++counts>1))count=2;memcpy(out,&count,1);return true;}
 else if(a==base+0x66bda8&&n==8){v=base+(defect==16?0xc26890:0x17c2e30);if(defect==6&&++slots>1)v+=8;if(defect==17)v=0x90000000;}
 else if(a==base+0x17d2e30&&n==4){uint32_t cursor=8192;if(defect==7&&++cursors>1)cursor+=8192;memcpy(out,&cursor,4);return true;}
 else if(a==actor+0x1d0+0x50&&n==8){v=resource;if(defect==8||(defect==9&&++resources>1))v=resource+8;if(defect==10)v=0;}
 else if(a==actor+0x1d0+0x30&&n==8){v=base+0x14f600;if(defect==11&&++callbacks>1)v+=8;if(defect==12)v=resource;}
 else if(a==actor+0x1d0&&n==44){memcpy(out,data+0x1d0,44);if(defect==13&&++sections>1)((unsigned char *)out)[4]++;if(defect==14)((unsigned char *)out)[1]=2;return true;}
 else return false;
 memcpy(out,&v,n);return true;
}
static bool codeFixture(void *c,uintptr_t a,uintptr_t b){(void)c;return a>=b&&a-b<0x2000000;}
static bool inspect(DonorAnimationStepMetadata *m){roots=states=sections=slots=cursors=resources=callbacks=counts=0;return donorAnimationStepRead(NULL,readFixture,codeFixture,base,0x2000000,actor,actor+0x1d0,m);}
#define CHECK(c,n) do{if(!(c)){printf("FAIL %u\n",(unsigned)n);return n;}}while(0)
int main(void){DonorAnimationStepMetadata m;uint16_t clip=81;uint32_t rate=0x3f800000;memcpy(data+0x1d0+0x24,&clip,2);memcpy(data+0x1d0+0x20,&rate,4);CHECK(inspect(&m)&&m.opaqueActor==actor&&m.opaqueState==state&&m.opaqueSection==actor+0x1d0&&m.opaqueResource==resource&&m.clip==81&&m.workspace==2&&m.cursor==8192&&m.rate==rate,1);
 for(unsigned i=0;i<3;i++)CHECK(donorAnimationStepCurrentSection(actor,actor+0x1d0+i*0x68),30+i);CHECK(!donorAnimationStepCurrentSection(actor,actor+0x2000+0x1d0)&&!donorAnimationStepCurrentSection(actor,actor+0x1d1)&&!donorAnimationStepCurrentSection(0,actor+0x1d0)&&!donorAnimationStepCurrentSection(UINTPTR_MAX-7,UINTPTR_MAX-7),33);
 for(defect=1;defect<=15;defect++){if(defect==8){CHECK(inspect(&m)&&m.opaqueResource==resource+8,20);continue;}CHECK(!inspect(&m),defect+1);}defect=16;CHECK(inspect(&m)&&m.workspace==1,21);defect=17;CHECK(inspect(&m)&&m.workspace==0,22);defect=0;
 CHECK(!donorAnimationStepRead(NULL,readFixture,codeFixture,base,0x1000,actor,actor+0x1d0,&m),23);CHECK(!donorAnimationStepRead(NULL,readFixture,codeFixture,base,0x2000000,actor,actor+0x1d1,&m),24);CHECK(!donorAnimationStepRead(NULL,readFixture,codeFixture,base,0x2000000,actor,actor+0x1d0+3*0x68,&m),25);CHECK(!donorAnimationStepRead(NULL,readFixture,codeFixture,base,0x2000000,UINTPTR_MAX-7,UINTPTR_MAX-7,&m),26);
 puts("PASS: current actor/state/section/count/code/resource/timing/scratch brackets, typed native fields, default/scoped/unknown workspace classification and invalid/changed/overflow refusal");return 0;}
