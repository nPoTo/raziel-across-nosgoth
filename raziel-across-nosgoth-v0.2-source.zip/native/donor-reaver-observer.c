// SPDX-License-Identifier: GPL-3.0-or-later
// Reuse exact-image read-only process admission; no new game hooks.
#define wmain legacyTelemetryEntryUnused
#include "raziel-telemetry.c"
#undef wmain
#include "donor-reaver-reader.h"
#include "donor-reaver-effects.h"
#include "donor-reaver-graphics.h"
#include "donor-reaver-ram-output.h"
static void reaverSocketMetrics(HANDLE p,const ReaverSnapshot *s){
 uintptr_t actorMatrices=0,weaponMatrices=0,after=0,model=0,table=0;uint16_t count=0;uint32_t counts[2]={0};bool member=false;
 bool metadata=s->weapon&&reaverField(p,donorStateRead,s->weapon,0x1c0,&model,8)&&model&&reaverField(p,donorStateRead,s->object,0x20,&count,2)&&count>0&&count<=16&&reaverField(p,donorStateRead,s->object,0x28,&table,8);
 if(metadata)for(unsigned i=0;i<count;i++){uintptr_t candidate=0;if(reaverField(p,donorStateRead,table,i*8,&candidate,8)&&candidate==model)member=true;}
 metadata=metadata&&member&&reaverField(p,donorStateRead,model,4,counts,sizeof(counts))&&counts[0]>0&&counts[0]<=128&&counts[1]<=128&&counts[0]+counts[1]<=128;
 printf(",\"weaponModelMetadataValid\":%s",metadata?"true":"false");if(metadata)printf(",\"weaponBoneCounts\":[%u,%u]",counts[0],counts[1]);
 if(metadata){unsigned char index=0;bool activeRead=reaverField(p,donorStateRead,s->weapon,0xa0,&index,1);printf(",\"activeModelIndex\":%d,\"modelSlots\":[",activeRead?(int)index:-1);
 for(unsigned i=0;i<count;i++){uintptr_t candidate=0,resource=0;uint32_t generation=0,actual=0,slots[2]={0};bool slot=reaverField(p,donorStateRead,table,i*8,&candidate,8)&&candidate&&reaverField(p,donorStateRead,candidate,4,slots,sizeof(slots))&&reaverField(p,donorStateRead,candidate,0x68,&resource,8)&&reaverField(p,donorStateRead,candidate,0x70,&generation,4);bool hd=slot&&resource&&reaverField(p,donorStateRead,resource,4,&actual,4)&&generation==actual;
 printf("%s{\"slot\":%u,\"read\":%s,\"animationModel\":%s,\"bones\":[%u,%u],\"hd\":%s}",i?",":"",i,slot?"true":"false",candidate==model?"true":"false",slots[0],slots[1],hd?"true":"false");}fputc(']',stdout);}
 if(metadata){const Sheet_reaverObservationPolicy *policy=&sheet_reaverObservationPolicy_candidate;uintptr_t resource=0,resourceAgain=0;uint32_t expected=0,actual=0,flags=0;
 bool read=reaverField(p,donorStateRead,model,policy->modelResourceOffset,&resource,8)&&reaverField(p,donorStateRead,model,policy->modelResourceGenerationOffset,&expected,4);
 bool current=read&&resource&&reaverField(p,donorStateRead,resource,policy->resourceGenerationOffset,&actual,4)&&actual==expected&&reaverField(p,donorStateRead,resource,policy->resourceFlagsOffset,&flags,4)&&reaverField(p,donorStateRead,model,policy->modelResourceOffset,&resourceAgain,8)&&resourceAgain==resource;
 printf(",\"weaponHdHandlePresent\":%s,\"weaponHdGenerationMatches\":%s",read&&resource?"true":"false",current?"true":"false");if(current)printf(",\"weaponHdFlags\":%u",flags);
 }
 float hand[16],weapon[16],handAgain[16],weaponAgain[16];
 bool ok=s->attachedParent==s->actor&&s->attachedBone==50&&s->configuredHand==50&&
 reaverField(p,donorStateRead,s->actor,0x60,&actorMatrices,8)&&reaverField(p,donorStateRead,s->weapon,0x60,&weaponMatrices,8)&&
 reaverField(p,donorStateRead,actorMatrices,50*64,hand,sizeof(hand))&&reaverField(p,donorStateRead,weaponMatrices,0,weapon,sizeof(weapon))&&affine(hand)&&affine(weapon)&&
 reaverField(p,donorStateRead,actorMatrices,50*64,handAgain,sizeof(handAgain))&&reaverField(p,donorStateRead,weaponMatrices,0,weaponAgain,sizeof(weaponAgain))&&memcmp(hand,handAgain,sizeof(hand))==0&&memcmp(weapon,weaponAgain,sizeof(weapon))==0&&
 reaverField(p,donorStateRead,s->actor,0x60,&after,8)&&after==actorMatrices&&reaverField(p,donorStateRead,s->weapon,0x60,&after,8)&&after==weaponMatrices;
 printf(",\"socketMatrixPairStable\":%s",ok?"true":"false");
 if(ok){double distance=0;for(unsigned k=12;k<15;k++)distance+=((double)hand[k]-weapon[k])*((double)hand[k]-weapon[k]);printf(",\"socketOriginDistance\":%.9g",sqrt(distance));}
}
// Matrix payloads remain local; persist only two distances to candidate hands.
static void reaverDistances(HANDLE p,const ReaverSnapshot *s){
 const Sheet_reaverObservationPolicy *policy=&sheet_reaverObservationPolicy_candidate;
 uintptr_t actorMatrices=0,weaponMatrices=0,after=0;float right[16],left[16],weapon[16];
 bool ok=s->weapon&&reaverField(p,donorStateRead,s->actor,policy->matrixOffset,&actorMatrices,8)&&reaverField(p,donorStateRead,s->weapon,policy->matrixOffset,&weaponMatrices,8)&&
  reaverField(p,donorStateRead,actorMatrices,(uintptr_t)policy->rightHandCandidate*64,right,sizeof(right))&&reaverField(p,donorStateRead,actorMatrices,(uintptr_t)policy->leftHandCandidate*64,left,sizeof(left))&&reaverField(p,donorStateRead,weaponMatrices,0,weapon,sizeof(weapon))&&affine(right)&&affine(left)&&affine(weapon)&&
  reaverField(p,donorStateRead,s->actor,policy->matrixOffset,&after,8)&&after==actorMatrices&&reaverField(p,donorStateRead,s->weapon,policy->matrixOffset,&after,8)&&after==weaponMatrices;
 printf(",\"handDistanceRead\":%s",ok?"true":"false");
 if(ok){double a=0,b=0;for(unsigned k=12;k<15;k++){a+=((double)right[k]-weapon[k])*((double)right[k]-weapon[k]);b+=((double)left[k]-weapon[k])*((double)left[k]-weapon[k]);}printf(",\"handDistanceCandidates\":[%.9g,%.9g]",sqrt(a),sqrt(b));}
}
int wmain(int argc,wchar_t **argv){
 bool ram=argc==4&&!wcscmp(argv[3],L"--ram");
 unsigned long pid=0,samples=0;if((argc!=3&&!ram)||!number(argv[1],0xffffffffUL,&pid)||!number(argv[2],(unsigned long)sheet_reaverObservationPolicy_candidate.samples,&samples))return 1;
 if(ram&&GetFileType(GetStdHandle(STD_OUTPUT_HANDLE))!=FILE_TYPE_PIPE)return 5;
 HANDLE p=OpenProcess(PROCESS_VM_READ|PROCESS_QUERY_LIMITED_INFORMATION,FALSE,pid);if(!p)return 2;
 wchar_t exe[32768],expected[32768];DWORD length=ARRAYSIZE(exe),n=GetEnvironmentVariableW(L"RAZIEL_DEFIANCE_EXE",expected,ARRAYSIZE(expected));char digest[65];
 if(!n||n>=ARRAYSIZE(expected)||!QueryFullProcessImageNameW(p,0,exe,&length)||_wcsicmp(exe,expected)||!hashFile(exe,digest)||strcmp(digest,supportedHash)){CloseHandle(p);return 3;}
 HANDLE modules=CreateToolhelp32Snapshot(TH32CS_SNAPMODULE,pid);MODULEENTRY32W m={0};m.dwSize=sizeof(m);uintptr_t base=0;DWORD size=0;
 if(modules!=INVALID_HANDLE_VALUE){if(Module32FirstW(modules,&m))do{if(!_wcsicmp(m.szExePath,exe)){base=(uintptr_t)m.modBaseAddr;size=m.modBaseSize;break;}}while(Module32NextW(modules,&m));CloseHandle(modules);}
 FILETIME created,exited,kernel,user;if(!base||size<0x17c2e18||!GetProcessTimes(p,&created,&exited,&kernel,&user)){CloseHandle(p);return 4;}
 printf("{\"type\":\"session\",\"pid\":%lu,\"sha256\":\"%s\",\"processCreation\":\"%llu\",\"mode\":\"read-only-reaver-candidates\"}\n",pid,digest,(unsigned long long)(((uint64_t)created.dwHighDateTime<<32)|created.dwLowDateTime));
 uint64_t begin=GetTickCount64();
 for(unsigned long i=0;i<samples&&GetTickCount64()-begin<(uint64_t)sheet_reaverObservationPolicy_candidate.maxWallMs;i++){
  uintptr_t registry=findContext(p,base),model=0,again=0;if(registry&&!razielModel(p,registry,&model))model=0;
  if(ram){ReaverGraphics graphics={0};uint64_t started=GetTickCount64();bool valid=model&&reaverGraphicsRead(p,donorStateRead,base,size,model,&graphics)&&registry&&razielModel(p,registry,&again)&&again==model;
   reaverRamOutput(&graphics,valid,(unsigned)i,started);Sleep((DWORD)sheet_reaverObservationPolicy_candidate.intervalMs);continue;}
  ReaverObservation r=reaverObserve(p,donorStateRead,base,size,model);if(!registry||!razielModel(p,registry,&again)||again!=model)r=(ReaverObservation){.reason=7};
  DWORD foreground=0;GetWindowThreadProcessId(GetForegroundWindow(),&foreground);
  printf("{\"type\":\"sample\",\"sequence\":%lu,\"tickMs\":%llu,\"foregroundPid\":%lu,\"valid\":%s,\"present\":%s",i,(unsigned long long)GetTickCount64(),foreground,r.valid?"true":"false",r.present?"true":"false");
  printf(",\"reason\":%u",r.reason);
  if(r.valid){ReaverSnapshot *s=&r.snapshot;printf(",\"enabledRaw\":%u,\"skinRaw\":%u",s->enabled,s->skin);if(r.present)printf(",\"stateBytes\":[%u,%u,%u],\"stateFloats\":[%.9g,%.9g],\"instanceFlags\":%u,\"partMask\":%u",s->b4,s->b5,s->type,s->f24,s->f28,s->flags,s->partMask);
   if(r.present)printf(",\"drawStateRaw\":%u,\"coilStateRaw\":%u,\"fadeRaw\":[%.9g,%.9g],\"configuredHandRaw\":%u",s->drawState,s->coilState,s->fadeCurrent,s->fadeTarget,s->configuredHand);
   if(r.present)printf(",\"attachedToActor\":%s,\"attachedBoneRaw\":%d",s->attachedParent==s->actor?"true":"false",(int)s->attachedBone);
   reaverDistances(p,s);
   if(r.present)reaverSocketMetrics(p,s);
   if(r.present){ReaverGraphics graphics;bool valid=reaverGraphicsRead(p,donorStateRead,base,size,model,&graphics);
    printf(",\"graphicsSnapshotValid\":%s,\"graphicsFailureStage\":%u",valid?"true":"false",graphics.failureStage);
    if(valid){printf(",\"graphicsVertices\":%u,\"graphicsBones\":%u,\"graphicsTextures\":%u,\"graphicsAlternateColors\":%s,\"graphicsBatches\":[",graphics.vertices,graphics.bones,graphics.textureCount,graphics.alternate?"true":"false");
     for(unsigned k=0;k<graphics.batchCount;k++)printf("%s{\"part\":%u,\"indices\":%u,\"material\":%u,\"textureId\":%u}",k?",":"",graphics.batch[k].part,graphics.batch[k].count,graphics.batch[k].material,graphics.batch[k].textureId);fputc(']',stdout);
    }
   }
   if(r.present){ReaverEffects effects=reaverEffects(p,donorStateRead,base,size,s->actor,s->weapon);
    printf(",\"effectsValid\":%s,\"effectsReason\":%u,\"effectsVisited\":%u",effects.valid?"true":"false",effects.reason,effects.visited);
    if(effects.valid){fputs(",\"ownedEffects\":[",stdout);for(unsigned k=0;k<effects.owned;k++)printf("%s{\"type\":%u,\"callbackRva\":%u,\"weaponOwner\":%s}",k?",":"",effects.items[k].type,effects.items[k].callbackRva,effects.items[k].weaponOwner?"true":"false");fputc(']',stdout);}
   }
   DonorStateSections a=donorStateSectionsRead(p,donorStateRead,donorStateCode,base,size,s->actor,base+0xc5aa78);if(a.valid&&a.ownerMatches)printf(",\"callbacks\":[%u,%u,%u]",a.sections[0].firstRva,a.sections[1].firstRva,a.sections[2].firstRva);
  }
  int16_t slots[26];if(readAt(p,base+0x113ec00,slots,sizeof(slots))){fputs(",\"input\":[",stdout);for(unsigned j=0;j<26;j++)printf("%s%d",j?",":"",slots[j]);fputc(']',stdout);}
  puts("}");fflush(stdout);Sleep((DWORD)sheet_reaverObservationPolicy_candidate.intervalMs);
 }
 CloseHandle(p);return 0;
}
