// SPDX-License-Identifier: GPL-3.0-or-later
#pragma once
#include "donor-initialization-observer.h"
#include "donor-initialization-proof.h"
static DonorInitializationObserver donorInitializationObserver;
static DonorNativeInitialization donorInitializationOriginal;static PVOID donorInitializationTarget;
static _Thread_local uint32_t donorInitializationDepth;
static uintptr_t donorInitializationBase;static uint32_t donorInitializationImageSize;
static bool donorInitializationSnapshot(void *unused,uintptr_t expected,DonorAnimationContextObservation *out){
 (void)unused;uintptr_t actor=0;
 // Re-resolve the model in the current registry. No pre-load object/context cache.
 donorProcessFindModel();uintptr_t model=(uintptr_t)InterlockedCompareExchangePointer(&donorRazielObject,NULL,NULL);
 if(!worldRead(donorInitializationBase+0xc5aa78,&actor,8)||!actor||(expected&&actor!=expected))return false;
 *out=donorAnimationContextRead(NULL,donorMessageRead,donorInitializationBase,donorInitializationImageSize,model);
 uintptr_t again=0;return out->valid&&worldRead(donorInitializationBase+0xc5aa78,&again,8)&&again==actor;
}
static uintptr_t __fastcall donorInitializationHook(uintptr_t actor){
 DWORD incoming=GetLastError();uintptr_t caller=(uintptr_t)__builtin_return_address(0);uint32_t rva=caller>=donorInitializationBase&&caller-donorInitializationBase<donorInitializationImageSize?(uint32_t)(caller-donorInitializationBase):0;SetLastError(incoming);
 return donorInitializationForward(&donorInitializationObserver,&donorInitializationDepth,donorInitializationOriginal,actor,rva);
}
static void donorInitializationDrain(void){
 DonorInitializationEvent e;unsigned n=0;while(n++<64&&donorInitializationPop(&donorInitializationObserver,&e))logLine("DONOR_INITIALIZATION {\"epoch\":%llu,\"tick\":%llu,\"phase\":%u,\"thread\":%u,\"depth\":%u,\"callerRva\":%u,\"active\":%u,\"current\":%u,\"valid\":%u,\"availableMask\":%u,\"cachedMatchMask\":%u,\"keys\":[%u,%u,%u]}",(unsigned long long)e.epoch,(unsigned long long)e.tick,e.phase,e.thread,e.depth,e.callerRva,e.active,e.current,e.valid,e.availableMask,e.cachedMatchMask,e.keys[0],e.keys[1],e.keys[2]);
}
static void donorInitializationTick(void){
 donorInitializationDrain();if(!donorInitializationTarget)return;
 uint64_t epoch=(uint64_t)InterlockedCompareExchange64(&donorInitializationObserver.epoch,0,0);DonorAnimationContextObservation m={0};
 bool valid=donorInitializationCurrent(&donorInitializationObserver,epoch,GetTickCount64())&&donorInitializationSnapshot(NULL,0,&m)&&donorInitializationCurrent(&donorInitializationObserver,epoch,GetTickCount64());
 logLine("DONOR_INITIALIZATION_STATUS epoch=%llu valid=%u active=%ld stopped=%ld calls=%lld published=%lld dropped=%lld keys=%u,%u,%u available=%u cached=%u; observed_init_only=1; synthetic_calls=0",(unsigned long long)epoch,valid,InterlockedCompareExchange(&donorInitializationObserver.active,0,0),InterlockedCompareExchange(&donorInitializationObserver.stopped,0,0),InterlockedCompareExchange64(&donorInitializationObserver.calls,0,0),InterlockedCompareExchange64(&donorInitializationObserver.published,0,0),InterlockedCompareExchange64(&donorInitializationObserver.dropped,0,0),valid?m.selectionKeys[0]:0,valid?m.selectionKeys[1]:0,valid?m.selectionKeys[2]:0,valid?m.availableMask:0,valid?m.cachedMatchMask:0);
}
static bool donorInitializationInstall(HMODULE module){
 if(donorInitializationTarget)return false;uintptr_t base=(uintptr_t)module;IMAGE_DOS_HEADER dos={0};IMAGE_NT_HEADERS64 nt={0};unsigned char body[3267];char sha[65];
 if(!worldRead(base,&dos,sizeof(dos))||dos.e_magic!=IMAGE_DOS_SIGNATURE||dos.e_lfanew<=0||dos.e_lfanew>0x100000||!worldRead(base+(uintptr_t)dos.e_lfanew,&nt,sizeof(nt))||nt.Signature!=IMAGE_NT_SIGNATURE||nt.OptionalHeader.Magic!=IMAGE_NT_OPTIONAL_HDR64_MAGIC||nt.OptionalHeader.SizeOfImage<0x1140498)return false;
 for(unsigned i=0;i<4;i++){const DonorInitializationProof *p=&donorInitializationProofs[i];if(p->bytes>sizeof(body)||!worldRead(base+p->rva,body,p->bytes)||!hashBytes(body,p->bytes,sha)||strcmp(sha,p->sha256))return false;}
 donorInitializationBase=base;donorInitializationImageSize=nt.OptionalHeader.SizeOfImage;donorInitializationInit(&donorInitializationObserver,GetTickCount64(),NULL,donorInitializationSnapshot);if(!donorInitializationObserver.configured)return false;
 MH_STATUS init=MH_Initialize();if(init!=MH_OK&&init!=MH_ERROR_ALREADY_INITIALIZED)return false;
 PVOID target=(PVOID)(base+DONOR_INITIALIZATION_RVA);if(MH_CreateHook(target,(PVOID)donorInitializationHook,(PVOID *)&donorInitializationOriginal)!=MH_OK||!donorInitializationOriginal)return false;
 if(MH_EnableHook(target)!=MH_OK){InterlockedExchange(&donorInitializationObserver.stopped,1);return false;}donorInitializationTarget=target;return true;
}
static void donorInitializationStop(void){
 InterlockedExchange(&donorInitializationObserver.stopped,1);if(donorInitializationTarget){MH_STATUS s=MH_DisableHook(donorInitializationTarget);if(s==MH_OK||s==MH_ERROR_DISABLED)donorInitializationTarget=NULL;else logLine("DONOR_INITIALIZATION_SHUTDOWN hook_disable=%d; ownership retained",s);}donorInitializationDrain();
 logLine("DONOR_INITIALIZATION_END calls=%lld active=%ld dropped=%lld; probe pinned and trampoline retained until process exit; no unload proof",InterlockedCompareExchange64(&donorInitializationObserver.calls,0,0),InterlockedCompareExchange(&donorInitializationObserver.active,0,0),InterlockedCompareExchange64(&donorInitializationObserver.dropped,0,0));
}
