#include "report-path.h"
// Read-only current-player controller vector observation. Original RAX forwarded.
#include "motion-code-proof.h"
#include "movement-forward.h"
typedef uintptr_t (__fastcall *MotionVectorFn)(uintptr_t,int32_t,int32_t,uintptr_t);
static MotionVectorFn originalMotion[2];static PVOID motionTargets[2];static bool motionAttempted;
static volatile LONG motionEnabled,motionLock,motionDrops;
static unsigned motionHead,motionTail,motionRecords;static ULONGLONG motionBegin;
typedef struct {ULONGLONG tick,sourceTick;uintptr_t player,anim,caller,result;int32_t section,type,adjustment,timeRaw;unsigned kind;bool timeValid,forwarded;float vector[3],delivered;} MotionEvent;
static MotionEvent motionQueue[512];
static uintptr_t motionObserve(unsigned kind,uintptr_t anim,int32_t section,int32_t type,uintptr_t vector,uintptr_t caller){
    MotionEvent e={0};uintptr_t player=0;float root[16];
    bool recording=InterlockedCompareExchange(&motionEnabled,0,0)!=0;
    bool valid=(recording||InterlockedCompareExchange(&movementEnabled,0,0))&&section==0&&type==0x22&&worldRoot(root,&player)&&anim==player+(kind?0x448:0x328);
    if(valid){e.tick=GetTickCount64();e.player=player;e.anim=anim;e.kind=kind;e.section=section;e.type=type;e.caller=caller;
        if(kind)valid=worldRead(vector,e.vector,sizeof(e.vector));
        else {int16_t values[3];valid=worldRead(vector,values,sizeof(values));if(valid)for(unsigned i=0;i<3;i++)e.vector[i]=values[i];}
        for(unsigned i=0;i<3&&valid;i++)if(!isfinite(e.vector[i])||fabsf(e.vector[i])>100000)valid=false;
        valid=valid&&worldRead(player+0x370,&e.adjustment,sizeof(e.adjustment));
        uintptr_t module=(uintptr_t)InterlockedCompareExchangePointer(&verifiedSr1Module,NULL,NULL);
        // Exact supported razApplyMotion reads this integer at RVAfc81c.
        e.timeValid=module&&worldRead(module+0x2a89628,&e.timeRaw,sizeof(e.timeRaw))&&e.timeRaw>0&&e.timeRaw<=32768;}
    float wide[3]={0};int16_t small[3]={0};uintptr_t delivered=vector;
    if(valid&&e.timeValid&&fabsf(e.vector[0])<.001f&&fabsf(e.vector[2])<.001f&&e.vector[1]<=0&&
        movementScope(player,caller,kind,e.tick,root,e.timeRaw)&&movementLoad(&e.delivered,&e.sourceTick,e.timeRaw,e.tick)){
        if(kind){wide[1]=e.delivered;delivered=(uintptr_t)wide;}else {small[1]=(int16_t)e.delivered;e.delivered=small[1];delivered=(uintptr_t)small;}
        e.forwarded=true;++movementForwarded;
    }
    uintptr_t result=originalMotion[kind](anim,section,type,delivered);e.result=result;
    if(!valid||(!recording&&!e.forwarded))return result;
    if(!InterlockedCompareExchange(&motionLock,1,0)){
        if(!motionBegin)motionBegin=e.tick;
        unsigned next=(motionHead+1)%ARRAYSIZE(motionQueue);
        if(e.tick>=motionBegin&&e.tick-motionBegin<120000&&motionRecords<4000){if(next!=motionTail){motionQueue[motionHead]=e;motionHead=next;++motionRecords;}else InterlockedIncrement(&motionDrops);}
        InterlockedExchange(&motionLock,0);
    }else InterlockedIncrement(&motionDrops);
    return result;
}
static uintptr_t __fastcall observeMotionShort(uintptr_t anim,int32_t section,int32_t type,uintptr_t vector){return motionObserve(0,anim,section,type,vector,(uintptr_t)__builtin_return_address(0));}
static uintptr_t __fastcall observeMotionFloat(uintptr_t anim,int32_t section,int32_t type,uintptr_t vector){return motionObserve(1,anim,section,type,vector,(uintptr_t)__builtin_return_address(0));}
static void motionFlush(void){
    MotionEvent local[512];unsigned count=0;if(InterlockedCompareExchange(&motionLock,1,0))return;
    while(motionTail!=motionHead){local[count++]=motionQueue[motionTail];motionTail=(motionTail+1)%ARRAYSIZE(motionQueue);}InterlockedExchange(&motionLock,0);
    for(unsigned i=0;i<count;i++){MotionEvent *e=&local[i];logLine("SR1_MOTION tick=%llu kind=%u player=%p anim=%p caller=%p section=%d type=%d adjustment=%d vector=%.9g,%.9g,%.9g result=%p timeValid=%u timeRaw=%d forwarded=%u deliveredY=%.9g sourceTick=%llu",
        e->tick,e->kind,(void *)e->player,(void *)e->anim,(void *)e->caller,e->section,e->type,e->adjustment,e->vector[0],e->vector[1],e->vector[2],(void *)e->result,e->timeValid,e->timeRaw,e->forwarded,e->delivered,e->sourceTick);}
}
static void motionInstall(HMODULE module){
    if(motionAttempted)return;motionAttempted=true;
    for(unsigned i=0;i<2;i++){
        unsigned char code[64];char hash[65];uintptr_t target=(uintptr_t)module+motionCodeProofs[i].rva;
        if(motionCodeProofs[i].size>sizeof(code)||!worldRead(target,code,motionCodeProofs[i].size)||!hashBytes(code,motionCodeProofs[i].size,hash)||strcmp(hash,motionCodeProofs[i].sha256)){logLine("SR1_MOTION kind=%u code proof failed",i);continue;}
        MH_STATUS init=MH_Initialize();if(init!=MH_OK&&init!=MH_ERROR_ALREADY_INITIALIZED)continue;
        MH_STATUS create=MH_CreateHook((PVOID)target,i?(PVOID)&observeMotionFloat:(PVOID)&observeMotionShort,(PVOID *)&originalMotion[i]);
        MH_STATUS enable=create==MH_OK?MH_EnableHook((PVOID)target):create;if(enable==MH_OK)motionTargets[i]=(PVOID)target;
        logLine("SR1_MOTION kind=%u create=%d enable=%d full-code proof=1; original forwarded unchanged",i,create,enable);
    }
}
static void motionTick(void){
    movementTick();
    bool requested=GetFileAttributesW(PROBE_PATH(L"\\motion-sr1.enable"))!=INVALID_FILE_ATTRIBUTES;
    if(!requested)InterlockedExchange(&motionEnabled,0);
    else if(!InterlockedCompareExchange(&motionEnabled,0,0)&&!InterlockedCompareExchange(&motionLock,1,0)){motionBegin=0;motionRecords=0;InterlockedExchange(&motionEnabled,1);InterlockedExchange(&motionLock,0);}
    motionFlush();
}
static void motionStop(void){InterlockedExchange(&movementEnabled,0);InterlockedExchange(&motionEnabled,0);for(unsigned i=0;i<2;i++)if(motionTargets[i])MH_DisableHook(motionTargets[i]);motionFlush();}
