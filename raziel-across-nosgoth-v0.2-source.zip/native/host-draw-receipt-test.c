// SPDX-License-Identifier: GPL-3.0-or-later
#include <assert.h>
#include <stdio.h>
#include "host-draw-receipt.h"
int main(void){
 HostDrawReceipt s={.magic=0x31524448,.version=1,.pid=12,.valid=1,.creation=99,.tick=1000,.serial=1};
 memcpy(s.policy,skeletonPolicyHash,32);s.rig.count=66;s.rig.actor=1;s.rig.object=2;s.rig.model=3;s.rig.legacy=100;s.rig.render=200;
 s.context.identity=s.context.foreground=s.context.verticalVelocityKnown=true;
 HostRig current=s.rig;Sr1RetargetContext c=s.context;
 assert(hostDrawAccept(&s,12,99,1010,&current,&c));
 // Owned copy survives legitimate rotation of both native buffers. No old
 // address is dereferenced and capture time cannot be refreshed by a reader.
 current.legacy=300;current.render=400;assert(hostDrawAccept(&s,12,99,1150,&current,&c));assert(!hostDrawAccept(&s,12,99,1151,&current,&c));assert(!hostDrawAccept(&s,12,99,999,&current,&c));
 assert(!hostDrawAccept(&s,13,99,1010,&current,&c));assert(!hostDrawAccept(&s,12,100,1010,&current,&c));
 current.model++;assert(!hostDrawAccept(&s,12,99,1010,&current,&c));current=s.rig;
 current.parents[3]++;assert(!hostDrawAccept(&s,12,99,1010,&current,&c));current=s.rig;
 c.callbacks[1]++;assert(!hostDrawAccept(&s,12,99,1010,&current,&c));c=s.context;c.foreground=false;assert(!hostDrawAccept(&s,12,99,1010,&current,&c));c=s.context;c.mode=6;assert(!hostDrawAccept(&s,12,99,1010,&current,&c));c=s.context;
#ifdef SR1_DRAW_PHASE_COMPAT
 Sr1RetargetContext idle=c,move=c;for(unsigned i=0;i<3;i++){idle.callbacks[i]=0xf2180;move.callbacks[i]=0xf3280;}
 assert(!hostDrawContextSame(&idle,&move));assert(hostDrawCurrentContextCompatible(&idle,&move));assert(hostDrawCurrentContextCompatible(&move,&idle));
 s.context=idle;assert(hostDrawAccept(&s,12,99,1150,&current,&move));assert(!hostDrawAccept(&s,12,99,1151,&current,&move));
 move.callbacks[1]=0xf2180;assert(hostDrawCurrentContextCompatible(&idle,&move));
 const uint32_t forbidden[]={0xefb50,0xedb40,0xee600,0xf2ae0,0xdead};
 for(unsigned i=0;i<sizeof(forbidden)/sizeof(*forbidden);i++){Sr1RetargetContext bad=move;bad.callbacks[1]=forbidden[i];assert(!hostDrawCurrentContextCompatible(&idle,&bad));}
 Sr1RetargetContext bad=move;bad.crouchHeld=true;assert(!hostDrawCurrentContextCompatible(&idle,&bad));bad=move;bad.mode=6;assert(!hostDrawCurrentContextCompatible(&idle,&bad));bad=move;bad.flags^=1;assert(!hostDrawCurrentContextCompatible(&idle,&bad));bad=move;bad.verticalVelocity=1;assert(!hostDrawCurrentContextCompatible(&idle,&bad));
 Sr1RetargetContext jump=c;for(unsigned i=0;i<3;i++)jump.callbacks[i]=0xf2ae0;jump.verticalVelocity=138;
 Sr1RetargetContext later=jump;later.verticalVelocity=122;
 assert(!hostDrawContextSame(&jump,&later)); // Publication still requires unchanged native input/context.
 assert(hostDrawCurrentContextCompatible(&jump,&later));
 s.context=jump;assert(hostDrawAccept(&s,12,99,1010,&current,&later));assert(!hostDrawAccept(&s,12,99,1151,&current,&later));
 later.callbacks[1]=0xefb50;assert(!hostDrawCurrentContextCompatible(&jump,&later));later=jump;later.flags^=1;assert(!hostDrawCurrentContextCompatible(&jump,&later));
 later=jump;later.verticalVelocity=2049;assert(!hostDrawCurrentContextCompatible(&jump,&later));later=jump;later.foreground=false;assert(!hostDrawCurrentContextCompatible(&jump,&later));
 later=c;later.verticalVelocity=1;assert(!hostDrawCurrentContextCompatible(&c,&later));s.context=c;
#endif
 s.policy[0]^=1;assert(!hostDrawAccept(&s,12,99,1010,&current,&c));s.policy[0]^=1;
 float nan=NAN;memcpy(s.rig.renderBytes[6],&nan,4);assert(!hostDrawAccept(&s,12,99,1010,&current,&c));memset(s.rig.renderBytes[6],0,4);
 HostDrawShared shared={0};HostDrawReceipt out;hostDrawStore(&shared,&s);assert(hostDrawCopy(&shared,&out)&&!memcmp(&s,&out,sizeof(s)));shared.sequence|=1;assert(!hostDrawCopy(&shared,&out));shared.sequence++;s.valid=0;hostDrawStore(&shared,&s);assert(hostDrawCopy(&shared,&out)&&!hostDrawAccept(&out,12,99,1010,&current,&c));
 puts("native draw receipt: buffer rotation, time, resource/context/process identity, torn/invalid copy PASS; synthetic only");return 0;
}
