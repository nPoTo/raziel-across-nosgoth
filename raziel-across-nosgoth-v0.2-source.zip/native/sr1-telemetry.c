// Build-gated, read-only Soul Reaver 1 transform publisher. No game writes.
#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <tlhelp32.h>
#include <bcrypt.h>
#include <stdbool.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <wchar.h>
#include <math.h>
#include "reader-hash.h"
#include "recording-status.h"
static bool readAt(HANDLE p,uintptr_t at,void *out,SIZE_T size) { SIZE_T actual=0; return at&&ReadProcessMemory(p,(LPCVOID)at,out,size,&actual)&&actual==size; }
static uintptr_t pointer(const unsigned char *b) { uintptr_t v; memcpy(&v,b,8); return v; }
static int16_t shortAt(const unsigned char *b) {int16_t v; memcpy(&v,b,2); return v;}
static int32_t intAt(const unsigned char *b) {int32_t v; memcpy(&v,b,4); return v;}
#include "fx-list-reader.h"
#include "host-camera-reader.h"
int wmain(int argc,wchar_t **argv) {
    bool fxMode=argc==6&&!wcscmp(argv[1],L"--fx"),cameraMode=argc==6&&!wcscmp(argv[1],L"--camera");int first=(fxMode||cameraMode)?2:1;
    if(argc!=5&&!fxMode&&!cameraMode) { puts("Usage: sr1-telemetry [--fx|--camera] PID SAMPLES INTERVAL_MS OUTPUT_JSONL"); return 1; }
    wchar_t *end; unsigned long args[3];
    for(int i=0;i<3;i++) { args[i]=wcstoul(argv[i+first],&end,10); if(!*argv[i+first]||*end||!args[i]){fwprintf(stderr,L"Invalid numeric argument %d: %ls (argc=%d fx=%d)\n",i,argv[i+first],argc,fxMode);return 1;} }
    if(args[1]>(unsigned long)(GetEnvironmentVariableW(L"RAZIEL_LIFETIME_TEST",NULL,0)?sheet_sessionLifetime_session.maxSamples:sheet_diagnosticLimits_controls.maxSamples)||args[2]>1000){fprintf(stderr,"Capture limits exceeded: samples=%lu interval=%lu\n",args[1],args[2]);return 1;}
    DWORD pid=args[0]; HANDLE p=OpenProcess(PROCESS_VM_READ|PROCESS_QUERY_LIMITED_INFORMATION,FALSE,pid); if(!p) return 2;
    char hash[65]; wchar_t path[32768],dll[32768]; DWORD len=ARRAYSIZE(path);
    if(!QueryFullProcessImageNameW(p,0,path,&len)||len+12>=ARRAYSIZE(path)||!wcsrchr(path,L'\\')||_wcsicmp(wcsrchr(path,L'\\')+1,L"SRX.exe")||!hashFile(path,hash)||strcmp(hash,"0fb3aef0530ebf0510191f934dc371b69b43574331d3623eda694b72f060db93"))return 3;
    wcscpy(dll,path);wcscpy(wcsrchr(dll,L'\\')+1,L"1\\sr1.dll");
    if(!hashFile(dll,hash)||strcmp(hash,"c006dea45509cdc3fbfab3a4230b47869c306ecdd7df8b4fd2499fd3654a2205"))return 3;
    HANDLE modules=CreateToolhelp32Snapshot(TH32CS_SNAPMODULE,pid); MODULEENTRY32W m={0}; m.dwSize=sizeof(m); uintptr_t base=0;DWORD imageSize=0;
    if(modules!=INVALID_HANDLE_VALUE) { if(Module32FirstW(modules,&m)) do { if(!_wcsicmp(m.szExePath,dll)&&m.modBaseSize>0x2a89318) {base=(uintptr_t)m.modBaseAddr;imageSize=m.modBaseSize; break;} } while(Module32NextW(modules,&m)); CloseHandle(modules); }
    if(!base) return 4;
    if(fxMode&&!fxListGate(p,base)){CloseHandle(p);return 7;}
    if(cameraMode&&!hostCameraGate(p,base,imageSize)){CloseHandle(p);return 8;}
    bool pipeOutput=!wcscmp(argv[first+3],L"-");
    FILE *out=pipeOutput?stdout:_wfopen(argv[first+3],L"wb"); if(!out) return 5;
    fprintf(out,"{\"type\":\"session\",\"game\":\"sr1\",\"pid\":%lu,\"moduleHash\":\"%s\",\"base\":\"0x%llx\",\"mode\":\"read-only\",\"fxList\":%s,\"cameraNative\":%s}\n",pid,hash,(unsigned long long)base,fxMode?"true":"false",cameraMode?"true":"false");
    unsigned int valid=0;uint64_t cameraStart=GetTickCount64();
    for(unsigned long seq=0;seq<args[1];seq++) {
        if(cameraMode&&GetTickCount64()-cameraStart>=138000)break;
        uintptr_t instance=0,after=0,name=0; unsigned char bytes[384],matrix[32]; char objectName[9]={0};
        bool ok=readAt(p,base+0x2a89310,&instance,8)&&readAt(p,instance,bytes,sizeof(bytes))&&
            readAt(p,pointer(bytes+0x30)+0x30,&name,8)&&readAt(p,name,objectName,9)&&!memcmp(objectName,"raziel__",9)&&
            readAt(p,pointer(bytes+0x68),matrix,sizeof(matrix))&&readAt(p,base+0x2a89310,&after,8)&&after==instance;
        uintptr_t objectAfter=0,matrixAfter=0;
        ok=ok&&readAt(p,instance+0x30,&objectAfter,8)&&objectAfter==pointer(bytes+0x30)&&readAt(p,instance+0x68,&matrixAfter,8)&&matrixAfter==pointer(bytes+0x68);
        float root[16]={0}; root[15]=1;
        if(ok) {
            for(int r=0;r<3;r++) for(int c=0;c<3;c++) root[c*4+r]=shortAt(matrix+(r*3+c)*2)/4096.0f;
            for(int k=0;k<3;k++) {root[12+k]=(float)intAt(matrix+20+k*4); if(fabsf(root[12+k])>1000000) ok=false;}
            for(int c=0;c<3;c++) {float norm=0; for(int r=0;r<3;r++) norm+=root[c*4+r]*root[c*4+r]; if(fabsf(norm-1)>.03f) ok=false;}
        }
        fprintf(out,"{\"type\":\"sample\",\"sequence\":%lu,\"tickMs\":%llu,\"valid\":%s",seq,(unsigned long long)GetTickCount64(),ok?"true":"false");
        if(ok) {
            valid++; fprintf(out,",\"instance\":\"0x%llx\",\"object\":\"0x%llx\",\"name\":\"raziel__\",\"positionCandidate\":[%d,%d,%d],\"rootMatrix\":[",(unsigned long long)instance,(unsigned long long)pointer(bytes+0x30),shortAt(bytes+0x9c),shortAt(bytes+0x9e),shortAt(bytes+0xa0));
            for(int k=0;k<16;k++) { if(k) fputc(',',out); fprintf(out,"%.9g",root[k]); } fputc(']',out);
            // Exact actor velocity/acceleration offsets already verified by the
            // physics observer; state pointer must belong to this same actor.
            int32_t kinematics[6];uintptr_t stateActor=0,process=0,checkActor=0,checkProcess=0;
            bool motionOk=readAt(p,instance+0x2cc,kinematics,sizeof(kinematics))&&
                readAt(p,base+0x2a88588,&stateActor,8)&&stateActor==instance&&
                readAt(p,base+0x2a88598,&process,8)&&process>=base&&process<base+imageSize&&
                readAt(p,base+0x2a88588,&checkActor,8)&&checkActor==stateActor&&
                readAt(p,base+0x2a88598,&checkProcess,8)&&checkProcess==process;
            fprintf(out,",\"nativeMotion\":{\"valid\":%s",motionOk?"true":"false");
            if(motionOk)fprintf(out,",\"processRva\":\"0x%llx\",\"velocity\":[%d,%d,%d],\"acceleration\":[%d,%d,%d]",(unsigned long long)(process-base),kinematics[0],kinematics[1],kinematics[2],kinematics[3],kinematics[4],kinematics[5]);
            fputc('}',out);
        }
        if(fxMode&&ok){fprintf(out,",\"fx\":");fxListObserve(out,p,base,instance,imageSize);}
        if(cameraMode&&ok)hostCameraObserve(out,p,base,instance);
        fprintf(out,"}\n"); fflush(out);
        if(!pipeOutput){if(cameraMode)recordingWriteStatus(pid,(uint32_t)((GetTickCount64()-cameraStart)/100)+1,1380);
        else recordingWriteStatus(pid,(uint32_t)seq+1,(uint32_t)args[1]);}
        if(seq+1<args[1]) Sleep(args[2]);
    }
    if(!pipeOutput)recordingStopStatus(pid);fclose(out); CloseHandle(p); fprintf(pipeOutput?stderr:stdout,"SR1 identity + root samples: %u/%lu\n",valid,args[1]); return valid?0:6;
}

