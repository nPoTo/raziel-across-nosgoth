// SPDX-License-Identifier: GPL-3.0-or-later
#include <assert.h>
#include <stdio.h>
#include "sr1-native-pose-forward.h"
static unsigned calls;static const uintptr_t expected[8]={0x101,0x202,0x303,0x404,0x505,0x606,0x707,0x808};
static uintptr_t original(uintptr_t a,uintptr_t b,uintptr_t c,uintptr_t d,uintptr_t e,uintptr_t f,uintptr_t g,uintptr_t h){const uintptr_t seen[8]={a,b,c,d,e,f,g,h};for(unsigned i=0;i<8;i++)assert(seen[i]==expected[i]);calls++;return UINTPTR_MAX-123;}
int main(void){assert(sr1NativePoseForward(original,expected)==UINTPTR_MAX-123);assert(calls==1);assert(sr1NativePoseArgumentsMatch(0x1070,0x2000,0x3000,0x1000,0x2000,0x3000,0x70));assert(!sr1NativePoseArgumentsMatch(0x4070,0x2000,0x3000,0x1000,0x2000,0x3000,0x70));assert(!sr1NativePoseArgumentsMatch(0x1070,0x4000,0x3000,0x1000,0x2000,0x3000,0x70));assert(!sr1NativePoseArgumentsMatch(0x1070,0x2000,0x4000,0x1000,0x2000,0x3000,0x70));assert(!sr1NativePoseArgumentsMatch(0x60,0x2000,0x3000,UINTPTR_MAX-15,0x2000,0x3000,0x70));assert(!sr1NativePoseArgumentsMatch(0x70,0x2000,0x3000,0,0x2000,0x3000,0x70));puts("native8-slot forwarding/opaque return and foreign record/model/matrix/overflow rejection PASS; fixture only, no live ABI acceptance");return 0;}
