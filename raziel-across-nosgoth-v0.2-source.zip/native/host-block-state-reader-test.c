// SPDX-License-Identifier: GPL-3.0-or-later
#define WIN32_LEAN_AND_MEAN
#include <stdio.h>
#include "host-block-state-reader.h"
static const uintptr_t base=0x10000000,actor=0x20000000,engagement=0x30000000,target=0x40000000;
static int defect;static unsigned actorReads,callbackReads,recordReads,targetReads;static bool away;
static bool fixture(void *unused,uintptr_t address,void *out,SIZE_T size){
 (void)unused;uintptr_t v=0;
 if(address==base+0x2a89310&&size==8){v=actor;if(defect==1&&++actorReads>1)v+=8;}
 else if(address==base+0x2a88588&&size==8)v=defect==2?actor+8:actor;
 else if(address==base+0x2a88ca0&&size==8)v=away?0:engagement;
 else if(address==base+0x2a88ca8&&size==1){*(unsigned char *)out=away?0:3;return true;}
 else if(address==engagement&&size==8)v=target;
 else if(address==engagement+0x10&&size==8){v=target;if(defect==3&&++targetReads>1)v+=8;}
 else if(address==actor+0x118&&size==4){uint32_t n=4;memcpy(out,&n,4);return true;}
 else if(address==target+0x64&&size==4){uint32_t n=defect==4?0:4;if(defect==5)return false;memcpy(out,&n,4);return true;}
 else{
  for(unsigned i=0;i<3;i++){
   uintptr_t s=base+0x2a88588+i*0x228,q=s+0x18;
   if(address==s+0x10&&size==8){v=base+0xf2180;if(defect==6)v=base+0x3000000;if(defect==7&&++callbackReads>3)v+=8;memcpy(out,&v,8);return true;}
   if((address==q||address==q+4)&&size==4){int32_t n=i==0?(address==q?15:0):0;if(defect==8&&address==q)n=-1;if(defect==9&&address==q+4)n=16;memcpy(out,&n,4);return true;}
   if(address==q+8+15*16&&size==4){uint32_t id=0x100001;if(defect==10&&++recordReads>1)id++;memcpy(out,&id,4);return true;}
   if(address==q+16+15*16&&size==8){v=0xdeadface;if(defect==11)return false;memcpy(out,&v,8);return true;}
  }
  return false;
 }
 memcpy(out,&v,size);return true;
}
static bool code(void *unused,uintptr_t address,uintptr_t module){(void)unused;return module==base&&address==base+0xf2180&&defect!=12;}
static HostBlockState get(void){actorReads=callbackReads=recordReads=targetReads=0;return hostBlockStateRead(NULL,fixture,code,base,0x3000000,actor);}
#define CHECK(c,n) do{if(!(c)){printf("FAIL %d\n",n);return n;}}while(0)
int main(void){
 HostBlockState r=get();CHECK(r.valid&&r.flagsMask==3&&r.entryPresent&&r.heldPresent&&r.slotsEqual&&r.relationKnown&&r.relationEqual,1);CHECK(r.sections[0].pending&&r.sections[0].readIndex==15&&r.sections[0].writeIndex==0&&r.sections[0].messageId==0x100001&&!r.sections[0].payloadZero&&!r.sections[1].pending,2);
 for(defect=1;defect<=3;defect++)CHECK(!get().valid,10+defect);
 defect=4;r=get();CHECK(r.valid&&r.relationKnown&&!r.relationEqual&&r.targetRelationZero,20);
 defect=5;r=get();CHECK(r.valid&&!r.relationKnown,21);
 for(defect=6;defect<=12;defect++)CHECK(!get().valid,30+defect);
 defect=0;away=true;r=get();CHECK(r.valid&&!r.engagementPresent&&!r.entryPresent&&!r.heldPresent&&!r.slotsEqual&&!r.relationKnown&&r.flagsMask==0,50);
 CHECK(!hostBlockStateRead(NULL,fixture,code,UINTPTR_MAX-4,0x3000000,actor).valid,51);CHECK(!hostBlockStateRead(NULL,fixture,code,base,0x1000,actor).valid,52);CHECK(!hostBlockStateRead(NULL,fixture,code,base,0x3000000,actor+1).valid,53);
 puts("PASS: production SR1 three-section/queue/target reader, wrap/empty/pending distinction, actor/owner/target/callback/message races, optional relation, bounds/foreign-code guards; no native pointers or payload dereferences");return 0;
}
