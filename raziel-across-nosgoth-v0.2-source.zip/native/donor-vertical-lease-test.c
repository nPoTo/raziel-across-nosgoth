// SPDX-License-Identifier: GPL-3.0-or-later
#include "donor-vertical-lease.h"
#include <assert.h>
#include <stdio.h>
typedef struct {float v[3];uintptr_t actor;uint64_t generation;unsigned writes,failAt;} Memory;
static bool readState(void *context,uintptr_t actor,uint64_t generation,float out[3]){
 Memory *m=context;if(actor!=m->actor||generation!=m->generation)return false;memcpy(out,m->v,sizeof(m->v));return true;
}
static bool writeState(void *context,uintptr_t actor,uint64_t generation,unsigned field,float value){
 Memory *m=context;if(actor!=m->actor||generation!=m->generation||field>=3)return false;
 m->v[field]=value;++m->writes;return m->writes!=m->failAt;
}
static Memory memory(void){return (Memory){.v={120,120,0},.actor=0x1234,.generation=42};}
int main(void){
 Memory m=memory();DonorVerticalLease lease={0};
 assert(!donorVerticalAcquire(&lease,&m,readState,m.actor,m.generation,false));
 assert(donorVerticalAcquire(&lease,&m,readState,m.actor,m.generation,true));
 for(unsigned i=0;i<600;i++){
  m.v[0]=120-(float)(i%24);m.v[1]=120;m.v[2]=-(float)i;
  float velocity=m.v[2];assert(donorVerticalPin(&lease,&m,readState,writeState));
  assert(m.v[0]==120&&m.v[1]==120&&m.v[2]==velocity);
 }
 assert(donorVerticalRelease(&lease,&m,readState,writeState));
 assert(m.v[0]==120&&m.v[1]==120&&m.v[2]==0);
 assert(!donorVerticalPin(&lease,&m,readState,writeState));
 assert(!donorVerticalAcquire(&lease,&m,readState,m.actor,m.generation,true));
 for(unsigned fail=1;fail<=2;fail++){
  m=memory();lease=(DonorVerticalLease){0};assert(donorVerticalAcquire(&lease,&m,readState,m.actor,m.generation,true));
  m.v[0]=117;m.v[1]=118;m.v[2]=-90;float before[3];memcpy(before,m.v,sizeof(before));m.failAt=fail;
  assert(!donorVerticalPin(&lease,&m,readState,writeState)&&lease.failed);
  assert(!memcmp(m.v,before,sizeof(before)));
 }
 // A failure after an earlier successful pin must restore from THIS frame,
 // whose native physics changed Z/VZ, not the previous frame's saved receipt.
 m=memory();lease=(DonorVerticalLease){0};
 assert(donorVerticalAcquire(&lease,&m,readState,m.actor,m.generation,true));
 m.v[0]=117;m.v[2]=-90;assert(donorVerticalPin(&lease,&m,readState,writeState));
 m.v[0]=116;m.v[1]=117;m.v[2]=-100;m.failAt=m.writes+2;
 assert(!donorVerticalPin(&lease,&m,readState,writeState));
 assert(donorVerticalRelease(&lease,&m,readState,writeState));
 assert(m.v[0]==120&&m.v[1]==120&&m.v[2]==0);
 for(unsigned fault=0;fault<3;fault++){
  m=memory();lease=(DonorVerticalLease){0};assert(donorVerticalAcquire(&lease,&m,readState,m.actor,m.generation,true));
  m.v[0]=117;m.v[2]=-90;assert(donorVerticalPin(&lease,&m,readState,writeState));
  if(fault==0)m.actor++;if(fault==1)m.generation++;if(fault==2)m.v[0]++;
  unsigned writes=m.writes;assert(!donorVerticalRelease(&lease,&m,readState,writeState));assert(m.writes==writes);
 }
 for(unsigned fail=1;fail<=3;fail++){
  m=memory();lease=(DonorVerticalLease){0};assert(donorVerticalAcquire(&lease,&m,readState,m.actor,m.generation,true));
  m.v[0]=117;m.v[2]=-90;assert(donorVerticalPin(&lease,&m,readState,writeState));
  m.failAt=m.writes+fail;
  assert(!donorVerticalRelease(&lease,&m,readState,writeState)&&!lease.released);
  assert(m.v[0]==120&&m.v[1]==120&&m.v[2]==-90);
  assert(!donorVerticalPin(&lease,&m,readState,writeState));
  assert(donorVerticalRelease(&lease,&m,readState,writeState)&&lease.released&&m.v[2]==0);
 }
 m=memory();lease=(DonorVerticalLease){0};m.v[2]=-1;
 assert(!donorVerticalAcquire(&lease,&m,readState,m.actor,m.generation,true));
 puts("PASS donor vertical ownership: 600 frames no accumulated offset, velocity preserved until release, partial-write rollback, foreign lifetime/state refusal; not game-integrated");
 return 0;
}
