// SPDX-License-Identifier: GPL-3.0-or-later
#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <stdint.h>
#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <wchar.h>
#include "reaver-gl-render.h"
#include "shader-source-reader.h"
static unsigned failUploadAt=0,uploadCalls=0;static GLuint stagedTexture=0;
static bool testTextureUpload(ReaverGL *r,unsigned slot,unsigned w,unsigned h,const unsigned char *pixels,bool linear,bool repeat){
 uploadCalls++;if(failUploadAt&&uploadCalls==failUploadAt)return false;
 bool ok=reaverGLTexture(r,slot,w,h,pixels,linear,repeat);if(ok)stagedTexture=r->textures[slot];return ok;
}
#define REAVER_TEXTURE_GENERATION_UPLOAD testTextureUpload
#include "reaver-texture-generation.h"
#include "reaver-presentation-draw.h"
#include "reaver-texture-upload.h"
#define REQUIRE(x) do{if(!(x)){fprintf(stderr,"FAIL line %d: %s\n",__LINE__,#x);return 1;}}while(0)
static bool same(const ReaverGLState *expected){ReaverGLState actual={0};reaverGLSave(&actual);return !memcmp(expected,&actual,sizeof(actual));}
static void pixel(unsigned char out[4]){glReadPixels(160,160,1,1,GL_RGBA,GL_UNSIGNED_BYTE,out);}
int main(void){
 WNDCLASSW wc={0};wc.lpfnWndProc=DefWindowProcW;wc.hInstance=GetModuleHandleW(NULL);wc.lpszClassName=L"ReaverIsolatedGLTest";REQUIRE(RegisterClassW(&wc));
 HWND window=CreateWindowW(wc.lpszClassName,L"Hidden weapon renderer test",WS_POPUP,0,0,320,320,NULL,NULL,wc.hInstance,NULL);REQUIRE(window);
 HDC dc=GetDC(window);PIXELFORMATDESCRIPTOR pf={0};pf.nSize=sizeof(pf);pf.nVersion=1;pf.dwFlags=PFD_DRAW_TO_WINDOW|PFD_SUPPORT_OPENGL|PFD_DOUBLEBUFFER;pf.iPixelType=PFD_TYPE_RGBA;pf.cColorBits=32;pf.cDepthBits=24;pf.cAlphaBits=8;
 int format=ChoosePixelFormat(dc,&pf);REQUIRE(format&&SetPixelFormat(dc,format,&pf));HGLRC context=wglCreateContext(dc);REQUIRE(context&&wglMakeCurrent(dc,context));REQUIRE(reaverGLLoad());
 glViewport(0,0,320,320);glClearColor(0,0,0,0);glClearDepth(1);glClear(GL_COLOR_BUFFER_BIT|GL_DEPTH_BUFFER_BIT);
 glEnable(GL_CULL_FACE);glEnable(GL_STENCIL_TEST);glEnable(GL_SCISSOR_TEST);glScissor(0,0,1,1);glEnable(GL_RASTERIZER_DISCARD);glEnable(GL_COLOR_LOGIC_OP);glEnable(GL_CLIP_DISTANCE0);
 glEnable(GL_SAMPLE_COVERAGE);glEnable(GL_SAMPLE_ALPHA_TO_COVERAGE);glEnable(GL_SAMPLE_ALPHA_TO_ONE);glEnable(GL_SAMPLE_MASK);glPolygonMode(GL_FRONT_AND_BACK,GL_LINE);
 ghActiveTexture(GL_TEXTURE3);glPixelStorei(GL_UNPACK_ALIGNMENT,8);glPixelStorei(GL_UNPACK_ROW_LENGTH,17);glPixelStorei(GL_UNPACK_SKIP_ROWS,2);glPixelStorei(GL_UNPACK_SKIP_PIXELS,3);
 rgBlendFuncSeparatei(0,GL_DST_COLOR,GL_ZERO,GL_ZERO,GL_ONE);rgBlendEquationSeparatei(0,GL_FUNC_REVERSE_SUBTRACT,GL_FUNC_SUBTRACT);glDepthFunc(GL_GREATER);glDepthMask(GL_TRUE);
 ReaverGLState before={0};reaverGLSave(&before);ReaverGL renderer={0};REQUIRE(reaverGLInit(&renderer));REQUIRE(same(&before));REQUIRE(!reaverGLInit(&renderer));
 // Cold host path: no overlay pglGetShaderiv initialization. This is the
 // actual reader used by original-Reaver light hiding, not a substitute.
 ShaderRecord sourceRecord={0};REQUIRE(!shaderRead(renderer.program,1,&sourceRecord));
 shaderInit();REQUIRE(shaderReady&&shaderQuery);GLuint attached[2]={0};GLsizei attachedCount=0;
 shaderAttached(renderer.program,2,&attachedCount,attached);REQUIRE(attachedCount==2);
 for(unsigned i=0;i<2;i++){REQUIRE(shaderRead(renderer.program,attached[i],&sourceRecord));REQUIRE(sourceRecord.length>0);HeapFree(GetProcessHeap(),0,sourceRecord.source);}
 PFNGLGETSHADERIVPROC savedQuery=shaderQuery;shaderQuery=NULL;REQUIRE(!shaderRead(renderer.program,attached[0],&sourceRecord));shaderQuery=savedQuery;REQUIRE(same(&before));
 const unsigned char white[]={255,255,255,255};REQUIRE(reaverGLTexture(&renderer,0,1,1,white,false,false));REQUIRE(same(&before));
 GLuint first=renderer.textures[0];REQUIRE(reaverGLTexture(&renderer,0,1,1,white,true,true));REQUIRE(renderer.textures[0]!=first);REQUIRE(!glIsTexture(first));REQUIRE(same(&before));
 // An accidentally externally bound owned image must survive replacement.
 glBindTexture(GL_TEXTURE_2D,renderer.textures[0]);ReaverGLState bound={0};reaverGLSave(&bound);first=renderer.textures[0];
 REQUIRE(!reaverGLTexture(&renderer,0,1,1,white,false,false));REQUIRE(renderer.textures[0]==first&&glIsTexture(first));REQUIRE(same(&bound));glBindTexture(GL_TEXTURE_2D,0);REQUIRE(same(&before));
 REQUIRE(!reaverGLTexture(&renderer,128,1,1,white,false,false));REQUIRE(!reaverGLTexture(&renderer,1,2049,1,white,false,false));REQUIRE(same(&before));
 ReaverGLVertex v[3]={{{-.8f,-.8f,0},{0,0},{1,0,0,.5f}},{{.8f,-.8f,0},{1,0},{1,0,0,.5f}},{{0,.8f,0},{.5f,1},{1,0,0,.5f}}};
 const uint16_t indices[]={0,1,2};float mvp[16]={1,0,0,0,0,1,0,0,0,0,1,0,0,0,0,1};unsigned char color[4];
 REQUIRE(reaverGLDraw(&renderer,v,3,indices,3,0,1,mvp,0,-1));REQUIRE(same(&before));pixel(color);REQUIRE(color[0]>=127&&color[0]<=129&&color[1]==0&&color[2]==0);
 for(unsigned i=0;i<3;i++){v[i].rgba[0]=0;v[i].rgba[2]=1;}
 REQUIRE(reaverGLDraw(&renderer,v,3,indices,3,0,2,mvp,0,-1));REQUIRE(same(&before));pixel(color);REQUIRE(color[0]>=127&&color[0]<=129&&color[2]>=127&&color[2]<=129);
 unsigned char prior[4];memcpy(prior,color,4);
 REQUIRE(reaverGLDraw(&renderer,v,3,indices,3,0,2,mvp,0,.75f));pixel(color);REQUIRE(!memcmp(prior,color,4));REQUIRE(same(&before));
 mvp[12]=2;REQUIRE(reaverGLDraw(&renderer,v,3,indices,3,0,2,mvp,0,-1));pixel(color);REQUIRE(!memcmp(prior,color,4));mvp[12]=0;
 const uint16_t bad[]={0,1,3};REQUIRE(!reaverGLDraw(&renderer,v,3,bad,3,0,1,mvp,0,-1));REQUIRE(!reaverGLDraw(&renderer,v,3,indices,3,0,3,mvp,0,-1));REQUIRE(same(&before));
 ReaverTextureGeneration bank={0};const unsigned char red[]={255,0,0,255},green[]={0,255,0,255};
 ReaverTextureView views[2]={{0,100,1,1,4,red,false,false},{1,101,1,1,4,green,false,false}};
 REQUIRE(reaverTexturesCommit(&bank,1,views,2));REQUIRE(same(&before));REQUIRE(reaverTexturesMatch(&bank,1,0,100));REQUIRE(!reaverTexturesMatch(&bank,2,0,100));REQUIRE(!reaverTexturesMatch(&bank,1,0,101));
 GLuint old=bank.gl.textures[0];REQUIRE(!reaverTexturesCommit(&bank,1,views,2));REQUIRE(bank.gl.textures[0]==old);
 views[1].slot=0;REQUIRE(!reaverTexturesCommit(&bank,2,views,2));views[1].slot=1;
 views[1].bytes=3;REQUIRE(!reaverTexturesCommit(&bank,2,views,2));views[1].bytes=4;
 REQUIRE(bank.generation==1&&glIsTexture(old)&&same(&before));
 uploadCalls=0;failUploadAt=2;REQUIRE(!reaverTexturesCommit(&bank,2,views,2));failUploadAt=0;
 REQUIRE(bank.generation==1&&bank.gl.textures[0]==old&&glIsTexture(old)&&!glIsTexture(stagedTexture)&&same(&before));
 for(unsigned i=0;i<3;i++)for(unsigned k=0;k<4;k++)v[i].rgba[k]=1;
 REQUIRE(reaverGLDraw(&bank.gl,v,3,indices,3,0,1,mvp,0,-1));pixel(color);REQUIRE(color[0]==255&&color[1]==0&&color[2]==0);
 glBindTexture(GL_TEXTURE_2D,old);reaverGLSave(&bound);REQUIRE(!reaverTexturesCommit(&bank,2,views,2));REQUIRE(!reaverTexturesDestroy(&bank));REQUIRE(same(&bound)&&glIsTexture(old));glBindTexture(GL_TEXTURE_2D,0);
 views[0].pixels=green;views[0].sourceId=102;REQUIRE(reaverTexturesCommit(&bank,2,views,1));REQUIRE(!glIsTexture(old));REQUIRE(!reaverTexturesMatch(&bank,1,0,100));REQUIRE(reaverTexturesMatch(&bank,2,0,102));REQUIRE(!reaverTexturesMatch(&bank,2,1,101));
 REQUIRE(reaverGLDraw(&bank.gl,v,3,indices,3,0,1,mvp,0,-1));pixel(color);REQUIRE(color[0]==0&&color[1]==255&&color[2]==0);REQUIRE(same(&before));
 ReaverPresentationLease *lease=calloc(1,sizeof(*lease));REQUIRE(lease);lease->session=(ReaverPacketSession){10,20,30,100,200,300,400,500,600,2};
 unsigned char packet[274]={0};uint32_t header[]={0x31565752,1,sizeof(packet),1,10,20,30,0};memcpy(packet,header,32);
 uint64_t identity[]={100,200,300,8,1000,400,500,600,2};memcpy(packet+32,identity,sizeof(identity));uint32_t counts[]={3,3,1,49};memcpy(packet+104,counts,16);
 memcpy(packet+128,v,sizeof(v));memcpy(packet+236,indices,sizeof(indices));uint32_t batch[]={0,3,0,1};memcpy(packet+242,batch,16);float threshold=-1;memcpy(packet+262,&threshold,4);
 REQUIRE(reaverPresentationAccept(lease,packet,sizeof(packet),1000));REQUIRE(reaverPresentationDraw(lease,&bank,1000,mvp));REQUIRE(same(&before));
 pixel(color);REQUIRE(color[0]==0&&color[1]==255&&color[2]==0);
 bank.generation=3;REQUIRE(!reaverPresentationDraw(lease,&bank,1000,mvp));bank.generation=2;
 unsigned savedId=bank.sourceIds[0];bank.sourceIds[0]=0;REQUIRE(!reaverPresentationDraw(lease,&bank,1000,mvp));bank.sourceIds[0]=savedId;
 REQUIRE(!reaverPresentationDraw(lease,&bank,1101,mvp));REQUIRE(same(&before));
 unsigned char texturePacket[164]={0};uint32_t textureHeader[]={0x31545752,1,164,0,10,20,30,0};memcpy(texturePacket,textureHeader,32);
 identity[8]=3;memcpy(texturePacket+32,identity,sizeof(identity));uint32_t textureCounts[]={1,4};memcpy(texturePacket+104,textureCounts,8);
 uint32_t descriptor[]={0,103,1,1,160,4,0,0};memcpy(texturePacket+128,descriptor,32);memcpy(texturePacket+160,red,4);
 lease->session.textureGeneration=3;
 REQUIRE(reaverTexturePacketUpload(&bank,texturePacket,sizeof(texturePacket),&lease->session));REQUIRE(same(&before));
 uint64_t generation=3,sequence=9;memcpy(packet+96,&generation,8);memcpy(packet+56,&sequence,8);
 reaverPresentationClear(lease);
 REQUIRE(reaverPresentationAccept(lease,packet,sizeof(packet),1000));REQUIRE(reaverPresentationDraw(lease,&bank,1000,mvp));
 pixel(color);REQUIRE(color[0]==255&&color[1]==0&&color[2]==0);REQUIRE(same(&before));
 texturePacket[152]=2;REQUIRE(!reaverTexturePacketUpload(&bank,texturePacket,sizeof(texturePacket),&lease->session));REQUIRE(bank.generation==3);free(lease);
 REQUIRE(reaverTexturesDestroy(&bank));REQUIRE(same(&before));
 REQUIRE(glGetError()==GL_NO_ERROR);REQUIRE(wglMakeCurrent(NULL,NULL));REQUIRE(!reaverGLDraw(&renderer,v,3,indices,3,0,1,mvp,0,-1));REQUIRE(!reaverGLDestroy(&renderer));
 REQUIRE(wglMakeCurrent(dc,context));REQUIRE(reaverGLDestroy(&renderer));REQUIRE(same(&before));REQUIRE(glGetError()==GL_NO_ERROR);
 wglMakeCurrent(NULL,NULL);wglDeleteContext(context);ReleaseDC(window,dc);DestroyWindow(window);
 puts("PASS real hidden GL: shader pixels/blend/discard; atomic texture generations, slot reuse, partial upload rollback, escaped ownership refusal; validated RAM frame drawing and stale/mismatched generation refusal; exact touched-state restoration. Synthetic geometry only, no host gameplay proof.");return 0;
}
