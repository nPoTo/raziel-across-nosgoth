// SPDX-License-Identifier: GPL-3.0-or-later
// Composed fixture: actual native draw-context function versus helper reader.
#define SR1_NATIVE_JUMP_POSE 1
#define SR1_AIR_COMBAT_POSE 1
#define SR1_NATIVE_EXIT_GUARD 1
#define SR1_NATIVE_CROUCH_HOLD 1
#include <windows.h>
#include <assert.h>
#include <stdio.h>
#include "sr1-retarget-context-reader.h"
#include "sr1-native-exit-reader.h"

typedef struct {uintptr_t at;SIZE_T bytes;uint64_t value;unsigned reads;} Field;
static Field fields[80];static unsigned count;static uintptr_t mutation,unreadable;static uint64_t mutationBits=1;static unsigned mutateFrom,unreadableAt;static bool foreground=true;
static const uintptr_t base=0x100000,actor=0x50000,object=0x60000,list=0x70000,model=0x80000;
static Sr1NativeExitLatch sr1ExitLatch;static uintptr_t sr1ExitActor,sr1ExitObject,sr1ExitModel;
static volatile LONG sr1ExitHeld,sr1ExitReleased,sr1ExitReadRefused;
static bool worldRead(uintptr_t at,void *out,SIZE_T bytes){
 for(unsigned i=0;i<count;i++)if(fields[i].at==at&&fields[i].bytes==bytes){
  Field *f=fields+i;unsigned n=++f->reads;if(at==unreadable&&n==unreadableAt)return false;
  uint64_t v=f->value;if(at==mutation&&n>=mutateFrom)v^=mutationBits;memcpy(out,&v,bytes);return true;
 }
 return false;
}
static bool sr1SkeletonRead(void *unused,uintptr_t at,void *out,SIZE_T bytes){(void)unused;return worldRead(at,out,bytes);}
static HWND fixtureWindow(void){return (HWND)1;}
static DWORD fixtureWindowPid(HWND w,LPDWORD pid){(void)w;*pid=foreground?12:13;return 1;}
static DWORD fixturePid(void){return 12;}
#define GetForegroundWindow fixtureWindow
#define GetWindowThreadProcessId fixtureWindowPid
#define GetCurrentProcessId fixturePid
#include "sr1-skeleton-context.h"
#undef GetForegroundWindow
#undef GetWindowThreadProcessId
#undef GetCurrentProcessId

static void add(uintptr_t at,SIZE_T bytes,uint64_t value){assert(count<80);fields[count++]=(Field){at,bytes,value,0};}
static Field *field(uintptr_t at){for(unsigned i=0;i<count;i++)if(fields[i].at==at)return fields+i;assert(0);return NULL;}
static uintptr_t clipAt(unsigned section){return actor+(section<3?0x358:0x480)+(section%3)*0x50+0x1c;}
static void setup(uint32_t callback,uint16_t clip){
 count=0;mutation=unreadable=0;mutationBits=1;mutateFrom=unreadableAt=0;foreground=true;
 sr1ExitLatch=(Sr1NativeExitLatch){0};sr1ExitActor=actor;sr1ExitObject=object;sr1ExitModel=model;
 add(base+0x2a88588,8,actor);add(base+0x2a89536,2,0);add(base+0x2a8950c,4,64);add(actor+0x2d4,4,0);
 for(unsigned i=0;i<3;i++)add(base+0x2a88598+i*0x228,8,base+callback);
 add(base+0xd6b388,8,0x90000);add(base+0x22acd0,4,0x800);add(0x90000,4,0);
 add(actor+0x30,8,object);add(object+0x10,8,list);add(list,8,model);
 for(unsigned i=0;i<6;i++){add(clipAt(i),2,clip);add(clipAt(i)-0x1c+0x48,8,0);}
}
static bool helperAllowed(unsigned kind){Sr1RetargetContext c;assert(sr1RetargetReadContext(NULL,sr1SkeletonRead,base,actor,foreground,&c));return kind==3?sr1RetargetJumpContextAllowed(&c):sr1RetargetContextAllowed(&c);}
int main(void){
 const uint32_t callbacks[]={0xedb40,0xedb40,0xee600,0xee600};const uint16_t clips[]={0x1a,0x22,0x1d,0x25};
 for(unsigned n=0;n<4;n++){
  setup(callbacks[n],clips[n]);assert(helperAllowed(3));setup(callbacks[n],clips[n]);assert(sr1SkeletonContextKind(base,actor,3)&&!sr1ExitLatch.nativeOwned);
  // The previous native manual context had no ordinary clip classification.
  Sr1RetargetContext old={.identity=true,.foreground=true,.verticalVelocityKnown=true,.flags=64};
  for(unsigned i=0;i<3;i++)old.callbacks[i]=callbacks[n];assert(!sr1RetargetJumpContextAllowed(&old));
  for(unsigned section=0;section<6;section++){
   setup(callbacks[n],clips[n]);field(clipAt(section))->value=0xffff;assert(!helperAllowed(3));
   setup(callbacks[n],clips[n]);field(clipAt(section))->value=0xffff;assert(!sr1SkeletonContextKind(base,actor,3)&&!sr1ExitLatch.nativeOwned);
   setup(callbacks[n],clips[n]);mutation=clipAt(section);mutateFrom=2;assert(!sr1SkeletonContextKind(base,actor,3));
   setup(callbacks[n],clips[n]);mutation=clipAt(section);mutateFrom=3;assert(!sr1SkeletonContextKind(base,actor,3));
   setup(callbacks[n],clips[n]);unreadable=clipAt(section);unreadableAt=1;assert(!sr1SkeletonContextKind(base,actor,3));
  }
  // A native action latch still waits for all interpolation to complete.
  setup(callbacks[n],clips[n]);sr1ExitLatch.nativeOwned=true;
  field(clipAt(5)-0x1c+0x48)->value=0xa0000;add(0xa0010,8,0xa1000);
  assert(!sr1SkeletonContextKind(base,actor,3)&&sr1ExitLatch.nativeOwned);
  field(0xa0010)->value=0;assert(sr1SkeletonContextKind(base,actor,3)&&!sr1ExitLatch.nativeOwned);
 }
 setup(0xee600,0x1d);field(base+0x2a88598+0x228)->value=base+0xf3280;assert(sr1SkeletonContextKind(base,actor,3));
 setup(0xf2180,0);assert(sr1SkeletonContextKind(base,actor,2));
 setup(0xf2ae0,0);field(actor+0x2d4)->value=138;assert(sr1SkeletonContextKind(base,actor,3));
 const uint32_t native[]={0xefb50,0xf48e0,0xecf70,0xf4490,0xeeb40};
 for(unsigned i=0;i<sizeof(native)/sizeof(*native);i++){setup(native[i],0);assert(!sr1SkeletonContextKind(base,actor,3)&&sr1ExitLatch.nativeOwned);}
 setup(0xdead,0);assert(!sr1SkeletonContextKind(base,actor,3)&&!sr1ExitLatch.nativeOwned);
 // An unrecognized ordinary landing upper-body clip refuses presentation,
 // without claiming a mechanical native interaction or accepting that clip.
 setup(0xee600,0x1d);field(clipAt(1))->value=227;field(clipAt(4))->value=227;
 assert(!sr1SkeletonContextKind(base,actor,3)&&!sr1ExitLatch.nativeOwned);
 field(clipAt(1))->value=29;field(clipAt(4))->value=29;
 field(clipAt(5)-0x1c+0x48)->value=0xa0000;add(0xa0010,8,0xa1000);
 assert(sr1SkeletonContextKind(base,actor,3)&&!sr1ExitLatch.nativeOwned); // No invented completion latch.
 // Exact recorded six-section Landing pattern; no wildcard upper-body rule.
 setup(0xee600,29);field(clipAt(1))->value=228;field(clipAt(4))->value=228;
 assert(helperAllowed(3)&&sr1SkeletonContextKind(base,actor,3));
 for(unsigned i=0;i<6;i++){
  setup(0xee600,29);field(clipAt(1))->value=228;field(clipAt(4))->value=228;
  field(clipAt(i))->value++;assert(!helperAllowed(3)&&!sr1SkeletonContextKind(base,actor,3));
 }
 for(unsigned i=0;i<3;i++){
  setup(0xee600,29);field(clipAt(1))->value=228;field(clipAt(4))->value=228;
  field(base+0x2a88598+i*0x228)->value=base+0xf3280;assert(!helperAllowed(3)&&!sr1SkeletonContextKind(base,actor,3));
 }
 setup(0xee600,29);field(clipAt(1))->value=228;field(clipAt(4))->value=228;field(0x90000)->value=0x800;
 assert(!helperAllowed(3)&&!sr1SkeletonContextKind(base,actor,3));
 setup(0xee600,29);field(clipAt(1))->value=228;field(clipAt(4))->value=228;sr1ExitLatch.nativeOwned=true;
 field(clipAt(5)-0x1c+0x48)->value=0xa0000;add(0xa0010,8,0xa1000);
 assert(!sr1SkeletonContextKind(base,actor,3)&&sr1ExitLatch.nativeOwned);
 field(0xa0010)->value=0;assert(sr1SkeletonContextKind(base,actor,3)&&!sr1ExitLatch.nativeOwned);
 // Genuine bars/crouch ownership still waits through the full native exit.
 for(unsigned action=0;action<2;action++){
  setup(action?0xf2180:0xecf70,0);if(action)field(0x90000)->value=0x800;
  assert(!sr1SkeletonContextKind(base,actor,2)&&sr1ExitLatch.nativeOwned);
  for(unsigned i=0;i<3;i++)field(base+0x2a88598+i*0x228)->value=base+0xf2180;
  field(0x90000)->value=0;field(clipAt(5)-0x1c+0x48)->value=0xa0000;add(0xa0010,8,0xa1000);
  assert(!sr1SkeletonContextKind(base,actor,2)&&sr1ExitLatch.nativeOwned);
  field(0xa0010)->value=0;assert(sr1SkeletonContextKind(base,actor,2)&&!sr1ExitLatch.nativeOwned);
 }
 setup(0xee600,0x1d);foreground=false;assert(!sr1SkeletonContextKind(base,actor,3));
 setup(0xee600,0x1d);field(base+0x2a88588)->value=actor+1;assert(!sr1SkeletonContextKind(base,actor,3));
 setup(0xee600,0x1d);field(0x90000)->value=0x800;assert(!sr1SkeletonContextKind(base,actor,3));
 setup(0xee600,0x1d);mutation=base+0x2a8950c;mutateFrom=3;assert(!sr1SkeletonContextKind(base,actor,3));
 setup(0xee600,0x1d);mutation=actor+0x30;mutateFrom=2;assert(!sr1SkeletonContextKind(base,actor,3));
 setup(0xee600,0x1d);mutation=0x90000;mutationBits=0x800;mutateFrom=3;assert(!sr1SkeletonContextKind(base,actor,3));
 puts("PASS actual native skeleton context and helper agree on legacy+HD ordinary air; old context omission reproduced; native exit, foreign/crouch/glide/torn/resource checks retained.");
 return 0;
}
