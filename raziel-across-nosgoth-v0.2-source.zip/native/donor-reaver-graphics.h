// SPDX-License-Identifier: GPL-3.0-or-later
#pragma once
#include "donor-reaver-reader.h"
// Small fixed RAM snapshot. Never persist matrix, color, or geometry payloads.
typedef struct {uint16_t count,part;uint32_t material,textureId,indexOffset,textureFlags;float scroll;} ReaverGraphicsBatch;
typedef struct {
 ReaverSnapshot source;
 uintptr_t model,matrices,colors,alternate,batches,textureTable,actorMatrices;
 uint32_t bones,extra,vertices,batchCount,textureCount,indexCount,failureStage;
 uint32_t objectFlags,flags2,partMask2,partMask3;unsigned char active,colorMode,partMode;float realmBlend;
 float pose[16][16],hand[16],palm[9];uint32_t color[2048],alternateColor[2048];
 uint16_t indices[8192];
 uint16_t textures[128][2];ReaverGraphicsBatch batch[16];
} ReaverGraphics;
static inline bool reaverGraphicsOnce(void *c,ReaverRead r,uintptr_t base,uint32_t size,const ReaverSnapshot *s,ReaverGraphics *o){
 const Sheet_reaverGraphicsReadPolicy *p=&sheet_reaverGraphicsReadPolicy_legacy_candidate;
 memset(o,0,sizeof(*o));o->failureStage=1;if(p->gameWrites||p->maxVertices!=2048||p->maxBones!=16||p->maxBatches!=16||p->maxTextures!=128||p->maxIndices!=8192||p->sourceHandBone!=50)return false;
 if(s->attachedParent!=s->actor||s->attachedBone!=p->sourceHandBone||s->configuredHand!=p->sourceHandBone)return false;
 if(p->realmBlendRva>size||size-p->realmBlendRva<4||!reaverField(c,r,base,p->realmBlendRva,&o->realmBlend,4)||!isfinite(o->realmBlend)||
 !reaverField(c,r,s->weapon,p->partModeOffset,&o->partMode,1)||
 !reaverField(c,r,s->object,p->objectFlagsOffset,&o->objectFlags,4)||
 !reaverField(c,r,s->weapon,p->instanceFlags2Offset,&o->flags2,4)||
 !reaverField(c,r,s->weapon,p->colorModeOffset,&o->colorMode,1)||
 !reaverField(c,r,s->weapon,p->secondaryPartMaskOffset,&o->partMask2,4)||
 !reaverField(c,r,s->weapon,p->tertiaryPartMaskOffset,&o->partMask3,4))return false;
 uint16_t count=0;uintptr_t table=0,selected=0;
 if(!reaverField(c,r,s->object,p->objectModelCountOffset,&count,2)||count!=2||
 !reaverField(c,r,s->object,p->objectModelsOffset,&table,8)||!table||
 !reaverField(c,r,s->weapon,p->activeModelOffset,&o->active,1)||o->active>=count||
 !reaverField(c,r,table,o->active*8,&selected,8)||!selected||
 !reaverField(c,r,s->weapon,p->animationModelOffset,&o->model,8)||o->model!=selected)return false;
 o->failureStage=2;uint32_t magic=0;
 if(!reaverField(c,r,o->model,0,&magic,4)||magic!=0x04c2042f||
 !reaverField(c,r,o->model,4,&o->bones,4)||!reaverField(c,r,o->model,8,&o->extra,4)||
 o->extra||o->bones!=(o->active?1u:10u)||
 !reaverField(c,r,o->model,p->vertexCountOffset,&o->vertices,4)||o->vertices!=(o->active?24u:1046u)||
 !reaverField(c,r,s->weapon,p->matrixOffset,&o->matrices,8)||!o->matrices||
 !reaverField(c,r,o->matrices,0,o->pose,o->bones*64)||
 !reaverField(c,r,s->actor,p->matrixOffset,&o->actorMatrices,8)||!o->actorMatrices||
 !reaverField(c,r,o->actorMatrices,p->sourceHandBone*64,o->hand,64))return false;
 const Sheet_reaverPalmBasis *anatomy=&sheet_reaverPalmBasis_anatomical;
 if(anatomy->sourceWrist!=40||anatomy->sourceFinger!=41||anatomy->sourceThumb!=47||anatomy->sourceSocket!=50||anatomy->nativeIntegrationEnabled)return false;
 const unsigned joints[]={40,41,47};
 for(unsigned j=0;j<3;j++)if(!reaverField(c,r,o->actorMatrices,joints[j]*64+48,o->palm+j*3,12))return false;
 for(unsigned k=0;k<9;k++)if(!isfinite(o->palm[k]))return false;
 for(unsigned k=0;k<16;k++)if(!isfinite(o->hand[k]))return false;
 if(fabsf(o->hand[3])>0.001f||fabsf(o->hand[7])>0.001f||fabsf(o->hand[11])>0.001f||fabsf(o->hand[15]-1)>0.001f)return false;
 o->failureStage=3;for(unsigned b=0;b<o->bones;b++){
  for(unsigned k=0;k<16;k++)if(!isfinite(o->pose[b][k]))return false;
  if(fabsf(o->pose[b][3])>0.001f||fabsf(o->pose[b][7])>0.001f||fabsf(o->pose[b][11])>0.001f||fabsf(o->pose[b][15]-1)>0.001f)return false;
 }
 o->failureStage=4;if(!reaverField(c,r,o->model,p->vertexColorsOffset,&o->colors,8)||!o->colors||!reaverField(c,r,o->colors,0,o->color,o->vertices*4)||
 !reaverField(c,r,o->model,p->alternateColorsOffset,&o->alternate,8)||
 (o->alternate&&!reaverField(c,r,o->alternate,0,o->alternateColor,o->vertices*4))||
 !reaverField(c,r,s->object,p->textureTableOffset,&o->textureTable,8)||!o->textureTable)return false;
 o->failureStage=5;bool end=false;
 for(unsigned i=0;i<=p->maxTextures;i++){
  uint16_t pair[2];if(!reaverField(c,r,o->textureTable,i*4,pair,4))return false;
  if(!pair[0]){end=true;break;}if(i==p->maxTextures)return false;
  for(unsigned j=0;j<i;j++)if(o->textures[j][0]==pair[0]||o->textures[j][1]==pair[1])return false;
  memcpy(o->textures[i],pair,4);o->textureCount++;
 }
 if(!end)return false;
 o->failureStage=6;uintptr_t batch=0,seen[16]={0};
 if(!reaverField(c,r,o->model,p->batchOffset,&o->batches,8))return false;batch=o->batches;
 for(unsigned i=0;i<=p->maxBatches;i++){
  int16_t n=0;if(!batch||!reaverField(c,r,batch,0,&n,2))return false;if(!n){o->failureStage=0;return true;}
  if(n<0||n%3||i==p->maxBatches)return false;
  for(unsigned j=0;j<i;j++)if(seen[j]==batch)return false;seen[i]=batch;
  ReaverGraphicsBatch *item=&o->batch[i];item->count=(uint16_t)n;item->indexOffset=o->indexCount;
  if((unsigned)n>p->maxIndices-o->indexCount||!reaverField(c,r,batch,24,o->indices+o->indexCount,(SIZE_T)n*2))return false;
  for(unsigned j=0;j<(unsigned)n;j++)if(o->indices[o->indexCount+j]>=o->vertices)return false;
  o->indexCount+=(unsigned)n;
  if(!reaverField(c,r,batch,2,&item->part,2)||item->part>31||!reaverField(c,r,batch,4,&item->material,4))return false;
  if(!reaverField(c,r,batch,p->batchScrollOffset,&item->scroll,4)||!isfinite(item->scroll))return false;
  const uint32_t texture=item->material&0x3ff;bool found=texture==0;
  if(texture>=p->textureRuntimeLimit)return false;
  uintptr_t flagsOffset=(uintptr_t)p->textureFlagsRva+(uintptr_t)texture*p->textureEntryStride;
  unsigned char textureFlags=0;if(flagsOffset>=size||!reaverField(c,r,base,flagsOffset,&textureFlags,1))return false;item->textureFlags=textureFlags;
  for(unsigned j=0;j<o->textureCount;j++)if(o->textures[j][1]==texture){item->textureId=o->textures[j][0];found=true;}
  if(!found)return false;o->batchCount++;
  if(!reaverField(c,r,batch,16,&batch,8))return false;
 }
 return false;
}
static inline bool reaverGraphicsRead(void *c,ReaverRead r,uintptr_t base,uint32_t size,uintptr_t knownModel,ReaverGraphics *out){
 memset(out,0,sizeof(*out));out->failureStage=7;
 ReaverObservation before=reaverObserve(c,r,base,size,knownModel);if(!before.valid||!before.present)return false;
 ReaverGraphics a,b;if(!reaverGraphicsOnce(c,r,base,size,&before.snapshot,&a)){out->failureStage=a.failureStage;return false;}
 if(!reaverGraphicsOnce(c,r,base,size,&before.snapshot,&b)){out->failureStage=b.failureStage;return false;}
 out->failureStage=8;if(memcmp(&a,&b,sizeof(a)))return false;
 out->failureStage=9;
 ReaverObservation after=reaverObserve(c,r,base,size,knownModel);
 if(!after.valid||!after.present||memcmp(&before.snapshot,&after.snapshot,sizeof(before.snapshot)))return false;
 *out=a;out->source=before.snapshot;return true;
}
