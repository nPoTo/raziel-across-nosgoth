// SPDX-License-Identifier: GPL-3.0-or-later
// Publish from the already-owned donor collision boundary, not a worker sample.
#include "air-clock-shared.h"
static HANDLE donorAirClockMap;static AirClockShared *donorAirClockView;static uint64_t donorAirClockSequence;
static bool donorAirClockOpen(HostContactLease expected){
 wchar_t name[96];airClockName(name,expected.pid);SetLastError(0);
 donorAirClockMap=CreateFileMappingW(INVALID_HANDLE_VALUE,NULL,PAGE_READWRITE,0,sizeof(AirClockShared),name);
 if(!donorAirClockMap)return false;
 if(GetLastError()==ERROR_ALREADY_EXISTS){CloseHandle(donorAirClockMap);donorAirClockMap=NULL;return false;}
 donorAirClockView=MapViewOfFile(donorAirClockMap,FILE_MAP_READ|FILE_MAP_WRITE,0,0,sizeof(AirClockShared));
 if(!donorAirClockView){CloseHandle(donorAirClockMap);donorAirClockMap=NULL;}
 return donorAirClockView!=NULL;
}
static void donorAirClockPublish(const HostContactLease *lease,uintptr_t actor,bool valid){
 if(!donorAirClockView)return;
 AirClockPacket p={.magic=0x314b4341,.version=1,.hostPid=lease->pid,.donorPid=GetCurrentProcessId(),
  .hostCreation=lease->creation,.epoch=lease->epoch,.tick=GetTickCount64(),.actor=lease->actor,.sequence=++donorAirClockSequence};
 uintptr_t context=0,state=0,owner=0,descriptor=0;uint32_t mode=0;int32_t scalar=0;
 bool ok=valid&&donorProcessIdentity(actor)&&worldRead(donorProcessBase+0xc67120,&context,8)&&context&&
  worldRead(donorProcessBase+0x113fff4,&mode,4)&&mode==10&&worldRead(context+0xc4,&scalar,4)&&scalar>0&&scalar<=4096&&
  worldRead(context+0x470,&descriptor,8)&&descriptor&&worldRead(actor+0x3f8,&state,8)&&state&&worldRead(state,&owner,8)&&owner==actor;
 for(unsigned i=0;ok&&i<3;i++){uintptr_t callbacks[2];ok=worldRead(state+i*0x250+16,callbacks,16)&&callbacks[0]==donorProcessBase+0x1319c0&&callbacks[1]==donorProcessBase+0x131a30;}
 uintptr_t contextAfter=0;int32_t scalarAfter=0;
 ok=ok&&worldRead(donorProcessBase+0xc67120,&contextAfter,8)&&contextAfter==context&&worldRead(context+0xc4,&scalarAfter,4)&&scalarAfter==scalar&&donorProcessIdentity(actor);
 p.active=ok;p.scalar=ok?scalar:4096;airClockStore(donorAirClockView,&p);
}
static void donorAirClockRevoke(void){if(donorAirClockView)InterlockedExchange(&donorAirClockView->revoked,1);}
