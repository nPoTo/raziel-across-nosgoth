#include <stdint.h>
#include <stdbool.h>
#include <stdio.h>
#include <string.h>
#include "sr1-jump-bridge.h"
#define CHECK(x) do{if(!(x)){printf("FAIL line %d\n",__LINE__);return 1;}}while(0)
int main(void){
 SrJumpBridge s={0};
 CHECK(srJumpButtons(&s,0x8000,1000,1,false)==0x8000);
 CHECK(srJumpButtons(&s,0x8000,1010,1,true)==0); // held on activation requires release
 CHECK(srJumpButtons(&s,0,1020,1,true)==0);
 CHECK(srJumpButtons(&s,0x8000|0x4000,1030,1,true)==0x4000);
 CHECK(srJumpLeftTrigger(&s,0,1030,true)==255);
 CHECK(srJumpButtons(&s,0x8000,1230,1,true)==0);
 CHECK(srJumpButtons(&s,0x8000,1330,1,true)==0x1000);
 CHECK(srJumpLeftTrigger(&s,0,1330,true)==255);
 CHECK(srJumpButtons(&s,0x8000|0x4000,1430,1,true)==0x5000);
 CHECK(srJumpLeftTrigger(&s,37,1430,true)==37);
 CHECK(srJumpButtons(&s,0x8000,1650,1,true)==0x1000);
 CHECK(srJumpButtons(&s,0x8000,1850,1,true)==0x1000);
 CHECK(srJumpButtons(&s,0x8000,1930,1,true)==0);
 CHECK(srJumpButtons(&s,0,1940,1,true)==0);
 CHECK(srJumpButtons(&s,0x8000,1950,1,true)==0);
 CHECK(srJumpButtons(&s,0x8000|0x1000,2100,1,true)==0x1000);
 CHECK(srJumpLeftTrigger(&s,0,2100,true)==0);
 CHECK(srJumpButtons(&s,0x8000,2250,1,true)==0); // physical A avoids double jump
 CHECK(srJumpButtons(&s,0x8000,2260,2,true)==0); // new actor requires release
 CHECK(srJumpButtons(&s,0,2270,2,true)==0);
 CHECK(srJumpButtons(&s,0x8000,2280,2,true)==0);
 CHECK(srJumpButtons(&s,0x8000,2680,2,true)==0); // gap invalidates held state
 CHECK(srJumpLeftTrigger(&s,11,2680,true)==11);
 CHECK(srJumpButtons(&s,0x8000,2580,2,true)==0); // backward clock
 CHECK(srJumpButtons(&s,0x8000,2800,2,false)==0x8000); // loss of scope immediately restores raw
 CHECK(srJumpLeftTrigger(&s,93,2800,false)==93);
 puts("SR1 jump bridge: hold threshold/pulse/release, buttons preserved, A overlap, identity/gap/scope restoration PASS");return 0;
}
