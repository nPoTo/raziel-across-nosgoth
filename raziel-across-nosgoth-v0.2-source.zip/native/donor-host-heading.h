// SPDX-License-Identifier: GPL-3.0-or-later
// Candidate behind HOST_LED_HEADING. Reuses proved 7c570 game-thread boundary;
// no new detour, no root-matrix writes, no position/velocity/input writes.
#include "donor-heading-lease.h"
#include <wchar.h>
static HeadingLease donorHeadingLease;
static HostContactLease donorHeadingCursor;
static uintptr_t donorHeadingActor,donorHeadingState;
static DWORD donorHeadingThread;
static uint64_t donorHeadingSequence;
static bool donorHeadingFailed;
static volatile LONG donorHeadingPublishedWrites,donorHeadingPublishedFailed;
static volatile LONG donorHeadingPublishedRestored,donorHeadingPublishedForeign;
static bool donorHeadingIdentity(void){
 uintptr_t state=0;return GetCurrentThreadId()==donorHeadingThread&&donorProcessIdentity(donorHeadingActor)&&
  worldRead(donorProcessBase+sheet_hostHeadingPolicy_host_authority.stateGlobalRva,&state,8)&&state==donorHeadingState&&state;
}
static bool donorHeadingRead(void *ctx,float values[5]){
 (void)ctx;const Sheet_hostHeadingPolicy *p=&sheet_hostHeadingPolicy_host_authority;
 if(!donorHeadingIdentity())return false;
 return worldRead(donorHeadingActor+p->currentOffset,values,4)&&worldRead(donorHeadingActor+p->previousOffset,values+1,4)&&
  worldRead(donorHeadingState+p->directionOffset,values+2,4)&&worldRead(donorHeadingState+p->recoveryOffset,values+3,4)&&worldRead(donorHeadingState+p->attackOffset,values+4,4)&&donorHeadingIdentity();
}
static bool donorHeadingWrite(void *ctx,unsigned field,float value){
 (void)ctx;const Sheet_hostHeadingPolicy *p=&sheet_hostHeadingPolicy_host_authority;
 uintptr_t address[5]={donorHeadingActor+p->currentOffset,donorHeadingActor+p->previousOffset,donorHeadingState+p->directionOffset,donorHeadingState+p->recoveryOffset,donorHeadingState+p->attackOffset};SIZE_T written=0;
 return field<5&&isfinite(value)&&donorHeadingIdentity()&&WriteProcessMemory(GetCurrentProcess(),(void *)address[field],&value,4,&written)&&written==4;
}
static void donorHeadingBoundary(uintptr_t actor,bool anchorScope){
 DWORD thread=GetCurrentThreadId();if(!donorHeadingThread)donorHeadingThread=thread;
 if(thread!=donorHeadingThread){InterlockedExchange(&donorContactCancel,1);return;}
 bool active=anchorScope&&InterlockedCompareExchange(&donorContactReady,0,0)&&!InterlockedCompareExchange(&donorContactCancel,0,0)&&!donorHeadingFailed;
 if(active&&wcscmp(sheet_hostHeadingPolicy_host_authority.cacheFramePolicy,L"host_delta_after_initial_alignment")){
  donorHeadingFailed=true;InterlockedExchange(&donorContactCancel,1);active=false;
 }
 HostContactSnapshot snapshot={0};bool fresh=false;
 if(active){
  if(!donorHeadingCursor.pid){
   // Copy only immutable expected identity; the collision reader owns its own
   // sequence cursor. Both mappings remain pinned until process exit.
   donorHeadingCursor=(HostContactLease){.pid=donorContactReader.lease.pid,.creation=donorContactReader.lease.creation,.epoch=donorContactOwnerEpoch,.actor=donorContactReader.lease.actor};
   donorHeadingActor=actor;
   if(!worldRead(donorProcessBase+sheet_hostHeadingPolicy_host_authority.stateGlobalRva,&donorHeadingState,8)||!donorHeadingState)active=false;
  }
  uint64_t now=GetTickCount64();
  active=active&&actor==donorHeadingActor&&hostContactCopy(donorContactReader.view,&snapshot)&&
   hostContactAccept(&donorHeadingCursor,&snapshot,now,donorContactReader.process&&WaitForSingleObject(donorContactReader.process,0)==WAIT_TIMEOUT,&fresh);
  if(!active){donorHeadingFailed=true;InterlockedExchange(&donorContactCancel,1);}
 }
 if(active&&snapshot.phase!=4){
  if(snapshot.headingValid!=1||!isfinite(snapshot.headingTurns)||snapshot.headingTurns<0||snapshot.headingTurns>=1||
     !headingApply(&donorHeadingLease,NULL,donorHeadingRead,donorHeadingWrite,snapshot.headingTurns)){
   donorHeadingFailed=true;InterlockedExchange(&donorContactCancel,1);
  }else donorHeadingSequence=snapshot.sequence;
 }else if(!headingRelease(&donorHeadingLease,NULL,donorHeadingRead,donorHeadingWrite)){
  donorHeadingFailed=true;InterlockedExchange(&donorContactCancel,1);
 }
 InterlockedExchange(&donorHeadingPublishedWrites,donorHeadingLease.writes);
 InterlockedExchange(&donorHeadingPublishedFailed,donorHeadingFailed||donorHeadingLease.failed);
 InterlockedExchange(&donorHeadingPublishedRestored,donorHeadingLease.restored);
 InterlockedExchange(&donorHeadingPublishedForeign,donorHeadingLease.foreign);
}
