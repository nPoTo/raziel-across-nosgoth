// SPDX-License-Identifier: GPL-3.0-or-later
#pragma once
#include <stdint.h>
#include <stdbool.h>
typedef struct {uintptr_t actor;uint64_t tick,epoch;} LiftVerticalLaunch;
static inline bool liftVerticalConsume(LiftVerticalLaunch *s,uint64_t now,uintptr_t actor,uint64_t epoch,bool live,uintptr_t caller,int gravity,int x,int y,int z){
 if(!live||now<s->tick||now-s->tick>350||s->epoch!=epoch){*s=(LiftVerticalLaunch){0};return false;}
 if(!s->actor||s->actor!=actor||caller!=0xede81||gravity!=-16||x!=0||y!=83||z!=154)return false;
 *s=(LiftVerticalLaunch){0};return true;
}
