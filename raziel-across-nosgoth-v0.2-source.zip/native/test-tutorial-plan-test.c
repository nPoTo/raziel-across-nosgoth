// SPDX-License-Identifier: GPL-3.0-or-later
#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <stdint.h>
#include <stdbool.h>
#include <stdio.h>
#include <wchar.h>
#include "test-tutorial-plan.h"
int main(void){
 if(tutorialWallBudgetMs(660)<=660000||tutorialWallBudgetMs(180)<=180000||tutorialWallBudgetMs(0xffffffff)!=(uint64_t)0xffffffff*1000+15000)return 50;
 if(tutorialInteractionSeconds()!=180||tutorialInteractionStageAt(180)||tutorialInteractionStageAt(0xffffffff))return 51;
 if(tutorialGlideStageAt(180)||tutorialGlideStageAt(0xffffffff))return 53;
 if(tutorialRoomSeconds()!=300||tutorialRoomStageAt(300)||tutorialRoomStageAt(0xffffffff)||tutorialWallBudgetMs(300)<=300000)return 55;
 for(unsigned second=0;second<300;second++){
  const TutorialStage *s=tutorialRoomStageAt(second);
  if(!s||second<s->begin||second>=s->end||!s->title[0]||!s->detail[0])return 56;
 }
 for(unsigned second=0;second<180;second++){
  const TutorialStage *s=tutorialInteractionStageAt(second);
  if(!s||second<s->begin||second>=s->end||!s->title[0]||!s->detail[0])return 52;
  s=tutorialGlideStageAt(second);
  if(!s||second<s->begin||second>=s->end||!s->title[0]||!s->detail[0])return 54;
 }
 if(tutorialLifetimeSeconds()!=660||!tutorialLifetimeStageAt(600)||tutorialLifetimeStageAt(660))return 40;
 if(tutorialWalkJumpSeconds()!=180)return 1;
 unsigned longPrevious=tutorialWalkJumpSeconds();
 for(unsigned k=0;k<ARRAYSIZE(sheet_tutorialLifetimeStages_rows);k++){
  const Sheet_tutorialLifetimeStages *s=sheet_tutorialLifetimeStages_rows[k];
  if(s->begin!=longPrevious||s->end<=s->begin||s->end>tutorialLifetimeSeconds())return 41;
  const TutorialStage *stage=tutorialLifetimeStageAt((unsigned)s->begin);
  if(!stage||stage->end!=s->end||wcscmp(stage->title,s->title)||!tutorialLifetimeStageAt((unsigned)s->end-1))return 42;
  longPrevious=(unsigned)s->end;
 }
 if(longPrevious!=tutorialLifetimeSeconds())return 43;
 unsigned previous=0;
 for(unsigned k=0;k<ARRAYSIZE(sheet_tutorialStages_rows);k++){
  const Sheet_tutorialStages *s=sheet_tutorialStages_rows[k];
  if(s->begin!=previous||s->end<=s->begin||s->end*1000>=sheet_diagnosticLimits_controls.durationMs||!s->title[0]||!s->detail[0])return 2;
  previous=(unsigned)s->end;
  const TutorialStage *begin=tutorialWalkJumpStageAt((unsigned)s->begin);
  if(!begin||begin->begin!=s->begin||begin->end!=s->end||wcscmp(begin->title,s->title))return 3;
  const TutorialStage *end=tutorialWalkJumpStageAt((unsigned)s->end-1);
  if(!end||end->end!=s->end)return 4;
 }
 if(tutorialWalkJumpStageAt(180)||tutorialWalkJumpStageAt(0xffffffff))return 5;
 if(!tutorialVisibilityStageAt(60)||!tutorialCameraStageAt(80)||!tutorialGroundStageAt(60)||!tutorialStageAt(100))return 6;
 puts("PASS: interaction/walk/jump/lifetime timelines, boundary seconds, lifetime wall budget, legacy plans preserved");return 0;
}
