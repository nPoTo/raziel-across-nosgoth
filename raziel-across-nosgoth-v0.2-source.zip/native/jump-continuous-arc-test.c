// SPDX-License-Identifier: GPL-3.0-or-later
#include <assert.h>
#include <stdio.h>
#include "jump-continuous-arc.h"
int main(void){
 const float pi=3.14159265358979323846f,identity[4]={0,0,0,1},a[3]={1,0,0};float last[4]={0},previous[3]={0};JumpArc rotation={0},edge={0};
 for(unsigned deg=179;deg<=181;deg++){
  float rad=deg*pi/180,q[4]={0,0,sinf(rad/2),cosf(rad/2)},out[4],target[3]={cosf(rad),sinf(rad),0},position[3];
  assert(jumpArcBlend(identity,q,.5f,&rotation,out));assert(jumpArcEdge(a,target,.5f,&edge,position));
  if(deg>179){float dot=0,distance=0;for(unsigned k=0;k<4;k++)dot+=last[k]*out[k];for(unsigned k=0;k<3;k++)distance+=(previous[k]-position[k])*(previous[k]-position[k]);assert(fabsf(dot)>.9999f);assert(distance<.001f);}
  memcpy(last,out,sizeof(last));memcpy(previous,position,sizeof(previous));
 }
 assert(previous[0]<0&&previous[1]>.999f);
 float target[4]={0,0,1,0},out[4];assert(jumpArcBlend(identity,target,0,&rotation,out));assert(!memcmp(out,identity,sizeof(out)));assert(jumpArcBlend(identity,target,1,&rotation,out));assert(!memcmp(out,target,sizeof(out)));
 puts("PASS: continuous 179/180/181 rotation and fixed-length edge, exact endpoints; no half-turn jump.");return 0;
}
