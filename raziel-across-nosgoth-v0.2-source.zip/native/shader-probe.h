#include "report-path.h"
// SPDX-License-Identifier: GPL-3.0-or-later
// Read-only sources attached to sampled host light programs. Worker writes files.
#include "shader-source-reader.h"


static GLuint shaderPrograms[64];
static unsigned int shaderProgramCount,shaderQueueCount;
static ShaderRecord shaderQueue[128];
static volatile LONG shaderQueueLock,shaderDrops;

static void shaderCollect(GLuint program) {
    if(!shaderReady||shaderProgramCount>=ARRAYSIZE(shaderPrograms))return;
    for(unsigned int i=0;i<shaderProgramCount;++i)if(shaderPrograms[i]==program)return;
    if(!cglIsProgram(program))return;
    shaderPrograms[shaderProgramCount++]=program;
    GLuint shaders[8]={0};GLsizei count=0;GLint attached=0;pglGetProgramiv(program,GL_ATTACHED_SHADERS,&attached);
    if(attached<1||attached>8)return;
    shaderAttached(program,8,&count,shaders);if(count!=attached)return;
    for(int i=0;i<count;++i){ShaderRecord record={0};if(!shaderRead(program,shaders[i],&record))continue;
        if(InterlockedCompareExchange(&shaderQueueLock,1,0)){InterlockedIncrement(&shaderDrops);HeapFree(GetProcessHeap(),0,record.source);continue;}
        if(shaderQueueCount==ARRAYSIZE(shaderQueue)){InterlockedIncrement(&shaderDrops);HeapFree(GetProcessHeap(),0,record.source);}
        else shaderQueue[shaderQueueCount++]=record;
        InterlockedExchange(&shaderQueueLock,0);
    }
}
static void shaderFlush(void) {
    ShaderRecord records[128];unsigned int count=0;
    if(InterlockedCompareExchange(&shaderQueueLock,1,0))return;
    count=shaderQueueCount;memcpy(records,shaderQueue,count*sizeof(*records));shaderQueueCount=0;
    InterlockedExchange(&shaderQueueLock,0);
    for(unsigned int i=0;i<count;++i){ShaderRecord *r=&records[i];wchar_t path[32768];
        _snwprintf(path,ARRAYSIZE(path),PROBE_PATH(L"\\sr1-light-shader-%lu-p%u-s%u-%s.glsl"),GetCurrentProcessId(),r->program,r->shader,r->type==GL_VERTEX_SHADER?L"vertex":r->type==GL_FRAGMENT_SHADER?L"fragment":L"geometry");
        FILE *out=_wfopen(path,L"wb");bool written=false;
        if(out){written=fwrite(r->source,1,(size_t)r->length,out)==(size_t)r->length;written=fclose(out)==0&&written;}
        char hash[65]={0};bool hashed=written&&hashFile(path,hash);
        logLine("LIGHT_SHADER program=%u shader=%u type=%d bytes=%d written=%d sha256=%s drops=%ld",r->program,r->shader,r->type,r->length,written,hashed?hash:"unavailable",InterlockedCompareExchange(&shaderDrops,0,0));
        HeapFree(GetProcessHeap(),0,r->source);
    }
}
