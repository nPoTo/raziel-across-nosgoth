// SPDX-License-Identifier: GPL-3.0-or-later
#pragma once
#include "donor-state-sections.h"
typedef struct {
 uintptr_t actor,object,context,descriptor;
 int16_t input[26];
 uint32_t physicsMode,actionKind;int32_t scalar;
 float position[3],velocity[3],acceleration[3],clock,actorFactor,frameFactor;
 uint16_t initial,increment,cap;unsigned char threshold;
 DonorStateSections sections;
} CombatPhaseSnapshot;
typedef struct {bool valid;unsigned attempts,reason;CombatPhaseSnapshot data;} CombatPhaseObservation;
static bool combatPhaseField(void *c,DonorActionStateRead r,uintptr_t a,uintptr_t o,void *out,SIZE_T n){return a&&o<=UINTPTR_MAX-a&&n<=UINTPTR_MAX-a-o&&r(c,a+o,out,n);}
static bool combatPhaseSnapshot(void *c,DonorActionStateRead r,DonorActionStateCode code,uintptr_t base,uint32_t size,uintptr_t model,CombatPhaseSnapshot *s){
 const Sheet_combatPhaseProbe *p=&sheet_combatPhaseProbe_current;memset(s,0,sizeof(*s));
 if(!combatPhaseField(c,r,base,p->actorRva,&s->actor,8)||!s->actor||s->actor%8||
 !combatPhaseField(c,r,s->actor,0x88,&s->object,8)||s->object!=model||
 !combatPhaseField(c,r,base,p->contextRva,&s->context,8)||!s->context||s->context%8||
 !combatPhaseField(c,r,base,p->inputRva,s->input,sizeof(s->input))||
 !combatPhaseField(c,r,base,p->physicsModeRva,&s->physicsMode,4)||
 !combatPhaseField(c,r,s->context,p->scalarOffset,&s->scalar,4)||
 !combatPhaseField(c,r,s->context,p->descriptorOffset,&s->descriptor,8)||
 !combatPhaseField(c,r,s->context,p->actionKindOffset,&s->actionKind,4)||
 !combatPhaseField(c,r,s->actor,p->positionOffset,s->position,12)||
 !combatPhaseField(c,r,s->actor,p->velocityOffset,s->velocity,12)||
 !combatPhaseField(c,r,s->actor,p->accelerationOffset,s->acceleration,12)||
 !combatPhaseField(c,r,s->actor,p->animationClockOffset,&s->clock,4)||
 !combatPhaseField(c,r,s->actor,p->actorTimeFactorOffset,&s->actorFactor,4)||
 !combatPhaseField(c,r,base,p->frameFactorRva,&s->frameFactor,4))return false;
 s->sections=donorStateSectionsRead(c,r,code,base,size,s->actor,base+p->actorRva);
 if(!s->sections.valid||!s->sections.ownerMatches)return false;
 // Only the proved air descriptor layout is interpreted. Idle/ground pointers
 // can refer to another layout and must never be guessed from non-null alone.
 bool air=true;for(unsigned i=0;i<3;i++)if(s->sections.sections[i].firstRva!=0x1319c0||!s->sections.sections[i].secondValid||s->sections.sections[i].secondRva!=0x131a30)air=false;
 if(air&&(!s->descriptor||s->descriptor%2||!combatPhaseField(c,r,s->descriptor,0x3c,&s->initial,2)||!combatPhaseField(c,r,s->descriptor,0x3e,&s->increment,2)||!combatPhaseField(c,r,s->descriptor,0x40,&s->cap,2)||!combatPhaseField(c,r,s->descriptor,0x44,&s->threshold,1)))return false;
 for(unsigned i=0;i<3;i++)if(!isfinite(s->position[i])||!isfinite(s->velocity[i])||!isfinite(s->acceleration[i]))return false;
 return isfinite(s->clock)&&isfinite(s->actorFactor)&&isfinite(s->frameFactor);
}
static CombatPhaseObservation combatPhaseObserve(void *c,DonorActionStateRead r,DonorActionStateCode code,uintptr_t base,uint32_t size,uintptr_t model){
 CombatPhaseObservation o={0};const Sheet_combatPhaseProbe *p=&sheet_combatPhaseProbe_current;
 if(!r||!code||!model||!base||base>UINTPTR_MAX-size||size<0x113fff8||p->gameWrites||p->attempts!=3){o.reason=1;return o;}
 for(unsigned i=0;i<3;i++){CombatPhaseSnapshot a,b;o.attempts=i+1;
  if(!combatPhaseSnapshot(c,r,code,base,size,model,&a)||!combatPhaseSnapshot(c,r,code,base,size,model,&b)){o.reason=2;continue;}
  if(memcmp(&a,&b,sizeof(a))){o.reason=3;continue;}
  o.valid=true;o.reason=0;o.data=a;return o;
 }return o;
}
