#include <stdint.h>
#include <stdbool.h>
#include <stdio.h>
#include <string.h>
#include <math.h>
#include "donor-motion-reader.h"
static uintptr_t base=0x10000000,instance=0x10010000,pool=0x20000000;
static uint16_t head=1;static unsigned char nodes[3][72];static unsigned headReads;static bool changeHead,changeOwner,failRead;
static float factor=0.5f;static bool changeFactor;static unsigned factorReads;
static uintptr_t object=0x30000000;static uint32_t objectFlags,instanceFlags;
static bool readFixture(void *ctx,uintptr_t at,void *out,size_t n){
 (void)ctx;if(failRead)return false;
 if((at==base+0xc5abc4||at==base+0xc5abc8||at==base+0xc5abcc)&&n==4){float f=changeFactor&&factorReads?0.6f:factor;++factorReads;memcpy(out,&f,n);return true;}
 if(at==instance+0x88&&n==8){memcpy(out,&object,n);return true;}
 if(at==object+4&&n==4){memcpy(out,&objectFlags,n);return true;}
 if(at==instance+0xac&&n==4){memcpy(out,&instanceFlags,n);return true;}
 if(at==base+0x10aa650&&n==8){memcpy(out,&pool,n);return true;}
 if(at==base+0xc5aa78&&n==8){uintptr_t owner=changeOwner?instance+8:instance;memcpy(out,&owner,n);return true;}
 if(at==instance+0x1ba&&n==2){uint16_t h=changeHead&&headReads?2:head;++headReads;memcpy(out,&h,n);return true;}
 if(at>=pool&&at<pool+sizeof(nodes)&&n==72){memcpy(out,((unsigned char *)nodes)+(at-pool),n);return true;}return false;
}
#define CHECK(x) do{if(!(x)){printf("FAIL line %d\n",__LINE__);return 1;}}while(0)
int main(void){
 nodes[1][0]=2;nodes[1][2]=0x22;nodes[2][2]=0x10;float v[3]={0,-57.5f,0};memcpy(nodes[1]+0x28,v,sizeof(v));
 DonorMotion m=donorMotionRead(readFixture,NULL,base,instance);CHECK(m.valid&&m.complete&&m.stable&&m.visited==2&&m.vector[1]==-57.5f&&m.node==pool+72);
 nodes[2][2]=0x22;CHECK(!donorMotionRead(readFixture,NULL,base,instance).valid);nodes[2][2]=0x10;
 nodes[2][0]=1;CHECK(!donorMotionRead(readFixture,NULL,base,instance).complete);nodes[2][0]=0;
 v[1]=NAN;memcpy(nodes[1]+0x28,v,sizeof(v));CHECK(!donorMotionRead(readFixture,NULL,base,instance).valid);v[1]=-57.5f;memcpy(nodes[1]+0x28,v,sizeof(v));
 headReads=0;changeHead=true;CHECK(!donorMotionRead(readFixture,NULL,base,instance).stable);changeHead=false;
 changeOwner=true;CHECK(!donorMotionRead(readFixture,NULL,base,instance).valid);changeOwner=false;
 head=5000;CHECK(!donorMotionRead(readFixture,NULL,base,instance).complete);head=1;
 failRead=true;CHECK(!donorMotionRead(readFixture,NULL,base,instance).valid);
 CHECK(!donorTimeRead(readFixture,NULL,base,instance).valid);failRead=false;
 CHECK(donorTimeRead(readFixture,NULL,base,instance).valid);
 factor=NAN;CHECK(!donorTimeRead(readFixture,NULL,base,instance).valid);
 factor=0;CHECK(!donorTimeRead(readFixture,NULL,base,instance).valid);
 factor=9;CHECK(!donorTimeRead(readFixture,NULL,base,instance).valid);
 factor=0.5f;factorReads=0;changeFactor=true;CHECK(!donorTimeRead(readFixture,NULL,base,instance).valid);changeFactor=false;
 changeOwner=true;CHECK(!donorTimeRead(readFixture,NULL,base,instance).valid);changeOwner=false;
 CHECK(donorTimeRead(readFixture,NULL,base,instance).selectedRva==0xc5abc4);
 objectFlags=0x10;CHECK(donorTimeRead(readFixture,NULL,base,instance).selectedRva==0xc5abcc);
 instanceFlags=0x08000000;CHECK(donorTimeRead(readFixture,NULL,base,instance).selectedRva==0xc5abc8);
 puts("Donor motion reader: exact node payload, ambiguity/cycle/bounds, finiteness, head/owner races and failed read rejection PASS");return 0;
}
