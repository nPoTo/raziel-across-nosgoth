// SPDX-License-Identifier: GPL-3.0-or-later
// Read-only exact-build SR1 mode/flag candidates. No game actions or resources.
#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <tlhelp32.h>
#include <bcrypt.h>
#include <stdbool.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <wchar.h>
#include "reader-hash.h"
static bool readAt(HANDLE p,uintptr_t at,void *out,SIZE_T size){SIZE_T n=0;return at&&ReadProcessMemory(p,(void*)at,out,size,&n)&&n==size;}
int wmain(int argc,wchar_t **argv){
 if(argc!=2)return 1;
 wchar_t *end;unsigned long pid=wcstoul(argv[1],&end,10);if(!pid||*end)return 1;
 HANDLE p=OpenProcess(PROCESS_QUERY_LIMITED_INFORMATION|PROCESS_VM_READ,FALSE,(DWORD)pid);if(!p)return 2;
 wchar_t file[32768],dll[32768];DWORD len=32768;char hash[65];FILETIME created,exited,kernel,user;int result=3;
 if(!QueryFullProcessImageNameW(p,0,file,&len)||len+12>=32768||!wcsrchr(file,L'\\')||_wcsicmp(wcsrchr(file,L'\\')+1,L"SRX.exe")||!hashFile(file,hash)||strcmp(hash,"0fb3aef0530ebf0510191f934dc371b69b43574331d3623eda694b72f060db93"))goto done;
 wcscpy(dll,file);wcscpy(wcsrchr(dll,L'\\')+1,L"1\\sr1.dll");
 if(!hashFile(dll,hash)||strcmp(hash,"c006dea45509cdc3fbfab3a4230b47869c306ecdd7df8b4fd2499fd3654a2205")||!GetProcessTimes(p,&created,&exited,&kernel,&user))goto done;
 HANDLE snap=CreateToolhelp32Snapshot(TH32CS_SNAPMODULE|TH32CS_SNAPMODULE32,(DWORD)pid);uintptr_t base=0;DWORD imageSize=0;unsigned matches=0;
 if(snap!=INVALID_HANDLE_VALUE){MODULEENTRY32W m={0};m.dwSize=sizeof(m);if(Module32FirstW(snap,&m))do{if(!_wcsicmp(m.szExePath,dll)&&m.modBaseSize>0x2a89538){base=(uintptr_t)m.modBaseAddr;imageSize=m.modBaseSize;matches++;}}while(Module32NextW(snap,&m));CloseHandle(snap);}
 result=4;if(matches!=1)goto done;
 const unsigned char proof[8]={0x66,0x83,0x3d,0x82,0x3f,0xa4,0x02,0x06};unsigned char actual[8];
 if(!readAt(p,base+0x455ac,actual,8)||memcmp(proof,actual,8))goto done;
 uint64_t creation=((uint64_t)created.dwHighDateTime<<32)|created.dwLowDateTime;
 printf("{\"type\":\"session\",\"pid\":%lu,\"creation\":\"%llu\",\"moduleHash\":\"%s\",\"mode\":\"read-only-candidate\"}\n",pid,(unsigned long long)creation,hash);
 unsigned valid=0,generation=0;uintptr_t previousActor=0;
 for(unsigned i=0;i<30;i++){
  uintptr_t actor=0,actorAfter=0,object=0,objectAfter=0,name=0,nameAfter=0,stateActor=0,stateAfter=0,process=0,processAfter=0;char label[9];uint32_t flags=0,flagsAfter=0;uint16_t mode=0,modeAfter=0;
  bool ok=readAt(p,base+0x2a89310,&actor,8)&&actor&&readAt(p,actor+0x30,&object,8)&&object&&readAt(p,object+0x30,&name,8)&&readAt(p,name,label,9)&&!memcmp(label,"raziel__",9)&&readAt(p,base+0x2a8950c,&flags,4)&&readAt(p,base+0x2a89536,&mode,2)&&readAt(p,base+0x2a8950c,&flagsAfter,4)&&flagsAfter==flags&&readAt(p,base+0x2a89536,&modeAfter,2)&&modeAfter==mode&&readAt(p,actor+0x30,&objectAfter,8)&&objectAfter==object&&readAt(p,object+0x30,&nameAfter,8)&&nameAfter==name&&readAt(p,base+0x2a89310,&actorAfter,8)&&actorAfter==actor;
  ok=ok&&readAt(p,base+0x2a88588,&stateActor,8)&&stateActor==actor&&readAt(p,base+0x2a88598,&process,8)&&process>=base&&process<base+imageSize&&readAt(p,base+0x2a88588,&stateAfter,8)&&stateAfter==stateActor&&readAt(p,base+0x2a88598,&processAfter,8)&&processAfter==process&&readAt(p,base+0x2a89310,&actorAfter,8)&&actorAfter==actor;
  if(ok){valid++;if(actor!=previousActor){generation++;previousActor=actor;}}else previousActor=0;
  printf("{\"type\":\"sample\",\"sequence\":%u,\"tickMs\":%llu,\"valid\":%s,\"actorGeneration\":%u,\"globalFlagsRaw\":%u,\"modeRaw\":%u,\"processRva\":\"0x%llx\"}\n",i,(unsigned long long)GetTickCount64(),ok?"true":"false",ok?generation:0,ok?flags:0,ok?mode:0,(unsigned long long)(ok?process-base:0));fflush(stdout);if(i<29)Sleep(50);
 }
 result=valid?0:5;
done:CloseHandle(p);return result;
}
