// SPDX-License-Identifier: GPL-3.0-or-later
// Reuse the supported executable/model-registry reader. Its legacy entry point
// is not called; this program accepts only PID and emits scalar identity checks.
#define wmain legacyTelemetryEntryUnused
#include "raziel-telemetry.c"
#undef wmain
#include "donor-identity-reader.h"
int wmain(int argc,wchar_t **argv){
 unsigned long pid=0;if(argc!=2||!number(argv[1],0xffffffffUL,&pid))return 1;
 HANDLE p=OpenProcess(PROCESS_VM_READ|PROCESS_QUERY_LIMITED_INFORMATION,FALSE,pid);if(!p)return 2;
 wchar_t exe[32768],expected[32768];DWORD length=ARRAYSIZE(exe),n=GetEnvironmentVariableW(L"RAZIEL_DEFIANCE_EXE",expected,ARRAYSIZE(expected));char digest[65];
 if(!n||n>=ARRAYSIZE(expected)||!QueryFullProcessImageNameW(p,0,exe,&length)||_wcsicmp(exe,expected)||!hashFile(exe,digest)||strcmp(digest,supportedHash)){CloseHandle(p);return 3;}
 HANDLE modules=CreateToolhelp32Snapshot(TH32CS_SNAPMODULE,pid);MODULEENTRY32W m={0};m.dwSize=sizeof(m);uintptr_t base=0;DWORD imageSize=0;
 if(modules!=INVALID_HANDLE_VALUE){if(Module32FirstW(modules,&m))do{if(!_wcsicmp(m.szExePath,exe)){base=(uintptr_t)m.modBaseAddr;imageSize=m.modBaseSize;break;}}while(Module32NextW(modules,&m));CloseHandle(modules);}
 FILETIME created,exited,kernel,user;if(!base||imageSize<0xc88020+512*64||!GetProcessTimes(p,&created,&exited,&kernel,&user)){CloseHandle(p);return 4;}
 printf("{\"type\":\"session\",\"pid\":%lu,\"sha256\":\"%s\",\"processCreation\":\"%llu\",\"mode\":\"read-only-actor-identity\"}\n",pid,digest,(unsigned long long)(((uint64_t)created.dwHighDateTime<<32)|created.dwLowDateTime));
 for(unsigned i=0;i<(unsigned)sheet_donorActorIdentityProbe_current.samples;i++){
  uintptr_t context=findContext(p,base),model=0,again=0;if(context&&!razielModel(p,context,&model))model=0;
  DonorIdentityObservation r=donorIdentityRead(p,donorStateRead,base,imageSize,model);
  if(context){if(!razielModel(p,context,&again)||again!=model)r=(DonorIdentityObservation){0};}
  printf("{\"type\":\"sample\",\"sequence\":%u,\"valid\":%s,\"actorPresent\":%s,\"objectReadable\":%s,\"actorStable\":%s,\"registryAvailable\":%s,\"modelMatchesRaziel\":%s}\n",i,r.valid?"true":"false",r.actorPresent?"true":"false",r.objectReadable?"true":"false",r.actorStable?"true":"false",r.registryAvailable?"true":"false",r.modelMatchesRaziel?"true":"false");fflush(stdout);if(i+1<(unsigned)sheet_donorActorIdentityProbe_current.samples)Sleep((DWORD)sheet_donorActorIdentityProbe_current.intervalMs);
 }
 CloseHandle(p);return 0;
}
