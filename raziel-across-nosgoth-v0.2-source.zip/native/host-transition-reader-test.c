// SPDX-License-Identifier: GPL-3.0-or-later
#define main oldBaseReaderMain
#include "host-block-state-reader-test.c"
#undef main
#include "host-transition-reader.h"
static unsigned transitionReads,idReads;static int animationDefect;
static bool transitionFixture(void *c,uintptr_t address,void *out,SIZE_T n){transitionReads++;for(unsigned i=0;i<3;i++)if(address==actor+0x374+i*0x50&&n==2){uint16_t id=i==0?0:i==1?65535:22;if(animationDefect==1)return false;if(animationDefect==2&&++idReads>3)id++;memcpy(out,&id,2);return true;}return fixture(c,address,out,n);}
static bool transitionCode(void *c,uintptr_t address,uintptr_t module){return address==base+0xeeb40&&module==base&&defect!=12?true:code(c,address,module);}
static int observe(uintptr_t state,uintptr_t target,HostTransitionMetadata *m){actorReads=callbackReads=recordReads=targetReads=idReads=transitionReads=0;return hostTransitionRead(NULL,transitionFixture,transitionCode,base,0x3000000,state,target,m);}
int main(void){
 CHECK(oldBaseReaderMain()==0,100);defect=animationDefect=0;away=false;HostTransitionMetadata m={0};
 CHECK(observe(base+0x2a88588,base+0xeeb40,&m)==1&&m.opaqueActor==actor&&m.requestedRva==0xeeb40&&m.clips[0]==0&&m.clips[1]==65535&&m.clips[2]==22,101);
 CHECK(observe(base+0x2a88590,base+0xeeb40,&m)==0&&transitionReads==0,102);
 CHECK(observe(base+0x2a88588,base-1,&m)==-1&&transitionReads==0,103);
 animationDefect=2;CHECK(observe(base+0x2a88588,base+0xeeb40,&m)==-1,104);animationDefect=0;
 defect=1;CHECK(observe(base+0x2a88588,base+0xeeb40,&m)==-1,105);defect=2;CHECK(observe(base+0x2a88588,base+0xeeb40,&m)==-1,106);defect=6;CHECK(observe(base+0x2a88588,base+0xeeb40,&m)==-1,107);defect=0;
 defect=7;CHECK(observe(base+0x2a88588,base+0xeeb40,&m)==-1,109);defect=12;CHECK(observe(base+0x2a88588,base+0xeeb40,&m)==-1,110);defect=0;animationDefect=1;CHECK(observe(base+0x2a88588,base+0xeeb40,&m)==-1,111);animationDefect=0;
 CHECK(hostTransitionRead(NULL,transitionFixture,code,UINTPTR_MAX-4,0x3000000,0,0,&m)==-1,108);
 puts("PASS: production transition reader exact state/unrelated no-read, requested code bounds, double actor/owner/handler/clip snapshots; no queue/payload reads");return 0;
}
