#include "report-path.h"
// Explicit experiment: finish only the current grounded StartMove transition.
#include "instant-start-proof.h"
typedef uintptr_t (__fastcall *StartMoveFn)(uintptr_t,int32_t,uintptr_t);
typedef uintptr_t (__fastcall *CharacterSwitchFn)(uintptr_t,uintptr_t,uintptr_t);
static StartMoveFn originalStartMove;static CharacterSwitchFn instantCharacterSwitch;
static PVOID instantStartTarget;static uintptr_t instantStartModule;
static bool instantStartAttempted,instantStartRequested;
static volatile LONG instantStartEnabled,instantStartBusy;
static ULONGLONG instantStartBegin;static unsigned instantStartSwitches;
static bool instantStartScope(uintptr_t state,int32_t section,ULONGLONG now,uintptr_t *player,float *target,uint64_t *source){
    uintptr_t instance=0,process=0;float root[16];int32_t velocity=0,time=0;DWORD foreground=0;
    if(!InterlockedCompareExchange(&instantStartEnabled,0,0)||!InterlockedCompareExchange(&movementEnabled,0,0)||
      !instantStartModule||section!=0||now<instantStartBegin||now-instantStartBegin>=75000||!worldRoot(root,player)||
      !worldRead(state,&instance,8)||instance!=*player||!worldRead(state+0x10,&process,8)||process!=instantStartModule+0xf48e0||
      !worldLastDraw||now<worldLastDraw||now-worldLastDraw>=250||worldLastInstance!=*player||root[10]<=.8f||
      !worldRead(*player+0x2d4,&velocity,4)||velocity!=0||!worldRead(instantStartModule+0x2a89628,&time,4)||time<=0||time>8192||!srGroundMovementInput())return false;
    GetWindowThreadProcessId(GetForegroundWindow(),&foreground);if(foreground!=GetCurrentProcessId())return false;
    unsigned char packet[80];
    return movementReadPacket(packet)&&movementPacketTarget(packet,sizeof(packet),now,overlayLivePid,overlayLiveTick,time,target,source)&&*target<-.01f;
}
static uintptr_t __fastcall instantStartMove(uintptr_t state,int32_t section,uintptr_t data){
    // Preserve entry/exit events and all original side effects. Native transition
    // sends exit+init messages to all three sections; recursion forwards only.
    uintptr_t result=originalStartMove(state,section,data);uintptr_t player=0;float target=0;uint64_t source=0;
    if(InterlockedCompareExchange(&instantStartBusy,1,0))return result;
    ULONGLONG now=GetTickCount64();
    if(instantStartScope(state,section,now,&player,&target,&source)){
        instantCharacterSwitch(state,instantStartModule+0xf3280,0);
        ++instantStartSwitches;uintptr_t process=0;bool moved=worldRead(state+0x10,&process,8)&&process==instantStartModule+0xf3280;
        logLine("SR1_INSTANT_START tick=%llu player=%p state=%p targetY=%.9g sourceTick=%llu switched=%u; native character transition",now,(void *)player,(void *)state,target,(unsigned long long)source,moved);
        if(!moved)InterlockedExchange(&instantStartEnabled,0);
    }
    InterlockedExchange(&instantStartBusy,0);return result;
}
static void instantStartInstall(HMODULE module){
    if(!module||instantStartAttempted)return;instantStartAttempted=true;
    for(unsigned i=0;i<ARRAYSIZE(instantStartProofs);i++){
      unsigned char bytes[4096];char sha[65];uintptr_t at=(uintptr_t)module+instantStartProofs[i].rva;
      if(instantStartProofs[i].size>sizeof(bytes)||!worldRead(at,bytes,instantStartProofs[i].size)||!hashBytes(bytes,instantStartProofs[i].size,sha)||strcmp(sha,instantStartProofs[i].sha256)){logLine("SR1_INSTANT_START full-code gate failed kind=%u",i);return;}
    }
    instantStartModule=(uintptr_t)module;instantCharacterSwitch=(CharacterSwitchFn)(instantStartModule+0x10ffc0);
    MH_STATUS init=MH_Initialize();if(init!=MH_OK&&init!=MH_ERROR_ALREADY_INITIALIZED)return;
    PVOID target=(void *)(instantStartModule+0xf48e0);MH_STATUS create=MH_CreateHook(target,(void *)&instantStartMove,(void **)&originalStartMove),enable=create==MH_OK?MH_EnableHook(target):create;
    if(enable==MH_OK)instantStartTarget=target;logLine("SR1_INSTANT_START create=%d enable=%d full-code proof=1; explicit native transition",create,enable);
}
static void instantStartTick(void){
    bool requested=instantStartTarget&&GetFileAttributesW(PROBE_PATH(L"\\instant-start-sr1.enable"))!=INVALID_FILE_ATTRIBUTES&&
      GetFileAttributesW(PROBE_PATH(L"\\movement-sr1.enable"))!=INVALID_FILE_ATTRIBUTES&&GetFileAttributesW(PROBE_PATH(L"\\replace-sr1.enable"))!=INVALID_FILE_ATTRIBUTES;
    if(requested!=instantStartRequested){instantStartRequested=requested;instantStartBegin=requested?GetTickCount64():0;instantStartSwitches=0;InterlockedExchange(&instantStartEnabled,requested);logLine("SR1_INSTANT_START enabled=%u; bounded75s, current ground actor, fresh donor command",requested);}
}
static void instantStartStop(void){InterlockedExchange(&instantStartEnabled,0);if(instantStartTarget)MH_DisableHook(instantStartTarget);}
