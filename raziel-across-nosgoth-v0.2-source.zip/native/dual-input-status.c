// SPDX-License-Identifier: GPL-3.0-or-later
#include <stdio.h>
#include <stdlib.h>
#include "dual-input-shared.h"
int wmain(int argc,wchar_t **argv){
 if(argc!=2)return 2;wchar_t *end=NULL;unsigned long pid=wcstoul(argv[1],&end,10);if(!pid||*end)return 2;
 wchar_t name[96];dualInputName(name,pid);HANDLE h=OpenFileMappingW(FILE_MAP_READ,FALSE,name);if(!h)return 3;
 const DualInputShared *m=MapViewOfFile(h,FILE_MAP_READ,0,0,sizeof(*m));if(!m){CloseHandle(h);return 4;}
 DualInputWire w={0};bool readable=dualInputCopy(m,&w);
 printf("{\"host\":%lu,\"donor\":%lu,\"epoch\":%llu,\"ready\":%lld,\"hostFrames\":%lld,\"donorFrames\":%lld,\"revoked\":%ld,\"readable\":%s,\"valid\":%u,\"sequence\":%llu,\"tick\":%llu}\n",(unsigned long)m->session.host,(unsigned long)m->session.donor,(unsigned long long)m->session.epoch,(long long)m->donorReady,(long long)m->hostFrames,(long long)m->donorFrames,m->revoked,readable?"true":"false",w.valid,(unsigned long long)w.sequence,(unsigned long long)w.tick);
 UnmapViewOfFile(m);CloseHandle(h);return 0;
}
