// SPDX-License-Identifier: GPL-3.0-or-later
#pragma once
#include <stdint.h>
#include <stdbool.h>
#include <string.h>
#include <math.h>
#include "dual-input-state.h"
typedef struct {uint16_t buttons;uint8_t lt,rt;int16_t x,y,rx,ry;} DualInputPad;
typedef struct {uint32_t mask,key,pad;} DualInputBinding;
typedef struct {uint8_t last[112],blocked[112];uint16_t lastPad,blockedPad;bool active;} DualInputReleaseGate;
static inline void dualInputReleaseGate(DualInputReleaseGate *g,const uint8_t keys[112],uint16_t pad,bool active,uint8_t nativeKeys[112],uint16_t *blockedPad){
 if(g->active&&!active){memcpy(g->blocked,g->last,112);g->blockedPad=g->lastPad;}
 memcpy(nativeKeys,keys,112);
 for(unsigned i=0;i<112;i++){g->blocked[i]&=keys[i];if(g->blocked[i])nativeKeys[i]=0;}
 g->blockedPad&=pad;*blockedPad=g->blockedPad;memset(g->last,0,112);
 for(unsigned i=0;i<sheet_dualInputFrameKeys_count;i++){unsigned k=(unsigned)sheet_dualInputFrameKeys_rows[i]->code;g->last[k]=keys[k];}
 g->lastPad=pad;g->active=active;
}
// Reconstruct from the CURRENT completed raw keyboard snapshot. A cached
// pre-write mask would resurrect a key released while ownership was ending.
static inline bool dualInputNativeKeyboard(const uint8_t keys[112],const DualInputBinding bindings[13],uint32_t *out){
 uint32_t value=0,seen=0;for(unsigned i=0;i<13;i++){
  const DualInputBinding *b=bindings+i;
  if(!b->mask||(b->mask&(b->mask-1))||(b->mask&~0xfff1u)||(seen&b->mask)||b->key>=112||b->pad<92||b->pad>107)return false;
  seen|=b->mask;if(keys[b->key])value|=b->mask;
 }if(seen!=0xfff1u)return false;*out=value;return true;
}
enum {DUAL_CROUCH=0x10000,DUAL_AIM=0x20000,DUAL_FORWARD=0x40000,DUAL_BACK=0x80000,DUAL_LEFT=0x100000,DUAL_RIGHT=0x200000};
static inline uint32_t dualInputKeys(const uint8_t keys[112]){
 uint32_t held=0;for(unsigned i=0;i<sheet_dualInputFrameKeys_count;i++){
  const Sheet_dualInputFrameKeys *r=sheet_dualInputFrameKeys_rows[i];
  if(r->code>=0&&r->code<112&&keys[r->code])held|=(uint32_t)r->mask;
 }return held;
}
static inline DualInputPad dualInputMerge(uint32_t keys,const DualInputPad *pad){
 DualInputPad r=pad?*pad:(DualInputPad){0};r.buttons|=(uint16_t)keys;
 if(keys&DUAL_CROUCH)r.lt=255;if(keys&DUAL_AIM)r.rt=255;
 // Analog input wins only outside the accepted deadzone. Digital diagonals
 // have unit length; opposed keys cancel, without changing pad precision.
 if((int64_t)r.x*r.x+(int64_t)r.y*r.y<=7849LL*7849){
  int x=!!(keys&DUAL_RIGHT)-!!(keys&DUAL_LEFT),y=!!(keys&DUAL_FORWARD)-!!(keys&DUAL_BACK);
  const int scale=x&&y?23170:32767;r.x=(int16_t)(x*scale);r.y=(int16_t)(y*scale);
 }return r;
}
// Accepted controller policy returns physical-XInput-layout buttons, already
// routed for SR1. Translate exactly once to SR1's native action mask.
static inline uint32_t dualInputHostMask(DualInputPad p){
 uint32_t r=0;const uint16_t b=p.buttons;
 if(b&0x1000)r|=0x4000;if(b&0x4000)r|=0x8000;if(b&0x2000)r|=0x2000;
 if(b&0x8000)r|=0x1000;if(b&0x100)r|=0x100;if(b&0x200)r|=0x800;
 if(p.lt>=30)r|=0x400;if(p.rt>=30)r|=0x200;
 if(p.y>7849)r|=0x10;if(p.y< -7849)r|=0x80;if(p.x< -7849)r|=0x40;if(p.x>7849)r|=0x20;
 return r;
}
// Restore only the bits still equal to our previous output. The original
// input function then processes new transitions. Never restore a stale whole
// word over Escape/Tab/UI state or another native writer's changes.
typedef struct {uint32_t before,after,mask;bool active;} DualInputMaskLease;
static inline uint32_t dualInputMaskRestore(DualInputMaskLease *l,uint32_t current){
 if(!l->active)return current;
 const uint32_t same=~(current^l->after)&l->mask;
 uint32_t r=(current&~same)|(l->before&same);l->active=false;return r;
}
static inline uint32_t dualInputMaskApply(DualInputMaskLease *l,uint32_t current,uint32_t wanted,uint32_t mask){
 l->before=current;l->mask=mask;l->after=(current&~mask)|(wanted&mask);l->active=true;return l->after;
}
