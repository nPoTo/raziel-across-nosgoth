// SPDX-License-Identifier: GPL-3.0-or-later
#include "donor-message-lease.h"
#include <stdio.h>
#define CHECK(x) do{if(!(x)){fprintf(stderr,"FAIL line %d: %s\n",__LINE__,#x);return 1;}}while(0)
static bool accept(DonorMessageSessionLease *s,bool valid,uint64_t session,uint32_t writer,uint64_t tick,uint64_t now){return donorMessageSessionAccept(s,valid,session,writer,tick,now,60000,1500);}
int main(void){
 DonorMessageSessionLease s={0};CHECK(!accept(NULL,true,5,3,100,100));
 CHECK(!accept(&s,false,0,0,0,100));CHECK(!s.session&&!s.terminal);
 CHECK(accept(&s,true,5,3,100,100));CHECK(s.session==5&&s.writer==3&&s.startTick==100&&s.heartbeatTick==100);
 CHECK(accept(&s,true,5,3,100,1599));CHECK(accept(&s,true,5,3,200,1600));
 CHECK(!accept(&s,false,5,3,200,1601));CHECK(s.terminal);CHECK(!accept(&s,true,5,3,1601,1601));
 // Each complete read failure, foreign owner, rewound/future/stale heartbeat
 // and deadline independently terminates the already bound session.
 for(unsigned reason=0;reason<7;reason++){
  DonorMessageSessionLease a={0};CHECK(accept(&a,true,5,3,100,100));
  uint64_t session=5,tick=200,now=200;uint32_t writer=3;bool valid=true;
  if(reason==0)valid=false;if(reason==1)session=6;if(reason==2)writer=4;
  if(reason==3)tick=99;if(reason==4)tick=201;if(reason==5){tick=100;now=1600;}if(reason==6){tick=60100;now=60100;}
  CHECK(!accept(&a,valid,session,writer,tick,now));CHECK(a.terminal);CHECK(!accept(&a,true,5,3,now,now));
 }
 DonorMessageSessionLease z={0};CHECK(!accept(&z,true,0,3,100,100));CHECK(!accept(&z,true,1,0,100,100));CHECK(!accept(&z,true,1,3,0,100));CHECK(!accept(&z,true,1,3,101,100));CHECK(!z.terminal&&!z.session);
 CHECK(!donorMessageSessionAccept(&z,true,1,3,100,100,0,1500));CHECK(!donorMessageSessionAccept(&z,true,1,3,100,100,60000,0));CHECK(!z.session);
 DonorMessageSessionLease edge={0};CHECK(accept(&edge,true,UINT64_MAX,UINT32_MAX,UINT64_MAX-100,UINT64_MAX-100));CHECK(accept(&edge,true,UINT64_MAX,UINT32_MAX,UINT64_MAX,UINT64_MAX));CHECK(!accept(&edge,true,UINT64_MAX,UINT32_MAX,1,1));CHECK(edge.terminal);
 DonorMessageSessionLease deadline={0};CHECK(accept(&deadline,true,9,3,100,100));CHECK(accept(&deadline,true,9,3,60099,60099));CHECK(!accept(&deadline,true,9,3,60100,60100));CHECK(deadline.terminal);
 puts("PASS: actual one-session lease binds once, immediate missing/foreign/future/stale revocation, terminal END policy, deadline and uint64 boundaries");return 0;
}
