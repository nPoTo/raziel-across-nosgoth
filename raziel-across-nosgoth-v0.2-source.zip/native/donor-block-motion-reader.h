// SPDX-License-Identifier: GPL-3.0-or-later
#pragma once
#include <math.h>
#include "donor-block-targets.h"
typedef struct {uintptr_t opaqueActor,opaqueState,opaqueUserdata;uint32_t handler,flags,selector;float direction[2],position[3];} DonorBlockMotionMetadata;
static inline int donorBlockMotionRead(void *c,DonorActionStateRead read,DonorActionStateCode code,uintptr_t base,uint32_t size,uintptr_t actor,uintptr_t target,DonorBlockMotionMetadata *out){
 memset(out,0,sizeof(*out));const Sheet_donorBlockMotionPolicy *p=&sheet_donorBlockMotionPolicy_bounded;if(!actor||!target||actor%8||target%8||p->flagsOffset||p->directionOffset!=0x70||p->selectorOffset!=0x78||p->positionOffset!=0x20)return -1;
 DonorBlockTargets observed=donorBlockTargetsRead(c,read,code,base,size,actor);if(!observed.valid)return -1;DonorBlockTargetSnapshot a,b;if(!donorBlockTargetSnapshot(c,read,base,actor,&a))return -1;
 bool entry=a.entry==target&&a.entryCallback==base+0xee380&&a.entryHandlerRead,held=a.held==target&&a.heldCallback==base+0xee380&&a.heldHandlerRead;if(!entry&&!held)return 0;uintptr_t userdata=entry?a.entryUserdata:a.heldUserdata,handler=entry?a.entryHandler:a.heldHandler;
 if(handler<base||handler-base>=size||!code(c,handler,base)||!(handler==base+0xce270||handler==base+0xce4c0||handler==base+0xce800))return -1;
 uint32_t flags=0,selector=0;float direction[2],position[3];if(!donorBlockTargetReadField(c,read,userdata,0,&flags,4)||!donorBlockTargetReadField(c,read,userdata,0x70,direction,8)||!donorBlockTargetReadField(c,read,userdata,0x78,&selector,4)||!donorBlockTargetReadField(c,read,target,0x20,position,12))return -1;
 for(unsigned i=0;i<2;i++)if(!isfinite(direction[i])||fabsf(direction[i])>1e6f)return -1;for(unsigned i=0;i<3;i++)if(!isfinite(position[i])||fabsf(position[i])>1e8f)return -1;
 if(!donorBlockTargetSnapshot(c,read,base,actor,&b)||memcmp(&a,&b,sizeof(a)))return -1;
 uint32_t f2=0,s2=0;float d2[2],p2[3];if(!donorBlockTargetReadField(c,read,userdata,0,&f2,4)||!donorBlockTargetReadField(c,read,userdata,0x70,d2,8)||!donorBlockTargetReadField(c,read,userdata,0x78,&s2,4)||!donorBlockTargetReadField(c,read,target,0x20,p2,12)||f2!=flags||s2!=selector||memcmp(d2,direction,8)||memcmp(p2,position,12))return -1;
 if(!donorBlockTargetSnapshot(c,read,base,actor,&b)||memcmp(&a,&b,sizeof(a)))return -1;
 out->opaqueActor=actor;out->opaqueState=a.state;out->opaqueUserdata=userdata;out->handler=(uint32_t)(handler-base);out->flags=flags;out->selector=selector;memcpy(out->direction,direction,8);memcpy(out->position,position,12);return 1;
}
