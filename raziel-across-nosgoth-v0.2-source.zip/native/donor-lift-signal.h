// SPDX-License-Identifier: GPL-3.0-or-later
#include "air-clock-shared.h"
static HANDLE donorLiftMap;static AirClockShared *donorLiftView;static uint64_t donorLiftSequence;
static bool donorLiftOpen(HostContactLease expected){
 wchar_t n[96];_snwprintf(n,96,L"Local\\LOKLift-v1-%lu",expected.pid);SetLastError(0);
 donorLiftMap=CreateFileMappingW(INVALID_HANDLE_VALUE,NULL,PAGE_READWRITE,0,sizeof(AirClockShared),n);
 if(!donorLiftMap)return false;
 if(GetLastError()==ERROR_ALREADY_EXISTS){CloseHandle(donorLiftMap);donorLiftMap=NULL;return false;}
 donorLiftView=MapViewOfFile(donorLiftMap,FILE_MAP_READ|FILE_MAP_WRITE,0,0,sizeof(AirClockShared));
 if(!donorLiftView){CloseHandle(donorLiftMap);donorLiftMap=NULL;}return donorLiftView!=NULL;
}
static void donorLiftPublish(const HostContactLease *l,uintptr_t actor,bool valid){
 if(!donorLiftView)return;
 AirClockPacket p={.magic=0x314c4341,.version=1,.hostPid=l->pid,.donorPid=GetCurrentProcessId(),.hostCreation=l->creation,.epoch=l->epoch,.tick=GetTickCount64(),.actor=l->actor,.sequence=++donorLiftSequence};
 uintptr_t state=0,owner=0;uint32_t mode=0;float vz=0;
 bool ok=valid&&donorProcessIdentity(actor)&&worldRead(actor+0x3f8,&state,8)&&state&&worldRead(state,&owner,8)&&owner==actor&&
 worldRead(donorProcessBase+0x113fff4,&mode,4)&&mode==10&&worldRead(actor+0x170,&vz,4)&&isfinite(vz)&&vz>0&&vz<4096;
 for(unsigned i=0;ok&&i<3;i++){uintptr_t c[2];ok=worldRead(state+i*0x250+16,c,16)&&c[0]==donorProcessBase+0x10f1d0&&c[1]==donorProcessBase+0x10f220;}
 uintptr_t after=0;ok=ok&&worldRead(actor+0x3f8,&after,8)&&after==state&&donorProcessIdentity(actor);p.active=ok;airClockStore(donorLiftView,&p);
}
static void donorLiftRevoke(void){if(donorLiftView)InterlockedExchange(&donorLiftView->revoked,1);}
