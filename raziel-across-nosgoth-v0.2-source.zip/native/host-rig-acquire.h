// SPDX-License-Identifier: GPL-3.0-or-later
#pragma once
#include "host-rig-reader.h"
#include "sr1-retarget-gate.h"
typedef bool (*RigContextRead)(void *,RigRead,uintptr_t,uintptr_t,bool,Sr1RetargetContext *);
typedef uint64_t (*RigClockUs)(void *);
typedef struct {HostRig receipt;Sr1RetargetContext context;bool coherent,matrixRace,same;unsigned reason,attempts,retries;uint64_t elapsedUs;} RigAcquisition;
// This weaker comparison ONLY permits another strict read. It never admits a
// snapshot or extends a cached pose's lifetime.
static inline bool rigSameResource(const HostRig *a,const HostRig *b){
 return a->count>0&&a->count<=128&&a->actor==b->actor&&a->object==b->object&&a->name==b->name&&a->list==b->list&&a->model==b->model&&a->segments==b->segments&&a->modelIndex==b->modelIndex&&a->count==b->count&&!memcmp(a->parents,b->parents,(SIZE_T)a->count*sizeof(a->parents[0]));
}
static inline bool rigAcquire(void *opaque,RigRead read,uintptr_t base,bool foreground,RigContextRead contextRead,RigClockUs clock,RigAcquisition *out){
 const Sheet_rigAcquisitionRetry *policy=&sheet_rigAcquisitionRetry_bounded_retry;
 memset(out,0,sizeof(*out));
 if(policy->maxAttempts!=3||policy->startBudgetUs!=4000||!policy->preserveStrictSnapshot||policy->gameWrites||policy->enabled)return false;
 uint64_t start=clock(opaque);HostRig first={0};bool pinned=false;
 for(unsigned attempt=0;attempt<(unsigned)policy->maxAttempts;attempt++){
  HostRig observed={0},race={0},current={0},after={0};bool matrixRace=false;
  out->coherent=hostRigReadClassified(opaque,read,base,&observed,&race,&matrixRace);out->reason=rigReadFailure;out->matrixRace=matrixRace;out->attempts=attempt+1;
  bool identity=rigIdentitySnapshot(opaque,read,base,&current);
  bool scalar=identity&&contextRead(opaque,read,base,current.actor,foreground,&out->context);
  bool afterRead=scalar&&rigIdentitySnapshot(opaque,read,base,&after);
  const HostRig *receipt=out->coherent?&observed:matrixRace?&race:NULL;
  out->same=afterRead&&rigSameIdentity(&current,&after)&&receipt&&rigSameIdentity(receipt,&current);
  if(receipt)out->receipt=*receipt;else memset(&out->receipt,0,sizeof(out->receipt));
  uint64_t now=clock(opaque);out->elapsedUs=now>=start?now-start:UINT64_MAX;
  if(out->same&&out->coherent)return true;
  // Unknown/native contexts immediately retain the existing yield behavior.
  bool allowed=scalar&&sr1RetargetContextAllowed(&out->context);
#ifdef SR1_NATIVE_JUMP_POSE
  allowed=allowed||(scalar&&sr1RetargetJumpContextAllowed(&out->context));
#endif
  if(!allowed||!afterRead||!rigSameResource(&current,&after))break;
  if(pinned&&!rigSameResource(&first,&current))break;
  if(!pinned){first=current;pinned=true;}
  // A rejected pair supplies no usable matrices. A retry can only succeed
  // with two new identical snapshots plus the current context/identity check.
  if(receipt&&!rigSameResource(receipt,&current))break;
  if(!out->coherent&&out->reason!=14)break;
  if(out->elapsedUs>=(uint64_t)policy->startBudgetUs||attempt+1>=(unsigned)policy->maxAttempts)break;
  out->retries++;
 }
 return out->same&&out->coherent;
}
