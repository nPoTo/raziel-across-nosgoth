// SPDX-License-Identifier: GPL-3.0-or-later
#include <assert.h>
#include <stdio.h>
#include "repeat-jump-advance.h"
int main(void){
 RepeatJumpAdvance s={0};
 assert(!repeatJumpAdvanceStep(&s,1000,1,true,0,false,0x1008,0x1d,true));
 assert(!repeatJumpAdvanceStep(&s,1000,1,true,0,true,0x1020,0x29,true));
 assert(!repeatJumpAdvanceStep(&s,1000,1,true,0,true,0x1008,0x29,true));
 assert(!repeatJumpAdvanceStep(&s,1000,1,true,0,true,0x1008,0x1d,false));
 assert(repeatJumpAdvanceStep(&s,1000,1,true,0,true,0x1008,0x1d,true));
 assert(!repeatJumpAdvanceStep(&s,1010,1,true,0,true,0x1008,0x1d,true));
 assert(repeatJumpAdvanceStep(&s,1050,1,true,1,false,8,0x1a,true));
 assert(!repeatJumpAdvanceStep(&s,1060,1,true,1,false,8,0x1a,true));
 assert(!repeatJumpAdvanceStep(&s,1400,1,true,1,false,8,0x1a,true)&&!s.waiting);
 assert(repeatJumpAdvanceStep(&s,1500,1,true,0,true,0x1010,0x25,true));
 assert(!repeatJumpAdvanceStep(&s,1510,2,true,1,false,0x10,0x22,true)&&!s.waiting);
 assert(repeatJumpAdvanceStep(&s,1600,1,true,0,true,0x1010,0x25,true));
 assert(!repeatJumpAdvanceStep(&s,1610,1,false,1,false,0x10,0x22,true)&&!s.waiting);
 puts("repeat jump completion: pending-only, ordinary clips, empty queues, one event per phase, expiry/identity/lease cancellation PASS");return 0;
}
