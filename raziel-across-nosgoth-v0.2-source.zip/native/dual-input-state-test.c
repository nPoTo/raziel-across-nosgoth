// SPDX-License-Identifier: GPL-3.0-or-later
#include <assert.h>
#include <stdio.h>
#include "dual-input-state.h"
int main(void){
 DualInputConsumer c={0};DualInputSample s={.session=19,.sequence=1,.tick=1000,.valid=true};
 assert(dualInputConsume(&c,&s,1000,19,150,true).active);
 s.held=3;s.sequence++;s.tick=1033;DualInputResult r=dualInputConsume(&c,&s,1033,19,150,true);assert(r.pressed==3&&r.held==3);
 // Observed 30Hz source / 240Hz receiver: re-reading one packet never repeats an edge.
 for(unsigned i=1;i<8;i++){r=dualInputConsume(&c,&s,1033+4*i,19,150,true);assert(!r.pressed&&r.held==3);}
 s.held=0;s.sequence++;s.tick=1066;r=dualInputConsume(&c,&s,1066,19,150,true);assert(r.released==3);
 s.held=4;s.sequence++;s.tick=1100;assert(dualInputConsume(&c,&s,1100,19,150,true).pressed==4);
 r=dualInputConsume(&c,&s,1251,19,150,true);assert(!r.active&&r.released==4);
 s.sequence++;s.tick=1260;r=dualInputConsume(&c,&s,1260,19,150,true);assert(!r.held&&!r.pressed);
 s.held=0;s.sequence++;s.tick++;dualInputConsume(&c,&s,s.tick,19,150,true);
 s.held=4;s.sequence++;s.tick++;assert(dualInputConsume(&c,&s,s.tick,19,150,true).pressed==4);
 r=dualInputConsume(&c,&s,s.tick,19,150,false);assert(r.released==4&&!r.active);
 // Bad session, future timestamps and backwards sequence cannot produce input.
 assert(!dualInputConsume(&c,&s,s.tick,20,150,true).active);
 assert(!dualInputConsume(&c,&s,s.tick-1,19,150,true).active);
 s.held=0;dualInputConsume(&c,&s,s.tick,19,150,true);s.sequence--;assert(!dualInputConsume(&c,&s,s.tick,19,150,true).active);
 s.sequence+=2;s.tick++;s.x=10000;assert(!dualInputConsume(&c,&s,s.tick,19,150,true).x);
 s.sequence++;s.tick++;assert(!dualInputConsume(&c,&s,s.tick,19,150,true).x);
 s.sequence++;s.tick++;s.x=0;dualInputConsume(&c,&s,s.tick,19,150,true);
 s.sequence++;s.tick++;s.x=10000;assert(dualInputConsume(&c,&s,s.tick,19,150,true).x==10000);
 s.held=1;assert(!dualInputConsume(&c,&s,s.tick,19,150,true).active); // Mutated duplicate packet.
 // Every pair of keyboard/controller held masks merges without double edges.
 for(unsigned k=0;k<256;k++)for(unsigned p=0;p<256;p++){
  c=(DualInputConsumer){0};s=(DualInputSample){.session=19,.sequence=1,.tick=1,.valid=true};dualInputConsume(&c,&s,1,19,150,true);
  s.sequence++;s.tick++;s.held=k|p;r=dualInputConsume(&c,&s,2,19,150,true);assert(r.pressed==(k|p));
  s.sequence++;s.tick++;s.held=p;r=dualInputConsume(&c,&s,3,19,150,true);assert(!r.pressed&&r.released==(k&~p));
 }
 puts("PASS 30/240Hz held-state replication, single press, expiry/focus/session release, 65536 device-mask pairs; native integration pending");return 0;
}
