#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <stdint.h>
#include <stdbool.h>
#include <stdio.h>
#include <string.h>
#include <math.h>
#include "MinHook.h"
#define PROBE_REPORT_DIR L"."
static uintptr_t fixturePlayer,fixtureObject=0x12345678,swapPlayer;static unsigned calls,writeCalls,failWrite;
static float fixtureFactor=.125f,fixtureRoot[16];static unsigned fixtureCallbacks;
static bool worldRead(uintptr_t at,void *out,size_t size){
 if(at==0x10000000+0xc5aa78&&size==8){memcpy(out,&fixturePlayer,8);return true;}
 if(at==0x10000000+0xc5abbc&&size==4){memcpy(out,&fixtureFactor,4);return true;}
 if(at<0x100000000)return false;memcpy(out,(void *)at,size);return true;
}
static bool hashBytes(const void *p,ULONG n,char *out){(void)p;(void)n;(void)out;return false;}
static void logLine(const char *fmt,...){(void)fmt;}
#include "donor-process-probe.h"
static BOOL mockWrite(HANDLE process,LPVOID at,LPCVOID from,SIZE_T size,SIZE_T *written){
 (void)process;++writeCalls;if(writeCalls==failWrite){*written=0;return FALSE;}
 uintptr_t a=(uintptr_t)at;if(size!=8||(a!=fixturePlayer+0x20&&a!=fixturePlayer+0x30)){*written=0;return FALSE;}
 memcpy(at,from,size);*written=size;return TRUE;
}
#define WriteProcessMemory mockWrite
#include "donor-anchor.h"
#undef WriteProcessMemory
static uintptr_t __fastcall mockProcess(uintptr_t instance,uintptr_t tracker){(void)instance;(void)tracker;return 0xabc;}
static uintptr_t __fastcall mockFrame(void){
 ++calls;float *p=(float *)(fixturePlayer+0x20),*old=(float *)(fixturePlayer+0x30);
 memcpy(old,p,12);p[0]+=30;p[1]-=15;p[2]+=20;if(swapPlayer)fixturePlayer=swapPlayer;
 for(unsigned k=0;k<fixtureCallbacks;k++)observeDonorProcess(fixturePlayer,donorProcessBase+0xc5aa50);
 return 0xfedcba;
}
#define CHECK(x) do{if(!(x)){printf("FAIL line %d\n",__LINE__);return 1;}}while(0)
static void setup(unsigned char *instance){
 memset(instance,0,1024);fixturePlayer=(uintptr_t)instance;memcpy(instance+0x88,&fixtureObject,8);
 float p[3]={10,20,0};memcpy(instance+0x20,p,12);memcpy(instance+0x30,p,12);
 donorProcessBase=0x10000000;donorRazielObject=(PVOID)fixtureObject;originalDonorFrame=mockFrame;
 donorAnchor=(DonorAnchor){0};donorAnchorEnabled=0;donorAnchorReset=0;donorAnchorHead=donorAnchorTail=0;
 calls=writeCalls=failWrite=0;swapPlayer=0;donorAnchorBegin=GetTickCount64();
 donorProcessEnabled=0;donorProcessHead=donorProcessTail=donorProcessRecords=0;donorProcessBegin=0;
 fixtureCallbacks=0;fixtureFactor=.125f;originalDonorProcess=mockProcess;memset(&donorFrameMotion,0,sizeof(donorFrameMotion));
 memset(fixtureRoot,0,sizeof(fixtureRoot));fixtureRoot[0]=fixtureRoot[5]=fixtureRoot[10]=fixtureRoot[15]=1;
 uintptr_t root=(uintptr_t)fixtureRoot;memcpy(instance+0x70,&root,8);
}
int main(void){
 unsigned char instance[1024],other[1024];setup(instance);
 CHECK(anchorDonorFrame()==0xfedcba&&calls==1&&writeCalls==0&&*(float *)(instance+0x20)==40);
 setup(instance);donorAnchorEnabled=1;donorAnchorReset=1;
 CHECK(anchorDonorFrame()==0xfedcba&&calls==1&&donorAnchor.ready&&!donorAnchor.failed);
 float *p=(float *)(instance+0x20),*old=(float *)(instance+0x30);
 CHECK(p[0]==10&&p[1]==20&&p[2]==20&&old[0]==10&&old[1]==20&&old[2]==0&&donorAnchor.writes==2);
 CHECK(anchorDonorFrame()==0xfedcba&&p[0]==10&&p[1]==20&&p[2]==40&&old[2]==20&&calls==2);
 donorAnchorEnabled=0;CHECK(anchorDonorFrame()==0xfedcba&&p[0]==40&&p[1]==5&&p[2]==60&&calls==3);
 setup(instance);donorAnchorEnabled=1;donorAnchorBegin=GetTickCount64()-75001;anchorDonorFrame();CHECK(!donorAnchor.ready&&writeCalls==0&&calls==1);
 setup(instance);donorAnchorEnabled=1;donorRazielObject=NULL;anchorDonorFrame();CHECK(donorAnchor.failed&&writeCalls==0&&calls==1);
 setup(instance);donorAnchorEnabled=1;anchorDonorFrame();unsigned writes=writeCalls;p[0]=300;anchorDonorFrame();CHECK(donorAnchor.failed&&writeCalls==writes&&p[0]==330&&calls==2);
 setup(instance);float xy[2]={8,9},saved[3],savedOld[3];memcpy(saved,p,12);memcpy(savedOld,old,12);failWrite=2;
 CHECK(!donorAnchorWrite(fixturePlayer,xy)&&!memcmp(saved,p,12)&&!memcmp(savedOld,old,12)&&writeCalls==4);
 setup(instance);donorAnchorEnabled=1;memset(other,0,sizeof(other));memcpy(other+0x88,&fixtureObject,8);swapPlayer=(uintptr_t)other;
 CHECK(anchorDonorFrame()==0xfedcba&&donorAnchor.failed&&calls==1&&writeCalls==2&&*(float *)(other+0x20)==0);
 setup(instance);p[2]=NAN;donorAnchorEnabled=1;anchorDonorFrame();CHECK(donorAnchor.failed&&writeCalls==0&&calls==1);
 setup(instance);p[2]=5;donorAnchorEnabled=1;anchorDonorFrame();CHECK(!donorAnchor.ready&&writeCalls==0&&calls==1);
 // Animation moved before the callback: its delta is zero, while enclosing
 // frame observation must retain the full step, before the unchanged XY pin.
 setup(instance);donorAnchorEnabled=donorProcessEnabled=1;fixtureCallbacks=1;
 CHECK(anchorDonorFrame()==0xfedcba&&calls==1&&!donorAnchor.failed);
 CHECK(donorProcessQueue[0].after[0]==donorProcessQueue[0].before[0]);
 CHECK(donorAnchorQueue[1].motionValid&&donorAnchorQueue[1].factor==.125f&&donorAnchorQueue[1].root[0]==1);
 CHECK(donorAnchorQueue[1].current[0]-donorAnchorQueue[1].anchor[0]==30&&donorAnchorQueue[1].current[1]-donorAnchorQueue[1].anchor[1]==-15);
 CHECK(p[0]==10&&p[1]==20&&p[2]==20&&!donorFrameMotion.wanted);
 setup(instance);donorAnchorEnabled=donorProcessEnabled=1;fixtureCallbacks=2;anchorDonorFrame();CHECK(!donorAnchorQueue[1].motionValid&&calls==1&&writeCalls==4);
 setup(instance);donorAnchorEnabled=donorProcessEnabled=1;fixtureCallbacks=1;fixtureFactor=NAN;anchorDonorFrame();CHECK(!donorAnchorQueue[1].motionValid&&!donorAnchor.failed);
 setup(instance);donorAnchorEnabled=1;fixtureCallbacks=1;anchorDonorFrame();CHECK(!donorAnchorQueue[1].motionValid);
 setup(instance);donorAnchorEnabled=donorProcessEnabled=1;fixtureCallbacks=1;donorAnchor.events=40000;anchorDonorFrame();CHECK(donorAnchorHead==0&&calls==1&&writeCalls==4);
 donorAnchorStop();donorAnchorInstall(NULL);donorAnchorTick();donorProcessStop();donorProcessInstall(NULL);donorProcessTick();
 CHECK(!donorAnchorEnabled);
 puts("Donor anchor: original forwarding, XY pin/Z unchanged, scoped whole-frame step/factor before pin, ambiguous/invalid/disabled metadata rejection, bounded queue, expiry/identity/teleport and rollback PASS");return 0;
}
