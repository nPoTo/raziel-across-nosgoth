// Generated from exact local SRM; covers visually identified in offline previews.
#define COVER_INDEX_SHA "86e3c3d60a97fbd72c433394438128f9d8de4a420711936e2dc73f6e466a3fff"
typedef struct {uint32_t offset,count;} CoverRange;
static unsigned coverRanges(bool verified,bool open,CoverRange out[3]){
 if(!verified)return 0;out[0]=(CoverRange){0,1872};out[1]=(CoverRange){open?1872:7830,5958};out[2]=(CoverRange){13788,112002};return 3;
}
