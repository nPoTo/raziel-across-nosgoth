// SPDX-License-Identifier: GPL-3.0-or-later
// Pure coordinator. No native calls, allocation, locks, or callback side effects.
// Caller supplies validated observations and acknowledges actual owned cleanup.
#ifndef BRIDGE_SESSION_H
#define BRIDGE_SESSION_H
#include "bridge-protocol.h"
typedef enum {
 BRIDGE_DISCOVERING,BRIDGE_VALIDATING,BRIDGE_WAITING,BRIDGE_READY,
 BRIDGE_ACTIVE,BRIDGE_PAUSED,BRIDGE_TRANSITIONING,BRIDGE_RECOVERING,
 BRIDGE_STOPPING,BRIDGE_DISABLED
} BridgeSessionState;
enum {BRIDGE_OWN_BODY=1,BRIDGE_OWN_INPUT=2,BRIDGE_OWN_CAMERA=4,
 BRIDGE_OWN_TRANSPORT=8,BRIDGE_OWN_HELPERS=16,BRIDGE_OWN_ALL=31};
typedef struct {
 bool hostAlive,donorAlive,identified,contractValid,unsupported;
 bool actorReady,paused,loading,lockBusy,abandoned,activate,stop;
 uint64_t now,heartbeat;
 BridgeIdentity identity;
 uint32_t requestedOwnership;
} BridgeSessionObservation;
typedef struct {
 BridgeSessionState state;
 BridgeIdentity identity;
 bool hasIdentity,hasTick;
 uint64_t lastNow;
 uint32_t owned,desired;
} BridgeSession;
typedef struct {BridgeSessionState state;uint32_t release,acquire;} BridgeSessionEffects;
static inline void bridgeSessionBegin(BridgeSession *s){memset(s,0,sizeof(*s));s->state=BRIDGE_DISCOVERING;}
// Changes acknowledged ownership only after the adapter has completed operations.
// Release must precede acquisition. Never acknowledge ownership of unrelated state.
static inline bool bridgeSessionAcknowledge(BridgeSession *s,uint32_t released,uint32_t acquired){
 if(!s||((released|acquired)&~BRIDGE_OWN_ALL)||(released&~s->owned)||(acquired&~s->desired))return false;
 uint32_t remaining=s->owned&~released;
 if(acquired&&(remaining&~s->desired))return false;
 s->owned=remaining|acquired;return true;
}
static inline BridgeSessionEffects bridgeSessionStep(BridgeSession *s,const BridgeSessionObservation *o){
 bool context=o->identified&&o->contractValid&&bridgeIdentityValid(&o->identity);
 bool changed=s->hasIdentity&&context&&!bridgeSameIdentity(&s->identity,&o->identity);
 bool fresh=o->heartbeat&&o->heartbeat<=o->now&&o->now-o->heartbeat<=(uint64_t)sheet_bridgeProtocol_session_v2.maxAgeMs;
 bool badClock=s->hasTick&&o->now<s->lastNow;
 uint32_t allowed=BRIDGE_OWN_TRANSPORT|BRIDGE_OWN_HELPERS;
 if(o->identity.capabilities&BRIDGE_COVER)allowed|=BRIDGE_OWN_BODY;
 if(o->identity.capabilities&(BRIDGE_GROUND|BRIDGE_AIR_HINT))allowed|=BRIDGE_OWN_INPUT;
 // Camera authority has no negotiated capability in this version.
 bool invalid=(o->requestedOwnership&~allowed)||badClock;
 bool fault=o->abandoned||!o->hostAlive||!o->donorAlive;
 if(!badClock){s->lastNow=o->now;s->hasTick=true;}
 if(s->state!=BRIDGE_DISABLED&&s->state!=BRIDGE_STOPPING&&o->stop)s->state=BRIDGE_STOPPING;
 else if(s->state!=BRIDGE_STOPPING&&s->state!=BRIDGE_DISABLED&&(o->unsupported||invalid))s->state=BRIDGE_DISABLED;
 else switch(s->state){
  case BRIDGE_DISCOVERING:
   if(!fault&&o->identified)s->state=BRIDGE_VALIDATING;
   break;
  case BRIDGE_VALIDATING:
   if(fault)s->state=BRIDGE_RECOVERING;
   else if(context){s->identity=o->identity;s->hasIdentity=true;s->state=BRIDGE_WAITING;}
   break;
  case BRIDGE_WAITING: case BRIDGE_READY: case BRIDGE_ACTIVE: case BRIDGE_PAUSED: case BRIDGE_TRANSITIONING:
   if(fault||!context||changed)s->state=BRIDGE_RECOVERING;
   else if(o->loading||!o->actorReady)s->state=BRIDGE_TRANSITIONING;
   else if(o->paused||o->lockBusy)s->state=BRIDGE_PAUSED;
   else if(!fresh)s->state=BRIDGE_RECOVERING;
   else if(s->owned&~s->desired){ /* Wait for prior cleanup acknowledgment. */ }
   else if(s->state==BRIDGE_ACTIVE||(s->state==BRIDGE_READY&&o->activate))s->state=BRIDGE_ACTIVE;
   else s->state=BRIDGE_READY;
   break;
  case BRIDGE_RECOVERING:
   if(!s->owned){s->hasIdentity=false;s->state=BRIDGE_DISCOVERING;}
   break;
  case BRIDGE_STOPPING:
   if(!s->owned){s->hasIdentity=false;s->state=BRIDGE_DISABLED;}
   break;
  case BRIDGE_DISABLED: break;
 }
 s->desired=s->state==BRIDGE_ACTIVE?o->requestedOwnership:0;
 BridgeSessionEffects effects={s->state,s->owned&~s->desired,0};
 // An adapter cannot obtain new ownership while old effects remain unreleased.
 if(!effects.release)effects.acquire=s->desired&~s->owned;
 return effects;
}
#endif
