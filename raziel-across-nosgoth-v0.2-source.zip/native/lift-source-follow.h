// SPDX-License-Identifier: GPL-3.0-or-later
#pragma once
#include <stdint.h>
#include <stdbool.h>
#include <string.h>
typedef struct {uintptr_t actor;uint64_t last,press,pulseUntil;bool armed,held,fired;} LiftSourceFollow;
static inline uint16_t liftSourceButtons(LiftSourceFollow *s,uint64_t now,uintptr_t actor,bool scope,bool grounded,bool compression,bool donorRise,uint16_t raw,uint16_t delivered){
 if(!scope||!actor){memset(s,0,sizeof(*s));return delivered;}
 if(s->actor!=actor||now<s->last||(s->last&&now-s->last>100)){memset(s,0,sizeof(*s));s->actor=actor;}
 s->last=now;
 if(!(raw&0x8000)){s->armed=true;s->held=false;s->fired=false;s->pulseUntil=0;return delivered;}
 if(!s->armed)return delivered;
 if(!s->held){s->held=true;s->press=now;}
 if(raw&0x1000){s->fired=true;s->pulseUntil=0;return delivered;}
 if(!s->fired&&grounded&&donorRise&&now-s->press<=3000){s->fired=true;s->pulseUntil=now+64;}
 if(s->fired&&s->pulseUntil>now&&(grounded||compression))delivered|=0x1000;
 return delivered;
}
