// SPDX-License-Identifier: GPL-3.0-or-later
#pragma once
#include <stdint.h>
#include <stdbool.h>
#include <string.h>
#include <stdio.h>
#include <windows.h>
#include "host-contact-compression.h"
#include "host-contact-native-pause.h"

#ifdef HOST_LED_HEADING
#define HOST_CONTACT_VERSION 3u
#define HOST_CONTACT_MAX_MS 200000u
#define HOST_CONTACT_MAX_PHASE 4u
#elif defined(GENERAL_FREE_TEST)
#define HOST_CONTACT_VERSION 2u
#define HOST_CONTACT_MAX_MS 200000u
#define HOST_CONTACT_MAX_PHASE 4u
#else
#define HOST_CONTACT_VERSION 1u
#define HOST_CONTACT_MAX_MS 60000u
#define HOST_CONTACT_MAX_PHASE 3u
#endif

#define HOST_CONTACT_MAGIC 0x31435748u
// phase: 0 unknown, 1 completed ground, 2 completed air, 3 proved compression.
// Compression does not assert a contact. No process pointers may be dereferenced by the peer.
typedef struct {
 uint32_t magic,version,pid,phase;
 uint64_t creation,epoch,tick,sequence,actor;
 uint32_t control,coherent;
 uint64_t callbacks[3];
 int32_t verticalVelocity;
 uint32_t reserved;
#ifdef HOST_LED_HEADING
 float headingTurns;
 uint32_t headingValid;
#endif
} HostContactSnapshot;
typedef struct {volatile LONG guard,revoked;HostContactSnapshot value;} HostContactShared;
#ifdef HOST_LED_HEADING
_Static_assert(sizeof(HostContactSnapshot)==104,"Heading contact wire layout changed");
_Static_assert(sizeof(HostContactShared)==112,"Heading contact mapping layout changed");
static inline void hostContactMappingName(wchar_t name[96],DWORD pid){_snwprintf(name,96,L"Local\\LOKHostContact-v3-%lu",pid);}
#else
_Static_assert(sizeof(HostContactSnapshot)==96,"Host contact wire layout changed");
_Static_assert(sizeof(HostContactShared)==104,"Host contact mapping layout changed");
static inline void hostContactMappingName(wchar_t name[96],DWORD pid){_snwprintf(name,96,L"Local\\LOKHostContact-v1-%lu",pid);}
#endif
// Caller serializes writers; readers never acquire a lock in the game thread.
static inline void hostContactStore(HostContactShared *m,const HostContactSnapshot *s){
 InterlockedIncrement(&m->guard);MemoryBarrier();memcpy(&m->value,s,sizeof(*s));MemoryBarrier();InterlockedIncrement(&m->guard);
}
static inline bool hostContactCopy(const HostContactShared *m,HostContactSnapshot *s){
 if(!m||!s||m->revoked)return false;
 for(unsigned i=0;i<3;i++){LONG g=m->guard;if(g&1)continue;MemoryBarrier();memcpy(s,&m->value,sizeof(*s));MemoryBarrier();if(g==m->guard&&!m->revoked)return true;}
 return false;
}
typedef struct {uint32_t pid;uint64_t creation,epoch,actor;HostContactSnapshot last;bool seen,revoked;} HostContactLease;
static inline bool hostContactAccept(HostContactLease *l,const HostContactSnapshot *s,uint64_t now,bool processAlive,bool *fresh){
 if(fresh)*fresh=false;
 if(!l||!s||!fresh||l->revoked)return false;
 // A suspended native action does not project a floor or air contact. Only
 // that already admitted suspension tolerates the measured 187ms bars gap.
 const unsigned ageLimit=HOST_CONTACT_MAX_PHASE==4&&l->seen&&l->last.phase==4&&s->phase==4?250u:150u;
 bool ok=processAlive&&l->pid&&l->creation&&l->epoch&&l->actor&&s->magic==HOST_CONTACT_MAGIC&&s->version==HOST_CONTACT_VERSION&&
  s->pid==l->pid&&s->creation==l->creation&&s->epoch==l->epoch&&s->actor==l->actor&&s->sequence&&
  s->epoch<=s->tick&&s->tick<=now&&now-s->tick<=ageLimit&&s->tick-s->epoch<=HOST_CONTACT_MAX_MS&&s->coherent==1&&!s->reserved&&s->phase>=1&&s->phase<=HOST_CONTACT_MAX_PHASE&&
  (!(s->control&0x4000000)||(HOST_CONTACT_MAX_PHASE==4&&s->phase==4&&hostContactNativeHangControl(s->control,s->callbacks)));
 if(ok&&s->phase==1)ok=(s->control&8)!=0;
 if(ok&&s->phase==2&&!(s->control&8))ok=(s->control==0x511||s->control==0x515)&&s->callbacks[0]==0xf2ae0&&s->callbacks[1]==0xf2ae0&&s->callbacks[2]==0xf2ae0;
 if(ok&&s->phase==3)ok=hostContactCompression(s->control,s->callbacks);
 if(ok&&s->phase==4)ok=hostContactNativePause(s->callbacks);
 if(ok&&l->seen){
  ok=s->sequence>=l->last.sequence&&s->tick>=l->last.tick;
  if(ok&&s->sequence==l->last.sequence){ok=!memcmp(s,&l->last,sizeof(*s));if(ok)return true;}
 }
 if(!ok){l->revoked=true;return false;}
 l->last=*s;l->seen=true;*fresh=true;return true;
}
