// SPDX-License-Identifier: GPL-3.0-or-later
#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <stdio.h>
#include "donor-control-query-reader.h"
static const uintptr_t base=0x10000000,actor=0x20000000,state=0x30000000;
static unsigned roots,states,keyReads,padReads;static int defect;
static bool readFixture(void *c,uintptr_t a,void *out,SIZE_T n){(void)c;uintptr_t v=0;
 if(defect==1)return false;
 if(a==base+0xc655a0&&n==8)v=base+(defect==5?0x19b158:0x19b150);
 else if(a==base+0xc5aa78&&n==8){v=actor;if(defect==2&&++roots>1)v+=8;}
 else if(a==actor+0x3f8&&n==8){v=state;if(defect==3&&++states>1)v+=8;}
 else if(a==base+0x10aa820+0x45*12&&n==8){uint32_t keys[2]={0x4000001,0xf0000002};if(defect==4&&++keyReads>1)keys[0]++;memcpy(out,keys,8);return true;}
 else if(a==base+0x10aa820+0x45*12+8&&n==1){uint8_t pad=3;if(defect==8&&++padReads>1)pad++;memcpy(out,&pad,1);return true;}
 else for(unsigned i=0;i<3;i++)if(a==state+i*0x250&&n==32){unsigned char data[32]={0};uintptr_t owner=defect==7?actor+8:actor,first=base+(defect==6?0x1090f0:0x117e30),second=base+0x117f10;memcpy(data,&owner,8);memcpy(data+16,&first,8);memcpy(data+24,&second,8);memcpy(out,data,32);return true;}
 if(!v)return false;memcpy(out,&v,n);return true;
}
static bool codeFixture(void *c,uintptr_t a,uintptr_t b){(void)c;return defect!=9&&b==base&&a>=base&&a<base+0x2000000;}
static bool inspect(DonorControlQueryMetadata *m){roots=states=keyReads=padReads=0;return donorControlQueryRead(NULL,readFixture,codeFixture,base,0x2000000,actor,0x45,m);}
#define CHECK(c,n) do{if(!(c)){printf("FAIL %u\n",(unsigned)n);return n;}}while(0)
int main(void){DonorControlQueryMetadata m;CHECK(inspect(&m)&&m.opaqueActor==actor&&m.opaqueState==state&&m.primaryRva==0x117e30&&m.key1==0x4000001&&m.key2==0xf0000002&&m.pad==3,1);for(defect=1;defect<=9;defect++)CHECK(!inspect(&m),defect+1);defect=0;
 CHECK(!donorControlQueryRead(NULL,readFixture,codeFixture,base,0x2000000,actor,45,&m),11);CHECK(!donorControlQueryRead(NULL,readFixture,codeFixture,base,0x2000000,actor+1,0x45,&m),12);CHECK(!donorControlQueryRead(NULL,readFixture,codeFixture,base,0x2000000,UINTPTR_MAX-7,0x45,&m),13);CHECK(!donorControlQueryRead(NULL,readFixture,codeFixture,base,0x1000,actor,0x45,&m),14);
 puts("PASS: exact logical69/73 reader, two keyboard bindings/native pad code, mapper/state/actor/binding races, wrong actor/state/type/code/alignment/overflow and decimal45 confusion refusal");return 0;}
