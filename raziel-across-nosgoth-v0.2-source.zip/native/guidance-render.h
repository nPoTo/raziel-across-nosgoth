// SPDX-License-Identifier: GPL-3.0-or-later
#pragma once
#include <GL/gl.h>
#include <GL/glext.h>
#include "guidance-text.h"
#define GUIDANCE_GL(X) \
 X(PFNGLCREATESHADERPROC,CreateShader) X(PFNGLSHADERSOURCEPROC,ShaderSource) X(PFNGLCOMPILESHADERPROC,CompileShader) X(PFNGLGETSHADERIVPROC,GetShaderiv) X(PFNGLDELETESHADERPROC,DeleteShader) \
 X(PFNGLCREATEPROGRAMPROC,CreateProgram) X(PFNGLATTACHSHADERPROC,AttachShader) X(PFNGLLINKPROGRAMPROC,LinkProgram) X(PFNGLGETPROGRAMIVPROC,GetProgramiv) X(PFNGLUSEPROGRAMPROC,UseProgram) X(PFNGLDELETEPROGRAMPROC,DeleteProgram) \
 X(PFNGLGETUNIFORMLOCATIONPROC,GetUniformLocation) X(PFNGLUNIFORM1IPROC,Uniform1i) X(PFNGLUNIFORM4FPROC,Uniform4f) X(PFNGLGENVERTEXARRAYSPROC,GenVertexArrays) X(PFNGLBINDVERTEXARRAYPROC,BindVertexArray) \
 X(PFNGLACTIVETEXTUREPROC,ActiveTexture) X(PFNGLBINDBUFFERPROC,BindBuffer) X(PFNGLBINDSAMPLERPROC,BindSampler) X(PFNGLGETINTEGERI_VPROC,GetIntegeri_v) X(PFNGLISENABLEDIPROC,IsEnabledi) X(PFNGLENABLEIPROC,Enablei) X(PFNGLDISABLEIPROC,Disablei) X(PFNGLCOLORMASKIPROC,ColorMaski)
#define GUIDANCE_DECLARE(type,name) static type gh##name;
GUIDANCE_GL(GUIDANCE_DECLARE)
#undef GUIDANCE_DECLARE
typedef struct{
 GLint program,vao,active,texture0,sampler0,unpack,unpackState[6],polygon[2];
 GLboolean blend,depth,stencil,cull,scissor,discard,logic,mask[4],clip[8],coverage,alphaCoverage,alphaOne,sampleMask;
} GuidanceGLState;
static HGLRC guidanceRenderContext,guidanceFailedContext;
static GLuint guidanceProgram,guidanceVao,guidanceTexture;
static unsigned guidanceRenderedPlan,guidanceRenderedSecond=UINT32_MAX;
static bool guidanceLoadGL(void){
#define GUIDANCE_LOAD(type,name) do{PROC p=wglGetProcAddress("gl" #name);if(!p||(uintptr_t)p<=3||(uintptr_t)p==UINTPTR_MAX)return false;gh##name=(type)p;}while(0);
 GUIDANCE_GL(GUIDANCE_LOAD)
#undef GUIDANCE_LOAD
 return true;
}
static void guidanceSaveGL(GuidanceGLState *s){
 glGetIntegerv(GL_CURRENT_PROGRAM,&s->program);glGetIntegerv(GL_VERTEX_ARRAY_BINDING,&s->vao);glGetIntegerv(GL_ACTIVE_TEXTURE,&s->active);
 ghActiveTexture(GL_TEXTURE0);glGetIntegerv(GL_TEXTURE_BINDING_2D,&s->texture0);ghActiveTexture((GLenum)s->active);ghGetIntegeri_v(GL_SAMPLER_BINDING,0,&s->sampler0);
 glGetIntegerv(GL_PIXEL_UNPACK_BUFFER_BINDING,&s->unpack);const GLenum names[]={GL_UNPACK_ALIGNMENT,GL_UNPACK_ROW_LENGTH,GL_UNPACK_SKIP_ROWS,GL_UNPACK_SKIP_PIXELS,GL_UNPACK_SWAP_BYTES,GL_UNPACK_LSB_FIRST};
 for(unsigned i=0;i<6;i++)glGetIntegerv(names[i],&s->unpackState[i]);
 glGetIntegerv(GL_POLYGON_MODE,s->polygon);s->blend=ghIsEnabledi(GL_BLEND,0);s->depth=glIsEnabled(GL_DEPTH_TEST);s->stencil=glIsEnabled(GL_STENCIL_TEST);s->cull=glIsEnabled(GL_CULL_FACE);s->scissor=glIsEnabled(GL_SCISSOR_TEST);s->discard=glIsEnabled(GL_RASTERIZER_DISCARD);s->logic=glIsEnabled(GL_COLOR_LOGIC_OP);glGetBooleanv(GL_COLOR_WRITEMASK,s->mask);
 for(unsigned i=0;i<8;i++)s->clip[i]=glIsEnabled(GL_CLIP_DISTANCE0+i);s->coverage=glIsEnabled(GL_SAMPLE_COVERAGE);s->alphaCoverage=glIsEnabled(GL_SAMPLE_ALPHA_TO_COVERAGE);s->alphaOne=glIsEnabled(GL_SAMPLE_ALPHA_TO_ONE);s->sampleMask=glIsEnabled(GL_SAMPLE_MASK);
}
static void guidanceToggle(GLenum name,GLboolean value){if(value)glEnable(name);else glDisable(name);}
static void guidanceRestoreGL(const GuidanceGLState *s){
 ghUseProgram((GLuint)s->program);ghBindVertexArray((GLuint)s->vao);ghActiveTexture(GL_TEXTURE0);glBindTexture(GL_TEXTURE_2D,(GLuint)s->texture0);ghBindSampler(0,(GLuint)s->sampler0);ghActiveTexture((GLenum)s->active);ghBindBuffer(GL_PIXEL_UNPACK_BUFFER,(GLuint)s->unpack);
 const GLenum names[]={GL_UNPACK_ALIGNMENT,GL_UNPACK_ROW_LENGTH,GL_UNPACK_SKIP_ROWS,GL_UNPACK_SKIP_PIXELS,GL_UNPACK_SWAP_BYTES,GL_UNPACK_LSB_FIRST};for(unsigned i=0;i<6;i++)glPixelStorei(names[i],s->unpackState[i]);
 glPolygonMode(GL_FRONT_AND_BACK,(GLenum)s->polygon[0]);if(s->polygon[0]!=s->polygon[1])glPolygonMode(GL_BACK,(GLenum)s->polygon[1]);
 if(s->blend)ghEnablei(GL_BLEND,0);else ghDisablei(GL_BLEND,0);guidanceToggle(GL_DEPTH_TEST,s->depth);guidanceToggle(GL_STENCIL_TEST,s->stencil);guidanceToggle(GL_CULL_FACE,s->cull);guidanceToggle(GL_SCISSOR_TEST,s->scissor);guidanceToggle(GL_RASTERIZER_DISCARD,s->discard);guidanceToggle(GL_COLOR_LOGIC_OP,s->logic);ghColorMaski(0,s->mask[0],s->mask[1],s->mask[2],s->mask[3]);
 for(unsigned i=0;i<8;i++)guidanceToggle(GL_CLIP_DISTANCE0+i,s->clip[i]);guidanceToggle(GL_SAMPLE_COVERAGE,s->coverage);guidanceToggle(GL_SAMPLE_ALPHA_TO_COVERAGE,s->alphaCoverage);guidanceToggle(GL_SAMPLE_ALPHA_TO_ONE,s->alphaOne);guidanceToggle(GL_SAMPLE_MASK,s->sampleMask);
}
static GLuint guidanceShader(GLenum type,const char *text){GLuint shader=ghCreateShader(type);ghShaderSource(shader,1,&text,NULL);ghCompileShader(shader);GLint ok=0;ghGetShaderiv(shader,GL_COMPILE_STATUS,&ok);if(!ok){ghDeleteShader(shader);return 0;}return shader;}
static bool guidanceInitRender(void){
 const char *vs="#version 330 core\nuniform vec4 bounds;out vec2 uv;void main(){vec2 p[6]=vec2[6](vec2(0,0),vec2(1,0),vec2(0,1),vec2(0,1),vec2(1,0),vec2(1,1));uv=p[gl_VertexID];gl_Position=vec4(bounds.x+uv.x*bounds.z,bounds.y-uv.y*bounds.w,0,1);}";
 const char *fs="#version 330 core\nuniform sampler2D glyphs;in vec2 uv;out vec4 color;void main(){vec4 glyph=texture(glyphs,uv);if(glyph.a<0.5)discard;color=vec4(1.0);}";
 GLuint vertex=guidanceShader(GL_VERTEX_SHADER,vs),fragment=guidanceShader(GL_FRAGMENT_SHADER,fs);if(!vertex||!fragment){if(vertex)ghDeleteShader(vertex);if(fragment)ghDeleteShader(fragment);return false;}
 guidanceProgram=ghCreateProgram();ghAttachShader(guidanceProgram,vertex);ghAttachShader(guidanceProgram,fragment);ghLinkProgram(guidanceProgram);ghDeleteShader(vertex);ghDeleteShader(fragment);GLint ok=0;ghGetProgramiv(guidanceProgram,GL_LINK_STATUS,&ok);if(!ok){ghDeleteProgram(guidanceProgram);guidanceProgram=0;return false;}
 int width=(int)sheet_guidanceRenderPolicy_native.rasterWidth,height=(int)sheet_guidanceRenderPolicy_native.rasterHeight;
 if(!guidanceInitText()){ghDeleteProgram(guidanceProgram);guidanceProgram=0;return false;}
 ghGenVertexArrays(1,&guidanceVao);glGenTextures(1,&guidanceTexture);glBindTexture(GL_TEXTURE_2D,guidanceTexture);glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MIN_FILTER,GL_LINEAR);glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MAG_FILTER,GL_LINEAR);glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_WRAP_S,GL_CLAMP_TO_EDGE);glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_WRAP_T,GL_CLAMP_TO_EDGE);glTexImage2D(GL_TEXTURE_2D,0,GL_RGBA8,width,height,0,GL_BGRA,GL_UNSIGNED_BYTE,NULL);return true;
}
static bool guidanceRender(HGLRC context,unsigned plan,unsigned elapsed){
 const TutorialStage *stage=guidanceStageAt(plan,elapsed);unsigned seconds=guidanceSeconds(plan);if(!context||!stage||elapsed>=seconds||context==guidanceFailedContext||(guidanceRenderContext&&context!=guidanceRenderContext))return false;
 GLint fbo=0,viewport[4]={0};glGetIntegerv(GL_DRAW_FRAMEBUFFER_BINDING,&fbo);glGetIntegerv(GL_VIEWPORT,viewport);if(fbo||viewport[2]<320||viewport[3]<240)return false;
 if(!guidanceRenderContext&&!guidanceLoadGL()){guidanceFailedContext=context;return false;}
 GuidanceGLState saved={0};guidanceSaveGL(&saved);ghActiveTexture(GL_TEXTURE0);ghBindSampler(0,0);ghBindBuffer(GL_PIXEL_UNPACK_BUFFER,0);
 glPixelStorei(GL_UNPACK_ALIGNMENT,4);glPixelStorei(GL_UNPACK_ROW_LENGTH,0);glPixelStorei(GL_UNPACK_SKIP_ROWS,0);glPixelStorei(GL_UNPACK_SKIP_PIXELS,0);glPixelStorei(GL_UNPACK_SWAP_BYTES,0);glPixelStorei(GL_UNPACK_LSB_FIRST,0);
 if(!guidanceRenderContext){if(!guidanceInitRender()){guidanceFailedContext=context;guidanceRestoreGL(&saved);return false;}guidanceRenderContext=context;}
 glBindTexture(GL_TEXTURE_2D,guidanceTexture);
 if(guidanceRenderedPlan!=plan||guidanceRenderedSecond!=elapsed){
  int width=(int)sheet_guidanceRenderPolicy_native.rasterWidth,height=(int)sheet_guidanceRenderPolicy_native.rasterHeight;
  if(!guidanceRaster(plan,elapsed)){guidanceRestoreGL(&saved);return false;}
  glTexSubImage2D(GL_TEXTURE_2D,0,0,0,width,height,GL_BGRA,GL_UNSIGNED_BYTE,guidancePixels);guidanceRenderedPlan=plan;guidanceRenderedSecond=elapsed;
 }
 ghUseProgram(guidanceProgram);ghBindVertexArray(guidanceVao);ghUniform1i(ghGetUniformLocation(guidanceProgram,"glyphs"),0);
 float width=(float)viewport[2]-(float)sheet_guidanceRenderPolicy_native.marginPixels*2;if(width>sheet_guidanceRenderPolicy_native.maxDisplayWidth)width=(float)sheet_guidanceRenderPolicy_native.maxDisplayWidth;
 float height=width*(float)sheet_guidanceRenderPolicy_native.rasterHeight/(float)sheet_guidanceRenderPolicy_native.rasterWidth;
 ghUniform4f(ghGetUniformLocation(guidanceProgram,"bounds"),-width/viewport[2],1-2*(float)sheet_guidanceRenderPolicy_native.topPixels/viewport[3],2*width/viewport[2],2*height/viewport[3]);
 ghDisablei(GL_BLEND,0);glDisable(GL_DEPTH_TEST);glDisable(GL_STENCIL_TEST);glDisable(GL_CULL_FACE);glDisable(GL_SCISSOR_TEST);glDisable(GL_RASTERIZER_DISCARD);glDisable(GL_COLOR_LOGIC_OP);for(unsigned i=0;i<8;i++)glDisable(GL_CLIP_DISTANCE0+i);glDisable(GL_SAMPLE_COVERAGE);glDisable(GL_SAMPLE_ALPHA_TO_COVERAGE);glDisable(GL_SAMPLE_ALPHA_TO_ONE);glDisable(GL_SAMPLE_MASK);glPolygonMode(GL_FRONT_AND_BACK,GL_FILL);ghColorMaski(0,GL_TRUE,GL_TRUE,GL_TRUE,GL_TRUE);glDrawArrays(GL_TRIANGLES,0,6);guidanceRestoreGL(&saved);return true;
}
