// SPDX-License-Identifier: GPL-3.0-or-later
#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <stdio.h>
#include "donor-block-targets.h"
static const uintptr_t base=0x10000000,actor=0x20000000,state=0x30000000,ctx=0x40000000,engage=0x50000000,target=0x60000000;
static unsigned roots,ctxReads,entryReads,callbackReads,userdataReads;static int defect;static bool idle;
static bool readFixture(void *unused,uintptr_t address,void *out,SIZE_T size){
 (void)unused;uintptr_t value=0;
 if(address==base+0xc5aa78&&size==8){value=actor;if(defect==1&&++roots>1)value+=8;}
 else if(address==actor+0x3f8&&size==8)value=state;
 else if(address==state&&size==8)value=defect==2?actor+8:actor;
 else if(address==base+0xc67120&&size==8){value=ctx;if(defect==3&&++ctxReads>1)value+=8;}
 else if(address==ctx+0x1c0&&size==8)value=idle?0:engage;
 else if(address==ctx+0x1c8&&size==1){*(unsigned char *)out=0xf3;return true;}
 else if(address==engage&&size==8){value=target;if(defect==4&&++entryReads>1)value+=8;}
 else if(address==engage+0x28&&size==8)value=defect==5?target+1:target;
 else if(address==target+0x3a8&&size==8){value=base+0xee380;if(defect==6)value=base+0x2000000;if(defect==7&&++callbackReads>2)value+=8;if(defect==8)return false;if(defect==15)value=base+0x1234;}
 else if(address==target+0x3f8&&size==8){value=0x70000000;if(defect==12&&++userdataReads>2)value+=8;else if(defect!=12)userdataReads++;}
 else if(address==0x70000008&&size==8)value=defect==13?base+0x2000000:base+0x4567;
 else if(address==actor+0x340&&size==4){uint32_t relation=defect==9?0:123;memcpy(out,&relation,4);return true;}
 else if(address==target+0x32c&&size==4){uint32_t relation=123;if(defect==10)return false;memcpy(out,&relation,4);return true;}
 else return false;
 memcpy(out,&value,size);return true;
}
static bool codeFixture(void *unused,uintptr_t address,uintptr_t module){(void)unused;return module==base&&(address==base+0xee380||address==base+0x1234||(address==base+0x4567&&defect!=14))&&defect!=11;}
static DonorBlockTargets get(void){roots=ctxReads=entryReads=callbackReads=userdataReads=0;return donorBlockTargetsRead(NULL,readFixture,codeFixture,base,0x2000000,actor);}
#define CHECK(c,n) do{if(!(c)){printf("FAIL %d\n",n);return n;}}while(0)
int main(void){
 DonorBlockTargets r=get();CHECK(r.valid&&r.flagsMask==3&&r.engagementPresent&&r.entryPresent&&r.heldPresent&&r.slotsEqual,1);
 CHECK(r.entryCallbackKnown&&r.heldCallbackKnown&&r.entryCallbackRva==0xee380&&r.heldCallbackRva==0xee380&&r.relationKnown&&r.relationEqual&&!r.ownerRelationZero&&!r.targetRelationZero,2);
 CHECK(r.entryHandlerKnown&&r.heldHandlerKnown&&r.entryHandlerRva==0x4567&&r.heldHandlerRva==0x4567,3);
 for(defect=1;defect<=5;defect++)CHECK(!get().valid,10+defect);
 defect=6;r=get();CHECK(r.valid&&!r.entryCallbackKnown&&!r.heldCallbackKnown&&!r.entryCallbackRva&&!r.heldCallbackRva,20);
 defect=7;CHECK(!get().valid,21);
 defect=8;r=get();CHECK(r.valid&&!r.entryCallbackKnown&&!r.heldCallbackKnown,22);
 defect=9;r=get();CHECK(r.valid&&r.relationKnown&&!r.relationEqual&&r.ownerRelationZero&&!r.targetRelationZero,23);
 defect=10;r=get();CHECK(r.valid&&!r.relationKnown&&!r.relationEqual,24);
 defect=11;r=get();CHECK(r.valid&&!r.entryCallbackKnown&&!r.heldCallbackKnown,25);
 defect=12;CHECK(!get().valid,30);
 for(defect=13;defect<=14;defect++){r=get();CHECK(r.valid&&r.entryCallbackKnown&&r.heldCallbackKnown&&!r.entryHandlerKnown&&!r.heldHandlerKnown,31+defect);}
 defect=15;r=get();CHECK(r.valid&&r.entryCallbackKnown&&!r.entryHandlerKnown&&userdataReads==0,46);
 defect=0;idle=true;r=get();CHECK(r.valid&&!r.engagementPresent&&!r.entryPresent&&!r.heldPresent&&!r.slotsEqual&&!r.relationKnown,26);
 CHECK(!donorBlockTargetsRead(NULL,readFixture,codeFixture,UINTPTR_MAX-2,100,actor).valid,27);
 CHECK(!donorBlockTargetsRead(NULL,readFixture,codeFixture,base,0x1000,actor).valid,28);
 CHECK(!donorBlockTargetsRead(NULL,readFixture,codeFixture,base,0x2000000,actor+1).valid,29);
 puts("PASS: production bounded target scalar reader, actor/state/context/slot/callback races, null engagement, unreadable and foreign callbacks, optional relation, overflow/image guards; no pointer output or ownership claim");return 0;
}
