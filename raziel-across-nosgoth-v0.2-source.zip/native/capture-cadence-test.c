#include <stdint.h>
#include <assert.h>
#include <stdio.h>
#include "capture-cadence.h"
int main(void) {
    assert(captureNext60(0,0,1000000)==16667);
    assert(captureNext60(0,12000,1000000)==16667);
    assert(captureNext60(0,16667,1000000)==33334);
    assert(captureNext60(0,45000,1000000)==50000);
    assert(captureNext60(1000000,1000000,1000000)==1016667);
    for(uint64_t n=0;n<8280;n++) {
        uint64_t now=n*1000000/60;
        uint64_t next=captureNext60(0,now,1000000);
        assert(next>now&&next-now<=16667);
    }
    puts("Capture cadence: absolute 60 Hz, read cost excluded, overdue slots skipped, bounded session PASS");
    return 0;
}
