// SPDX-License-Identifier: GPL-3.0-or-later
#include "native-action-callbacks-r12.h"
#include <assert.h>
#include <stdio.h>

int main(void) {
 const uint64_t knownNative[]={0xf4490,0xeeb40,0xf3c40,0xed4b0,0xf9830,0xf5d10};
 const uint64_t ordinary[]={0xf2180,0xf3280,0xf4dc0,0xf5340,0xf54d0,0xedb40,0xee600,0xf2ae0,0xef480};
 const uint64_t rejected[]={0,0xdead,0xeb990,0xec860,0xf3a80,0xf6a30,0xf7dd0,0x1800f9830ULL};
 unsigned checked=0;
 assert(!nativeActionCallbacksR12(NULL));
 for(unsigned i=0;i<sizeof(knownNative)/sizeof(*knownNative);i++) {
  assert(nativeActionCallbackR12(knownNative[i]));
  uint64_t same[3]={knownNative[i],knownNative[i],knownNative[i]};assert(nativeActionCallbacksR12(same));
  // All mixed ordinary section combinations: one explicit action suffices;
  // no delay, floor result or velocity decides ownership.
  for(unsigned section=0;section<3;section++)for(unsigned a=0;a<9;a++)for(unsigned b=0;b<9;b++) {
   uint64_t mixed[3]={ordinary[a],ordinary[b],ordinary[a]};mixed[section]=knownNative[i];assert(nativeActionCallbacksR12(mixed));checked++;
  }
  // Any unproved state, including enemy attack, vetoes the complete tuple.
  for(unsigned bad=0;bad<sizeof(rejected)/sizeof(*rejected);bad++)for(unsigned section=0;section<3;section++) {
   uint64_t mixed[3]={knownNative[i],knownNative[i],knownNative[i]};mixed[section]=rejected[bad];assert(!nativeActionCallbacksR12(mixed));checked++;
  }
 }
 for(unsigned i=0;i<9;i++)assert(!nativeActionCallbackR12(ordinary[i]));
 for(unsigned a=0;a<9;a++)for(unsigned b=0;b<9;b++)for(unsigned c=0;c<9;c++) {
  uint64_t idle[3]={ordinary[a],ordinary[b],ordinary[c]};assert(!nativeActionCallbacksR12(idle));checked++;
 }
 // Played block lifecycle: entry, held, per-section release lag, full exit.
 const uint64_t block[][3]={{0xf4490,0xf4490,0xf4490},{0xf4490,0xeeb40,0xf4490},{0xeeb40,0xeeb40,0xeeb40},{0xeeb40,0xf2180,0xeeb40},{0xf2180,0xf2180,0xeeb40},{0xf2180,0xf2180,0xf2180}};
 for(unsigned i=0;i<6;i++)assert(nativeActionCallbacksR12(block[i])==(i<5));
 const uint64_t swimFall[3]={0xf5d10,0xef480,0xf5d10},dryFall[3]={0xef480,0xef480,0xef480};
 assert(nativeActionCallbacksR12(swimFall));assert(!nativeActionCallbacksR12(dryFall));
 for(unsigned bad=0;bad<sizeof(rejected)/sizeof(*rejected);bad++)assert(!nativeActionCallbackR12(rejected[bad]));
 printf("PASS %u mixed/native/ordinary/unknown classifier cases; no gameplay claim\n",checked);
 return 0;
}
