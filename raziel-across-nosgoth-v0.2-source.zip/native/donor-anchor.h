#include "session-budget.h"
#include "report-path.h"
// In-place animation source. No collision flags, animation nodes or Z writes.
#include "donor-frame-proof.h"
#include "exploration-sheets.h"
typedef uintptr_t (__fastcall *DonorFrameFn)(void);
static DonorFrameFn originalDonorFrame;static PVOID donorFrameTarget;
static volatile LONG donorAnchorEnabled,donorAnchorReset;
static ULONGLONG donorAnchorBegin;
static ULONGLONG donorAnchorDuration=75000;
typedef struct {uintptr_t instance;float xy[2];bool ready,failed;unsigned writes,events;} DonorAnchor;
static DonorAnchor donorAnchor;
static void (*donorAnchorMotionSample)(uintptr_t,const float[3],const float[2],uint64_t);
typedef struct {ULONGLONG tick;uintptr_t instance;unsigned phase;float current[3],previous[3],anchor[2],result[3],oldResult[3],factor,root[16];bool ok,motionValid;} DonorAnchorEvent;
static DonorAnchorEvent donorAnchorQueue[1024];static unsigned donorAnchorHead,donorAnchorTail;
static volatile LONG donorAnchorLock;
typedef struct {ULONGLONG tick;unsigned writes;bool ready,failed,scope;float xy[2];} DonorAnchorStatus;
static DonorAnchorStatus donorAnchorStatus;static ULONGLONG donorAnchorStatusPrinted;
static bool donorAnchorWrite(uintptr_t instance,const float xy[2]){
    float before[2],old[2],after[2],oldAfter[2];SIZE_T written=0;
    if(!donorProcessIdentity(instance)||!worldRead(instance+0x20,before,8)||!worldRead(instance+0x30,old,8))return false;
    bool first=WriteProcessMemory(GetCurrentProcess(),(void *)(instance+0x20),xy,8,&written)&&written==8;
    bool second=first&&WriteProcessMemory(GetCurrentProcess(),(void *)(instance+0x30),xy,8,&written)&&written==8;
    bool valid=second&&donorProcessIdentity(instance)&&worldRead(instance+0x20,after,8)&&worldRead(instance+0x30,oldAfter,8)&&!memcmp(xy,after,8)&&!memcmp(xy,oldAfter,8);
    if(!valid&&donorProcessIdentity(instance)){
        // A failed two-field update must not leave half of the pin applied.
        WriteProcessMemory(GetCurrentProcess(),(void *)(instance+0x20),before,8,&written);
        WriteProcessMemory(GetCurrentProcess(),(void *)(instance+0x30),old,8,&written);
    }
    return valid;
}
static bool donorAnchorPositions(const float current[3],const float previous[3]){
    for(unsigned k=0;k<3;k++)if(!isfinite(current[k])||!isfinite(previous[k])||fabsf(current[k])>100000||fabsf(previous[k])>100000)return false;
    return true;
}
static bool donorAnchorApply(uintptr_t instance,unsigned phase,ULONGLONG now){
    DonorAnchorEvent e={0};e.tick=now;e.instance=instance;e.phase=phase;
    if(!donorProcessIdentity(instance)||!worldRead(instance+0x20,e.current,12)||!worldRead(instance+0x30,e.previous,12)||!donorAnchorPositions(e.current,e.previous))return false;
    if(!donorAnchor.ready){
        // Start only from a quiet, level frame. Caller asks user to stand on a
        // clear floor. This does not attempt to invent a ground/contact flag.
        if(phase||fabsf(e.current[2]-e.previous[2])>1||fabsf(e.current[0]-e.previous[0])>1||fabsf(e.current[1]-e.previous[1])>1)return true;
        donorAnchor.instance=instance;memcpy(donorAnchor.xy,e.current,8);donorAnchor.ready=true;
    }
    if(instance!=donorAnchor.instance)return false;
    for(unsigned k=0;k<2;k++)if(fabsf(e.current[k]-donorAnchor.xy[k])>256||fabsf(e.previous[k]-donorAnchor.xy[k])>256)return false;
    memcpy(e.anchor,donorAnchor.xy,8);
    e.motionValid=phase==1&&donorFrameMotion.wanted&&donorFrameMotion.thread==GetCurrentThreadId()&&
        donorFrameMotion.instance==instance&&donorFrameMotion.callbacks==1&&donorFrameMotion.valid;
    if(e.motionValid){e.factor=donorFrameMotion.factor;memcpy(e.root,donorFrameMotion.root,sizeof(e.root));}
    e.ok=donorAnchorWrite(instance,donorAnchor.xy);
    e.ok=e.ok&&worldRead(instance+0x20,e.result,12)&&worldRead(instance+0x30,e.oldResult,12)&&e.current[2]==e.result[2]&&e.previous[2]==e.oldResult[2];
    if(e.ok){++donorAnchor.writes;if(donorAnchorMotionSample)donorAnchorMotionSample(instance,e.current,e.anchor,now);}
    if(!InterlockedCompareExchange(&donorAnchorLock,1,0)){
        unsigned next=(donorAnchorHead+1)%ARRAYSIZE(donorAnchorQueue);
        if(next!=donorAnchorTail&&donorAnchor.events<40000){donorAnchorQueue[donorAnchorHead]=e;donorAnchorHead=next;++donorAnchor.events;}
        InterlockedExchange(&donorAnchorLock,0);
    }
    return e.ok;
}
static uintptr_t __fastcall anchorDonorFrame(void){
    ULONGLONG now=GetTickCount64();bool enabled=InterlockedCompareExchange(&donorAnchorEnabled,0,0)!=0;
    if(enabled&&InterlockedExchange(&donorAnchorReset,0))memset(&donorAnchor,0,sizeof(donorAnchor));
    uintptr_t instance=0;bool scope=enabled&&!donorAnchor.failed&&now>=donorAnchorBegin&&sessionBudget(donorAnchorBegin,now,donorAnchorDuration)&&worldRead(donorProcessBase+0xc5aa78,&instance,8);
    if(scope&&!donorAnchorApply(instance,0,now)){donorAnchor.failed=true;scope=false;}
#ifdef HOST_LED_HEADING
    donorHeadingBoundary(instance,scope&&donorAnchor.ready);
#endif
    memset(&donorFrameMotion,0,sizeof(donorFrameMotion));
    donorFrameMotion.wanted=scope&&donorAnchor.ready&&InterlockedCompareExchange(&donorProcessEnabled,0,0);
    donorFrameMotion.instance=instance;donorFrameMotion.thread=GetCurrentThreadId();
    uintptr_t result=originalDonorFrame();
#ifdef HOST_LED_HEADING
    donorHeadingBoundary(instance,scope&&donorAnchor.ready&&InterlockedCompareExchange(&donorAnchorEnabled,0,0));
#endif
    if(scope&&InterlockedCompareExchange(&donorAnchorEnabled,0,0)&&!donorAnchorApply(instance,1,GetTickCount64()))donorAnchor.failed=true;
    donorFrameMotion.wanted=false;
    // One coherent scalar receipt survives the detailed-event cap. Never log
    // or perform IO from the game hook; the observer thread drains this copy.
    if(enabled&&!InterlockedCompareExchange(&donorAnchorLock,1,0)){
        donorAnchorStatus=(DonorAnchorStatus){.tick=GetTickCount64(),.writes=donorAnchor.writes,.ready=donorAnchor.ready,.failed=donorAnchor.failed,.scope=scope};
        memcpy(donorAnchorStatus.xy,donorAnchor.xy,sizeof(donorAnchorStatus.xy));
        InterlockedExchange(&donorAnchorLock,0);
    }
    return result;
}
static void donorAnchorFlush(void){
    DonorAnchorEvent local[1024];unsigned n=0;if(InterlockedCompareExchange(&donorAnchorLock,1,0))return;
    DonorAnchorStatus status=donorAnchorStatus;
    while(donorAnchorTail!=donorAnchorHead){local[n++]=donorAnchorQueue[donorAnchorTail];donorAnchorTail=(donorAnchorTail+1)%ARRAYSIZE(donorAnchorQueue);}InterlockedExchange(&donorAnchorLock,0);
    for(unsigned i=0;i<n;i++){DonorAnchorEvent *e=&local[i];logLine("DONOR_ANCHOR tick=%llu instance=%p phase=%u current=%.9g,%.9g,%.9g previous=%.9g,%.9g,%.9g anchor=%.9g,%.9g result=%.9g,%.9g,%.9g old_result=%.9g,%.9g,%.9g ok=%u; XY only",
      e->tick,(void *)e->instance,e->phase,e->current[0],e->current[1],e->current[2],e->previous[0],e->previous[1],e->previous[2],e->anchor[0],e->anchor[1],e->result[0],e->result[1],e->result[2],e->oldResult[0],e->oldResult[1],e->oldResult[2],e->ok);
      if(e->phase==1)logLine("DONOR_FRAME_STEP tick=%llu instance=%p valid=%u factor=%.9g delta=%.9g,%.9g,0 rotation=%.9g,%.9g,%.9g,%.9g,%.9g,%.9g,%.9g,%.9g,%.9g; read-only whole-frame XY displacement before pin, includes native collision",
        e->tick,(void *)e->instance,e->ok&&e->motionValid,e->motionValid?e->factor:0,e->current[0]-e->anchor[0],e->current[1]-e->anchor[1],
        e->root[0],e->root[1],e->root[2],e->root[4],e->root[5],e->root[6],e->root[8],e->root[9],e->root[10]);}
    if(status.tick&&status.tick>=donorAnchorStatusPrinted+1000){
        donorAnchorStatusPrinted=status.tick;
#ifdef HOST_LED_HEADING
        logLine("DONOR_HEADING writes=%ld failed=%ld restored=%ld foreign=%ld; host authority, game frame",InterlockedCompareExchange(&donorHeadingPublishedWrites,0,0),InterlockedCompareExchange(&donorHeadingPublishedFailed,0,0),InterlockedCompareExchange(&donorHeadingPublishedRestored,0,0),InterlockedCompareExchange(&donorHeadingPublishedForeign,0,0));
#endif
        logLine("DONOR_ANCHOR_STATUS tick=%llu writes=%u ready=%u failed=%u scope=%u anchor=%.9g,%.9g",status.tick,status.writes,status.ready,status.failed,status.scope,status.xy[0],status.xy[1]);
    }
}
static void donorAnchorInstall(HMODULE module){
    if(!module)return;unsigned char bytes[DONOR_FRAME_SIZE];char sha[65];PVOID target=(void *)((uintptr_t)module+DONOR_FRAME_RVA);
    if(!worldRead((uintptr_t)target,bytes,sizeof(bytes))||!hashBytes(bytes,sizeof(bytes),sha)||strcmp(sha,DONOR_FRAME_SHA)){logLine("DONOR_ANCHOR full-code proof failed");return;}
    MH_STATUS init=MH_Initialize();if(init!=MH_OK&&init!=MH_ERROR_ALREADY_INITIALIZED)return;
    MH_STATUS create=MH_CreateHook(target,(void *)&anchorDonorFrame,(void **)&originalDonorFrame),enable=create==MH_OK?MH_EnableHook(target):create;
    if(enable==MH_OK)donorFrameTarget=target;logLine("DONOR_ANCHOR create=%d enable=%d full-code proof=1; explicit XY pin, Z untouched",create,enable);
}
static void donorAnchorTick(void){
    bool requested=donorFrameTarget&&GetFileAttributesW(PROBE_PATH(L"\\donor-anchor.enable"))!=INVALID_FILE_ATTRIBUTES&&GetFileAttributesW(PROBE_PATH(L"\\defiance-background.enable"))!=INVALID_FILE_ATTRIBUTES;
    bool enabled=InterlockedCompareExchange(&donorAnchorEnabled,0,0)!=0;
    if(requested&&!enabled){donorProcessFindModel();donorAnchorBegin=GetTickCount64();donorAnchorDuration=GetFileAttributesW(PROBE_PATH(L"\\direct-motion-donor.enable"))!=INVALID_FILE_ATTRIBUTES?180000:(ULONGLONG)sheet_diagnosticLimits_controls.durationMs;InterlockedExchange(&donorAnchorReset,1);InterlockedExchange(&donorAnchorEnabled,1);logLine("DONOR_ANCHOR enabled=1; quiet floor anchor, boundedMs=%llu",donorAnchorDuration);}
    if(!requested&&enabled){InterlockedExchange(&donorAnchorEnabled,0);logLine("DONOR_ANCHOR enabled=0; native movement resumes");}
    donorAnchorFlush();
}
static void donorAnchorStop(void){
 InterlockedExchange(&donorAnchorEnabled,0);
 if(donorFrameTarget)MH_DisableHook(donorFrameTarget);donorAnchorFlush();
}

