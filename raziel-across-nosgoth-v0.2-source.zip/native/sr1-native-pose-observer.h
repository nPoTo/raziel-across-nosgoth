// SPDX-License-Identifier: GPL-3.0-or-later
// Forwarding-only native consumer observation. NEVER substitutes a matrix.
#include "host-rig-reader.h"
#include "sr1-native-pose-forward.h"
typedef struct {ULONGLONG tick;DWORD thread;unsigned depth;bool scoped,unchanged;int bones,weighted,extraRaw;unsigned failure;} Sr1NativePoseRecord;
static Sr1NativePoseFn sr1NativePoseOriginal;static PVOID sr1NativePoseTarget;
static volatile LONG sr1NativePoseEnabled,sr1NativePoseCalls,sr1NativePoseForwarded,sr1NativePoseDropped,sr1NativePoseLock;
static _Thread_local unsigned sr1NativePoseDepth;
static ULONGLONG sr1NativePoseBegin,sr1NativePoseLast;static bool sr1NativePoseStarted;
static Sr1NativePoseRecord sr1NativePoseQueue[128];static unsigned sr1NativePoseHead,sr1NativePoseTail,sr1NativePoseSamples;
static bool sr1NativePoseRead(void *unused,uintptr_t address,void *out,SIZE_T size){(void)unused;return worldRead(address,out,size);}
static bool sr1NativePoseCandidate(uintptr_t record,uintptr_t model,uintptr_t matrices){
 const Sheet_rigRead *p=&sheet_rigRead_current;uintptr_t base=(uintptr_t)InterlockedCompareExchangePointer(&verifiedSr1Module,NULL,NULL),actor=0,object=0,list=0,currentModel=0,currentMatrices=0;int16_t index=-1;
 return base&&worldRead(base+p->actorGlobalRva,&actor,8)&&actor&&worldRead(actor+p->actorCurrentModelOffset,&index,2)&&index==0&&worldRead(actor+p->actorObjectOffset,&object,8)&&object&&worldRead(object+p->objectModelsOffset,&list,8)&&list&&worldRead(list,&currentModel,8)&&worldRead(actor+p->actorRenderMatricesOffset,&currentMatrices,8)&&sr1NativePoseArgumentsMatch(record,model,matrices,object,currentModel,currentMatrices,0x70);
}
static uintptr_t sr1NativePoseObserve(uintptr_t a,uintptr_t b,uintptr_t c,uintptr_t d,uintptr_t e,uintptr_t f,uintptr_t g,uintptr_t h){
 const uintptr_t args[8]={a,b,c,d,e,f,g,h};InterlockedIncrement(&sr1NativePoseCalls);unsigned depth=++sr1NativePoseDepth;
 const Sheet_nativePoseObserver *p=&sheet_nativePoseObserver_original;ULONGLONG now=GetTickCount64();Sr1NativePoseRecord record={.tick=now,.thread=GetCurrentThreadId(),.depth=depth};HostRig before;bool capture=false;
 if(depth==1&&InterlockedCompareExchange(&sr1NativePoseEnabled,0,0)&&!InterlockedCompareExchange(&probeBoundedComplete,0,0)&&now>=sr1NativePoseBegin&&now-sr1NativePoseBegin<=(ULONGLONG)p->durationMs&&now-sr1NativePoseLast>=(ULONGLONG)p->intervalMs&&sr1NativePoseCandidate(a,b,d)){
  // Zero-wait sample ownership. Another native thread always forwards.
  if(!InterlockedCompareExchange(&sr1NativePoseLock,1,0)){
   if(sr1NativePoseSamples<(unsigned)p->samples){sr1NativePoseLast=now;capture=true;++sr1NativePoseSamples;}
   InterlockedExchange(&sr1NativePoseLock,0);
  }
 }
 if(capture){
  uintptr_t base=(uintptr_t)InterlockedCompareExchangePointer(&verifiedSr1Module,NULL,NULL);record.scoped=hostRigRead(NULL,sr1NativePoseRead,base,&before)&&before.count==p->bones&&before.modelIndex==p->modelIndex&&sr1NativePoseArgumentsMatch(a,b,d,before.object,before.model,before.render,(uintptr_t)p->recordObjectOffset);
  record.failure=rigReadFailure;record.bones=record.scoped?before.count:0;
  if(record.scoped){unsigned char mask[66];int32_t extra=0;
   record.scoped=a<=UINTPTR_MAX-0x6de&&worldRead(a+0x69c,mask,sizeof(mask))&&worldRead(a+0xc,&extra,4);record.extraRaw=extra;
   if(record.scoped)for(unsigned i=0;i<sizeof(mask);i++)record.weighted+=mask[i]!=0;
  }
 }
 // Every path forwards ALL original slots once; opaque return is preserved.
 uintptr_t result=sr1NativePoseForward(sr1NativePoseOriginal,args);InterlockedIncrement(&sr1NativePoseForwarded);
 if(capture){
  if(record.scoped){HostRig after;record.unchanged=hostRigRead(NULL,sr1NativePoseRead,(uintptr_t)InterlockedCompareExchangePointer(&verifiedSr1Module,NULL,NULL),&after)&&after.actor==before.actor&&after.object==before.object&&after.model==before.model&&after.render==before.render&&!memcmp(before.renderBytes,after.renderBytes,(size_t)before.count*52);}
  if(!InterlockedCompareExchange(&sr1NativePoseLock,1,0)){unsigned next=(sr1NativePoseHead+1)%ARRAYSIZE(sr1NativePoseQueue);if(next!=sr1NativePoseTail){sr1NativePoseQueue[sr1NativePoseHead]=record;sr1NativePoseHead=next;}else InterlockedIncrement(&sr1NativePoseDropped);InterlockedExchange(&sr1NativePoseLock,0);}else InterlockedIncrement(&sr1NativePoseDropped);
 }
 --sr1NativePoseDepth;return result;
}
static void sr1NativePoseFlush(void){
 Sr1NativePoseRecord records[128];unsigned n=0;if(InterlockedCompareExchange(&sr1NativePoseLock,1,0))return;
 while(sr1NativePoseTail!=sr1NativePoseHead){records[n++]=sr1NativePoseQueue[sr1NativePoseTail];sr1NativePoseTail=(sr1NativePoseTail+1)%ARRAYSIZE(sr1NativePoseQueue);}InterlockedExchange(&sr1NativePoseLock,0);
 for(unsigned i=0;i<n;i++){const Sr1NativePoseRecord *r=&records[i];logLine("SR1_NATIVE_POSE tick=%llu thread=%lu depth=%u scoped=%u bones=%d weighted=%d extra_raw=%d input_unchanged=%u read_failure=%u; original8args forwarded; no mesh/texture/pose writes",r->tick,r->thread,r->depth,r->scoped,r->bones,r->weighted,r->extraRaw,r->unchanged,r->failure);}
}
static bool sr1NativePoseInstall(HMODULE module){
 const Sheet_nativePoseObserver *p=&sheet_nativePoseObserver_original;if(sr1NativePoseTarget)return true;
 if(!module||p->targetRva!=0x40d10||p->targetBytes!=1961||p->recordObjectOffset!=0x70||p->bones!=66||p->matrixBytes!=52||p->modelIndex!=0||p->samples!=60||p->durationMs!=20000||p->intervalMs!=33||p->gameWrites||p->resourceSerialization)return false;
 unsigned char code[1961];char hash[65],expected[65];uintptr_t target=(uintptr_t)module+(uintptr_t)p->targetRva;
 if(wcslen(p->codeSha256)!=64)return false;for(unsigned i=0;i<64;i++){if(!wcschr(L"0123456789abcdef",p->codeSha256[i]))return false;expected[i]=(char)p->codeSha256[i];}expected[64]=0;
 if(!worldRead(target,code,sizeof(code))||!hashBytes(code,sizeof(code),hash)||strcmp(hash,expected))return false;
 MH_STATUS init=MH_Initialize();if(init!=MH_OK&&init!=MH_ERROR_ALREADY_INITIALIZED)return false;
 MH_STATUS create=MH_CreateHook((void *)target,(void *)&sr1NativePoseObserve,(void **)&sr1NativePoseOriginal),enable=create==MH_OK?MH_EnableHook((void *)target):create;
 if(enable!=MH_OK)return false;sr1NativePoseTarget=(void *)target;logLine("CAPABILITY sr1_native_pose_observer=1; forwarding-only, argument4 untouched, no model transfer");return true;
}
static void sr1NativePoseTick(void){
 const Sheet_nativePoseObserver *p=&sheet_nativePoseObserver_original;
 if(!sr1NativePoseStarted&&sr1NativePoseTarget&&GetFileAttributesW(PROBE_PATH(L"\\sr1-native-pose-observe.enable"))!=INVALID_FILE_ATTRIBUTES){sr1NativePoseStarted=true;sr1NativePoseBegin=GetTickCount64();InterlockedExchange(&sr1NativePoseEnabled,1);logLine("SR1_NATIVE_POSE active=1 samples=%lld duration_ms=%lld; READ ONLY",(long long)p->samples,(long long)p->durationMs);}
 if(InterlockedCompareExchange(&sr1NativePoseEnabled,0,0)&&(GetFileAttributesW(PROBE_PATH(L"\\sr1-native-pose-observe.enable"))==INVALID_FILE_ATTRIBUTES||GetTickCount64()-sr1NativePoseBegin>(ULONGLONG)p->durationMs||sr1NativePoseSamples>=(unsigned)p->samples)){InterlockedExchange(&sr1NativePoseEnabled,0);logLine("SR1_NATIVE_POSE active=0 samples=%u dropped=%ld; original forwarding retained",sr1NativePoseSamples,InterlockedCompareExchange(&sr1NativePoseDropped,0,0));}
 sr1NativePoseFlush();
}
static void sr1NativePoseStop(void){InterlockedExchange(&sr1NativePoseEnabled,0);sr1NativePoseFlush();logLine("SR1_NATIVE_POSE stopped calls=%ld forwarded=%ld; hook/trampoline pinned for unchanged native forwarding",InterlockedCompareExchange(&sr1NativePoseCalls,0,0),InterlockedCompareExchange(&sr1NativePoseForwarded,0,0));}
