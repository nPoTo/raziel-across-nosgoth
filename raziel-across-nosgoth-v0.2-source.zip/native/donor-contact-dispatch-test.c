// SPDX-License-Identifier: GPL-3.0-or-later
#include "donor-contact-dispatch.h"
#include <assert.h>
#include <stdio.h>
static unsigned lines,cached;static DonorContactLine *expected;
static float *expectedEnd,*expectedStart;
static void lineOriginal(uintptr_t actor,DonorContactLine *line,uint32_t opaque){
 assert(actor==123&&line==expected&&opaque==0xdeadbeef);lines++;line->kind=3;
}
static int32_t cachedOriginal(uintptr_t level,uintptr_t segment,float *end,float *start,uintptr_t triangle){
 assert(level==12&&segment==34&&triangle==56&&end==expectedEnd&&start==expectedStart);cached++;return -17;
}
int main(void){
 float position[3]={0,0,100},start[4]={0},end[4]={0};expectedStart=start;expectedEnd=end;
 for(unsigned phase=1;phase<=2;phase++){
  DonorContactProjection scope={.actor=123,.phase=phase,.admitted=true};
  DonorContactLine line={.flags=0x3f,.start={0,0,148,0},.end={0,0,4,0}};expected=&line;
  assert(donorContactDispatchCached(cachedOriginal,&scope,0x103b4d,12,34,end,start,56)==0);
  assert(donorContactDispatchLine(lineOriginal,&scope,0x103bf5,123,&line,0xdeadbeef,position));
  assert(!lines&&!cached&&line.kind==(phase==1?2u:0u));
  // Foreign wall query still executes the native function once with all args.
  assert(!donorContactDispatchLine(lineOriginal,&scope,0x104500,123,&line,0xdeadbeef,position));
  assert(!scope.poisoned&&line.kind==3);
  assert(donorContactDispatchCached(cachedOriginal,&scope,0x123456,12,34,end,start,56)==-17);
  assert(lines==1&&cached==1);lines=cached=0;
  line.start[0]=1;
  assert(!donorContactDispatchLine(lineOriginal,&scope,0x103c47,123,&line,0xdeadbeef,position));
  assert(scope.poisoned&&lines==1);lines=0;
 }
 puts("PASS real-detour dispatch: five-argument cached ABI, line opaque preserved, exact callers only, invalid primary poisons scope");
}
