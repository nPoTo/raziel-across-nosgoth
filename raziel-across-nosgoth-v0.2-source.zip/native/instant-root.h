#include "session-budget.h"
#include "report-path.h"
#include "exploration-sheets.h"
// Explicit actual-handler bridge. Native event/controller APIs; no XYZ writes.
#include "instant-root-proof.h"
#include "root-controller-read.h"
typedef uintptr_t (__fastcall *RootStateFn)(uintptr_t,int32_t,uintptr_t);
typedef uintptr_t (__fastcall *RootCharacterFn)(uintptr_t,uintptr_t,uintptr_t);
typedef uintptr_t (__fastcall *RootControlFn)(uintptr_t,int32_t,int32_t);
static RootStateFn originalRootState[4];static RootCharacterFn rootCharacterSwitch;
static RootControlFn rootEnable[2],rootDisable[2];static PVOID rootStateTargets[4];
static const uintptr_t rootStateRvas[4]={0xf2180,0xf3280,0xf4dc0,0xf5340};
static uintptr_t instantRootModule,instantRootOwner;static unsigned instantRootOwned;
// Optional owner cleanup on native walking transitions. No state switch by it.
static void (*rootOtherRelease)(uintptr_t);
static void (*rootOtherAfter)(uintptr_t,int32_t);
static bool (*rootOtherOwnsControllers)(void);
// Optional separately scoped owner. The old render/root pilot stays disabled.
typedef void (*RootExternalReleaseFn)(uintptr_t);
typedef bool (*RootExternalAfterFn)(uintptr_t,int32_t);
typedef bool (*RootExternalOwnsFn)(void);
static RootExternalReleaseFn rootExternalRelease;
static RootExternalAfterFn rootExternalAfter;
static RootExternalOwnsFn rootExternalOwnsControllers;
static bool rootEligibleProcess(uintptr_t process){for(unsigned k=0;k<ARRAYSIZE(rootStateRvas);k++)if(process==instantRootModule+rootStateRvas[k])return true;return false;}
static volatile LONG instantRootEnabled,instantRootBusy;static bool instantRootAttempted,instantRootRequested,instantRootFailed,instantRootWasMoving;
static ULONGLONG instantRootBegin;static unsigned instantRootFrames,instantRootCalls,instantRootRejects,instantRootGates[9];
static bool instantRootIdentity(uintptr_t state,uintptr_t expected){uintptr_t player=0,instance=0;float root[16];return worldRoot(root,&player)&&player==expected&&worldRead(state,&instance,8)&&instance==expected;}
static void instantRootRelease(uintptr_t state){
 if(!instantRootOwned)return;
 if(instantRootIdentity(state,instantRootOwner))for(unsigned k=0;k<2;k++)if(instantRootOwned&(1u<<k)){uintptr_t anim=instantRootOwner+(k?0x448:0x328);RootController c;if(rootControllerRead(instantRootModule,anim,k,&c)&&c.found&&c.active)rootDisable[k](anim,0,34);}
 instantRootOwned=0;instantRootOwner=0;
}
static unsigned instantRootScope(uintptr_t state,int32_t section,ULONGLONG now,uintptr_t *player,uintptr_t *process,float *target,uint64_t *source){
 uintptr_t instance=0;float root[16];int32_t velocity=0,time=0;DWORD foreground=0;
 if(!InterlockedCompareExchange(&instantRootEnabled,0,0)||instantRootFailed||!InterlockedCompareExchange(&movementEnabled,0,0)||!instantRootModule||section!=0||now<instantRootBegin||!sessionBudget(instantRootBegin,now,(uint64_t)sheet_diagnosticLimits_controls.durationMs))return 1;
 if(!worldRoot(root,player)||!worldRead(state,&instance,8)||instance!=*player)return 2;
 if(!worldRead(state+0x10,process,8)||!rootEligibleProcess(*process))return 3;
 if(!worldLastDraw||now<worldLastDraw||now-worldLastDraw>=250||worldLastInstance!=*player||root[10]<=.8f)return 4;
 if(!worldRead(*player+0x2d4,&velocity,4)||velocity!=0||!worldRead(instantRootModule+0x2a89628,&time,4)||time<=0||time>8192)return 5;
 if(!srGroundMovingInput())return 6;GetWindowThreadProcessId(GetForegroundWindow(),&foreground);if(foreground!=GetCurrentProcessId())return 7;
 unsigned char packet[80];return movementReadPacket(packet)&&movementPacketTarget(packet,sizeof(packet),now,overlayLivePid,overlayLiveTick,time,target,source)&&*target<-.01f?0:8;
}
static uintptr_t rootStateObserve(unsigned kind,uintptr_t state,int32_t section,uintptr_t data){
 if(InterlockedCompareExchange(&instantRootBusy,1,0))return originalRootState[kind](state,section,data);
 // Cleanup occurs on the handler thread, before native decisions for this frame.
 if(section==0){instantRootRelease(state);RootExternalReleaseFn release=(RootExternalReleaseFn)InterlockedCompareExchangePointer((PVOID volatile *)&rootExternalRelease,NULL,NULL);if(release)release(state);if(rootOtherRelease)rootOtherRelease(state);}
 uintptr_t result=originalRootState[kind](state,section,data),player=0,process=0;float target=0;uint64_t source=0;ULONGLONG now=GetTickCount64();
 if(rootOtherAfter)rootOtherAfter(state,section);
 RootExternalAfterFn external=(RootExternalAfterFn)InterlockedCompareExchangePointer((PVOID volatile *)&rootExternalAfter,NULL,NULL);
 if(external&&external(state,section)){InterlockedExchange(&instantRootBusy,0);return result;}
 unsigned gate=instantRootScope(state,section,now,&player,&process,&target,&source);
 if(section==0&&InterlockedCompareExchange(&instantRootEnabled,0,0)){++instantRootCalls;++instantRootGates[gate];}
 if(gate&&section==0)instantRootWasMoving=false;
 if(!gate){
  bool began=!instantRootWasMoving;
  uintptr_t fromRva=process-instantRootModule;
  // Preserve native steering until StartTurn itself exits. Forward translation
  // in the old heading during that interval produces an arc on reverse onset.
  bool pivot=sheet_groundTurnPolicy_pivot.preserveNativeTurn&&process==instantRootModule+0xf5340;
  if(pivot&&sheet_groundTurnPolicy_pivot.zeroTurnTranslation)target=0;
  if(!pivot&&process!=instantRootModule+0xf3280){rootCharacterSwitch(state,instantRootModule+0xf3280,0);worldRead(state+0x10,&process,8);}
  RootController before[2],after[2];bool ok=(pivot||process==instantRootModule+0xf3280)&&instantRootIdentity(state,player);
  for(unsigned k=0;k<2&&ok;k++)ok=rootControllerRead(instantRootModule,player+(k?0x448:0x328),k,&before[k])&&before[k].found;
  if(ok){
   instantRootOwner=player;
   for(unsigned k=0;k<2;k++)if(!before[k].active){instantRootOwned|=1u<<k;rootEnable[k](player+(k?0x448:0x328),0,34);}
   for(unsigned k=0;k<2&&ok;k++)ok=rootControllerRead(instantRootModule,player+(k?0x448:0x328),k,&after[k])&&after[k].found&&after[k].active;
   if(ok){
    int16_t small[3]={0,(int16_t)target,0};float wide[3]={0,target,0};originalMotion[0](player+0x328,0,34,(uintptr_t)small);originalMotion[1](player+0x448,0,34,(uintptr_t)wide);
    RootController check[2];ok=instantRootIdentity(state,player);
    for(unsigned k=0;k<2&&ok;k++)ok=rootControllerRead(instantRootModule,player+(k?0x448:0x328),k,&check[k])&&check[k].found&&check[k].active&&check[k].node==before[k].node&&!memcmp(check[k].vector,k?(void *)wide:(void *)small,k?12:6);
    if(!ok&&instantRootIdentity(state,player)){originalMotion[0](player+0x328,0,34,(uintptr_t)before[0].vector);originalMotion[1](player+0x448,0,34,(uintptr_t)before[1].vector);}
   }
   if(!ok){instantRootRelease(state);instantRootFailed=true;InterlockedExchange(&instantRootEnabled,0);}if(ok)++instantRootFrames;instantRootWasMoving=ok;
   if(began||instantRootFrames<=12||instantRootFrames%30==0||!ok)logLine("SR1_INSTANT_ROOT tick=%llu player=%p state=%p targetY=%.9g sourceTick=%llu ok=%u owned=%u frames=%u began=%u kind=%u fromRva=%llx; native root controllers, no XYZ writes",now,(void *)player,(void *)state,target,(unsigned long long)source,ok,instantRootOwned,instantRootFrames,began,kind,(unsigned long long)fromRva);
  }else {++instantRootRejects;instantRootWasMoving=false;}
 }
 InterlockedExchange(&instantRootBusy,0);return result;
}
static uintptr_t __fastcall rootStationary(uintptr_t state,int32_t section,uintptr_t data){return rootStateObserve(0,state,section,data);}
static uintptr_t __fastcall rootMoving(uintptr_t state,int32_t section,uintptr_t data){return rootStateObserve(1,state,section,data);}
static uintptr_t __fastcall rootStarting(uintptr_t state,int32_t section,uintptr_t data){return rootStateObserve(2,state,section,data);}
static uintptr_t __fastcall rootTurning(uintptr_t state,int32_t section,uintptr_t data){return rootStateObserve(3,state,section,data);}
static void instantRootInstall(HMODULE module){
 if(!module||instantRootAttempted)return;instantRootAttempted=true;if(!originalMotion[0]||!originalMotion[1])return;
 for(unsigned i=0;i<ARRAYSIZE(instantRootProofs);i++){unsigned char bytes[4096];char sha[65];if(instantRootProofs[i].size>sizeof(bytes)||!worldRead((uintptr_t)module+instantRootProofs[i].rva,bytes,instantRootProofs[i].size)||!hashBytes(bytes,instantRootProofs[i].size,sha)||strcmp(sha,instantRootProofs[i].sha256)){logLine("SR1_INSTANT_ROOT code gate failed kind=%u",i);return;}}
 instantRootModule=(uintptr_t)module;rootCharacterSwitch=(RootCharacterFn)(instantRootModule+0x10ffc0);rootEnable[0]=(RootControlFn)(instantRootModule+0x61ce0);rootEnable[1]=(RootControlFn)(instantRootModule+0x61d80);rootDisable[0]=(RootControlFn)(instantRootModule+0x61bb0);rootDisable[1]=(RootControlFn)(instantRootModule+0x61bf0);
 MH_STATUS init=MH_Initialize();if(init!=MH_OK&&init!=MH_ERROR_ALREADY_INITIALIZED)return;
 PVOID handlers[4]={(void *)&rootStationary,(void *)&rootMoving,(void *)&rootStarting,(void *)&rootTurning};
 for(unsigned k=0;k<ARRAYSIZE(rootStateRvas);k++){PVOID target=(void *)(instantRootModule+rootStateRvas[k]);MH_STATUS create=MH_CreateHook(target,handlers[k],(void **)&originalRootState[k]),enable=create==MH_OK?MH_EnableHook(target):create;if(enable==MH_OK)rootStateTargets[k]=target;logLine("SR1_INSTANT_ROOT kind=%u create=%d enable=%d full-code proof=1",k,create,enable);}
}
static void instantRootTick(void){
 bool requested=rootStateTargets[0]&&rootStateTargets[1]&&rootStateTargets[2]&&rootStateTargets[3]&&GetFileAttributesW(PROBE_PATH(L"\\instant-start-sr1.enable"))!=INVALID_FILE_ATTRIBUTES&&GetFileAttributesW(PROBE_PATH(L"\\movement-sr1.enable"))!=INVALID_FILE_ATTRIBUTES&&GetFileAttributesW(PROBE_PATH(L"\\replace-sr1.enable"))!=INVALID_FILE_ATTRIBUTES;
 if(requested!=instantRootRequested){instantRootRequested=requested;instantRootBegin=requested?GetTickCount64():0;if(requested){instantRootFrames=instantRootCalls=instantRootRejects=0;memset(instantRootGates,0,sizeof(instantRootGates));instantRootFailed=false;}InterlockedExchange(&instantRootEnabled,requested);logLine("SR1_INSTANT_ROOT enabled=%u calls=%u frames=%u rejected=%u gates=%u,%u,%u,%u,%u,%u,%u,%u,%u; bounded%ums, handler-thread cleanup",requested,instantRootCalls,instantRootFrames,instantRootRejects,instantRootGates[0],instantRootGates[1],instantRootGates[2],instantRootGates[3],instantRootGates[4],instantRootGates[5],instantRootGates[6],instantRootGates[7],instantRootGates[8],(unsigned)sheet_diagnosticLimits_controls.durationMs);}
}
static void instantRootStop(void){InterlockedExchange(&instantRootEnabled,0);RootExternalOwnsFn owns=(RootExternalOwnsFn)InterlockedCompareExchangePointer((PVOID volatile *)&rootExternalOwnsControllers,NULL,NULL);if(!instantRootOwned&&(!rootOtherOwnsControllers||!rootOtherOwnsControllers())&&(!owns||!owns()))for(unsigned k=0;k<ARRAYSIZE(rootStateTargets);k++)if(rootStateTargets[k])MH_DisableHook(rootStateTargets[k]);}


