// SPDX-License-Identifier: GPL-3.0-or-later
#pragma once
#include <stdint.h>
#include <stdbool.h>
#include <string.h>
// The original input poll needs actor identity, not the rotating bone buffers.
typedef bool (*CombatIdentityRead)(void *,uintptr_t,void *,size_t);
static inline bool srCombatInputIdentity(void *ctx,CombatIdentityRead read,uintptr_t base,uintptr_t *actor,uintptr_t *object){
 uintptr_t a=0,o=0,n=0,a2=0,o2=0;int16_t model=-1;char label[9]={0};
 if(!base||!read||!actor||!object)return false;
 if(!read(ctx,base+0x2a89310,&a,8)||!a||a%8||!read(ctx,a+0x30,&o,8)||!o||o%8||
    !read(ctx,o+0x30,&n,8)||!n||!read(ctx,n,label,9)||memcmp(label,"raziel__",9)||
    !read(ctx,a+0x1c6,&model,2)||model!=0||!read(ctx,base+0x2a89310,&a2,8)||a2!=a||
    !read(ctx,a+0x30,&o2,8)||o2!=o)return false;
 *actor=a;*object=o;return true;
}
