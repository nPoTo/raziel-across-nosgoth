// External PROCESS_VM_READ only. Raw camera fields deliberately retain native layout.
#include "host-camera-proof.h"
static bool hostCameraGate(HANDLE p,uintptr_t base,DWORD size){
    if(size<HOST_CAMERA_LEGACY_RVA+0x100)return false;
    for(size_t k=0;k<ARRAYSIZE(hostCameraChecks);k++){
        unsigned char actual[32];
        if(!readAt(p,base+hostCameraChecks[k].rva,actual,hostCameraChecks[k].length)||memcmp(actual,hostCameraChecks[k].bytes,hostCameraChecks[k].length))return false;
    }
    return true;
}
static void hostCameraHex(FILE *out,const unsigned char *bytes,size_t size){fputc('"',out);for(size_t i=0;i<size;i++)fprintf(out,"%02x",bytes[i]);fputc('"',out);}
static void hostCameraObserve(FILE *out,HANDLE p,uintptr_t base,uintptr_t actor){
    unsigned char core[HOST_CAMERA_HD_BYTES],again[HOST_CAMERA_HD_BYTES],legacy[0x100],legacyAgain[0x100];
    const size_t offsets[]={0x88,0x90,0xa0,0xa8,0xb0};
    unsigned char matrices[5][52],matrixAgain[52];bool matrixOk[5]={false};uintptr_t after=0;
    bool ok=readAt(p,base+HOST_CAMERA_HD_RVA,core,sizeof(core))&&readAt(p,base+HOST_CAMERA_LEGACY_RVA,legacy,sizeof(legacy));
    if(ok)for(size_t i=0;i<ARRAYSIZE(offsets);i++){
        uintptr_t at=pointer(core+offsets[i]);
        matrixOk[i]=at>=0x10000&&at<=UINTPTR_MAX-52&&readAt(p,at,matrices[i],52)&&readAt(p,at,matrixAgain,52)&&!memcmp(matrices[i],matrixAgain,52);
    }
    ok=ok&&readAt(p,base+HOST_CAMERA_HD_RVA,again,sizeof(again))&&!memcmp(core,again,sizeof(core))&&
        readAt(p,base+HOST_CAMERA_LEGACY_RVA,legacyAgain,sizeof(legacyAgain))&&!memcmp(legacy,legacyAgain,sizeof(legacy))&&
        readAt(p,base+0x2a89310,&after,8)&&after==actor;
    fprintf(out,",\"cameraNative\":{\"valid\":%s,\"hdRva\":%u,\"legacyRva\":%u",ok?"true":"false",HOST_CAMERA_HD_RVA,HOST_CAMERA_LEGACY_RVA);
    if(ok){
        fprintf(out,",\"hdRawHex\":");hostCameraHex(out,core,sizeof(core));
        fprintf(out,",\"legacyCoreRawHex\":");hostCameraHex(out,legacy,sizeof(legacy));
        fprintf(out,",\"matrixCandidates\":[");
        for(size_t i=0;i<ARRAYSIZE(offsets);i++){
            if(i)fputc(',',out);
            fprintf(out,"{\"pointerOffset\":%zu,\"valid\":%s",offsets[i],matrixOk[i]?"true":"false");
            if(matrixOk[i]){fprintf(out,",\"rawHex\":");hostCameraHex(out,matrices[i],52);}
            fputc('}',out);
        }
        fputc(']',out);
    }
    fputc('}',out);
}
