// SPDX-License-Identifier: GPL-3.0-or-later
#include "host-contact-shared.h"
#include "host-contact-source.h"
#include "host-contact-reader.h"
#include <assert.h>
#include <stdio.h>
static HostContactLease lease(void){return (HostContactLease){.pid=42,.creation=123,.epoch=1000,.actor=0x1000};}
int main(void){
 HostContactShared m={0};HostContactSnapshot s={.magic=HOST_CONTACT_MAGIC,.version=1,.pid=42,.phase=1,.creation=123,.epoch=1000,.tick=1000,.sequence=1,.actor=0x1000,.control=0x519,.coherent=1},copy;
 hostContactStore(&m,&s);assert(hostContactCopy(&m,&copy)&&!memcmp(&s,&copy,sizeof(s)));
 m.guard=3;assert(!hostContactCopy(&m,&copy));m.guard=4;m.revoked=1;assert(!hostContactCopy(&m,&copy));m.revoked=0;
 HostContactLease l=lease();bool fresh=false;assert(hostContactAccept(&l,&s,1000,true,&fresh)&&fresh);
 assert(hostContactAccept(&l,&s,1001,true,&fresh)&&!fresh);
 s.phase=2;assert(!hostContactAccept(&l,&s,1001,true,&fresh)&&l.revoked);
 s.phase=1;assert(!hostContactAccept(&l,&s,1001,true,&fresh));
 for(unsigned fault=0;fault<10;fault++){
  HostContactSnapshot bad=s;l=lease();
  if(fault==0)bad.creation++;if(fault==1)bad.actor++;if(fault==2)bad.epoch++;if(fault==3)bad.pid++;
  if(fault==4)bad.sequence=0;if(fault==5)bad.phase=0;if(fault==6)bad.control|=0x4000000;
  if(fault==7)bad.coherent=0;if(fault==8)bad.version++;if(fault==9)bad.magic++;
  assert(!hostContactAccept(&l,&bad,1000,true,&fresh)&&l.revoked);
 }
 l=lease();assert(!hostContactAccept(&l,&s,1151,true,&fresh));
 l=lease();assert(!hostContactAccept(&l,&s,999,true,&fresh));
 l=lease();assert(!hostContactAccept(&l,&s,1000,false,&fresh));
 // Fresh compression is transport-valid but explicitly NOT grounded.
 l=lease();s.phase=3;s.control=0x101;for(unsigned i=0;i<3;i++)s.callbacks[i]=0xedb40;
 assert(hostContactAccept(&l,&s,1000,true,&fresh)&&fresh&&l.last.phase==3);
 l=lease();s.control=0x111;assert(hostContactAccept(&l,&s,1000,true,&fresh)&&fresh&&l.last.phase==3);
 for(unsigned bit=0;bit<32;bit++){HostContactSnapshot bad=s;bad.control^=1u<<bit;HostContactLease other=lease();assert(hostContactAccept(&other,&bad,1000,true,&fresh)==(bit==4));}
 s.sequence++;s.callbacks[1]=0xefb50;assert(!hostContactAccept(&l,&s,1001,true,&fresh));
 // Use a second view of the real Windows mapping; revocation is immediate even
 // if a producer had already begun constructing its next local snapshot.
 HostContactSource source={0},collision={0};assert(hostContactSourceOpen(&source,GetTickCount64()));
 assert(!hostContactSourceOpen(&collision,source.epoch));
 wchar_t name[96];hostContactMappingName(name,GetCurrentProcessId());
 HANDLE peer=OpenFileMappingW(FILE_MAP_READ,FALSE,name);assert(peer);
 const HostContactShared *view=MapViewOfFile(peer,FILE_MAP_READ,0,0,sizeof(*view));assert(view);
 s.phase=1;s.control=0x519;s.tick=source.epoch;s.sequence=1;
 hostContactSourcePublish(&source,s);assert(hostContactCopy(view,&copy));
 assert(copy.creation==source.creation&&copy.pid==GetCurrentProcessId()&&copy.epoch==source.epoch);
 HostContactLease expected={.pid=GetCurrentProcessId(),.creation=source.creation,.epoch=source.epoch,.actor=s.actor};
 HostContactReader reader={0},wrong={0};HostContactSnapshot received;
 HostContactLease wrongLifetime=expected;wrongLifetime.creation++;
 assert(!hostContactReaderOpen(&wrong,wrongLifetime)&&wrong.lease.revoked);
 assert(!hostContactReaderOpen(&wrong,expected));
 assert(hostContactReaderOpen(&reader,expected));
 assert(hostContactReaderRead(&reader,source.epoch,&received,&fresh)&&fresh&&received.actor==s.actor);
 assert(hostContactReaderRead(&reader,source.epoch,&received,&fresh)&&!fresh);
 HostContactReader stale={0};assert(hostContactReaderOpen(&stale,expected));
 assert(!hostContactReaderRead(&stale,source.epoch+151,&received,&fresh)&&stale.lease.revoked&&!received.actor);
 hostContactReaderClose(&stale);hostContactReaderClose(&stale);
 hostContactSourceStop(&source);assert(!hostContactCopy(view,&copy));
 assert(!hostContactReaderRead(&reader,source.epoch,&received,&fresh)&&reader.lease.revoked&&!received.actor);
 hostContactReaderClose(&reader);assert(!hostContactReaderOpen(&reader,expected));
 hostContactSourcePublish(&source,s);assert(!hostContactCopy(view,&copy));
 assert(!hostContactSourceOpen(&source,source.epoch+1));
 UnmapViewOfFile(view);CloseHandle(peer);UnmapViewOfFile(source.view);CloseHandle(source.mapping);
 puts("PASS contact RAM protocol: torn/foreign/stale/dead/replayed/mutated packets rejected; compression distinct from contact");
}
