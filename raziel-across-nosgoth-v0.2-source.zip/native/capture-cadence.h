// Absolute 60 Hz deadlines: skip overdue slots instead of accumulating read time.
static uint64_t captureNext60(uint64_t origin,uint64_t now,uint64_t frequency) {
    uint64_t elapsed=now>=origin?now-origin:0;
    uint64_t slot=elapsed*60/frequency+1;
    return origin+(slot*frequency+59)/60;
}
