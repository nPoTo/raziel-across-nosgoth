// Tests exercise the same forwarding/scope/allocation path as the live hooks.
static unsigned int ribbonMockForwards,ribbonMockTicks,ribbonMockContinuationCalls;
static bool ribbonMockNested,ribbonMockValid;
static uintptr_t __fastcall ribbonMockAllocator(uintptr_t tracker) {++ribbonMockForwards;return tracker+8;}
static uintptr_t ribbonMockAllocate(uintptr_t tracker,uintptr_t caller){
    // Synthetic ownership enters the actual production allocation path. The
    // separate real visibility-scope fixture proves HUD/actor lease admission.
    return ribbonAllocateRequested(tracker,caller,InterlockedCompareExchange(&ribbonRequested,0,0)!=0);
}
static void __fastcall ribbonMockContinuation(uintptr_t node,uintptr_t tracker) {
    ++ribbonMockContinuationCalls;++ribbonMockTicks;
    if(node==1){
        ribbonMockValid=ribbonMockValid&&ribbonMockAllocate(tracker,ribbonBase+0x52775)==0;
        ribbonMockValid=ribbonMockValid&&ribbonMockAllocate(tracker,ribbonBase+0x52854)==0;
        ribbonMockValid=ribbonMockValid&&ribbonMockAllocate(tracker,ribbonBase+0x519d0)==tracker+8;
        ribbonMockValid=ribbonMockValid&&ribbonMockAllocate(tracker+1,ribbonBase+0x52775)==tracker+9;
        if(ribbonMockNested)ribbonForward(2,tracker,false);
        ribbonMockValid=ribbonMockValid&&(uintptr_t)TlsGetValue(ribbonTls)==tracker;
    }else ribbonMockValid=ribbonMockValid&&ribbonMockAllocate(tracker,ribbonBase+0x52775)==tracker+8;
}
static DWORD WINAPI ribbonMockOtherThread(LPVOID unused) {
    (void)unused;return TlsGetValue(ribbonTls)==NULL&&ribbonMockAllocate(7,ribbonBase+0x52775)==15?0:1;
}
static bool testRibbonReplacement(void) {
    unsigned char raw[80]={0};uintptr_t callback=0x52560,owner=0x12340,pool=0x45670;int16_t four=4,one=1;
    memcpy(raw+8,&callback,8);memcpy(raw+16,&owner,8);memcpy(raw+0x30,&pool,8);memcpy(raw+0x28,&four,2);memcpy(raw+0x3a,&one,2);
    bool ok=ribbonNodeMatches(raw,callback,owner)&&!ribbonNodeMatches(raw,callback+1,owner)&&!ribbonNodeMatches(raw,callback,owner+1);
    raw[24]=1;ok=ok&&!ribbonNodeMatches(raw,callback,owner);raw[24]=0;raw[25]=2;
    ok=ok&&!ribbonNodeMatches(raw,callback,owner);raw[25]=0;raw[0x38]=1;ok=ok&&!ribbonNodeMatches(raw,callback,owner);raw[0x38]=0;
    ok=ok&&ribbonAllocationMatches(7,7,0x152775,0x100000,true)&&!ribbonAllocationMatches(7,7,0x152775,0x100000,false)&&
        !ribbonAllocationMatches(7,8,0x152775,0x100000,true)&&!ribbonAllocationMatches(7,7,0x152774,0x100000,true);
    ribbonTls=TlsAlloc();if(ribbonTls==TLS_OUT_OF_INDEXES)return false;
    ribbonBase=0x100000;originalRibbon=ribbonMockContinuation;originalRibbonAlloc=ribbonMockAllocator;
    InterlockedExchange(&ribbonRequested,1);ribbonMockValid=true;ribbonMockNested=true;
    ribbonForward(1,7,true);
    ok=ok&&ribbonMockValid&&ribbonMockTicks==2&&ribbonMockContinuationCalls==2&&ribbonMockForwards==3&&
        ribbonBlocked==2&&TlsGetValue(ribbonTls)==NULL;
    // A different thread cannot inherit an eligible continuation's TLS scope.
    TlsSetValue(ribbonTls,(PVOID)(uintptr_t)7);HANDLE thread=CreateThread(NULL,0,ribbonMockOtherThread,NULL,0,NULL);DWORD result=1;
    if(thread){WaitForSingleObject(thread,5000);GetExitCodeThread(thread,&result);CloseHandle(thread);}ok=ok&&thread&&result==0;
    ok=ok&&ribbonMockForwards==4;
    InterlockedExchange(&ribbonRequested,0);ok=ok&&ribbonMockAllocate(7,ribbonBase+0x52775)==15;
    // No actual owned visibility session is present in this DLL self-test.
    ok=ok&&ribbonAllocate(7,ribbonBase+0x52775)==15;
    InterlockedExchange(&ribbonRequested,1);InterlockedExchange(&ribbonFailed,1);ok=ok&&ribbonMockAllocate(7,ribbonBase+0x52775)==15;
    InterlockedExchange(&ribbonFailed,0);InterlockedExchange(&probeBoundedComplete,1);ok=ok&&ribbonMockAllocate(7,ribbonBase+0x52775)==15;
    InterlockedExchange(&probeBoundedComplete,0);TlsSetValue(ribbonTls,NULL);TlsFree(ribbonTls);ribbonTls=TLS_OUT_OF_INDEXES;
    originalRibbon=NULL;originalRibbonAlloc=NULL;ribbonBase=0;InterlockedExchange(&ribbonRequested,0);ribbonBlocked=0;
    return ok;
}
