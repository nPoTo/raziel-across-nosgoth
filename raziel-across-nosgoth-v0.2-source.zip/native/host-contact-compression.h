#pragma once
#include <stdint.h>
#include <stdbool.h>
static inline bool hostContactCompression(uint32_t control,const uint64_t cb[3]){
 return (control==0x101||control==0x111)&&cb[0]==0xedb40&&cb[1]==0xedb40&&cb[2]==0xedb40;
}
