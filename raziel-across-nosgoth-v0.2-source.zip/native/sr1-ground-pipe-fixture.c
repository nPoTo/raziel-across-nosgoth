// SPDX-License-Identifier: GPL-3.0-or-later
// Synthetic scalar command into a Node-owned mapping. Never a game test.
#define WIN32_LEAN_AND_MEAN
#include "sr1-ground-shared.h"
#include <stdio.h>
#include <stdlib.h>
#include <io.h>
#include <fcntl.h>
int main(int argc,char **argv){
 if(argc<3)return 1;DWORD pid=(DWORD)strtoul(argv[2],NULL,10);if(!pid)return 1;
 if(!strcmp(argv[1],"produce")){
  if(argc!=4)return 1;DWORD writer=(DWORD)strtoul(argv[3],NULL,10);uint64_t now=GetTickCount64();SkeletonGroundPacket s={.magic=0x31475a52,.version=1,.hostPid=pid,.sourcePid=GetCurrentProcessId(),.writerPid=writer,.active=1,.epoch=now,.tick=now,.hostTick=now,.sourceTick=now,.sequence=1,.actor=1,.object=2,.model=3,.forwardPerFactor=60};memcpy(s.policyHash,skeletonPolicyHash,32);
  _setmode(_fileno(stdout),_O_BINARY);if(fwrite(&s,sizeof(s),1,stdout)!=1||fflush(stdout))return 2;if(getchar()!=EOF)return 3;return 0;
 }
 if(strcmp(argv[1],"observe")||argc!=3)return 1;
 wchar_t name[96];skeletonGroundName(name,pid);uint64_t begin=GetTickCount64();HANDLE map=NULL;while(!map&&GetTickCount64()-begin<5000){map=OpenFileMappingW(FILE_MAP_READ,FALSE,name);if(!map)Sleep(1);}if(!map)return 4;
 const SkeletonGroundShared *view=MapViewOfFile(map,FILE_MAP_READ,0,0,sizeof(SkeletonGroundShared));if(!view){CloseHandle(map);return 5;}bool attached=false;int result=6;
 while(GetTickCount64()-begin<5000){SkeletonGroundPacket s;if(skeletonGroundCopy(view,&s)){if(!attached&&s.magic){if(!skeletonGroundValid(&s,pid,GetTickCount64())||!s.active||s.forwardPerFactor!=60){result=7;break;}attached=true;puts("{\"attached\":true}");fflush(stdout);}else if(attached&&!s.magic){puts("{\"cleared\":true}");fflush(stdout);result=0;break;}}Sleep(1);}
 UnmapViewOfFile(view);CloseHandle(map);return result;
}
