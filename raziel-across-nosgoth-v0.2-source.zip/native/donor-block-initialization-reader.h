// SPDX-License-Identifier: GPL-3.0-or-later
#pragma once
#include "donor-block-targets.h"
typedef struct {bool knownType,cleanup,initialized;} DonorBlockInitializationMetadata;
static inline bool donorBlockInitializationRead(void *c,DonorActionStateRead read,DonorActionStateCode code,uintptr_t base,uint32_t size,uintptr_t actor,bool after,DonorBlockInitializationMetadata *out){
 memset(out,0,sizeof(*out));const Sheet_donorBlockInitializationPolicy *p=&sheet_donorBlockInitializationPolicy_bounded;
 if(!actor||actor%8||base>UINTPTR_MAX-size||size<=p->knownCallbackRva||size<=p->initialHandlerRva)return false;
 uint32_t flags[2]={0};uintptr_t resource[2]={0},callback[2]={0},userdata[2]={0},handler[2]={0};uint16_t magic[2]={0},subtype[2]={0};
 for(unsigned i=0;i<2;i++){
  if(!donorBlockTargetReadField(c,read,actor,p->actorFlagsOffset,&flags[i],4)||!donorBlockTargetReadField(c,read,actor,p->actorResourceOffset,&resource[i],8)||!resource[i]||resource[i]%2||!donorBlockTargetReadField(c,read,resource[i],p->resourceMagicOffset,&magic[i],2)||!donorBlockTargetReadField(c,read,resource[i],p->resourceSubtypeOffset,&subtype[i],2))return false;
  // No userdata read before native initialization, or on any cleanup path.
  if(after&&!(flags[i]&p->cleanupMask)&&magic[i]==p->resourceMagic&&subtype[i]==p->resourceSubtype){
   if(!donorBlockTargetReadField(c,read,actor,p->actorCallbackOffset,&callback[i],8)||callback[i]!=base+p->knownCallbackRva||!code(c,callback[i],base)||!donorBlockTargetReadField(c,read,actor,p->actorUserdataOffset,&userdata[i],8)||!userdata[i]||userdata[i]%8||!donorBlockTargetReadField(c,read,userdata[i],p->userdataHandlerOffset,&handler[i],8)||handler[i]!=base+p->initialHandlerRva||!code(c,handler[i],base))return false;
  }
 }
 if(flags[0]!=flags[1]||resource[0]!=resource[1]||magic[0]!=magic[1]||subtype[0]!=subtype[1]||callback[0]!=callback[1]||userdata[0]!=userdata[1]||handler[0]!=handler[1])return false;
 // A final actor/resource bracket follows the only optional userdata reads.
 uint32_t finalFlags=0;uintptr_t finalResource=0;if(!donorBlockTargetReadField(c,read,actor,p->actorFlagsOffset,&finalFlags,4)||!donorBlockTargetReadField(c,read,actor,p->actorResourceOffset,&finalResource,8)||finalFlags!=flags[0]||finalResource!=resource[0])return false;
 out->knownType=magic[0]==p->resourceMagic&&subtype[0]==p->resourceSubtype;out->cleanup=(flags[0]&p->cleanupMask)!=0;out->initialized=after&&out->knownType&&!out->cleanup&&handler[0]==base+p->initialHandlerRva;return true;
}
