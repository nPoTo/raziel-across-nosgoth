#include "report-path.h"
// Default-off measured-curve experiment through the native paired controllers.
// No actor position, rotation, physics mode or native handler is overwritten.
#include "host-lock-proof.h"
#include "evade-packet.h"
static RootStateFn originalEvadeState;static PVOID evadeStateTarget;
static uintptr_t evadeModule,evadeOwner,evadeLastPlayer;
static RootController evadeSaved[2];static unsigned char evadeWritten[2][12];
static bool evadeOwned,evadeRequested,evadeAttempted,evadeFailed;
static volatile LONG evadeEnabled,evadeBusy;
static ULONGLONG evadeBegin,evadeLastTick,evadeLastSource,evadeLastEpisode;
static unsigned evadeFrames,evadeCalls,evadeGates[9];
static bool evadeReadFile(unsigned char packet[96]){
 DWORD got=0;LARGE_INTEGER size;HANDLE file=CreateFileW(PROBE_PATH(L"\\..\\assets\\raziel-evade.bin"),GENERIC_READ,FILE_SHARE_READ|FILE_SHARE_WRITE|FILE_SHARE_DELETE,NULL,OPEN_EXISTING,FILE_ATTRIBUTE_NORMAL,NULL);
 if(file==INVALID_HANDLE_VALUE)return false;bool ok=GetFileSizeEx(file,&size)&&size.QuadPart==96&&ReadFile(file,packet,96,&got,NULL)&&got==96;CloseHandle(file);return ok;
}
static bool (*evadeReadPacket)(unsigned char[96])=evadeReadFile;
static bool evadeOwnsControllers(void){return evadeOwned;}
static bool evadeRelease(uintptr_t state){
 if(!evadeOwned)return true;
 // Retain ownership on unrelated/stale state so the next real owner callback
 // can restore it. Never write through another actor's callback.
 if(!instantRootIdentity(state,evadeOwner))return false;
 bool ok=true;
 for(unsigned k=0;k<2;k++){
  if(!instantRootIdentity(state,evadeOwner)){ok=false;break;}
  RootController c;uintptr_t anim=evadeOwner+(k?0x448:0x328);
  bool found=rootControllerRead(evadeModule,anim,k,&c)&&c.found&&c.node==evadeSaved[k].node;
  if(!found){ok=false;continue;}
  // A native modification wins; never overwrite it with our old snapshot.
  if(!memcmp(c.vector,evadeWritten[k],k?12:6)){
   originalMotion[k](anim,0,34,(uintptr_t)evadeSaved[k].vector);
   if(!evadeSaved[k].active&&c.active)rootDisable[k](anim,0,34);
   RootController restored;
   if(!rootControllerRead(evadeModule,anim,k,&restored)||!restored.found||restored.node!=evadeSaved[k].node||restored.active!=evadeSaved[k].active||memcmp(restored.vector,evadeSaved[k].vector,k?12:6))ok=false;
  }
 }
 evadeOwned=false;evadeOwner=0;return ok;
}
static void evadeReleaseOnTransition(uintptr_t state){if(!evadeRelease(state)){evadeFailed=true;InterlockedExchange(&evadeEnabled,0);}}
static unsigned evadeScope(uintptr_t state,int32_t section,ULONGLONG now,ULONGLONG dt,uintptr_t *player,float v[2],uint64_t *source,uint64_t *episode){
 uintptr_t actor=0,process=0;float root[16];int32_t vz=0,time=0;DWORD foreground=0;XINPUT_STATE input={0};
 if(!InterlockedCompareExchange(&evadeEnabled,0,0)||evadeFailed||!InterlockedCompareExchange(&srCombatEnabled,0,0)||section||!evadeModule||now<evadeBegin||now-evadeBegin>=75000)return 1;
 if(!worldRoot(root,player)||!worldRead(state,&actor,8)||actor!=*player)return 2;
 if(!worldRead(state+0x10,&process,8)||(process!=evadeModule+HOST_LOCK_RVA&&!rootEligibleProcess(process)))return 3;
 if(!worldLastDraw||now<worldLastDraw||now-worldLastDraw>=250||worldLastInstance!=*player||root[10]<=.8f)return 4;
 if(!dt||dt>50||!worldRead(*player+0x2d4,&vz,4)||vz||!worldRead(evadeModule+0x2a89628,&time,4)||time<=0||time>8192)return 5;
 if(!originalSrInput||originalSrInput(0,&input)!=ERROR_SUCCESS||!(input.Gamepad.wButtons&XINPUT_GAMEPAD_LEFT_SHOULDER)||
    (input.Gamepad.wButtons&~(XINPUT_GAMEPAD_LEFT_SHOULDER|XINPUT_GAMEPAD_A))||input.Gamepad.bLeftTrigger>=30||input.Gamepad.bRightTrigger>=30)return 6;
 GetWindowThreadProcessId(GetForegroundWindow(),&foreground);if(foreground!=GetCurrentProcessId())return 7;
 unsigned char packet[96];if(!evadeReadPacket(packet)||!evadePacketVelocity(packet,sizeof(packet),now,overlayLivePid,overlayLiveTick,v,source,episode)||
    (evadeLastEpisode==*episode&&*source<evadeLastSource))return 8;
 for(unsigned k=0;k<2;k++)if(fabsf(v[k]*(float)dt)>240)return 8;
 return 0;
}
static bool evadeApply(uintptr_t state,uintptr_t player,const float step[2]){
 if(!instantRootIdentity(state,player))return false;
 RootController before[2],after[2];
 for(unsigned k=0;k<2;k++)if(!rootControllerRead(evadeModule,player+(k?0x448:0x328),k,&before[k])||!before[k].found)return false;
 evadeOwner=player;memcpy(evadeSaved,before,sizeof(before));evadeOwned=true;
 for(unsigned k=0;k<2;k++)memcpy(evadeWritten[k],before[k].vector,12);
 // Track each actual value written, including partial enable, for rollback.
 for(unsigned k=0;k<2;k++){
  if(!before[k].active)rootEnable[k](player+(k?0x448:0x328),0,34);
  if(!rootControllerRead(evadeModule,player+(k?0x448:0x328),k,&after[k])||!after[k].found||!after[k].active||after[k].node!=before[k].node){evadeRelease(state);return false;}
  memcpy(evadeWritten[k],after[k].vector,12);
 }
 int16_t small[3]={(int16_t)step[0],(int16_t)step[1],0};float wide[3]={step[0],step[1],0};
 for(unsigned k=0;k<2;k++){
  uintptr_t anim=player+(k?0x448:0x328),values=k?(uintptr_t)wide:(uintptr_t)small;
  originalMotion[k](anim,0,34,values);
  RootController c;
  if(!instantRootIdentity(state,player)||!rootControllerRead(evadeModule,anim,k,&c)||!c.found||!c.active||c.node!=before[k].node){evadeRelease(state);return false;}
  memcpy(evadeWritten[k],c.vector,12);
  if(memcmp(c.vector,(void *)values,k?12:6)){evadeRelease(state);return false;}
 }
 return true;
}
static void evadeAfterState(uintptr_t state,int32_t section){
 if(section||InterlockedCompareExchange(&evadeBusy,1,0))return;
 ULONGLONG now=GetTickCount64(),dt=0;uintptr_t beforePlayer=0;
 if(section==0){
  if(worldRead(state,&beforePlayer,8)){if(beforePlayer==evadeLastPlayer&&now>=evadeLastTick)dt=now-evadeLastTick;evadeLastTick=now;evadeLastPlayer=beforePlayer;}
 }
 uintptr_t player=0;float velocity[2];uint64_t source=0,episode=0;
 unsigned gate=evadeScope(state,section,now,dt,&player,velocity,&source,&episode);
 if(section==0&&InterlockedCompareExchange(&evadeEnabled,0,0)){++evadeCalls;++evadeGates[gate];}
 if(!gate){
  float step[2]={velocity[0]*(float)dt,velocity[1]*(float)dt};bool ok=evadeApply(state,player,step);
  if(ok){++evadeFrames;evadeLastSource=source;evadeLastEpisode=episode;}else{evadeFailed=true;InterlockedExchange(&evadeEnabled,0);}
  if(evadeFrames<=12||evadeFrames%15==0||!ok)logLine("SR1_EVADE_ROOT tick=%llu player=%p dt=%llu velocity=%.9g,%.9g step=%.9g,%.9g source=%llu episode=%llu ok=%u frames=%u; measured profile, native controller path",now,(void *)player,dt,velocity[0],velocity[1],step[0],step[1],source,episode,ok,evadeFrames);
 }
 InterlockedExchange(&evadeBusy,0);
}
static uintptr_t __fastcall observeEvadeState(uintptr_t state,int32_t section,uintptr_t data){
 if(section==0)evadeReleaseOnTransition(state);
 uintptr_t result=originalEvadeState(state,section,data);
 evadeAfterState(state,section);return result;
}
static void evadeInstall(HMODULE module){
 if(!module||evadeAttempted)return;evadeAttempted=true;
 if(!instantRootModule||!originalMotion[0]||!originalMotion[1]||!rootEnable[0]||!rootEnable[1])return;
 unsigned char code[HOST_LOCK_SIZE];char hash[65];uintptr_t target=(uintptr_t)module+HOST_LOCK_RVA;
 if(!worldRead(target,code,sizeof(code))||!hashBytes(code,sizeof(code),hash)||strcmp(hash,HOST_LOCK_SHA)){logLine("SR1_EVADE_ROOT code proof failed");return;}
 evadeModule=(uintptr_t)module;MH_STATUS create=MH_CreateHook((PVOID)target,(PVOID)&observeEvadeState,(PVOID *)&originalEvadeState),enable=create==MH_OK?MH_EnableHook((PVOID)target):create;
 if(enable==MH_OK){evadeStateTarget=(PVOID)target;rootOtherRelease=evadeReleaseOnTransition;rootOtherAfter=evadeAfterState;rootOtherOwnsControllers=evadeOwnsControllers;}logLine("SR1_EVADE_ROOT create=%d enable=%d full-code proof=1; default off",create,enable);
}
static void evadeTick(void){
 bool requested=evadeStateTarget&&GetFileAttributesW(PROBE_PATH(L"\\evade-sr1.enable"))!=INVALID_FILE_ATTRIBUTES&&GetFileAttributesW(PROBE_PATH(L"\\combat-input-sr1.enable"))!=INVALID_FILE_ATTRIBUTES&&GetFileAttributesW(PROBE_PATH(L"\\replace-sr1.enable"))!=INVALID_FILE_ATTRIBUTES;
 if(requested!=evadeRequested){evadeRequested=requested;evadeBegin=requested?GetTickCount64():0;
  if(requested){evadeCalls=evadeFrames=0;memset(evadeGates,0,sizeof(evadeGates));evadeLastEpisode=evadeLastSource=0;evadeFailed=false;}
  InterlockedExchange(&evadeEnabled,requested);logLine("SR1_EVADE_ROOT enabled=%u calls=%u frames=%u failed=%u gates=%u,%u,%u,%u,%u,%u,%u,%u,%u",requested,evadeCalls,evadeFrames,evadeFailed,evadeGates[0],evadeGates[1],evadeGates[2],evadeGates[3],evadeGates[4],evadeGates[5],evadeGates[6],evadeGates[7],evadeGates[8]);}
}
static void evadeStop(void){InterlockedExchange(&evadeEnabled,0);if(!evadeOwned&&evadeStateTarget)MH_DisableHook(evadeStateTarget);}
