// SPDX-License-Identifier: GPL-3.0-or-later
#include <assert.h>
#include <stdio.h>
#include "sr1-native-exit-reader.h"
typedef struct {unsigned char actor[0x600],info[6][0x18];unsigned calls,mutateAt,failAt;} Fixture;
static bool readFixture(void *p,uintptr_t address,void *out,SIZE_T n){
 Fixture *f=p;f->calls++;if(f->calls==f->failAt)return false;
 unsigned char *src=NULL;
 if(address>=0x1000&&address+n<=0x1600)src=f->actor+address-0x1000;
 for(unsigned i=0;i<6;i++)if(address>=0x2000+i*0x100&&address+n<=0x2018+i*0x100)src=f->info[i]+address-(0x2000+i*0x100);
 if(!src)return false;memcpy(out,src,n);if(f->calls==f->mutateAt)((unsigned char *)out)[0]^=1;return true;
}
static void setup(Fixture *f){memset(f,0,sizeof(*f));for(unsigned i=0;i<6;i++){uintptr_t p=0x2000+i*0x100;memcpy(f->actor+(i<3?0x358:0x480)+(i%3)*0x50+0x48,&p,8);}}
int main(void){
 Fixture f;Sr1NativeExitSample out;setup(&f);assert(sr1NativeExitRead(&f,readFixture,0x1000,&out)&&!sr1NativeExitBlending(&out));assert(f.calls==36);
 for(unsigned i=0;i<6;i++){setup(&f);f.info[i][0x10]=1;assert(sr1NativeExitRead(&f,readFixture,0x1000,&out)&&sr1NativeExitBlending(&out));}
 for(unsigned i=1;i<=36;i++){setup(&f);f.failAt=i;assert(!sr1NativeExitRead(&f,readFixture,0x1000,&out));}
 for(unsigned i=19;i<=36;i++){setup(&f);f.mutateAt=i;assert(!sr1NativeExitRead(&f,readFixture,0x1000,&out));}
 setup(&f);memset(f.actor+0x3a0,0,8);assert(sr1NativeExitRead(&f,readFixture,0x1000,&out)&&!sr1NativeExitBlending(&out));
 Sr1NativeExitLatch latch={0};memset(&out,0,sizeof(out));
 assert(sr1NativeExitAdmit(&latch,true,true,false,false,NULL)); // Existing mod locomotion unaffected.
 assert(!sr1NativeExitAdmit(&latch,true,false,false,true,&out)&&!latch.nativeOwned); // Refused pose is not a native mechanic.
 assert(!sr1NativeExitAdmit(&latch,true,false,true,true,&out)&&latch.nativeOwned);
 assert(!sr1NativeExitAdmit(&latch,false,true,false,true,&out)&&latch.nativeOwned);
 assert(!sr1NativeExitAdmit(&latch,true,true,false,false,&out)&&latch.nativeOwned);
 out.active[2]=1;assert(!sr1NativeExitAdmit(&latch,true,true,false,true,&out)&&latch.nativeOwned);
 out.active[2]=0;assert(sr1NativeExitAdmit(&latch,true,true,false,true,&out)&&!latch.nativeOwned);
 Sr1RetargetContext context={.identity=true};
 const uint32_t mechanics[]={0xeded0,0xefb50,0xf48e0,0xf1ad0,0xecf70,0xf8c80,0xf8e90,0xf0240,0xf4490,0xeeb40};
 for(unsigned i=0;i<sizeof(mechanics)/sizeof(*mechanics);i++){context.callbacks[1]=mechanics[i];assert(sr1NativeActionActive(&context));}
 const uint32_t ordinary[]={0xf2180,0xf3280,0xf54d0,0xedb40,0xee600,0xef480,0xf2ae0,0xdead};
 for(unsigned i=0;i<sizeof(ordinary)/sizeof(*ordinary);i++){context.callbacks[1]=ordinary[i];assert(!sr1NativeActionActive(&context));}
 context.crouchHeld=true;assert(sr1NativeActionActive(&context));context.crouchHeld=false;
 context.mode=1;assert(sr1NativeActionActive(&context));context.mode=0;context.flags=0x10000000;assert(sr1NativeActionActive(&context));context.identity=false;assert(!sr1NativeActionActive(&context));
 puts("PASS read-only legacy+HD section exit candidate: each active section blocks, torn/unreadable reads refuse, native ownership retained until completion. Not gameplay.");return 0;
}
