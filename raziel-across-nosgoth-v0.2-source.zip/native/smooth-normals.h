// SPDX-License-Identifier: GPL-3.0-or-later
// Area-weighted posed normals. Existing vertex splits remain intact.
static void smoothNormals(const float *positions, const uint32_t *indices,
                          uint32_t vertices, uint32_t count, float *normals) {
    memset(normals,0,(size_t)vertices*3*sizeof(float));
    for(uint32_t i=0;i<count;i+=3) {
        uint32_t a=indices[i],b=indices[i+1],c=indices[i+2];
        float u[3],v[3],n[3];
        for(int k=0;k<3;++k) {u[k]=positions[b*3+k]-positions[a*3+k];v[k]=positions[c*3+k]-positions[a*3+k];}
        n[0]=u[1]*v[2]-u[2]*v[1];n[1]=u[2]*v[0]-u[0]*v[2];n[2]=u[0]*v[1]-u[1]*v[0];
        for(int k=0;k<3;++k) {normals[a*3+k]+=n[k];normals[b*3+k]+=n[k];normals[c*3+k]+=n[k];}
    }
    for(uint32_t i=0;i<vertices;++i) {
        float *n=normals+i*3, length=sqrtf(n[0]*n[0]+n[1]*n[1]+n[2]*n[2]);
        if(isfinite(length) && length>1e-12f) for(int k=0;k<3;++k) n[k]/=length;
        else {n[0]=0;n[1]=0;n[2]=1;}
    }
}
