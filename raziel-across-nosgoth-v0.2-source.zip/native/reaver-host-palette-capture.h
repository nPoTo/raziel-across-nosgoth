// SPDX-License-Identifier: GPL-3.0-or-later
#pragma once
#include "reaver-joint-palette.h"
static _Thread_local ReaverJointPalette reaverHostPalette;
static inline void reaverHostCapturePalette(uintptr_t base){
 memset(&reaverHostPalette,0,sizeof(reaverHostPalette));
 const Sheet_reaverPalettePolicy *p=&sheet_reaverPalettePolicy_submitted_gpu_palette;
 if(!base||!reaverHostHand.valid||!reaverHostContext||wglGetCurrentContext()!=reaverHostContext||p->nativeIntegrationEnabled||
 p->countRva!=0x5aa3264||p->paletteRva!=0x5aa3300)return;
 unsigned before=0,after=0;float a[96*12],b[96*12];
 if(!worldRead(base+p->countRva,&before,sizeof(before))||!before||before>96||
 !worldRead(base+p->paletteRva,a,before*48)||!worldRead(base+p->paletteRva,b,before*48)||
 !worldRead(base+p->countRva,&after,sizeof(after))||wglGetCurrentContext()!=reaverHostContext)return;
 reaverPaletteCapture(&reaverHostPalette,&reaverHostHand,(uint64_t)(uintptr_t)reaverHostContext,a,before,b,after,true);
}
