#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <stdint.h>
#include <stdbool.h>
#include <stdio.h>
#include <string.h>
#include "MinHook.h"
#define PROBE_REPORT_DIR L"."
static void logLine(const char *fmt,...){(void)fmt;}
static bool worldRead(uintptr_t p,void *out,size_t n){if(p<0x100000)return false;memcpy(out,(void *)p,n);return true;}
static uintptr_t testPlayer;
static ULONGLONG testNow=1000;
static ULONGLONG testTick(void){return testNow;}
#define GetTickCount64 testTick
static DWORD testForeground(HWND window,LPDWORD pid){(void)window;*pid=GetCurrentProcessId();return 1;}
#define GetWindowThreadProcessId testForeground
static bool overlayAirSupport;
static ULONGLONG overlayLiveTick,worldLastDraw,srJumpLaunch;
static uintptr_t srJumpPlayer,worldLastInstance;
static float srJumpBaseZ;
static bool worldRoot(float *root,uintptr_t *player){memset(root,0,16*sizeof(float));root[10]=1;root[14]=*(int16_t *)(testPlayer+0xa0);*player=testPlayer;return true;}
static bool hashBytes(const void *p,ULONG n,char *out){(void)p;(void)n;(void)out;return false;}
#include "physics-probe.h"
static unsigned calls;static int32_t args[3];
static void __fastcall mockPhysics(uintptr_t player,int32_t segment,int32_t time,int32_t clamp){
 ++calls;args[0]=segment;args[1]=time;args[2]=clamp;
 int32_t *v=(int32_t *)(player+0x2cc);int16_t *pos=(int16_t *)(player+0x9c);
 pos[0]+=(int16_t)v[0];if(!clamp)pos[2]+=(int16_t)(v[2]+v[5]/2);v[2]+=v[5];
}
#define CHECK(x) do{if(!(x)){printf("FAIL line %d\n",__LINE__);return 1;}}while(0)
int main(void){
 unsigned char fixture[1024]={0};testPlayer=(uintptr_t)fixture;originalPhysics=mockPhysics;
 int32_t *v=(int32_t *)(fixture+0x2cc);int16_t *pos=(int16_t *)(fixture+0x9c);
 v[2]=120;v[5]=-16;pos[2]=-4828;
 observePhysics(testPlayer,1,4096,0);CHECK(calls==1&&v[2]==104&&pos[2]==-4716&&physicsHead==0);
 physicsEnabled=1;observePhysics(testPlayer,2,4096,0);
 CHECK(calls==2&&args[0]==2&&args[1]==4096&&args[2]==0&&v[2]==88&&pos[2]==-4620);
 CHECK(physicsHead==1&&physicsQueue[0].pre[2]==104&&physicsQueue[0].post[2]==88&&physicsQueue[0].before[2]==-4716&&physicsQueue[0].after[2]==-4620);
 observePhysics(testPlayer,3,2048,1);CHECK(calls==3&&args[2]==1&&pos[2]==-4620&&v[2]==72&&physicsHead==2);
 physicsLock=1;observePhysics(testPlayer,4,4096,0);physicsLock=0;CHECK(calls==4&&physicsDrops==1);
 physicsRecords=2500;observePhysics(testPlayer,5,4096,0);CHECK(calls==5&&physicsHead==2);
 physicsRecords=0;physicsEnabled=airHoldEnabled=1;airHoldBegin=900;
 overlayAirSupport=true;overlayLiveTick=worldLastDraw=980;srJumpLaunch=950;srJumpPlayer=worldLastInstance=testPlayer;srJumpBaseZ=-4828;
 v[0]=7;v[2]=-40;v[5]=-16;pos[0]=0;pos[2]=-4400;
 observePhysics(testPlayer,0,4096,0);CHECK(calls==6&&args[2]==1&&pos[0]==7&&pos[2]==-4400&&v[2]==0&&v[5]==-16);
 CHECK(physicsQueue[2].held&&physicsQueue[2].zeroed&&physicsQueue[2].post[2]==0);
 overlayAirSupport=false;observePhysics(testPlayer,0,4096,0);CHECK(calls==7&&args[2]==0&&pos[0]==14&&pos[2]==-4408&&v[2]==-16);
 physicsTick();physicsStop();physicsInstall(NULL);
 puts("Physics: default forwarding, recording limits; eligible air clamp keeps horizontal motion, zeroes vertical speed, missing hint restores fall PASS");return 0;
}
