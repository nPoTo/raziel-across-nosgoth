// SPDX-License-Identifier: GPL-3.0-or-later
#include <assert.h>
#include <stdio.h>
#include "rig-rejection-diagnostic.h"
static uint64_t value=7;static bool fail;
static bool fixture(void *c,uintptr_t at,void *out,SIZE_T n){(void)c;(void)at;if(fail)return false;memcpy(out,&value,n);return true;}
int main(void){
 HostRig a={.count=2,.parents={-1,0}},b=a;assert(rigDiagnosticDiff(&a,&b)==0);
 size_t offsets[]={offsetof(HostRig,actor),offsetof(HostRig,object),offsetof(HostRig,name),offsetof(HostRig,list),offsetof(HostRig,model),offsetof(HostRig,segments),offsetof(HostRig,legacy),offsetof(HostRig,render)};
 for(unsigned i=0;i<8;i++){b=a;uintptr_t changed=8;memcpy((char*)&b+offsets[i],&changed,8);assert(rigDiagnosticDiff(&a,&b)==(1u<<i));}
 b=a;b.modelIndex=1;assert(rigDiagnosticDiff(&a,&b)==256);b=a;b.count=1;assert(rigDiagnosticDiff(&a,&b)==1536);b=a;b.parents[1]=-1;assert(rigDiagnosticDiff(&a,&b)==1024);
 RigContextTrace t={.read=fixture};uint64_t out=0;assert(rigContextTraceRead(&t,1,&out,8)&&!t.changed);value=8;assert(rigContextTraceRead(&t,1,&out,8)&&t.changed==1);fail=true;assert(!rigContextTraceRead(&t,2,&out,8)&&t.failed==2);
 puts("PASS: each identity/buffer/topology difference and context change/read failure is distinguished without pointer or matrix serialization.");return 0;
}
