// SPDX-License-Identifier: GPL-3.0-or-later
#pragma once
#include <stdint.h>
#include <stdbool.h>
// Only presentation ownership. A body admission mode, donor receipt, draw count
// or pose failure is deliberately absent from this bounded lifetime contract.
typedef struct {
 bool requested,healthy,complete,originalModel;
 uint32_t writer;
 uint64_t session,begin,now;
 uintptr_t actor,object,model;
} Sr1WeaponSessionObservation;
typedef struct {
 bool pinned,ended;
 uint32_t writer;
 uint64_t session,begin,lastNow;
 uintptr_t actor,object,model;
} Sr1WeaponSession;
static inline bool sr1WeaponSessionStep(Sr1WeaponSession *s,const Sr1WeaponSessionObservation *o,uint64_t budget){
 if(!s||!o||!budget||s->ended)return false;
 bool healthy=o->requested&&o->healthy&&!o->complete&&o->writer&&o->session&&o->begin&&o->now>=o->begin&&o->now-o->begin<budget;
 if(!healthy){if(s->pinned)s->ended=true;return false;}
 // An unreadable current identity grants no suppression. Keep the pinned
 // owner for retry; it may never be replaced by another actor/model below.
 if(!o->originalModel||!o->actor||!o->object||!o->model)return false;
 if(!s->pinned){s->pinned=true;s->writer=o->writer;s->session=o->session;s->begin=o->begin;s->actor=o->actor;s->object=o->object;s->model=o->model;}
 if(o->writer!=s->writer||o->session!=s->session||o->begin!=s->begin||o->now<s->lastNow||o->actor!=s->actor||o->object!=s->object||o->model!=s->model){s->ended=true;return false;}
 s->lastNow=o->now;return true;
}
