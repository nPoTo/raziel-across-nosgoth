// SPDX-License-Identifier: GPL-3.0-or-later
// Pagefile-backed, host-PID-scoped transport. No filesystem asset cache.
#ifndef RENDER_MEMORY_H
#define RENDER_MEMORY_H
#include <windows.h>
#include <stdint.h>
#include <stdbool.h>
#include <stdio.h>
#include <string.h>
#ifdef SR1_RETARGET_PREVIEW
#include "sr1-render-profile.h"
#define RM_GEOMETRY_BYTES (16u+SR1_PROFILE_VERTICES*12u+SR1_PROFILE_INDICES*4u)
#define RM_APPEARANCE_BYTES (48u+SR1_PROFILE_VERTICES*12u+SR1_PROFILE_TEXTURES*512u*512u)
#define RM_LIVE_BYTES (96u+SR1_PROFILE_VERTICES*12u)
#define RM_MAGIC SR1_PROFILE_MAP_MAGIC
#define RM_VERSION 3u
#else
#define RM_GEOMETRY_BYTES (16u+24135u*12u+125790u*4u)
#define RM_APPEARANCE_BYTES (48u+24135u*12u+8u*512u*512u*4u)
#define RM_LIVE_BYTES (64u+24135u*12u)
#define RM_MAGIC 0x324d5a52u
#define RM_VERSION 2u
#endif
#define RM_MOVEMENT_BYTES 80u
typedef struct {
    uint32_t magic,version,hostPid,writerPid,online,geometryBytes,appearanceBytes,liveBytes;
    unsigned char movement[RM_MOVEMENT_BYTES];
    unsigned char geometry[RM_GEOMETRY_BYTES];
    unsigned char appearance[RM_APPEARANCE_BYTES];
    unsigned char live[RM_LIVE_BYTES];
} RenderMemory;
static inline void renderMemoryNames(DWORD pid,wchar_t map[96],wchar_t mutex[96]) {
#ifdef SR1_RETARGET_PREVIEW
    swprintf(map,96,L"Local\\LOKSr1RetargetMemory-v3-%lu",pid);
    swprintf(mutex,96,L"Local\\LOKSr1RetargetMutex-v3-%lu",pid);
#else
    swprintf(map,96,L"Local\\LOKRenderMemory-v2-%lu",pid);
    swprintf(mutex,96,L"Local\\LOKRenderMutex-v2-%lu",pid);
#endif
}
static inline bool renderMemoryHeader(const RenderMemory *m,DWORD pid) {
    return m&&m->magic==RM_MAGIC&&m->version==RM_VERSION&&m->hostPid==pid&&m->writerPid&&m->online==1&&m->geometryBytes==RM_GEOMETRY_BYTES&&m->appearanceBytes==RM_APPEARANCE_BYTES&&m->liveBytes==RM_LIVE_BYTES;
}
// Independent handles: gameplay callbacks never mutate the render reader's state.
// Only the first page (header + command) is mapped; all waits are nonblocking.
static inline bool renderMemoryMovementCopy(unsigned char output[RM_MOVEMENT_BYTES]) {
    if(!output)return false;
    wchar_t name[96],mutexName[96];renderMemoryNames(GetCurrentProcessId(),name,mutexName);
    HANDLE map=OpenFileMappingW(FILE_MAP_READ,FALSE,name);
    if(!map)return false;
    HANDLE lock=OpenMutexW(SYNCHRONIZE|MUTEX_MODIFY_STATE,FALSE,mutexName);
    const RenderMemory *view=lock?MapViewOfFile(map,FILE_MAP_READ,0,0,32+RM_MOVEMENT_BYTES):NULL;
    bool ok=false;
    if(view){DWORD wait=WaitForSingleObject(lock,0);
        if(wait==WAIT_OBJECT_0){
            if(renderMemoryHeader(view,GetCurrentProcessId())){
                HANDLE writer=OpenProcess(SYNCHRONIZE,FALSE,view->writerPid);
                if(writer){ok=WaitForSingleObject(writer,0)==WAIT_TIMEOUT;if(ok)memcpy(output,view->movement,RM_MOVEMENT_BYTES);CloseHandle(writer);}
            }
            ReleaseMutex(lock);
        }else if(wait==WAIT_ABANDONED)ReleaseMutex(lock);
        UnmapViewOfFile(view);
    }
    if(lock)CloseHandle(lock);CloseHandle(map);return ok;
}
#endif
