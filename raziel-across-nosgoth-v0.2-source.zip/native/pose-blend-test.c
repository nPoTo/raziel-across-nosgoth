#include <stdint.h>
#include <stdbool.h>
#include <stddef.h>
#include <stdio.h>
#include <string.h>
#include <math.h>
#include "pose-blend.h"
#define CHECK(x) do {if(!(x)){printf("FAIL line %d\n",__LINE__);return 1;}}while(0)
int main(void) {
    float from[3],target[3],display[3],a[]={0,0,0},b[]={48,96,-48};
    PoseBlend blend={0};blend.from=from;blend.target=target;blend.display=display;blend.count=3;
    CHECK(poseBlendAccept(&blend,a,7,1000,1010));
    CHECK(poseBlendAccept(&blend,b,7,1048,1058));
    CHECK(poseBlendStep(&blend,1074)&&display[0]==16&&display[1]==32);
    CHECK(poseBlendStep(&blend,1090)&&display[0]==32&&display[2]==-32);
    CHECK(poseBlendStep(&blend,1106)&&display[0]==48&&!blend.active);
    CHECK(!poseBlendStep(&blend,1122));
    // Repeated packet must not restart the interpolation. Invalid input must
    // leave all display/target/timing state intact.
    CHECK(!poseBlendAccept(&blend,b,7,1048,1122));
    b[0]=NAN;CHECK(!poseBlendAccept(&blend,b,7,1096,1122)&&display[0]==48&&target[0]==48&&blend.sourceTick==1048);b[0]=96;
    CHECK(poseBlendAccept(&blend,b,7,1096,1122));
    CHECK(poseBlendStep(&blend,1138)&&display[0]==64);
    b[0]=144;CHECK(poseBlendAccept(&blend,b,7,1144,1138)==false); // future packet
    CHECK(poseBlendAccept(&blend,b,7,1144,1154)&&display[0]==80); // continuous transition
    CHECK(poseBlendStep(&blend,1202)&&display[0]==144);
    b[0]=300;CHECK(poseBlendAccept(&blend,b,8,1200,1205)&&display[0]==300&&!blend.active); // donor restart
    b[0]=400;CHECK(poseBlendAccept(&blend,b,8,1800,1810)&&display[0]==400&&!blend.active); // long gap snaps
    CHECK(!poseBlendAccept(&blend,a,8,1801,2400)); // stale
    puts("Pose blend PASS: 60Hz intermediate samples, continuity, invalid/repeated/stale rejection, donor restart, gap reset, hold");return 0;
}
