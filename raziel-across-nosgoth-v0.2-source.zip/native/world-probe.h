#include "report-path.h"
// Diagnostic world clone, enabled explicitly in SR1 gameplay. No controller writes.
#include "host-transform.h"
static unsigned int worldDraws;
static ULONGLONG worldLastDraw;
// Scalar diagnostics only. Render callbacks increment counters; the existing
// worker writes once per second, without adding file I/O to these early exits.
static volatile LONG worldGateCounts[8];
static void worldGate(unsigned reason){if(reason<ARRAYSIZE(worldGateCounts))InterlockedIncrement(&worldGateCounts[reason]);}
static void worldGateFlush(void){
 LONG counts[8];for(unsigned k=0;k<ARRAYSIZE(counts);k++)counts[k]=InterlockedExchange(&worldGateCounts[k],0);
 if(GetFileAttributesW(PROBE_PATH(L"\\world-sr1.enable"))==INVALID_FILE_ATTRIBUTES)return;
 logLine("WORLD_GATES success=%ld stale_pose=%ld readiness=%ld root_snapshot=%ld framebuffer=%ld camera_matrix=%ld invalid_mvp=%ld disabled=%ld; scalar diagnostic only",counts[0],counts[1],counts[2],counts[3],counts[4],counts[5],counts[6],counts[7]);
}
static uintptr_t worldLastInstance;
static void (*worldAuthorityModel)(float[16],uintptr_t);
static void (*worldFrameAudit)(const float[16],const float[16],uintptr_t);
static void (*worldCameraModel)(float[16],uintptr_t);
static bool worldRead(uintptr_t address,void *out,SIZE_T size) {SIZE_T actual=0; return address&&ReadProcessMemory(GetCurrentProcess(),(LPCVOID)address,out,size,&actual)&&actual==size;}
#include "world-actor.h"
static uintptr_t worldPointer(const unsigned char *b) {uintptr_t v; memcpy(&v,b,8); return v;}
static bool worldRoot(float model[16],uintptr_t *instanceOut) {
    if(!InterlockedCompareExchangePointer(&verifiedSr1Module,NULL,NULL)) return false;
    uintptr_t base=(uintptr_t)InterlockedCompareExchangePointer(&verifiedSr1Module,NULL,NULL),instance=0,after=0,name=0;
    unsigned char bytes[384],raw[32]; char objectName[9]; 
    if(!worldRead(base+0x2a89310,&instance,8)||!worldRead(instance,bytes,sizeof(bytes))||
        !worldRead(worldPointer(bytes+0x30)+0x30,&name,8)||!worldRead(name,objectName,9)||memcmp(objectName,"raziel__",9)||
        !worldRead(worldPointer(bytes+0x68),raw,sizeof(raw))||!worldRead(base+0x2a89310,&after,8)||after!=instance||!decodeHostRoot(raw,model)) return false;
    uintptr_t objectAfter=0,matrixAfter=0;
    if(!worldRead(instance+0x30,&objectAfter,8)||objectAfter!=worldPointer(bytes+0x30)||!worldRead(instance+0x68,&matrixAfter,8)||matrixAfter!=worldPointer(bytes+0x68)) return false;
    *instanceOut=instance;return true;
}
static bool worldRenderRoot(float model[16],uintptr_t *instanceOut) {
    if(!worldRoot(model,instanceOut))return false;
    uintptr_t base=(uintptr_t)InterlockedCompareExchangePointer(&verifiedSr1Module,NULL,NULL),matrix=0,after=0,owner=0;unsigned char raw[52],again[52];
    // Exact-build actor+70 -> R9 packed float matrices, consumed at40d10.
    // Control/physics retains the legacy root through worldRoot.
    static const struct {uintptr_t rva;unsigned char bytes[5];unsigned length;} proof[]={
        {0x41ed7,{0x48,0x8b,0x41,0x70},4},{0x42947,{0x4c,0x8b,0x4c,0x24,0x60},5},
        {0x4297e,{0xe8,0x8d,0xe3,0xff,0xff},5},{0x40dac,{0x49,0x8d,0x45,0x08},4},
        {0x40dd5,{0xf3,0x0f,0x10,0x48,0x20},5},{0x40dff,{0xf3,0x0f,0x10,0x58,0x24},5},
        {0x40e2d,{0xf3,0x0f,0x10,0x78,0x28},5},{0x40ea9,{0x48,0x83,0xc0,0x34},4}};
    for(unsigned k=0;k<sizeof(proof)/sizeof(proof[0]);k++){unsigned char code[5];if(!worldRead(base+proof[k].rva,code,proof[k].length)||memcmp(code,proof[k].bytes,proof[k].length))return false;}
    if(!worldRead(*instanceOut+0x70,&matrix,8)||!worldRead(matrix,raw,52)||!worldRead(matrix,again,52)||memcmp(raw,again,52)||!worldRead(*instanceOut+0x70,&after,8)||matrix!=after||!worldRead(base+0x2a89310,&owner,8)||owner!=*instanceOut)return false;
    return decodeHostRenderRoot(raw,model);
}
#ifdef SR1_RETARGET_PREVIEW
#include "sr1-retarget-gate.h"
#include "sr1-weapon-visibility.h"
// Weapon visual ownership is independent of the current body pose. In
// particular native crouch/flight must not make the original blade reappear.
// This lease never refreshes worldLastDraw or grants body/root authority.
static bool sr1RetargetWeaponScope(uintptr_t actor){
 const Sheet_rigRead *layout=&sheet_rigRead_current;
 const Sheet_retargetWeaponPresentation *policy=&sheet_retargetWeaponPresentation_scope;
 uintptr_t base=(uintptr_t)InterlockedCompareExchangePointer(&verifiedSr1Module,NULL,NULL),owner=0,object=0,list=0,model=0,again=0;int16_t index=-1,indexAfter=-1;
 if(!base||!actor||actor!=overlayHostActor||!policy->healthyLeaseRequired||!policy->allVisualFlagsRequired||policy->nativePoseRequired||!policy->currentOriginalModelRequired||policy->hostPhysicsWrites)return false;
 Sr1WeaponVisibility s={.requested=GetFileAttributesW(PROBE_PATH(L"\\world-sr1.enable"))!=INVALID_FILE_ATTRIBUTES&&
  GetFileAttributesW(PROBE_PATH(L"\\replace-sr1.enable"))!=INVALID_FILE_ATTRIBUTES&&
  GetFileAttributesW(PROBE_PATH(L"\\hide-reaver-sr1.enable"))!=INVALID_FILE_ATTRIBUTES&&
  GetFileAttributesW(PROBE_PATH(L"\\hide-reaver-light-sr1.enable"))!=INVALID_FILE_ATTRIBUTES&&
  GetFileAttributesW(PROBE_PATH(L"\\hide-reaver-ribbon-sr1.enable"))!=INVALID_FILE_ATTRIBUTES,
  .healthyLease=lifetimeBudgetStatus(GetTickCount64())==1,.complete=InterlockedCompareExchange(&probeBoundedComplete,0,0)!=0,
  .expectedActor=overlayHostActor,.expectedObject=overlayHostObject,.expectedModel=overlayHostModel};
 if(!s.requested||!s.healthyLease||s.complete||!worldRead(base+layout->actorGlobalRva,&owner,8)||owner!=actor||
  !worldRead(actor+layout->actorCurrentModelOffset,&index,2)||index!=0||
  !worldRead(actor+layout->actorObjectOffset,&object,8)||object!=s.expectedObject||
  !worldRead(object+layout->objectModelsOffset,&list,8)||!list||!worldRead(list,&model,8)||model!=s.expectedModel||
  !worldRead(actor+layout->actorObjectOffset,&again,8)||again!=object||
  !worldRead(object+layout->objectModelsOffset,&again,8)||again!=list||!worldRead(list,&again,8)||again!=model||
  !worldRead(actor+layout->actorCurrentModelOffset,&indexAfter,2)||indexAfter!=index||
  !worldRead(base+layout->actorGlobalRva,&again,8)||again!=owner)return false;
 s.actor=owner;s.object=object;s.model=model;s.originalModel=true;return sr1WeaponVisibilityAllowed(&s);
}
static bool sr1RetargetAllowed(uintptr_t actor){
 uintptr_t base=(uintptr_t)InterlockedCompareExchangePointer(&verifiedSr1Module,NULL,NULL),owner=0,again=0,callbacks[3];uint16_t mode=0,modeAfter=0;uint32_t flags=0,flagsAfter=0;int32_t velocity=0,velocityAfter=0;DWORD foreground=0;
 GetWindowThreadProcessId(GetForegroundWindow(),&foreground);
 Sr1RetargetContext s={.foreground=foreground==GetCurrentProcessId()};
 const Sheet_retargetNativeAirGuard *air=&sheet_retargetNativeAirGuard_sr1;
 if(!base||!actor||air->verticalVelocityOffset!=0x2d4||air->verticalVelocityBytes!=4||!air->zeroVerticalVelocityRequired||air->hostWrites||!worldRead(base+0x2a88588,&owner,8)||owner!=actor||!worldRead(base+0x2a89536,&mode,2)||!worldRead(base+0x2a8950c,&flags,4)||!worldRead(actor+air->verticalVelocityOffset,&velocity,4))return false;
 for(unsigned i=0;i<3;i++){if(!worldRead(base+0x2a88598+i*0x228,&callbacks[i],8)||callbacks[i]<base||callbacks[i]-base>UINT32_MAX)return false;s.callbacks[i]=(uint32_t)(callbacks[i]-base);}
 if(!worldRead(base+0x2a89310,&again,8)||again!=actor||!worldRead(base+0x2a88588,&again,8)||again!=owner||!worldRead(base+0x2a89536,&modeAfter,2)||modeAfter!=mode||!worldRead(base+0x2a8950c,&flagsAfter,4)||flagsAfter!=flags||!worldRead(actor+air->verticalVelocityOffset,&velocityAfter,4)||velocityAfter!=velocity)return false;
 s.identity=true;s.mode=mode;s.flags=flags;s.verticalVelocityKnown=true;s.verticalVelocity=velocity;return sr1RetargetContextAllowed(&s);
}
#endif
static void worldDraw(HGLRC context) {
    // Missing/stale donor poses must stop replacement drawing, so drawArm
    // releases original-host suppression instead of displaying a frozen donor.
    ULONGLONG now=GetTickCount64();
    if(!livePoseFresh(overlayLiveTick,now)){worldGate(1);return;}
    if(!overlayReady || context!=overlayContext || !cameraReady || !InterlockedCompareExchangePointer(&verifiedSr1Module,NULL,NULL) ||
        !sessionBudget(overlayBegin,now,300001) || GetFileAttributesW(PROBE_PATH(L"\\world-sr1.enable"))==INVALID_FILE_ATTRIBUTES){worldGate(2);return;}
    float model[16]; uintptr_t instance=0;
    if(!worldRenderRoot(model,&instance)){worldGate(3);return;}
#ifdef SR1_RETARGET_PREVIEW
    if(!sr1RetargetAllowed(instance)){worldLastDraw=0;worldGate(2);return;}
    uintptr_t object=0,list=0,modelPointer=0;
    if(instance!=overlayHostActor||now<overlayHostTick||now-overlayHostTick>200||!worldRead(instance+0x30,&object,8)||object!=overlayHostObject||!worldRead(object+0x10,&list,8)||!worldRead(list,&modelPointer,8)||modelPointer!=overlayHostModel){worldLastDraw=0;worldGate(3);return;}
#endif
    OverlayState saved; overlaySave(&saved);
    if(saved.drawFbo!=0 || saved.viewport[2]<512 || saved.viewport[3]<512){worldGate(4);return;}
    GLint ubo=0; glGetIntegerv(GL_UNIFORM_BUFFER_BINDING,&ubo);
    float view[16],projection[16],inverse[16]; bool found=false; GLuint selected=0;
    for(unsigned int i=0;i<cameraFieldCount && !found;i++) {
        CameraField *f=&cameraFields[i]; if(strcmp(f->field,"uViewInverseMatrix") || !cglIsProgram(f->program)) continue;
        bool v=false,p=false,inv=false; GLint buffer=0;
        for(unsigned int j=0;j<cameraFieldCount;j++) if(cameraFields[j].program==f->program && !cameraFields[j].rowMajor) {
            CameraField *at=&cameraFields[j];
            if(!strcmp(at->field,"uViewMatrix")) v=cameraRead(at,view,&buffer);
            else if(!strcmp(at->field,"uProjMatrix")) p=cameraRead(at,projection,&buffer);
            else if(!strcmp(at->field,"uViewInverseMatrix")) inv=cameraRead(at,inverse,&buffer);
        }
        if(v&&p&&inv&&fabsf(projection[15])<.0001f&&fabsf(projection[11])>.1f) {
            float check[16]; hostMultiply(view,inverse,check); found=true;
            for(int k=0;k<16;k++) if(fabsf(check[k]-(k%5==0?1.0f:0.0f))>.005f) found=false;
            if(found) selected=f->program;
        }
    }
    pglBindBuffer(GL_UNIFORM_BUFFER,(GLuint)ubo);
    if(!found){worldGate(5);return;}
    bool replacement=GetFileAttributesW(PROBE_PATH(L"\\replace-sr1.enable"))!=INVALID_FILE_ATTRIBUTES;
    if(replacement&&worldAuthorityModel)worldAuthorityModel(model,instance);
    if(worldFrameAudit)worldFrameAudit(model,inverse,instance);
    if(replacement&&worldCameraModel)worldCameraModel(model,instance);
    float localOffset=replacement?0.0f:500.0f;
    for(int k=0;k<3;k++) model[12+k]+=model[k]*localOffset;
    float viewModel[16],mvp[16]; hostMultiply(view,model,viewModel); hostMultiply(projection,viewModel,mvp);
    // The actor origin is at the feet, not a bounding volume. It can be
    // behind the camera while the upper mesh remains in view. Let GL clip
    // individual triangles; origin culling also broke authority freshness.
    for(unsigned int k=0;k<16;k++) if(!isfinite(mvp[k])){worldGate(6);return;}
    pglBindFramebuffer(GL_FRAMEBUFFER,0); pglUseProgram(overlayProgram); pglBindVertexArray(overlayVao);
    pglUniformMatrix4fv(pglGetUniformLocation(overlayProgram,"view"),1,GL_FALSE,mvp);
    overlayAppearance();
    overlayBlend(GL_FALSE); glDisable(GL_CULL_FACE); glDisable(GL_SCISSOR_TEST); glDisable(GL_RASTERIZER_DISCARD);
    glEnable(GL_DEPTH_TEST); glDepthFunc(GL_LEQUAL); glDepthMask(GL_TRUE); pglColorMaski(0,GL_TRUE,GL_TRUE,GL_TRUE,GL_TRUE); glPolygonMode(GL_FRONT_AND_BACK,GL_FILL);
    overlayGeometryDraw(); overlayRestore(&saved);worldGate(0); ++worldDraws;worldLastDraw=GetTickCount64();worldLastInstance=instance;
    if(worldDraws==1 || worldDraws%600==0) logLine("WORLD_SR1 draws=%u camera_program=%u source=%p scale=1 local_offset=%.0f depth_write=1; EXPERIMENTAL CLONE, scene depth unverified",worldDraws,selected,(void *)instance,localOffset);
}
