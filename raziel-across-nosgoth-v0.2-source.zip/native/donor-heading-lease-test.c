// SPDX-License-Identifier: GPL-3.0-or-later
#include <assert.h>
#include <stdio.h>
#include "donor-heading-lease.h"
typedef struct {float v[5];unsigned writes,failAt;bool alive;} Memory;
static bool readValues(void *ctx,float out[5]){Memory *m=ctx;if(!m->alive)return false;memcpy(out,m->v,sizeof(m->v));return true;}
static bool writeValue(void *ctx,unsigned i,float x){Memory *m=ctx;if(!m->alive||i>=5)return false;m->v[i]=x;return ++m->writes!=m->failAt;}
int main(void){
 unsigned cases=0;
 for(int i=-720;i<=720;i+=3){float t=i/360.f,a=t*2*3.14159265358979323846f,c=cosf(a),s=sinf(a),root[16]={c,s,0,0,-s,c,0,0,0,0,1,0,2,3,4,1},h;
  assert(headingRoot(root,&h));assert(fabsf(headingDelta(h,t))<1e-6f);
  float targets[]={0,.25f,.5f,.9999f,-.0001f};
  for(unsigned j=0;j<5;j++){float before[5]={t,t-.01f,t-.1f,t+.2f,t+.49f},after[5];assert(headingRebase(before,targets[j],after));assert(fabsf(headingDelta(after[0],targets[j]))<1e-6f);for(unsigned k=1;k<5;k++)assert(fabsf(headingDelta(after[k]-after[0],before[k]-before[0]))<1e-6f);++cases;}
 }
 for(unsigned failed=0;failed<=5;failed++){
  Memory m={.v={.9f,.89f,.8f,.2f,.1f},.alive=true,.failAt=failed};float original[5];memcpy(original,m.v,sizeof(original));HeadingLease l={0};
  bool ok=headingApply(&l,&m,readValues,writeValue,.01f);
  if(failed){assert(!ok&&l.failed&&!l.acquired);assert(!memcmp(m.v,original,sizeof(original)));}
  else {assert(ok&&l.acquired);assert(headingApply(&l,&m,readValues,writeValue,.3f));assert(headingRelease(&l,&m,readValues,writeValue));assert(!memcmp(m.v,original,sizeof(original)));assert(l.restored==1&&!l.acquired);}
 }
 Memory m={.v={.1f,.1f,.2f,.3f,.4f},.alive=true};HeadingLease l={0};assert(headingApply(&l,&m,readValues,writeValue,.5f));m.v[3]=.123f;float changed[5];memcpy(changed,m.v,sizeof(changed));unsigned writes=m.writes;assert(headingRelease(&l,&m,readValues,writeValue));assert(m.writes==writes&&!memcmp(changed,m.v,sizeof(changed))&&l.foreign==1);
 l=(HeadingLease){0};assert(headingApply(&l,&m,readValues,writeValue,.7f));m.alive=false;writes=m.writes;assert(headingRelease(&l,&m,readValues,writeValue)&&m.writes==writes);
 float invalid[5]={0,0,NAN,0,0},out[5];assert(!headingRebase(invalid,0,out));
 // Repeated native quarter-turn attempts are not repeated external frames.
 Memory loop={.v={.1f,.1f,.2f,.3f,.4f},.alive=true};HeadingLease follow={0};
 assert(headingApply(&follow,&loop,readValues,writeValue,.5f));
 float fixed[5];memcpy(fixed,loop.v,sizeof(fixed));float old[5];memcpy(old,fixed,sizeof(old));unsigned oldWound=0;
 for(unsigned i=0;i<63;i++){
  loop.v[0]=headingWrap(.5f+.25f);loop.v[1]=.5f;
  old[0]=headingWrap(.5f+.25f);old[1]=.5f;float next[5];assert(headingRebase(old,.5f,next));memcpy(old,next,sizeof(old));
  if(fabsf(headingDelta(old[4],fixed[4]))>.01f)++oldWound;
  assert(headingApply(&follow,&loop,readValues,writeValue,.5f));
  assert(fabsf(headingDelta(loop.v[1],.5f))<1e-6f);
  for(unsigned k=2;k<5;k++)assert(fabsf(headingDelta(loop.v[k],fixed[k]))<1e-6f);
 }assert(oldWound>0);
 float headings[]={.99f,.01f,.2f,.2f,.8f};
 for(unsigned i=0;i<sizeof(headings)/sizeof(headings[0]);i++){
  float before[5];memcpy(before,loop.v,sizeof(before));float authority=follow.authority;
  // Preserve a new native authored cache value; only the host delta is added.
  loop.v[4]=headingWrap(loop.v[4]+.07f);before[4]=loop.v[4];loop.v[0]=headingWrap(authority+.25f);loop.v[1]=authority;
  assert(headingApply(&follow,&loop,readValues,writeValue,headings[i]));
  for(unsigned k=2;k<5;k++)assert(fabsf(headingDelta(loop.v[k],before[k]+headingDelta(headings[i],authority)))<1e-6f);
 }
 for(unsigned failed=1;failed<=5;failed++){
  Memory partial={.v={.1f,.1f,.2f,.3f,.4f},.alive=true};HeadingLease lease={0};assert(headingApply(&lease,&partial,readValues,writeValue,.5f));
  partial.v[0]=.75f;partial.v[1]=.5f;float before[5];memcpy(before,partial.v,sizeof(before));partial.failAt=partial.writes+failed;
  assert(!headingApply(&lease,&partial,readValues,writeValue,.6f)&&lease.failed&&lease.authority==.5f);
  assert(!memcmp(partial.v,before,sizeof(before)));
 }
 assert(headingRelease(&follow,&loop,readValues,writeValue));
 loop.v[0]=.2f;assert(headingApply(&follow,&loop,readValues,writeValue,.4f));assert(follow.authority==.4f);
 puts("Heading frame/lease PASS: 2405 headings; native-turn cache winding reproduced/removed; host delta/authored cache/previous-angle continuity; every partial-write rollback; owned restore; foreign/lost actor untouched");return cases!=2405;
}
