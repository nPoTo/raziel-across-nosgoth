#include <stdbool.h>
#include <stdint.h>
#include <string.h>
#include <stdio.h>
#include "live-packet.h"
int main(void) {
    if(livePoseFresh(0,1000)||livePoseFresh(1001,1000)||livePoseFresh(499,1000)||!livePoseFresh(500,1000)||!livePoseFresh(1000,1000))return 10;
    uint32_t h[16]={0x324c5a52,24135,2,12,1000,0,15748,1};
    const unsigned char hash[32]={0x40,0x59,0xa8,0x3f,0x3d,0x47,0xa1,0x98,0x71,0x4b,0x21,0x5a,0xae,0xdc,0x21,0xc8,0x91,0x93,0x14,0xc7,0xd4,0xfc,0xd6,0x79,0x55,0x0f,0x89,0x60,0xc1,0xd8,0xda,0x0c};
    memcpy(&h[8],hash,32); uint64_t size=64+24135*12;
    if(!liveHeaderValid(h,24135,size,1100,0)) return 1;
    if(liveHeaderValid(h,24135,size-1,1100,0)||liveHeaderValid(h,24135,size,999,0)||liveHeaderValid(h,24135,size,1501,0)||liveHeaderValid(h,24135,size,1100,1000)) return 2;
    for(int i=0;i<16;i++) {
        if(i==3 || i==6) continue;
        uint32_t before=h[i]; h[i]^=0xffffffff;
        if(liveHeaderValid(h,24135,size,1100,0)) return 3;
        h[i]=before;
    }
    h[6]=0; if(liveHeaderValid(h,24135,size,1100,0)) return 4;
    h[6]=15748;h[7]=5;if(!liveHeaderValid(h,24135,size,1100,0))return 5;
    h[7]=2;if(liveHeaderValid(h,24135,size,1100,0))return 6;
    h[7]=9;if(!liveHeaderValid(h,24135,size,1100,0))return 7;
    h[7]=13;if(!liveHeaderValid(h,24135,size,1100,0))return 8;
    h[7]=17;if(liveHeaderValid(h,24135,size,1100,0))return 9;
    puts("Live packet validation: PASS (bounds, identity, freshness, replay, truncation)"); return 0;
}
