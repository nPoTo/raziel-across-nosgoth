#include "report-path.h"
// SPDX-License-Identifier: GPL-3.0-or-later
// Hash/byte-gated SR1 Reaver render observer and explicit visual suppression.
typedef void (__fastcall *ReaverFn)(uintptr_t);
static ReaverFn originalReaver;
static PVOID reaverTarget;
static bool reaverAttempted;
static volatile LONG reaverLock;
static volatile LONG64 reaverCalls,reaverDrops;
typedef struct {
    LONG64 sequence;ULONGLONG tick;uintptr_t argument,instance,object,extraData,player;
    char name[9];unsigned char data[32];bool valid;
} ReaverEvent;
static ReaverEvent latestReaver;
static LONG64 reaverLastLogged;
static volatile LONG reaverHideEnabled;
static volatile LONG64 reaverHidden;
static bool reaverIdentityCanHide(const ReaverEvent *event,bool enabled,uintptr_t renderedPlayer) {
    return enabled&&event->valid&&!memcmp(event->name,"sreavr__",8)&&event->player&&event->player==renderedPlayer&&
        event->instance&&event->instance!=event->player&&event->extraData;
}
static bool reaverCanHide(const ReaverEvent *event,bool enabled,uint64_t now,uint64_t lastDraw,uintptr_t renderedPlayer) {
    return reaverIdentityCanHide(event,enabled,renderedPlayer)&&lastDraw&&now>=lastDraw&&now-lastDraw<250;
}
static bool reaverPresentationHide(const ReaverEvent *event,bool enabled,uint64_t now){
#ifdef SR1_NATIVE_SKELETON_ADAPTER
    // The bounded session owns visibility even when the body yields. Ignore the
    // once-per-second worker cache; the session rechecks its owned flags now.
    (void)now;(void)enabled;return reaverIdentityCanHide(event,true,event->player)&&sr1SkeletonVisibilityScope(event->player);
#elif defined(SR1_RETARGET_PREVIEW)
    // Keep the exact observed Reaver identity requirements. The lifetime lease,
    // not a fabricated recent body draw, owns this render-only suppression.
    (void)now;
    return reaverIdentityCanHide(event,enabled,event->player)&&sr1RetargetWeaponScope(event->player);
#else
    return reaverCanHide(event,enabled,now,worldLastDraw,worldLastInstance);
#endif
}
static bool reaverPlayerIdentity(uintptr_t *player){
#ifdef SR1_NATIVE_SKELETON_ADAPTER
    uintptr_t base=(uintptr_t)InterlockedCompareExchangePointer(&verifiedSr1Module,NULL,NULL);
    return base&&worldActorRead(base,player);
#else
    float root[16];return worldRoot(root,player);
#endif
}
static void __fastcall observeReaver(uintptr_t argument) {
    ReaverEvent event={0};event.argument=argument;event.sequence=InterlockedIncrement64(&reaverCalls);
    event.tick=GetTickCount64();
    uintptr_t base=(uintptr_t)InterlockedCompareExchangePointer(&verifiedSr1Module,NULL,NULL),name=0,after=0;
    unsigned char bytes[712];
    event.valid=base&&worldRead(base+0x2bcd18,&event.instance,8)&&worldRead(event.instance,bytes,sizeof(bytes))&&
        reaverPlayerIdentity(&event.player);
    if(event.valid) {
        event.object=worldPointer(bytes+0x30);event.extraData=worldPointer(bytes+0x2c0);
        event.valid=worldRead(event.object+0x30,&name,8)&&worldRead(name,event.name,8)&&
            worldRead(event.extraData,event.data,sizeof(event.data))&&
            worldRead(base+0x2bcd18,&after,8)&&after==event.instance;
    }
    if(!InterlockedCompareExchange(&reaverLock,1,0)){latestReaver=event;InterlockedExchange(&reaverLock,0);}
    else InterlockedIncrement64(&reaverDrops);
    if(reaverPresentationHide(&event,InterlockedCompareExchange(&reaverHideEnabled,0,0)!=0,GetTickCount64())) {
        LONG64 hidden=InterlockedIncrement64(&reaverHidden);
        if(hidden==1||hidden%600==0)logLine("REAVER_REPLACE hidden_calls=%lld instance=%p player=%p; render only",hidden,(void *)event.instance,(void *)event.player);
        return;
    }
    originalReaver(argument);
}
static void reaverLog(void) {
#ifdef SR1_NATIVE_SKELETON_ADAPTER
    bool enabled=GetFileAttributesW(PROBE_PATH(L"\\hide-reaver-sr1.enable"))!=INVALID_FILE_ATTRIBUTES;
#else
    bool enabled=GetFileAttributesW(PROBE_PATH(L"\\hide-reaver-sr1.enable"))!=INVALID_FILE_ATTRIBUTES&&
        GetFileAttributesW(PROBE_PATH(L"\\replace-sr1.enable"))!=INVALID_FILE_ATTRIBUTES&&
        GetFileAttributesW(PROBE_PATH(L"\\world-sr1.enable"))!=INVALID_FILE_ATTRIBUTES;
#endif
    InterlockedExchange(&reaverHideEnabled,enabled);
    if(GetFileAttributesW(PROBE_PATH(L"\\reaver-capture.enable"))==INVALID_FILE_ATTRIBUTES)return;
    ReaverEvent event;
    if(InterlockedCompareExchange(&reaverLock,1,0))return;
    event=latestReaver;InterlockedExchange(&reaverLock,0);
    if(!event.sequence||event.sequence==reaverLastLogged)return;
    reaverLastLogged=event.sequence;
    // Hex avoids interpreting arbitrary bytes as formatting/control characters.
    char nameHex[17],dataHex[65];
    for(int i=0;i<8;++i)sprintf(nameHex+i*2,"%02x",(unsigned char)event.name[i]);
    for(int i=0;i<32;++i)sprintf(dataHex+i*2,"%02x",event.data[i]);
    logLine("REAVER_OBSERVER sequence=%lld valid=%d arg=%p instance=%p player=%p object=%p extra=%p name_hex=%s data_hex=%s",
        event.sequence,event.valid,(void *)event.argument,(void *)event.instance,(void *)event.player,(void *)event.object,(void *)event.extraData,nameHex,dataHex);
}
static void reaverInstall(HMODULE module) {
    if(reaverAttempted)return;reaverAttempted=true;
    // Full function bytes, including both relative call targets, from supported sr1.dll.
    unsigned char actual[sizeof(reaverExpected)];
    uintptr_t address=(uintptr_t)module+0x543b0;
    if(!worldRead(address,actual,sizeof(actual))||memcmp(actual,reaverExpected,sizeof(actual))) {logLine("REAVER_OBSERVER function bytes mismatch; disabled");return;}
    HMODULE pinned;
    if(!GetModuleHandleExW(GET_MODULE_HANDLE_EX_FLAG_FROM_ADDRESS|GET_MODULE_HANDLE_EX_FLAG_PIN,(LPCWSTR)address,&pinned))return;
    MH_STATUS init=MH_Initialize();
    if(init!=MH_OK&&init!=MH_ERROR_ALREADY_INITIALIZED){logLine("REAVER_OBSERVER init failed=%d",init);return;}
    MH_STATUS created=MH_CreateHook((PVOID)address,(PVOID)&observeReaver,(PVOID *)&originalReaver);
    MH_STATUS enabled=created==MH_OK?MH_EnableHook((PVOID)address):created;
    if(enabled==MH_OK)reaverTarget=(PVOID)address;
    logLine("REAVER_OBSERVER create=%d enable=%d target_rva=0x543b0; forwarding unchanged, not controller/combat hook",created,enabled);
}
