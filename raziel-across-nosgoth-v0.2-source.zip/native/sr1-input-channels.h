// SPDX-License-Identifier: GPL-3.0-or-later
#pragma once
// A completed native keyboard frame is not an XInput device or return site.
// Keep it outside all four real pad slots, including a pad in slot 3.
#ifdef SR1_DUAL_INPUT
#define SR_INPUT_CHANNELS 5u
#define SR_INPUT_FRAME_CHANNEL 4u
#else
#define SR_INPUT_CHANNELS 4u
#endif
static inline bool srInputPollSite(uintptr_t caller,uintptr_t base){return base&&(caller==base+0x5bc9||caller==base+0x5047);}
