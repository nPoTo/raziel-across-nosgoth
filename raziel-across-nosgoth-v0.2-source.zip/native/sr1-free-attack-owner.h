// SPDX-License-Identifier: GPL-3.0-or-later
#pragma once
#include <stdint.h>
#include <stdbool.h>
typedef struct {uint64_t identity,lastTick;bool armed,consumed;} SrFreeAttackOwner;
// ownerAlive is bounded independently from fresh pose eligibility. Retaining
// an already-consumed press across a stale pose must not synthesize native X.
static inline uint16_t srFreeAttackStep(SrFreeAttackOwner *s,uint64_t now,uint64_t identity,bool ownerAlive,bool eligible,uint16_t hardware,uint16_t delivered,uint16_t mask){
 if(!s||!mask)return delivered;
 if(!ownerAlive||!identity||s->identity!=identity||now<s->lastTick){
  *s=(SrFreeAttackOwner){.identity=identity,.lastTick=now};
  if(!ownerAlive||!identity)return delivered;
 }
 s->lastTick=now;
 if(!(hardware&mask)){s->consumed=false;s->armed=eligible;return delivered;}
 if(s->consumed)return (uint16_t)(delivered&~mask);
 if(s->armed&&eligible){s->consumed=true;s->armed=false;return (uint16_t)(delivered&~mask);}
 s->armed=false;return delivered;
}
// Independent press lifetimes: adding LB to held X must not inherit X ownership.
static inline uint16_t srFreeAttackPairStep(SrFreeAttackOwner s[2],uint64_t now,uint64_t identity,bool ownerAlive,bool eligible,uint16_t hardware,uint16_t delivered){
 delivered=srFreeAttackStep(&s[0],now,identity,ownerAlive,eligible,hardware,delivered,0x4000);
 return srFreeAttackStep(&s[1],now,identity,ownerAlive,eligible,hardware,delivered,0x0100);
}
