// SPDX-License-Identifier: GPL-3.0-or-later
// Opt-in host adapter. All handles/resource attachment belong to one worker.
#include "bridge-consumer.h"
#include "bridge-session.h"
typedef struct {
 bool active,resources;
 uint64_t generation,tick;
 unsigned char geometry[RM_GEOMETRY_BYTES],appearance[RM_APPEARANCE_BYTES],pose[RM_LIVE_BYTES],movement[80];
 bool movementReady;
} SessionRuntimeCache;
static SessionRuntimeCache sessionCache;
static SRWLOCK sessionCacheLock=SRWLOCK_INIT;
static volatile LONG sessionRuntimeStopRequested;
static HANDLE sessionRuntimeThread;
static volatile LONG64 sessionRenderedGeneration;
static volatile LONG64 sessionHealthyTick;
static bool sessionRuntimeRequested(void){return GetFileAttributesW(PROBE_PATH(L"\\session-v2.enable"))!=INVALID_FILE_ATTRIBUTES;}
static bool (*sessionRuntimeMode)(void)=sessionRuntimeRequested;
static bool sessionRuntimeCopy(unsigned kind,void *out,size_t bytes){
 if(!sessionRuntimeMode())return renderMemoryLegacyCopy(kind,out,bytes);
 size_t expected=kind==0?RM_GEOMETRY_BYTES:kind==1?RM_APPEARANCE_BYTES:RM_LIVE_BYTES;
 if(kind>2||!out||bytes!=expected||!TryAcquireSRWLockShared(&sessionCacheLock))return false;
 bool ok=sessionCache.active&&sessionCache.resources&&livePoseFresh(sessionCache.tick,GetTickCount64());
 if(ok)memcpy(out,kind==0?sessionCache.geometry:kind==1?sessionCache.appearance:sessionCache.pose,bytes);
 if(ok&&kind==2)InterlockedExchange64(&sessionRenderedGeneration,(LONG64)sessionCache.generation);
 ReleaseSRWLockShared(&sessionCacheLock);return ok;
}
static bool sessionRuntimeMovement(unsigned char out[80]){
 if(!sessionRuntimeMode())return renderMemoryMovementCopy(out);
 if(!out||!TryAcquireSRWLockShared(&sessionCacheLock))return false;
 uint64_t now=GetTickCount64();bool ok=sessionCache.active&&sessionCache.movementReady&&sessionCache.generation==(uint64_t)InterlockedCompareExchange64(&sessionRenderedGeneration,0,0)&&sessionCache.tick<=now&&now-sessionCache.tick<=150;
 if(ok)memcpy(out,sessionCache.movement,80);ReleaseSRWLockShared(&sessionCacheLock);return ok;
}
static bool sessionRuntimeHealthy(void){
 if(!sessionRuntimeMode())return true;
 // Do not equate the worker's brief cache publication lock with peer loss.
 // Only a complete active publication sets this deadline; invalidation clears it.
 return livePoseFresh((uint64_t)InterlockedCompareExchange64(&sessionHealthyTick,0,0),GetTickCount64());
}
static void sessionRuntimeInvalidate(void){InterlockedExchange64(&sessionHealthyTick,0);AcquireSRWLockExclusive(&sessionCacheLock);sessionCache.active=false;sessionCache.resources=false;sessionCache.movementReady=false;memset(sessionCache.movement,0,80);ReleaseSRWLockExclusive(&sessionCacheLock);}
static bool sessionRuntimeIdentity(BridgeIdentity *i){
 wchar_t path[32768];_snwprintf(path,ARRAYSIZE(path),L"%ls\\session-v2-%lu.bin",PROBE_REPORT_DIR,GetCurrentProcessId());
 FILE *file=_wfopen(path,L"rb");if(!file)return false;unsigned char b[BRIDGE_HEADER_BYTES];bool size=fread(b,1,sizeof(b),file)==sizeof(b)&&fgetc(file)==EOF;fclose(file);if(!size)return false;
 uint64_t creation=0;if(!bridgeProcessCreation(GetCurrentProcess(),&creation))return false;
 *i=(BridgeIdentity){.sourcePid=bridgeU32(b+16),.hostPid=GetCurrentProcessId(),.sourceCreation=bridgeU64(b+24),.hostCreation=creation,.sessionGeneration=bridgeU64(b+40),.levelGeneration=1,.actorId=1,.actorGeneration=1,.capabilities=15};
 if(!bridgeHex(sheet_bridgeProtocol_session_v2.sourceBuild,i->sourceBuild)||!bridgeHex(sheet_bridgeProtocol_session_v2.hostBuild,i->hostBuild)||bridgeU64(b+72)>GetTickCount64())return false;
 BridgeHeader hello;if(!bridgeDecode(b,sizeof(b),sizeof(b),bridgeU64(b+72),i,&hello)||hello.type!=BRIDGE_HELLO)return false;
 HANDLE source=OpenProcess(SYNCHRONIZE|PROCESS_QUERY_LIMITED_INFORMATION,FALSE,i->sourcePid);DWORD length=ARRAYSIZE(path);char hash[65];
 bool valid=bridgeMemoryProcess(source,i->sourceCreation)&&QueryFullProcessImageNameW(source,0,path,&length)&&hashFile(path,hash)&&!strcmp(hash,"fc6a406ff7ac9b5eb7788dc7a65d335e1c1aad9236618112671975b71d2daddc");if(source)CloseHandle(source);return valid;
}
static DWORD WINAPI sessionRuntimeWorker(LPVOID unused){
 (void)unused;BridgeMemory memory={0};BridgeConsumer *consumer=calloc(1,sizeof(*consumer));SessionRuntimeCache *staging=calloc(1,sizeof(*staging));unsigned char *pose=malloc(RM_LIVE_BYTES),movement[80];BridgeSession session;bridgeSessionBegin(&session);uintptr_t actor=0;bool resources=false;
 if(!consumer||!staging||!pose)goto done;
 bool diagnosticActive=false;unsigned diagnosticTransitions=0,diagnosticActorFailures=0;
 while(!InterlockedCompareExchange(&sessionRuntimeStopRequested,0,0)){
  Sleep(25);uint64_t now=GetTickCount64();
  if(!sessionRuntimeMode()||!InterlockedCompareExchangePointer(&verifiedSr1Module,NULL,NULL)){sessionRuntimeInvalidate();bridgeMemoryClose(&memory);resources=false;actor=0;bridgeSessionBegin(&session);continue;}
  if(!memory.view){BridgeIdentity identity;if(!sessionRuntimeIdentity(&identity)||!bridgeMemoryOpen(&memory,&identity,false))continue;bridgeConsumerBegin(consumer,&identity);bridgeSessionBegin(&session);logLine("RZB2 attached generation=%llu creation_verified=1 source_build_verified=1",identity.sessionGeneration);}
  uintptr_t player=0;bool ready=worldActorRead((uintptr_t)InterlockedCompareExchangePointer(&verifiedSr1Module,NULL,NULL),&player);
  if(!ready&&diagnosticActorFailures++<64)logLine("RZB2_ACTOR_GATE reason=%u; bounded scalar identity read diagnostic",worldActorFailure);
  // A new native host actor needs a new publisher session; no old commands cross.
  if(ready&&actor&&actor!=player){sessionRuntimeInvalidate();logLine("RZB2 host actor changed; fresh session required");break;}if(ready&&!actor)actor=player;
  bridgeConsumerRead(consumer,&memory,pose,movement,now);
  // Contention is not corrupted data. Leave the last published immutable cache
  // alone; independent callback deadlines still expire pose/control promptly.
  if(memory.status==BM_BUSY)continue;
  if(!resources&&consumer->poseReady){resources=bridgeMemoryResource(&memory,BRIDGE_GEOMETRY,staging->geometry,RM_GEOMETRY_BYTES,now)&&bridgeMemoryResource(&memory,BRIDGE_APPEARANCE,staging->appearance,RM_APPEARANCE_BYTES,now);}
  BridgeSessionObservation observation={.hostAlive=true,.donorAlive=memory.status!=BM_PEER_LOST,.identified=true,.contractValid=true,.actorReady=ready&&resources&&consumer->poseReady,.lockBusy=memory.status==BM_BUSY,.abandoned=memory.status==BM_ABANDONED,.activate=true,.now=now,.heartbeat=consumer->tick,.identity=memory.identity,.requestedOwnership=BRIDGE_OWN_TRANSPORT};
  BridgeSessionEffects effects=bridgeSessionStep(&session,&observation);
  staging->active=effects.state==BRIDGE_ACTIVE&&consumer->poseReady;staging->resources=resources;staging->generation=memory.identity.sessionGeneration;staging->tick=consumer->tick;staging->movementReady=staging->active&&consumer->movementReady;
  if(staging->active!=diagnosticActive){diagnosticActive=staging->active;if(diagnosticTransitions++<64)logLine("RZB2_ACTIVE active=%u state=%u transport=%u host_ready=%u resources=%u pose_ready=%u pose_age=%llu; bounded transition diagnostic",staging->active,(unsigned)effects.state,(unsigned)memory.status,ready,resources,consumer->poseReady,(unsigned long long)(now>=consumer->tick?now-consumer->tick:UINT64_MAX));}
  if(staging->active){memcpy(staging->pose,consumer->pose,RM_LIVE_BYTES);memcpy(staging->movement,consumer->movement,80);}else memset(staging->movement,0,80);
  AcquireSRWLockExclusive(&sessionCacheLock);sessionCache.active=staging->active;sessionCache.tick=staging->tick;sessionCache.movementReady=staging->movementReady;sessionCache.generation=staging->generation;
  if(resources&&!sessionCache.resources){memcpy(sessionCache.geometry,staging->geometry,RM_GEOMETRY_BYTES);memcpy(sessionCache.appearance,staging->appearance,RM_APPEARANCE_BYTES);}sessionCache.resources=resources;
  if(staging->active)memcpy(sessionCache.pose,staging->pose,RM_LIVE_BYTES);memcpy(sessionCache.movement,staging->movement,80);ReleaseSRWLockExclusive(&sessionCacheLock);
  InterlockedExchange64(&sessionHealthyTick,staging->active?(LONG64)staging->tick:0);
  bridgeSessionAcknowledge(&session,effects.release,effects.acquire);
  if(memory.status==BM_PEER_LOST||memory.status==BM_ABANDONED){sessionRuntimeInvalidate();bridgeMemoryClose(&memory);resources=false;actor=0;}
 }
done:sessionRuntimeInvalidate();bridgeMemoryClose(&memory);free(consumer);free(staging);free(pose);return 0;
}
