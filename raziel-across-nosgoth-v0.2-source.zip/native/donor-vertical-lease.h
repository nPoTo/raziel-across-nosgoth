// SPDX-License-Identifier: GPL-3.0-or-later
#pragma once
#include <stdint.h>
#include <stdbool.h>
#include <string.h>
#include <math.h>
// Pure owned-state transaction; callbacks must run on the owning game frame.
// No address discovery, hook installation or game writes in this header alone.
typedef bool (*DonorVerticalRead)(void *,uintptr_t,uint64_t,float[3]);
typedef bool (*DonorVerticalWrite)(void *,uintptr_t,uint64_t,unsigned,float);
typedef struct {
 uintptr_t actor;uint64_t generation;
 float saved[3],last[3];
 unsigned releaseAttempts;
 bool acquired,pinned,failed,released;
} DonorVerticalLease;
static inline bool donorVerticalFinite(const float v[3]){
 return isfinite(v[0])&&isfinite(v[1])&&isfinite(v[2]);
}
static inline bool donorVerticalAcquire(DonorVerticalLease *l,void *ctx,DonorVerticalRead read,
 uintptr_t actor,uint64_t generation,bool completedDonorGround){
 if(!l||l->acquired||l->failed||l->released||!actor||!generation||!completedDonorGround)return false;
 float v[3];if(!read(ctx,actor,generation,v)||!donorVerticalFinite(v)||v[0]!=v[1]||v[2]!=0)return false;
 l->actor=actor;l->generation=generation;memcpy(l->saved,v,sizeof(v));memcpy(l->last,v,sizeof(v));l->acquired=true;return true;
}
static inline bool donorVerticalTransaction(DonorVerticalLease *l,void *ctx,DonorVerticalRead read,
 DonorVerticalWrite write,const float before[3],const float target[3],unsigned count){
 float current[3];unsigned attempted=0;
 if(!read(ctx,l->actor,l->generation,current)||memcmp(current,before,sizeof(current)))return false;
 for(unsigned i=0;i<count;i++){
  attempted=i+1;
  if(!write(ctx,l->actor,l->generation,i,target[i]))goto rollback;
 }
 if(read(ctx,l->actor,l->generation,current)&&!memcmp(current,target,sizeof(current))){memcpy(l->last,current,sizeof(current));return true;}
rollback:
 // Restore only still-owned scalar values, including a failed write that may
 // already have reached memory. Never overwrite a foreign changed value.
 for(unsigned i=attempted;i>0;i--){unsigned k=i-1;
  if(read(ctx,l->actor,l->generation,current)&&!memcmp(&current[k],&target[k],sizeof(float)))
   (void)write(ctx,l->actor,l->generation,k,before[k]);
 }
 return false;
}
static inline bool donorVerticalPin(DonorVerticalLease *l,void *ctx,DonorVerticalRead read,DonorVerticalWrite write){
 if(!l||!l->acquired||l->failed||l->released||l->releaseAttempts)return false;
 float before[3],target[3];
 if(!read(ctx,l->actor,l->generation,before)||!donorVerticalFinite(before)){l->failed=true;return false;}
 // This is the owned original frame's completed state. If a pin transaction
 // rolls back, release must compare against this state, not the prior frame.
 memcpy(l->last,before,sizeof(before));
 memcpy(target,before,sizeof(target));target[0]=target[1]=l->saved[0];
 if(!donorVerticalTransaction(l,ctx,read,write,before,target,2)){l->failed=true;return false;}
 l->pinned=true;return true;
}
static inline bool donorVerticalRelease(DonorVerticalLease *l,void *ctx,DonorVerticalRead read,DonorVerticalWrite write){
 if(!l||!l->acquired||l->released)return false;
 if(!l->pinned){l->released=true;return !l->failed;}
 if(l->releaseAttempts>=3){l->failed=true;l->released=true;return false;}
 ++l->releaseAttempts;
 // Last post-frame values must still match; the caller cannot restore across
 // an intervening native action, actor replacement or level lifetime change.
 bool ok=donorVerticalTransaction(l,ctx,read,write,l->last,l->saved,3);
 if(ok){l->released=true;return true;}
 l->failed=true;
 float current[3];
 // A rolled-back failed transaction may retry at the next owned boundary.
 // Actor replacement or a foreign value ends ownership immediately.
 if(l->releaseAttempts>=3||!read(ctx,l->actor,l->generation,current)||memcmp(current,l->last,sizeof(current)))l->released=true;
 return false;
}
