// SPDX-License-Identifier: GPL-3.0-or-later
#include <assert.h>
#include <stdio.h>
#include "sr1-jump-exit-blend.h"
int main(void){
 float from[66][13]={0},current[66][13]={0},out[66][13],saved[66][13];int16_t parents[66];
 for(unsigned i=0;i<66;i++){parents[i]=i?(int16_t)(i-1):-1;from[i][0]=from[i][4]=from[i][8]=1;from[i][10]=(float)i;from[i][9]=(float)i;}
 memcpy(current,from,sizeof(from));for(unsigned i=0;i<66;i++){current[i][10]=500;current[i][11]=(float)i;current[i][12]=70;}
 memcpy(saved,current,sizeof(saved));SkeletonSnapshot s={.mode=3,.tick=1000,.epoch=900,.actor=1,.object=2,.model=3,.sourcePid=4,.writerPid=5};
 Sr1RetargetContext c={.identity=true,.foreground=true,.verticalVelocityKnown=true,.verticalVelocity=-80,.callbacks={0xef480,0xef480,0xef480}};JumpExitBlend b={0};
 assert(jumpExitCapture(&b,&s,parents,from,1000));s.mode=0;
 assert(jumpExitApply(&b,&s,&c,parents,current,1000,out));assert(!memcmp(current,out,52));assert(fabsf(out[65][10]-565)<.001f&&fabsf(out[65][11])<.001f);
 assert(jumpExitApply(&b,&s,&c,parents,current,1060,out));assert(fabsf(out[1][10]-500.5f)<.001f&&fabsf(out[1][11]-.5f)<.001f&&fabsf(out[1][12]-70)<.001f);for(unsigned i=2;i<66;i++){float x=out[i][10]-out[i-1][10],y=out[i][11]-out[i-1][11],z=out[i][12]-out[i-1][12];assert(fabsf(sqrtf(x*x+y*y+z*z)-1)<.001f);assert(skeletonRigid(out[i]));}
 assert(jumpExitApply(&b,&s,&c,parents,current,1119,out));assert(fabsf(out[65][11]-65)<.01f);assert(!jumpExitApply(&b,&s,&c,parents,current,1120,out));assert(!b.ready);assert(!memcmp(saved,current,sizeof(saved)));
 float a[3]={1,0,0},z[3]={-1,0,0},edge[3];jumpEdge(a,z,.5f,edge);assert(fabsf(sqrtf(edge[0]*edge[0]+edge[1]*edge[1]+edge[2]*edge[2])-1)<.0001f);
 for(unsigned reason=0;reason<8;reason++){s.mode=3;s.actor=1;s.epoch=900;s.tick=1000;c.foreground=true;c.crouchHeld=false;c.mode=0;c.callbacks[0]=0xef480;assert(jumpExitCapture(&b,&s,parents,from,1000));s.mode=0;uint64_t now=1060;
  if(reason==0)s.actor++;if(reason==1)s.epoch++;if(reason==2)c.foreground=false;if(reason==3)c.crouchHeld=true;if(reason==4)c.callbacks[0]=0xefb50;if(reason==5)c.mode=1;if(reason==6)now=999;if(reason==7)s.tick=800;
  assert(!jumpExitApply(&b,&s,&c,parents,current,now,out));assert(!b.ready);
 }
 // Pelvis is an offset, not a fixed-length limb: equal-height endpoints
 // must not gain height as the offset crosses the root centreline.
 memset(from,0,sizeof(from));memset(current,0,sizeof(current));
 for(unsigned i=0;i<66;i++){from[i][0]=from[i][4]=from[i][8]=current[i][0]=current[i][4]=current[i][8]=1;if(i){from[i][10]=20+(float)i-1;current[i][10]=-20+(float)i-1;from[i][12]=current[i][12]=100;}}
 s.mode=3;s.tick=1000;s.actor=1;s.epoch=900;c.foreground=true;c.mode=0;c.crouchHeld=false;c.callbacks[0]=0xef480;
 assert(jumpExitCapture(&b,&s,parents,from,1000));s.mode=0;
 assert(jumpExitApply(&b,&s,&c,parents,current,1060,out));
 assert(fabsf(out[1][10])<.001f&&fabsf(out[1][12]-100)<.001f);
 for(unsigned i=2;i<66;i++)assert(fabsf(out[i][10]-out[i-1][10]-1)<.001f);
 // Quaternion interpolation stays rigid even at a half-turn.
 float q[4]={0,0,1,0},m[9],back[4];jumpMatrix(q,m);float rigid[13]={0};memcpy(rigid,m,sizeof(m));jumpQuat(rigid,back);assert(fabsf(back[2])>.999f);
 puts("PASS Jump exit: current native root, spherical edges, rigid rotations,120ms expiry/no renewal, identity/pause/crouch/glide/clock refusal, inputs untouched.");return 0;
}
