// SPDX-License-Identifier: GPL-3.0-or-later
// Read-only public runtime probe. A hidden owned swap chain supplies API RVAs;
// another process is read only at those same OS-runtime entry points.
#define WIN32_LEAN_AND_MEAN
#define COBJMACROS
#include <windows.h>
#include <tlhelp32.h>
#include <d3d11.h>
#include <dxgi1_2.h>
#include <stdint.h>
#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
static uintptr_t remoteBase(DWORD pid,const wchar_t *name){
 HANDLE s=CreateToolhelp32Snapshot(TH32CS_SNAPMODULE,pid);if(s==INVALID_HANDLE_VALUE)return 0;MODULEENTRY32W e={0};e.dwSize=sizeof(e);uintptr_t base=0;if(Module32FirstW(s,&e))do{if(!_wcsicmp(e.szModule,name)){base=(uintptr_t)e.modBaseAddr;break;}}while(Module32NextW(s,&e));CloseHandle(s);return base;
}
static void describe(DWORD pid,uintptr_t address,const char *kind){
 HANDLE s=CreateToolhelp32Snapshot(TH32CS_SNAPMODULE,pid);MODULEENTRY32W e={0};e.dwSize=sizeof(e);bool found=false;
 if(s!=INVALID_HANDLE_VALUE&&Module32FirstW(s,&e))do{uintptr_t base=(uintptr_t)e.modBaseAddr;if(address>=base&&address-base<e.modBaseSize){printf("%s module=%ls rva=0x%llx\n",kind,e.szModule,(unsigned long long)(address-base));found=true;break;}}while(Module32NextW(s,&e));if(s!=INVALID_HANDLE_VALUE)CloseHandle(s);if(!found)printf("%s not_in_loaded_module\n",kind);
}
int main(int argc,char **argv){
 if(argc!=2)return 2;DWORD pid=(DWORD)strtoul(argv[1],NULL,10);if(!pid)return 2;HANDLE process=OpenProcess(PROCESS_VM_READ|PROCESS_QUERY_LIMITED_INFORMATION,FALSE,pid);if(!process)return 3;
 WNDCLASSW wc={0};wc.lpfnWndProc=DefWindowProcW;wc.hInstance=GetModuleHandleW(NULL);wc.lpszClassName=L"LOKPublicDXGIDiscovery";if(!RegisterClassW(&wc))return 4;HWND w=CreateWindowW(wc.lpszClassName,L"Hidden read-only public DXGI probe",WS_POPUP,0,0,64,64,NULL,NULL,wc.hInstance,NULL);
 DXGI_SWAP_CHAIN_DESC d={0};d.BufferDesc.Width=d.BufferDesc.Height=64;d.BufferDesc.Format=DXGI_FORMAT_R8G8B8A8_UNORM;d.SampleDesc.Count=1;d.BufferUsage=DXGI_USAGE_RENDER_TARGET_OUTPUT;d.BufferCount=1;d.OutputWindow=w;d.Windowed=TRUE;
 IDXGISwapChain *chain=NULL;IDXGISwapChain1 *chain1=NULL;ID3D11Device *device=NULL;ID3D11DeviceContext *context=NULL;HRESULT hr=D3D11CreateDeviceAndSwapChain(NULL,D3D_DRIVER_TYPE_WARP,NULL,0,NULL,0,D3D11_SDK_VERSION,&d,&chain,&device,NULL,&context);if(FAILED(hr))return 5;
 uintptr_t localBase=(uintptr_t)GetModuleHandleW(L"dxgi.dll"),base=remoteBase(pid,L"dxgi.dll");if(!base)return 6;PVOID targets[2]={(PVOID)chain->lpVtbl->Present,NULL};if(SUCCEEDED(IDXGISwapChain_QueryInterface(chain,&IID_IDXGISwapChain1,(void **)&chain1)))targets[1]=(PVOID)chain1->lpVtbl->Present1;
 for(unsigned i=0;i<2;i++)if(targets[i]){
  uintptr_t rva=(uintptr_t)targets[i]-localBase,address=base+rva;unsigned char bytes[16];SIZE_T n=0;printf("%s public_rva=0x%llx\n",i?"Present1":"Present",(unsigned long long)rva);
  if(!ReadProcessMemory(process,(void *)address,bytes,sizeof(bytes),&n)||n!=sizeof(bytes))continue;
  uintptr_t destination=0;if(bytes[0]==0xe9){int32_t relative;memcpy(&relative,bytes+1,4);destination=address+5+relative;}
  else if(bytes[0]==0xff&&bytes[1]==0x25){int32_t relative;memcpy(&relative,bytes+2,4);ReadProcessMemory(process,(void *)(address+6+relative),&destination,sizeof(destination),&n);}
  else if(bytes[0]==0x48&&bytes[1]==0xb8&&bytes[10]==0xff&&bytes[11]==0xe0)memcpy(&destination,bytes+2,8);
  if(destination)describe(pid,destination,"existing_redirect");else puts("no_entry_redirect");
 }
 if(chain1)IDXGISwapChain1_Release(chain1);IDXGISwapChain_Release(chain);ID3D11DeviceContext_Release(context);ID3D11Device_Release(device);DestroyWindow(w);CloseHandle(process);return 0;
}
