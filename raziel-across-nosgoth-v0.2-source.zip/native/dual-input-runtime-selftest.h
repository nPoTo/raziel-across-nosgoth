// SPDX-License-Identifier: GPL-3.0-or-later
// Executes the actual post-poll writer against private synthetic memory.
// No game process, game resources, input injection or installed files.
static unsigned dualMockCalls;
static void dualMockOriginal(void){dualMockCalls++;}
static int dualRuntimeSelfTest(void){
 uint8_t *memory=VirtualAlloc(NULL,0x1800000,MEM_RESERVE|MEM_COMMIT,PAGE_READWRITE);
 if(!memory)return 301;
 DualInputShared shared={0};dualBase=(uintptr_t)memory;dualHost=false;dualView=&shared;
 dualSession=(DualInputSession){.host=77,.epoch=1000};dualNamesReady=true;dualConsumer=(DualInputConsumer){0};
 for(unsigned i=0;i<sheet_dualInputFrameKeys_count;i++)dualScancodes[i]=100+(int)i;
 dualScancodes[1]=-1;dualScancodes[2]=-2;
 DualInputWire w={.sequence=1,.tick=1000,.valid=1};dualInputStore(&shared,&w);dualDonorFrame(1000,77,true);dualRestore();
 w.sequence=2;w.tick=1010;w.held=0xd100;w.x=23170;w.y=23170;w.keys=DUAL_FORWARD|DUAL_RIGHT;
 dualInputStore(&shared,&w);dualDonorFrame(1010,77,true);
 int result=0;int16_t *slots=(int16_t*)(memory+0x113ec00),*axes=(int16_t*)(memory+0x17c2e10);
 if(slots[6]!=32767||slots[7]!=32767||slots[5]!=32767||slots[22]!=32767||axes[0]!=23170||axes[1]!=-23170||memory[0x113e9d0]!=1||memory[0x113e9d1]!=1)result=302;
 // Repeated donor polls use held state; the same wire is not a new edge.
 dualRestore();dualDonorFrame(1011,77,true);
 if(dualConsumer.sequence!=2||dualConsumer.held!=0xd100||slots[7]!=32767)result=303;
 // Compare the WHOLE short: preserve a foreign change to one byte.
 slots[7]=0x7f12;dualRestore();if(slots[7]!=0x7f12||slots[6]||axes[0]||memory[0x113e9d0])result=304;
 dualDonorFrame(1200,77,true);if(dualChanged||dualConsumer.active)result=305;
 // Focus return cannot replay the still-held keys.
 w.sequence=3;w.tick=1210;dualInputStore(&shared,&w);dualDonorFrame(1210,77,true);
 if(dualConsumer.held||slots[6]||axes[0])result=306;dualRestore();
 w.sequence=4;w.tick=1220;w.held=0;w.x=w.y=0;w.keys=0;dualInputStore(&shared,&w);dualDonorFrame(1220,77,true);dualRestore();
 w.sequence=5;w.tick=1230;w.held=0x4000;dualInputStore(&shared,&w);dualDonorFrame(1230,77,true);
 if(slots[7]!=32767)result=307;dualRestore();dualDonorFrame(1231,88,true);if(dualChanged||dualConsumer.active)result=308;
 // Forwarding after revocation still calls the original exactly once.
 dualOriginal=dualMockOriginal;dualMockCalls=0;dualView=NULL;dualEnabled=0;dualFrame();if(dualMockCalls!=1)result=309;
 dualOriginal=NULL;dualBase=0;dualNamesReady=false;dualChanged=false;dualConsumer=(DualInputConsumer){0};dualSession=(DualInputSession){0};
 VirtualFree(memory,0,MEM_RELEASE);return result;
}
