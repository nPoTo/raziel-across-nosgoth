// SPDX-License-Identifier: GPL-3.0-or-later
#pragma once
#include <stdint.h>
#include <stdbool.h>
#include "exploration-sheets.h"

// Read-only classification. The caller still owns actor identity, coherent
// reads, contact freshness, control refusal and action completion. This cannot
// make an unknown callback safe or infer swimming from an ordinary fall.
static inline const Sheet_nativeActionCallbacksR12 *nativeActionCallbackRowR12(uint64_t callback) {
 for(size_t i=0;i<sheet_nativeActionCallbacksR12_count;i++) {
  const Sheet_nativeActionCallbacksR12 *row=sheet_nativeActionCallbacksR12_rows[i];
  if(callback==(uint64_t)row->callbackRva)return row;
 }
 return NULL;
}

// Only newly proved explicit native callbacks; existing native exceptions are
// classified by the existing hostContactNativePause implementation.
static inline bool nativeActionCallbackR12(uint64_t callback) {
 const Sheet_nativeActionCallbacksR12 *row=nativeActionCallbackRowR12(callback);
 return row&&row->nativeAction;
}

// Native sections can finish at different frames. Ordinary sections mixed
// with a still-owned native section must not prematurely resume Defiance.
static inline bool nativeActionCallbacksR12(const uint64_t callbacks[3]) {
 bool native=false;
 if(!callbacks)return false;
 for(unsigned i=0;i<3;i++) {
  const Sheet_nativeActionCallbacksR12 *row=nativeActionCallbackRowR12(callbacks[i]);
  if(!row)return false;
  native=native||row->nativeAction;
 }
 return native;
}
