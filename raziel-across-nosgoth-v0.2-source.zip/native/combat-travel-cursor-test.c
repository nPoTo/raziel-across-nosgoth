// SPDX-License-Identifier: GPL-3.0-or-later
#include <stdint.h>
#include <stdbool.h>
#include <math.h>
#include <stdio.h>
#include "combat-travel-cursor.h"
#define CHECK(x) do{if(!(x)){printf("FAIL%d\n",__LINE__);return 1;}}while(0)
int main(void){CombatTravelCursor c={0};float step=99;CHECK(combatTravelStep(&c,1,1,100,2,3,50,true,&step)&&step==0);CHECK(combatTravelStep(&c,1,2,116,2,3,60,true,&step)&&step==-10);CHECK(combatTravelStep(&c,1,2,116,2,3,60,true,&step)&&step==0);CHECK(combatTravelStep(&c,1,3,132,2,3,55,true,&step)&&step==5);CHECK(combatTravelStep(&c,1,4,148,2,3,70,false,&step)&&step==0);CHECK(combatTravelStep(&c,1,5,164,2,3,72,true,&step)&&step==-2);CHECK(combatTravelStep(&c,1,6,500,2,3,90,true,&step)&&step==0);CHECK(combatTravelStep(&c,2,7,516,2,3,100,true,&step)&&step==0);CHECK(!combatTravelStep(&c,2,6,500,2,3,80,true,&step));CHECK(!combatTravelStep(&c,2,8,532,2,3,500,true,&step));CHECK(combatTravelStep(&c,2,9,548,2,3,501,true,&step)&&step==-1);puts("PASS signed once-only travel, identity baseline, duplicate suppression, gap/native backlog discard and step bounds");return 0;}
