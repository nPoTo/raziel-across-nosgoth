// SPDX-License-Identifier: GPL-3.0-or-later
#pragma once
#include "donor-state-sections.h"
typedef struct {uint32_t selectionKeyRaw;uint16_t animationId;bool descriptorPresent;DonorStateSection state;} DonorAnimationSelectionSection;
typedef struct {bool valid;DonorAnimationSelectionSection sections[3];} DonorAnimationSelection;
typedef struct {uint32_t key;uint16_t animationId;uintptr_t descriptor;} DonorSelectionSnapshot;
static inline bool donorSelectionField(void *c,DonorActionStateRead read,uintptr_t address,uintptr_t offset,void *out,SIZE_T n){return address&&offset<=UINTPTR_MAX-address&&n<=UINTPTR_MAX-address-offset&&read(c,address+offset,out,n);}
static inline DonorAnimationSelection donorAnimationSelectionRead(void *context,DonorActionStateRead read,DonorActionStateCode code,uintptr_t base,uint32_t imageSize,uintptr_t actor){
 DonorAnimationSelection out={0};const Sheet_donorAnimationSelectionProbe *p=&sheet_donorAnimationSelectionProbe_current;
 if(!read||!code||!actor||actor%8||!base||base>UINTPTR_MAX-imageSize||p->actorPointerRva!=0xc5aa78||p->actorStateOffset!=0x3f8||p->sectionCount!=3||p->stateSectionStride!=0x250||p->selectionKeyOffset!=0x248||p->cachedDescriptorOffset!=0x250||p->animationIdOffset!=0x1f4||p->animationSectionStride!=0x68||p->selectionKeyBytes!=4||p->descriptorPointerBytes!=8||p->animationIdBytes!=2||p->stableReads!=2||p->serializePointers||p->serializeDescriptors||imageSize<0xc5aa80)return out;
 uintptr_t state=0,current=0,again=0;const uintptr_t address=base+(uintptr_t)p->actorPointerRva;
 if(!read(context,address,&current,8)||current!=actor||!donorSelectionField(context,read,actor,(uintptr_t)p->actorStateOffset,&state,8)||!state||state%8||state>UINTPTR_MAX-0x6f8)return out;
 DonorSelectionSnapshot a[3],b[3];memset(a,0,sizeof(a));memset(b,0,sizeof(b));
 for(unsigned pass=0;pass<2;pass++){
  DonorSelectionSnapshot *s=pass?b:a;
  for(unsigned i=0;i<3;i++)if(!donorSelectionField(context,read,state,i*(uintptr_t)p->stateSectionStride+(uintptr_t)p->selectionKeyOffset,&s[i].key,4)||!donorSelectionField(context,read,state,i*(uintptr_t)p->stateSectionStride+(uintptr_t)p->cachedDescriptorOffset,&s[i].descriptor,8)||!donorSelectionField(context,read,actor,i*(uintptr_t)p->animationSectionStride+(uintptr_t)p->animationIdOffset,&s[i].animationId,2))return out;
  if(!pass){DonorStateSections sections=donorStateSectionsRead(context,read,code,base,imageSize,actor,address);if(!sections.valid||!sections.ownerMatches)return out;for(unsigned i=0;i<3;i++)out.sections[i].state=sections.sections[i];}
 }
 if(memcmp(a,b,sizeof(a))||!donorSelectionField(context,read,actor,(uintptr_t)p->actorStateOffset,&again,8)||again!=state||!read(context,address,&current,8)||current!=actor)return (DonorAnimationSelection){0};
 for(unsigned i=0;i<3;i++){out.sections[i].selectionKeyRaw=a[i].key;out.sections[i].animationId=a[i].animationId;out.sections[i].descriptorPresent=a[i].descriptor!=0;}out.valid=true;return out;
}
