// SPDX-License-Identifier: GPL-3.0-or-later
#include <stdbool.h>
#include <math.h>
#include <stdio.h>
#include "combat-local-step.h"
int main(void){float a[2]={0},r[16]={1,0,0,0,0,1,0,0,0,0,1,0,0,0,0,1},p[3]={0,-10,0};double d[2],sum=0;if(!combatLocalStep(r,p,a,d)||fabs(d[0])>1e-8||fabs(d[1]-10)>1e-8)return 1;sum+=d[1];r[0]=0;r[1]=1;r[4]=-1;r[5]=0;p[0]=10;p[1]=0;if(!combatLocalStep(r,p,a,d)||fabs(d[0])>1e-8||fabs(d[1]-10)>1e-8)return 2;sum+=d[1];if(sum!=20)return 3;r[0]=NAN;if(combatLocalStep(r,p,a,d))return 4;r[0]=0;p[0]=257;if(combatLocalStep(r,p,a,d))return 5;puts("PASS each-step local projection preserves20units across90degree turn; invalid root/step refused; no host writes");return 0;}
