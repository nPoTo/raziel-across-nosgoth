// SPDX-License-Identifier: GPL-3.0-or-later
#pragma once
#include "host-rig-reader.h"
// Exact-build REA evidence: original Crouch release tests this dynamic mask.
// No writes, input simulation, or assumption about the physical button mapping.
static inline bool sr1CrouchHeld(void *p,RigRead read,uintptr_t base,bool *held){
 const Sheet_nativeCrouchHold *s=&sheet_nativeCrouchHold_sr1;
 uintptr_t pointer=0,again=0;uint32_t mask=0,maskAfter=0,command=0,commandAfter=0;*held=false;
 if(s->commandPointerRva!=0xd6b388||s->maskRva!=0x22acd0||s->bytes!=4||s->stableReads!=2||!s->holdNative||s->gameWrites||s->enabled)return false;
 if(!read(p,base+s->commandPointerRva,&pointer,8)||!pointer||pointer>UINTPTR_MAX-4||!read(p,base+s->maskRva,&mask,4)||!mask||!read(p,pointer,&command,4))return false;
 if(!read(p,base+s->commandPointerRva,&again,8)||again!=pointer||!read(p,base+s->maskRva,&maskAfter,4)||maskAfter!=mask||!read(p,pointer,&commandAfter,4)||commandAfter!=command)return false;
 *held=(command&mask)!=0;return true;
}
