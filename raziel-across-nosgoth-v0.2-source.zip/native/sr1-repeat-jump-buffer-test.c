// SPDX-License-Identifier: GPL-3.0-or-later
#include <assert.h>
#include <stdio.h>
#include "sr1-repeat-jump-buffer.h"
static uint16_t step(RepeatJumpBuffer *b,uint64_t t,RepeatJumpPhase p,uint16_t raw){return repeatJumpStep(b,t,7,true,p,raw,350,32,64);}
int main(void){
 RepeatJumpBuffer b={0};const uint16_t A=0x1000,B=0x2000;
 assert(step(&b,100,REPEAT_JUMP_LANDING,0)==0);
 assert(step(&b,130,REPEAT_JUMP_LANDING,A)==A);
 assert(step(&b,160,REPEAT_JUMP_LANDING,0)==0);
 assert(step(&b,190,REPEAT_JUMP_GROUND,B)==(A|B));
 assert(step(&b,220,REPEAT_JUMP_GROUND,B)==(A|B));
 assert(step(&b,254,REPEAT_JUMP_GROUND,B)==B);
 assert(step(&b,280,REPEAT_JUMP_GROUND,0)==0&&!b.pending);
 // Held A: exactly one release window followed by bounded pulse, no repeat.
 b=(RepeatJumpBuffer){0};step(&b,100,REPEAT_JUMP_LANDING,0);step(&b,130,REPEAT_JUMP_LANDING,A);
 assert(step(&b,160,REPEAT_JUMP_GROUND,A)==0);
 assert(step(&b,191,REPEAT_JUMP_GROUND,A)==0);
 assert(step(&b,192,REPEAT_JUMP_GROUND,A)==A);
 step(&b,256,REPEAT_JUMP_GROUND,A);assert(!b.pending);
 // No fabricated edge on initial held input; never replay in air/native actions.
 b=(RepeatJumpBuffer){0};step(&b,100,REPEAT_JUMP_LANDING,A);assert(!b.pending);
 step(&b,130,REPEAT_JUMP_LANDING,0);step(&b,160,REPEAT_JUMP_LANDING,A);
 assert(step(&b,190,REPEAT_JUMP_OTHER,0)==0&&!b.pending);
 // Actor change, stale stream, disabled scope discard intent, preserve raw.
 for(unsigned mode=0;mode<3;mode++){
  b=(RepeatJumpBuffer){0};step(&b,100,REPEAT_JUMP_LANDING,0);step(&b,130,REPEAT_JUMP_LANDING,A);
  assert(repeatJumpStep(&b,mode==1?300:160,mode==0?8:7,mode!=2,REPEAT_JUMP_GROUND,B,350,32,64)==B&&!b.pending);
 }
 b=(RepeatJumpBuffer){0};step(&b,100,REPEAT_JUMP_LANDING,0);step(&b,130,REPEAT_JUMP_LANDING,A);step(&b,160,REPEAT_JUMP_LANDING,0);
 for(uint64_t t=190;t<=490;t+=30)step(&b,t,REPEAT_JUMP_LANDING,0);
 assert(step(&b,520,REPEAT_JUMP_GROUND,0)==0&&!b.pending);
 puts("PASS: landing intent once, released/held A, no air/native replay, identity/gap/lease expiry, unrelated buttons preserved.");
 RepeatJumpPacket packet={0};assert(repeatJumpPacket(&packet,100,0,0)==100);
 assert(repeatJumpPacket(&packet,100,0,A)==101);assert(repeatJumpPacket(&packet,100,0,A)==101);
 assert(repeatJumpPacket(&packet,100,0,0)!=101);assert(repeatJumpPacket(&packet,100,0,0)==100);
 packet=(RepeatJumpPacket){0};assert(repeatJumpPacket(&packet,100,0,A)==101);assert(repeatJumpPacket(&packet,101,0,0)!=101);
 puts("PASS: synthetic A changes XInput packet identity, held pulse stable, raw state restored.");
 return 0;
}
