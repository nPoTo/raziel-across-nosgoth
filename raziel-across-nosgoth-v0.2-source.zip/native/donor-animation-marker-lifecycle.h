// SPDX-License-Identifier: GPL-3.0-or-later
// Opt-in original callback trace. Depends on the selector observer being active.
#pragma once
#include "donor-animation-marker-observer.h"
#include "donor-animation-marker-proof.h"
static DonorAnimationMarkerObserver donorAnimationMarkers;
static _Thread_local DonorMessageObserverThread donorAnimationMarkerThread;
static DonorNativeAnimationMarker donorAnimationMarkerOriginal;
static PVOID donorAnimationMarkerTarget;
static HANDLE donorAnimationMarkerWorker;
static volatile LONG donorAnimationMarkerStopping,donorAnimationMarkerActive;
static bool donorAnimationMarkerReadLease(void *unused,DonorMessageLease *out){
 if(InterlockedCompareExchange(&donorAnimationMarkerStopping,0,0))return false;
 return donorAnimationCallReadLease(unused,out)&&!InterlockedCompareExchange(&donorAnimationMarkerStopping,0,0);
}
static bool donorAnimationMarkerSnapshot(void *unused,void *root,int32_t section,DonorAnimationMarkerMetadata *out){
 (void)unused;uintptr_t actor=0,again=0,callback=0,object=0,source=0;
 if(section<0||section>2||!worldRead(donorMessageBase+0xc5aa78,&actor,8)||!actor||actor>UINTPTR_MAX-0x400||(uintptr_t)root!=actor+0x1a8)return false;
 DonorAnimationCallMetadata metadata={0};
 if(!donorAnimationCallSnapshot(NULL,(void *)actor,section,NULL,&metadata))return false;
 uintptr_t sec=actor+0x1d0+(uintptr_t)section*0x68;
 if(!worldRead(sec+0x30,&callback,8)||callback!=donorMessageBase+DONOR_ANIMATION_MARKER_RVA||!worldRead(actor+0x88,&object,8)||!object||!worldRead(sec+0x40,&source,8)||source!=object||!worldRead(donorMessageBase+0xc5aa78,&again,8)||again!=actor||!donorProcessIdentity(actor))return false;
 out->key=metadata.key;out->clip=metadata.clip;out->opaqueState=metadata.opaqueState;return true;
}
static uintptr_t __fastcall donorAnimationMarkerHook(void *root,int32_t section,uint32_t type,uint32_t data,void *payload,void *context){
 DWORD incoming=GetLastError();InterlockedIncrement(&donorAnimationMarkerActive);
 uintptr_t caller=(uintptr_t)__builtin_return_address(0);
 uint32_t rva=caller>=donorMessageBase&&caller-donorMessageBase<donorMessageImageSize?(uint32_t)(caller-donorMessageBase):0;
 DWORD tid=GetCurrentThreadId();
 uint32_t message=(DWORD)InterlockedCompareExchange(&donorMessageThreadState.ownerThread,0,0)==tid?donorMessageThreadState.depth:0;
 uint32_t selector=(DWORD)InterlockedCompareExchange(&donorAnimationCallThread.ownerThread,0,0)==tid?donorAnimationCallThread.depth:0;
 SetLastError(incoming);uintptr_t result=donorAnimationMarkerForward(&donorAnimationMarkers,&donorAnimationMarkerThread,donorAnimationMarkerOriginal,root,section,type,data,payload,context,rva,message,selector);
 DWORD outgoing=GetLastError();InterlockedDecrement(&donorAnimationMarkerActive);SetLastError(outgoing);return result;
}
static void donorAnimationMarkerDrain(void){
 DonorAnimationMarkerEvent e;unsigned n=0;
 while(n++<512&&donorAnimationMarkerPop(&donorAnimationMarkers,&e))logLine("DONOR_ANIMATION_MARKER {\"session\":\"%llu\",\"callId\":%llu,\"tickMs\":%llu,\"phase\":%u,\"threadId\":%u,\"depth\":%u,\"callerRva\":%u,\"messageDepth\":%u,\"selectorDepth\":%u,\"section\":%u,\"eventType\":%u,\"eventData\":%u,\"key\":%u,\"clip\":%u,\"afterValid\":%u,\"sameState\":%u}",
  (unsigned long long)e.session,(unsigned long long)e.callId,(unsigned long long)e.tickMs,e.phase,e.threadId,e.depth,e.callerRva,e.messageDepth,e.selectorDepth,e.section,e.eventType,e.eventData,e.key,e.clip,e.afterValid,e.sameState);
}
static DWORD WINAPI donorAnimationMarkerCollect(LPVOID unused){
 (void)unused;uint64_t session=0,revoke=0;
 for(;;){
  DonorMessageLease l={0};bool ready=donorAnimationMarkerReadLease(NULL,&l)&&donorMessageLeaseValid(&l);
  if(ready&&!session){session=l.session;logLine("DONOR_ANIMATION_MARKER_SESSION session=%llu start=%llu; native callbacks only",(unsigned long long)session,(unsigned long long)l.startTick);}
  donorAnimationMarkerDrain();
  if((session&&!ready)||InterlockedCompareExchange(&donorAnimationMarkerStopping,0,0)){
   if(!revoke)revoke=GetTickCount64();
   if(!InterlockedCompareExchange(&donorAnimationMarkerActive,0,0)){
    donorAnimationMarkerDrain();logLine("DONOR_ANIMATION_MARKER_END session=%llu published=%llu dropped=%llu forwarded=%llu; synthetic_calls=0 drop_lease=%llu drop_metadata=%llu drop_depth=%llu drop_producer=%llu drop_queue=%llu drop_budget=%llu",(unsigned long long)session,(unsigned long long)InterlockedCompareExchange64(&donorAnimationMarkers.published,0,0),(unsigned long long)InterlockedCompareExchange64(&donorAnimationMarkers.dropped,0,0),(unsigned long long)InterlockedCompareExchange64(&donorAnimationMarkers.forwarded,0,0),(unsigned long long)InterlockedCompareExchange64(&donorAnimationMarkers.leaseDrops,0,0),(unsigned long long)InterlockedCompareExchange64(&donorAnimationMarkers.metadataDrops,0,0),(unsigned long long)InterlockedCompareExchange64(&donorAnimationMarkers.depthDrops,0,0),(unsigned long long)InterlockedCompareExchange64(&donorAnimationMarkers.producerDrops,0,0),(unsigned long long)InterlockedCompareExchange64(&donorAnimationMarkers.queueDrops,0,0),(unsigned long long)InterlockedCompareExchange64(&donorAnimationMarkers.budgetDrops,0,0));return 0;
   }
   if(GetTickCount64()-revoke>=3000){logLine("DONOR_ANIMATION_MARKER_SHUTDOWN incomplete active calls; END withheld");return 1;}
  }
  Sleep(50);
 }
}
static bool donorAnimationMarkerInstall(void){
 unsigned char body[DONOR_ANIMATION_MARKER_BYTES];char digest[65];
 if(!donorAnimationCallTarget||!donorAnimationCallWorker||donorMessageImageSize<DONOR_ANIMATION_MARKER_RVA+sizeof(body)||!worldRead(donorMessageBase+DONOR_ANIMATION_MARKER_RVA,body,sizeof(body))||memcmp(body,donorAnimationMarkerEntry,sizeof(donorAnimationMarkerEntry))||!hashBytes(body,sizeof(body),digest)||strcmp(digest,DONOR_ANIMATION_MARKER_SHA256))return false;
 donorAnimationMarkerInit(&donorAnimationMarkers,NULL,donorAnimationMarkerReadLease,donorAnimationMarkerSnapshot);if(!donorAnimationMarkers.configured)return false;
 PVOID target=(PVOID)(donorMessageBase+DONOR_ANIMATION_MARKER_RVA);
 if(MH_CreateHook(target,(PVOID)donorAnimationMarkerHook,(PVOID *)&donorAnimationMarkerOriginal)!=MH_OK||!donorAnimationMarkerOriginal)return false;
 if(MH_EnableHook(target)!=MH_OK){MH_RemoveHook(target);return false;}donorAnimationMarkerTarget=target;
 donorAnimationMarkerWorker=CreateThread(NULL,0,donorAnimationMarkerCollect,NULL,0,NULL);
 if(!donorAnimationMarkerWorker){MH_STATUS disabled=MH_DisableHook(target);if(disabled==MH_OK||disabled==MH_ERROR_DISABLED)donorAnimationMarkerTarget=NULL;return false;}return true;
}
static bool donorAnimationMarkerStop(void){
 bool complete=true;InterlockedExchange(&donorAnimationMarkerStopping,1);
 if(donorAnimationMarkerTarget){MH_STATUS s=MH_DisableHook(donorAnimationMarkerTarget);if(s==MH_OK||s==MH_ERROR_DISABLED)donorAnimationMarkerTarget=NULL;else complete=false;}
 if(donorAnimationMarkerWorker){DWORD waited=WaitForSingleObject(donorAnimationMarkerWorker,5000);if(waited==WAIT_OBJECT_0){DWORD code=1;if(!GetExitCodeThread(donorAnimationMarkerWorker,&code)||code!=0)complete=false;if(CloseHandle(donorAnimationMarkerWorker))donorAnimationMarkerWorker=NULL;else complete=false;}else complete=false;}
 logLine("DONOR_ANIMATION_MARKER_SHUTDOWN complete=%d; trampoline retained",complete);return complete;
}
