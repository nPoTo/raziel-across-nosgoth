// SPDX-License-Identifier: GPL-3.0-or-later
// Cross-language owned-file fixture. No game handles, calls, hooks or resources.
#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <stdbool.h>
#include <stdint.h>
#include <stdio.h>
#include <string.h>
#include <wchar.h>
#include "recording-status.h"
#include "guidance-plan.h"
int wmain(int argc,wchar_t **argv){
 if(argc==2&&!wcscmp(argv[1],L"--clock")){printf("{\"tick\":%llu}\n",(unsigned long long)GetTickCount64());return 0;}
 if(argc!=3||wcscmp(argv[1],L"--read"))return 2;
 unsigned plan=(unsigned)wcstoul(argv[2],NULL,10);if(plan!=10&&plan!=11)return 3;
 const DWORD gamePid=42;RecordingStatus status={0};GuidanceDescriptor descriptor={0};
 SetLastError(0);bool statusRead=recordingReadStatus(gamePid,&status);DWORD statusError=GetLastError();uint64_t now=GetTickCount64();
 bool statusValid=statusRead&&recordingStatusValid(&status,gamePid,now);
 wchar_t statusPath[512],guidancePath[512];recordingStatusPath(statusPath,gamePid);_snwprintf(guidancePath,ARRAYSIZE(guidancePath),PROBE_PATH(L"\\guidance-%lu.bin"),gamePid);
 SetLastError(0);HANDLE f=CreateFileW(guidancePath,GENERIC_READ,FILE_SHARE_READ|FILE_SHARE_WRITE|FILE_SHARE_DELETE,NULL,OPEN_EXISTING,FILE_ATTRIBUTE_NORMAL,NULL);DWORD openError=GetLastError();LARGE_INTEGER size={0};DWORD read=0;
 bool descriptorRead=f!=INVALID_HANDLE_VALUE&&GetFileSizeEx(f,&size)&&size.QuadPart==sizeof(descriptor)&&ReadFile(f,&descriptor,sizeof(descriptor),&read,NULL)&&read==sizeof(descriptor);DWORD descriptorError=GetLastError();if(f!=INVALID_HANDLE_VALUE)CloseHandle(f);
 bool descriptorValid=descriptorRead&&guidanceDescriptorValid(&descriptor,gamePid,status.writerPid,status.total);
 bool pathReadable=GetFileAttributesW(statusPath)!=INVALID_FILE_ATTRIBUTES&&GetFileAttributesW(guidancePath)!=INVALID_FILE_ATTRIBUTES;
 printf("{\"statusRead\":%s,\"statusValid\":%s,\"statusError\":%lu,\"descriptorRead\":%s,\"descriptorValid\":%s,\"descriptorOpenError\":%lu,\"descriptorError\":%lu,\"pathReadable\":%s,\"statusBytes\":%zu,\"descriptorBytes\":%zu,\"descriptorReadBytes\":%lu,\"descriptorFileBytes\":%lld,\"statusMagic\":%u,\"descriptorMagic\":%u,\"gamePid\":%u,\"writer\":%u,\"descriptorWriter\":%u,\"plan\":%u,\"seconds\":%u,\"total\":%u,\"heartbeatTick\":%llu,\"now\":%llu,\"sheetHash\":\"%s\"}\n",
 statusRead?"true":"false",statusValid?"true":"false",(unsigned long)statusError,descriptorRead?"true":"false",descriptorValid?"true":"false",(unsigned long)openError,(unsigned long)descriptorError,pathReadable?"true":"false",sizeof(status),sizeof(descriptor),(unsigned long)read,(long long)size.QuadPart,status.magic,descriptor.magic,status.gamePid,status.writerPid,descriptor.writerPid,descriptor.plan,descriptor.seconds,status.total,(unsigned long long)status.tick,(unsigned long long)now,EXPLORATION_SHEET_SHA256);
 return statusValid&&descriptorValid&&descriptor.plan==plan&&pathReadable?0:1;
}
