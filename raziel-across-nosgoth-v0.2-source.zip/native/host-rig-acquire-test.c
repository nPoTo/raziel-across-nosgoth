// SPDX-License-Identifier: GPL-3.0-or-later
#define main priorFixture
#include "host-rig-reader-test.c"
#undef main
#include "host-rig-acquire.h"
static unsigned changeAt;static bool alwaysSwap,nativeState;static uint64_t clockStep,clockValue;
static bool swapRead(void *c,uintptr_t at,void *out,SIZE_T n){
 if(at==0x100000+0x2a89310&&((alwaysSwap&&globalReads%4==1)||globalReads==changeAt)){
  uintptr_t p=0;memcpy(&p,blocks[1].data+0x70,8);p=p==blocks[8].at?blocks[8].at+128:blocks[8].at;u64(1,0x70,p);
 }
 return readFixture(c,at,out,n);
}
static bool contextFixture(void *c,RigRead read,uintptr_t base,uintptr_t actor,bool foreground,Sr1RetargetContext *s){
 (void)c;(void)read;(void)base;memset(s,0,sizeof(*s));s->identity=actor==0x50000;s->foreground=foreground;s->verticalVelocityKnown=true;
 for(unsigned i=0;i<3;i++)s->callbacks[i]=nativeState?0xefb50:0xf2180;return s->identity;
}
static uint64_t clockFixture(void *c){(void)c;uint64_t v=clockValue;clockValue+=clockStep;return v;}
static void reset(void){setup();changeAt=UINT32_MAX;alwaysSwap=nativeState=false;clockStep=10;clockValue=100;}
int main(void){
 RigAcquisition a;reset();CHECK(rigAcquire(NULL,swapRead,0x100000,true,contextFixture,clockFixture,&a)&&a.attempts==1,101);
 reset();changeAt=1;CHECK(rigAcquire(NULL,swapRead,0x100000,true,contextFixture,clockFixture,&a)&&a.attempts==2&&a.retries==1&&a.same,102);
 reset();changeAt=3;CHECK(rigAcquire(NULL,swapRead,0x100000,true,contextFixture,clockFixture,&a)&&a.attempts==2,103);
 reset();alwaysSwap=true;CHECK(!rigAcquire(NULL,swapRead,0x100000,true,contextFixture,clockFixture,&a)&&a.attempts==3&&!a.same,104);
 reset();alwaysSwap=true;clockStep=4000;CHECK(!rigAcquire(NULL,swapRead,0x100000,true,contextFixture,clockFixture,&a)&&a.attempts==1,105);
 reset();changeAt=1;nativeState=true;CHECK(!rigAcquire(NULL,swapRead,0x100000,true,contextFixture,clockFixture,&a)&&a.attempts==1,106);
 reset();changeAt=1;CHECK(!rigAcquire(NULL,swapRead,0x100000,false,contextFixture,clockFixture,&a)&&a.attempts==1,107);
 reset();blocks[3].data[0]='k';CHECK(!rigAcquire(NULL,swapRead,0x100000,true,contextFixture,clockFixture,&a)&&a.attempts==1,108);
 puts("PASS: strict full read retries recover buffer switches; repeated races/budget/native/focus/wrong identity refuse without publication.");return 0;
}
