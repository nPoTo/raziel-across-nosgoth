// Read-only observer of the build-gated donor's explicit bounded IPC stream.
#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <stdint.h>
#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <wchar.h>
#include <math.h>
#include "direct-motion-shared.h"
#include "direct-motion-consumer.h"
#include "recording-status.h"
#include "test-tutorial-plan.h"
int wmain(int argc,wchar_t **argv){
 if(argc!=5){fprintf(stderr,"Usage: direct-motion-reader PID SAMPLES INTERVAL_MS OUTPUT_JSONL\n");return 1;}
 wchar_t *end;DWORD pid=wcstoul(argv[1],&end,10);if(!pid||*end)return 2;
 unsigned samples=wcstoul(argv[2],&end,10);if(!samples||samples>3600||*end)return 2;
 DWORD interval=wcstoul(argv[3],&end,10);if(interval<16||interval>100||*end)return 2;
 HANDLE process=OpenProcess(PROCESS_QUERY_LIMITED_INFORMATION|SYNCHRONIZE,FALSE,pid);if(!process)return 3;
 wchar_t path[32768];DWORD length=ARRAYSIZE(path);
 if(!QueryFullProcessImageNameW(process,0,path,&length)||_wcsicmp(path,L"C:\\Program Files (x86)\\Steam\\steamapps\\common\\Legacy of Kain Defiance Remastered\\defiance.exe")){CloseHandle(process);return 4;}
 FILE *out=_wfopen(argv[4],L"wb");if(!out){CloseHandle(process);return 5;}
 fprintf(out,"{\"type\":\"session\",\"schema\":1,\"pid\":%lu,\"mode\":\"read-only shared motion\"}\n",pid);
 HANDLE mapping=NULL;const DirectMotionShared *view=NULL;DirectMotionCursor cursor={0};unsigned valid=0,fresh=0;uint64_t start=GetTickCount64(),heartbeat=0;
 for(unsigned i=0;i<samples;i++){
  uint64_t elapsed=GetTickCount64()-start;if(elapsed>=TUTORIAL_SECONDS*1000||WaitForSingleObject(process,0)==WAIT_OBJECT_0)break;
  if(!heartbeat||GetTickCount64()-heartbeat>=250){recordingWriteStatus(pid,(uint32_t)(elapsed/100)+1,TUTORIAL_SECONDS*10);heartbeat=GetTickCount64();}
  if(!view){wchar_t name[96];directMotionName(name,pid);mapping=OpenFileMappingW(FILE_MAP_READ,FALSE,name);if(mapping)view=MapViewOfFile(mapping,FILE_MAP_READ,0,0,sizeof(DirectMotionShared));if(mapping&&!view){CloseHandle(mapping);mapping=NULL;}}
  DirectMotionSnapshot s={0};uint64_t now=GetTickCount64();double delta[2];unsigned result=directMotionCopy(view,&s)?directMotionDelta(&cursor,&s,pid,now,delta):0;
  fprintf(out,"{\"type\":\"sample\",\"sequence\":%u,\"tickMs\":%llu,\"valid\":%s,\"result\":%u",i,(unsigned long long)now,result?"true":"false",result);
  if(result){++valid;if(result==2)++fresh;fprintf(out,",\"sourceTick\":%llu,\"epoch\":%llu,\"nativeSamples\":%u,\"xy\":[%.12g,%.12g],\"delta\":[%.12g,%.12g],\"z\":%.9g,\"height\":%.9g,\"root\":[",(unsigned long long)s.tick,(unsigned long long)s.epoch,s.samples,s.xy[0],s.xy[1],delta[0],delta[1],s.z,s.z-s.baseZ);for(unsigned k=0;k<9;k++){if(k)fputc(',',out);fprintf(out,"%.9g",s.root[k]);}fputc(']',out);}
  fprintf(out,"}\n");fflush(out);Sleep(interval);
 }
 recordingStopStatus(pid);if(view)UnmapViewOfFile(view);if(mapping)CloseHandle(mapping);fclose(out);CloseHandle(process);printf("Direct motion read-only: %u valid, %u fresh deltas\n",valid,fresh);return 0;
}
