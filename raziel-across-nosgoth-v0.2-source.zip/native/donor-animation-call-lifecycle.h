// SPDX-License-Identifier: GPL-3.0-or-later
// Original native calls only. All persisted records are scalar metadata.
#pragma once
#include "donor-animation-selection-reader.h"
#include "donor-animation-call-observer.h"
#include "donor-animation-call-proof.h"
static DonorAnimationCallObserver donorAnimationCalls;
static _Thread_local DonorMessageObserverThread donorAnimationCallThread;
static DonorNativeAnimationSelect donorAnimationCallOriginal;
static PVOID donorAnimationCallTarget;
static HANDLE donorAnimationCallWorker;
static volatile LONG donorAnimationCallStopping,donorAnimationCallActive;
static bool donorAnimationCallReadLease(void *unused,DonorMessageLease *out){
 if(InterlockedCompareExchange(&donorAnimationCallStopping,0,0))return false;
 return donorMessageLease(unused,out)&&!InterlockedCompareExchange(&donorAnimationCallStopping,0,0);
}
static bool donorAnimationCallSnapshot(void *unused,void *actor,int32_t section,void *descriptor,DonorAnimationCallMetadata *out){
 (void)unused;uintptr_t a=(uintptr_t)actor,state=0,again=0,cached=0,owner=0;
 if(section<0||section>2||!donorProcessIdentity(a)||!worldRead(a+0x3f8,&state,8)||!state||state>UINTPTR_MAX-0x700)return false;
 DonorAnimationSelection r=donorAnimationSelectionRead(NULL,donorMessageRead,donorMessageCode,donorMessageBase,donorMessageImageSize,a);
 if(!r.valid||!worldRead(a+0x3f8,&again,8)||again!=state||!worldRead(state,&owner,8)||owner!=a||!worldRead(state+0x250+(uintptr_t)section*0x250,&cached,8)||!worldRead(a+0x3f8,&again,8)||again!=state||!donorProcessIdentity(a))return false;
 out->key=r.sections[section].selectionKeyRaw;out->clip=r.sections[section].animationId;out->opaqueState=state;out->descriptorMatches=cached==(uintptr_t)descriptor;return true;
}
static uintptr_t __fastcall donorAnimationCallHook(void *actor,int32_t section,void *descriptor,int32_t a,int32_t b,int32_t c){
 DWORD incoming=GetLastError();InterlockedIncrement(&donorAnimationCallActive);
 uintptr_t caller=(uintptr_t)__builtin_return_address(0);uint32_t callerRva=caller>=donorMessageBase&&caller-donorMessageBase<donorMessageImageSize?(uint32_t)(caller-donorMessageBase):0;
 uint32_t parent=(DWORD)InterlockedCompareExchange(&donorMessageThreadState.ownerThread,0,0)==GetCurrentThreadId()?donorMessageThreadState.depth:0;
 SetLastError(incoming);uintptr_t result=donorAnimationCallForward(&donorAnimationCalls,&donorAnimationCallThread,donorAnimationCallOriginal,actor,section,descriptor,a,b,c,callerRva,parent);
 DWORD outgoing=GetLastError();InterlockedDecrement(&donorAnimationCallActive);SetLastError(outgoing);return result;
}
static void donorAnimationCallDrain(void){
 DonorAnimationCallEvent e;unsigned n=0;
 while(n++<512&&donorAnimationCallPop(&donorAnimationCalls,&e))logLine("DONOR_ANIMATION_CALL {\"session\":\"%llu\",\"callId\":%llu,\"tickMs\":%llu,\"phase\":%u,\"threadId\":%u,\"depth\":%u,\"callerRva\":%u,\"messageDepth\":%u,\"section\":%u,\"overrides\":[%d,%d,%d],\"key\":%u,\"clip\":%u,\"afterValid\":%u,\"sameState\":%u,\"descriptorMatches\":%u}",
  (unsigned long long)e.session,(unsigned long long)e.callId,(unsigned long long)e.tickMs,e.phase,e.threadId,e.depth,e.callerRva,e.messageDepth,e.section,e.overrides[0],e.overrides[1],e.overrides[2],e.key,e.clip,e.afterValid,e.sameState,e.descriptorMatches);
}
static DWORD WINAPI donorAnimationCallCollect(LPVOID unused){
 (void)unused;uint64_t session=0,revoke=0;
 for(;;){
  DonorMessageLease l={0};bool ready=donorAnimationCallReadLease(NULL,&l)&&donorMessageLeaseValid(&l);
  if(ready&&!session){session=l.session;logLine("DONOR_ANIMATION_CALL_SESSION session=%llu start=%llu; native calls only",(unsigned long long)session,(unsigned long long)l.startTick);}
  donorAnimationCallDrain();
  if((session&&!ready)||InterlockedCompareExchange(&donorAnimationCallStopping,0,0)){
   if(!revoke)revoke=GetTickCount64();
   if(!InterlockedCompareExchange(&donorAnimationCallActive,0,0)){
    donorAnimationCallDrain();logLine("DONOR_ANIMATION_CALL_END session=%llu published=%llu dropped=%llu forwarded=%llu; synthetic_calls=0",(unsigned long long)session,(unsigned long long)InterlockedCompareExchange64(&donorAnimationCalls.published,0,0),(unsigned long long)InterlockedCompareExchange64(&donorAnimationCalls.dropped,0,0),(unsigned long long)InterlockedCompareExchange64(&donorAnimationCalls.forwarded,0,0));return 0;
   }
   if(GetTickCount64()-revoke>=3000){logLine("DONOR_ANIMATION_CALL_SHUTDOWN incomplete active calls; END withheld");return 1;}
  }
  Sleep(50);
 }
}
static bool donorAnimationCallInstall(void){
 unsigned char body[DONOR_ANIMATION_CALL_BYTES];char digest[65];
 if(!donorMessageTarget||!donorMessageWorker||donorMessageImageSize<DONOR_ANIMATION_CALL_RVA+sizeof(body)||!worldRead(donorMessageBase+DONOR_ANIMATION_CALL_RVA,body,sizeof(body))||memcmp(body,donorAnimationCallEntry,sizeof(donorAnimationCallEntry))||!hashBytes(body,sizeof(body),digest)||strcmp(digest,DONOR_ANIMATION_CALL_SHA256))return false;
 donorAnimationCallInit(&donorAnimationCalls,NULL,donorAnimationCallReadLease,donorAnimationCallSnapshot);
 if(!donorAnimationCalls.configured)return false;
 PVOID target=(PVOID)(donorMessageBase+DONOR_ANIMATION_CALL_RVA);
 if(MH_CreateHook(target,(PVOID)donorAnimationCallHook,(PVOID *)&donorAnimationCallOriginal)!=MH_OK||!donorAnimationCallOriginal)return false;
 if(MH_EnableHook(target)!=MH_OK){MH_RemoveHook(target);return false;}donorAnimationCallTarget=target;
 donorAnimationCallWorker=CreateThread(NULL,0,donorAnimationCallCollect,NULL,0,NULL);
 if(!donorAnimationCallWorker){MH_STATUS disabled=MH_DisableHook(target);if(disabled==MH_OK||disabled==MH_ERROR_DISABLED)donorAnimationCallTarget=NULL;return false;}return true;
}
static bool donorAnimationCallStop(void){
 bool complete=true;InterlockedExchange(&donorAnimationCallStopping,1);
 if(donorAnimationCallTarget){MH_STATUS s=MH_DisableHook(donorAnimationCallTarget);if(s==MH_OK||s==MH_ERROR_DISABLED)donorAnimationCallTarget=NULL;else complete=false;}
 if(donorAnimationCallWorker){DWORD waited=WaitForSingleObject(donorAnimationCallWorker,5000);if(waited==WAIT_OBJECT_0){DWORD code=1;if(!GetExitCodeThread(donorAnimationCallWorker,&code)||code!=0)complete=false;if(CloseHandle(donorAnimationCallWorker))donorAnimationCallWorker=NULL;else complete=false;}else complete=false;}
 logLine("DONOR_ANIMATION_CALL_SHUTDOWN complete=%d; trampoline retained",complete);return complete;
}
