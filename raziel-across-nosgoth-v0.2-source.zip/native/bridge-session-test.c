// SPDX-License-Identifier: GPL-3.0-or-later
#include <stdio.h>
#include "bridge-session.h"
#define CHECK(x) do{if(!(x)){printf("FAIL bridge session line%d\n",__LINE__);return 1;}}while(0)
static BridgeSessionObservation healthy(void){
 BridgeSessionObservation o={.hostAlive=true,.donorAlive=true,.identified=true,.contractValid=true,.actorReady=true,.activate=true,.now=1000,.heartbeat=950,.requestedOwnership=BRIDGE_OWN_BODY|BRIDGE_OWN_INPUT|BRIDGE_OWN_TRANSPORT|BRIDGE_OWN_HELPERS};
 o.identity=(BridgeIdentity){.sourcePid=99,.hostPid=42,.sourceCreation=111,.hostCreation=222,.sessionGeneration=7,.levelGeneration=9,.actorId=1,.actorGeneration=2,.capabilities=15};
 bridgeHex(sheet_bridgeProtocol_session_v2.sourceBuild,o.identity.sourceBuild);bridgeHex(sheet_bridgeProtocol_session_v2.hostBuild,o.identity.hostBuild);return o;
}
static int activate(BridgeSession *s,BridgeSessionObservation *o){
 bridgeSessionBegin(s);
 CHECK(bridgeSessionStep(s,o).state==BRIDGE_VALIDATING);
 CHECK(bridgeSessionStep(s,o).state==BRIDGE_WAITING);
 CHECK(bridgeSessionStep(s,o).state==BRIDGE_READY);
 BridgeSessionEffects e=bridgeSessionStep(s,o);CHECK(e.state==BRIDGE_ACTIVE&&e.acquire==o->requestedOwnership);
 CHECK(bridgeSessionAcknowledge(s,0,e.acquire));return 0;
}
int main(void){
 BridgeSession s;BridgeSessionObservation o=healthy();BridgeSessionEffects e;
 bridgeSessionBegin(&s);o.donorAlive=false;CHECK(bridgeSessionStep(&s,&o).state==BRIDGE_DISCOVERING);
 o=healthy();CHECK(!activate(&s,&o));
 o.paused=true;e=bridgeSessionStep(&s,&o);CHECK(e.state==BRIDGE_PAUSED&&e.release==o.requestedOwnership&&!e.acquire);
 o.paused=false;e=bridgeSessionStep(&s,&o);CHECK(e.state==BRIDGE_PAUSED&&e.release==o.requestedOwnership&&!e.acquire);
 CHECK(!bridgeSessionAcknowledge(&s,0,BRIDGE_OWN_CAMERA));CHECK(bridgeSessionAcknowledge(&s,e.release,0));
 CHECK(bridgeSessionStep(&s,&o).state==BRIDGE_READY);CHECK(bridgeSessionStep(&s,&o).state==BRIDGE_ACTIVE);
 CHECK(bridgeSessionAcknowledge(&s,0,s.desired));
 o.loading=true;e=bridgeSessionStep(&s,&o);CHECK(e.state==BRIDGE_TRANSITIONING&&e.release==s.owned);
 CHECK(bridgeSessionAcknowledge(&s,e.release,0));o.loading=false;CHECK(bridgeSessionStep(&s,&o).state==BRIDGE_READY);
 CHECK(!activate(&s,&o));o.actorReady=false;CHECK(bridgeSessionStep(&s,&o).state==BRIDGE_TRANSITIONING);
 o=healthy();CHECK(!activate(&s,&o));o.lockBusy=true;e=bridgeSessionStep(&s,&o);CHECK(e.state==BRIDGE_PAUSED&&e.release==s.owned);
 CHECK(bridgeSessionAcknowledge(&s,e.release,0));o.lockBusy=false;CHECK(bridgeSessionStep(&s,&o).state==BRIDGE_READY);
 o=healthy();CHECK(!activate(&s,&o));o.abandoned=true;e=bridgeSessionStep(&s,&o);CHECK(e.state==BRIDGE_RECOVERING&&e.release==s.owned);
 CHECK(bridgeSessionStep(&s,&o).state==BRIDGE_RECOVERING);CHECK(bridgeSessionAcknowledge(&s,s.owned,0));
 CHECK(bridgeSessionStep(&s,&o).state==BRIDGE_DISCOVERING);o.abandoned=false;
 CHECK(bridgeSessionStep(&s,&o).state==BRIDGE_VALIDATING);
 for(unsigned fault=0;fault<6;fault++){
  o=healthy();CHECK(!activate(&s,&o));
  switch(fault){case 0:o.donorAlive=false;break;case 1:o.hostAlive=false;break;case 2:o.heartbeat=499;break;case 3:o.heartbeat=1001;break;case 4:o.identity.levelGeneration++;break;default:o.identity.sourceCreation++;break;}
  e=bridgeSessionStep(&s,&o);CHECK(e.state==BRIDGE_RECOVERING&&e.release==s.owned&&!e.acquire);
  CHECK(bridgeSessionStep(&s,&o).state==BRIDGE_RECOVERING);CHECK(bridgeSessionAcknowledge(&s,s.owned,0));
  CHECK(bridgeSessionStep(&s,&o).state==BRIDGE_DISCOVERING);
 }
 o=healthy();CHECK(!activate(&s,&o));o.stop=true;e=bridgeSessionStep(&s,&o);CHECK(e.state==BRIDGE_STOPPING&&e.release==s.owned);
 CHECK(bridgeSessionStep(&s,&o).state==BRIDGE_STOPPING);CHECK(bridgeSessionAcknowledge(&s,s.owned,0));
 CHECK(bridgeSessionStep(&s,&o).state==BRIDGE_DISABLED);o.stop=false;CHECK(bridgeSessionStep(&s,&o).state==BRIDGE_DISABLED);
 for(unsigned invalid=0;invalid<3;invalid++){
  o=healthy();CHECK(!activate(&s,&o));if(invalid==0)o.unsupported=true;else if(invalid==1)o.now=999;else o.requestedOwnership|=BRIDGE_OWN_CAMERA;
  e=bridgeSessionStep(&s,&o);CHECK(e.state==BRIDGE_DISABLED&&e.release==s.owned&&!e.acquire);
 }
 o=healthy();CHECK(!activate(&s,&o));
 o.requestedOwnership=BRIDGE_OWN_INPUT;e=bridgeSessionStep(&s,&o);CHECK(e.release==(BRIDGE_OWN_BODY|BRIDGE_OWN_TRANSPORT|BRIDGE_OWN_HELPERS)&&!e.acquire);
 CHECK(!bridgeSessionAcknowledge(&s,0,BRIDGE_OWN_INPUT));CHECK(bridgeSessionAcknowledge(&s,e.release,0));
 for(unsigned step=0;step<100000;step++){o.now++;o.heartbeat=o.now;e=bridgeSessionStep(&s,&o);CHECK(e.state==BRIDGE_ACTIVE&&!e.acquire&&!e.release&&s.owned==BRIDGE_OWN_INPUT);}
 puts("PASS: session discovery/validation/readiness, pause/load/actor loss, busy/abandoned lock, crash/stale/future/epoch recovery, cleanup acknowledgment, unsupported/camera/clock rejection, stop and 100000 bounded steps");
 return 0;
}
