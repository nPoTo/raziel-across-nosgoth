// SPDX-License-Identifier: GPL-3.0-or-later
// Main-worker-owned scalar lease. Native callbacks only inspect atomic deadlines.
#include "session-budget.h"
#include "bridge-protocol.h"
#include "bridge-process-identity.h"
static volatile LONG64 lifetimeTick;
static HANDLE lifetimeProcesses[3];
static unsigned char lifetimeIdentity[48];
static bool lifetimeRequested(void){wchar_t path[32768];_snwprintf(path,ARRAYSIZE(path),L"%ls\\%ls.enable",PROBE_REPORT_DIR,sheet_sessionLifetime_session.normalFlag);return GetFileAttributesW(path)!=INVALID_FILE_ATTRIBUTES;}
static int lifetimeBudgetStatus(uint64_t now){if(!lifetimeRequested())return -1;uint64_t tick=(uint64_t)InterlockedCompareExchange64(&lifetimeTick,0,0);return tick&&tick<=now&&now-tick<=(uint64_t)sheet_sessionLifetime_session.leaseAgeMs?1:0;}
static void lifetimeClose(void){InterlockedExchange64(&lifetimeTick,0);for(unsigned n=0;n<3;n++){if(lifetimeProcesses[n])CloseHandle(lifetimeProcesses[n]);lifetimeProcesses[n]=NULL;}memset(lifetimeIdentity,0,sizeof(lifetimeIdentity));}
static bool lifetimeLeaseShape(const unsigned char b[56],uint64_t now){return bridgeU32(b)==0x31465a52&&bridgeU32(b+4)==1&&bridgeU32(b+8)&&bridgeU32(b+12)&&bridgeU32(b+16)&&!bridgeU32(b+20)&&bridgeU32(b+8)!=bridgeU32(b+12)&&bridgeU64(b+24)&&bridgeU64(b+32)&&bridgeU64(b+40)&&bridgeU64(b+48)&&bridgeU64(b+48)<=now&&now-bridgeU64(b+48)<=(uint64_t)sheet_sessionLifetime_session.leaseAgeMs;}
static void lifetimePoll(void){
 if(!lifetimeRequested()){lifetimeClose();return;}
 wchar_t path[32768];_snwprintf(path,ARRAYSIZE(path),L"%ls\\%ls",PROBE_REPORT_DIR,sheet_sessionLifetime_session.leaseFile);
 HANDLE file=CreateFileW(path,GENERIC_READ,FILE_SHARE_READ|FILE_SHARE_WRITE|FILE_SHARE_DELETE,NULL,OPEN_EXISTING,FILE_ATTRIBUTE_NORMAL,NULL);unsigned char b[56];LARGE_INTEGER size;DWORD read=0;
 bool valid=file!=INVALID_HANDLE_VALUE&&GetFileSizeEx(file,&size)&&size.QuadPart==sizeof(b)&&ReadFile(file,b,sizeof(b),&read,NULL)&&read==sizeof(b);if(file!=INVALID_HANDLE_VALUE)CloseHandle(file);
 uint64_t now=GetTickCount64();if(!valid||!lifetimeLeaseShape(b,now)||(bridgeU32(b+8)!=GetCurrentProcessId()&&bridgeU32(b+12)!=GetCurrentProcessId())){lifetimeClose();return;}
 if(memcmp(lifetimeIdentity,b,48)){
  lifetimeClose();
  for(unsigned n=0;n<3;n++){
   lifetimeProcesses[n]=OpenProcess(SYNCHRONIZE|PROCESS_QUERY_LIMITED_INFORMATION,FALSE,bridgeU32(b+8+n*4));uint64_t creation=0;
   if(!lifetimeProcesses[n]||!bridgeProcessCreation(lifetimeProcesses[n],&creation)||creation!=bridgeU64(b+24+n*8)){lifetimeClose();return;}
  }
  memcpy(lifetimeIdentity,b,48);
 }
 for(unsigned n=0;n<3;n++)if(WaitForSingleObject(lifetimeProcesses[n],0)!=WAIT_TIMEOUT){lifetimeClose();return;}
 InterlockedExchange64(&lifetimeTick,(LONG64)bridgeU64(b+48));
}
