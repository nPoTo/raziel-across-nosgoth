// SPDX-License-Identifier: GPL-3.0-or-later
#pragma once
#include "host-block-state-reader.h"
typedef struct {uint32_t section,queueKind,index,handlerRva;uintptr_t opaqueActor;} HostEnqueueMetadata;
// 0 means unrelated queue, -1 means current-player queue but invalid snapshot.
static inline int hostEnqueueRead(void *c,HostBlockRead read,HostBlockCode code,uintptr_t base,uint32_t size,uintptr_t queue,HostEnqueueMetadata *out){
 const Sheet_hostBlockStateProbe *p=&sheet_hostBlockStateProbe_current;
 if(!read||!code||!base||size<0x2a89318||base>UINTPTR_MAX-size||p->stateRva!=0x2a88588||p->sectionStride!=0x228||p->sectionCount!=3||p->eventQueueOffset!=0x18||p->deferQueueOffset!=0x120)return -1;
 bool found=false;uint32_t section=0,kind=0;
 for(uint32_t i=0;i<3;i++)for(uint32_t k=0;k<2;k++)if(queue==base+(uintptr_t)p->stateRva+(uintptr_t)i*0x228+(k?0x120:0x18)){found=true;section=i;kind=k;}
 if(!found)return 0;
 uintptr_t actor=0,owner=0,again=0,callback=0,callbackAgain=0;int32_t index=-1;
 uintptr_t state=base+(uintptr_t)p->stateRva,sectionState=state+(uintptr_t)section*0x228;
 if(!read(c,base+(uintptr_t)p->currentActorRva,&actor,8)||!actor||actor%8||!read(c,state,&owner,8)||owner!=actor||!read(c,sectionState+0x10,&callback,8)||callback<base||callback-base>=size||!code(c,callback,base)||!read(c,queue+4,&index,4)||index<0||index>=16||!read(c,sectionState+0x10,&callbackAgain,8)||callbackAgain!=callback||!read(c,state,&again,8)||again!=actor||!read(c,base+(uintptr_t)p->currentActorRva,&again,8)||again!=actor)return -1;
 *out=(HostEnqueueMetadata){section,kind,(uint32_t)index,(uint32_t)(callback-base),actor};return 1;
}
