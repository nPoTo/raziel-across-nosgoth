#include "report-path.h"
// Physics observation; explicit bounded airborne attack support is default off.
#include "physics-code-proof.h"
#include "air-hold.h"
#ifdef SR1_LIFT_FOLLOW
#include "sr1-lift-follow.h"
#endif
#ifdef SR1_AIR_PHYSICS_CLOCK
#include "sr1-air-clock.h"
#endif
static volatile LONG airHoldEnabled;
static ULONGLONG airHoldBegin;
static bool airHoldRequested,airHoldFailed;
static AirHoldTimer airHoldTimer;
static unsigned airHoldFrames;
typedef void (__fastcall *SrPhysicsFn)(uintptr_t,int32_t,int32_t,int32_t);
static SrPhysicsFn originalPhysics;
static PVOID physicsTarget;
static bool physicsAttempted;
static volatile LONG physicsEnabled,physicsLock,physicsDrops;
static ULONGLONG physicsBegin;
static unsigned physicsHead,physicsTail,physicsRecords;
typedef struct {ULONGLONG tick;uintptr_t player;int32_t segment,time,clamp,pre[6],post[6];int16_t before[3],after[3];bool held,zeroed;} PhysicsEvent;
static PhysicsEvent physicsQueue[256];
static void __fastcall observePhysics(uintptr_t instance,int32_t segment,int32_t time,int32_t clamp){
    PhysicsEvent e={0};uintptr_t player=0;float root[16];
    bool recording=InterlockedCompareExchange(&physicsEnabled,0,0)!=0;
    bool airEnabled=InterlockedCompareExchange(&airHoldEnabled,0,0)!=0;
    bool valid=(recording||airEnabled)&&worldRoot(root,&player)&&player==instance;
    if(valid){e.tick=GetTickCount64();e.player=player;e.segment=segment;e.time=time;e.clamp=clamp;
        valid=worldRead(instance+0x2cc,e.pre,sizeof(e.pre))&&worldRead(instance+0x9c,e.before,sizeof(e.before));}
    DWORD foreground=0;GetWindowThreadProcessId(GetForegroundWindow(),&foreground);
    AirHoldScope scope={0};scope.now=GetTickCount64();
    if(valid){scope=(AirHoldScope){airEnabled&&!airHoldFailed,overlayAirSupport,foreground==GetCurrentProcessId(),e.tick,airHoldBegin,overlayLiveTick,worldLastDraw,srJumpLaunch,
        player,srJumpPlayer,worldLastInstance,(float)e.before[2]-srJumpBaseZ,root[10],segment,time,clamp,e.pre[2],e.pre[5]};}
    e.held=airHoldStep(&airHoldTimer,&scope);
    int32_t submittedTime=time;
#ifdef SR1_AIR_PHYSICS_CLOCK
    if(!e.held)submittedTime=srAirClockTime(instance,segment,time,clamp);
    if(submittedTime!=time)logLine("SR1_AIR_CLOCK tick=%llu original=%d submitted=%d scalar_time_only=1",GetTickCount64(),time,submittedTime);
#endif
    originalPhysics(instance,segment,submittedTime,e.held?1:clamp);
    if(!valid||!worldRead(instance+0x2cc,e.post,sizeof(e.post))||!worldRead(instance+0x9c,e.after,sizeof(e.after)))return;
    if(e.held){
        uintptr_t afterPlayer=0;float afterRoot[16];int32_t zero=0;SIZE_T written=0;
        e.zeroed=e.after[2]==e.before[2]&&worldRoot(afterRoot,&afterPlayer)&&afterPlayer==player&&
            WriteProcessMemory(GetCurrentProcess(),(PVOID)(instance+0x2d4),&zero,sizeof(zero),&written)&&written==sizeof(zero);
        if(e.zeroed){e.post[2]=0;++airHoldFrames;}
        else {airHoldFailed=true;InterlockedExchange(&airHoldEnabled,0);logLine("SR1_AIR_HOLD stopped: identity/position/velocity update failed");}
    }
    if(!recording)return;
    if(!InterlockedCompareExchange(&physicsLock,1,0)){
        if(!physicsBegin)physicsBegin=e.tick;
        unsigned next=(physicsHead+1)%ARRAYSIZE(physicsQueue);
        if(e.tick>=physicsBegin&&e.tick-physicsBegin<120000&&physicsRecords<2500){
            if(next!=physicsTail){physicsQueue[physicsHead]=e;physicsHead=next;++physicsRecords;}
            else InterlockedIncrement(&physicsDrops);
        }
        InterlockedExchange(&physicsLock,0);
    }else InterlockedIncrement(&physicsDrops);
}
static void physicsFlush(void){
    PhysicsEvent local[256];unsigned count=0;
    if(InterlockedCompareExchange(&physicsLock,1,0))return;
    while(physicsTail!=physicsHead){local[count++]=physicsQueue[physicsTail];physicsTail=(physicsTail+1)%ARRAYSIZE(physicsQueue);}
    InterlockedExchange(&physicsLock,0);
    for(unsigned i=0;i<count;++i){PhysicsEvent *e=&local[i];
        logLine("SR1_PHYSICS tick=%llu player=%p segment=%d time=%d clamp=%d pre_v=%d,%d,%d pre_a=%d,%d,%d post_v=%d,%d,%d post_a=%d,%d,%d pos_before=%d,%d,%d pos_after=%d,%d,%d held=%d zeroed=%d",
            e->tick,(void *)e->player,e->segment,e->time,e->clamp,e->pre[0],e->pre[1],e->pre[2],e->pre[3],e->pre[4],e->pre[5],
            e->post[0],e->post[1],e->post[2],e->post[3],e->post[4],e->post[5],e->before[0],e->before[1],e->before[2],e->after[0],e->after[1],e->after[2],e->held,e->zeroed);}
}
static void physicsInstall(HMODULE module){
    if(physicsAttempted)return;physicsAttempted=true;
    unsigned char code[SR_PHYSICS_SIZE];char hash[65];uintptr_t target=(uintptr_t)module+SR_PHYSICS_RVA;
    if(!worldRead(target,code,sizeof(code))||!hashBytes(code,sizeof(code),hash)||strcmp(hash,SR_PHYSICS_SHA)){logLine("SR1_PHYSICS full-code gate failed");return;}
    MH_STATUS init=MH_Initialize();if(init!=MH_OK&&init!=MH_ERROR_ALREADY_INITIALIZED)return;
    MH_STATUS create=MH_CreateHook((PVOID)target,(PVOID)&observePhysics,(PVOID *)&originalPhysics);
    MH_STATUS enable=create==MH_OK?MH_EnableHook((PVOID)target):create;
    if(enable==MH_OK)physicsTarget=(PVOID)target;
    logLine("SR1_PHYSICS read-only observer create=%d enable=%d full-code verified=1",create,enable);
}
static void physicsTick(void){
#ifdef SR1_LIFT_FOLLOW
    srLiftTick();
#endif
#ifdef SR1_AIR_PHYSICS_CLOCK
    srAirClockTick();
#endif
    bool air=GetFileAttributesW(PROBE_PATH(L"\\air-attack-sr1.enable"))!=INVALID_FILE_ATTRIBUTES&&
        GetFileAttributesW(PROBE_PATH(L"\\jump-y-sr1.enable"))!=INVALID_FILE_ATTRIBUTES&&
        GetFileAttributesW(PROBE_PATH(L"\\world-sr1.enable"))!=INVALID_FILE_ATTRIBUTES&&
        GetFileAttributesW(PROBE_PATH(L"\\replace-sr1.enable"))!=INVALID_FILE_ATTRIBUTES;
    if(air!=airHoldRequested){airHoldRequested=air;airHoldBegin=air?GetTickCount64():0;InterlockedExchange(&airHoldEnabled,air&&!airHoldFailed);
        logLine("SR1_AIR_HOLD enabled=%d frames=%u; donor hint required, bounded75s/session 2s/continuous support",air,airHoldFrames);}
    bool requested=GetFileAttributesW(PROBE_PATH(L"\\physics-sr1.enable"))!=INVALID_FILE_ATTRIBUTES;
    if(!requested)InterlockedExchange(&physicsEnabled,0);
    else if(!InterlockedCompareExchange(&physicsEnabled,0,0)&&!InterlockedCompareExchange(&physicsLock,1,0)){
        physicsBegin=0;physicsRecords=0;InterlockedExchange(&physicsEnabled,1);InterlockedExchange(&physicsLock,0);}
    physicsFlush();
}
static void physicsStop(void){
#ifdef SR1_LIFT_VERTICAL_LAUNCH
 srLiftLaunchStop();
#endif
 InterlockedExchange(&airHoldEnabled,0);InterlockedExchange(&physicsEnabled,0);if(physicsTarget)MH_DisableHook(physicsTarget);physicsFlush();}
