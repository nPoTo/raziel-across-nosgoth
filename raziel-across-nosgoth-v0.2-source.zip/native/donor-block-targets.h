// SPDX-License-Identifier: GPL-3.0-or-later
#pragma once
#include "donor-action-state.h"

// Only scalar classifications leave this reader. Pointer equality is a bounded
// snapshot observation, never an ownership/generation or callable-ABI proof.
typedef struct {
 bool valid,engagementPresent,entryPresent,heldPresent,slotsEqual;
 bool entryCallbackKnown,heldCallbackKnown,relationKnown,relationEqual,ownerRelationZero,targetRelationZero;
 uint32_t flagsMask,entryCallbackRva,heldCallbackRva;
 bool entryHandlerKnown,heldHandlerKnown;
 uint32_t entryHandlerRva,heldHandlerRva;
} DonorBlockTargets;
typedef struct {
 uintptr_t actor,state,owner,context,engagement,entry,held,entryCallback,heldCallback;
 uint32_t ownerRelation,targetRelation;
 unsigned char flags;
 bool entryRead,heldRead,ownerRelationRead,targetRelationRead;
 uintptr_t entryUserdata,heldUserdata,entryHandler,heldHandler;
 bool entryHandlerRead,heldHandlerRead;
} DonorBlockTargetSnapshot;
static inline bool donorBlockTargetReadField(void *context,DonorActionStateRead read,uintptr_t address,uintptr_t offset,void *out,SIZE_T size){
 return address&&offset<=UINTPTR_MAX-address&&size<=UINTPTR_MAX-address-offset&&read(context,address+offset,out,size);
}
static inline bool donorBlockTargetSnapshot(void *context,DonorActionStateRead read,uintptr_t base,uintptr_t expectedActor,DonorBlockTargetSnapshot *s){
 const Sheet_donorBlockTargetProbe *p=&sheet_donorBlockTargetProbe_current;
 memset(s,0,sizeof(*s));
 if(!read(context,base+(uintptr_t)p->actorPointerRva,&s->actor,8)||s->actor!=expectedActor||
    !donorBlockTargetReadField(context,read,s->actor,(uintptr_t)p->actorStateOffset,&s->state,8)||!s->state||s->state%8||
    !donorBlockTargetReadField(context,read,s->state,(uintptr_t)p->stateOwnerOffset,&s->owner,8)||s->owner!=s->actor||
    !read(context,base+(uintptr_t)p->contextPointerRva,&s->context,8)||!s->context||s->context%8||
    !donorBlockTargetReadField(context,read,s->context,(uintptr_t)p->engagementPointerOffset,&s->engagement,8)||
    !donorBlockTargetReadField(context,read,s->context,(uintptr_t)p->engagementLowFlagsOffset,&s->flags,1))return false;
 s->flags&=3;
 if(s->engagement){
  if(s->engagement%8||!donorBlockTargetReadField(context,read,s->engagement,(uintptr_t)p->entryTargetOffset,&s->entry,8)||
     !donorBlockTargetReadField(context,read,s->engagement,(uintptr_t)p->heldTargetOffset,&s->held,8))return false;
 }
 if((s->entry&&s->entry%8)||(s->held&&s->held%8))return false;
 if(s->entry)s->entryRead=donorBlockTargetReadField(context,read,s->entry,(uintptr_t)p->targetMessageCallbackOffset,&s->entryCallback,8);
 if(s->entryRead&&s->entryCallback==base+(uintptr_t)p->targetWrapperRva&&
    donorBlockTargetReadField(context,read,s->entry,(uintptr_t)p->targetUserdataOffset,&s->entryUserdata,8)&&s->entryUserdata&&s->entryUserdata%8==0)
  s->entryHandlerRead=donorBlockTargetReadField(context,read,s->entryUserdata,(uintptr_t)p->userdataHandlerOffset,&s->entryHandler,8);
 if(s->held){
  s->heldRead=donorBlockTargetReadField(context,read,s->held,(uintptr_t)p->targetMessageCallbackOffset,&s->heldCallback,8);
  if(s->heldRead&&s->heldCallback==base+(uintptr_t)p->targetWrapperRva&&
     donorBlockTargetReadField(context,read,s->held,(uintptr_t)p->targetUserdataOffset,&s->heldUserdata,8)&&s->heldUserdata&&s->heldUserdata%8==0)
   s->heldHandlerRead=donorBlockTargetReadField(context,read,s->heldUserdata,(uintptr_t)p->userdataHandlerOffset,&s->heldHandler,8);
  s->ownerRelationRead=donorBlockTargetReadField(context,read,s->actor,(uintptr_t)p->ownerRelationOffset,&s->ownerRelation,4);
  s->targetRelationRead=donorBlockTargetReadField(context,read,s->held,(uintptr_t)p->targetRelationOffset,&s->targetRelation,4);
 }
 return true;
}
static inline DonorBlockTargets donorBlockTargetsRead(void *context,DonorActionStateRead read,DonorActionStateCode code,uintptr_t base,uint32_t imageSize,uintptr_t actor){
 DonorBlockTargets out={0};const Sheet_donorBlockTargetProbe *p=&sheet_donorBlockTargetProbe_current;
 if(!read||!code||!base||!actor||actor%8||base>UINTPTR_MAX-imageSize||
    p->contextPointerRva!=0xc67120||p->actorPointerRva!=0xc5aa78||p->actorStateOffset!=0x3f8||p->stateOwnerOffset!=0||
    p->engagementPointerOffset!=0x1c0||p->engagementLowFlagsOffset!=0x1c8||p->entryTargetOffset!=0||p->heldTargetOffset!=0x28||
    p->targetMessageCallbackOffset!=0x3a8||p->ownerRelationOffset!=0x340||p->targetRelationOffset!=0x32c||
    p->pointerBytes!=8||p->relationBytes!=4||p->flagReadBytes!=1||p->stableReads!=2||p->serializePointers||p->serializeRelationValues||
    p->targetWrapperRva!=0xee380||p->targetUserdataOffset!=0x3f8||p->userdataHandlerOffset!=8||
    imageSize<8||(uint32_t)p->contextPointerRva>imageSize-8||(uint32_t)p->actorPointerRva>imageSize-8)return out;
 DonorBlockTargetSnapshot a,b;
 if(!donorBlockTargetSnapshot(context,read,base,actor,&a)||!donorBlockTargetSnapshot(context,read,base,actor,&b)||memcmp(&a,&b,sizeof(a)))return out;
 // Recheck the roots after child reads, including the second snapshot's reads.
 uintptr_t again=0;
 if(!read(context,base+(uintptr_t)p->actorPointerRva,&again,8)||again!=actor||
    !donorBlockTargetReadField(context,read,actor,(uintptr_t)p->actorStateOffset,&again,8)||again!=a.state||
    !read(context,base+(uintptr_t)p->contextPointerRva,&again,8)||again!=a.context||
    !donorBlockTargetReadField(context,read,a.context,(uintptr_t)p->engagementPointerOffset,&again,8)||again!=a.engagement)return out;
 out.valid=true;out.flagsMask=a.flags;out.engagementPresent=a.engagement!=0;out.entryPresent=a.entry!=0;out.heldPresent=a.held!=0;out.slotsEqual=a.entry&&a.held&&a.entry==a.held;
 out.entryCallbackKnown=a.entryRead&&a.entryCallback>=base&&a.entryCallback-base<imageSize&&code(context,a.entryCallback,base);
 out.heldCallbackKnown=a.heldRead&&a.heldCallback>=base&&a.heldCallback-base<imageSize&&code(context,a.heldCallback,base);
 if(out.entryCallbackKnown)out.entryCallbackRva=(uint32_t)(a.entryCallback-base);
 if(out.heldCallbackKnown)out.heldCallbackRva=(uint32_t)(a.heldCallback-base);
 out.entryHandlerKnown=out.entryCallbackKnown&&a.entryHandlerRead&&a.entryHandler>=base&&a.entryHandler-base<imageSize&&code(context,a.entryHandler,base);
 out.heldHandlerKnown=out.heldCallbackKnown&&a.heldHandlerRead&&a.heldHandler>=base&&a.heldHandler-base<imageSize&&code(context,a.heldHandler,base);
 if(out.entryHandlerKnown)out.entryHandlerRva=(uint32_t)(a.entryHandler-base);
 if(out.heldHandlerKnown)out.heldHandlerRva=(uint32_t)(a.heldHandler-base);
 out.relationKnown=a.held&&a.ownerRelationRead&&a.targetRelationRead;
 if(out.relationKnown){out.relationEqual=a.ownerRelation==a.targetRelation;out.ownerRelationZero=!a.ownerRelation;out.targetRelationZero=!a.targetRelation;}
 return out;
}
