// SPDX-License-Identifier: GPL-3.0-or-later
#pragma once
#include "host-block-state-reader.h"
typedef struct {uintptr_t opaqueActor;uint32_t requestedRva,handlers[3],clips[3];} HostTransitionMetadata;
// 0: unrelated state, -1: exact state but invalid. Never read queue payloads.
static inline int hostTransitionRead(void *c,HostBlockRead read,HostBlockCode code,uintptr_t base,uint32_t size,uintptr_t state,uintptr_t requested,HostTransitionMetadata *out){
 if(!read||!code||!out||!base||size<0x2a89318||base>UINTPTR_MAX-size)return -1;
 const Sheet_hostBlockStateProbe *p=&sheet_hostBlockStateProbe_current;const Sheet_hostAnimationIndexProbe *a=&sheet_hostAnimationIndexProbe_current;
 if(p->stateRva!=0x2a88588||p->currentActorRva!=0x2a89310||p->sectionStride!=0x228||p->firstCallbackOffset!=0x10||p->sectionCount!=3||a->actorAnimationIdOffset!=0x374||a->actorAnimationSectionStride!=0x50||a->animationIdBytes!=2||a->sectionCount!=3)return -1;
 if(state!=base+(uintptr_t)p->stateRva)return 0;
 if(requested<base||requested-base>=size||!code(c,requested,base))return -1;
 uintptr_t actor=0,owner=0,again=0,callbacks[3],after[3];uint16_t clips[3],clipAgain[3];
 if(!read(c,base+(uintptr_t)p->currentActorRva,&actor,8)||!actor||actor%8||!read(c,state,&owner,8)||owner!=actor)return -1;
 for(unsigned i=0;i<3;i++)if(!read(c,state+i*(uintptr_t)p->sectionStride+0x10,&callbacks[i],8)||callbacks[i]<base||callbacks[i]-base>=size||!code(c,callbacks[i],base)||!hostBlockField(c,read,actor,0x374+i*0x50,&clips[i],2))return -1;
 for(unsigned i=0;i<3;i++)if(!read(c,state+i*(uintptr_t)p->sectionStride+0x10,&after[i],8)||!hostBlockField(c,read,actor,0x374+i*0x50,&clipAgain[i],2))return -1;
 if(memcmp(callbacks,after,sizeof(callbacks))||memcmp(clips,clipAgain,sizeof(clips))||!read(c,state,&again,8)||again!=actor||!read(c,base+(uintptr_t)p->currentActorRva,&again,8)||again!=actor)return -1;
 memset(out,0,sizeof(*out));out->opaqueActor=actor;out->requestedRva=(uint32_t)(requested-base);for(unsigned i=0;i<3;i++){out->handlers[i]=(uint32_t)(callbacks[i]-base);out->clips[i]=clips[i];}return 1;
}
