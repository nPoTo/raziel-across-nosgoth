// SPDX-License-Identifier: GPL-3.0-or-later
#pragma once
#include "host-rig-reader.h"
#include "sr1-retarget-gate.h"
#include "skeleton-policy-identity.h"
typedef struct {uint32_t magic,version,pid,valid;uint64_t creation,tick,serial;unsigned char policy[32];Sr1RetargetContext context;HostRig rig;} HostDrawReceipt;
typedef struct {volatile LONG sequence;HostDrawReceipt receipt;} HostDrawShared;
static inline void hostDrawName(wchar_t name[96],DWORD pid){_snwprintf(name,96,L"Local\\LOKNativeDrawReceipt-v1-%lu",pid);}
static inline bool hostDrawPolicy(void){const Sheet_nativeDrawReceipt *p=&sheet_nativeDrawReceipt_native_draw;return p->consumerRva==0x40d10&&p->bones==66&&p->maxAgeMs==150&&p->postCallUnchanged&&p->currentContext&&p->resourceIdentity&&!p->gameWrites&&!p->enabled;}
static inline bool hostDrawResourceSame(const HostRig *a,const HostRig *b){
 return a->count==66&&b->count==66&&!a->modelIndex&&!b->modelIndex&&a->actor==b->actor&&a->object==b->object&&a->name==b->name&&a->list==b->list&&a->model==b->model&&a->segments==b->segments&&!memcmp(a->parents,b->parents,66*sizeof(int16_t));
}
static inline bool hostDrawContextSame(const Sr1RetargetContext *a,const Sr1RetargetContext *b){return a->identity&&b->identity&&a->verticalVelocityKnown&&b->verticalVelocityKnown&&a->foreground==b->foreground&&a->crouchHeld==b->crouchHeld&&a->mode==b->mode&&a->flags==b->flags&&a->verticalVelocity==b->verticalVelocity&&!memcmp(a->callbacks,b->callbacks,sizeof(a->callbacks));}
static inline bool hostDrawCurrentContextCompatible(const Sr1RetargetContext *a,const Sr1RetargetContext *b){
 if(hostDrawContextSame(a,b))return true;
#if defined(SR1_DRAW_PHASE_COMPAT) && defined(SR1_NATIVE_JUMP_POSE)
 const Sheet_nativeGroundDrawCompatibility *g=&sheet_nativeGroundDrawCompatibility_idle_move;
 if(!g->enabled&&g->idleRva==0xf2180&&g->moveRva==0xf3280&&g->bothGround&&g->sameModeAndFlags&&g->preserveCaptureTime&&
    sr1RetargetContextAllowed(a)&&sr1RetargetContextAllowed(b)&&a->mode==b->mode&&a->flags==b->flags){
  bool pair=true;for(unsigned i=0;i<3;i++)pair=pair&&(a->callbacks[i]==0xf2180||a->callbacks[i]==0xf3280)&&(b->callbacks[i]==0xf2180||b->callbacks[i]==0xf3280);
  if(pair)return true;
 }
 const Sheet_nativeDrawPhasePolicy *p=&sheet_nativeDrawPhasePolicy_ordinary_jump;
 if(!p->sameCallbacks||!p->sameModeAndFlags||!p->bothOrdinaryJump||p->maxAgeMs!=150||!p->preserveCaptureTime||p->gameWrites||p->enabled)return false;
 return sr1RetargetJumpContextAllowed(a)&&sr1RetargetJumpContextAllowed(b)&&a->mode==b->mode&&a->flags==b->flags&&!memcmp(a->callbacks,b->callbacks,sizeof(a->callbacks));
#else
 return false;
#endif
}
static inline bool hostDrawAccept(const HostDrawReceipt *s,DWORD pid,uint64_t creation,uint64_t now,const HostRig *current,const Sr1RetargetContext *context){
 if(!hostDrawPolicy()||s->magic!=0x31524448||s->version!=1||s->pid!=pid||s->creation!=creation||!s->valid||!s->serial||!s->tick||s->tick>now||now-s->tick>150||memcmp(s->policy,skeletonPolicyHash,32)||!hostDrawResourceSame(&s->rig,current)||!hostDrawCurrentContextCompatible(&s->context,context))return false;
 for(unsigned i=0;i<66;i++)for(unsigned k=0;k<13;k++){float v;memcpy(&v,s->rig.renderBytes[i]+4*k,4);if(!isfinite(v)||fabsf(v)>1000000)return false;}
 return true;
}
static inline bool hostDrawCopy(const HostDrawShared *shared,HostDrawReceipt *out){
 if(!shared||!out)return false;for(unsigned i=0;i<3;i++){LONG n=shared->sequence;if(n&1)continue;MemoryBarrier();memcpy(out,&shared->receipt,sizeof(*out));MemoryBarrier();if(n==shared->sequence)return true;}return false;
}
static inline void hostDrawStore(HostDrawShared *shared,const HostDrawReceipt *s){InterlockedIncrement(&shared->sequence);MemoryBarrier();memcpy(&shared->receipt,s,sizeof(*s));MemoryBarrier();InterlockedIncrement(&shared->sequence);}
