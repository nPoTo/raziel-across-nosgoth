// SPDX-License-Identifier: GPL-3.0-or-later
#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <stdio.h>
#include <stdint.h>
#include <stdbool.h>
static wchar_t lifetimeTestDirectory[32768];
#define PROBE_REPORT_DIR lifetimeTestDirectory
#include "session-lifetime.h"
#define CHECK(x) do{if(!(x)){printf("FAIL lifetime line%d\n",__LINE__);return 1;}}while(0)
static int mode;
static int leaseMode(uint64_t now){(void)now;return mode;}
static bool writeFixture(const wchar_t *path,const unsigned char *data,size_t bytes){FILE *f=_wfopen(path,L"wb");if(!f)return false;bool ok=fwrite(data,1,bytes,f)==bytes;fclose(f);return ok;}
int main(int argc,char **argv){
 if(argc==2&&!strcmp(argv[1],"--idle")){Sleep(10000);return 0;}
 _snwprintf(lifetimeTestDirectory,ARRAYSIZE(lifetimeTestDirectory),L"@RAZIEL_SOURCE_ROOT@\\build\\lease-test-%lu",GetCurrentProcessId());CreateDirectoryW(lifetimeTestDirectory,NULL);
 unsigned char b[56]={0};bridgePut(b,0x31465a52,4);bridgePut(b+4,1,4);for(unsigned n=0;n<3;n++){bridgePut(b+8+n*4,n+1,4);bridgePut(b+24+n*8,n+11,8);}bridgePut(b+48,1000,8);
 CHECK(lifetimeLeaseShape(b,1000)&&lifetimeLeaseShape(b,2500)&&!lifetimeLeaseShape(b,2501)&&!lifetimeLeaseShape(b,999));
 b[20]=1;CHECK(!lifetimeLeaseShape(b,1000));b[20]=0;bridgePut(b+40,0,8);CHECK(!lifetimeLeaseShape(b,1000));bridgePut(b+40,13,8);
 sessionBudgetExtended=leaseMode;mode=-1;CHECK(sessionBudget(1,239999,240000)&&!sessionBudget(1,240001,240000));
 mode=1;CHECK(sessionBudget(1,7200000,240000)&&sessionBudget(1,7200000,300001));CHECK(!sessionBudget(2,1,240000)&&!sessionBudget(0,7200000,240000));
 mode=0;CHECK(!sessionBudget(1,50,240000)&&!sessionBudget(1,7200000,240000));
 lifetimeTick=1000;CHECK(!lifetimeRequested()&&lifetimeBudgetStatus(1000)==-1);lifetimePoll();CHECK(!lifetimeTick);
 lifetimeProcesses[0]=OpenProcess(SYNCHRONIZE,FALSE,GetCurrentProcessId());CHECK(lifetimeProcesses[0]);lifetimeClose();CHECK(!lifetimeProcesses[0]);
 wchar_t flag[32768],file[32768],exe[32768],command[32768];_snwprintf(flag,ARRAYSIZE(flag),L"%ls\\%ls.enable",lifetimeTestDirectory,sheet_sessionLifetime_session.normalFlag);_snwprintf(file,ARRAYSIZE(file),L"%ls\\%ls",lifetimeTestDirectory,sheet_sessionLifetime_session.leaseFile);
 CHECK(GetModuleFileNameW(NULL,exe,ARRAYSIZE(exe)));_snwprintf(command,ARRAYSIZE(command),L"\"%ls\" --idle",exe);PROCESS_INFORMATION child={0};STARTUPINFOW startup={.cb=sizeof(startup)};
 CHECK(CreateProcessW(exe,command,NULL,NULL,FALSE,CREATE_NO_WINDOW,NULL,NULL,&startup,&child));
 uint64_t ownCreation=0,childCreation=0;bool nativePass=bridgeProcessCreation(GetCurrentProcess(),&ownCreation)&&bridgeProcessCreation(child.hProcess,&childCreation);
 bridgePut(b+8,GetCurrentProcessId(),4);bridgePut(b+12,child.dwProcessId,4);bridgePut(b+16,GetCurrentProcessId(),4);bridgePut(b+24,ownCreation,8);bridgePut(b+32,childCreation,8);bridgePut(b+40,ownCreation,8);bridgePut(b+48,GetTickCount64(),8);
 nativePass=nativePass&&writeFixture(flag,b,0)&&writeFixture(file,b,sizeof(b));lifetimePoll();nativePass=nativePass&&lifetimeBudgetStatus(GetTickCount64())==1;
 bridgePut(b+40,ownCreation+1,8);nativePass=nativePass&&writeFixture(file,b,sizeof(b));lifetimePoll();nativePass=nativePass&&!lifetimeTick&&!lifetimeProcesses[0];
 bridgePut(b+40,ownCreation,8);bridgePut(b+48,GetTickCount64(),8);nativePass=nativePass&&writeFixture(file,b,sizeof(b));lifetimePoll();nativePass=nativePass&&lifetimeTick;
 TerminateProcess(child.hProcess,77);WaitForSingleObject(child.hProcess,1000);lifetimePoll();nativePass=nativePass&&!lifetimeTick&&!lifetimeProcesses[0];
 CloseHandle(child.hThread);CloseHandle(child.hProcess);DeleteFileW(flag);DeleteFileW(file);RemoveDirectoryW(lifetimeTestDirectory);lifetimeClose();CHECK(nativePass);
 puts("PASS: normal lease beyond old budgets, stale/future/malformed lease rejection, diagnostics preserved, cancellation and owned handle cleanup");return 0;
}
