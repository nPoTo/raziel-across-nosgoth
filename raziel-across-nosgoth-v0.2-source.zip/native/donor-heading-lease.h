// SPDX-License-Identifier: GPL-3.0-or-later
#pragma once
#include <stdint.h>
#include <string.h>
#include "host-heading-math.h"
typedef bool (*HeadingRead)(void *,float[5]);
typedef bool (*HeadingWrite)(void *,unsigned,float);
typedef struct {float saved[5],last[5],authority;bool acquired,failed;unsigned writes,restored,foreign;} HeadingLease;
static inline bool headingTransaction(void *ctx,HeadingRead read,HeadingWrite write,const float before[5],const float target[5]){
 float current[5];unsigned attempted=0;
 if(!read(ctx,current)||memcmp(before,current,sizeof(current)))return false;
 for(unsigned i=0;i<5;i++){attempted=i+1;if(!write(ctx,i,target[i]))goto rollback;}
 if(read(ctx,current)&&!memcmp(target,current,sizeof(current)))return true;
rollback:
 for(unsigned i=attempted;i>0;i--){unsigned k=i-1;if(read(ctx,current)&&!memcmp(&current[k],&target[k],4))(void)write(ctx,k,before[k]);}
 return false;
}
static inline bool headingApply(HeadingLease *l,void *ctx,HeadingRead read,HeadingWrite write,float desired){
 if(l->failed)return false;
 float before[5],target[5];
 if(!read(ctx,before)||!(l->acquired?headingFollowFrame(before,desired,l->authority,target):headingRebase(before,desired,target))){l->failed=true;return false;}
 if(!l->acquired)memcpy(l->saved,before,sizeof(before));
 if(!headingTransaction(ctx,read,write,before,target)){l->failed=true;return false;}
 l->acquired=true;l->authority=headingWrap(desired);memcpy(l->last,target,sizeof(target));++l->writes;return true;
}
static inline bool headingRelease(HeadingLease *l,void *ctx,HeadingRead read,HeadingWrite write){
 if(!l->acquired)return true;
 float current[5];
 // Never restore a partial coordinate frame over a native update/load.
 if(!read(ctx,current)||memcmp(current,l->last,sizeof(current))){l->foreign++;l->acquired=false;return true;}
 if(!headingTransaction(ctx,read,write,current,l->saved)){l->failed=true;return false;}
 l->restored++;l->acquired=false;return true;
}
