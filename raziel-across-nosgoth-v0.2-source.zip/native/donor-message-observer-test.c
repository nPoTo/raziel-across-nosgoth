// SPDX-License-Identifier: GPL-3.0-or-later
#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <stdint.h>
#include <stdbool.h>
#include <stdio.h>
#include <string.h>
#include "donor-message-observer.h"

typedef struct {uint32_t id,padding;uint64_t payload;} FakeMessage;
typedef struct {
 DonorMessageLease lease;
 bool leaseReadFails,metadataFails,afterFails,changeBefore,changeAfter,changeOriginal,expireOriginal,invalidFirst,invalidMask,enforceLockFree;
 unsigned wantedDepth,nativeDepth;
 volatile LONG originals,failures,beforeReads,afterReads;
 void *expectedState,*expectedMessage;int32_t expectedSection;
 DWORD incomingError,resultError;
 uintptr_t result;
} Fixture;
static Fixture fixture;
static DonorMessageObserver observer;
static DonorMessageObserverThread threadState;
static uint64_t fakeState;
static void fail(void){InterlockedIncrement(&fixture.failures);}
static bool leaseRead(void *context,DonorMessageLease *out){
 Fixture *f=context;*out=f->lease;SetLastError(0xaabbccdd);return !f->leaseReadFails;
}
static bool snapshotRead(void *context,void *state,int32_t section,void *message,bool after,DonorMessageMetadata *out){
 Fixture *f=context;SetLastError(0x55667788);
 if(state!=f->expectedState||section!=f->expectedSection||message!=f->expectedMessage)fail();
 if(after)InterlockedIncrement(&f->afterReads);else InterlockedIncrement(&f->beforeReads);
 if(f->metadataFails||(after&&f->afterFails))return false;
 if(!after){const FakeMessage *m=message;out->messageId=m->id;out->payloadZero=m->payload==0;if(f->changeBefore)f->lease.session++;}
 else if(f->changeAfter)f->lease.session++;
 for(unsigned i=0;i<3;i++){out->firstRva[i]=(after?0x2000:0x1000)+i*0x10;out->secondRva[i]=(after?0x4000:0x3000)+i*0x10;}
 out->secondValidMask=f->invalidMask?8:5;
 if(f->invalidFirst)out->firstRva[1]=0;
 return true;
}
static uintptr_t __fastcall nativeOriginal(void *state,int32_t section,void *message){
 Fixture *f=&fixture;InterlockedIncrement(&f->originals);
 if(state!=f->expectedState||section!=f->expectedSection||message!=f->expectedMessage||GetLastError()!=f->incomingError)fail();
 if(f->enforceLockFree){if(!TryAcquireSRWLockExclusive(&observer.queueLock))fail();else ReleaseSRWLockExclusive(&observer.queueLock);}
 if(f->wantedDepth>1){
  f->nativeDepth++;
  if(f->nativeDepth<f->wantedDepth){
   FakeMessage child={0x20010000+f->nativeDepth,0,UINT64_C(0xa1b2c3d4e5f60718)};
   void *priorMessage=f->expectedMessage;int32_t priorSection=f->expectedSection;
   f->expectedMessage=&child;f->expectedSection=(int32_t)(f->nativeDepth%3);SetLastError(f->incomingError);
   uintptr_t result=donorMessageObserverForward(&observer,&threadState,nativeOriginal,state,f->expectedSection,&child);
   if(result!=f->result||GetLastError()!=f->resultError)fail();
   f->expectedMessage=priorMessage;f->expectedSection=priorSection;
  }
  f->nativeDepth--;
 }
 if(f->changeOriginal)f->lease.session++;
 if(f->expireOriginal)f->lease.nowTick+=1501;
 SetLastError(f->resultError);return f->result;
}
static void setup(FakeMessage *message){
 memset(&fixture,0,sizeof(fixture));memset(&threadState,0,sizeof(threadState));
 fixture.lease=(DonorMessageLease){true,17,1000,1000,1000};fixture.wantedDepth=1;fixture.enforceLockFree=true;
 fixture.expectedState=&fakeState;fixture.expectedMessage=message;fixture.expectedSection=2;fixture.incomingError=0x12345678;fixture.resultError=0xfedcba98;fixture.result=UINT64_C(0xfedcba9876543210);
 donorMessageObserverInit(&observer,&fixture,leaseRead,snapshotRead);
}
static bool invoke(DonorMessageObserver *o,DonorMessageObserverThread *t){
 SetLastError(fixture.incomingError);uintptr_t r=donorMessageObserverForward(o,t,nativeOriginal,fixture.expectedState,fixture.expectedSection,fixture.expectedMessage);
 return r==fixture.result&&GetLastError()==fixture.resultError&&fixture.failures==0;
}
static unsigned drain(DonorMessageEvent *events,unsigned capacity){unsigned n=0;DonorMessageEvent e;while(donorMessageObserverPop(&observer,&e)){if(n<capacity)events[n]=e;n++;}return n;}
#define CHECK(c) do{if(!(c)){printf("FAIL message observer line%u\n",(unsigned)__LINE__);return 1;}}while(0)
static DWORD WINAPI parallelCalls(void *context){
 DonorMessageObserverThread local={0};unsigned n=(unsigned)(uintptr_t)context;
 for(unsigned i=0;i<n;i++)if(!invoke(&observer,&local))return 1;return local.depth==0?0:2;
}
static DWORD WINAPI foreignThreadStorage(void *unused){(void)unused;return invoke(&observer,&threadState)?0:1;}

int main(void){
 FakeMessage message={0x100001,0,UINT64_C(0x8877665544332211)};DonorMessageEvent events[DONOR_MESSAGE_OBSERVER_CAPACITY];DonorMessageObserverStats stats;
 setup(&message);CHECK(observer.configured&&invoke(&observer,&threadState));CHECK(fixture.originals==1&&fixture.beforeReads==1&&fixture.afterReads==1&&threadState.depth==0);CHECK(drain(events,512)==2);
 CHECK(events[0].phase==DONOR_MESSAGE_ENTER&&events[1].phase==DONOR_MESSAGE_EXIT&&events[0].callId==events[1].callId&&events[0].callId==1&&events[0].depth==1&&events[1].depth==1&&events[0].session==17&&events[1].session==17&&events[0].threadId==GetCurrentThreadId());
 CHECK(!events[0].afterValid&&events[1].afterValid&&events[0].messageId==message.id&&events[1].messageId==message.id&&events[0].payloadZero==0&&events[1].payloadZero==0&&events[0].section==2&&events[1].section==2);
 for(unsigned i=0;i<3;i++){CHECK(events[1].beforeFirstRva[i]==0x1000+i*0x10&&events[1].afterFirstRva[i]==0x2000+i*0x10);CHECK(events[0].afterFirstRva[i]==0);CHECK(events[1].beforeSecondRva[i]==(i==1?0:0x3000+i*0x10));}
 for(unsigned n=0;n<2;n++)for(size_t i=0;i+8<=sizeof(events[n]);i++){uint64_t v;memcpy(&v,(unsigned char *)&events[n]+i,8);CHECK(v!=message.payload&&v!=fixture.result);}
 message.payload=0;setup(&message);CHECK(invoke(&observer,&threadState)&&drain(events,512)==2&&events[0].payloadZero==1&&events[1].payloadZero==1);

 setup(&message);CHECK(invoke(NULL,NULL)&&fixture.originals==1);CHECK(invoke(&observer,NULL)&&fixture.originals==2&&drain(events,512)==0);
 setup(&message);observer.configured=false;CHECK(invoke(&observer,&threadState)&&fixture.originals==1&&drain(events,512)==0);
 setup(&message);fixture.lease.enabled=false;CHECK(invoke(&observer,&threadState)&&fixture.originals==1&&fixture.beforeReads==0&&drain(events,512)==0);
 setup(&message);fixture.leaseReadFails=true;CHECK(invoke(&observer,&threadState)&&fixture.originals==1&&drain(events,512)==0);
 setup(&message);fixture.lease.nowTick=2501;CHECK(invoke(&observer,&threadState)&&fixture.originals==1&&drain(events,512)==0);CHECK(donorMessageObserverStatsRead(&observer).leaseDrops==1);
 setup(&message);fixture.lease.nowTick=2499;CHECK(invoke(&observer,&threadState)&&drain(events,512)==2&&events[0].tickMs==2499&&events[1].tickMs==2499);
 setup(&message);fixture.lease.nowTick=2500;CHECK(invoke(&observer,&threadState)&&drain(events,512)==0);
 setup(&message);fixture.lease.nowTick=999;CHECK(invoke(&observer,&threadState)&&drain(events,512)==0);
 setup(&message);fixture.lease.heartbeatTick=999;CHECK(invoke(&observer,&threadState)&&drain(events,512)==0);
 setup(&message);fixture.lease.nowTick=61000;fixture.lease.heartbeatTick=61000;CHECK(invoke(&observer,&threadState)&&drain(events,512)==0);
 setup(&message);fixture.lease.heartbeatTick=1001;CHECK(invoke(&observer,&threadState)&&drain(events,512)==0);
 setup(&message);fixture.lease.session=0;CHECK(invoke(&observer,&threadState)&&drain(events,512)==0);
 setup(&message);fixture.metadataFails=true;CHECK(invoke(&observer,&threadState)&&fixture.originals==1&&drain(events,512)==0);CHECK(donorMessageObserverStatsRead(&observer).metadataDrops==1);
 setup(&message);fixture.invalidFirst=true;CHECK(invoke(&observer,&threadState)&&drain(events,512)==0);
 setup(&message);fixture.invalidMask=true;CHECK(invoke(&observer,&threadState)&&drain(events,512)==0);
 setup(&message);fixture.expectedState=NULL;CHECK(invoke(&observer,&threadState)&&fixture.originals==1&&fixture.beforeReads==0&&drain(events,512)==0);
 setup(&message);fixture.expectedMessage=NULL;CHECK(invoke(&observer,&threadState)&&fixture.originals==1&&fixture.beforeReads==0&&drain(events,512)==0);
 setup(&message);fixture.expectedSection=-1;CHECK(invoke(&observer,&threadState)&&fixture.originals==1&&fixture.beforeReads==0&&drain(events,512)==0);
 setup(&message);fixture.expectedSection=3;CHECK(invoke(&observer,&threadState)&&fixture.originals==1&&fixture.beforeReads==0&&drain(events,512)==0);
 for(unsigned i=0;i<3;i++){setup(&message);message.id=i==0?0x100000:i==1?0x100017:0x100018;CHECK(invoke(&observer,&threadState)&&fixture.originals==1&&fixture.afterReads==0&&drain(events,512)==0);}message.id=0x100001;

 setup(&message);fixture.afterFails=true;CHECK(invoke(&observer,&threadState)&&fixture.originals==1&&drain(events,512)==1&&events[0].phase==DONOR_MESSAGE_ENTER&&!events[0].afterValid);CHECK(donorMessageObserverStatsRead(&observer).metadataDrops==1);
 setup(&message);fixture.changeBefore=true;CHECK(invoke(&observer,&threadState)&&fixture.originals==1&&drain(events,512)==0);CHECK(donorMessageObserverStatsRead(&observer).leaseDrops==1);
 setup(&message);fixture.changeOriginal=true;CHECK(invoke(&observer,&threadState)&&fixture.originals==1&&fixture.afterReads==0&&drain(events,512)==1);CHECK(donorMessageObserverStatsRead(&observer).leaseDrops==1);
 setup(&message);fixture.expireOriginal=true;CHECK(invoke(&observer,&threadState)&&fixture.originals==1&&fixture.afterReads==0&&drain(events,512)==1);
 setup(&message);fixture.changeAfter=true;CHECK(invoke(&observer,&threadState)&&fixture.originals==1&&drain(events,512)==1);CHECK(donorMessageObserverStatsRead(&observer).leaseDrops==1);

 setup(&message);fixture.wantedDepth=3;CHECK(invoke(&observer,&threadState)&&fixture.originals==3&&threadState.depth==0&&drain(events,512)==6);
 for(unsigned i=0;i<3;i++){CHECK(events[i].phase==DONOR_MESSAGE_ENTER&&events[i].depth==i+1&&events[i].callId==i+1);CHECK(events[5-i].phase==DONOR_MESSAGE_EXIT&&events[5-i].depth==i+1&&events[5-i].callId==i+1&&events[5-i].afterValid);}
 setup(&message);fixture.wantedDepth=34;CHECK(invoke(&observer,&threadState)&&fixture.originals==34&&threadState.depth==0&&drain(events,512)==64);CHECK(donorMessageObserverStatsRead(&observer).depthDrops==2);
 for(unsigned i=0;i<32;i++){CHECK(events[i].depth==i+1&&events[63-i].depth==i+1&&events[i].callId==events[63-i].callId);}

 setup(&message);for(unsigned i=0;i<256;i++)CHECK(invoke(&observer,&threadState));CHECK(invoke(&observer,&threadState)&&fixture.originals==257);stats=donorMessageObserverStatsRead(&observer);CHECK(stats.published==512&&stats.queueFullDrops==1&&drain(events,512)==512);
 setup(&message);fixture.enforceLockFree=false;AcquireSRWLockExclusive(&observer.queueLock);bool contentionPassed=true;for(unsigned i=0;i<64;i++)if(!invoke(&observer,&threadState))contentionPassed=false;ReleaseSRWLockExclusive(&observer.queueLock);CHECK(contentionPassed&&fixture.originals==64&&drain(events,512)==0);CHECK(donorMessageObserverStatsRead(&observer).contentionDrops==64);
 setup(&message);for(unsigned i=0;i<60000;i++){CHECK(invoke(&observer,&threadState));CHECK(drain(events,512)==2);}CHECK(invoke(&observer,&threadState)&&fixture.originals==60001&&drain(events,512)==0);stats=donorMessageObserverStatsRead(&observer);CHECK(stats.published==120000&&stats.budgetDrops==1);

 setup(&message);CHECK(invoke(&observer,&threadState)&&drain(events,512)==2);HANDLE foreign=CreateThread(NULL,0,foreignThreadStorage,NULL,0,NULL);CHECK(foreign&&WaitForSingleObject(foreign,5000)==WAIT_OBJECT_0);DWORD code=9;CHECK(GetExitCodeThread(foreign,&code)&&code==0);CloseHandle(foreign);CHECK(fixture.originals==2&&threadState.depth==0&&drain(events,512)==0);
 setup(&message);fixture.enforceLockFree=false;HANDLE workers[4];for(unsigned i=0;i<4;i++){workers[i]=CreateThread(NULL,0,parallelCalls,(void *)(uintptr_t)100,0,NULL);CHECK(workers[i]);}
 CHECK(WaitForMultipleObjects(4,workers,TRUE,10000)==WAIT_OBJECT_0);for(unsigned i=0;i<4;i++){code=9;CHECK(GetExitCodeThread(workers[i],&code)&&code==0);CloseHandle(workers[i]);}
 stats=donorMessageObserverStatsRead(&observer);CHECK(fixture.originals==400&&stats.forwarded==400&&stats.published<=512&&drain(events,512)==stats.published&&fixture.failures==0);
 for(unsigned i=0;i<(unsigned)stats.published;i++){
  CHECK(events[i].threadId&&events[i].depth==1&&events[i].callId);
  if(events[i].phase==DONOR_MESSAGE_EXIT){bool paired=false;CHECK(events[i].afterValid);for(unsigned j=0;j<i;j++)if(events[j].phase==DONOR_MESSAGE_ENTER&&events[j].callId==events[i].callId){paired=true;CHECK(events[j].threadId==events[i].threadId&&events[j].depth==events[i].depth&&events[j].session==events[i].session&&events[j].messageId==events[i].messageId);}CHECK(paired);}
  for(unsigned j=0;j<i;j++)if(events[i].phase==events[j].phase)CHECK(events[i].callId!=events[j].callId);
 }
 puts("PASS: actual forwarding core preserves exact arguments/64-bit return/LastError, nested pairing/depth, rejected and absent metadata, tick forwarding, lease/session expiry, bounded queue/budget/nonblocking contention, foreign thread rejection and four-thread producers; event rows contain scalars only");return 0;
}
