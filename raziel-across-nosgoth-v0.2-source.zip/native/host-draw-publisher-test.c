// SPDX-License-Identifier: GPL-3.0-or-later
#define main readerFixtureMain
#include "host-rig-reader-test.c"
#undef main
#include <assert.h>
static bool worldRead(uintptr_t at,void *out,SIZE_T n){
 uint64_t owner=0x50000,cb=0x100000+0xf2180;uint16_t mode=0;uint32_t flags=64;
 if(at==0x100000+0x2a88588&&n==8){memcpy(out,&owner,8);return true;}
 for(unsigned i=0;i<3;i++)if(at==0x100000+0x2a88598+i*0x228&&n==8){memcpy(out,&cb,8);return true;}
 if(at==0x100000+0x2a89536&&n==2){memcpy(out,&mode,2);return true;}
 if(at==0x100000+0x2a8950c&&n==4){memcpy(out,&flags,4);return true;}
 return readFixture(NULL,at,out,n);
}
static bool sr1SkeletonRead(void *unused,uintptr_t at,void *out,SIZE_T n){(void)unused;return worldRead(at,out,n);}
#include "host-draw-publisher.h"
int main(void){
 setup();i32(5,0x30,66);for(int i=0;i<66;i++)i16(6,i*32+18,i-1);
 HostRig r;Sr1RetargetContext c;assert(hostRigRead(NULL,sr1SkeletonRead,0x100000,&r));assert(hostDrawContext(0x100000,r.actor,&c));
 hostDrawInitialize();assert(hostDrawView);wchar_t name[96];hostDrawName(name,GetCurrentProcessId());HANDLE reader=OpenFileMappingW(FILE_MAP_READ,FALSE,name);assert(reader);const HostDrawShared *view=MapViewOfFile(reader,FILE_MAP_READ,0,0,sizeof(HostDrawShared));assert(view);
 uint64_t now=GetTickCount64();HostDrawReceipt s;
 hostDrawPublish(&r,&c,0x100000,r.render,now);assert(hostDrawCopy(view,&s)&&s.valid&&s.tick==now&&hostDrawAccept(&s,GetCurrentProcessId(),hostDrawCreation,now,&r,&c));
 // A separate adapted buffer must never be accepted as the native input.
 hostDrawPublish(&r,&c,0x100000,r.render+52,now);assert(hostDrawCopy(view,&s)&&!s.valid);
 blocks[8].data[40]^=1;hostDrawPublish(&r,&c,0x100000,r.render,now);assert(hostDrawCopy(view,&s)&&!s.valid);blocks[8].data[40]^=1;
 c.callbacks[1]++;hostDrawPublish(&r,&c,0x100000,r.render,now);assert(hostDrawCopy(view,&s)&&!s.valid);c.callbacks[1]--;
 hostDrawPublish(&r,&c,0x100000,r.render,now);assert(hostDrawCopy(view,&s)&&s.valid);hostDrawClear();assert(hostDrawCopy(view,&s)&&!s.valid);
 UnmapViewOfFile(view);CloseHandle(reader);UnmapViewOfFile(hostDrawView);CloseHandle(hostDrawMapping);
 puts("actual publisher/pagefile read-only view: original input, changed input/context refusal, clear PASS; fixture memory, not gameplay");return 0;
}
