// SPDX-License-Identifier: GPL-3.0-or-later
#define SR1_NATIVE_JUMP_POSE 1
#include <assert.h>
#include <stdio.h>
#include "sr1-retarget-gate.h"
#include "sr1-skeleton-shared.h"
int main(int argc,char **argv){
 Sr1RetargetContext c={.identity=true,.foreground=true,.verticalVelocityKnown=true,.verticalVelocity=138,.callbacks={0xf2ae0,0xf2ae0,0xf2ae0}};
 assert(sr1RetargetJumpContextAllowed(&c)&&!sr1RetargetContextAllowed(&c));c.verticalVelocity=0;assert(sr1RetargetJumpContextAllowed(&c));c.verticalVelocity=-6;assert(sr1RetargetJumpContextAllowed(&c));
 for(unsigned i=0;i<3;i++){uint32_t saved=c.callbacks[i];for(unsigned j=0;j<5;j++){const uint32_t native[]={0xefb50,0xef480,0xf5340,0xf4490,0xf2180};c.callbacks[i]=native[j];assert(!sr1RetargetJumpContextAllowed(&c));}c.callbacks[i]=saved;}
 c.foreground=false;assert(!sr1RetargetJumpContextAllowed(&c));c.foreground=true;c.mode=1;assert(!sr1RetargetJumpContextAllowed(&c));c.mode=0;c.verticalVelocity=2049;assert(!sr1RetargetJumpContextAllowed(&c));c.verticalVelocity=0;c.flags=0x10000000;assert(!sr1RetargetJumpContextAllowed(&c));
 if(argc==2){FILE *f=fopen(argv[1],"rb");SkeletonSnapshot s;assert(f&&fread(&s,1,sizeof(s),f)==sizeof(s)&&fgetc(f)==EOF);fclose(f);assert(s.mode==3&&skeletonPacketValid(&s,12,1101));s.bones[0][10]=1;assert(!skeletonPacketValid(&s,12,1101));s.bones[0][10]=0;s.mode=4;assert(!skeletonPacketValid(&s,12,1101));}
 puts("PASS exact Jump/apex versus native glide/fall/crouch/mixed/menu/air-outlier refusal; mode3 rigid root/packet. Fixtures, not gameplay.");return 0;
}
