// SPDX-License-Identifier: GPL-3.0-or-later
#pragma once
#include <windows.h>
#include <stdbool.h>
#include <stdint.h>
#include <string.h>
#include <math.h>
#include "exploration-sheets.h"
typedef bool (*ReaverRead)(void *,uintptr_t,void *,SIZE_T);
typedef struct {
 uintptr_t actor,actorObject,context,weapon,object,name,state;
 uint32_t flags,partMask,skin,configuredHand;uintptr_t actorConfig,attachedParent;int16_t attachedBone;
 unsigned char enabled,b4,b5,type,drawState,coilState;float f24,f28,fadeCurrent,fadeTarget;
} ReaverSnapshot;
typedef struct {bool valid,present,nameMatches;unsigned reason;ReaverSnapshot snapshot;} ReaverObservation;
static inline bool reaverField(void *c,ReaverRead r,uintptr_t a,uintptr_t o,void *out,SIZE_T n){return a&&o<=UINTPTR_MAX-a&&n<=UINTPTR_MAX-a-o&&r(c,a+o,out,n);}
static inline bool reaverSnapshot(void *c,ReaverRead r,uintptr_t base,uintptr_t knownModel,ReaverSnapshot *s){
 const Sheet_reaverObservationPolicy *p=&sheet_reaverObservationPolicy_candidate;memset(s,0,sizeof(*s));
 if(!reaverField(c,r,base,p->actorRva,&s->actor,8)||!s->actor||s->actor%8||!reaverField(c,r,s->actor,p->objectOffset,&s->actorObject,8)||s->actorObject!=knownModel||
 !reaverField(c,r,base,p->contextRva,&s->context,8)||!s->context||s->context%8||!reaverField(c,r,s->context,p->weaponSlot,&s->weapon,8)||
 !reaverField(c,r,s->context,p->enabledOffset,&s->enabled,1)||!reaverField(c,r,base,p->skinRva,&s->skin,4))return false;
 if(!s->weapon)return true;
 if(s->weapon%8||!reaverField(c,r,s->weapon,p->objectOffset,&s->object,8)||!s->object||s->object%8||!reaverField(c,r,s->object,p->objectNameOffset,&s->name,8)||
 !reaverField(c,r,s->weapon,p->stateOffset,&s->state,8)||!s->state||s->state%8||!reaverField(c,r,s->weapon,p->instanceFlagsOffset,&s->flags,4)||!reaverField(c,r,s->weapon,p->partMaskOffset,&s->partMask,4))return false;
 return reaverField(c,r,s->state,4,&s->b4,1)&&reaverField(c,r,s->state,5,&s->b5,1)&&reaverField(c,r,s->state,8,&s->type,1)&&reaverField(c,r,s->state,0x24,&s->f24,4)&&reaverField(c,r,s->state,0x28,&s->f28,4)&&isfinite(s->f24)&&isfinite(s->f28)&&
 reaverField(c,r,s->state,p->drawStateOffset,&s->drawState,1)&&reaverField(c,r,s->state,p->coilStateOffset,&s->coilState,1)&&
 reaverField(c,r,s->weapon,p->fadeCurrentOffset,&s->fadeCurrent,4)&&reaverField(c,r,s->weapon,p->fadeTargetOffset,&s->fadeTarget,4)&&isfinite(s->fadeCurrent)&&isfinite(s->fadeTarget)&&
 reaverField(c,r,s->actor,p->actorConfigOffset,&s->actorConfig,8)&&s->actorConfig&&reaverField(c,r,s->actorConfig,p->configuredHandOffset,&s->configuredHand,4)&&
 reaverField(c,r,s->weapon,p->attachedParentOffset,&s->attachedParent,8)&&reaverField(c,r,s->weapon,p->attachedBoneOffset,&s->attachedBone,2);
}
static inline ReaverObservation reaverObserve(void *c,ReaverRead read,uintptr_t base,uint32_t size,uintptr_t knownModel){
 ReaverObservation out={0};out.reason=1;const Sheet_reaverObservationPolicy *p=&sheet_reaverObservationPolicy_candidate;
 if(!read||!base||!knownModel||base>UINTPTR_MAX-size||size<0xc67128||p->gameWrites)return out;
 ReaverSnapshot a,b;char name[8]={0},again[8]={0};
 out.reason=2;if(!reaverSnapshot(c,read,base,knownModel,&a))return out;
 out.reason=3;if(a.weapon&&(!reaverField(c,read,a.name,0,name,8)||memcmp(name,"sreaver",8)))return out;
 out.reason=4;if(!reaverSnapshot(c,read,base,knownModel,&b)||memcmp(&a,&b,sizeof(a)))return out;
 out.reason=5;if(b.weapon&&(!reaverField(c,read,b.name,0,again,8)||memcmp(name,again,8)))return out;
 uintptr_t actor=0,context=0,weapon=0;
 out.reason=6;if(!reaverField(c,read,base,p->actorRva,&actor,8)||actor!=a.actor||!reaverField(c,read,base,p->contextRva,&context,8)||context!=a.context||!reaverField(c,read,context,p->weaponSlot,&weapon,8)||weapon!=a.weapon)return out;
 out.reason=0;out.valid=true;out.present=a.weapon!=0;out.nameMatches=out.present;out.snapshot=a;return out;
}
