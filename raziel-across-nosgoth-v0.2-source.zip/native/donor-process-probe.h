#include "report-path.h"
// Read-only observation before any future donor locomotion isolation.
#include "donor-process-proof.h"
typedef uintptr_t (__fastcall *DonorProcessFn)(uintptr_t,uintptr_t);
static DonorProcessFn originalDonorProcess;static PVOID donorProcessTarget;
static uintptr_t donorProcessBase;static PVOID volatile donorRazielObject;
static volatile LONG donorProcessEnabled,donorProcessLock;
static ULONGLONG donorProcessBegin;static unsigned donorProcessHead,donorProcessTail,donorProcessRecords;
typedef struct {ULONGLONG tick;uintptr_t instance,tracker,state,owner,result;float before[3],after[3],factor,root[16];bool motionValid;} DonorProcessEvent;
static DonorProcessEvent donorProcessQueue[256];
// Same-thread metadata for the enclosing, already proved frame hook. Native
// animation translation runs before the Raziel callback, so callback delta
// alone does not measure a roll. No game fields are written by this context.
static struct {uintptr_t instance;DWORD thread;unsigned callbacks;float factor,root[16];bool wanted,valid;} donorFrameMotion;
static bool donorProcessMotion(uintptr_t instance,float *factor,float root[16],uintptr_t *buffer){
 if(!worldRead(donorProcessBase+0xc5abbc,factor,4)||!isfinite(*factor)||*factor<.01f||*factor>2||
    !worldRead(instance+0x70,buffer,8)||!*buffer||!worldRead(*buffer,root,64))return false;
 for(unsigned k=0;k<16;k++)if(!isfinite(root[k]))return false;
 if(fabsf(root[3])>1e-5f||fabsf(root[7])>1e-5f||fabsf(root[11])>1e-5f||fabsf(root[15]-1)>1e-5f)return false;
 for(unsigned c=0;c<3;c++){
  float norm=0;for(unsigned r=0;r<3;r++)norm+=root[c*4+r]*root[c*4+r];
  if(fabsf(norm-1)>.03f)return false;
  for(unsigned d=0;d<c;d++){float dot=0;for(unsigned r=0;r<3;r++)dot+=root[c*4+r]*root[d*4+r];if(fabsf(dot)>.03f)return false;}
 }
 float det=root[0]*(root[5]*root[10]-root[6]*root[9])-root[4]*(root[1]*root[10]-root[2]*root[9])+root[8]*(root[1]*root[6]-root[2]*root[5]);
 return fabsf(det-1)<.03f;
}
static bool donorProcessIdentity(uintptr_t instance){
 uintptr_t player=0,object=0;return donorProcessBase&&worldRead(donorProcessBase+0xc5aa78,&player,8)&&player==instance&&
  worldRead(instance+0x88,&object,8)&&object==(uintptr_t)InterlockedCompareExchangePointer(&donorRazielObject,NULL,NULL)&&object;
}
static uintptr_t __fastcall observeDonorProcess(uintptr_t instance,uintptr_t tracker){
 DonorProcessEvent e={0};uintptr_t rootBuffer=0;bool recording=InterlockedCompareExchange(&donorProcessEnabled,0,0)&&tracker==donorProcessBase+0xc5aa50&&donorProcessIdentity(instance);
 if(recording){e.tick=GetTickCount64();e.instance=instance;e.tracker=tracker;
  recording=worldRead(instance+0x20,e.before,12)&&worldRead(tracker+0x28,&e.state,8)&&e.state==instance&&worldRead(e.state,&e.owner,8);
  if(recording)e.motionValid=donorProcessMotion(instance,&e.factor,e.root,&rootBuffer);}
 uintptr_t result=originalDonorProcess(instance,tracker);e.result=result;
 if(!recording||!donorProcessIdentity(instance)||!worldRead(instance+0x20,e.after,12))return result;
 for(unsigned i=0;i<3;i++)if(!isfinite(e.before[i])||!isfinite(e.after[i]))return result;
 if(e.motionValid){float afterFactor=0;uintptr_t afterBuffer=0;
  e.motionValid=worldRead(donorProcessBase+0xc5abbc,&afterFactor,4)&&afterFactor==e.factor&&
   worldRead(instance+0x70,&afterBuffer,8)&&afterBuffer==rootBuffer;
  for(unsigned k=0;k<3;k++)if(fabsf(e.after[k]-e.before[k])>256)e.motionValid=false;
 }
 if(donorFrameMotion.wanted&&donorFrameMotion.thread==GetCurrentThreadId()&&donorFrameMotion.instance==instance){
  ++donorFrameMotion.callbacks;donorFrameMotion.valid=e.motionValid;
  if(e.motionValid){donorFrameMotion.factor=e.factor;memcpy(donorFrameMotion.root,e.root,sizeof(e.root));}
 }
 if(!InterlockedCompareExchange(&donorProcessLock,1,0)){
  if(!donorProcessBegin)donorProcessBegin=e.tick;unsigned next=(donorProcessHead+1)%ARRAYSIZE(donorProcessQueue);
  if(e.tick>=donorProcessBegin&&e.tick-donorProcessBegin<90000&&donorProcessRecords<12000&&next!=donorProcessTail){donorProcessQueue[donorProcessHead]=e;donorProcessHead=next;++donorProcessRecords;}
  InterlockedExchange(&donorProcessLock,0);
 }
 return result;
}
static void donorProcessFlush(void){
 DonorProcessEvent local[256];unsigned count=0;if(InterlockedCompareExchange(&donorProcessLock,1,0))return;
 while(donorProcessTail!=donorProcessHead){local[count++]=donorProcessQueue[donorProcessTail];donorProcessTail=(donorProcessTail+1)%ARRAYSIZE(donorProcessQueue);}InterlockedExchange(&donorProcessLock,0);
 for(unsigned i=0;i<count;i++){DonorProcessEvent *e=&local[i];logLine("DONOR_PROCESS tick=%llu instance=%p tracker=%p tracker_player=%p prefix_word=%p before=%.9g,%.9g,%.9g after=%.9g,%.9g,%.9g result=%p; read-only",
  e->tick,(void *)e->instance,(void *)e->tracker,(void *)e->state,(void *)e->owner,e->before[0],e->before[1],e->before[2],e->after[0],e->after[1],e->after[2],(void *)e->result);
  logLine("DONOR_PROCESS_STEP tick=%llu instance=%p valid=%u factor=%.9g delta=%.9g,%.9g,%.9g rotation=%.9g,%.9g,%.9g,%.9g,%.9g,%.9g,%.9g,%.9g,%.9g; read-only callback displacement, includes native collision/physics",
   e->tick,(void *)e->instance,e->motionValid,e->motionValid?e->factor:0,e->after[0]-e->before[0],e->after[1]-e->before[1],e->after[2]-e->before[2],
   e->root[0],e->root[1],e->root[2],e->root[4],e->root[5],e->root[6],e->root[8],e->root[9],e->root[10]);}
}
static void donorProcessFindModel(void){
 uintptr_t player=0,currentObject=0;
 if(!worldRead(donorProcessBase+0xc5aa78,&player,8)||!worldRead(player+0x88,&currentObject,8)){InterlockedExchangePointer(&donorRazielObject,NULL);return;}
 for(unsigned i=0;i<512;i++){uintptr_t context=donorProcessBase+0xc88020+i*64,name=0,object=0;char text[7];
  if(worldRead(context,&name,8)&&worldRead(name,text,7)&&!memcmp(text,"raziel",7)&&worldRead(context+8,&object,8)&&object==currentObject&&object){InterlockedExchangePointer(&donorRazielObject,(PVOID)object);return;}}
 InterlockedExchangePointer(&donorRazielObject,NULL);
}
static void donorProcessInstall(HMODULE module){
 if(!module)return;donorProcessBase=(uintptr_t)module;unsigned char code[DONOR_PROCESS_SIZE];char hash[65];PVOID target=(PVOID)(donorProcessBase+DONOR_PROCESS_RVA);
 if(!worldRead((uintptr_t)target,code,sizeof(code))||!hashBytes(code,sizeof(code),hash)||strcmp(hash,DONOR_PROCESS_SHA)){logLine("DONOR_PROCESS code proof failed");return;}
 MH_STATUS init=MH_Initialize();if(init!=MH_OK&&init!=MH_ERROR_ALREADY_INITIALIZED)return;
 MH_STATUS create=MH_CreateHook(target,(PVOID)&observeDonorProcess,(PVOID *)&originalDonorProcess),enable=create==MH_OK?MH_EnableHook(target):create;
 if(enable==MH_OK)donorProcessTarget=target;logLine("DONOR_PROCESS create=%d enable=%d full-code proof=1; read-only",create,enable);
}
static void donorProcessTick(void){
 bool enabled=donorProcessTarget&&GetFileAttributesW(PROBE_PATH(L"\\donor-process.enable"))!=INVALID_FILE_ATTRIBUTES;
 if(enabled)donorProcessFindModel();
 if(!enabled)InterlockedExchange(&donorProcessEnabled,0);
 else if(!InterlockedCompareExchange(&donorProcessEnabled,0,0)&&!InterlockedCompareExchange(&donorProcessLock,1,0)){donorProcessBegin=0;donorProcessRecords=0;InterlockedExchange(&donorProcessEnabled,1);InterlockedExchange(&donorProcessLock,0);}
 donorProcessFlush();
}
static void donorProcessStop(void){InterlockedExchange(&donorProcessEnabled,0);if(donorProcessTarget)MH_DisableHook(donorProcessTarget);donorProcessFlush();}
