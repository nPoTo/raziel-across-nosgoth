// SPDX-License-Identifier: GPL-3.0-or-later
// Opt-in native detours. The frame owner must explicitly admit one fresh host
// receipt; merely installing these hooks cannot change a collision result.
#include "donor-contact-dispatch.h"
#include "donor-contact-proof.h"
static DonorGroundOriginal donorContactOriginalGround;
static DonorLineOriginal donorContactOriginalLine;
static DonorCachedOriginal donorContactOriginalCached;
typedef void (*DonorCollisionOriginal)(uintptr_t,uint64_t,uint64_t);
static DonorCollisionOriginal donorContactOriginalCollision;
static void donorContactCollision(uintptr_t,uint64_t,uint64_t);
static PVOID donorContactTargets[4];
static _Thread_local DonorContactProjection *donorContactScope;
static _Thread_local struct {
 uintptr_t actor;unsigned phase,queries;bool open,failed;
 uint64_t sequence,tick;
} donorContactFrame;
static volatile LONG64 donorContactProjected,donorContactRefused;
static _Thread_local uintptr_t donorContactObservedActor;
static _Thread_local bool donorContactObservedGround;

// Called only by the owning frame, never by the worker or another hook.
static bool donorContactRuntimeBegin(uintptr_t actor,unsigned phase,uint64_t sequence,uint64_t tick){
 if(donorContactFrame.open){donorContactFrame.failed=true;return false;}
 if(!donorContactTargets[0]||!actor||!sequence||!tick||!donorProcessIdentity(actor)||(phase!=1&&phase!=2))return false;
 memset(&donorContactFrame,0,sizeof(donorContactFrame));
 donorContactFrame.actor=actor;donorContactFrame.phase=phase;donorContactFrame.sequence=sequence;
 donorContactFrame.tick=tick;donorContactFrame.open=true;return true;
}
static bool donorContactRuntimeEnd(unsigned *queries){
 if(queries)*queries=donorContactFrame.queries;
 bool ok=donorContactFrame.open&&!donorContactFrame.failed&&!donorContactScope&&donorProcessIdentity(donorContactFrame.actor);
 donorContactFrame.open=false;return ok;
}
static uint32_t donorContactGround(uintptr_t actor,float *payload,uint16_t flags,uint32_t opaque){
 uintptr_t caller=(uintptr_t)__builtin_return_address(0)-donorProcessBase;
 uint64_t now=GetTickCount64();
 bool eligible=donorContactFrame.open&&!donorContactFrame.failed&&actor==donorContactFrame.actor&&
  caller==0x1563be&&flags==7&&now>=donorContactFrame.tick&&now-donorContactFrame.tick<=150&&donorProcessIdentity(actor);
 DonorContactProjection candidate={.actor=actor,.phase=donorContactFrame.phase,.admitted=eligible};bool matched=false;
 uint32_t result=donorContactForwardGround(donorContactOriginalGround,&donorContactScope,caller,actor,payload,flags,opaque,
  eligible?&candidate:NULL,&matched);
 if(!donorContactFrame.open&&caller==0x1563be&&flags==7&&donorProcessIdentity(actor)){
  donorContactObservedActor=actor;donorContactObservedGround=(result&1)!=0;
 }
 if(eligible){
  ++donorContactFrame.queries;
  if(!matched||!donorProcessIdentity(actor)){donorContactFrame.failed=true;InterlockedIncrement64(&donorContactRefused);}
  else InterlockedIncrement64(&donorContactProjected);
 }else if(donorContactFrame.open&&actor==donorContactFrame.actor&&caller==0x1563be){
  donorContactFrame.failed=true;InterlockedIncrement64(&donorContactRefused);
 }
 return result;
}
static void donorContactLine(uintptr_t actor,DonorContactLine *line,uint32_t opaque){
 uintptr_t caller=(uintptr_t)__builtin_return_address(0)-donorProcessBase;float position[3];
 const float *p=NULL;
 if(donorContactScope&&donorProcessIdentity(actor)&&worldRead(actor+0x20,position,sizeof(position)))p=position;
 donorContactDispatchLine(donorContactOriginalLine,donorContactScope,caller,actor,line,opaque,p);
}
static int32_t donorContactCached(uintptr_t level,uintptr_t segment,float *end,float *start,uintptr_t triangle){
 uintptr_t caller=(uintptr_t)__builtin_return_address(0)-donorProcessBase;
 return donorContactDispatchCached(donorContactOriginalCached,donorContactScope,caller,level,segment,end,start,triangle);
}
static bool donorContactRuntimeInstall(HMODULE module){
 if(!module||donorContactTargets[0])return false;
 uintptr_t base=(uintptr_t)module;
 // Validate every chained unwind fragment BEFORE installing any detour.
 for(unsigned i=0;i<ARRAYSIZE(donorContactProof);i++){
  unsigned char code[4096];char sha[65];const DonorContactProof *p=donorContactProof+i;
  if(!p->bytes||p->bytes>sizeof(code)||!worldRead(base+p->rva,code,p->bytes)||!hashBytes(code,p->bytes,sha)||strcmp(sha,p->sha))return false;
 }
 MH_STATUS init=MH_Initialize();if(init!=MH_OK&&init!=MH_ERROR_ALREADY_INITIALIZED)return false;
 const uintptr_t rvas[4]={0x1039f0,0x103160,0x26ef0,0x1560d0};
 PVOID detours[4]={(PVOID)donorContactGround,(PVOID)donorContactLine,(PVOID)donorContactCached,(PVOID)donorContactCollision};
 PVOID *originals[4]={(PVOID *)&donorContactOriginalGround,(PVOID *)&donorContactOriginalLine,(PVOID *)&donorContactOriginalCached,(PVOID *)&donorContactOriginalCollision};
 unsigned created=0;
 for(unsigned i=0;i<4;i++){
  PVOID target=(PVOID)(base+rvas[i]);
  if(MH_CreateHook(target,detours[i],originals[i])!=MH_OK)goto fail;
  donorContactTargets[i]=target;++created;
 }
 // Enable the outer scope last; partial setup never supplies a projection.
 const unsigned order[4]={2,1,0,3};
 for(unsigned j=0;j<4;j++)if(MH_EnableHook(donorContactTargets[order[j]])!=MH_OK)goto fail;
 logLine("CAPABILITY donor_contact_projection=1; dormant; exact ground scope, native payload retained");
 return true;
fail:
 for(unsigned i=0;i<created;i++){MH_DisableHook(donorContactTargets[i]);MH_RemoveHook(donorContactTargets[i]);donorContactTargets[i]=NULL;}
 return false;
}
// Frame owner must have ended and restored its vertical lease before stop.
// Do not remove trampolines while in-flight original calls may still return.
static void donorContactRuntimeStop(void){
 for(unsigned j=4;j>0;j--)if(donorContactTargets[j-1])MH_DisableHook(donorContactTargets[j-1]);
 logLine("DONOR_CONTACT stop projected=%lld refused=%lld",InterlockedCompareExchange64(&donorContactProjected,0,0),InterlockedCompareExchange64(&donorContactRefused,0,0));
}
