#include "report-path.h"
// SPDX-License-Identifier: GPL-3.0-or-later
// Scoped refusal of new Reaver ribbon primitives. The original continuation
// still updates its vertex pool, end index and lifetime through its NULL path.
typedef void (__fastcall *RibbonFn)(uintptr_t,uintptr_t);
typedef uintptr_t (__fastcall *RibbonAllocFn)(uintptr_t);
static RibbonFn originalRibbon;
static RibbonAllocFn originalRibbonAlloc;
static PVOID ribbonTarget,ribbonAllocTarget;
static DWORD ribbonTls=TLS_OUT_OF_INDEXES;
static uintptr_t ribbonBase;
static bool ribbonAttempted;
static volatile LONG ribbonRequested,ribbonFailed;
static volatile LONG64 ribbonCalls,ribbonEligible,ribbonBlocked;
static bool ribbonNodeMatches(const unsigned char raw[80],uintptr_t callback,uintptr_t owner) {
    int16_t count,start,end;memcpy(&count,raw+0x28,2);memcpy(&start,raw+0x38,2);memcpy(&end,raw+0x3a,2);
    return owner&&worldPointer(raw+8)==callback&&worldPointer(raw+16)==owner&&raw[24]==0&&raw[25]==0&&
        count==4&&start==0&&end==1&&worldPointer(raw+0x30)>=65536;
}
static bool ribbonOwnsNode(uintptr_t node) {
    bool requested=
#ifdef SR1_NATIVE_SKELETON_ADAPTER
        sr1SkeletonCurrentVisibility();
#else
        InterlockedCompareExchange(&ribbonRequested,0,0)!=0;
#endif
    if(!requested||InterlockedCompareExchange(&ribbonFailed,0,0)||
       InterlockedCompareExchange(&probeBoundedComplete,0,0))return false;
    ULONGLONG now=GetTickCount64();
#ifdef SR1_NATIVE_SKELETON_ADAPTER
    {uintptr_t player=0,base=(uintptr_t)InterlockedCompareExchangePointer(&verifiedSr1Module,NULL,NULL);if(!base||!worldRead(base+0x2a89310,&player,8)||!sr1SkeletonVisibilityScope(player))return false;}
#elif defined(SR1_RETARGET_PREVIEW)
    if(!sr1RetargetWeaponScope(overlayHostActor))return false;
#else
    if(!worldLastDraw||now<worldLastDraw||now-worldLastDraw>=250)return false;
#endif
    uintptr_t player=0;uint32_t color=0;ReaverEvent event={0};unsigned char raw[80],again[32];
    if(!reaverPlayerIdentity(&player)||
#ifdef SR1_NATIVE_SKELETON_ADAPTER
       !sr1SkeletonVisibilityScope(player)||
#elif defined(SR1_RETARGET_PREVIEW)
       !sr1RetargetWeaponScope(player)||
#else
       player!=worldLastInstance||
#endif
       !lightReaverColor(player,now,&color))return false;
    if(InterlockedCompareExchange(&reaverLock,1,0))return false;
    event=latestReaver;InterlockedExchange(&reaverLock,0);
    if(!lightRecentReaver(&event,player,now)||!worldRead(node,raw,sizeof(raw))||
       !ribbonNodeMatches(raw,ribbonBase+0x52560,event.instance)||!worldRead(node,again,sizeof(again))||
       memcmp(raw,again,sizeof(again)))return false;
    return true;
}
static bool ribbonAllocationMatches(uintptr_t tracker,uintptr_t scope,uintptr_t caller,uintptr_t base,bool enabled) {
    return enabled&&tracker&&tracker==scope&&base&&(caller==base+0x52775||caller==base+0x52854);
}
// Shared production allocation/forwarding path. Request ownership is supplied
// separately so fixtures need not fabricate a live HUD/player visibility lease.
static uintptr_t ribbonAllocateRequested(uintptr_t tracker,uintptr_t caller,bool requested) {
    uintptr_t scope=ribbonTls==TLS_OUT_OF_INDEXES?0:(uintptr_t)TlsGetValue(ribbonTls);
    bool enabled=requested&&!InterlockedCompareExchange(&ribbonFailed,0,0)&&
        !InterlockedCompareExchange(&probeBoundedComplete,0,0);
    if(ribbonAllocationMatches(tracker,scope,caller,ribbonBase,enabled)){
        InterlockedIncrement64(&ribbonBlocked);return 0;
    }
    return originalRibbonAlloc(tracker);
}
static uintptr_t ribbonAllocate(uintptr_t tracker,uintptr_t caller) {
    bool requested=
#ifdef SR1_NATIVE_SKELETON_ADAPTER
        sr1SkeletonCurrentVisibility();
#else
        InterlockedCompareExchange(&ribbonRequested,0,0)!=0;
#endif
    return ribbonAllocateRequested(tracker,caller,requested);
}
static __declspec(noinline) uintptr_t __fastcall observeRibbonAlloc(uintptr_t tracker) {
    return ribbonAllocate(tracker,(uintptr_t)__builtin_return_address(0));
}
static void ribbonForward(uintptr_t node,uintptr_t tracker,bool eligible) {
    if(ribbonTls==TLS_OUT_OF_INDEXES){originalRibbon(node,tracker);return;}
    PVOID previous=TlsGetValue(ribbonTls);
    // An unrelated nested continuation must clear an outer scope temporarily.
    if(!TlsSetValue(ribbonTls,eligible?(PVOID)tracker:NULL)){
        InterlockedExchange(&ribbonFailed,1);originalRibbon(node,tracker);return;
    }
    originalRibbon(node,tracker);
    if(!TlsSetValue(ribbonTls,previous))InterlockedExchange(&ribbonFailed,1);
}
static void __fastcall observeRibbon(uintptr_t node,uintptr_t tracker) {
    InterlockedIncrement64(&ribbonCalls);bool eligible=tracker&&ribbonOwnsNode(node);
    if(eligible)InterlockedIncrement64(&ribbonEligible);
    ribbonForward(node,tracker,eligible);
}
static void ribbonLog(void) {
#ifdef SR1_NATIVE_SKELETON_ADAPTER
    bool requested=GetFileAttributesW(PROBE_PATH(L"\\hide-reaver-ribbon-sr1.enable"))!=INVALID_FILE_ATTRIBUTES;
#else
    bool requested=GetFileAttributesW(PROBE_PATH(L"\\hide-reaver-ribbon-sr1.enable"))!=INVALID_FILE_ATTRIBUTES&&
        GetFileAttributesW(PROBE_PATH(L"\\replace-sr1.enable"))!=INVALID_FILE_ATTRIBUTES&&
        GetFileAttributesW(PROBE_PATH(L"\\world-sr1.enable"))!=INVALID_FILE_ATTRIBUTES;
#endif
    InterlockedExchange(&ribbonRequested,requested);
    if(requested)logLine("REAVER_RIBBON calls=%lld eligible=%lld blocked=%lld failed=%ld; original continuation forwarded",
        InterlockedCompareExchange64(&ribbonCalls,0,0),InterlockedCompareExchange64(&ribbonEligible,0,0),
        InterlockedCompareExchange64(&ribbonBlocked,0,0),InterlockedCompareExchange(&ribbonFailed,0,0));
}
static void ribbonInstall(HMODULE module) {
    if(ribbonAttempted)return;ribbonAttempted=true;
    uintptr_t base=(uintptr_t)module;unsigned char code[1247];char hash[65];
    for(unsigned int i=0;i<ARRAYSIZE(ribbonCodeProofs);++i){
        if(ribbonCodeProofs[i].size>sizeof(code)||!worldRead(base+ribbonCodeProofs[i].rva,code,ribbonCodeProofs[i].size)||
           !hashBytes(code,ribbonCodeProofs[i].size,hash)||strcmp(hash,ribbonCodeProofs[i].sha256)){
            logLine("REAVER_RIBBON full-code proof mismatch; disabled");return;
        }
    }
    HMODULE pinned;if(!GetModuleHandleExW(GET_MODULE_HANDLE_EX_FLAG_FROM_ADDRESS|GET_MODULE_HANDLE_EX_FLAG_PIN,(LPCWSTR)base,&pinned))return;
    ribbonTls=TlsAlloc();if(ribbonTls==TLS_OUT_OF_INDEXES)return;
    MH_STATUS init=MH_Initialize();if(init!=MH_OK&&init!=MH_ERROR_ALREADY_INITIALIZED)return;
    PVOID continuation=(PVOID)(base+0x52560),allocator=(PVOID)(base+0x556d0);
    MH_STATUS a=MH_CreateHook(continuation,(PVOID)&observeRibbon,(PVOID *)&originalRibbon);
    MH_STATUS b=a==MH_OK?MH_CreateHook(allocator,(PVOID)&observeRibbonAlloc,(PVOID *)&originalRibbonAlloc):a;
    if(a!=MH_OK||b!=MH_OK){logLine("REAVER_RIBBON create failed=%d,%d",a,b);return;}
    ribbonBase=base;
    a=MH_EnableHook(allocator);b=a==MH_OK?MH_EnableHook(continuation):a;
    if(a!=MH_OK||b!=MH_OK){MH_DisableHook(allocator);MH_DisableHook(continuation);logLine("REAVER_RIBBON enable failed=%d,%d",a,b);return;}
    ribbonTarget=continuation;ribbonAllocTarget=allocator;
    logLine("REAVER_RIBBON installed; full code hashes verified, default forwarding, scoped NULL allocation only");
}
static void ribbonStop(void) {
    InterlockedExchange(&ribbonRequested,0);
    if(ribbonTarget)logLine("REAVER_RIBBON continuation disabled=%d",MH_DisableHook(ribbonTarget)==MH_OK);
    if(ribbonAllocTarget)logLine("REAVER_RIBBON allocator disabled=%d",MH_DisableHook(ribbonAllocTarget)==MH_OK);
    // Retain trampolines and TLS slot for any in-flight call until process exit.
}
