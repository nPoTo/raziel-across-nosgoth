// SPDX-License-Identifier: GPL-3.0-or-later
#include "donor-contact-scope.h"
#include <assert.h>
#include <stdio.h>
static DonorContactProjection *scope;
static unsigned calls;static float *expectedPayload;static bool nested;
static uint32_t original(uintptr_t actor,float *payload,uint16_t flags,uint32_t opaque){
 ++calls;assert(actor==0x1234&&payload==expectedPayload&&flags==7&&opaque==0xdeadbeef);
 if(nested){
  nested=false;bool matched=true;
  DonorContactProjection child={.actor=actor,.phase=1,.admitted=true};
  assert(donorContactForwardGround(original,&scope,0x1563be,actor,payload,flags,opaque,&child,&matched)==17);
  assert(!matched&&scope&&scope->poisoned);
 }
 if(scope&&!scope->poisoned){
  float p[3]={0,0,100};DonorContactLine line={.flags=0x3f,.start={0,0,148,0},.end={0,0,4,0}};
  assert(donorContactSkipCached(scope,0x103b4d));
  assert(donorContactProjectLine(scope,0x103c47,actor,&line,p));
  // Stand-in for the native consumer's contact bit, never a game call.
  return scope->phase==1?1:0;
 }
 return 17;
}
int main(void){
 float nativePool[8]={0};expectedPayload=nativePool;bool matched=false;
 for(unsigned phase=1;phase<=2;phase++){
  calls=0;DonorContactProjection candidate={.actor=0x1234,.phase=phase,.admitted=true};
  uint32_t result=donorContactForwardGround(original,&scope,0x1563be,0x1234,nativePool,7,0xdeadbeef,&candidate,&matched);
  assert(calls==1&&!scope&&matched&&result==(phase==1?1u:0u));
 }
 calls=0;DonorContactProjection candidate={.actor=0x1234,.phase=1,.admitted=true};
 assert(donorContactForwardGround(original,&scope,0,0x1234,nativePool,7,0xdeadbeef,&candidate,&matched)==17);
 assert(calls==1&&!scope&&!matched&&!candidate.lineCalls);
 calls=0;nested=true;
 assert(donorContactForwardGround(original,&scope,0x1563be,0x1234,nativePool,7,0xdeadbeef,&candidate,&matched)==17);
 assert(calls==2&&!scope&&!matched&&candidate.poisoned);
 puts("PASS scoped native query forwarding: original once, identical native payload/flags/opaque, foreign passthrough and nested poison; no runtime hook");
 return 0;
}
