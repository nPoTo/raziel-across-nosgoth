// SPDX-License-Identifier: GPL-3.0-or-later
// Reads actual SR1 scalars; writes only our pagefile intent/ack mapping.
#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <tlhelp32.h>
#include <bcrypt.h>
#include <stdio.h>
#include <stdlib.h>
#include <wchar.h>
#include "host-block-animation-reader.h"
#include "first-block-memory.h"
#include "reader-hash.h"
static bool readAt(void *p,uintptr_t at,void *out,SIZE_T n){SIZE_T got=0;return at&&ReadProcessMemory((HANDLE)p,(void *)at,out,n,&got)&&got==n;}
static bool codeAt(void *p,uintptr_t at,uintptr_t base){MEMORY_BASIC_INFORMATION m={0};return VirtualQueryEx((HANDLE)p,(void *)at,&m,sizeof(m))==sizeof(m)&&m.State==MEM_COMMIT&&m.Type==MEM_IMAGE&&(uintptr_t)m.AllocationBase==base&&!(m.Protect&(PAGE_GUARD|PAGE_NOACCESS))&&(m.Protect&(PAGE_EXECUTE|PAGE_EXECUTE_READ|PAGE_EXECUTE_READWRITE|PAGE_EXECUTE_WRITECOPY));}
static uint64_t creation(HANDLE p){FILETIME c,e,k,u;return GetProcessTimes(p,&c,&e,&k,&u)?((uint64_t)c.dwHighDateTime<<32)|c.dwLowDateTime:0;}
static bool game(HANDLE p,const wchar_t *env,const char *expected,wchar_t path[32768]){wchar_t configured[32768];DWORD n=32768,length=GetEnvironmentVariableW(env,configured,32768);char hash[65];return length&&length<32768&&QueryFullProcessImageNameW(p,0,path,&n)&&!_wcsicmp(path,configured)&&hashFile(path,hash)&&!strcmp(hash,expected);}
static bool actorIdentity(HANDLE p,uintptr_t actor){uintptr_t object=0,name=0;char value[9];return actor&&actor%8==0&&hostBlockField(p,readAt,actor,0x30,&object,8)&&hostBlockField(p,readAt,object,0x30,&name,8)&&readAt(p,name,value,9)&&!memcmp(value,"raziel__",9);}
static unsigned long pidArg(const wchar_t *s){wchar_t *e=NULL;unsigned long v=wcstoul(s,&e,10);return v&&e&&!*e?v:0;}
int wmain(int argc,wchar_t **argv){
 const Sheet_firstBlockPilotPolicy *policy=&sheet_firstBlockPilotPolicy_bounded;
 if(argc!=3)return 1;DWORD hostPid=pidArg(argv[1]),donorPid=pidArg(argv[2]);if(!hostPid||!donorPid||hostPid==donorPid)return 1;
 HANDLE host=OpenProcess(SYNCHRONIZE|PROCESS_QUERY_LIMITED_INFORMATION|PROCESS_VM_READ,FALSE,hostPid),donor=OpenProcess(SYNCHRONIZE|PROCESS_QUERY_LIMITED_INFORMATION,FALSE,donorPid),map=NULL;FirstBlockMemory *view=NULL;int result=2;
 wchar_t hostPath[32768],donorPath[32768],modulePath[32768];char hash[65];
 if(!game(host,L"RAZIEL_SR1_EXE","0fb3aef0530ebf0510191f934dc371b69b43574331d3623eda694b72f060db93",hostPath)||!game(donor,L"RAZIEL_DEFIANCE_EXE","fc6a406ff7ac9b5eb7788dc7a65d335e1c1aad9236618112671975b71d2daddc",donorPath)||wcslen(hostPath)+12>=32768||!wcsrchr(hostPath,L'\\'))goto done;
 wcscpy(modulePath,hostPath);wcscpy(wcsrchr(modulePath,L'\\')+1,L"1\\sr1.dll");if(!hashFile(modulePath,hash)||strcmp(hash,"c006dea45509cdc3fbfab3a4230b47869c306ecdd7df8b4fd2499fd3654a2205"))goto done;
 uintptr_t base=0;uint32_t imageSize=0;HANDLE snapshot=CreateToolhelp32Snapshot(TH32CS_SNAPMODULE,hostPid);MODULEENTRY32W entry={0};entry.dwSize=sizeof(entry);unsigned matches=0;
 if(snapshot!=INVALID_HANDLE_VALUE){if(Module32FirstW(snapshot,&entry))do{if(!_wcsicmp(entry.szExePath,modulePath)){base=(uintptr_t)entry.modBaseAddr;imageSize=entry.modBaseSize;++matches;}}while(Module32NextW(snapshot,&entry));CloseHandle(snapshot);}if(matches!=1||imageSize<0x2a89538)goto done;
 FirstBlockHeader h={.magic=0x314b4c42,.version=1,.bytes=sizeof(FirstBlockMemory),.hostPid=hostPid,.donorPid=donorPid,.writerPid=GetCurrentProcessId(),.hostCreation=creation(host),.donorCreation=creation(donor),.writerCreation=creation(GetCurrentProcess()),.beginTick=GetTickCount64()};
 if(BCryptGenRandom(NULL,(unsigned char *)&h.session,8,BCRYPT_USE_SYSTEM_PREFERRED_RNG)<0)goto done;for(unsigned i=0;i<32;i++){char text[3]={EXPLORATION_SHEET_SHA256[i*2],EXPLORATION_SHEET_SHA256[i*2+1],0};h.sheetHash[i]=(unsigned char)strtoul(text,NULL,16);}if(!firstBlockHeaderValid(&h,donorPid,h.donorCreation))goto done;
 wchar_t name[160];firstBlockName(name,donorPid,h.donorCreation);SetLastError(0);map=CreateFileMappingW(INVALID_HANDLE_VALUE,NULL,PAGE_READWRITE,0,sizeof(FirstBlockMemory),name);if(!map||GetLastError()==ERROR_ALREADY_EXISTS)goto done;view=MapViewOfFile(map,FILE_MAP_READ|FILE_MAP_WRITE,0,0,sizeof(*view));if(!view)goto done;memset(view,0,sizeof(*view));view->header=h;
 printf("{\"type\":\"ready\",\"session\":\"%llu\",\"hostCreation\":\"%llu\",\"donorCreation\":\"%llu\",\"tick\":%llu}\n",(unsigned long long)h.session,(unsigned long long)h.hostCreation,(unsigned long long)h.donorCreation,(unsigned long long)h.beginTick);fflush(stdout);
 // Runner holds the displayed counter at preparation until actual native HUD
 // acknowledgement. Only then does it send the scenario's monotonic start.
 uint64_t start=0;DWORD got=0;if(!ReadFile(GetStdHandle(STD_INPUT_HANDLE),&start,8,&got,NULL)||got!=8||start<h.beginTick||start-h.beginTick>(uint64_t)policy->startupMs)goto done;
 uintptr_t boundActor=0;uint64_t sequence=0,lastPrinted=0;uint32_t publishBusy=0;result=0;
 while(GetTickCount64()-start<(uint64_t)policy->seconds*1000+(uint64_t)policy->cancelDeadlineMs){uint64_t now=GetTickCount64(),elapsed=now-start;FirstBlockIntent c={.session=h.session,.sequence=++sequence,.tick=now};FirstBlockAck ack={0};unsigned desired=0;uintptr_t actor=0,again=0;uint16_t ids[3]={0};HostBlockState state={0};uint32_t flags=0,flagsAfter=0;uint16_t mode=0,modeAfter=0;
  DWORD available=0;bool supervisor=PeekNamedPipe(GetStdHandle(STD_INPUT_HANDLE),NULL,0,NULL,&available,NULL)&&!available;
  bool alive=supervisor&&WaitForSingleObject(host,0)==WAIT_TIMEOUT&&WaitForSingleObject(donor,0)==WAIT_TIMEOUT;
  if(alive&&readAt(host,base+0x2a89310,&actor,8)&&actorIdentity(host,actor))state=hostBlockAnimationStateRead(host,readAt,codeAt,base,imageSize,actor,ids);
  if(state.valid&&(!actorIdentity(host,actor)||!readAt(host,base+0x2a89310,&again,8)||again!=actor))state.valid=false;
  if(state.valid){if(boundActor&&actor!=boundActor){state.valid=false;result=4;}else boundActor=actor;}
  bool ui=readAt(host,base+0x2a8950c,&flags,4)&&readAt(host,base+0x2a89536,&mode,2)&&readAt(host,base+0x2a8950c,&flagsAfter,4)&&readAt(host,base+0x2a89536,&modeAfter,2)&&flags==flagsAfter&&mode==modeAfter&&mode==0&&!(flags&0x10000000);
  for(unsigned i=0;i<3;i++)c.phases[i]=state.valid?firstBlockPhase(state.sections[i].callbackRva,ids[i],i):FB_UNKNOWN;
  bool mapped=firstBlockDesired(c.phases,&desired);c.desired=desired;c.valid=alive&&state.valid&&ui&&mapped&&elapsed>=(uint64_t)policy->prepareSeconds*1000&&elapsed<(uint64_t)policy->seconds*1000&&!(elapsed>=(uint64_t)policy->outageBeginMs&&elapsed<(uint64_t)policy->outageEndMs)&&!result;
  if(!firstBlockWriteIntent(view,&c))++publishBusy; // try again on the next bounded sample; expiry still applies
  bool ackRead=firstBlockReadAck(view,&ack);uint64_t readTick=GetTickCount64();bool ackValid=ackRead&&ack.tick&&readTick>=ack.tick&&readTick-ack.tick<=(uint64_t)policy->ackFreshMs&&ack.sequence<=sequence;
  if(now-lastPrinted>=100||elapsed>=(uint64_t)policy->seconds*1000){lastPrinted=now;printf("{\"type\":\"sample\",\"sequence\":%llu,\"tick\":%llu,\"elapsed\":%llu,\"stateValid\":%u,\"ui\":%u,\"mapped\":%u,\"valid\":%u,\"desired\":%u,\"phases\":[%u,%u,%u],\"ackValid\":%u,\"ackSequence\":%llu,\"ackTick\":%llu,\"frames\":%llu,\"owned\":%u,\"held\":%u,\"primary\":[%u,%u,%u],\"keys\":[%u,%u,%u],\"overrides\":[%u,%u,%u,%u],\"pressTrue\":%u,\"releaseTrue\":%u,\"heldTrue\":%u,\"failure\":%u,\"gates\":%u,\"targetValid\":%u,\"targetHandler\":%u,\"publishBusy\":%u}\n",(unsigned long long)sequence,(unsigned long long)now,(unsigned long long)elapsed,state.valid,ui,mapped,c.valid,desired,c.phases[0],c.phases[1],c.phases[2],ackValid,(unsigned long long)ack.sequence,(unsigned long long)ack.tick,(unsigned long long)ack.frames,ack.owned,ack.held,ack.primary[0],ack.primary[1],ack.primary[2],ack.keys[0],ack.keys[1],ack.keys[2],ack.overrides[0],ack.overrides[1],ack.overrides[2],ack.overrides[3],ack.pressTrue,ack.releaseTrue,ack.heldTrue,ack.failure,ack.gates,ack.targetValid,ack.targetHandler,publishBusy);fflush(stdout);}
  if(!alive){result=6;break;}if(result)break;if(elapsed>=(uint64_t)policy->seconds*1000&&ackValid&&!ack.owned&&ack.targetValid&&ack.targetHandler==0xce270)break;Sleep((DWORD)policy->sampleIntervalMs);
 }
 {FirstBlockIntent clear={.session=h.session,.sequence=++sequence,.tick=GetTickCount64()};firstBlockWriteIntent(view,&clear);}
done:if(view)UnmapViewOfFile(view);if(map)CloseHandle(map);if(host)CloseHandle(host);if(donor)CloseHandle(donor);return result;
}
