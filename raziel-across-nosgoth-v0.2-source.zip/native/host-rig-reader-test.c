// SPDX-License-Identifier: GPL-3.0-or-later
#include <stdio.h>
#include "host-rig-reader.h"
typedef struct {uintptr_t at;unsigned char data[16384];size_t bytes;} Block;
static Block blocks[9];static unsigned reads,globalReads;static bool race;
static bool readFixture(void *unused,uintptr_t at,void *out,SIZE_T n){
 (void)unused;reads++;if(at==0x100000+0x2a89310&&++globalReads==2&&race)return false;
 for(unsigned i=0;i<9;i++)if(at>=blocks[i].at&&at-blocks[i].at<=blocks[i].bytes&&n<=blocks[i].bytes-(at-blocks[i].at)){memcpy(out,blocks[i].data+at-blocks[i].at,n);return true;}return false;
}
static void u64(unsigned b,size_t p,uint64_t v){memcpy(blocks[b].data+p,&v,8);}
static void i32(unsigned b,size_t p,int32_t v){memcpy(blocks[b].data+p,&v,4);}
static void i16(unsigned b,size_t p,int16_t v){memcpy(blocks[b].data+p,&v,2);}
static void setup(void){
 memset(blocks,0,sizeof(blocks));reads=globalReads=0;race=false;
 uintptr_t a[]={0x100000+0x2a89310,0x50000,0x60000,0x70000,0x80000,0x90000,0xa0000,0xb0000,0xc0000};
 for(unsigned i=0;i<9;i++){blocks[i].at=a[i];blocks[i].bytes=sizeof(blocks[i].data);}
 u64(0,0,blocks[1].at);u64(1,0x30,blocks[2].at);u64(2,0x30,blocks[3].at);memcpy(blocks[3].data,"raziel__",9);
 u64(2,0x10,blocks[4].at);u64(4,0,blocks[5].at);i32(5,0x30,2);u64(5,0x38,blocks[6].at);i16(6,18,-1);i16(6,32+18,0);
 u64(1,0x68,blocks[7].at);u64(1,0x70,blocks[8].at);
}
#define CHECK(c,n) do{if(!(c)){printf("failed %d\n",n);return n;}}while(0)
int main(void){
 HostRig out;setup();CHECK(hostRigRead(NULL,readFixture,0x100000,&out)&&out.count==2&&out.parents[0]==-1&&reads<100,1);
 setup();i32(5,0x30,129);CHECK(!hostRigRead(NULL,readFixture,0x100000,&out),2);
 setup();i16(1,0x1c6,1);CHECK(!hostRigRead(NULL,readFixture,0x100000,&out),3);
 setup();i16(6,18,1);i16(6,32+18,0);CHECK(!hostRigRead(NULL,readFixture,0x100000,&out),4);
 setup();i16(6,32+18,2);CHECK(!hostRigRead(NULL,readFixture,0x100000,&out),5);
 setup();blocks[3].data[0]='k';CHECK(!hostRigRead(NULL,readFixture,0x100000,&out),6);
 setup();race=true;CHECK(!hostRigRead(NULL,readFixture,0x100000,&out),7);
 setup();i32(8,0,0x7fc00000);CHECK(!hostRigRead(NULL,readFixture,0x100000,&out),8);
 setup();u64(1,0x70,0);CHECK(!hostRigRead(NULL,readFixture,0x100000,&out),9);
 setup();u64(4,0,0x90001);CHECK(!hostRigRead(NULL,readFixture,0x100000,&out),10);
 setup();blocks[6].bytes=20;CHECK(!hostRigRead(NULL,readFixture,0x100000,&out),11);
 CHECK(!rigField(NULL,readFixture,UINTPTR_MAX-1,8,&out,8),12);
 setup();blocks[3].at++;u64(2,0x30,blocks[3].at);CHECK(hostRigRead(NULL,readFixture,0x100000,&out),13);
 setup();blocks[4].at+=4;u64(2,0x10,blocks[4].at);CHECK(hostRigRead(NULL,readFixture,0x100000,&out),14);
 setup();blocks[5].at+=4;u64(4,0,blocks[5].at);blocks[6].at+=4;u64(5,0x38,blocks[6].at);CHECK(hostRigRead(NULL,readFixture,0x100000,&out),15);
 puts("host rig reader: bounded identity/topology/race/finite negatives PASS; not live proof");return 0;
}
