// SPDX-License-Identifier: GPL-3.0-or-later
#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <stdbool.h>
#include <stdint.h>
#include <stdio.h>
#include <string.h>
#include "donor-message-collector.h"

#define CHECK(x) do{if(!(x)){printf("FAIL message collector line%u: %s\n",(unsigned)__LINE__,#x);return 1;}}while(0)
typedef struct {uint64_t count;DonorMessageEvent first[300],last;} Sink;
static DonorMessageCollector collector;
static Sink sink;
static void emit(void *context,const DonorMessageEvent *e){Sink *s=context;if(s->count<ARRAYSIZE(s->first))s->first[s->count]=*e;s->last=*e;s->count++;}
static void setup(void){memset(&sink,0,sizeof(sink));donorMessageCollectorInit(&collector,&sink,emit);}
static void pair(DonorMessageEvent *entry,DonorMessageEvent *exit,uint64_t id,uint64_t tick){
 memset(entry,0,sizeof(*entry));entry->session=17;entry->callId=id;entry->tickMs=tick;entry->threadId=3;entry->depth=1;entry->phase=DONOR_MESSAGE_ENTER;entry->section=0;entry->messageId=0x4010402;entry->payloadZero=1;entry->beforeSecondMask=7;
 for(unsigned i=0;i<3;i++){entry->beforeFirstRva[i]=0x1000+i*0x10;entry->beforeSecondRva[i]=0x2000+i*0x10;}
 *exit=*entry;exit->phase=DONOR_MESSAGE_EXIT;exit->afterValid=1;exit->afterSecondMask=7;memcpy(exit->afterFirstRva,entry->beforeFirstRva,sizeof(exit->afterFirstRva));memcpy(exit->afterSecondRva,entry->beforeSecondRva,sizeof(exit->afterSecondRva));
}
static void acceptPair(DonorMessageEvent *entry,DonorMessageEvent *exit){donorMessageCollectorAccept(&collector,entry);donorMessageCollectorAccept(&collector,exit);}
static bool conserved(void){return collector.seen==collector.logged+collector.sampled+collector.discarded+collector.pendingCount&&collector.logged==sink.count;}
int main(void){
 DonorMessageEvent entry,exit;setup();CHECK(collector.configured&&collector.maxRecords==20000);
 pair(&entry,&exit,1,1000);DonorMessageEvent originalEntry=entry,originalExit=exit;acceptPair(&entry,&exit);CHECK(!memcmp(&entry,&originalEntry,sizeof(entry))&&!memcmp(&exit,&originalExit,sizeof(exit)));CHECK(collector.seen==2&&collector.logged==2&&collector.sampled==0&&conserved());
 for(unsigned i=0;i<4;i++){pair(&entry,&exit,2+i,1001+i);acceptPair(&entry,&exit);}
 CHECK(collector.seen==10&&collector.logged==2&&collector.sampled==8&&conserved());
 pair(&entry,&exit,6,1100);acceptPair(&entry,&exit);CHECK(collector.logged==4&&collector.sampled==8&&conserved());
 // Observed callback changes, nested calls and rare IDs never coalesce.
 for(unsigned kind=0;kind<3;kind++)for(unsigned i=0;i<2;i++){
  pair(&entry,&exit,10+kind*2+i,1101);if(kind==0)exit.afterFirstRva[1]++;if(kind==1)entry.depth=exit.depth=2;if(kind==2)entry.messageId=exit.messageId=0x100004;acceptPair(&entry,&exit);
 }
 CHECK(collector.logged==16&&collector.sampled==8&&conserved());donorMessageCollectorFinish(&collector);CHECK(collector.finished&&collector.pendingCount==0&&collector.orphanEntries==0&&conserved());
 donorMessageCollectorFinish(&collector);CHECK(collector.logged==16);donorMessageCollectorAccept(&collector,&entry);CHECK(collector.discarded==1&&conserved());
 // A nested child completes first: preserve each pair, including their original
 // clocks/depth, while permitting completion-order (not global time) output.
 setup();DonorMessageEvent outer,outerExit,inner,innerExit;pair(&outer,&outerExit,1,2000);outerExit.tickMs=2003;pair(&inner,&innerExit,2,2001);inner.depth=innerExit.depth=2;innerExit.tickMs=2002;
 donorMessageCollectorAccept(&collector,&outer);donorMessageCollectorAccept(&collector,&inner);donorMessageCollectorAccept(&collector,&innerExit);donorMessageCollectorAccept(&collector,&outerExit);CHECK(sink.count==4&&sink.first[0].callId==2&&sink.first[1].phase==2&&sink.first[2].callId==1&&sink.first[2].tickMs==2000&&conserved());
 // The same numeric call ID on another session/thread must never steal a slot.
 setup();pair(&entry,&exit,1,3000);donorMessageCollectorAccept(&collector,&entry);DonorMessageEvent other=exit;other.session++;donorMessageCollectorAccept(&collector,&other);CHECK(collector.pendingCount==1&&collector.logged==1);other=exit;other.threadId++;donorMessageCollectorAccept(&collector,&other);CHECK(collector.pendingCount==1&&collector.logged==2);donorMessageCollectorAccept(&collector,&exit);CHECK(collector.pendingCount==0&&collector.logged==4&&conserved());
 // Duplicate pending entries count a single discarded raw row, without eviction.
 setup();pair(&entry,&exit,1,4000);donorMessageCollectorAccept(&collector,&entry);donorMessageCollectorAccept(&collector,&entry);CHECK(collector.discarded==1&&collector.pendingCount==1&&conserved());donorMessageCollectorAccept(&collector,&exit);CHECK(collector.logged==2&&conserved());
 // All128 pending slots remain intact when a129th entry falls back to wire.
 setup();for(unsigned i=0;i<129;i++){pair(&entry,&exit,i+1,5000+i);donorMessageCollectorAccept(&collector,&entry);}CHECK(collector.pendingCount==128&&collector.logged==1&&sink.first[0].callId==129&&conserved());
 pair(&entry,&exit,129,5128);donorMessageCollectorAccept(&collector,&exit);CHECK(collector.logged==2&&sink.first[1].callId==129&&conserved());
 for(unsigned i=0;i<128;i++){pair(&entry,&exit,i+1,5000+i);entry.messageId=exit.messageId=0x4010402;donorMessageCollectorAccept(&collector,&exit);}donorMessageCollectorFinish(&collector);CHECK(collector.orphanEntries==0&&collector.pendingCount==0&&conserved());
 // Finish emits retained orphan entries and reports their missing exits without
 // claiming that those emitted entry rows themselves were discarded.
 setup();for(unsigned i=0;i<3;i++){pair(&entry,&exit,i+1,6000+i);donorMessageCollectorAccept(&collector,&entry);}CHECK(collector.logged==0&&collector.pendingCount==3&&conserved());donorMessageCollectorFinish(&collector);CHECK(collector.logged==3&&collector.orphanEntries==3&&collector.discarded==0&&conserved());
 // Exercise the real20k wire policy, including the one-slot remainder case.
 setup();for(unsigned i=0;i<9999;i++){pair(&entry,&exit,i+1,7000+i);entry.messageId=exit.messageId=0x100004;acceptPair(&entry,&exit);}CHECK(collector.logged==19998&&conserved());
 pair(&entry,&exit,10000,17000);exit.messageId=0x100004;donorMessageCollectorAccept(&collector,&exit);CHECK(collector.logged==19999&&conserved());
 pair(&entry,&exit,10001,17001);entry.messageId=exit.messageId=0x100004;acceptPair(&entry,&exit);CHECK(collector.logged==19999&&collector.discarded==2&&conserved());
 pair(&entry,&exit,10002,17002);donorMessageCollectorAccept(&collector,&entry);donorMessageCollectorFinish(&collector);CHECK(collector.logged==20000&&collector.orphanEntries==1&&conserved());
 // Saturated wire budget discards orphan flush rows once and caps all output.
 setup();for(unsigned i=0;i<10000;i++){pair(&entry,&exit,i+1,18000+i);entry.messageId=exit.messageId=0x100004;acceptPair(&entry,&exit);}CHECK(collector.logged==20000&&conserved());
 for(unsigned i=0;i<129;i++){pair(&entry,&exit,11000+i,30000+i);donorMessageCollectorAccept(&collector,&entry);}CHECK(collector.pendingCount==128&&collector.discarded==1&&conserved());donorMessageCollectorFinish(&collector);CHECK(collector.logged==20000&&collector.discarded==129&&collector.orphanEntries==128&&conserved());
 // Invalid phase/no sink cannot escape accounting; NULL is not a raw row.
 setup();pair(&entry,&exit,1,40000);entry.phase=3;donorMessageCollectorAccept(&collector,&entry);donorMessageCollectorAccept(&collector,NULL);donorMessageCollectorAccept(NULL,&entry);CHECK(collector.seen==1&&collector.discarded==1&&conserved());
 donorMessageCollectorInit(&collector,&sink,NULL);CHECK(!collector.configured);donorMessageCollectorAccept(&collector,&exit);donorMessageCollectorFinish(&collector);CHECK(collector.seen==1&&collector.discarded==1&&collector.logged==0);
 puts("PASS: production fixed128 scalar collector, completed-pair sampling, transition/nested/rare retention, tuple ownership, pending overflow without eviction, terminal orphan flush, atomic two-row20k budget and exact seen/logged/sampled/discarded conservation; no native calls, game access or I/O");return 0;
}
