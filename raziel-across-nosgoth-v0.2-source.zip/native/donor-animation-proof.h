// Instance+398 callback, supported caller (instance, tracker), return ignored.
#define DONOR_ANIMATION_RVA 0x1560d0
#define DONOR_ANIMATION_SIZE 2575
#define DONOR_ANIMATION_SHA "360aff9b6c1e943bcacce5277244209a6df575e1e4fd3403d0aa58a20e5eef41"
// Matrix update copies final translation into instance+20/+24/+28 at5f16b/5f176/5f181.
#define DONOR_MATRIX_RVA 0x5edb0
#define DONOR_MATRIX_SIZE 992
#define DONOR_MATRIX_SHA "389b1a73e6435e6ad03dde3f7d91959a306f95ddb5a014ccb1eb998d73bab334"
