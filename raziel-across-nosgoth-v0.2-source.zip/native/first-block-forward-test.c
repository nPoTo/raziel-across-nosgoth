// SPDX-License-Identifier: GPL-3.0-or-later
#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <stdint.h>
#include <stdbool.h>
#include <stdio.h>
#include <stdarg.h>
#include <assert.h>
#include <MinHook.h>
#include "donor-state-sections.h"
static uintptr_t donorMessageBase=0x10000000;static uint32_t donorMessageImageSize=0x2000000;static PVOID donorMessageTarget;
static bool worldRead(uintptr_t a,void *b,SIZE_T n){(void)a;(void)b;(void)n;return false;}
static bool donorMessageRead(void *c,uintptr_t a,void *b,SIZE_T n){(void)c;return worldRead(a,b,n);}
static bool donorMessageCode(void *c,uintptr_t a,uintptr_t b){(void)c;(void)a;(void)b;return false;}
static bool donorProcessIdentity(uintptr_t a){(void)a;return false;}
static void donorProcessFindModel(void){}
static bool hashBytes(void *a,ULONG n,char out[65]){(void)a;(void)n;(void)out;return false;}
static void logLine(const char *format,...){(void)format;}
#define PROBE_PATH(s) L"C:\\nonexistent-first-block-fixture" s
#include "first-block-runtime.h"
static volatile unsigned calls;static uintptr_t args[3];static DWORD seenError;static volatile uintptr_t answer=UINT64_C(0xfedcba98765432ff);
__attribute__((noinline)) static uintptr_t __fastcall query(uintptr_t a,uintptr_t b){seenError=GetLastError();args[0]=a;args[1]=b;++calls;SetLastError(7654);return answer;}
__attribute__((noinline)) static uintptr_t __fastcall direction(uintptr_t a,uintptr_t b,uintptr_t c){seenError=GetLastError();args[0]=a;args[1]=b;args[2]=c;++calls;SetLastError(7654);return answer;}
int main(void){
 (void)firstBlockInstall;(void)firstBlockTick;(void)firstBlockStop;
 for(unsigned kind=0;kind<3;kind++){firstBlockOriginalQuery[kind]=query;firstBlockControl=(FirstBlockControl){.suppress=true,.pressed=true,.held=true,.released=true};firstBlockFrameScope=true;firstBlockFrameTick=GetTickCount64();calls=0;SetLastError(4321);uint32_t caller=kind==0?0x155715:kind==1?0x15576a:0x1189c0;uintptr_t r=firstBlockQueryForward(kind,11,69,donorMessageBase+caller);assert(calls==1&&args[0]==11&&args[1]==69&&seenError==4321&&GetLastError()==7654&&r==(answer&~(uintptr_t)255)+1&&firstBlockControl.queryCount[kind]==1);
  calls=0;SetLastError(4321);r=firstBlockQueryForward(kind,17,69,donorMessageBase+caller+1);assert(calls==1&&r==answer&&GetLastError()==7654);
 }
 assert(!firstBlockQueryCaller(0,73,0x155715)&&!firstBlockQueryCaller(2,69,0x156f82)&&firstBlockQueryCaller(2,73,0x156f82));
 assert(MH_Initialize()==MH_OK);PVOID original=NULL;assert(MH_CreateHook((PVOID)query,(PVOID)firstBlockPress,&original)==MH_OK);firstBlockOriginalQuery[0]=(FirstBlockQueryFn)original;assert(MH_EnableHook((PVOID)query)==MH_OK);firstBlockFrameScope=false;calls=0;SetLastError(4321);uintptr_t r=query(23,69);assert(calls==1&&args[0]==23&&args[1]==69&&seenError==4321&&r==answer&&GetLastError()==7654);assert(MH_DisableHook((PVOID)query)==MH_OK);
 assert(MH_CreateHook((PVOID)direction,(PVOID)firstBlockDirection,&original)==MH_OK);firstBlockOriginalDirection=(FirstBlockDirectionFn)original;assert(MH_EnableHook((PVOID)direction)==MH_OK);calls=0;SetLastError(4321);r=direction(31,32,33);assert(calls==1&&args[0]==31&&args[1]==32&&args[2]==33&&seenError==4321&&r==answer&&GetLastError()==7654);assert(MH_DisableHook((PVOID)direction)==MH_OK);
 FirstBlockMemory *a=NULL,*b=NULL;HANDLE map=CreateFileMappingW(INVALID_HANDLE_VALUE,NULL,PAGE_READWRITE,0,sizeof(FirstBlockMemory),NULL);assert(map);a=MapViewOfFile(map,FILE_MAP_READ|FILE_MAP_WRITE,0,0,sizeof(*a));b=MapViewOfFile(map,FILE_MAP_READ|FILE_MAP_WRITE,0,0,sizeof(*b));assert(a&&b&&a!=b);FirstBlockIntent c={.session=7,.sequence=8,.tick=9},out={0};assert(firstBlockWriteIntent(a,&c)&&firstBlockReadIntent(b,&out)&&!memcmp(&c,&out,sizeof(c)));FirstBlockAck ack={.sequence=8,.frames=10},copy={0};assert(firstBlockWriteAck(b,&ack)&&firstBlockReadAck(a,&copy)&&copy.frames==10);UnmapViewOfFile(a);UnmapViewOfFile(b);CloseHandle(map);
 HANDLE reader=NULL,writer=NULL;DWORD available=99;assert(CreatePipe(&reader,&writer,NULL,0));assert(PeekNamedPipe(reader,NULL,0,NULL,&available,NULL)&&!available);CloseHandle(writer);assert(!PeekNamedPipe(reader,NULL,0,NULL,&available,NULL)&&GetLastError()==ERROR_BROKEN_PIPE);CloseHandle(reader);
 puts("PASS production caller filters/counts, original-once/full-RAX/LastError/arguments, actual MinHook query+direction forwarding, two real pagefile views; no gameplay claim");return 0;
}
