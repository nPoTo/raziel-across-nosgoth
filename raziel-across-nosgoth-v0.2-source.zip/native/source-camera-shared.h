#ifndef SOURCE_CAMERA_SHARED_H
#define SOURCE_CAMERA_SHARED_H
#include "direct-motion-shared.h"
typedef struct {uint32_t magic,version,pid,reserved;uint64_t epoch,tick,instance;float actor[3],view[16],inverse[16];unsigned char hash[32];} SourceCameraSnapshot;
typedef struct {volatile LONG sequence;SourceCameraSnapshot snapshot;} SourceCameraShared;
static inline void sourceCameraName(wchar_t name[96],DWORD pid){_snwprintf(name,96,L"Local\\LOKDirectCamera-%lu",pid);}
static inline bool sourceCameraValid(const SourceCameraSnapshot *s,uint32_t pid,uint64_t now){
 if(!s||s->magic!=0x31435a52||s->version!=1||s->pid!=pid||!pid||s->reserved||!s->instance||!s->epoch||s->epoch>s->tick||s->tick>now||now-s->tick>150||s->tick-s->epoch>=138000||memcmp(s->hash,directMotionHash,32))return false;
 for(unsigned k=0;k<16;k++)if(!isfinite(s->view[k])||!isfinite(s->inverse[k])||fabsf(s->view[k])>1000000||fabsf(s->inverse[k])>1000000)return false;
 for(unsigned k=0;k<3;k++)if(!isfinite(s->actor[k])||fabsf(s->actor[k])>100000||fabsf(s->inverse[12+k]-s->actor[k])>10000)return false;
 for(unsigned k=0;k<4;k++)if(fabsf(s->view[k*4+3]-(k==3))>1e-5f||fabsf(s->inverse[k*4+3]-(k==3))>1e-5f)return false;
 for(unsigned order=0;order<2;order++)for(unsigned c=0;c<4;c++)for(unsigned r=0;r<4;r++){
  const float *a=order?s->inverse:s->view,*b=order?s->view:s->inverse;float v=0;
  for(unsigned k=0;k<4;k++)v+=a[k*4+r]*b[c*4+k];if(fabsf(v-(r==c))>.01f)return false;
 }
 // Measured source camera has no roll. Reject unverified roll/gimbal states.
 float sx=s->view[10];if(fabsf(sx)>=.99999f||fabsf(s->view[8])>.0001f)return false;
 float pitch=asinf(sx),yaw=atan2f(-s->view[2],s->view[6]);
 float cx=cosf(pitch),sz=sinf(yaw),cz=cosf(yaw);
 const float expected[9]={cz,sz,0,-sx*sz,sx*cz,-cx,-cx*sz,cx*cz,sx};
 for(unsigned r=0;r<3;r++)for(unsigned c=0;c<3;c++)if(fabsf(s->view[c*4+r]-expected[r*3+c])>.001f)return false;
 return true;
}
static inline bool sourceCameraCopy(const SourceCameraShared *shared,SourceCameraSnapshot *s){
 if(!shared||!s)return false;for(unsigned k=0;k<3;k++){LONG begin=shared->sequence;if(begin&1)continue;MemoryBarrier();memcpy(s,&shared->snapshot,sizeof(*s));MemoryBarrier();if(begin==shared->sequence)return true;}return false;
}
static inline void sourceCameraStore(SourceCameraShared *shared,const SourceCameraSnapshot *s){InterlockedIncrement(&shared->sequence);MemoryBarrier();memcpy(&shared->snapshot,s,sizeof(*s));MemoryBarrier();InterlockedIncrement(&shared->sequence);}
static inline float sourceCameraAngle(float radians){float v=fmodf(radians*(4096.0f/6.283185307179586f),4096);return v<0?v+4096:v;}
static inline bool sourceCameraHostPose(const SourceCameraSnapshot *s,uint32_t pid,uint64_t now,const float root[16],float cosine,float sine,float position[3],float rotation[3]){
 if(!sourceCameraValid(s,pid,now)||!isfinite(cosine)||!isfinite(sine)||fabsf(cosine*cosine+sine*sine-1)>.001f)return false;
 for(unsigned k=0;k<3;k++)if(!isfinite(root[12+k])||fabsf(root[12+k])>100000)return false;
 float x=s->inverse[12]-s->actor[0],y=s->inverse[13]-s->actor[1];
 position[0]=root[12]+cosine*x-sine*y;position[1]=root[13]+sine*x+cosine*y;position[2]=root[14]+s->inverse[14]-s->actor[2];
 rotation[0]=sourceCameraAngle(asinf(s->view[10]));rotation[1]=0;rotation[2]=sourceCameraAngle(atan2f(-s->view[2],s->view[6])+atan2f(sine,cosine));
 for(unsigned k=0;k<3;k++)if(!isfinite(position[k])||fabsf(position[k])>32760)return false;
 return true;
}
// Match the pose display's arrival-time interpolation, but blend only the
// camera offset and angles. The current host actor position never lags.
typedef struct {float from[6],target[6],display[6];uint32_t pid,duration;uint64_t epoch,instance,tick,start;bool ready;} SourceCameraBlend;
static inline float sourceCameraAngleDelta(float to,float from){float d=fmodf(to-from+2048,4096);if(d<0)d+=4096;return d-2048;}
static inline void sourceCameraBlendStep(SourceCameraBlend *b,uint64_t now){
 if(!b->ready||now<b->start)return;float alpha=b->duration?(float)(now-b->start)/b->duration:1;if(alpha>1)alpha=1;
 for(unsigned k=0;k<6;k++){float d=k<3?b->target[k]-b->from[k]:sourceCameraAngleDelta(b->target[k],b->from[k]);float v=b->from[k]+d*alpha;if(k>=3){v=fmodf(v,4096);if(v<0)v+=4096;}b->display[k]=v;}
}
static inline bool sourceCameraBlendPose(SourceCameraBlend *b,const SourceCameraSnapshot *s,uint32_t pid,uint64_t now,const float root[16],float cosine,float sine,float position[3],float rotation[3]){
 float next[6];if(!sourceCameraHostPose(s,pid,now,root,cosine,sine,next,next+3)){b->ready=false;return false;}
 for(unsigned k=0;k<3;k++)next[k]-=root[12+k];
 bool reset=!b->ready||b->pid!=pid||b->epoch!=s->epoch||b->instance!=s->instance||s->tick<b->tick||s->tick-b->tick>150;
 if(reset){memcpy(b->display,next,sizeof(next));memcpy(b->from,next,sizeof(next));memcpy(b->target,next,sizeof(next));b->duration=0;b->ready=true;b->start=now;}
 else if(s->tick>b->tick){sourceCameraBlendStep(b,now);memcpy(b->from,b->display,sizeof(next));memcpy(b->target,next,sizeof(next));uint64_t interval=s->tick-b->tick;b->duration=(uint32_t)(interval<16?16:interval>100?100:interval);b->start=now;}
 b->pid=pid;b->epoch=s->epoch;b->instance=s->instance;b->tick=s->tick;sourceCameraBlendStep(b,now);
 for(unsigned k=0;k<3;k++){position[k]=root[12+k]+b->display[k];rotation[k]=b->display[k+3];if(!isfinite(position[k])||fabsf(position[k])>32760){b->ready=false;return false;}}
 return true;
}
// User-requested host framing. Keep donor orientation, remove the lateral
// shoulder offset and 60% retreat, then double that framed actor distance.
// Reduce height above the actor by 15%, preserving horizontal distance and yaw centering.
static inline bool sourceCameraFrameActor(const float root[16],float position[3],const float rotation[3]){
 const float radians=6.283185307179586f/4096.0f;
 float pitch=rotation[0]*radians,yaw=rotation[2]*radians;
 float right[3]={cosf(yaw),sinf(yaw),0};
 float forward[3]={-cosf(pitch)*sinf(yaw),cosf(pitch)*cosf(yaw),sinf(pitch)};
 float offset[3],distance=0,lateral=0,next[3];
 for(unsigned k=0;k<3;k++){if(!isfinite(position[k])||!isfinite(root[12+k])||!isfinite(rotation[k]))return false;offset[k]=position[k]-root[12+k];distance+=offset[k]*offset[k];lateral+=offset[k]*right[k];}
 distance=sqrtf(distance);if(!isfinite(distance)||distance<1||distance>10000)return false;
 for(unsigned k=0;k<3;k++){next[k]=root[12+k]+2.0f*(offset[k]-lateral*right[k]-0.60f*distance*forward[k]);if(k==2&&next[k]>root[14])next[k]=root[14]+0.85f*(next[k]-root[14]);if(!isfinite(next[k])||fabsf(next[k])>32760)return false;}
 memcpy(position,next,sizeof(next));return true;
}
#endif
