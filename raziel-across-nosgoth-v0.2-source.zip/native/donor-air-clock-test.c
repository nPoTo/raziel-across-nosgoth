// SPDX-License-Identifier: GPL-3.0-or-later
#include <assert.h>
#include <stdio.h>
#include "host-contact-reader.h"
static uintptr_t donorProcessBase=0x100000,actor=0x200000;
static bool allowed=true;static unsigned mode=10;static int scalar=50;static uintptr_t attack=0x1319c0;
static bool donorProcessIdentity(uintptr_t a){return allowed&&a==actor;}
static bool worldRead(uintptr_t a,void *out,size_t n){
 uintptr_t value=0;
 if(a==donorProcessBase+0xc67120)value=0x300000;
 else if(a==donorProcessBase+0x113fff4&&n==4){memcpy(out,&mode,4);return true;}
 else if(a==0x3000c4&&n==4){memcpy(out,&scalar,4);return true;}
 else if(a==0x300470)value=0x400000;
 else if(a==actor+0x3f8)value=0x500000;
 else if(a==0x500000)value=actor;
 else {for(unsigned i=0;i<3;i++)if(a==0x500010+i*0x250&&n==16){uintptr_t pair[2]={donorProcessBase+attack,donorProcessBase+0x131a30};memcpy(out,pair,16);return true;}return false;}
 if(n!=8)return false;memcpy(out,&value,8);return true;
}
#include "donor-air-clock.h"
int main(void){
 HostContactLease lease={.pid=GetCurrentProcessId(),.creation=123,.epoch=GetTickCount64(),.actor=0x600000};
 assert(donorAirClockOpen(lease));AirClockPacket p;
 donorAirClockPublish(&lease,actor,true);assert(airClockCopy(donorAirClockView,&p)&&p.active==1&&p.scalar==50&&p.actor==lease.actor&&p.hostCreation==123);
 mode=3;donorAirClockPublish(&lease,actor,true);assert(airClockCopy(donorAirClockView,&p)&&!p.active);mode=10;
 attack=0x111a00;donorAirClockPublish(&lease,actor,true);assert(airClockCopy(donorAirClockView,&p)&&!p.active);attack=0x1319c0;
 scalar=4097;donorAirClockPublish(&lease,actor,true);assert(airClockCopy(donorAirClockView,&p)&&!p.active);scalar=50;
 allowed=false;donorAirClockPublish(&lease,actor,true);assert(airClockCopy(donorAirClockView,&p)&&!p.active);allowed=true;
 donorAirClockPublish(&lease,actor,false);assert(airClockCopy(donorAirClockView,&p)&&!p.active);
 donorAirClockPublish(&lease,actor,true);assert(airClockCopy(donorAirClockView,&p)&&p.active);donorAirClockRevoke();assert(!airClockCopy(donorAirClockView,&p));
 puts("PASS donor clock real RAM publication: exact air callbacks, identity, scalar, mode, scope and revocation");
}
