#include "report-path.h"
// First ground-only authority pilot: measured cumulative donor displacement.
// Native paired root controllers/collision path; render-only donor heading.
#include "direct-motion-shared.h"
#include "direct-motion-consumer.h"
static HANDLE directHostMapping;static const DirectMotionShared *directHostView;
static uint32_t directHostPid;static volatile LONG directHostReadLock,directHostEnabled,directHostBusy;
static DirectMotionCursor directHostCursor;static uintptr_t directHostPlayer;
static uint32_t directHostAlignmentPid;static uint64_t directHostAlignmentEpoch,directHostAlignmentInstance;
static uint64_t directHostBegin,directHostReadyTick;static float directHostCos=1,directHostSin;
static bool directHostRequested,directHostFailed,directHostHasSource;static unsigned directHostFrames,directHostGates[9];
static bool directHostReadFile(DirectMotionSnapshot *s){
 if(InterlockedCompareExchange(&directHostReadLock,1,0))return false;
 uint32_t pid=overlayLivePid;
 if(pid&&pid!=directHostPid){
  if(directHostView)UnmapViewOfFile(directHostView);if(directHostMapping)CloseHandle(directHostMapping);
  directHostView=NULL;directHostMapping=NULL;directHostPid=pid;
 }
 if(pid&&!directHostView){wchar_t name[96];directMotionName(name,pid);directHostMapping=OpenFileMappingW(FILE_MAP_READ,FALSE,name);
  if(directHostMapping)directHostView=MapViewOfFile(directHostMapping,FILE_MAP_READ,0,0,sizeof(DirectMotionShared));
  if(directHostMapping&&!directHostView){CloseHandle(directHostMapping);directHostMapping=NULL;}
 }
 bool ok=pid&&directMotionCopy(directHostView,s)&&directMotionValid(s,pid,GetTickCount64());InterlockedExchange(&directHostReadLock,0);return ok;
}
static bool (*directHostRead)(DirectMotionSnapshot *)=directHostReadFile;
static bool directHostScope(uintptr_t state,uint64_t now,float root[16],uintptr_t *player,DirectMotionSnapshot *s,unsigned *gate){
 uintptr_t actor=0,process=0;int32_t vz=0;DWORD foreground=0;
 *gate=1;if(!InterlockedCompareExchange(&directHostEnabled,0,0)||directHostFailed||now<directHostBegin||now-directHostBegin>=138000)return false;
 *gate=2;if(!worldRoot(root,player)||!worldRead(state,&actor,8)||actor!=*player)return false;
 *gate=3;if(!worldRead(state+0x10,&process,8)||!rootEligibleProcess(process))return false;
 *gate=4;if(!worldLastDraw||now<worldLastDraw||now-worldLastDraw>=250||*player!=worldLastInstance||root[10]<.8f)return false;
 *gate=5;if(!worldRead(*player+0x2d4,&vz,4)||vz)return false;
 *gate=6;GetWindowThreadProcessId(GetForegroundWindow(),&foreground);if(foreground!=GetCurrentProcessId())return false;
 *gate=7;if(!directHostRead(s)||fabsf(s->z-s->baseZ)>20||s->root[8]<.8f||!overlayLiveTick||now<overlayLiveTick||now-overlayLiveTick>250)return false;
 *gate=0;return true;
}
static void directHostRelease(uintptr_t state){if(!evadeRelease(state)){directHostFailed=true;directHostReadyTick=0;InterlockedExchange(&directHostEnabled,0);}}
static void directHostAfter(uintptr_t state,int32_t section){
 if(section||InterlockedCompareExchange(&directHostBusy,1,0))return;
 uint64_t now=GetTickCount64();float root[16];uintptr_t player=0;DirectMotionSnapshot snapshot;unsigned gate=0;
 if(!directHostScope(state,now,root,&player,&snapshot,&gate)){directHostReadyTick=0;memset(&directHostCursor,0,sizeof(directHostCursor));if(InterlockedCompareExchange(&directHostEnabled,0,0))++directHostGates[gate];InterlockedExchange(&directHostBusy,0);return;}
 directHostHasSource=true;
 // The consumption cursor can reset on a transient gate. World alignment
 // belongs to the actor/session identity and must survive those resets.
 bool newSource=directHostPlayer!=player||directHostAlignmentPid!=snapshot.pid||directHostAlignmentEpoch!=snapshot.epoch||directHostAlignmentInstance!=snapshot.instance;
 if(newSource){
  // Align worlds once, then source turns remain source turns. Never derive
  // movement direction from the host stick or camera after this baseline.
  float sx=snapshot.root[0],sy=snapshot.root[1],hx=root[0],hy=root[1],sn=hypotf(sx,sy),hn=hypotf(hx,hy);
  if(sn<.8f||hn<.8f){++directHostGates[8];InterlockedExchange(&directHostBusy,0);return;}
  directHostCos=(hx*sx+hy*sy)/(sn*hn);directHostSin=(hy*sx-hx*sy)/(sn*hn);directHostPlayer=player;
  directHostAlignmentPid=snapshot.pid;directHostAlignmentEpoch=snapshot.epoch;directHostAlignmentInstance=snapshot.instance;
 }
 double delta[2];unsigned result=directMotionDelta(&directHostCursor,&snapshot,overlayLivePid,now,delta);
 if(!result){++directHostGates[8];directHostReadyTick=0;InterlockedExchange(&directHostBusy,0);return;}
 float wx=(float)(delta[0]*directHostCos-delta[1]*directHostSin),wy=(float)(delta[0]*directHostSin+delta[1]*directHostCos);
 float step[2]={wx*root[0]+wy*root[1],wx*root[4]+wy*root[5]};
 if(fabsf(step[0])>240||fabsf(step[1])>240){++directHostGates[8];directHostReadyTick=0;InterlockedExchange(&directHostBusy,0);return;}
 uintptr_t process=0;worldRead(state+0x10,&process,8);
 if(process!=instantRootModule+0xf3280){rootCharacterSwitch(state,instantRootModule+0xf3280,0);worldRead(state+0x10,&process,8);}
 bool ok=process==instantRootModule+0xf3280&&evadeApply(state,player,step);
 if(ok){directHostReadyTick=now;++directHostFrames;}else{directHostFailed=true;directHostReadyTick=0;InterlockedExchange(&directHostEnabled,0);}
 if(directHostFrames<=8||directHostFrames%60==0||!ok)logLine("SR1_DIRECT_HOST tick=%llu source=%llu samples=%u result=%u local=%.9g,%.9g world=%.9g,%.9g ok=%u frames=%u; cumulative source, no XYZ writes",now,snapshot.tick,snapshot.samples,result,step[0],step[1],wx,wy,ok,directHostFrames);
 InterlockedExchange(&directHostBusy,0);
}
static bool directHostInputScope(ULONGLONG now,uintptr_t caller,DWORD foreground){
 if(!InterlockedCompareExchange(&directHostEnabled,0,0)||directHostFailed||!directHostHasSource||now<directHostBegin||now-directHostBegin>=138000||foreground!=GetCurrentProcessId()||(caller!=srInputMainBase+0x5bc9&&caller!=srInputMainBase+0x5047))return false;
 // Authority persists between source snapshots; a missed movement frame must
 // never route the same physical LB/stick back into native map/steering.
 float root[16];uintptr_t player=0;return worldRoot(root,&player)&&player==directHostPlayer&&worldLastDraw&&now>=worldLastDraw&&now-worldLastDraw<250;
}
static void directHostModel(float model[16],uintptr_t instance){
 if(instance!=directHostPlayer||!directHostReadyTick||GetTickCount64()<directHostReadyTick||GetTickCount64()-directHostReadyTick>100||!directHostInputScope(GetTickCount64(),srInputMainBase+0x5bc9,GetCurrentProcessId()))return;
 DirectMotionSnapshot s;if(!directHostRead(&s))return;
 for(unsigned c=0;c<3;c++){float x=s.root[c*3],y=s.root[c*3+1];model[c*4]=directHostCos*x-directHostSin*y;model[c*4+1]=directHostSin*x+directHostCos*y;model[c*4+2]=s.root[c*3+2];}
}
static void directHostAfterDispatch(uintptr_t state,int32_t section){if(InterlockedCompareExchange(&directHostEnabled,0,0))directHostAfter(state,section);else evadeAfterState(state,section);}
static void directHostInstall(void){if(!instantRootModule||!evadeModule)return;rootOtherAfter=directHostAfterDispatch;rootOtherRelease=directHostRelease;rootOtherOwnsControllers=evadeOwnsControllers;srAuthorityInputScope=directHostInputScope;worldAuthorityModel=directHostModel;}
static void directHostTick(void){
 bool requested=rootStateTargets[0]&&rootStateTargets[1]&&GetFileAttributesW(PROBE_PATH(L"\\direct-host-sr1.enable"))!=INVALID_FILE_ATTRIBUTES&&GetFileAttributesW(PROBE_PATH(L"\\replace-sr1.enable"))!=INVALID_FILE_ATTRIBUTES;
 if(requested!=directHostRequested){directHostRequested=requested;directHostBegin=requested?GetTickCount64():0;directHostReadyTick=0;directHostHasSource=false;memset(&directHostCursor,0,sizeof(directHostCursor));directHostAlignmentPid=0;directHostAlignmentEpoch=directHostAlignmentInstance=0;
  if(requested){directHostFailed=false;directHostFrames=0;memset(directHostGates,0,sizeof(directHostGates));}InterlockedExchange(&directHostEnabled,requested);
  logLine("SR1_DIRECT_HOST enabled=%u frames=%u failed=%u gates=%u,%u,%u,%u,%u,%u,%u,%u,%u; first ground authority pilot",requested,directHostFrames,directHostFailed,directHostGates[0],directHostGates[1],directHostGates[2],directHostGates[3],directHostGates[4],directHostGates[5],directHostGates[6],directHostGates[7],directHostGates[8]);}
}
static void directHostStop(void){InterlockedExchange(&directHostEnabled,0);directHostReadyTick=0;directHostHasSource=false;}
