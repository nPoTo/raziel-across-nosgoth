// SPDX-License-Identifier: GPL-3.0-or-later
#pragma once
#include <stdlib.h>
#include "reaver-texture-generation.h"
#include "reaver-presentation-lease.h"
// Caller supplies its admitted current-host-hand MVP. This isolated consumer
// performs no camera lookup, hook, IPC wait, body rendering or engine write.
static bool reaverPresentationDraw(ReaverPresentationLease *lease,ReaverTextureGeneration *bank,uint64_t now,const float mvp[16]){
 if(!lease||!bank||!mvp||!reaverPresentationCurrent(lease,now))return false;
 ReaverPacketView view;if(!reaverPacketValidate(lease->bytes,lease->size,&lease->session,now,lease->highest,&view)||!view.visible)return false;
 if(bank->generation!=lease->session.textureGeneration||bank->gl.context!=wglGetCurrentContext()||!bank->gl.program)return false;
 for(unsigned i=0;i<16;i++)if(!isfinite(mvp[i]))return false;
 const unsigned char *vertices=lease->bytes+128,*indices=vertices+view.vertices*36,*batches=indices+view.indices*2;
 // Validate the WHOLE set before drawing its first triangle. Missing images
 // must not leave a partially rendered weapon.
 for(unsigned i=0;i<view.batches;i++){
  unsigned slot=reaverPacketU32(batches+i*32+8);
  if(!reaverTexturesMatch(bank,lease->session.textureGeneration,slot,bank->sourceIds[slot]))return false;
 }
 // Byte packet storage is not a C vertex array: copy to aligned typed storage.
 ReaverGLVertex *v=malloc(view.vertices*sizeof(*v));uint16_t *ix=malloc(view.indices*sizeof(*ix));
 if(!v||!ix){free(v);free(ix);return false;}
 _Static_assert(sizeof(ReaverGLVertex)==36,"vertex packet layout");
 memcpy(v,vertices,view.vertices*36);memcpy(ix,indices,view.indices*2);bool ok=true;
 for(unsigned i=0;i<view.batches;i++){
  const unsigned char *b=batches+i*32;
  if(!reaverGLDraw(&bank->gl,v,view.vertices,ix+reaverPacketU32(b),reaverPacketU32(b+4),reaverPacketU32(b+8),reaverPacketU32(b+12),mvp,reaverPacketFloat(b+16),reaverPacketFloat(b+20))){ok=false;break;}
 }
 free(v);free(ix);return ok;
}
