// Read-only candidate FX list. Native cleanup code at RVA54c50 traverses next
// at +0 and effect type at +24, freeing a pool at +48 for type0. Other fields
// remain candidates until the factory/continuation ABI has been validated.
static bool fxListGate(HANDLE process,uintptr_t base) {
    const unsigned char expected[]={0x40,0x53,0x48,0x83,0xec,0x20,0x48,0x8b,0x1d,0x73,0x80,0x26,0x00,0x48,0x85,0xdb};
    unsigned char actual[sizeof(expected)];return readAt(process,base+0x54c50,actual,sizeof(actual))&&!memcmp(actual,expected,sizeof(actual));
}
static void fxListObserve(FILE *out,HANDLE process,uintptr_t base,uintptr_t player,DWORD imageSize) {
    uintptr_t head=0,after=0,seen[32]={0};unsigned int count=0;bool cycle=false,truncated=false,readable=readAt(process,base+0x2bccd0,&head,8);
    fprintf(out,"{\"head\":\"0x%llx\",\"readable\":%s,\"nodes\":[",(unsigned long long)head,readable?"true":"false");
    uintptr_t cursor=head;
    while(readable&&cursor&&count<32) {
        for(unsigned int i=0;i<count;++i)if(seen[i]==cursor)cycle=true;
        if(cycle)break;
        unsigned char raw[96];if(cursor<65536||cursor%8||!readAt(process,cursor,raw,sizeof(raw))){readable=false;break;}
        seen[count]=cursor;uintptr_t next=pointer(raw),callback=pointer(raw+8),owner=pointer(raw+16),object=0,name=0;unsigned char ownerName[8]={0};
        bool ownerReadable=readAt(process,owner+0x30,&object,8)&&readAt(process,object+0x30,&name,8)&&readAt(process,name,ownerName,8);
        MEMORY_BASIC_INFORMATION info={0};bool callbackExecutable=VirtualQueryEx(process,(LPCVOID)callback,&info,sizeof(info))==sizeof(info)&&info.State==MEM_COMMIT&&info.Type==MEM_IMAGE&&
            ((info.Protect&0xff)==PAGE_EXECUTE||(info.Protect&0xff)==PAGE_EXECUTE_READ||(info.Protect&0xff)==PAGE_EXECUTE_READWRITE||(info.Protect&0xff)==PAGE_EXECUTE_WRITECOPY);
        bool callbackInModule=callback>=base&&callback-base<imageSize;
        if(count)fputc(',',out);
        fprintf(out,"{\"node\":\"0x%llx\",\"next\":\"0x%llx\",\"callback\":\"0x%llx\",\"callbackRva\":\"0x%llx\",\"callbackExecutable\":%s,\"callbackInModule\":%s,\"ownerCandidate\":\"0x%llx\",\"playerMatch\":%s,\"ownerReadable\":%s,\"ownerNameHex\":\"",
            (unsigned long long)cursor,(unsigned long long)next,(unsigned long long)callback,(unsigned long long)(callbackInModule?callback-base:0),callbackExecutable?"true":"false",callbackInModule?"true":"false",(unsigned long long)owner,owner==player?"true":"false",ownerReadable?"true":"false");
        for(int i=0;i<8;++i)fprintf(out,"%02x",ownerName[i]);
        fprintf(out,"\",\"effectTypeByte\":%u,\"typeByteCandidate\":%u,\"lifeTimeCandidate\":%d,\"prefixHex\":\"",raw[24],raw[25],shortAt(raw+26));
        for(size_t i=0;i<sizeof(raw);++i)fprintf(out,"%02x",raw[i]);
        unsigned char pool[32]={0};uintptr_t poolAddress=pointer(raw+48);bool ownedCandidate=owner==player||(ownerReadable&&!memcmp(ownerName,"sreavr__",8));
        bool poolReadable=raw[24]==0&&ownedCandidate&&poolAddress>=65536&&readAt(process,poolAddress,pool,sizeof(pool));
        fprintf(out,"\",\"poolAt48\":\"0x%llx\",\"poolReadable\":%s,\"poolHex\":\"",(unsigned long long)poolAddress,poolReadable?"true":"false");
        if(poolReadable)for(size_t i=0;i<sizeof(pool);++i)fprintf(out,"%02x",pool[i]);
        fprintf(out,"\"}");++count;cursor=next;
    }
    truncated=cursor&&!cycle&&readable&&count==32;
    bool headStable=readAt(process,base+0x2bccd0,&after,8)&&after==head;
    fprintf(out,"],\"headStable\":%s,\"complete\":%s,\"cycle\":%s,\"truncated\":%s}",headStable?"true":"false",readable&&!cursor?"true":"false",cycle?"true":"false",truncated?"true":"false");
}
