// SPDX-License-Identifier: GPL-3.0-or-later
#include "host-contact-frame.h"
#include <assert.h>
#include <stdio.h>
int main(void){
 HostContactFrame f;uintptr_t cb[3]={0xf2ae0,0xf2ae0,0xf2ae0};
 hostContactBegin(&f,0x1000,1);
 hostContactQuery(&f,0x1000,1,true,true,0x519,0x519,1);
 assert(hostContactFinish(&f,0x1000,10,true,0x519,cb).contact==HOST_CONTACT_GROUND);
 // New takeoff cannot inherit previous grounded query. VZ is intentionally not an input.
 hostContactBegin(&f,0x1000,2);
 assert(hostContactFinish(&f,0x1000,11,true,0x511,cb).contact==HOST_CONTACT_AIR);
 assert(hostContactFinish(&f,0x1000,11,true,0x515,cb).contact==HOST_CONTACT_AIR);
 assert(hostContactFinish(&f,0x1000,11,true,0x514,cb).contact==HOST_CONTACT_UNKNOWN);
 assert(hostContactFinish(&f,0x1000,11,true,0x519,cb).contact==HOST_CONTACT_UNKNOWN);
 cb[1]=0xefb50;
 assert(hostContactFinish(&f,0x1000,11,true,0x511,cb).contact==HOST_CONTACT_UNKNOWN);
 cb[1]=0xf2ae0;
 assert(hostContactFinish(&f,0x1000,11,false,0x511,cb).contact==HOST_CONTACT_UNKNOWN);
 assert(hostContactFinish(&f,0x2000,11,true,0x511,cb).contact==HOST_CONTACT_UNKNOWN);
 for(unsigned result=0;result<256;result++){
  hostContactBegin(&f,0x1000,3);hostContactQuery(&f,0x1000,1,true,true,0x519,0x519,result);
  assert(hostContactFinish(&f,0x1000,12,true,0x519,cb).contact==((result&1)?HOST_CONTACT_GROUND:HOST_CONTACT_AIR));
  assert(hostContactFinish(&f,0x1000,12,true,0x511,cb).contact==HOST_CONTACT_UNKNOWN);
  assert(hostContactFinish(&f,0x1000,12,true,0x4000519,cb).contact==HOST_CONTACT_UNKNOWN);
  hostContactQuery(&f,0x1000,1,true,true,0x519,0x519,result);
  assert(hostContactFinish(&f,0x1000,12,true,0x519,cb).contact==HOST_CONTACT_UNKNOWN);
 }
 for(unsigned fault=0;fault<4;fault++){
  hostContactBegin(&f,0x1000,4);
  hostContactQuery(&f,fault==0?0x2000:0x1000,fault==1?2:1,fault!=2,fault!=3,0x519,0x519,1);
  assert(hostContactFinish(&f,0x1000,13,true,0x519,cb).contact==HOST_CONTACT_UNKNOWN);
 }
 puts("PASS completed host frame: no stale ground, exact jump bridge, no velocity inference, nested/foreign/duplicate/control rejection");
}
