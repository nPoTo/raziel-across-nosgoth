#include <assert.h>
#include <stdio.h>
#include "lift-vertical-launch.h"
int main(void){
 LiftVerticalLaunch s={42,100,90};
 assert(!liftVerticalConsume(&s,101,43,90,true,0xede81,-16,0,83,154));
 assert(!liftVerticalConsume(&s,101,42,90,true,0xeddb0,-16,0,40,154));
 assert(!liftVerticalConsume(&s,101,42,90,true,0xede81,-16,0,83,155));
 assert(liftVerticalConsume(&s,101,42,90,true,0xede81,-16,0,83,154));
 assert(!liftVerticalConsume(&s,102,42,90,true,0xede81,-16,0,83,154));
 for(int i=0;i<4;i++){s=(LiftVerticalLaunch){42,100,90};assert(!liftVerticalConsume(&s,i==0?99:i==1?451:101,42,i==2?91:90,i!=3,0xede81,-16,0,83,154));assert(!s.actor);}
 puts("PASS lift vertical launch: exact running-jump caller/arguments, actor/session/expiry, once only, ordinary launches unchanged");
}
