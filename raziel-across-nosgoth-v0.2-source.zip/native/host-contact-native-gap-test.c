// SPDX-License-Identifier: GPL-3.0-or-later
#include "host-contact-shared.h"
#include <assert.h>
static HostContactLease lease(void){return (HostContactLease){.pid=1,.creation=2,.epoch=1000,.actor=3};}
int main(void){
 HostContactSnapshot s={.magic=HOST_CONTACT_MAGIC,.version=HOST_CONTACT_VERSION,.pid=1,.creation=2,.epoch=1000,.actor=3,.tick=1000,.sequence=1,.phase=4,.control=0x8001,.coherent=1,.callbacks={0xecf70,0xecf70,0xecf70}};
 bool f;HostContactLease l=lease();
 assert(!hostContactAccept(&l,&s,1151,true,&f)); // No stale initial admission.
 l=lease();assert(hostContactAccept(&l,&s,1000,true,&f));
 assert(hostContactAccept(&l,&s,1250,true,&f)&&!f&&l.last.phase==4);
 assert(!hostContactAccept(&l,&s,1251,true,&f)&&l.revoked);
 for(unsigned fault=0;fault<5;fault++){
  l=lease();assert(hostContactAccept(&l,&s,1000,true,&f));HostContactSnapshot b=s;
  if(fault==0)b.actor++;if(fault==1)b.callbacks[1]=0xdead;
  if(fault==2){b.phase=1;b.control|=8;}if(fault==3)b.coherent=0;
  assert(!hostContactAccept(&l,&b,1187,fault!=4,&f));
 }
 l=lease();assert(hostContactAccept(&l,&s,1000,true,&f));
 s.tick=1187;s.sequence++;s.phase=2;s.control=8;s.callbacks[0]=s.callbacks[1]=s.callbacks[2]=0xef480;
 assert(hostContactAccept(&l,&s,1187,true,&f)&&f&&l.last.phase==2);
 assert(!hostContactAccept(&l,&s,1338,true,&f)); // Ordinary150ms unchanged.
 puts("PASS bounded native-only gap; expiry, stale admission, foreign/dead/unknown rejected; fresh air resumes");
}
