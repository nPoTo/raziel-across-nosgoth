// SPDX-License-Identifier: GPL-3.0-or-later
// Read-only external helper. Resource fields travel through an anonymous RAM
// pipe to the parent; no output-file argument, injection, hook or write access.
#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <tlhelp32.h>
#include <bcrypt.h>
#include <stdio.h>
#include <stdlib.h>
#include <wchar.h>
#include "host-rig-reader.h"
#include "reader-hash.h"
static bool readAt(void *c,uintptr_t p,void *out,SIZE_T n){SIZE_T got=0;return p&&ReadProcessMemory((HANDLE)c,(LPCVOID)p,out,n,&got)&&got==n;}
int wmain(int argc,wchar_t **argv){
 if(argc!=2||GetFileType(GetStdHandle(STD_OUTPUT_HANDLE))!=FILE_TYPE_PIPE)return 1;
 wchar_t *end=NULL;unsigned long pid=wcstoul(argv[1],&end,10);if(!pid||*end||pid>UINT32_MAX)return 1;
 HANDLE process=OpenProcess(PROCESS_VM_READ|PROCESS_QUERY_LIMITED_INFORMATION,FALSE,(DWORD)pid);if(!process)return 2;
 wchar_t file[32768];DWORD n=ARRAYSIZE(file);char digest[65];int result=3;
 if(!QueryFullProcessImageNameW(process,0,file,&n)||!wcsrchr(file,L'\\')||_wcsicmp(wcsrchr(file,L'\\')+1,L"SRX.exe")||!hashFile(file,digest)||strcmp(digest,"0fb3aef0530ebf0510191f934dc371b69b43574331d3623eda694b72f060db93"))goto done;
 HANDLE snap=CreateToolhelp32Snapshot(TH32CS_SNAPMODULE|TH32CS_SNAPMODULE32,(DWORD)pid);if(snap==INVALID_HANDLE_VALUE)goto done;
 MODULEENTRY32W me={.dwSize=sizeof(me)};uintptr_t base=0;
 if(Module32FirstW(snap,&me))do{if(!_wcsicmp(me.szModule,L"sr1.dll")&&hashFile(me.szExePath,digest)&&!strcmp(digest,"c006dea45509cdc3fbfab3a4230b47869c306ecdd7df8b4fd2499fd3654a2205")){base=(uintptr_t)me.modBaseAddr;break;}}while(Module32NextW(snap,&me));CloseHandle(snap);if(!base)goto done;
 unsigned valid=0;FILETIME creation,exit,kernel,user;if(!GetProcessTimes(process,&creation,&exit,&kernel,&user))goto done;
 printf("{\"type\":\"session\",\"pid\":%lu,\"creation\":\"%llu\",\"moduleSha256\":\"%s\",\"samples\":%d}\n",pid,((unsigned long long)creation.dwHighDateTime<<32)|creation.dwLowDateTime,digest,(int)sheet_rigRead_current.maxSamples);fflush(stdout);
 uintptr_t previousActor=0,previousModel=0;unsigned epoch=0;
 for(int sample=0;sample<sheet_rigRead_current.maxSamples;sample++){
  HostRig s;bool ok=hostRigRead(process,readAt,base,&s);
  if(ok){valid++;if(s.actor!=previousActor||s.model!=previousModel){epoch++;previousActor=s.actor;previousModel=s.model;}}
  printf("{\"type\":\"sample\",\"sequence\":%d,\"tick\":%llu,\"valid\":%s,\"epoch\":%u,\"reason\":%u,\"modelIndex\":%d,\"count\":%d",sample,(unsigned long long)GetTickCount64(),ok?"true":"false",epoch,rigReadFailure,rigReadModelIndex,rigReadCount);
  if(ok){printf(",\"resourceAlignmentRemainders\":[%u,%u,%u],\"parents\":[",(unsigned)(s.list%8),(unsigned)(s.model%8),(unsigned)(s.segments%8));for(int i=0;i<s.count;i++)printf("%s%d",i?",":"",s.parents[i]);printf("],\"render\":[");for(int i=0;i<s.count;i++){printf("%s[",i?",":"");for(int k=0;k<13;k++){float v;memcpy(&v,s.renderBytes[i]+k*4,4);printf("%s%.9g",k?",":"",v);}putchar(']');}putchar(']');}puts("}");fflush(stdout);Sleep((DWORD)sheet_rigRead_current.intervalMs);
 }
 printf("{\"type\":\"complete\",\"valid\":%u,\"samples\":%d}\n",valid,(int)sheet_rigRead_current.maxSamples);fflush(stdout);result=valid?0:4;
done:CloseHandle(process);return result;
}
