// SPDX-License-Identifier: GPL-3.0-or-later
#include <stdio.h>
#include <stdlib.h>
#include "donor-reaver-reader.h"
#include "donor-reaver-effects.h"
#define CHECK(x) do{if(!(x)){fprintf(stderr,"FAIL line%d\n",__LINE__);return 1;}}while(0)
static unsigned char memory[0x1800000];static unsigned hits;static bool change,deny;
static bool readFake(void *c,uintptr_t at,void *out,SIZE_T n){(void)c;if(deny||at<0x100000||at-0x100000>sizeof(memory)||n>sizeof(memory)-(at-0x100000))return false;memcpy(out,memory+at-0x100000,n);if(change&&at==0x100000+0xc67120&&++hits==2){uintptr_t different=0x103008;memcpy(out,&different,8);}return true;}
static void ptr(uintptr_t at,uintptr_t v){memcpy(memory+at,&v,8);}
int main(void){
 const uintptr_t base=0x100000,actor=base+0x1000,model=base+0x2000,context=base+0x3000,weapon=base+0x5000,object=base+0x6000,state=base+0x7000,name=base+0x8000;
 ptr(0xc5aa78,actor);ptr(0x1088,model);ptr(0xc67120,context);ptr(0x33f8,weapon);ptr(0x5088,object);ptr(0x6050,name);ptr(0x53f8,state);memcpy(memory+0x8000,"sreaver",8);
 ptr(0x1310,base+0x9000);uint32_t hand=40;memcpy(memory+0x9254,&hand,4);
 ptr(0x50b8,actor);int16_t bone=40;memcpy(memory+0x50c0,&bone,2);
 memory[0x7006]=1;memory[0x7007]=0;
 ReaverObservation r=reaverObserve(NULL,readFake,base,sizeof(memory),model);CHECK(r.valid&&r.present&&r.nameMatches&&r.snapshot.configuredHand==40&&r.snapshot.drawState==1&&r.snapshot.coilState==0);
 CHECK(r.snapshot.attachedParent==actor&&r.snapshot.attachedBone==40);
 CHECK(!reaverObserve(NULL,readFake,base,sizeof(memory),model+8).valid);
 memory[0x8000]='x';CHECK(!reaverObserve(NULL,readFake,base,sizeof(memory),model).valid);memory[0x8000]='s';
 change=true;CHECK(!reaverObserve(NULL,readFake,base,sizeof(memory),model).valid);change=false;deny=true;CHECK(!reaverObserve(NULL,readFake,base,sizeof(memory),model).valid);deny=false;
 float nanValue=NAN;memcpy(memory+0x7024,&nanValue,4);CHECK(!reaverObserve(NULL,readFake,base,sizeof(memory),model).valid);memset(memory+0x7024,0,4);
 memcpy(memory+0x5428,&nanValue,4);CHECK(!reaverObserve(NULL,readFake,base,sizeof(memory),model).valid);memset(memory+0x5428,0,4);
 ptr(0x1310,0);CHECK(!reaverObserve(NULL,readFake,base,sizeof(memory),model).valid);ptr(0x1310,base+0x9000);
 ptr(0x33f8,0);r=reaverObserve(NULL,readFake,base,sizeof(memory),model);CHECK(r.valid&&!r.present);
 CHECK(!reaverObserve(NULL,readFake,UINTPTR_MAX-2,sizeof(memory),model).valid);
 // Effect census distinguishes actor/weapon ownership, and rejects loops or bad callbacks.
 ptr(0x10aa630,base+0xa000);ptr(0xa000,base+0xa100);ptr(0xa008,base+0x49910);ptr(0xa010,weapon);memory[0xa018]=0x84;
 ptr(0xa108,base+0x1234);ptr(0xa110,actor);memory[0xa118]=2;
 ReaverEffects fx=reaverEffects(NULL,readFake,base,sizeof(memory),actor,weapon);CHECK(fx.valid&&fx.visited==2&&fx.owned==2&&fx.items[0].weaponOwner&&fx.items[0].type==0x84&&!fx.items[1].weaponOwner);
 ptr(0xa100,base+0xa000);CHECK(!reaverEffects(NULL,readFake,base,sizeof(memory),actor,weapon).valid);ptr(0xa100,0);
 ptr(0xa008,base-1);CHECK(!reaverEffects(NULL,readFake,base,sizeof(memory),actor,weapon).valid);ptr(0xa008,base+0x49910);
 deny=true;CHECK(!reaverEffects(NULL,readFake,base,sizeof(memory),actor,weapon).valid);deny=false;
 ptr(0x10aa630,0);fx=reaverEffects(NULL,readFake,base,sizeof(memory),actor,weapon);CHECK(fx.valid&&fx.owned==0&&fx.visited==0);
 puts("PASS Reaver candidate reader: exact-name/model, torn roots, absent weapon, unreadable/nonfinite, overflow. No live semantic proof.");return 0;
}
