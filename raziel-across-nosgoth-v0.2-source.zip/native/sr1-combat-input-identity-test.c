// SPDX-License-Identifier: GPL-3.0-or-later
#include "sr1-combat-input-identity.h"
#include "sr1-actor-position-read.h"
#include "sr1-free-attack-owner.h"
#include <assert.h>
#include <stdio.h>
static unsigned actorReads,positionReads;static bool changed,positionChanged;
static bool readIdentity(void *ctx,uintptr_t at,void *out,size_t size){
 (void)ctx;uintptr_t v=0;
 if(at==0x100000+0x2a89310){actorReads++;v=changed&&actorReads>1?0x9000:0x2000;}
 else if(at==0x2030)v=0x3000;else if(at==0x3030)v=0x4000;
 else if(at==0x4000&&size==9){memcpy(out,"raziel__",9);return true;}
 else if(at==0x21c6&&size==2){int16_t m=0;memcpy(out,&m,2);return true;}
 else if(at==0x209c&&size==6){int16_t p[3]={12,-34,56};positionReads++;if(positionChanged&&positionReads>1)p[0]++;memcpy(out,p,6);return true;}
 else return false; // No matrices, render receipt or additional input poll exists.
 if(size!=8)return false;memcpy(out,&v,8);return true;
}
int main(void){uintptr_t a=0,o=0;assert(srCombatInputIdentity(NULL,readIdentity,0x100000,&a,&o));assert(a==0x2000&&o==0x3000);
 SrFreeAttackOwner owner={0};srFreeAttackStep(&owner,1,a,true,true,0,0,0x4000);
 assert(srFreeAttackStep(&owner,2,a,true,true,0x4000,0x4000,0x4000)==0);
 actorReads=0;changed=true;assert(!srCombatInputIdentity(NULL,readIdentity,0x100000,&a,&o));
 changed=false;actorReads=0;int16_t pos[3];assert(srActorPositionRead(NULL,readIdentity,0x100000,0x2000,0x3000,pos)&&pos[0]==12&&pos[1]==-34&&pos[2]==56);
 positionReads=0;positionChanged=true;assert(!srActorPositionRead(NULL,readIdentity,0x100000,0x2000,0x3000,pos));
 puts("PASS stable original player identity independent of rotating matrices; actor change rejected; owned X consumed.");return 0;}
