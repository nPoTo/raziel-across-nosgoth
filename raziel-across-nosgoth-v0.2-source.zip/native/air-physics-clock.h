#include "general-test-budget.h"
// SPDX-License-Identifier: GPL-3.0-or-later
#pragma once
#include <stdint.h>
#include <stdbool.h>
#include <string.h>
// Pure argument calculation. No game memory or legacy overlay dependencies.
typedef struct {uint64_t epoch,begin,lastNow;uint32_t remainder;bool active,exhausted;} AirPhysicsClock;
typedef struct {
 bool enabled,identity,hostAir,donorAttack,nativeAction;
 uint64_t epoch,now,sourceTick;
 int32_t scalar,time,segment,clamp;
} AirPhysicsClockInput;
static inline int32_t airPhysicsClockStep(AirPhysicsClock *c,const AirPhysicsClockInput *s){
 if(!c||!s)return s?s->time:0;
 bool valid=s->enabled&&s->identity&&s->hostAir&&s->donorAttack&&!s->nativeAction&&s->epoch&&
  s->epoch<=s->now&&s->now-s->epoch<GENERAL_OR_SHORT_MS(50000)&&s->sourceTick>=s->epoch&&s->sourceTick<=s->now&&
  s->now-s->sourceTick<=100&&s->scalar>0&&s->scalar<=4096&&s->time>0&&s->time<=8192&&s->segment==0&&s->clamp==0;
 if(c->epoch&&c->epoch!=s->epoch)valid=false;
 if(c->lastNow&&s->now<c->lastNow)valid=false;
 if(!valid){c->active=false;c->remainder=0;return s->time;}
 if(!c->epoch)c->epoch=s->epoch;
 c->lastNow=s->now;
 // Exhaustion is latched for the session, not reset by a single missing packet.
 if(c->exhausted)return s->time;
 if(!c->active){c->active=true;c->begin=s->now;c->remainder=0;}
 if(s->now-c->begin>=3000){c->exhausted=true;c->active=false;c->remainder=0;return s->time;}
 uint64_t numerator=(uint64_t)s->time*(uint32_t)s->scalar+c->remainder;
 uint32_t next=(uint32_t)(numerator/4096);c->remainder=(uint32_t)(numerator%4096);
 // Native zero-time semantics are not proved; never submit zero.
 if(!next){next=1;c->remainder=0;}
 return (int32_t)next;
}
