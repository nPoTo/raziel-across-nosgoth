// SPDX-License-Identifier: GPL-3.0-or-later
#include <stdio.h>
#include <stdlib.h>
#include <fcntl.h>
#include <io.h>
#include "exploration-sheets.h"
#include "reaver-presentation-packet.h"
#include "reaver-presentation-lease.h"
#include "reaver-presentation-memory.h"
#include "reaver-texture-memory.h"
#include <assert.h>
static void writerTests(const unsigned char *original,size_t n,const char *exe){
 SECURITY_ATTRIBUTES sa={sizeof(sa),NULL,TRUE};HANDLE inputRead=NULL,inputWrite=NULL,outputRead=NULL,outputWrite=NULL;
 assert(CreatePipe(&inputRead,&inputWrite,&sa,0)&&CreatePipe(&outputRead,&outputWrite,&sa,0));
 assert(SetHandleInformation(inputWrite,HANDLE_FLAG_INHERIT,0)&&SetHandleInformation(outputRead,HANDLE_FLAG_INHERIT,0));
 FILETIME born,exit,kernel,user;assert(GetProcessTimes(GetCurrentProcess(),&born,&exit,&kernel,&user));
 uint64_t creation=((uint64_t)born.dwHighDateTime<<32)|born.dwLowDateTime;uint32_t pid=GetCurrentProcessId();
 char command[2048];snprintf(command,sizeof(command),"\"%s\" %lu %llu %lu %llu 400 500 600 700",exe,(unsigned long)pid,(unsigned long long)creation,(unsigned long)pid,(unsigned long long)creation);
 STARTUPINFOA si={0};si.cb=sizeof(si);si.dwFlags=STARTF_USESTDHANDLES;si.hStdInput=inputRead;si.hStdOutput=outputWrite;si.hStdError=outputWrite;PROCESS_INFORMATION pi={0};
 assert(CreateProcessA(NULL,command,NULL,NULL,TRUE,CREATE_NO_WINDOW,NULL,NULL,&si,&pi));CloseHandle(inputRead);CloseHandle(outputWrite);
 char line[256]={0};DWORD got;unsigned at=0;uint64_t deadline=GetTickCount64()+3000;
 while(at<sizeof(line)-1&&GetTickCount64()<deadline){DWORD available=0;assert(PeekNamedPipe(outputRead,NULL,0,NULL,&available,NULL));if(!available){Sleep(1);continue;}assert(ReadFile(outputRead,line+at,1,&got,NULL)&&got==1);if(line[at++]=='\n')break;}
 unsigned long writerPid=0;unsigned long long writerCreation=0;
 assert(sscanf(line,"{\"writerPid\":%lu,\"writerCreation\":\"%llu\"}",&writerPid,&writerCreation)==2&&writerPid==pi.dwProcessId);
 ReaverPresentationLease *l=calloc(1,sizeof(*l));unsigned char *packet=malloc(REAVER_PRESENTATION_CAPACITY),*scratch=malloc(REAVER_PRESENTATION_CAPACITY);assert(l&&packet&&scratch);
 l->session=(ReaverPacketSession){pid,(uint32_t)writerPid,pid,creation,writerCreation,creation,400,500,600,700};memcpy(packet,original,n);
 uint32_t wp=(uint32_t)writerPid;uint64_t wc=writerCreation,tick=GetTickCount64();
 memcpy(packet+16,&pid,4);memcpy(packet+20,&wp,4);memcpy(packet+24,&pid,4);memcpy(packet+32,&creation,8);memcpy(packet+40,&wc,8);memcpy(packet+48,&creation,8);memcpy(packet+64,&tick,8);
 unsigned char texture[164]={0};memcpy(texture,packet,104);uint32_t magic=0x31545752,total=164,zero=0,one=1,four=4;memcpy(texture,&magic,4);memcpy(texture+8,&total,4);memcpy(texture+12,&zero,4);memcpy(texture+104,&one,4);memcpy(texture+108,&four,4);
 uint32_t descriptor[]={0,123,1,1,160,4,0,0};memcpy(texture+128,descriptor,32);memset(texture+160,255,4);DWORD textureWrote;
 assert(WriteFile(inputWrite,&total,4,&textureWrote,NULL)&&textureWrote==4);assert(WriteFile(inputWrite,texture,total,&textureWrote,NULL)&&textureWrote==total);
 size_t textureSize=0;unsigned char *textureCopy=NULL;deadline=GetTickCount64()+1000;
 do{textureCopy=reaverTextureMemoryCopy(&l->session,&textureSize);if(!textureCopy)Sleep(1);}while(!textureCopy&&GetTickCount64()<deadline);
 assert(textureCopy&&textureSize==sizeof(texture)&&!memcmp(textureCopy,texture,sizeof(texture)));free(textureCopy);
 tick=GetTickCount64();memcpy(packet+64,&tick,8);
 uint32_t length=(uint32_t)n;DWORD wrote;assert(WriteFile(inputWrite,&length,4,&wrote,NULL)&&wrote==4);assert(WriteFile(inputWrite,packet,length,&wrote,NULL)&&wrote==length);
 bool admitted=false;deadline=GetTickCount64()+80;
 do{admitted=reaverPresentationRead(l,scratch,GetTickCount64());if(!admitted)Sleep(1);}while(!admitted&&GetTickCount64()<deadline);
 assert(admitted&&reaverPresentationCurrent(l,GetTickCount64()));CloseHandle(inputWrite);
 assert(WaitForSingleObject(pi.hProcess,3000)==WAIT_OBJECT_0);DWORD code;assert(GetExitCodeProcess(pi.hProcess,&code)&&code==0);
 assert(!reaverPresentationRead(l,scratch,GetTickCount64())&&!reaverPresentationCurrent(l,GetTickCount64()));
 assert(!reaverTextureMemoryCopy(&l->session,&textureSize));
 CloseHandle(outputRead);CloseHandle(pi.hThread);CloseHandle(pi.hProcess);free(packet);free(scratch);free(l);
}
static void memoryTests(const unsigned char *original,size_t n){
 ReaverPresentationLease *l=calloc(1,sizeof(*l));unsigned char *scratch=malloc(REAVER_PRESENTATION_CAPACITY);assert(l&&scratch);
 FILETIME born,exit,kernel,user;assert(GetProcessTimes(GetCurrentProcess(),&born,&exit,&kernel,&user));
 uint64_t creation=((uint64_t)born.dwHighDateTime<<32)|born.dwLowDateTime;uint32_t pid=GetCurrentProcessId();
 l->session=(ReaverPacketSession){pid,pid,pid,creation,creation,creation,400,500,600,700};
 assert(!reaverPresentationRead(l,scratch,1000)); // mapping absent
 wchar_t name[160],lockName[160];reaverPresentationNames(&l->session,name,lockName);
 HANDLE lock=CreateMutexW(NULL,FALSE,lockName);assert(lock&&GetLastError()!=ERROR_ALREADY_EXISTS);
 HANDLE map=CreateFileMappingW(INVALID_HANDLE_VALUE,NULL,PAGE_READWRITE,0,sizeof(ReaverPresentationMemory),name);assert(map&&GetLastError()!=ERROR_ALREADY_EXISTS);
 ReaverPresentationMemory *v=MapViewOfFile(map,FILE_MAP_WRITE,0,0,sizeof(*v));assert(v);memset(v,0,sizeof(*v));
 assert(!reaverPresentationRead(l,scratch,1000));
 assert(WaitForSingleObject(lock,0)==WAIT_OBJECT_0);memcpy(v->packet,original,n);v->magic=0x314d5752;v->version=1;v->online=1;v->size=(uint32_t)n;
 for(unsigned i=0;i<3;i++){memcpy(v->packet+16+i*4,&pid,4);memcpy(v->packet+32+i*8,&creation,8);}ReleaseMutex(lock);
 assert(reaverPresentationRead(l,scratch,1000));assert(reaverPresentationCurrent(l,1000));
 // Reader must not mutate the shared packet or online flag.
 assert(v->online==1&&v->packet[128]==original[128]);
 assert(!reaverPresentationRead(l,scratch,1101));assert(!reaverPresentationCurrent(l,1101));
 uint64_t seq=9,tick=1101;assert(WaitForSingleObject(lock,0)==WAIT_OBJECT_0);memcpy(v->packet+56,&seq,8);memcpy(v->packet+64,&tick,8);ReleaseMutex(lock);
 assert(reaverPresentationRead(l,scratch,1101));v->online=0;
 assert(!reaverPresentationRead(l,scratch,1101));assert(!reaverPresentationCurrent(l,1101));
 v->online=1;l->session.writerCreation++;assert(!reaverPresentationRead(l,scratch,1101));l->session.writerCreation--;
 v->size=REAVER_PRESENTATION_CAPACITY+1;assert(!reaverPresentationRead(l,scratch,1101));
 UnmapViewOfFile(v);CloseHandle(map);CloseHandle(lock);assert(!reaverPresentationRead(l,scratch,1101));free(scratch);free(l);
}
static void leaseTests(const unsigned char *original,size_t n,ReaverPacketSession s){
 ReaverPresentationLease *l=calloc(1,sizeof(*l));assert(l);l->session=s;
 unsigned char b[100000];memcpy(b,original,n);
 assert(reaverPresentationAccept(l,b,n,1000));assert(reaverPresentationCurrent(l,1100));
 assert(reaverPresentationAccept(l,b,n,1100));assert(!reaverPresentationCurrent(l,1101));
 assert(!reaverPresentationAccept(l,b,n,1100)); // no resurrection, even a backwards local test clock
 uint64_t seq=9,tick=1100;memcpy(b+56,&seq,8);memcpy(b+64,&tick,8);
 assert(reaverPresentationAccept(l,b,n,1100));assert(reaverPresentationCurrent(l,1100));
 b[128]^=1;assert(!reaverPresentationAccept(l,b,n,1100));b[128]^=1;
 assert(!reaverPresentationAccept(l,b,n,1100)); // same sequence altered/restored
 seq=10;memcpy(b+56,&seq,8);assert(reaverPresentationAccept(l,b,n,1100));
 assert(!reaverPresentationAccept(l,NULL,0,1100));assert(!reaverPresentationCurrent(l,1100));
 seq=11;memcpy(b+56,&seq,8);assert(reaverPresentationAccept(l,b,n,1100));
 // Explicit hidden state supersedes visible state, yet remains a valid packet.
 seq=12;memcpy(b+56,&seq,8);uint32_t zero=0,size=128;memcpy(b+8,&size,4);memcpy(b+12,&zero,4);memset(b+104,0,12);
 assert(reaverPresentationAccept(l,b,128,1100));assert(!reaverPresentationCurrent(l,1100));
 assert(!reaverPresentationAccept(l,original,n,1100));assert(!reaverPresentationCurrent(l,1100));
 free(l);
}
int main(int argc,char **argv){
 if(argc!=2)return 8;
 _setmode(_fileno(stdin),_O_BINARY);
 ReaverPacketSession s={10,20,30,100,200,300,400,500,600,700};
 unsigned char b[100000];uint32_t n;unsigned total=0;
 while(fread(&n,4,1,stdin)==1){if(n>sizeof(b)||fread(b,1,n,stdin)!=n)return 2;
  ReaverPacketView v;memset(&v,0xff,sizeof(v));bool ok=reaverPacketValidate(b,n,&s,1100,8,&v);
  if(!ok&&(v.sequence||v.tick||v.vertices||v.indices||v.batches||v.visible))return 3;
  if(total==0){assert(ok);leaseTests(b,n,s);memoryTests(b,n);writerTests(b,n,argv[1]);}
  printf("%u\n",ok?1:0);total++;
 }
 return total?0:4;
}
