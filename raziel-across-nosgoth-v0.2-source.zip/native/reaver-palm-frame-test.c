// SPDX-License-Identifier: GPL-3.0-or-later
#include <stdbool.h>
#include <math.h>
#include <string.h>
#include <stdio.h>
#include <assert.h>
#include "reaver-palm-frame.h"
int main(void){
 float p[9]={3,4,5,3,4,15,13,4,5},o[3]={7,8,9},m[16];
 assert(reaverPalmFrame(m,p,o));assert(m[0]==1&&m[5]==1&&m[10]==1&&m[12]==7);
 for(unsigned i=0;i<9;i+=3){float x=p[i];p[i]=-p[i+1]+100;p[i+1]=x-50;}
 assert(reaverPalmFrame(m,p,o));assert(fabsf(m[1]-1)<.00001f&&fabsf(m[4]+1)<.00001f);
 for(unsigned i=0;i<16;i++)printf("%.9g%c",m[i],i==15?'\n':' ');
 float saved[16];memcpy(saved,m,sizeof(m));memset(p,0,sizeof(p));assert(!reaverPalmFrame(m,p,o));assert(!memcmp(saved,m,sizeof(m)));
 p[5]=1;p[8]=2;assert(!reaverPalmFrame(m,p,o));p[0]=NAN;assert(!reaverPalmFrame(m,p,o));
 return 0;
}
