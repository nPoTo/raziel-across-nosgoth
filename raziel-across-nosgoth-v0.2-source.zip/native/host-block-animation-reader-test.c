// SPDX-License-Identifier: GPL-3.0-or-later
// Reuse the existing production base-reader fixture and its full negative suite.
#define main baseReaderTestMain
#include "host-block-state-reader-test.c"
#undef main
#include "host-block-animation-reader.h"
static unsigned idReads;static int animationDefect;
static bool animationFixture(void *context,uintptr_t address,void *out,SIZE_T bytes){
 for(unsigned i=0;i<3;i++)if(address==actor+0x374+i*0x50&&bytes==2){
  uint16_t id=i==0?0:i==1?65535:22;if(animationDefect==1)return false;if(animationDefect==2&&++idReads>3)id++;memcpy(out,&id,2);return true;
 }
 return fixture(context,address,out,bytes);
}
static HostBlockState animated(uint16_t ids[3]){actorReads=callbackReads=recordReads=targetReads=idReads=0;return hostBlockAnimationStateRead(NULL,animationFixture,code,base,0x3000000,actor,ids);}
int main(void){
 CHECK(baseReaderTestMain()==0,60);defect=0;away=false;uint16_t ids[3];HostBlockState s=animated(ids);CHECK(s.valid&&ids[0]==0&&ids[1]==65535&&ids[2]==22,61);
 animationDefect=1;CHECK(!animated(ids).valid&&ids[0]==0&&ids[1]==0&&ids[2]==0,62);
 animationDefect=2;CHECK(!animated(ids).valid,63);animationDefect=0;
 defect=1;CHECK(!animated(ids).valid,64);defect=2;CHECK(!animated(ids).valid,65);defect=6;CHECK(!animated(ids).valid,66);defect=0;
 CHECK(!hostBlockAnimationStateRead(NULL,animationFixture,code,UINTPTR_MAX-4,0x3000000,actor,ids).valid,67);CHECK(!hostBlockAnimationStateRead(NULL,animationFixture,code,base,0x3000000,actor,NULL).valid,68);
 puts("PASS: production scalar animation IDs bracket stable host state; ID0/65535 preserved; unreadable/racing IDs, actor/owner/code/bounds rejected; no resource dereference");return 0;
}
