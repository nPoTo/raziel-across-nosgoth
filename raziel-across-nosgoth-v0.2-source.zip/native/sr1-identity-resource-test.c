// SPDX-License-Identifier: GPL-3.0-or-later
// Compose the actual stream's scalar identity encoder with the native draw
// identity comparator. No game process is opened by main.
#include <assert.h>
#define wmain observed_stream_wmain
#include "sr1-retarget-stream.c"
#undef wmain
int main(void){
 HostRig a={.actor=8,.object=16,.name=24,.list=32,.model=40,.segments=48,.legacy=56,.render=64,.count=66};
 for(unsigned i=0;i<66;i++)a.parents[i]=i?(int16_t)(i-1):-1;
 char original[65],actual[65];assert(identityResourceHash(&a,original));HostRig b=a;
 b.legacy=80;b.render=88;assert(hostDrawResourceSame(&a,&b));assert(identityResourceHash(&b,actual));assert(!strcmp(original,actual));
 uintptr_t *fields[]={&b.actor,&b.object,&b.name,&b.list,&b.model,&b.segments};
 for(unsigned i=0;i<ARRAYSIZE(fields);i++){uintptr_t saved=*fields[i];*fields[i]+=8;assert(!hostDrawResourceSame(&a,&b));assert(identityResourceHash(&b,actual));assert(strcmp(original,actual));*fields[i]=saved;}
 b.parents[3]=0;assert(!hostDrawResourceSame(&a,&b));assert(identityResourceHash(&b,actual));assert(strcmp(original,actual));b=a;
 b.count=65;assert(!identityResourceHash(&b,actual));b=a;b.modelIndex=1;assert(!identityResourceHash(&b,actual));
 puts("PASS actual stream identity hash matches native resource identity; rotating palette excluded; hierarchy/resource changes detected");return 0;
}
