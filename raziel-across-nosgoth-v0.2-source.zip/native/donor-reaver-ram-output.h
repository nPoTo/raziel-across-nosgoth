// SPDX-License-Identifier: GPL-3.0-or-later
#pragma once
// Called ONLY after stdout has been admitted as a pipe. Never log payloads.
static void reaverRamFloats(const float *v,unsigned n){fputc('[',stdout);for(unsigned i=0;i<n;i++)printf("%s%.9g",i?",":"",v[i]);fputc(']',stdout);}
static void reaverRamColors(const uint32_t *v,unsigned n){fputc('[',stdout);for(unsigned i=0;i<n;i++)printf("%s%u",i?",":"",v[i]);fputc(']',stdout);}
static void reaverRamOutput(const ReaverGraphics *g,bool valid,unsigned sequence,uint64_t tick){
 printf("{\"type\":\"reaverRam\",\"version\":5,\"sequence\":%u,\"tick\":%llu,\"valid\":%s,\"failureStage\":%u",sequence,(unsigned long long)tick,valid?"true":"false",g->failureStage);
 if(valid){const ReaverSnapshot *s=&g->source;
  printf(",\"actor\":\"%llx\",\"weapon\":\"%llx\",\"model\":\"%llx\",\"active\":%u,\"bones\":%u,\"vertices\":%u,\"partMask\":%u,\"flags\":%u,\"draw\":%u,\"fade\":%.9g,\"form\":%u",
   (unsigned long long)s->actor,(unsigned long long)s->weapon,(unsigned long long)g->model,g->active,g->bones,g->vertices,s->partMask|g->partMask2|g->partMask3,s->flags,s->drawState,s->fadeCurrent,s->type);
  printf(",\"objectFlags\":%u,\"flags2\":%u,\"colorMode\":%u",g->objectFlags,g->flags2,g->colorMode);
  printf(",\"realmBlend\":%.9g,\"partMode\":%u",g->realmBlend,g->partMode);
  fputs(",\"palm\":",stdout);reaverRamFloats(g->palm,9);fputs(",\"hand\":",stdout);reaverRamFloats(g->hand,16);fputs(",\"pose\":",stdout);reaverRamFloats(&g->pose[0][0],g->bones*16);
  fputs(",\"colors\":",stdout);reaverRamColors(g->color,g->vertices);
  fputs(",\"alternateColors\":",stdout);if(g->alternate)reaverRamColors(g->alternateColor,g->vertices);else fputs("null",stdout);
  fputs(",\"indices\":[",stdout);for(unsigned i=0;i<g->indexCount;i++)printf("%s%u",i?",":"",g->indices[i]);
  fputs("],\"batches\":[",stdout);for(unsigned i=0;i<g->batchCount;i++){const ReaverGraphicsBatch *b=&g->batch[i];printf("%s{\"count\":%u,\"part\":%u,\"material\":%u,\"textureId\":%u,\"indexOffset\":%u,\"scroll\":%.9g,\"textureFlags\":%u}",i?",":"",b->count,b->part,b->material,b->textureId,b->indexOffset,b->scroll,b->textureFlags);}fputc(']',stdout);
 }
 puts("}");fflush(stdout);
}

