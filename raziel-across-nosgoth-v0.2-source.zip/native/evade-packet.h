// Experimental measured profile velocity, units/ms. Independent of donor factor.
static bool evadePacketVelocity(const unsigned char *b,size_t size,uint64_t now,uint32_t pid,uint64_t poseTick,float velocity[2],uint64_t *tick,uint64_t *episode){
 static const unsigned char hash[32]={0xfc,0x6a,0x40,0x6f,0xf7,0xac,0x9b,0x5e,0xb7,0x78,0x8d,0xc7,0xa6,0x5d,0x33,0x5e,0x1c,0x1a,0xad,0x92,0x36,0x61,0x81,0x12,0x67,0x19,0x75,0xb7,0x1d,0x2d,0xad,0xdc};
 if(!b||size!=96||!pid||!poseTick)return false;
 uint32_t w[24];memcpy(w,b,96);float clock;memcpy(tick,b+16,8);memcpy(episode,b+24,8);memcpy(velocity,b+32,8);memcpy(&clock,b+48,4);
 if(w[0]!=0x31455a52||w[1]!=1||w[2]!=pid||w[10]<25||w[10]>28||w[11]!=1||w[13]||w[14]||w[15]||memcmp(b+64,hash,32)||
    *tick>now||now-*tick>150||poseTick>now||now-poseTick>250||(*tick>poseTick?*tick-poseTick:poseTick-*tick)>100||
    !*episode||*episode>*tick||*tick-*episode>1400||!isfinite(clock)||clock<0||clock>3500)return false;
 for(unsigned j=0;j<2;j++)if(!isfinite(velocity[j])||fabsf(velocity[j])>6)return false;
 return true;
}
