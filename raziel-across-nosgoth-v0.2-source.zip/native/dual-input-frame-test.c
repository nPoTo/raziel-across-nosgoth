// SPDX-License-Identifier: GPL-3.0-or-later
#include <assert.h>
#include <stdio.h>
#include "exploration-sheets.h"
#include "dual-input-frame.h"
#include "sr1-free-attack-owner.h"
int main(void){
 uint8_t keys[112]={0};keys[21]=1; // Physical A, even though native row calls it back.
 assert(dualInputKeys(keys)==DUAL_LEFT);keys[39]=1;assert(dualInputKeys(keys)==(DUAL_LEFT|DUAL_BACK));
 DualInputPad p=dualInputMerge(dualInputKeys(keys),NULL);assert(p.x==-23170&&p.y==-23170);
 keys[24]=1;keys[43]=1;p=dualInputMerge(dualInputKeys(keys),NULL);assert(!p.x&&!p.y);
 memset(keys,0,sizeof(keys));keys[108]=keys[109]=keys[4]=1;
 p=dualInputMerge(dualInputKeys(keys),NULL);assert(p.buttons==0xd000);
 DualInputPad pad={.buttons=0x4000,.x=16000,.y=13000};p=dualInputMerge(dualInputKeys(keys),&pad);assert(p.buttons==0xd000&&p.x==16000&&p.y==13000);
 // Feed keyboard E has semantic RB, not native B before host remapping.
 memset(keys,0,sizeof(keys));keys[25]=1;assert(dualInputMerge(dualInputKeys(keys),NULL).buttons==0x200);
 DualInputBinding bindings[13]={{16,43,106},{128,21,104},{64,39,107},{32,24,105},{16384,4,92},{32768,108,94},{8192,25,93},{4096,37,95},{256,23,96},{1024,9,102},{512,109,103},{2048,8,97},{1,5,98}};
 uint32_t baseline=0;assert(dualInputNativeKeyboard(keys,bindings,&baseline)&&baseline==8192);
 // Native-context handback uses current raw release, never last frame's press.
 keys[25]=0;assert(dualInputNativeKeyboard(keys,bindings,&baseline)&&!baseline);
 DualInputReleaseGate gate={0};uint8_t released[112];uint16_t blocked=0;keys[108]=1;
 dualInputReleaseGate(&gate,keys,0x4000,true,released,&blocked);
 dualInputReleaseGate(&gate,keys,0x4000,false,released,&blocked);assert(!released[108]&&blocked==0x4000);
 keys[5]=1;dualInputReleaseGate(&gate,keys,0x4000,false,released,&blocked);assert(released[5]&&!released[108]); // Tab untouched.
 keys[108]=0;dualInputReleaseGate(&gate,keys,0,false,released,&blocked);assert(!blocked);
 keys[108]=1;dualInputReleaseGate(&gate,keys,0,false,released,&blocked);assert(released[108]); // A NEW native press is legal.
 bindings[0].key=112;assert(!dualInputNativeKeyboard(keys,bindings,&baseline));bindings[0].key=43;
 DualInputMaskLease lease={0};uint32_t original=0x400001|0x8000;
 uint32_t changed=dualInputMaskApply(&lease,original,0,0xfff0);assert(changed==0x400001);
 assert(dualInputMaskRestore(&lease,changed|0x1000000)==(original|0x1000000));
 // Actual press-owner policy: one consumed action stays consumed across a
// temporarily absent pose, but native interaction remains native.
 SrFreeAttackOwner owner={0};assert(!srFreeAttackStep(&owner,1,42,true,true,0,0,0x4000));
 assert(!srFreeAttackStep(&owner,2,42,true,true,0x4000,0x4000,0x4000));
 assert(!srFreeAttackStep(&owner,3,42,true,false,0x4000,0x4000,0x4000));
 srFreeAttackStep(&owner,4,42,true,false,0,0,0x4000);
 assert(srFreeAttackStep(&owner,5,42,true,false,0x4000,0x4000,0x4000)==0x4000);
 // Exhaust all 16-bit delivered chords: UI/navigation bits never become gameplay bits.
 for(uint32_t b=0;b<65536;b++){
  p=(DualInputPad){.buttons=(uint16_t)b};uint32_t m=dualInputHostMask(p);
  assert(!(m&~0xff00u));assert(m==dualInputHostMask((DualInputPad){.buttons=(uint16_t)(b&~0xffu)}));
 }
 puts("PASS dual frame: physical keys, diagonals, simultaneous inputs, current-release restore, press ownership, 65536 native masks");return 0;
}
