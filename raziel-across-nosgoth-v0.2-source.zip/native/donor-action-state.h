// SPDX-License-Identifier: GPL-3.0-or-later
#pragma once
#include "exploration-sheets.h"
typedef bool (*DonorActionStateRead)(void *,uintptr_t,void *,SIZE_T);
typedef bool (*DonorActionStateCode)(void *,uintptr_t,uintptr_t);
typedef struct {uint32_t firstRva,secondRva;bool valid,secondValid;} DonorActionState;
static inline DonorActionState donorActionStateRead(void *context,DonorActionStateRead read,DonorActionStateCode code,uintptr_t base,uint32_t imageSize,uintptr_t actor,uintptr_t currentActorAddress){
 DonorActionState result={0};const Sheet_donorActionStateProbe *p=&sheet_donorActionStateProbe_current;
 if(!read||!code||!base||!actor||actor%8||p->statePrefixBytes!=32||p->stableReads!=2||!p->requireExecutableImage||p->serializePointers||base>UINTPTR_MAX-imageSize||actor>UINTPTR_MAX-(uintptr_t)p->actorStateOffset-8)return result;
 uintptr_t state=0,again=0,current=0,first=0,second=0;unsigned char prefix[32],after[32];
 if(!read(context,currentActorAddress,&current,8)||current!=actor||!read(context,actor+(uintptr_t)p->actorStateOffset,&state,8)||!state||state%8||state>UINTPTR_MAX-sizeof(prefix)||!read(context,state,prefix,sizeof(prefix)))return result;
 memcpy(&first,prefix+(size_t)p->firstCallbackOffset,8);memcpy(&second,prefix+(size_t)p->secondCallbackOffset,8);
 if(first<base||first-base>=imageSize||!code(context,first,base))return result;
 bool secondValid=second>=base&&second-base<imageSize&&code(context,second,base);
 if(!read(context,state,after,sizeof(after))||memcmp(prefix,after,sizeof(prefix))||!read(context,actor+(uintptr_t)p->actorStateOffset,&again,8)||again!=state||!read(context,currentActorAddress,&current,8)||current!=actor)return result;
 result.firstRva=(uint32_t)(first-base);result.secondRva=secondValid?(uint32_t)(second-base):0;result.valid=true;result.secondValid=secondValid;return result;
}
