// SPDX-License-Identifier: GPL-3.0-or-later
#pragma once
#include "guidance-render.h"
#include "guidance-d3d.h"
static uint64_t guidancePoll,guidanceBegin,guidanceSession;
static bool guidanceActive;static unsigned guidancePlan,guidanceElapsed,guidanceLastStage=UINT32_MAX;
static unsigned long guidanceFrames;
static uint32_t guidanceWriter;static unsigned guidanceAckSecond=UINT32_MAX;
typedef struct{uint32_t magic,version,gamePid,writerPid,plan,elapsed;uint64_t session,tick,frames;} GuidanceVisible;
_Static_assert(sizeof(GuidanceVisible)==48,"Guidance visibility acknowledgement");
static bool guidanceRefresh(void){
 uint64_t now=GetTickCount64();
 if(now-guidancePoll>=(uint64_t)sheet_guidanceRenderPolicy_native.pollMs){
  guidancePoll=now;guidanceActive=false;RecordingStatus status={0};GuidanceDescriptor d={0};
  if(recordingReadStatus(GetCurrentProcessId(),&status)&&recordingStatusValid(&status,GetCurrentProcessId(),now)){
   wchar_t path[512];_snwprintf(path,512,PROBE_PATH(L"\\guidance-%lu.bin"),GetCurrentProcessId());HANDLE f=CreateFileW(path,GENERIC_READ,FILE_SHARE_READ|FILE_SHARE_WRITE|FILE_SHARE_DELETE,NULL,OPEN_EXISTING,FILE_ATTRIBUTE_NORMAL,NULL);
   if(f!=INVALID_HANDLE_VALUE){LARGE_INTEGER size;DWORD n=0;bool ok=GetFileSizeEx(f,&size)&&size.QuadPart==sizeof(d)&&ReadFile(f,&d,sizeof(d),&n,NULL)&&n==sizeof(d);CloseHandle(f);
    if(ok&&guidanceDescriptorValid(&d,GetCurrentProcessId(),status.writerPid,status.total)){
     if(d.session!=guidanceSession){guidanceSession=d.session;guidanceBegin=now;guidanceLastStage=UINT32_MAX;guidanceAckSecond=UINT32_MAX;guidanceFrames=0;}
     guidanceWriter=d.writerPid;
     guidanceElapsed=(unsigned)((uint64_t)status.completed*d.seconds/status.total);guidancePlan=d.plan;guidanceActive=guidanceElapsed<d.seconds&&guidanceWithinBudget(now,guidanceBegin,d.seconds);
    }
   }
  }
 }
 return guidanceActive;
}
static void guidanceAcknowledge(const char *backend){
  ++guidanceFrames;const TutorialStage *s=guidanceStageAt(guidancePlan,guidanceElapsed);
  if(guidanceAckSecond!=guidanceElapsed){
   wchar_t path[512];_snwprintf(path,512,PROBE_PATH(L"\\guidance-visible-%lu.bin"),GetCurrentProcessId());
   HANDLE f=CreateFileW(path,GENERIC_READ|GENERIC_WRITE,FILE_SHARE_READ|FILE_SHARE_DELETE,NULL,OPEN_ALWAYS,FILE_ATTRIBUTE_NORMAL,NULL);DWORD creationError=GetLastError();
   if(f!=INVALID_HANDLE_VALUE){GuidanceVisible old={0};DWORD n=0;LARGE_INTEGER size;bool owned=creationError!=ERROR_ALREADY_EXISTS;
    if(!owned&&GetFileSizeEx(f,&size)&&size.QuadPart==sizeof(old)&&ReadFile(f,&old,sizeof(old),&n,NULL)&&n==sizeof(old))owned=old.magic==0x31534956&&old.version==1&&old.gamePid==GetCurrentProcessId()&&old.writerPid==guidanceWriter&&old.session==guidanceSession;
    if(owned){GuidanceVisible ack={0x31534956,1,GetCurrentProcessId(),guidanceWriter,guidancePlan,guidanceElapsed,guidanceSession,GetTickCount64(),guidanceFrames};SetFilePointer(f,0,NULL,FILE_BEGIN);if(WriteFile(f,&ack,sizeof(ack),&n,NULL)&&n==sizeof(ack))guidanceAckSecond=guidanceElapsed;}
    CloseHandle(f);
   }
  }
  if(s&&guidanceLastStage!=s->begin){guidanceLastStage=s->begin;logLine("GUIDANCE_HUD backend=%s writer=%lu plan=%u stage_begin=%u elapsed=%u remaining=%u frames=%lu; native-frame",backend,(unsigned long)guidanceWriter,guidancePlan,s->begin,guidanceElapsed,guidanceSeconds(guidancePlan)-guidanceElapsed,guidanceFrames);}
}
static void guidanceDraw(HGLRC context){
 if(guidanceRefresh()&&guidanceRender(context,guidancePlan,guidanceElapsed))guidanceAcknowledge("opengl");
}
