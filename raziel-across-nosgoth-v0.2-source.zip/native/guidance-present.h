// SPDX-License-Identifier: GPL-3.0-or-later
#pragma once
typedef HRESULT (STDMETHODCALLTYPE *GuidancePresentFn)(IDXGISwapChain *,UINT,UINT);
typedef HRESULT (STDMETHODCALLTYPE *GuidancePresent1Fn)(IDXGISwapChain1 *,UINT,UINT,const DXGI_PRESENT_PARAMETERS *);
static GuidancePresentFn guidanceOriginalPresent;static GuidancePresent1Fn guidanceOriginalPresent1;
static LONG64 guidancePresentCalls;static LONG guidancePresentLock;static _Thread_local bool guidanceInPresent;
static void guidancePresentDraw(IDXGISwapChain *chain,UINT flags){
 if(!chain||(flags&(DXGI_PRESENT_TEST|DXGI_PRESENT_DO_NOT_WAIT))||guidanceInPresent||InterlockedCompareExchange(&guidancePresentLock,1,0))return;
 guidanceInPresent=true;DXGI_SWAP_CHAIN_DESC desc={0};DWORD pid=0;
 if(SUCCEEDED(IDXGISwapChain_GetDesc(chain,&desc))){GetWindowThreadProcessId(desc.OutputWindow,&pid);
  if(pid==GetCurrentProcessId()&&desc.BufferDesc.Width>=320&&desc.BufferDesc.Height>=240){
   LONG64 count=InterlockedIncrement64(&guidancePresentCalls);if(count==1)logLine("GUIDANCE_PRESENT actual_game_frame=1; D3D11 HUD pending fresh recording heartbeat");
   if(guidanceRefresh()){HRESULT hr=E_FAIL;if(guidanceD3DRender(chain,guidancePlan,guidanceElapsed,&hr))guidanceAcknowledge("d3d11");else if(guidanceFrames==0&&guidanceLastStage==UINT32_MAX){guidanceLastStage=UINT32_MAX-1;logLine("GUIDANCE_RENDER_FAILED hr=0x%08lx; original Present preserved",(unsigned long)hr);}}
  }
 }
 guidanceInPresent=false;InterlockedExchange(&guidancePresentLock,0);
}
static HRESULT STDMETHODCALLTYPE guidancePresent(IDXGISwapChain *chain,UINT interval,UINT flags){
 guidancePresentDraw(chain,flags);return guidanceOriginalPresent(chain,interval,flags);
}
static HRESULT STDMETHODCALLTYPE guidancePresent1(IDXGISwapChain1 *chain,UINT interval,UINT flags,const DXGI_PRESENT_PARAMETERS *parameters){
 // Keep dirty/scroll semantics untouched. Such presentations require another proved composition path.
 if(!parameters||(!parameters->DirtyRectsCount&&!parameters->pScrollRect&&!parameters->pScrollOffset))guidancePresentDraw((IDXGISwapChain *)chain,flags);
 return guidanceOriginalPresent1(chain,interval,flags,parameters);
}
static bool guidanceDXGITarget(PVOID target){
 HMODULE dxgi=GetModuleHandleW(L"dxgi.dll"),steam=GetModuleHandleW(L"GameOverlayRenderer64.dll");MEMORY_BASIC_INFORMATION m={0};
 // Public methods from our own runtime-created COM interface only. MinHook's original trampoline
 // preserves existing entry redirects; it does not bypass another overlay's Present implementation.
 return target&&dxgi&&VirtualQuery(target,&m,sizeof(m))==sizeof(m)&&m.State==MEM_COMMIT&&m.Type==MEM_IMAGE&&(m.AllocationBase==dxgi||(steam&&m.AllocationBase==steam))&&(m.Protect&(PAGE_EXECUTE|PAGE_EXECUTE_READ|PAGE_EXECUTE_READWRITE|PAGE_EXECUTE_WRITECOPY));
}
static bool guidancePresentInstall(void){
 if(!sheet_guidanceBackendPolicy_donor.enabled)return false;
 if(offsetof(IDXGISwapChainVtbl,Present)/sizeof(void *)!=(size_t)sheet_guidanceBackendPolicy_donor.presentSlot||offsetof(IDXGISwapChain1Vtbl,Present1)/sizeof(void *)!=(size_t)sheet_guidanceBackendPolicy_donor.present1Slot)return false;
 WNDCLASSW wc={0};wc.lpfnWndProc=DefWindowProcW;wc.hInstance=self;wc.lpszClassName=L"LOKGuidanceHookDiscovery";
 if(!RegisterClassW(&wc))return false;HWND window=CreateWindowW(wc.lpszClassName,L"Hidden owned DXGI discovery",WS_POPUP,0,0,64,64,NULL,NULL,self,NULL);
 IDXGISwapChain *chain=NULL;IDXGISwapChain1 *chain1=NULL;ID3D11Device *device=NULL;ID3D11DeviceContext *context=NULL;PVOID target=NULL,target1=NULL;bool installed=false;
 if(window){DXGI_SWAP_CHAIN_DESC d={0};d.BufferDesc.Width=d.BufferDesc.Height=64;d.BufferDesc.Format=DXGI_FORMAT_R8G8B8A8_UNORM;d.SampleDesc.Count=1;d.BufferUsage=DXGI_USAGE_RENDER_TARGET_OUTPUT;d.BufferCount=1;d.OutputWindow=window;d.Windowed=TRUE;d.SwapEffect=DXGI_SWAP_EFFECT_DISCARD;
  HRESULT hr=D3D11CreateDeviceAndSwapChain(NULL,D3D_DRIVER_TYPE_WARP,NULL,0,NULL,0,D3D11_SDK_VERSION,&d,&chain,&device,NULL,&context);
  if(SUCCEEDED(hr)){target=(PVOID)chain->lpVtbl->Present;if(SUCCEEDED(IDXGISwapChain_QueryInterface(chain,&IID_IDXGISwapChain1,(void **)&chain1)))target1=(PVOID)chain1->lpVtbl->Present1;}
  logLine("GUIDANCE_PRESENT_DISCOVERY hr=0x%08lx public_dxgi_present=%d present1=%d; hidden owned device only",(unsigned long)hr,guidanceDXGITarget(target),guidanceDXGITarget(target1));
 }
 GUIDANCE_RELEASE(chain1,IDXGISwapChain1);GUIDANCE_RELEASE(chain,IDXGISwapChain);GUIDANCE_RELEASE(context,ID3D11DeviceContext);GUIDANCE_RELEASE(device,ID3D11Device);if(window)DestroyWindow(window);UnregisterClassW(wc.lpszClassName,self);
 MH_STATUS init=MH_Initialize();if(init!=MH_OK&&init!=MH_ERROR_ALREADY_INITIALIZED)return false;
 if(guidanceDXGITarget(target)){MH_STATUS c=MH_CreateHook(target,(PVOID)&guidancePresent,(PVOID *)&guidanceOriginalPresent);MH_STATUS e=c==MH_OK?MH_EnableHook(target):c;installed=e==MH_OK;logLine("GUIDANCE_PRESENT_HOOK create=%d enable=%d",c,e);}
 if(guidanceDXGITarget(target1)&&target1!=target){MH_STATUS c=MH_CreateHook(target1,(PVOID)&guidancePresent1,(PVOID *)&guidanceOriginalPresent1);MH_STATUS e=c==MH_OK?MH_EnableHook(target1):c;installed=installed||e==MH_OK;logLine("GUIDANCE_PRESENT1_HOOK create=%d enable=%d",c,e);}
 return installed;
}
