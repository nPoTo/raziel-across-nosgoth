// SPDX-License-Identifier: GPL-3.0-or-later
#pragma once
#include "host-rig-reader.h"
#include "sr1-retarget-gate.h"
// Read-only candidate. Static evidence R01.03-native-interpolation-exit-20261023.
// The caller must separately validate the actor generation and action context.
typedef struct {uint16_t animation[6];uintptr_t info[6],active[6];} Sr1NativeExitSample;
static inline bool sr1NativeExitOnce(void *p,RigRead read,uintptr_t actor,Sr1NativeExitSample *out){
 const Sheet_nativeInterpolationExit *s=&sheet_nativeInterpolationExit_sr1_sections;
 memset(out,0,sizeof(*out));
 if(!actor||actor>UINTPTR_MAX-0x570||s->sectionOffset!=0x358||s->hdSectionOffset!=0x480||s->sectionStride!=0x50||s->sections!=3||s->animationOffset!=0x1c||s->interpolationPointerOffset!=0x48||s->activeListOffset!=0x10||s->gameWrites||s->enabled)return false;
 for(unsigned i=0;i<6;i++){
  uintptr_t section=actor+(i<3?s->sectionOffset:s->hdSectionOffset)+(i%3)*s->sectionStride;
  if(!read(p,section+s->animationOffset,&out->animation[i],2)||!read(p,section+s->interpolationPointerOffset,&out->info[i],8))return false;
  if(out->info[i]&&(out->info[i]>UINTPTR_MAX-0x18||!read(p,out->info[i]+s->activeListOffset,&out->active[i],8)))return false;
 }
 return true;
}
static inline bool sr1NativeExitRead(void *p,RigRead read,uintptr_t actor,Sr1NativeExitSample *out){
 Sr1NativeExitSample a,b;memset(out,0,sizeof(*out));
 if(!sr1NativeExitOnce(p,read,actor,&a)||!sr1NativeExitOnce(p,read,actor,&b)||memcmp(&a,&b,sizeof(a)))return false;
 *out=a;return true;
}
static inline bool sr1NativeExitBlending(const Sr1NativeExitSample *s){for(unsigned i=0;i<6;i++)if(s->active[i])return true;return false;}
// A native-action latch survives missing data and clears only at a confirmed
// allowed action context with all legacy AND HD interpolation lists finished.
typedef struct {bool nativeOwned;} Sr1NativeExitLatch;
// Retarget admission can fail for a valid ordinary clip or scalar variant.
// Only separately identified mechanics may claim native ownership. Unknown
// states still refuse the pose; they do not manufacture a native transition.
static inline bool sr1NativeActionActive(const Sr1RetargetContext *c){
 if(!c||!c->identity)return false;
 if(c->crouchHeld||c->mode||(c->flags&0x10000000u))return true;
 for(unsigned i=0;i<3;i++)switch(c->callbacks[i]){
  case 0xeded0: case 0xefb50: case 0xf48e0: case 0xf1ad0:
  case 0xecf70: case 0xf8c80: case 0xf8e90: case 0xf0240:
  case 0xf4490: case 0xeeb40:return true;
  default:break;
 }
 return false;
}
static inline bool sr1NativeExitAdmit(Sr1NativeExitLatch *s,bool contextKnown,bool actionAllowed,bool nativeAction,bool exitKnown,const Sr1NativeExitSample *pose){
 if(!contextKnown)return false;
 if(nativeAction){s->nativeOwned=true;return false;}
 if(!actionAllowed)return false;
 if(!s->nativeOwned)return true;
 if(!exitKnown||!pose||sr1NativeExitBlending(pose))return false;
 s->nativeOwned=false;return true;
}
