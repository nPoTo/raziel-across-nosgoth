// SPDX-License-Identifier: GPL-3.0-or-later
#include <stdbool.h>
#include <stdint.h>
#include <string.h>
#include <math.h>
#include <assert.h>
#include <stdio.h>
#include <wchar.h>
#include "exploration-sheets.h"
#include "host-transform.h"
#include "reaver-submitted-hand.h"
int main(void){
 float native[66][13]={0},adapted[66][13],after[66][13];
 for(unsigned b=0;b<66;b++)native[b][0]=native[b][4]=native[b][8]=1;
 native[49][10]=10;native[49][11]=20;native[49][12]=30;
 memcpy(adapted,native,sizeof(native));adapted[49][10]=100;
 adapted[49][0]=0;adapted[49][1]=-1;adapted[49][3]=1;adapted[49][4]=0;
 memcpy(after,adapted,sizeof(after));ReaverSubmittedHand s;
 assert(reaverHandCapture(&s,adapted,after,1,2,3,4,5,true,true,1));
 assert(s.matrix[12]==100&&s.matrix[1]==1&&s.matrix[4]==-1);
 assert(reaverHandCurrent(&s,1,2,3,4));
 assert(!reaverHandCurrent(&s,1,2,3,5));assert(!reaverHandCurrent(&s,1,2,6,4));assert(!reaverHandCurrent(&s,1,9,3,4));
 // Native fallback must replace the adapted hand, not inherit its last value.
 assert(reaverHandCapture(&s,native,native,1,2,3,4,6,true,true,1));assert(s.matrix[12]==10);
 // Any mutation invalidates the whole submitted pose, even outside the hand.
 after[3][12]=1;assert(!reaverHandCapture(&s,adapted,after,1,2,3,4,7,true,true,1));assert(!s.valid);
 memcpy(after,adapted,sizeof(after));
 assert(!reaverHandCapture(&s,adapted,after,1,2,3,4,7,false,true,1));
 assert(!reaverHandCapture(&s,adapted,after,1,2,3,4,7,true,false,1));
 assert(!reaverHandCapture(&s,adapted,after,1,2,3,4,7,true,true,2));
 adapted[49][0]=NAN;memcpy(after,adapted,sizeof(after));assert(!reaverHandCapture(&s,adapted,after,1,2,3,4,8,true,true,1));
 // Existing helpers remain available in this translation unit.
 unsigned char legacy[32]={0};float m[16],product[16],identity[16]={1,0,0,0,0,1,0,0,0,0,1,0,0,0,0,1};assert(!decodeHostRoot(legacy,m));hostMultiply(identity,identity,product);assert(!memcmp(identity,product,sizeof(identity)));
 puts("PASS submitted hand: adapted/native choice, current frame/session, unchanged pose, outer player draw, malformed rejection. Not a live hook test.");return 0;
}
