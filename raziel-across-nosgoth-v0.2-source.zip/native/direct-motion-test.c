#define main anchorHarnessMain
#include "donor-anchor-test.c"
#undef main
#include "direct-motion-source.h"
#include "direct-motion-consumer.h"
int main(void){
 unsigned char instance[1024];DirectMotionShared shared={0};setup(instance);
 directMotionView=&shared;directMotionEnabled=1;directMotionLock=0;memset(&directMotionCurrent,0,sizeof(directMotionCurrent));
 donorAnchorMotionSample=directMotionSample;donorAnchorEnabled=1;
 CHECK(anchorDonorFrame()==0xfedcba&&calls==1);DirectMotionSnapshot s;
 CHECK(directMotionCopy(&shared,&s)&&directMotionValid(&s,GetCurrentProcessId(),GetTickCount64()));
 CHECK(s.xy[0]==30&&s.xy[1]==-15&&s.z==20&&s.baseZ==0&&s.samples==2);
 CHECK(*(float *)(instance+0x20)==10&&*(float *)(instance+0x24)==20&&*(float *)(instance+0x28)==20);
 DirectMotionCursor cursor={0};double d[2];CHECK(directMotionDelta(&cursor,&s,s.pid,s.tick,d)==1);CHECK(directMotionDelta(&cursor,&s,s.pid,s.tick,d)==3&&d[0]==0&&d[1]==0);
 anchorDonorFrame();CHECK(directMotionCopy(&shared,&s)&&s.xy[0]==60&&s.xy[1]==-30&&s.z==40);
 CHECK(directMotionDelta(&cursor,&s,s.pid,s.tick,d)==2&&d[0]==30&&d[1]==-15);CHECK(directMotionDelta(&cursor,&s,s.pid,s.tick,d)==3);
 DirectMotionSnapshot bad=s;bad.xy[0]=NAN;CHECK(!directMotionValid(&bad,s.pid,s.tick));bad=s;bad.moduleHash[0]^=1;CHECK(!directMotionValid(&bad,s.pid,s.tick));bad=s;bad.root[0]=2;CHECK(!directMotionValid(&bad,s.pid,s.tick));
 CHECK(!directMotionValid(&s,s.pid+1,s.tick));CHECK(!directMotionValid(&s,s.pid,s.tick+151));CHECK(!directMotionValid(&s,s.pid,s.tick-1));
 bad=s;bad.samples--;CHECK(directMotionDelta(&cursor,&bad,s.pid,s.tick,d)==0);bad=s;bad.samples++;bad.xy[0]+=513;CHECK(directMotionDelta(&cursor,&bad,s.pid,s.tick,d)==0);
 bad=s;bad.epoch++;bad.tick++;CHECK(directMotionDelta(&cursor,&bad,s.pid,bad.tick,d)==1&&d[0]==0);
 shared.sequence|=1;CHECK(!directMotionCopy(&shared,&s));shared.sequence++;
 // Reader view must work with FILE_MAP_READ: no atomic write on its sequence.
 wchar_t name[96];_snwprintf(name,96,L"Local\\LOKDirectTest-%lu",GetCurrentProcessId());HANDLE mapping=CreateFileMappingW(INVALID_HANDLE_VALUE,NULL,PAGE_READWRITE,0,sizeof(shared),name);CHECK(mapping);
 DirectMotionShared *writeView=MapViewOfFile(mapping,FILE_MAP_WRITE,0,0,sizeof(shared));const DirectMotionShared *readView=MapViewOfFile(mapping,FILE_MAP_READ,0,0,sizeof(shared));CHECK(writeView&&readView);directMotionStore(writeView,&directMotionCurrent);CHECK(directMotionCopy(readView,&s)&&s.xy[0]==60);UnmapViewOfFile(writeView);UnmapViewOfFile(readView);CloseHandle(mapping);
 directMotionEnabled=0;unsigned count=directMotionCurrent.samples;anchorDonorFrame();CHECK(directMotionCurrent.samples==count);
 directMotionSourceStop();CHECK(directMotionCopy(&shared,&s)&&s.magic==0);directMotionView=NULL;donorAnchorMotionSample=NULL;directMotionSourceTick();
 puts("Direct motion: both anchor phases accumulated once, Z/root preserved, repeated reads zero delta, source reset/freshness/hash/basis bounds, odd sequence rejection and read-only mapping PASS");return 0;
}
