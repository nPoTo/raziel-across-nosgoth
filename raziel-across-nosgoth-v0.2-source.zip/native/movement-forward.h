#include "session-budget.h"
#include "report-path.h"
// Default-off experiment: forward only the verified player's ground motion.
#include "movement-packet.h"
#include "render-memory.h"
#include "exploration-sheets.h"
static volatile LONG movementEnabled;
static bool movementRequested;
static ULONGLONG movementBegin,movementPreviousTick;
static uint32_t movementPreviousPid;
static unsigned movementForwarded;
static bool (*movementReadPacket)(unsigned char[80])=renderMemoryMovementCopy;
static bool movementLoad(float *target,uint64_t *sourceTick,int32_t time,uint64_t now){
 unsigned char packet[80];bool ok=movementReadPacket(packet);
 if(!ok||!movementPacketTarget(packet,sizeof(packet),now,overlayLivePid,overlayLiveTick,time,target,sourceTick))return false;
 if(movementPreviousPid==overlayLivePid&&*sourceTick<movementPreviousTick)return false;
 movementPreviousPid=overlayLivePid;movementPreviousTick=*sourceTick;return true;
}
static bool movementScope(uintptr_t player,uintptr_t caller,unsigned kind,uint64_t now,const float root[16],int32_t time){
 uintptr_t module=(uintptr_t)InterlockedCompareExchangePointer(&verifiedSr1Module,NULL,NULL);DWORD foreground=0;int32_t velocity=0;
 GetWindowThreadProcessId(GetForegroundWindow(),&foreground);
 return InterlockedCompareExchange(&movementEnabled,0,0)&&movementBegin&&now>=movementBegin&&sessionBudget(movementBegin,now,(uint64_t)sheet_diagnosticLimits_controls.durationMs)&&
  module&&(caller==module+(kind?0xfc880:0xfc864)||caller==module+(kind?0xfe985:0xfe969))&&
  worldLastDraw&&now>=worldLastDraw&&now-worldLastDraw<250&&player==worldLastInstance&&root[10]>.8f&&
  time>0&&time<=8192&&foreground==GetCurrentProcessId()&&srGroundMovementInput()&&worldRead(player+0x2d4,&velocity,4)&&velocity==0;
}
static void movementTick(void){
 bool requested=GetFileAttributesW(PROBE_PATH(L"\\movement-sr1.enable"))!=INVALID_FILE_ATTRIBUTES&&
  GetFileAttributesW(PROBE_PATH(L"\\world-sr1.enable"))!=INVALID_FILE_ATTRIBUTES&&GetFileAttributesW(PROBE_PATH(L"\\replace-sr1.enable"))!=INVALID_FILE_ATTRIBUTES;
 if(requested!=movementRequested){movementRequested=requested;movementBegin=requested?GetTickCount64():0;movementPreviousTick=0;movementPreviousPid=0;movementForwarded=0;
  InterlockedExchange(&movementEnabled,requested);logLine("SR1_MOVEMENT enabled=%d; RAM command, bounded%ums, ground-only, native fallback",requested,(unsigned)sheet_diagnosticLimits_controls.durationMs);}
}

