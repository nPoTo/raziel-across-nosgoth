// SPDX-License-Identifier: GPL-3.0-or-later
#pragma once
#include <windows.h>
#include <stdbool.h>
#include <stdint.h>
#include <string.h>
#include "exploration-sheets.h"
typedef bool (*HostBlockRead)(void *,uintptr_t,void *,SIZE_T);
typedef bool (*HostBlockCode)(void *,uintptr_t,uintptr_t);
typedef struct {uint32_t callbackRva,readIndex,writeIndex,messageId;bool pending,payloadZero;} HostBlockSection;
typedef struct {bool valid,engagementPresent,entryPresent,heldPresent,slotsEqual,relationKnown,relationEqual,ownerRelationZero,targetRelationZero;uint32_t flagsMask;HostBlockSection sections[3];} HostBlockState;
typedef struct {uintptr_t callback;int32_t readIndex,writeIndex;uint32_t messageId;uintptr_t payload;bool pending;} HostBlockSectionSnapshot;
typedef struct {uintptr_t actor,owner,engagement,entry,held;unsigned char flags;uint32_t ownerRelation,targetRelation;bool ownerRelationRead,targetRelationRead;HostBlockSectionSnapshot sections[3];} HostBlockSnapshot;
static inline bool hostBlockField(void *context,HostBlockRead read,uintptr_t address,uintptr_t offset,void *out,SIZE_T size){return address&&offset<=UINTPTR_MAX-address&&size<=UINTPTR_MAX-address-offset&&read(context,address+offset,out,size);}
static inline bool hostBlockSnapshot(void *context,HostBlockRead read,uintptr_t base,uintptr_t actor,HostBlockSnapshot *s){
 const Sheet_hostBlockStateProbe *p=&sheet_hostBlockStateProbe_current;memset(s,0,sizeof(*s));
 if(!read(context,base+(uintptr_t)p->currentActorRva,&s->actor,8)||s->actor!=actor||
    !read(context,base+(uintptr_t)p->stateRva,&s->owner,8)||s->owner!=actor||
    !read(context,base+(uintptr_t)p->engagementPointerRva,&s->engagement,8)||
    !read(context,base+(uintptr_t)p->engagementFlagsRva,&s->flags,1))return false;
 s->flags&=3;
 if(s->engagement){if(s->engagement%8||!hostBlockField(context,read,s->engagement,(uintptr_t)p->entryTargetOffset,&s->entry,8)||!hostBlockField(context,read,s->engagement,(uintptr_t)p->heldTargetOffset,&s->held,8))return false;}
 if((s->entry&&s->entry%8)||(s->held&&s->held%8))return false;
 if(s->held){s->ownerRelationRead=hostBlockField(context,read,actor,(uintptr_t)p->ownerRelationOffset,&s->ownerRelation,4);s->targetRelationRead=hostBlockField(context,read,s->held,(uintptr_t)p->targetRelationOffset,&s->targetRelation,4);}
 for(unsigned i=0;i<3;i++){
  const uintptr_t state=base+(uintptr_t)p->stateRva+i*(uintptr_t)p->sectionStride,queue=state+(uintptr_t)p->eventQueueOffset;
  HostBlockSectionSnapshot *q=&s->sections[i];
  if(!read(context,state+(uintptr_t)p->firstCallbackOffset,&q->callback,8)||!q->callback||
     !read(context,queue,&q->readIndex,4)||!read(context,queue+4,&q->writeIndex,4)||q->readIndex<0||q->readIndex>=16||q->writeIndex<0||q->writeIndex>=16)return false;
  q->pending=q->readIndex!=q->writeIndex;
  if(q->pending){const uintptr_t record=queue+8+(uintptr_t)q->readIndex*16;if(!read(context,record,&q->messageId,4)||!read(context,record+8,&q->payload,8))return false;}
 }
 return true;
}
static inline HostBlockState hostBlockStateRead(void *context,HostBlockRead read,HostBlockCode code,uintptr_t base,uint32_t imageSize,uintptr_t actor){
 HostBlockState out={0};const Sheet_hostBlockStateProbe *p=&sheet_hostBlockStateProbe_current;
 if(!read||!code||!base||!actor||actor%8||base>UINTPTR_MAX-imageSize||p->currentActorRva!=0x2a89310||p->stateRva!=0x2a88588||p->ownerOffset!=0||p->firstCallbackOffset!=0x10||p->sectionStride!=0x228||p->sectionCount!=3||p->eventQueueOffset!=0x18||p->deferQueueOffset!=0x120||p->queueReadOffset!=0||p->queueWriteOffset!=4||p->queueRecordOffset!=8||p->queueRecordBytes!=16||p->queueCapacity!=16||p->messageIdOffset!=0||p->payloadOffset!=8||p->engagementPointerRva!=0x2a88ca0||p->engagementFlagsRva!=0x2a88ca8||p->entryTargetOffset!=0||p->heldTargetOffset!=0x10||p->ownerRelationOffset!=0x118||p->targetRelationOffset!=0x64||p->pointerBytes!=8||p->relationBytes!=4||p->stableReads!=2||p->serializePointers||p->serializePayloads||imageSize<0x2a89318)return out;
 HostBlockSnapshot a,b;if(!hostBlockSnapshot(context,read,base,actor,&a)||!hostBlockSnapshot(context,read,base,actor,&b)||memcmp(&a,&b,sizeof(a)))return out;
 for(unsigned i=0;i<3;i++){HostBlockSectionSnapshot *s=&a.sections[i];if(s->callback<base||s->callback-base>=imageSize||!code(context,s->callback,base))return (HostBlockState){0};out.sections[i]=(HostBlockSection){.callbackRva=(uint32_t)(s->callback-base),.readIndex=(uint32_t)s->readIndex,.writeIndex=(uint32_t)s->writeIndex,.pending=s->pending,.messageId=s->messageId,.payloadZero=s->pending&&s->payload==0};}
 uintptr_t again=0;if(!read(context,base+(uintptr_t)p->currentActorRva,&again,8)||again!=actor||!read(context,base+(uintptr_t)p->stateRva,&again,8)||again!=actor||!read(context,base+(uintptr_t)p->engagementPointerRva,&again,8)||again!=a.engagement)return (HostBlockState){0};
 out.valid=true;out.engagementPresent=a.engagement!=0;out.entryPresent=a.entry!=0;out.heldPresent=a.held!=0;out.slotsEqual=a.entry&&a.held&&a.entry==a.held;out.flagsMask=a.flags;out.relationKnown=a.held&&a.ownerRelationRead&&a.targetRelationRead;if(out.relationKnown){out.relationEqual=a.ownerRelation==a.targetRelation;out.ownerRelationZero=!a.ownerRelation;out.targetRelationZero=!a.targetRelation;}return out;
}
