// SPDX-License-Identifier: GPL-3.0-or-later
// Bounded read-only host stream. Skeletal payload exists only in an anonymous
// pipe; the caller must not log it or persist extracted resources.
#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <tlhelp32.h>
#include <bcrypt.h>
#include <stdio.h>
#include <stdlib.h>
#include <wchar.h>
#include "host-rig-reader.h"
#include "reader-hash.h"
#include "sr1-retarget-gate.h"
#include "sr1-actor-position-read.h"
#ifdef SR1_NATIVE_EXIT_GUARD
#include "sr1-native-exit-reader.h"
#endif
#ifdef SR1_HANDOFF_CONTINUITY
#include "host-rig-continuity.h"
#include "sr1-retarget-context-reader.h"
#ifdef SR1_RIG_RETRY
#include "host-rig-acquire.h"
static uint64_t rigClockUs(void *unused){(void)unused;LARGE_INTEGER t,f;if(!QueryPerformanceCounter(&t)||!QueryPerformanceFrequency(&f)||f.QuadPart<=0)return UINT64_MAX;return (uint64_t)(t.QuadPart/f.QuadPart)*1000000+(uint64_t)(t.QuadPart%f.QuadPart)*1000000/(uint64_t)f.QuadPart;}
#endif
#endif
#ifdef SR1_NATIVE_DRAW_RECEIPT
#include "host-draw-receipt.h"
#endif
#ifdef SR1_SKELETON_CADENCE60
#include "capture-cadence.h"
#endif
static bool readAt(void *c,uintptr_t p,void *out,SIZE_T n){SIZE_T got=0;return p&&ReadProcessMemory((HANDLE)c,(LPCVOID)p,out,n,&got)&&got==n;}
#ifdef SR1_NATIVE_DRAW_RECEIPT
static bool identityResourceHash(const HostRig *r,char output[65]){
 // Exclude rotating matrix buffers; hash only the exact resource identity
 // already compared by hostDrawResourceSame. No matrices or model data.
 struct {uintptr_t fields[8];int16_t parents[66];} key;memset(&key,0,sizeof(key));
 if(r->count!=66||r->modelIndex)return false;
 key.fields[0]=r->actor;key.fields[1]=r->object;key.fields[2]=r->name;key.fields[3]=r->list;
 key.fields[4]=r->model;key.fields[5]=r->segments;key.fields[6]=(uintptr_t)r->count;key.fields[7]=(uintptr_t)r->modelIndex;
 memcpy(key.parents,r->parents,sizeof(key.parents));unsigned char digest[32];
 BCRYPT_ALG_HANDLE algorithm=NULL;BCRYPT_HASH_HANDLE hash=NULL;bool ok=false;
 if(BCryptOpenAlgorithmProvider(&algorithm,BCRYPT_SHA256_ALGORITHM,NULL,0)<0)goto done;
 if(BCryptCreateHash(algorithm,&hash,NULL,0,NULL,0,0)<0)goto done;
 if(BCryptHashData(hash,(PUCHAR)&key,sizeof(key),0)<0||BCryptFinishHash(hash,digest,sizeof(digest),0)<0)goto done;
 for(unsigned i=0;i<32;i++)sprintf(output+i*2,"%02x",digest[i]);output[64]=0;ok=true;
done:
 if(hash)BCryptDestroyHash(hash);if(algorithm)BCryptCloseAlgorithmProvider(algorithm,0);return ok;
}
#endif
#if !defined(SR1_RIG_RETRY) || defined(SR1_NATIVE_DRAW_RECEIPT)
static bool contextRead(HANDLE p,uintptr_t base,uintptr_t actor,Sr1RetargetContext *s){
#ifdef SR1_HANDOFF_CONTINUITY
 DWORD front=0;GetWindowThreadProcessId(GetForegroundWindow(),&front);return sr1RetargetReadContext(p,readAt,base,actor,front==GetProcessId(p),s);
#else
 uintptr_t owner=0,again=0,cb[3];uint16_t mode=0,mode2=0;uint32_t flags=0,flags2=0;int32_t velocity=0,velocityAfter=0;DWORD front=0;memset(s,0,sizeof(*s));GetWindowThreadProcessId(GetForegroundWindow(),&front);s->foreground=front==GetProcessId(p);
 const Sheet_retargetNativeAirGuard *air=&sheet_retargetNativeAirGuard_sr1;
 if(air->verticalVelocityOffset!=0x2d4||air->verticalVelocityBytes!=4||!air->zeroVerticalVelocityRequired||air->hostWrites||!readAt(p,base+0x2a88588,&owner,8)||owner!=actor||!readAt(p,base+0x2a89536,&mode,2)||!readAt(p,base+0x2a8950c,&flags,4)||!readAt(p,actor+air->verticalVelocityOffset,&velocity,4))return false;
 for(unsigned i=0;i<3;i++){if(!readAt(p,base+0x2a88598+i*0x228,cb+i,8)||cb[i]<base||cb[i]-base>UINT32_MAX)return false;s->callbacks[i]=(uint32_t)(cb[i]-base);}
 if(!readAt(p,base+0x2a88588,&again,8)||again!=owner||!readAt(p,base+0x2a89536,&mode2,2)||mode2!=mode||!readAt(p,base+0x2a8950c,&flags2,4)||flags2!=flags||!readAt(p,actor+air->verticalVelocityOffset,&velocityAfter,4)||velocityAfter!=velocity)return false;
 s->identity=true;s->mode=mode;s->flags=flags;s->verticalVelocityKnown=true;s->verticalVelocity=velocity;return true;
#endif
}
#endif
int wmain(int argc,wchar_t **argv){
 bool fast=false;unsigned long requested=0;uint64_t fastWall=120000;
#ifdef SR1_SKELETON_CADENCE60
 fast=argc==4&&!wcscmp(argv[2],L"--skeleton-60");
 if(fast){wchar_t *last=NULL;requested=wcstoul(argv[3],&last,10);if(!requested||*last||requested>(unsigned long)sheet_skeletonCadencePolicy_capture.maxSamples)return 1;}
#endif
 if((argc!=2&&!fast)||GetFileType(GetStdHandle(STD_OUTPUT_HANDLE))!=FILE_TYPE_PIPE)return 1;
 wchar_t *end=NULL;unsigned long pid=wcstoul(argv[1],&end,10);if(!pid||*end||pid>UINT32_MAX)return 1;
 HANDLE p=OpenProcess(PROCESS_VM_READ|PROCESS_QUERY_LIMITED_INFORMATION,FALSE,(DWORD)pid);if(!p)return 2;
 wchar_t file[32768];DWORD n=ARRAYSIZE(file);char digest[65];int result=3;
 if(!QueryFullProcessImageNameW(p,0,file,&n)||!wcsrchr(file,L'\\')||_wcsicmp(wcsrchr(file,L'\\')+1,L"SRX.exe")||!hashFile(file,digest)||strcmp(digest,"0fb3aef0530ebf0510191f934dc371b69b43574331d3623eda694b72f060db93"))goto done;
 HANDLE snap=CreateToolhelp32Snapshot(TH32CS_SNAPMODULE|TH32CS_SNAPMODULE32,(DWORD)pid);if(snap==INVALID_HANDLE_VALUE)goto done;
 MODULEENTRY32W me={.dwSize=sizeof(me)};uintptr_t base=0;
 if(Module32FirstW(snap,&me))do{if(!_wcsicmp(me.szModule,L"sr1.dll")&&hashFile(me.szExePath,digest)&&!strcmp(digest,"c006dea45509cdc3fbfab3a4230b47869c306ecdd7df8b4fd2499fd3654a2205")){base=(uintptr_t)me.modBaseAddr;break;}}while(Module32NextW(snap,&me));CloseHandle(snap);if(!base)goto done;
 FILETIME creation,exit,kernel,user;if(!GetProcessTimes(p,&creation,&exit,&kernel,&user))goto done;
 const Sheet_retargetPreviewPolicy *policy=&sheet_retargetPreviewPolicy_bounded;
 if(policy->maxSamples>4200||policy->intervalMs<33||policy->hostPhysicsWrites||policy->saveWrites||!policy->swimmingNative||!policy->flightNative||!policy->glideNative)goto done;
 HANDLE cadenceTimer=NULL;uint64_t started=GetTickCount64();
#ifdef SR1_SKELETON_CADENCE60
 LARGE_INTEGER cadenceFrequency={0},cadenceOrigin={0};
 if(fast){const Sheet_skeletonCadencePolicy *cp=&sheet_skeletonCadencePolicy_capture;if(cp->targetHz!=60||!((cp->maxSamples==7200&&cp->maxWallMs==120000)||(cp->maxSamples==8400&&cp->maxWallMs==140000)||(cp->maxSamples==12000&&cp->maxWallMs==200000))||!cp->helperOnly||cp->gameWrites)goto done;fastWall=(uint64_t)cp->maxWallMs;if(!QueryPerformanceFrequency(&cadenceFrequency)||!QueryPerformanceCounter(&cadenceOrigin))goto done;cadenceTimer=CreateWaitableTimerExW(NULL,NULL,2,TIMER_ALL_ACCESS);if(!cadenceTimer)cadenceTimer=CreateWaitableTimerW(NULL,FALSE,NULL);}
#endif
 printf("{\"type\":\"session\",\"pid\":%lu,\"creation\":\"%llu\",\"moduleSha256\":\"%s\"}\n",pid,((unsigned long long)creation.dwHighDateTime<<32)|creation.dwLowDateTime,digest);fflush(stdout);
 uintptr_t actor=0,model=0;unsigned epoch=0;
#ifdef SR1_NATIVE_EXIT_GUARD
 Sr1NativeExitLatch exitLatch={.nativeOwned=true};
#endif
#ifdef SR1_HANDOFF_CONTINUITY
 #ifndef SR1_NATIVE_DRAW_RECEIPT
 HostRigContinuity continuity={0};
#else
 HANDLE drawMapping=NULL;const HostDrawShared *drawView=NULL;
#endif
#endif
 for(unsigned long j=0;j<(fast?requested:(unsigned long)policy->maxSamples);j++){
  if(fast&&GetTickCount64()-started>=fastWall)break;
  DWORD status=0;if(!GetExitCodeProcess(p,&status)||status!=STILL_ACTIVE){result=4;goto done;}
  HostRig r;Sr1RetargetContext c={0};bool valid,context;uint64_t observedTick=0,rigTick=0;unsigned reason=0;
#ifdef SR1_HANDOFF_CONTINUITY
#ifdef SR1_NATIVE_DRAW_RECEIPT
  bool held=false;HostDrawReceipt receipt={0};HostRig current={0},after={0};
  if(!drawView){wchar_t name[96];hostDrawName(name,(DWORD)pid);drawMapping=OpenFileMappingW(FILE_MAP_READ,FALSE,name);if(drawMapping){drawView=MapViewOfFile(drawMapping,FILE_MAP_READ,0,0,sizeof(HostDrawShared));if(!drawView){CloseHandle(drawMapping);drawMapping=NULL;}}}
  bool copied=hostDrawCopy(drawView,&receipt);
  context=rigIdentitySnapshot(p,readAt,base,&current)&&contextRead(p,base,current.actor,&c)&&rigIdentitySnapshot(p,readAt,base,&after)&&hostDrawResourceSame(&current,&after);
  observedTick=GetTickCount64();uint64_t processCreation=((uint64_t)creation.dwHighDateTime<<32)|creation.dwLowDateTime;
  valid=copied&&context&&hostDrawAccept(&receipt,(DWORD)pid,processCreation,observedTick,&current,&c);
  reason=valid?0:!copied?16:!context?17:18;rigTick=valid?receipt.tick:observedTick;if(valid)r=receipt.rig;
#elif defined(SR1_RIG_RETRY)
  RigAcquisition acquisition={0};DWORD front=0;GetWindowThreadProcessId(GetForegroundWindow(),&front);
  rigAcquire(p,readAt,base,front==GetProcessId(p),sr1RetargetReadContext,rigClockUs,&acquisition);
  bool held=false;reason=acquisition.reason;c=acquisition.context;context=c.identity;
  observedTick=GetTickCount64();
  valid=hostRigContinuitySelect(&continuity,&acquisition.receipt,acquisition.coherent,acquisition.matrixRace,reason,acquisition.same,&c,observedTick,&r,&rigTick,&held);
#else
  HostRig observed={0},raceIdentity={0},current={0},after={0};bool matrixRace=false,held=false;
  bool coherent=hostRigReadClassified(p,readAt,base,&observed,&raceIdentity,&matrixRace);reason=rigReadFailure;
  // Context is a current independent observation even if matrices raced. Never
  // manufacture zero callbacks/focus from a rejected full matrix snapshot.
  bool identity=rigIdentitySnapshot(p,readAt,base,&current);
  context=identity&&contextRead(p,base,current.actor,&c);
  context=context&&rigIdentitySnapshot(p,readAt,base,&after)&&rigSameIdentity(&current,&after);
  const HostRig *receipt=coherent?&observed:matrixRace?&raceIdentity:NULL;
  bool same=context&&receipt&&rigSameIdentity(receipt,&current);observedTick=GetTickCount64();
  valid=hostRigContinuitySelect(&continuity,receipt,coherent,matrixRace,reason,same,&c,observedTick,&r,&rigTick,&held);
#endif
#else
  valid=hostRigRead(p,readAt,base,&r);reason=rigReadFailure;context=valid&&contextRead(p,base,r.actor,&c);observedTick=rigTick=GetTickCount64();
#endif
  bool allowed=context&&valid&&sr1RetargetContextAllowed(&c);
  if(valid&&(r.actor!=actor||r.model!=model)){actor=r.actor;model=r.model;epoch++;
#ifdef SR1_NATIVE_EXIT_GUARD
   exitLatch.nativeOwned=true;
#endif
  }
#ifdef SR1_NATIVE_EXIT_GUARD
  Sr1NativeExitSample exitPose={0};Sr1RetargetContext exitContext={0};HostRig exitIdentity={0};
  bool exitKnown=valid&&context&&sr1NativeExitRead(p,readAt,r.actor,&exitPose)&&contextRead(p,base,r.actor,&exitContext)&&hostDrawContextSame(&c,&exitContext)&&rigIdentitySnapshot(p,readAt,base,&exitIdentity)&&hostDrawResourceSame(&r,&exitIdentity);
  bool exitAction=context&&(sr1RetargetContextAllowed(&c)||sr1RetargetJumpContextAllowed(&c));
  bool exitAdmitted=sr1NativeExitAdmit(&exitLatch,context,exitAction,sr1NativeActionActive(&c),exitKnown,&exitPose);
  allowed=allowed&&exitAdmitted;
#endif
  printf("{\"type\":\"sample\",\"sequence\":%lu,\"tick\":%llu,\"valid\":%s,\"allowed\":%s,\"reason\":%u,\"epoch\":%u,\"callbacks\":[%u,%u,%u],\"foreground\":%s,\"contextValid\":%s,\"mode\":%u,\"flags\":%u,\"verticalVelocity\":%d",j,(unsigned long long)(valid?rigTick:observedTick),valid?"true":"false",allowed?"true":"false",reason,epoch,c.callbacks[0],c.callbacks[1],c.callbacks[2],c.foreground?"true":"false",context?"true":"false",c.mode,c.flags,c.verticalVelocity);
  int16_t actorPosition[3]={0};bool positionKnown=valid&&srActorPositionRead(p,readAt,base,r.actor,r.object,actorPosition);
  printf(",\"actorPositionValid\":%s",positionKnown?"true":"false");
  if(positionKnown)printf(",\"actorPosition\":[%d,%d,%d]",actorPosition[0],actorPosition[1],actorPosition[2]);
#ifdef SR1_HANDOFF_CONTINUITY
  printf(",\"observedTick\":%llu,\"held\":%s,\"rigAgeMs\":%llu",(unsigned long long)observedTick,held?"true":"false",(unsigned long long)(valid?observedTick-rigTick:0));
#if defined(SR1_RIG_RETRY) && !defined(SR1_NATIVE_DRAW_RECEIPT)
  printf(",\"acquisitionAttempts\":%u,\"acquisitionRetries\":%u,\"acquisitionUs\":%llu",acquisition.attempts,acquisition.retries,(unsigned long long)acquisition.elapsedUs);
#endif
#endif
#ifdef SR1_NATIVE_JUMP_POSE
  printf(",\"crouchHeld\":%s",c.crouchHeld?"true":"false");
  bool jumpAllowed=context&&sr1RetargetJumpContextAllowed(&c);
#ifdef SR1_NATIVE_EXIT_GUARD
  jumpAllowed=jumpAllowed&&exitAdmitted;
#endif
  printf(",\"jumpAllowed\":%s",jumpAllowed?"true":"false");
#endif
#ifdef SR1_NATIVE_EXIT_GUARD
  printf(",\"nativeExitKnown\":%s,\"nativeExitPending\":%s,\"nativeExitBlending\":%s,\"nativeExitAnimations\":[%u,%u,%u,%u,%u,%u]",exitKnown?"true":"false",exitLatch.nativeOwned?"true":"false",exitKnown&&sr1NativeExitBlending(&exitPose)?"true":"false",exitPose.animation[0],exitPose.animation[1],exitPose.animation[2],exitPose.animation[3],exitPose.animation[4],exitPose.animation[5]);
#endif
#ifdef SR1_NATIVE_DRAW_RECEIPT
  // Current resource/context identity has a separate lifetime from the last
  // drawable palette. Native actions may suspend drawing; this scalar channel
  // never grants bone admission or refreshes the palette's capture timestamp.
  char resourceHash[65];bool identityReady=context&&identityResourceHash(&current,resourceHash);
  printf(",\"identityValid\":%s,\"identityTick\":%llu",identityReady?"true":"false",(unsigned long long)observedTick);
  if(identityReady)printf(",\"identityActor\":\"0x%llx\",\"identityObject\":\"0x%llx\",\"identityModel\":\"0x%llx\",\"identityEpoch\":%u,\"identityResource\":\"%s\"",(unsigned long long)current.actor,(unsigned long long)current.object,(unsigned long long)current.model,epoch,resourceHash);
  unsigned drawRejectReason=valid?0:!copied?1:!receipt.valid?2:!context?3:!hostDrawResourceSame(&receipt.rig,&current)?4:!hostDrawCurrentContextCompatible(&receipt.context,&c)?5:6;
  printf(",\"nativeDrawReceipt\":true,\"drawSerial\":%llu,\"drawRejectReason\":%u",(unsigned long long)(valid?receipt.serial:0),drawRejectReason);
#endif
  if(valid){printf(",\"actor\":\"0x%llx\",\"object\":\"0x%llx\",\"model\":\"0x%llx\",\"parents\":[",(unsigned long long)r.actor,(unsigned long long)r.object,(unsigned long long)r.model);for(int i=0;i<r.count;i++)printf("%s%d",i?",":"",r.parents[i]);printf("],\"render\":[");for(int i=0;i<r.count;i++){printf("%s[",i?",":"");for(int k=0;k<13;k++){float v;memcpy(&v,r.renderBytes[i]+k*4,4);printf("%s%.9g",k?",":"",v);}putchar(']');}putchar(']');}puts("}");fflush(stdout);
#ifdef SR1_SKELETON_CADENCE60
  if(fast){LARGE_INTEGER now;QueryPerformanceCounter(&now);uint64_t due=captureNext60(cadenceOrigin.QuadPart,now.QuadPart,cadenceFrequency.QuadPart),remaining=due-now.QuadPart;LARGE_INTEGER wait;wait.QuadPart=-(LONGLONG)(remaining*10000000/(uint64_t)cadenceFrequency.QuadPart);if(cadenceTimer&&SetWaitableTimer(cadenceTimer,&wait,0,NULL,NULL,FALSE))WaitForSingleObject(cadenceTimer,50);else Sleep((DWORD)(remaining*1000/(uint64_t)cadenceFrequency.QuadPart));}
  else
#endif
  Sleep((DWORD)policy->intervalMs);
 }
#ifdef SR1_NATIVE_DRAW_RECEIPT
 if(drawView)UnmapViewOfFile(drawView);if(drawMapping)CloseHandle(drawMapping);
#endif
 if(cadenceTimer)CloseHandle(cadenceTimer);
 result=0;
done:CloseHandle(p);return result;
}
