// SPDX-License-Identifier: GPL-3.0-or-later
#pragma once
#include <windows.h>
#include <stdint.h>
#include <stdbool.h>
#include <math.h>
#include <string.h>
#include "exploration-sheets.h"
#include "skeleton-policy-identity.h"
typedef struct {
 uint32_t magic,version,hostPid,sourcePid,writerPid,active;
 uint64_t epoch,tick,hostTick,sourceTick,sequence,actor,object,model;
 float forwardPerFactor;uint32_t reserved;unsigned char policyHash[32];
} SkeletonGroundPacket;
typedef struct {volatile LONG sequence;SkeletonGroundPacket packet;} SkeletonGroundShared;
_Static_assert(sizeof(SkeletonGroundPacket)==128,"Ground command is scalar-only128bytes");
static inline void skeletonGroundName(wchar_t name[96],DWORD pid){_snwprintf(name,96,L"Local\\LOKSkeletonGround-%lu",pid);}
static inline bool skeletonGroundValid(const SkeletonGroundPacket *s,DWORD pid,uint64_t now){
 const Sheet_skeletonGroundDriverPolicy *p=&sheet_skeletonGroundDriverPolicy_skeleton_ground;
 if(p->freshMs!=150||(p->maxSessionMs!=120000&&p->maxSessionMs!=140000&&p->maxSessionMs!=200000)||p->maxNormalizedForward!=120||p->maxHostTime!=8192||p->timeDenominator!=4096||p->maxTargetStep!=240||!p->preserveNativeTurn||p->hostCoordinatesWrites||p->hostFacingWrites||!p->nativeControllerWrites||p->bodyReplacement||p->enabled)return false;
 if(!s||s->magic!=0x31475a52||s->version!=1||s->hostPid!=pid||!s->sourcePid||!s->writerPid||s->sourcePid==pid||s->writerPid==pid||s->active>
#ifdef SR1_COMBAT_TRAVEL
 3
#else
 1
#endif
 ||s->reserved||memcmp(s->policyHash,skeletonPolicyHash,32))return false;
 if(!s->epoch||!s->sequence||!s->actor||!s->object||!s->model||s->epoch>s->tick||s->tick>now||now-s->tick>150||s->tick-s->epoch>=(uint64_t)p->maxSessionMs||s->hostTick>s->tick||s->sourceTick>s->tick||s->tick-s->hostTick>150||s->tick-s->sourceTick>150)return false;
 
#ifdef SR1_COMBAT_TRAVEL
 if(s->active==2||s->active==3){const Sheet_combatTravelPolicy *c=&sheet_combatTravelPolicy_bounded;return c->attackOwnershipValue==3&&c->releaseOwnershipValue==2&&c->zeroStepOwnsMotion&&!c->enabled&&c->primaryRva==0x125340&&c->secondaryRva==0x125620&&c->freshMs==150&&c->maxStep==240&&c->maxCumulative==100000&&!c->hostPositionWrites&&!c->hostFacingWrites&&c->groundOnly&&isfinite(s->forwardPerFactor)&&fabsf(s->forwardPerFactor)<=100000;}
#endif
 return isfinite(s->forwardPerFactor)&&s->forwardPerFactor>=0&&s->forwardPerFactor<=120&&(s->active||s->forwardPerFactor==0);
}
static inline bool skeletonGroundCopy(const SkeletonGroundShared *m,SkeletonGroundPacket *s){if(!m||!s)return false;for(unsigned n=0;n<3;n++){LONG a=m->sequence;if(a&1)continue;MemoryBarrier();memcpy(s,&m->packet,sizeof(*s));MemoryBarrier();if(a==m->sequence)return true;}return false;}
static inline void skeletonGroundStore(SkeletonGroundShared *m,const SkeletonGroundPacket *s){InterlockedIncrement(&m->sequence);MemoryBarrier();memcpy(&m->packet,s,sizeof(*s));MemoryBarrier();InterlockedIncrement(&m->sequence);}
static inline bool skeletonGroundStep(const SkeletonGroundPacket *s,int32_t time,float *step){if(!s->active||time<=0||time>8192||!isfinite(s->forwardPerFactor)||s->forwardPerFactor<=.01f||s->forwardPerFactor>120)return false;*step=-s->forwardPerFactor*((float)time/4096);return isfinite(*step)&&*step>=-240&&*step<=0;}
