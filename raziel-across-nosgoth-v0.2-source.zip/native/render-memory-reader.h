// SPDX-License-Identifier: GPL-3.0-or-later
#include "render-memory.h"
static HANDLE renderMemoryMap,renderMemoryMutex,renderMemoryWriter;
static const RenderMemory *renderMemoryView;
static void renderMemoryClose(void) {
    if(renderMemoryView)UnmapViewOfFile(renderMemoryView);
    if(renderMemoryMap)CloseHandle(renderMemoryMap);
    if(renderMemoryMutex)CloseHandle(renderMemoryMutex);
    if(renderMemoryWriter)CloseHandle(renderMemoryWriter);
    renderMemoryView=NULL;renderMemoryMap=NULL;renderMemoryMutex=NULL;renderMemoryWriter=NULL;
}
static bool renderMemoryLock(void) {
    if(!renderMemoryView) {
        wchar_t name[96],mutex[96];renderMemoryNames(GetCurrentProcessId(),name,mutex);
        renderMemoryMap=OpenFileMappingW(FILE_MAP_READ,FALSE,name);
        if(!renderMemoryMap)return false;
        renderMemoryMutex=OpenMutexW(SYNCHRONIZE|MUTEX_MODIFY_STATE,FALSE,mutex);
        if(renderMemoryMutex)renderMemoryView=MapViewOfFile(renderMemoryMap,FILE_MAP_READ,0,0,sizeof(RenderMemory));
        if(!renderMemoryView){renderMemoryClose();return false;}
    }
    DWORD wait=WaitForSingleObject(renderMemoryMutex,0); // Never stall the render thread.
    if(wait==WAIT_ABANDONED){ReleaseMutex(renderMemoryMutex);renderMemoryClose();return false;}
    if(wait!=WAIT_OBJECT_0)return false;
    if(!renderMemoryHeader(renderMemoryView,GetCurrentProcessId())){ReleaseMutex(renderMemoryMutex);renderMemoryClose();return false;}
    if(!renderMemoryWriter)renderMemoryWriter=OpenProcess(SYNCHRONIZE,FALSE,renderMemoryView->writerPid);
    if(!renderMemoryWriter||WaitForSingleObject(renderMemoryWriter,0)!=WAIT_TIMEOUT){ReleaseMutex(renderMemoryMutex);renderMemoryClose();return false;}
    return true;
}
static bool (*renderMemoryAlternateCopy)(unsigned,void *,size_t);
static bool (*renderMemoryAlternateIsActive)(void);
static bool (*renderMemoryAlternateReady)(void);
static bool renderMemoryLegacyCopy(unsigned kind,void *output,size_t bytes) {
    size_t expected=kind==0?RM_GEOMETRY_BYTES:kind==1?RM_APPEARANCE_BYTES:RM_LIVE_BYTES;
    if(kind>2||!output||bytes!=expected||!renderMemoryLock())return false;
    const unsigned char *source=kind==0?renderMemoryView->geometry:kind==1?renderMemoryView->appearance:renderMemoryView->live;
    memcpy(output,source,bytes);ReleaseMutex(renderMemoryMutex);return true;
}
static bool renderMemoryCopy(unsigned kind,void *output,size_t bytes){return renderMemoryAlternateCopy?renderMemoryAlternateCopy(kind,output,bytes):renderMemoryLegacyCopy(kind,output,bytes);}
