// SPDX-License-Identifier: GPL-3.0-or-later
#pragma once
#include "host-enqueue-observer.h"
#include "host-enqueue-proof.h"
static HostEnqueueObserver hostEnqueueObserver;
static _Thread_local DonorMessageObserverThread hostEnqueueThread;
static HostNativeEnqueue hostEnqueueOriginal;
static PVOID hostEnqueueTarget;static HMODULE hostEnqueueModule;
static uintptr_t hostEnqueueBase;static uint32_t hostEnqueueImageSize;
static HANDLE hostEnqueueWorker;static volatile LONG hostEnqueueStopping,hostEnqueueEnabled,hostEnqueueActive;
static volatile LONG64 hostEnqueueSession,hostEnqueueStart,hostEnqueueHeartbeat;
static bool hostEnqueueReadLease(void *unused,DonorMessageLease *out){
 (void)unused;if(InterlockedCompareExchange(&hostEnqueueStopping,0,0)||!InterlockedCompareExchange(&hostEnqueueEnabled,0,0))return false;
 out->session=(uint64_t)InterlockedCompareExchange64(&hostEnqueueSession,0,0);out->startTick=(uint64_t)InterlockedCompareExchange64(&hostEnqueueStart,0,0);out->heartbeatTick=(uint64_t)InterlockedCompareExchange64(&hostEnqueueHeartbeat,0,0);out->nowTick=GetTickCount64();out->enabled=!InterlockedCompareExchange(&hostEnqueueStopping,0,0)&&InterlockedCompareExchange(&hostEnqueueEnabled,0,0);return true;
}
static int hostEnqueueSnapshot(void *unused,void *queue,HostEnqueueMetadata *out){
 (void)unused;if((uintptr_t)InterlockedCompareExchangePointer(&verifiedSr1Module,NULL,NULL)!=hostEnqueueBase)return -1;
 int status=hostEnqueueRead(NULL,donorMessageRead,donorMessageCode,hostEnqueueBase,hostEnqueueImageSize,(uintptr_t)queue,out);
 if(status==1){float root[16];uintptr_t actor=0;if(!worldRoot(root,&actor)||actor!=out->opaqueActor)return -1;}return status;
}
static uintptr_t __fastcall hostEnqueueHook(void *queue,uint32_t id,uintptr_t payload){
 DWORD incoming=GetLastError();InterlockedIncrement(&hostEnqueueActive);uintptr_t caller=(uintptr_t)__builtin_return_address(0);uint32_t rva=caller>=hostEnqueueBase&&caller-hostEnqueueBase<hostEnqueueImageSize?(uint32_t)(caller-hostEnqueueBase):0;
 SetLastError(incoming);uintptr_t result=hostEnqueueForward(&hostEnqueueObserver,&hostEnqueueThread,hostEnqueueOriginal,queue,id,payload,rva);DWORD outgoing=GetLastError();InterlockedDecrement(&hostEnqueueActive);SetLastError(outgoing);return result;
}
static void hostEnqueueDrain(void){
 HostEnqueueEvent e;unsigned n=0;while(n++<512&&hostEnqueuePop(&hostEnqueueObserver,&e))logLine("HOST_ENQUEUE {\"session\":\"%llu\",\"callId\":%llu,\"tickMs\":%llu,\"phase\":%u,\"threadId\":%u,\"depth\":%u,\"callerRva\":%u,\"section\":%u,\"queueKind\":%u,\"messageId\":%u,\"payloadZero\":%u,\"index\":%u,\"handlerRva\":%u,\"afterValid\":%u,\"sameActor\":%u}",(unsigned long long)e.session,(unsigned long long)e.callId,(unsigned long long)e.tickMs,e.phase,e.threadId,e.depth,e.callerRva,e.section,e.queueKind,e.messageId,e.payloadZero,e.index,e.handlerRva,e.afterValid,e.sameActor);
}
static DWORD WINAPI hostEnqueueCollect(LPVOID unused){
 (void)unused;DonorMessageSessionLease lease={0};uint64_t revoke=0;
 for(;;){
  RecordingStatus hb={0};GuidanceDescriptor d={0};uint64_t now=GetTickCount64();bool stopped=InterlockedCompareExchange(&hostEnqueueStopping,0,0)!=0;
  bool files=!stopped&&recordingReadStatus(GetCurrentProcessId(),&hb)&&recordingStatusValid(&hb,GetCurrentProcessId(),now)&&donorMessageReadGuidance(&d)&&guidanceDescriptorValid(&d,GetCurrentProcessId(),hb.writerPid,hb.total)&&d.plan==(uint32_t)sheet_hostNativeEnqueuePolicy_bounded.plan;
  uint64_t previous=lease.session;bool ready=donorMessageSessionAccept(&lease,files,d.session,d.writerPid,hb.tick,now,(uint64_t)sheet_hostNativeEnqueuePolicy_bounded.seconds*1000,(uint64_t)sheet_donorMessageObservationPolicy_bounded.leaseMs);
  if(ready){if(!previous){InterlockedExchange64(&hostEnqueueSession,(LONG64)lease.session);InterlockedExchange64(&hostEnqueueStart,(LONG64)lease.startTick);logLine("HOST_ENQUEUE_SESSION session=%llu start=%llu; original calls only",(unsigned long long)lease.session,(unsigned long long)lease.startTick);}InterlockedExchange64(&hostEnqueueHeartbeat,(LONG64)lease.heartbeatTick);InterlockedExchange(&hostEnqueueEnabled,1);}else InterlockedExchange(&hostEnqueueEnabled,0);
  hostEnqueueDrain();
  if(lease.terminal||stopped){
   if(!revoke)revoke=now;
   if(!InterlockedCompareExchange(&hostEnqueueActive,0,0)){
    hostEnqueueDrain();logLine("HOST_ENQUEUE_END session=%llu published=%llu dropped=%llu forwarded=%llu unrelated=%llu boundary=%llu lease=%llu metadata=%llu depth=%llu producer=%llu queue=%llu budget=%llu; synthetic_calls=0",(unsigned long long)lease.session,(unsigned long long)hostEnqueueObserver.published,(unsigned long long)hostEnqueueObserver.dropped,(unsigned long long)hostEnqueueObserver.forwarded,(unsigned long long)hostEnqueueObserver.unrelated,(unsigned long long)hostEnqueueObserver.boundaryRejected,(unsigned long long)hostEnqueueObserver.leaseDrops,(unsigned long long)hostEnqueueObserver.metadataDrops,(unsigned long long)hostEnqueueObserver.depthDrops,(unsigned long long)hostEnqueueObserver.producerDrops,(unsigned long long)hostEnqueueObserver.queueDrops,(unsigned long long)hostEnqueueObserver.budgetDrops);return 0;
   }
   if(now-revoke>=3000){logLine("HOST_ENQUEUE_SHUTDOWN active calls; END withheld");return 1;}
  }
  Sleep(50);
 }
}
static bool hostEnqueueInstall(HMODULE module){
 if(hostEnqueueTarget)return (uintptr_t)module==hostEnqueueBase;
 if(hostEnqueueModule||hostEnqueueWorker)return false;
 IMAGE_DOS_HEADER dos={0};IMAGE_NT_HEADERS64 nt={0};uintptr_t base=(uintptr_t)module;unsigned char body[HOST_ENQUEUE_BYTES];char digest[65];
 if(!worldRead(base,&dos,sizeof(dos))||dos.e_magic!=IMAGE_DOS_SIGNATURE||dos.e_lfanew<=0||dos.e_lfanew>0x100000||!worldRead(base+(uintptr_t)dos.e_lfanew,&nt,sizeof(nt))||nt.Signature!=IMAGE_NT_SIGNATURE||nt.OptionalHeader.Magic!=IMAGE_NT_OPTIONAL_HDR64_MAGIC||nt.OptionalHeader.SizeOfImage<0x2a89318||!worldRead(base+HOST_ENQUEUE_RVA,body,sizeof(body))||!hashBytes(body,sizeof(body),digest)||strcmp(digest,HOST_ENQUEUE_SHA256))return false;
 hostEnqueueBase=base;hostEnqueueImageSize=nt.OptionalHeader.SizeOfImage;
 if(!GetModuleHandleExW(GET_MODULE_HANDLE_EX_FLAG_FROM_ADDRESS,(LPCWSTR)(base+HOST_ENQUEUE_RVA),&hostEnqueueModule)||hostEnqueueModule!=module)return false;
 hostEnqueueInit(&hostEnqueueObserver,NULL,hostEnqueueReadLease,hostEnqueueSnapshot);if(!hostEnqueueObserver.configured)return false;
 MH_STATUS init=MH_Initialize();if(init!=MH_OK&&init!=MH_ERROR_ALREADY_INITIALIZED)return false;PVOID target=(PVOID)(base+HOST_ENQUEUE_RVA);
 if(MH_CreateHook(target,(PVOID)hostEnqueueHook,(PVOID *)&hostEnqueueOriginal)!=MH_OK||!hostEnqueueOriginal)return false;
 if(MH_EnableHook(target)!=MH_OK){MH_RemoveHook(target);return false;}hostEnqueueTarget=target;
 hostEnqueueWorker=CreateThread(NULL,0,hostEnqueueCollect,NULL,0,NULL);if(!hostEnqueueWorker){MH_STATUS disabled=MH_DisableHook(target);if(disabled==MH_OK||disabled==MH_ERROR_DISABLED)hostEnqueueTarget=NULL;return false;}
 logLine("CAPABILITY host_native_enqueue_observation=1; exact supported SR1 queues, no synthetic calls");return true;
}
static bool hostEnqueueStop(void){
 bool complete=true;InterlockedExchange(&hostEnqueueStopping,1);InterlockedExchange(&hostEnqueueEnabled,0);
 if(hostEnqueueTarget){MH_STATUS status=MH_DisableHook(hostEnqueueTarget);if(status==MH_OK||status==MH_ERROR_DISABLED)hostEnqueueTarget=NULL;else complete=false;}
 if(hostEnqueueWorker){DWORD waited=WaitForSingleObject(hostEnqueueWorker,5000);if(waited==WAIT_OBJECT_0){DWORD code=1;if(!GetExitCodeThread(hostEnqueueWorker,&code)||code)complete=false;if(CloseHandle(hostEnqueueWorker))hostEnqueueWorker=NULL;else complete=false;}else complete=false;}
 // A callback may have entered just before its active counter increment. Keep
 // the module reference and trampoline until process exit in this diagnostic;
 // this is not a verified portable module-unload/restart capability.
 if(InterlockedCompareExchange(&hostEnqueueActive,0,0))complete=false;
 logLine("HOST_ENQUEUE_SHUTDOWN complete=%d; module reference/trampoline retained until process exit",complete);return complete;
}
