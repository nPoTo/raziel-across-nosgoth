// SPDX-License-Identifier: GPL-3.0-or-later
#pragma once
#include "host-draw-receipt.h"
#include "sr1-retarget-context-reader.h"
static PVOID hostDrawView;static HANDLE hostDrawMapping;static uint64_t hostDrawCreation;
static volatile LONG hostDrawBusy;static volatile LONG64 hostDrawPublished,hostDrawRejected;
static void hostDrawInitialize(void){
 if(hostDrawView||!hostDrawPolicy())return;FILETIME c,e,k,u;
 if(!GetProcessTimes(GetCurrentProcess(),&c,&e,&k,&u))return;
 wchar_t name[96];hostDrawName(name,GetCurrentProcessId());
 HANDLE m=CreateFileMappingW(INVALID_HANDLE_VALUE,NULL,PAGE_READWRITE,0,sizeof(HostDrawShared),name);
 if(!m)return;if(GetLastError()==ERROR_ALREADY_EXISTS){CloseHandle(m);return;}
 PVOID v=MapViewOfFile(m,FILE_MAP_WRITE|FILE_MAP_READ,0,0,sizeof(HostDrawShared));if(!v){CloseHandle(m);return;}
 hostDrawCreation=((uint64_t)c.dwHighDateTime<<32)|c.dwLowDateTime;hostDrawMapping=m;InterlockedExchangePointer(&hostDrawView,v);
}
static bool hostDrawContext(uintptr_t base,uintptr_t actor,Sr1RetargetContext *c){DWORD front=0;GetWindowThreadProcessId(GetForegroundWindow(),&front);return sr1RetargetReadContext(NULL,sr1SkeletonRead,base,actor,front==GetCurrentProcessId(),c);}
static void hostDrawPublish(const HostRig *rig,const Sr1RetargetContext *before,uintptr_t base,uintptr_t original,uint64_t tick){
 HostDrawShared *view=InterlockedCompareExchangePointer(&hostDrawView,NULL,NULL);if(!view||InterlockedCompareExchange(&hostDrawBusy,1,0))return;
 HostDrawReceipt s={.magic=0x31524448,.version=1,.pid=GetCurrentProcessId(),.creation=hostDrawCreation,.tick=tick};HostRig after={0};Sr1RetargetContext context={0};unsigned char matrices[66][52];
 bool ok=rig&&before&&rig->render==original&&rigIdentitySnapshot(NULL,sr1SkeletonRead,base,&after)&&rigSameIdentity(rig,&after)&&worldRead(original,matrices,sizeof(matrices))&&!memcmp(matrices,rig->renderBytes,sizeof(matrices))&&hostDrawContext(base,rig->actor,&context)&&hostDrawContextSame(before,&context);
 if(ok){s.valid=1;s.rig=*rig;s.context=*before;s.serial=(uint64_t)InterlockedIncrement64(&hostDrawPublished);memcpy(s.policy,skeletonPolicyHash,32);}else InterlockedIncrement64(&hostDrawRejected);
 hostDrawStore(view,&s);InterlockedExchange(&hostDrawBusy,0);
}
static void hostDrawClear(void){HostDrawShared *v=InterlockedCompareExchangePointer(&hostDrawView,NULL,NULL);if(v&&!InterlockedCompareExchange(&hostDrawBusy,1,0)){HostDrawReceipt s={0};hostDrawStore(v,&s);InterlockedExchange(&hostDrawBusy,0);}}
