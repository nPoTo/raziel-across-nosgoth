// SPDX-License-Identifier: GPL-3.0-or-later
#include <windows.h>
#include <stdint.h>
#include <stdbool.h>
#include <stdio.h>
#include <string.h>
#include <math.h>
#include <assert.h>
#include <stdarg.h>
#include "host-contact-source.h"
#define PROBE_PATH(s) L"C:\\nonexistent-contact-fixture" s
static uintptr_t donorProcessBase=0x100000,actor=0x200000;
static float state[3]={100,100,0};
static PVOID donorContactTargets[3]={(PVOID)1,(PVOID)2,(PVOID)3};
static uintptr_t donorContactObservedActor;
static bool donorContactObservedGround,scopeOpen;
static unsigned collisionCalls;
static void fixtureCollision(uintptr_t a,uint64_t b,uint64_t c){
 assert(b==0x123456789abcdef0ULL&&c==0xfedcba9876543210ULL);collisionCalls++;
 if(a!=actor)return;
 donorContactObservedActor=a;donorContactObservedGround=true;
 if(scopeOpen){state[0]=90;state[2]=-200;}
}
static void (*donorContactOriginalCollision)(uintptr_t,uint64_t,uint64_t)=fixtureCollision;
static void logLine(const char *format,...){(void)format;}
static bool donorProcessIdentity(uintptr_t a){return a==actor;}
static void donorProcessFindModel(void){}
static bool hashFile(const wchar_t *file,char sha[65]){(void)file;(void)sha;return false;}
static bool worldRead(uintptr_t address,void *out,size_t n){
 if(address==donorProcessBase+0xc5aa78&&n==8){memcpy(out,&actor,8);return true;}
 for(unsigned i=0;i<3;i++){const unsigned offsets[]={0x28,0x38,0x170};if(address==actor+offsets[i]&&n==4){memcpy(out,state+i,4);return true;}}
 return false;
}
static BOOL fixtureWrite(HANDLE p,void *address,const void *value,SIZE_T bytes,SIZE_T *written){
 (void)p;const unsigned offsets[]={0x28,0x38,0x170};
 for(unsigned i=0;i<3;i++)if((uintptr_t)address==actor+offsets[i]&&bytes==4){memcpy(state+i,value,4);*written=4;return TRUE;}
 *written=0;return FALSE;
}
static bool donorContactRuntimeBegin(uintptr_t a,unsigned phase,uint64_t seq,uint64_t tick){assert(a==actor&&phase>=1&&phase<=2&&seq&&tick&&!scopeOpen);scopeOpen=true;return true;}
static bool donorContactRuntimeEnd(unsigned *queries){assert(scopeOpen);scopeOpen=false;*queries=1;return true;}
#define WriteProcessMemory fixtureWrite
#include "donor-contact-frame-owner.h"
#undef WriteProcessMemory
int main(void){
 HostContactSource source={0};uint64_t now=GetTickCount64();assert(hostContactSourceOpen(&source,now));
 HostContactSnapshot s={.tick=now,.sequence=1,.actor=0x1234,.phase=1,.control=8,.coherent=1};
 hostContactSourcePublish(&source,s);
 HostContactLease expected={.pid=GetCurrentProcessId(),.creation=source.creation,.epoch=now,.actor=s.actor};
 assert(donorContactOwnerArm(expected));
 // An update boundary without collision cannot acquire support (v2 failure).
 assert(donorContactOwnerBefore());donorContactOwnerAfter();
 assert(!donorContactVertical.acquired);
 donorContactCollision(actor+1,0x123456789abcdef0ULL,0xfedcba9876543210ULL);
 assert(collisionCalls==1&&!donorContactVertical.acquired);
 donorContactCollision(actor,0x123456789abcdef0ULL,0xfedcba9876543210ULL);
 assert(collisionCalls==2);
 assert(donorContactVertical.acquired&&!scopeOpen);
 s.phase=2;s.sequence++;s.tick=GetTickCount64();hostContactSourcePublish(&source,s);
 donorContactCollision(actor,0x123456789abcdef0ULL,0xfedcba9876543210ULL);
 assert(collisionCalls==3);
 assert(!scopeOpen&&state[0]==100&&state[1]==100&&state[2]==-200);
 s.phase=3;s.control=0x101;s.callbacks[0]=s.callbacks[1]=s.callbacks[2]=0xedb40;
 s.sequence++;s.tick=GetTickCount64();hostContactSourcePublish(&source,s);
 donorContactCollision(actor,0x123456789abcdef0ULL,0xfedcba9876543210ULL);
 assert(collisionCalls==4&&donorContactProjectedFrame&&!scopeOpen);
 assert(donorContactEvents[(donorContactHead+127)%128].phase==3&&donorContactEvents[(donorContactHead+127)%128].queries==1);
 assert(!donorContactOwnerStop()); // worker cannot write Z/VZ
 assert(state[2]==-200&&donorContactReady);
 donorContactCollision(actor,0x123456789abcdef0ULL,0xfedcba9876543210ULL);
 assert(collisionCalls==5); // next collision restores, original still once
 assert(state[0]==100&&state[1]==100&&state[2]==0&&donorContactFinished);
 assert(donorContactOwnerStop()&&!donorContactOwnerArm(expected));
 hostContactSourceStop(&source);
 (void)donorContactOwnerTick;
 puts("PASS frame owner with real RAM mapping: quiet acquire, air projection scope, pin preserves velocity, worker cancellation defers restoration to owner, no rearm");
}
