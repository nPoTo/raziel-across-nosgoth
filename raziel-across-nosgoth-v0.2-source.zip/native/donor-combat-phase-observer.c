// SPDX-License-Identifier: GPL-3.0-or-later
#define wmain legacyTelemetryEntryUnused
#include "raziel-telemetry.c"
#undef wmain
#include "donor-combat-phase.h"
int wmain(int argc,wchar_t **argv){
 unsigned long pid=0,samples=0;if(argc!=3||!number(argv[1],0xffffffffUL,&pid)||!number(argv[2],(unsigned long)sheet_combatPhaseProbe_current.samples,&samples))return 1;
 HANDLE p=OpenProcess(PROCESS_VM_READ|PROCESS_QUERY_LIMITED_INFORMATION,FALSE,pid);if(!p)return 2;
 wchar_t exe[32768],expected[32768];DWORD len=ARRAYSIZE(exe),n=GetEnvironmentVariableW(L"RAZIEL_DEFIANCE_EXE",expected,ARRAYSIZE(expected));char digest[65];
 if(!n||n>=ARRAYSIZE(expected)||!QueryFullProcessImageNameW(p,0,exe,&len)||_wcsicmp(exe,expected)||!hashFile(exe,digest)||strcmp(digest,supportedHash)){CloseHandle(p);return 3;}
 HANDLE modules=CreateToolhelp32Snapshot(TH32CS_SNAPMODULE,pid);MODULEENTRY32W m={0};m.dwSize=sizeof(m);uintptr_t base=0;DWORD size=0;
 if(modules!=INVALID_HANDLE_VALUE){if(Module32FirstW(modules,&m))do{if(!_wcsicmp(m.szExePath,exe)){base=(uintptr_t)m.modBaseAddr;size=m.modBaseSize;break;}}while(Module32NextW(modules,&m));CloseHandle(modules);}
 FILETIME created,exited,kernel,user;if(!base||size<0x113fff8||!GetProcessTimes(p,&created,&exited,&kernel,&user)){CloseHandle(p);return 4;}
 uintptr_t registry=findContext(p,base),model=0;if(!registry||!razielModel(p,registry,&model)||!model){CloseHandle(p);return 5;}
 printf("{\"type\":\"session\",\"pid\":%lu,\"sha256\":\"%s\",\"processCreation\":\"%llu\",\"mode\":\"read-only-combat-phase\"}\n",pid,digest,(unsigned long long)(((uint64_t)created.dwHighDateTime<<32)|created.dwLowDateTime));
 for(unsigned i=0;i<samples;i++){
  CombatPhaseObservation o=combatPhaseObserve(p,donorStateRead,donorStateCode,base,size,model);DWORD foreground=0;GetWindowThreadProcessId(GetForegroundWindow(),&foreground);
  printf("{\"type\":\"sample\",\"sequence\":%u,\"tickMs\":%llu,\"foregroundPid\":%lu,\"valid\":%s,\"reason\":%u,\"attempts\":%u",i,GetTickCount64(),foreground,o.valid?"true":"false",o.reason,o.attempts);
  if(o.valid){const CombatPhaseSnapshot *s=&o.data;
   fputs(",\"input\":[",stdout);for(unsigned j=0;j<26;j++)printf("%s%d",j?",":"",s->input[j]);fputc(']',stdout);
   printf(",\"physicsMode\":%u,\"actionKind\":%u,\"scalar\":%d,\"scale\":%.9g,\"clock\":%.9g,\"actorFactor\":%.9g,\"frameFactor\":%.9g,\"descriptorPresent\":%s,\"airDescriptor\":[%u,%u,%u,%u]",s->physicsMode,s->actionKind,s->scalar,(double)s->scalar/4096,s->clock,s->actorFactor,s->frameFactor,s->descriptor?"true":"false",s->initial,s->increment,s->cap,s->threshold);
   printf(",\"primary\":[%u,%u,%u],\"secondary\":[%u,%u,%u]",s->sections.sections[0].firstRva,s->sections.sections[1].firstRva,s->sections.sections[2].firstRva,s->sections.sections[0].secondRva,s->sections.sections[1].secondRva,s->sections.sections[2].secondRva);
   printf(",\"position\":[%.9g,%.9g,%.9g],\"velocity\":[%.9g,%.9g,%.9g],\"acceleration\":[%.9g,%.9g,%.9g]",s->position[0],s->position[1],s->position[2],s->velocity[0],s->velocity[1],s->velocity[2],s->acceleration[0],s->acceleration[1],s->acceleration[2]);
  }
  puts("}");fflush(stdout);if(i+1<samples)Sleep((DWORD)sheet_combatPhaseProbe_current.intervalMs);
 }CloseHandle(p);return 0;
}
