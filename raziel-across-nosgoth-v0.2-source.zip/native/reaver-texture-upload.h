// SPDX-License-Identifier: GPL-3.0-or-later
#pragma once
#include "reaver-texture-generation.h"
#include "reaver-texture-packet.h"
static bool reaverTexturePacketUpload(ReaverTextureGeneration *bank,const unsigned char *b,size_t size,const ReaverPacketSession *session){
 if(!bank||!reaverTexturePacket(b,size,session))return false;
 ReaverTextureView views[128]={0};unsigned count=reaverPacketU32(b+104);
 for(unsigned i=0;i<count;i++){const unsigned char *a=b+128+i*32;
  views[i]=(ReaverTextureView){reaverPacketU32(a),reaverPacketU32(a+4),reaverPacketU32(a+8),reaverPacketU32(a+12),reaverPacketU32(a+20),b+reaverPacketU32(a+16),reaverPacketU32(a+24)!=0,reaverPacketU32(a+28)!=0};
 }
 return reaverTexturesCommit(bank,session->textureGeneration,views,count);
}
