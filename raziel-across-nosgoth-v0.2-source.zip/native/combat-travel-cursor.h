// SPDX-License-Identifier: GPL-3.0-or-later
#pragma once
typedef struct {uint64_t epoch,sequence,tick,actor;uint32_t sourcePid;float total;bool ready;} CombatTravelCursor;
// Consume the cumulative source once. Native handoff/stale gaps discard backlog.
static bool combatTravelStep(CombatTravelCursor *c,uint64_t epoch,uint64_t sequence,uint64_t tick,uintptr_t actor,uint32_t sourcePid,float total,bool allowed,float *step){
 *step=0;if(!epoch||!sequence||!tick||!actor||!sourcePid||!isfinite(total)||fabsf(total)>100000)return false;
 bool identity=c->ready&&c->epoch==epoch&&c->actor==actor&&c->sourcePid==sourcePid;
 if(identity&&(sequence<c->sequence||tick<c->tick))return false;
 if(identity&&sequence==c->sequence)return tick==c->tick&&total==c->total;
 float delta=identity?total-c->total:0;bool continuous=identity&&tick-c->tick<=150;
 *c=(CombatTravelCursor){epoch,sequence,tick,actor,sourcePid,total,true};
 if(!allowed||!continuous)return true;
 if(!isfinite(delta)||fabsf(delta)>240)return false;
 *step=-delta;return true;
}
