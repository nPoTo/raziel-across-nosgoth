// SPDX-License-Identifier: GPL-3.0-or-later
// Synthetic executable thunks only: no game or OS code is patched by this test.
#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <stdint.h>
#include <stdio.h>
#include <string.h>
#include <MinHook.h>
typedef int (__fastcall *CallFn)(int,int);
static CallFn previous;static unsigned wrappers;
static int __fastcall wrapper(int a,int b){wrappers++;return previous(a,b);}
int main(void){
 unsigned char *code=VirtualAlloc(NULL,4096,MEM_COMMIT|MEM_RESERVE,PAGE_READWRITE);if(!code)return 1;memset(code,0x90,4096);
 // A pre-existing redirect to a second implementation: increment counter, return a+b+17.
 const unsigned char redirect[]={0xe9,59,0,0,0},implementation[]={0xff,0x05,58,0,0,0,0x8b,0xc1,0x03,0xc2,0x83,0xc0,17,0xc3};memcpy(code,redirect,sizeof(redirect));memcpy(code+64,implementation,sizeof(implementation));memset(code+128,0,4);
 DWORD old;if(!VirtualProtect(code,4096,PAGE_EXECUTE_READWRITE,&old))return 2;FlushInstructionCache(GetCurrentProcess(),code,4096);CallFn call=(CallFn)(uintptr_t)code;
 if(call(3,4)!=24||*(uint32_t *)(code+128)!=1)return 3;
 if(MH_Initialize()!=MH_OK||MH_CreateHook(code,(PVOID)&wrapper,(PVOID *)&previous)!=MH_OK||MH_EnableHook(code)!=MH_OK)return 4;
 if(call(9,10)!=36||wrappers!=1||*(uint32_t *)(code+128)!=2)return 5;
 if(MH_DisableHook(code)!=MH_OK||call(1,2)!=20||wrappers!=1||*(uint32_t *)(code+128)!=3||memcmp(code,redirect,sizeof(redirect)))return 6;
 if(MH_RemoveHook(code)!=MH_OK||MH_Uninitialize()!=MH_OK)return 7;VirtualFree(code,0,MEM_RELEASE);
 puts("PASS: pre-existing redirect preserved in original trampoline, original args/results/one call, owned-hook removal preserves prior redirect");return 0;
}
