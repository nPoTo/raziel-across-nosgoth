// SPDX-License-Identifier: GPL-3.0-or-later
// Forwarding-only scalar observation. No synthetic messages or game-state writes.
#pragma once
#include "donor-state-sections.h"
#include "donor-message-observer.h"
#include "donor-message-lease.h"
#include "donor-message-collector.h"
static DonorMessageObserver donorMessageObserver;
static DonorMessageCollector donorMessageCollector;
// This toolchain emits native Windows TLS directly, without lazy emutls calls.
static _Thread_local DonorMessageObserverThread donorMessageThreadState;
static DonorNativeMessageDispatch donorMessageOriginal;
static PVOID donorMessageTarget;
static uintptr_t donorMessageBase;
static uint32_t donorMessageImageSize;
static HANDLE donorMessageWorker;
static volatile LONG donorMessageStopRequested,donorMessageEnabled,donorMessageActiveCalls;
static volatile LONG64 donorMessageSession,donorMessageStart,donorMessageHeartbeat;
static bool donorMessageRead(void *unused,uintptr_t address,void *out,SIZE_T size){(void)unused;return worldRead(address,out,size);}
static bool donorMessageCode(void *unused,uintptr_t address,uintptr_t base){
 (void)unused;MEMORY_BASIC_INFORMATION m={0};return VirtualQuery((void *)address,&m,sizeof(m))==sizeof(m)&&m.State==MEM_COMMIT&&m.Type==MEM_IMAGE&&(uintptr_t)m.AllocationBase==base&&!(m.Protect&(PAGE_GUARD|PAGE_NOACCESS))&&(m.Protect&(PAGE_EXECUTE|PAGE_EXECUTE_READ|PAGE_EXECUTE_READWRITE|PAGE_EXECUTE_WRITECOPY));
}
static bool donorMessageLease(void *unused,DonorMessageLease *out){
 (void)unused;if(InterlockedCompareExchange(&donorMessageStopRequested,0,0)||!InterlockedCompareExchange(&donorMessageEnabled,0,0))return false;
 out->session=(uint64_t)InterlockedCompareExchange64(&donorMessageSession,0,0);out->startTick=(uint64_t)InterlockedCompareExchange64(&donorMessageStart,0,0);out->heartbeatTick=(uint64_t)InterlockedCompareExchange64(&donorMessageHeartbeat,0,0);out->nowTick=GetTickCount64();
 out->enabled=!InterlockedCompareExchange(&donorMessageStopRequested,0,0)&&InterlockedCompareExchange(&donorMessageEnabled,0,0)&&out->session==(uint64_t)InterlockedCompareExchange64(&donorMessageSession,0,0);return true;
}
static bool donorMessageSnapshot(void *unused,void *state,int32_t section,void *message,bool after,DonorMessageMetadata *out){
 (void)unused;uintptr_t actor=0,currentState=0;const Sheet_donorActionStateProbe *p=&sheet_donorActionStateProbe_current;
 if(section<0||section>2||!worldRead(donorMessageBase+0xc5aa78,&actor,8)||!donorProcessIdentity(actor)||!worldRead(actor+(uintptr_t)p->actorStateOffset,&currentState,8)||currentState!=(uintptr_t)state)return false;
 DonorStateSections s=donorStateSectionsRead(NULL,donorMessageRead,donorMessageCode,donorMessageBase,donorMessageImageSize,actor,donorMessageBase+0xc5aa78);
 if(!s.valid||!s.ownerMatches||!worldRead(actor+(uintptr_t)p->actorStateOffset,&currentState,8)||currentState!=(uintptr_t)state)return false;
 for(unsigned k=0;k<3;k++){out->firstRva[k]=s.sections[k].firstRva;out->secondRva[k]=s.sections[k].secondRva;if(s.sections[k].secondValid)out->secondValidMask|=1U<<k;}
 if(!after){unsigned char native[16];uintptr_t payload=0;if(!worldRead((uintptr_t)message,native,sizeof(native)))return false;memcpy(&out->messageId,native,4);memcpy(&payload,native+8,8);out->payloadZero=payload==0;}
 return true;
}
static uintptr_t __fastcall donorMessageForward(void *state,int32_t section,void *message){
 DWORD incoming=GetLastError();InterlockedIncrement(&donorMessageActiveCalls);SetLastError(incoming);
 uintptr_t result=donorMessageObserverForward(&donorMessageObserver,&donorMessageThreadState,donorMessageOriginal,state,section,message);
 DWORD outgoing=GetLastError();InterlockedDecrement(&donorMessageActiveCalls);SetLastError(outgoing);return result;
}
static void donorMessageLogEvent(const DonorMessageEvent *e){
 logLine("DONOR_MESSAGE {\"session\":\"%llu\",\"callId\":%llu,\"tickMs\":%llu,\"threadId\":%u,\"depth\":%u,\"phase\":%u,\"section\":%u,\"messageId\":%u,\"payloadZero\":%u,\"afterValid\":%u,\"beforeFirstRva\":[%u,%u,%u],\"beforeSecondRva\":[%u,%u,%u],\"beforeSecondMask\":%u,\"afterFirstRva\":[%u,%u,%u],\"afterSecondRva\":[%u,%u,%u],\"afterSecondMask\":%u}",
  (unsigned long long)e->session,(unsigned long long)e->callId,(unsigned long long)e->tickMs,e->threadId,e->depth,e->phase,e->section,e->messageId,e->payloadZero,e->afterValid,e->beforeFirstRva[0],e->beforeFirstRva[1],e->beforeFirstRva[2],e->beforeSecondRva[0],e->beforeSecondRva[1],e->beforeSecondRva[2],e->beforeSecondMask,e->afterFirstRva[0],e->afterFirstRva[1],e->afterFirstRva[2],e->afterSecondRva[0],e->afterSecondRva[1],e->afterSecondRva[2],e->afterSecondMask);
}
static void donorMessageEmit(void *unused,const DonorMessageEvent *e){(void)unused;donorMessageLogEvent(e);}
static void donorMessageDrain(bool final){DonorMessageEvent e;unsigned count=0;while((final||count<DONOR_MESSAGE_OBSERVER_CAPACITY)&&donorMessageObserverPop(&donorMessageObserver,&e)){count++;donorMessageCollectorAccept(&donorMessageCollector,&e);}}
static bool donorMessageReadGuidance(GuidanceDescriptor *d){
 wchar_t path[512];_snwprintf(path,512,PROBE_PATH(L"\\guidance-%lu.bin"),GetCurrentProcessId());HANDLE f=CreateFileW(path,GENERIC_READ,FILE_SHARE_READ|FILE_SHARE_WRITE|FILE_SHARE_DELETE,NULL,OPEN_EXISTING,FILE_ATTRIBUTE_NORMAL,NULL);if(f==INVALID_HANDLE_VALUE)return false;
 LARGE_INTEGER size;DWORD n=0;bool ok=GetFileSizeEx(f,&size)&&size.QuadPart==sizeof(*d)&&ReadFile(f,d,sizeof(*d),&n,NULL)&&n==sizeof(*d);CloseHandle(f);return ok;
}
static DWORD WINAPI donorMessageCollect(LPVOID unused){
 (void)unused;DonorMessageSessionLease lease={0};uint64_t revokeTick=0;
 for(;;){
  RecordingStatus hb={0};GuidanceDescriptor d={0};uint64_t now=GetTickCount64();
  bool stopped=InterlockedCompareExchange(&donorMessageStopRequested,0,0)!=0;
  bool filesValid=!stopped&&recordingReadStatus(GetCurrentProcessId(),&hb)&&recordingStatusValid(&hb,GetCurrentProcessId(),now)&&donorMessageReadGuidance(&d)&&guidanceDescriptorValid(&d,GetCurrentProcessId(),hb.writerPid,hb.total)&&d.plan==(uint32_t)sheet_donorMessageObservationPolicy_bounded.plan;
  uint64_t previousSession=lease.session;
  bool ready=donorMessageSessionAccept(&lease,filesValid,d.session,d.writerPid,hb.tick,now,(uint64_t)sheet_donorMessageObservationPolicy_bounded.seconds*1000,(uint64_t)sheet_donorMessageObservationPolicy_bounded.leaseMs);
  if(ready){
   if(!previousSession){InterlockedExchange64(&donorMessageSession,(LONG64)lease.session);InterlockedExchange64(&donorMessageStart,(LONG64)lease.startTick);logLine("DONOR_MESSAGE_SESSION session=%llu writer=%lu start=%llu; scalar forwarding-only",(unsigned long long)lease.session,(unsigned long)lease.writer,(unsigned long long)lease.startTick);}
   donorProcessFindModel();InterlockedExchange64(&donorMessageHeartbeat,(LONG64)lease.heartbeatTick);InterlockedExchange(&donorMessageEnabled,1);
  }else InterlockedExchange(&donorMessageEnabled,0);
  donorMessageDrain(false);
  if(lease.terminal){
   // END is terminal. Every call that could have observed the lease must leave
   // before the final drain, so no successfully published row can follow END.
   if(!revokeTick)revokeTick=now;
   if(!InterlockedCompareExchange(&donorMessageActiveCalls,0,0)){donorMessageDrain(true);donorMessageCollectorFinish(&donorMessageCollector);DonorMessageObserverStats s=donorMessageObserverStatsRead(&donorMessageObserver);logLine("DONOR_MESSAGE_END session=%llu published=%llu dropped=%llu metadata_drops=%llu lease_drops=%llu sampled=%llu observed=%llu raw_dropped=%llu collector_dropped=%llu orphan_entries=%llu; no game writes",(unsigned long long)lease.session,(unsigned long long)donorMessageCollector.logged,(unsigned long long)(s.dropped+donorMessageCollector.discarded),(unsigned long long)s.metadataDrops,(unsigned long long)s.leaseDrops,(unsigned long long)donorMessageCollector.sampled,(unsigned long long)s.published,(unsigned long long)s.dropped,(unsigned long long)donorMessageCollector.discarded,(unsigned long long)donorMessageCollector.orphanEntries);return 0;}
   if(now-revokeTick>=3000){logLine("DONOR_MESSAGE_SHUTDOWN incomplete active_calls=%ld; END withheld",InterlockedCompareExchange(&donorMessageActiveCalls,0,0));return 1;}
  }else if(stopped)return 0;
  Sleep((DWORD)sheet_guidanceRenderPolicy_native.pollMs);
 }
}
static bool donorMessageInstall(HMODULE module){
 unsigned char bytes[DONOR_MESSAGE_DISPATCH_BODY_BYTES];char sha[65];IMAGE_DOS_HEADER dos={0};IMAGE_NT_HEADERS64 nt={0};donorMessageBase=(uintptr_t)module;
 if(!worldRead(donorMessageBase,&dos,sizeof(dos))||dos.e_magic!=IMAGE_DOS_SIGNATURE||dos.e_lfanew<=0||dos.e_lfanew>0x100000||!worldRead(donorMessageBase+(uintptr_t)dos.e_lfanew,&nt,sizeof(nt))||nt.Signature!=IMAGE_NT_SIGNATURE||nt.OptionalHeader.Magic!=IMAGE_NT_OPTIONAL_HDR64_MAGIC)return false;
 donorMessageImageSize=nt.OptionalHeader.SizeOfImage;if(donorMessageImageSize<=DONOR_MESSAGE_DISPATCH_RVA+sizeof(bytes)||!worldRead(donorMessageBase+DONOR_MESSAGE_DISPATCH_RVA,bytes,sizeof(bytes))||memcmp(bytes,donorMessageDispatchEntryBytes,sizeof(donorMessageDispatchEntryBytes))||!hashBytes(bytes,sizeof(bytes),sha)||strcmp(sha,DONOR_MESSAGE_DISPATCH_BODY_SHA256))return false;
 donorMessageObserverInit(&donorMessageObserver,NULL,donorMessageLease,donorMessageSnapshot);donorMessageCollectorInit(&donorMessageCollector,NULL,donorMessageEmit);PVOID target=(PVOID)(donorMessageBase+DONOR_MESSAGE_DISPATCH_RVA);
 MH_STATUS init=MH_Initialize();if(init!=MH_OK&&init!=MH_ERROR_ALREADY_INITIALIZED)return false;
 if(MH_CreateHook(target,(PVOID)donorMessageForward,(PVOID *)&donorMessageOriginal)!=MH_OK||!donorMessageOriginal)return false;
 if(MH_EnableHook(target)!=MH_OK){MH_RemoveHook(target);return false;}donorMessageTarget=target;
 donorMessageWorker=CreateThread(NULL,0,donorMessageCollect,NULL,0,NULL);if(!donorMessageWorker){MH_STATUS disabled=MH_DisableHook(target);if(disabled==MH_OK||disabled==MH_ERROR_DISABLED)donorMessageTarget=NULL;else logLine("DONOR_MESSAGE_SHUTDOWN incomplete hook_disable=%d; target ownership retained",disabled);return false;}return true;
}
static bool donorMessageStop(void){
 bool complete=true;
 InterlockedExchange(&donorMessageEnabled,0);InterlockedExchange(&donorMessageStopRequested,1);
 if(donorMessageTarget){MH_STATUS disabled=MH_DisableHook(donorMessageTarget);if(disabled==MH_OK||disabled==MH_ERROR_DISABLED)donorMessageTarget=NULL;else{complete=false;logLine("DONOR_MESSAGE_SHUTDOWN incomplete hook_disable=%d; target ownership retained",disabled);}}
 if(donorMessageWorker){DWORD waited=WaitForSingleObject(donorMessageWorker,5000);if(waited==WAIT_OBJECT_0){DWORD code=1;if(!GetExitCodeThread(donorMessageWorker,&code)||code!=0)complete=false;if(CloseHandle(donorMessageWorker))donorMessageWorker=NULL;else complete=false;}else{complete=false;logLine("DONOR_MESSAGE_SHUTDOWN incomplete worker_wait=%lu; handle retained",(unsigned long)waited);}}
 // Keep the original trampoline and pinned module alive for any in-flight call.
 logLine("DONOR_MESSAGE_SHUTDOWN complete=%d; no trampoline removal",complete);return complete;
}
