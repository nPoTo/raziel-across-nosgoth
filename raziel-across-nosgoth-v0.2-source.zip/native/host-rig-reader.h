// SPDX-License-Identifier: GPL-3.0-or-later
#pragma once
#include <windows.h>
#include <stdint.h>
#include <stdbool.h>
#include <string.h>
#include <math.h>
#include "exploration-sheets.h"
typedef bool (*RigRead)(void *,uintptr_t,void *,SIZE_T);
static unsigned rigReadFailure;
static int rigReadModelIndex,rigReadCount;
typedef struct {
 uintptr_t actor,object,name,list,model,segments,legacy,render;
 int16_t modelIndex,parents[128];int32_t count;
 unsigned char legacyBytes[128][32],renderBytes[128][52];
} HostRig;
static inline bool rigField(void *c,RigRead read,uintptr_t base,uintptr_t offset,void *out,SIZE_T bytes){
 // Byte strings need no alignment. Typed pointers are checked at admission.
 return base&&offset<=UINTPTR_MAX-base&&bytes<=UINTPTR_MAX-base-offset&&read(c,base+offset,out,bytes);
}
static inline bool rigIdentitySnapshot(void *c,RigRead read,uintptr_t base,HostRig *s){
 const Sheet_rigRead *p=&sheet_rigRead_current;char label[9];memset(s,0,sizeof(*s));
#define RIG_GATE(condition,reason) do{if(!(condition)){rigReadFailure=reason;return false;}}while(0)
 RIG_GATE(rigField(c,read,base,(uintptr_t)p->actorGlobalRva,&s->actor,8)&&s->actor&&s->actor%8==0,1);
 RIG_GATE(rigField(c,read,s->actor,(uintptr_t)p->actorObjectOffset,&s->object,8)&&s->object&&s->object%8==0,2);
 RIG_GATE(rigField(c,read,s->object,(uintptr_t)p->objectNameOffset,&s->name,8)&&rigField(c,read,s->name,0,label,9)&&!memcmp(label,"raziel__",9),3);
 RIG_GATE(rigField(c,read,s->actor,(uintptr_t)p->actorCurrentModelOffset,&s->modelIndex,2),4);rigReadModelIndex=s->modelIndex;
 RIG_GATE(s->modelIndex==0,4);
 // Resource-internal lists are packed; x64 pointer width does not establish
 // eight-byte alignment. Admission still requires the exact native layout,
 // bounded complete reads, valid hierarchy, and two identical snapshots.
 RIG_GATE(rigField(c,read,s->object,(uintptr_t)p->objectModelsOffset,&s->list,8)&&s->list,5);
 RIG_GATE(rigField(c,read,s->list,0,&s->model,8)&&s->model,6);
 RIG_GATE(rigField(c,read,s->model,(uintptr_t)p->modelCountOffset,&s->count,4),7);rigReadCount=s->count;
 RIG_GATE(s->count>=1&&s->count<=p->maxBones,7);
 RIG_GATE(rigField(c,read,s->model,(uintptr_t)p->modelSegmentsOffset,&s->segments,8)&&s->segments,8);
 RIG_GATE(rigField(c,read,s->actor,(uintptr_t)p->actorLegacyMatricesOffset,&s->legacy,8)&&s->legacy&&s->legacy%4==0&&rigField(c,read,s->actor,(uintptr_t)p->actorRenderMatricesOffset,&s->render,8)&&s->render&&s->render%4==0,9);
 for(int i=0;i<s->count;i++){
  RIG_GATE(rigField(c,read,s->segments,(uintptr_t)i*(uintptr_t)p->segmentBytes+(uintptr_t)p->segmentParentOffset,s->parents+i,2),10);
  RIG_GATE(s->parents[i]>=-1&&s->parents[i]<s->count&&s->parents[i]!=i,10);
 }
 for(int i=0;i<s->count;i++){int j=i,n=0;while(j>=0&&n++<=s->count)j=s->parents[j];RIG_GATE(j==-1,11);}
 #undef RIG_GATE
 return true;
}
static inline bool rigSameIdentity(const HostRig *a,const HostRig *b){
 return a&&b&&a->count>0&&a->count<=128&&a->actor==b->actor&&a->object==b->object&&a->name==b->name&&a->list==b->list&&a->model==b->model&&a->segments==b->segments&&a->legacy==b->legacy&&a->render==b->render&&a->modelIndex==b->modelIndex&&a->count==b->count&&!memcmp(a->parents,b->parents,(SIZE_T)a->count*sizeof(a->parents[0]));
}
static inline bool rigSnapshot(void *c,RigRead read,uintptr_t base,HostRig *s){
 if(!rigIdentitySnapshot(c,read,base,s))return false;
#define RIG_GATE(condition,reason) do{if(!(condition)){rigReadFailure=reason;return false;}}while(0)
 RIG_GATE(rigField(c,read,s->legacy,0,s->legacyBytes,(SIZE_T)s->count*32)&&rigField(c,read,s->render,0,s->renderBytes,(SIZE_T)s->count*52),12);
 for(int i=0;i<s->count;i++)for(int k=0;k<13;k++){float v;memcpy(&v,s->renderBytes[i]+k*4,4);RIG_GATE(isfinite(v)&&fabsf(v)<=1000000,13);}
#undef RIG_GATE
 return true;
}
static inline bool hostRigReadClassified(void *c,RigRead read,uintptr_t base,HostRig *out,HostRig *raceIdentity,bool *matrixRace){
 if(matrixRace)*matrixRace=false;
 const Sheet_rigRead *p=&sheet_rigRead_current;
 rigReadFailure=15;rigReadModelIndex=0;rigReadCount=0;
 if(!out||!read||!base||p->actorGlobalRva!=0x2a89310||p->actorObjectOffset!=0x30||p->objectNameOffset!=0x30||p->actorCurrentModelOffset!=0x1c6||p->objectModelsOffset!=0x10||p->modelCountOffset!=0x30||p->modelSegmentsOffset!=0x38||p->segmentBytes!=32||p->segmentParentOffset!=18||p->actorLegacyMatricesOffset!=0x68||p->actorRenderMatricesOffset!=0x70||p->legacyMatrixBytes!=32||p->renderMatrixBytes!=52||p->maxBones<1||p->maxBones>128||p->serializeResources)return false;
 HostRig a,b;if(!rigSnapshot(c,read,base,&a)||!rigSnapshot(c,read,base,&b))return false;
 if(memcmp(&a,&b,sizeof(a))){rigReadFailure=14;if(raceIdentity&&matrixRace&&rigSameIdentity(&a,&b)){*raceIdentity=b;*matrixRace=true;}return false;}
 *out=a;rigReadFailure=0;return true;
}
static inline bool hostRigRead(void *c,RigRead read,uintptr_t base,HostRig *out){return hostRigReadClassified(c,read,base,out,NULL,NULL);}
