// SPDX-License-Identifier: GPL-3.0-or-later
// Completed-input hooks only. No OS input injection, game launch, save writes
// or changes to the host's world/physics authority.
#include "dual-input-frame.h"
#include "dual-input-shared.h"
typedef void (*DualFrameFn)(void);
static DualFrameFn dualOriginal;static PVOID dualTarget;static uintptr_t dualBase;static bool dualHost;
static HANDLE dualMap,dualPeer,dualWriter;static DualInputShared *dualView;static DualInputSession dualSession;
static volatile LONG dualEnabled;static uint64_t dualBegin;static DualInputConsumer dualConsumer;
static XINPUT_STATE dualPhysical;static uint64_t dualPhysicalTick;static SRWLOCK dualPhysicalLock=SRWLOCK_INIT;
static uint64_t dualSequence;static bool dualChanged,dualNamesReady;static int dualScancodes[32];
static DualInputReleaseGate dualRelease;
static uint32_t dualBeforeMask,dualAfterMask,dualBeforePad,dualAfterPad;
static uint8_t dualBeforeKeys[512],dualAfterKeys[512],dualBeforeMouse[9],dualAfterMouse[9];
static int16_t dualBeforeSlots[26],dualAfterSlots[26],dualBeforeAxes[4],dualAfterAxes[4];
static bool dualWrite(uintptr_t address,const void *p,size_t n){SIZE_T written=0;return WriteProcessMemory(GetCurrentProcess(),(void*)address,p,n,&written)&&written==n;}
static uint64_t dualCreation(HANDLE h){FILETIME a,b,c,d;if(!GetProcessTimes(h,&a,&b,&c,&d))return 0;return ((uint64_t)a.dwHighDateTime<<32)|a.dwLowDateTime;}
static bool dualPhysicalRead(XINPUT_STATE *out){
 if(!InterlockedCompareExchange(&dualEnabled,0,0)||!TryAcquireSRWLockShared(&dualPhysicalLock))return false;
 uint64_t now=GetTickCount64();DWORD fg=0;GetWindowThreadProcessId(GetForegroundWindow(),&fg);
 bool ok=fg==GetCurrentProcessId()&&dualPhysicalTick&&now>=dualPhysicalTick&&now-dualPhysicalTick<=150;
 if(ok)*out=dualPhysical;ReleaseSRWLockShared(&dualPhysicalLock);return ok;
}
static bool dualPadRead(DualInputPad *out){
 memset(out,0,sizeof(*out));if(!originalSrInput)return true;unsigned count=0;
 for(DWORD i=0;i<4;i++){XINPUT_STATE p={0};DWORD status=originalSrInput(i,&p);if(status==ERROR_DEVICE_NOT_CONNECTED)continue;
  if(status!=ERROR_SUCCESS||++count>1)return false;
  *out=(DualInputPad){p.Gamepad.wButtons,p.Gamepad.bLeftTrigger,p.Gamepad.bRightTrigger,p.Gamepad.sThumbLX,p.Gamepad.sThumbLY,p.Gamepad.sThumbRX,p.Gamepad.sThumbRY};
 }return true;
}
static bool dualCurrentScope(uint64_t now,uintptr_t *actor){
 uintptr_t base=(uintptr_t)InterlockedCompareExchangePointer(&verifiedSr1Module,NULL,NULL),object=0;Sr1RetargetContext c={0};
 return srFreeLease&&srFreeWriter&&now>=srFreeHeartbeat&&now-srFreeHeartbeat<1500&&
  base&&srCombatInputIdentity(NULL,srRepeatRead,base,actor,&object)&&sr1RetargetReadContext(NULL,srRepeatRead,base,*actor,true,&c)&&!c.mode&&!(c.flags&0x10000000u);
}
static void dualRestore(void){
 if(!dualChanged)return;dualChanged=false;
 if(dualHost){
  // This runs BEFORE the native event pump. The post-original release path
  // also rebuilds the keyboard mask from its current raw state.
  uint32_t current=0;DualInputMaskLease l={dualBeforeMask,dualAfterMask,0xfff1,true};
  if(worldRead(dualBase+0x426064,&current,4)){current=dualInputMaskRestore(&l,current);dualWrite(dualBase+0x426064,&current,4);}
  l=(DualInputMaskLease){dualBeforePad,dualAfterPad,0xfff0,true};if(worldRead(dualBase+0x104058,&current,4)){current=dualInputMaskRestore(&l,current);dualWrite(dualBase+0x104058,&current,4);}
 }else{
  // Compare owned bytes; never restore over a foreign change. Original poll
  // follows immediately and refreshes physical inputs, including on expiry.
  const uintptr_t at[4]={0x113eca0,0x113e9d0,0x113ec00,0x17c2e10};
  const size_t sizes[4]={512,9,52,8};const void *before[4]={dualBeforeKeys,dualBeforeMouse,dualBeforeSlots,dualBeforeAxes};const void *after[4]={dualAfterKeys,dualAfterMouse,dualAfterSlots,dualAfterAxes};
  for(unsigned i=0;i<4;i++){uint8_t current[512];if(!worldRead(dualBase+at[i],current,sizes[i]))continue;
   const size_t width=i>=2?2:1;for(size_t j=0;j<sizes[i];j+=width)if(!memcmp(current+j,(const uint8_t*)after[i]+j,width))memcpy(current+j,(const uint8_t*)before[i]+j,width);dualWrite(dualBase+at[i],current,sizes[i]);}
 }
}
static void dualHostFrame(uint64_t now,DWORD fg,bool alive){
 uint8_t keys[112];DualInputBinding bindings[13];uint32_t nativeMask=0,keyboard=0,padMask=0;DualInputPad pad={0};uintptr_t actor=0;
 bool readable=worldRead(dualBase+0x426c44,keys,sizeof(keys))&&worldRead(dualBase+0x426da8,bindings,sizeof(bindings))&&
  worldRead(dualBase+0x426064,&keyboard,4)&&worldRead(dualBase+0x104058,&padMask,4)&&dualInputNativeKeyboard(keys,bindings,&nativeMask);
 uint64_t ready=dualView?(uint64_t)InterlockedCompareExchange64(&dualView->donorReady,0,0):0;
 bool padValid=dualPadRead(&pad);
 bool scope=alive&&readable&&padValid&&ready&&now>=ready&&now-ready<=150&&fg==dualSession.host&&dualCurrentScope(now,&actor);
 uint32_t kh=readable?dualInputKeys(keys):0;DualInputPad merged=dualInputMerge(kh,&pad);
 DualInputSample sample={dualSession.epoch,++dualSequence,now,merged.buttons|(merged.lt>=30?DUAL_CROUCH:0)|(merged.rt>=30?DUAL_AIM:0),merged.x,merged.y,scope};
 DualInputResult r=dualInputConsume(&dualConsumer,&sample,now,dualSession.epoch,150,scope);
 DualInputWire wire={.sequence=dualSequence,.tick=now,.held=r.held,.keys=kh&r.held,.x=r.x,.y=r.y,.rx=merged.rx,.ry=merged.ry,.lt=(r.held&DUAL_CROUCH)?merged.lt:0,.rt=(r.held&DUAL_AIM)?merged.rt:0,.valid=r.active};
 // Direction keys are axes, not button bits in the press-state consumer.
 if(r.active&&!(pad.x||pad.y))wire.keys|=kh&(DUAL_FORWARD|DUAL_BACK|DUAL_LEFT|DUAL_RIGHT);
 if(dualView){dualInputStore(dualView,&wire);InterlockedIncrement64(&dualView->hostFrames);}
 XINPUT_STATE raw={.dwPacketNumber=(DWORD)dualSequence};raw.Gamepad=(XINPUT_GAMEPAD){(WORD)r.held,wire.lt,wire.rt,r.x,r.y,merged.rx,merged.ry};
 AcquireSRWLockExclusive(&dualPhysicalLock);dualPhysical=raw;dualPhysicalTick=r.active?now:0;ReleaseSRWLockExclusive(&dualPhysicalLock);
 uint8_t nativeKeys[112];uint16_t blockedPad=0;
 if(!readable)return;
 dualInputReleaseGate(&dualRelease,keys,pad.buttons,r.active,nativeKeys,&blockedPad);
 if(!r.active){
  uint32_t clean=0;if(!dualInputNativeKeyboard(nativeKeys,bindings,&clean))return;
  uint32_t block=dualInputHostMask((DualInputPad){.buttons=blockedPad});
  dualBeforeMask=keyboard;dualAfterMask=(keyboard&~0xfff1u)|(clean&0xfff1u);dualBeforePad=padMask;dualAfterPad=padMask&~block;
  dualChanged=dualBeforeMask!=dualAfterMask||dualBeforePad!=dualAfterPad;
  if(dualChanged){dualWrite(dualBase+0x426064,&dualAfterMask,4);dualWrite(dualBase+0x104058,&dualAfterPad,4);}return;
 }
 XINPUT_STATE output=raw;output.Gamepad.wButtons=srRepeatApplyBoundary(SR_INPUT_FRAME_CHANNEL,now,true,fg,&raw,&output);
 output.Gamepad.wButtons=srFreeApplyBoundary(SR_INPUT_FRAME_CHANNEL,now,true,fg,&raw,&output);
 DualInputPad delivered={output.Gamepad.wButtons,output.Gamepad.bLeftTrigger,output.Gamepad.bRightTrigger,r.x,r.y,merged.rx,merged.ry};
 uint32_t wanted=dualInputHostMask(delivered);if(delivered.buttons&0x20)wanted|=1; // Existing Down -> native glyph/realm menu.
 dualBeforeMask=(keyboard&~0xfff1u)|(nativeMask&0xfff1u);dualAfterMask=(keyboard&~0xfff1u)|(nativeMask&1)|wanted;
 dualBeforePad=padMask;dualAfterPad=padMask&~0xfff0u;dualChanged=true;
 if(!dualWrite(dualBase+0x426064,&dualAfterMask,4)||!dualWrite(dualBase+0x104058,&dualAfterPad,4)){InterlockedExchange(&dualEnabled,0);dualRestore();}
}
static bool dualDonorNames(void){
 if(dualNamesReady)return true;HMODULE sdl=GetModuleHandleW(L"SDL3.dll");if(!sdl||sheet_dualInputFrameKeys_count>32)return false;
 typedef int (__cdecl *NameFn)(const char*);NameFn name=(NameFn)GetProcAddress(sdl,"SDL_GetScancodeFromName");if(!name)return false;
 for(unsigned i=0;i<sheet_dualInputFrameKeys_count;i++){const wchar_t *w=sheet_dualInputFrameKeys_rows[i]->donorName;char n[64];
  if(!WideCharToMultiByte(CP_UTF8,0,w,-1,n,sizeof(n),NULL,NULL))return false;
  if(!strcmp(n,"MouseLeft")){dualScancodes[i]=-1;continue;}if(!strcmp(n,"MouseRight")){dualScancodes[i]=-2;continue;}
  int code=name(n);if(code<=0||code>=512)return false;dualScancodes[i]=code;
 }dualNamesReady=true;return true;
}
static void dualDonorFrame(uint64_t now,DWORD fg,bool alive){
 if(!dualView||!dualDonorNames())return;InterlockedExchange64(&dualView->donorReady,(LONG64)now);
 DualInputWire w={0};bool scope=alive&&fg==dualSession.host&&dualInputCopy(dualView,&w)&&w.valid;
 DualInputSample s={dualSession.epoch,w.sequence,w.tick,w.held,w.x,w.y,scope};DualInputResult r=dualInputConsume(&dualConsumer,&s,now,dualSession.epoch,150,scope);
 if(!r.active)return;
 if(!worldRead(dualBase+0x113eca0,dualBeforeKeys,512)||!worldRead(dualBase+0x113e9d0,dualBeforeMouse,9)||!worldRead(dualBase+0x113ec00,dualBeforeSlots,52)||!worldRead(dualBase+0x17c2e10,dualBeforeAxes,8))return;
 memcpy(dualAfterKeys,dualBeforeKeys,512);memcpy(dualAfterMouse,dualBeforeMouse,9);
 // Original physical pad is represented by the same combined press state.
 // Clear owned slots to avoid held-entry duplicates. Navigation is retained.
 memcpy(dualAfterSlots,dualBeforeSlots,52);
 for(unsigned i=0;i<sheet_dualInputDonorSlots_count;i++){const Sheet_dualInputDonorSlots *p=sheet_dualInputDonorSlots_rows[i];dualAfterSlots[p->slot]=(r.held&p->mask)?32767:0;}
 dualAfterSlots[20]=(r.held&DUAL_CROUCH)?(int16_t)(w.lt*128):0;dualAfterSlots[21]=(r.held&DUAL_AIM)?(int16_t)(w.rt*128):0;
 // SDL vertical axis has the opposite sign to XInput. Digital keyboard
 // movement also reaches the native keyboard branch when no pad is present.
 dualAfterAxes[0]=r.x;dualAfterAxes[1]=(int16_t)(r.y==-32768?32767:-r.y);dualAfterAxes[2]=w.rx;dualAfterAxes[3]=(int16_t)(w.ry==-32768?32767:-w.ry);
 for(unsigned i=0;i<sheet_dualInputFrameKeys_count;i++){
  unsigned mask=(unsigned)sheet_dualInputFrameKeys_rows[i]->mask;bool down=(mask>=DUAL_FORWARD)?!!(w.keys&mask):!!(r.held&mask);
  if(mask>=DUAL_FORWARD&&!(r.x||r.y))down=false;
  int code=dualScancodes[i];if(code<0)dualAfterMouse[-code-1]=(uint8_t)down;else dualAfterKeys[code]=(uint8_t)down;
 }
 dualChanged=true;
 if(!dualWrite(dualBase+0x113eca0,dualAfterKeys,512)||!dualWrite(dualBase+0x113e9d0,dualAfterMouse,9)||!dualWrite(dualBase+0x113ec00,dualAfterSlots,52)||!dualWrite(dualBase+0x17c2e10,dualAfterAxes,8)){InterlockedExchange(&dualEnabled,0);dualRestore();return;}
 InterlockedIncrement64(&dualView->donorFrames);
}
static void dualFrame(void){
 dualRestore();srUnifiedFrame=dualHost&&InterlockedCompareExchange(&dualEnabled,0,0);dualOriginal();srUnifiedFrame=false;
 uint64_t now=GetTickCount64();DWORD fg=0;GetWindowThreadProcessId(GetForegroundWindow(),&fg);
 bool alive=InterlockedCompareExchange(&dualEnabled,0,0)&&dualView&&!dualView->revoked&&now>=dualBegin&&now-dualBegin<200000&&
  dualPeer&&WaitForSingleObject(dualPeer,0)==WAIT_TIMEOUT&&dualWriter&&WaitForSingleObject(dualWriter,0)==WAIT_TIMEOUT;
 if(dualHost)dualHostFrame(now,fg,alive);else dualDonorFrame(now,fg,alive);
}
static void dualInputTick(bool host,uintptr_t base){
 if(dualTarget){
  if(GetFileAttributesW(PROBE_PATH(L"\\dual-input-session.bin"))==INVALID_FILE_ATTRIBUTES||GetTickCount64()-dualBegin>=200000){InterlockedExchange(&dualEnabled,0);if(dualHost&&dualView)InterlockedExchange(&dualView->revoked,1);}
  return;
 }
 DualInputSession s={0};HANDLE f=CreateFileW(PROBE_PATH(L"\\dual-input-session.bin"),GENERIC_READ,FILE_SHARE_READ|FILE_SHARE_DELETE,NULL,OPEN_EXISTING,0,NULL);if(f==INVALID_HANDLE_VALUE)return;
 DWORD got=0;LARGE_INTEGER n;bool ok=GetFileSizeEx(f,&n)&&n.QuadPart==sizeof(s)&&ReadFile(f,&s,sizeof(s),&got,NULL)&&got==sizeof(s);CloseHandle(f);
 uint64_t now=GetTickCount64();if(!ok||s.magic!=DUAL_INPUT_MAGIC||s.version!=1||s.reserved||!s.writer||!s.host||!s.donor||s.host==s.donor||s.epoch>now||now-s.epoch>20000||GetCurrentProcessId()!=(host?s.host:s.donor)||dualCreation(GetCurrentProcess())!=(host?s.hostCreation:s.donorCreation))return;
 HANDLE peer=OpenProcess(PROCESS_QUERY_LIMITED_INFORMATION|SYNCHRONIZE,FALSE,host?s.donor:s.host),writer=OpenProcess(SYNCHRONIZE,FALSE,s.writer);
 if(!peer||!writer||dualCreation(peer)!=(host?s.donorCreation:s.hostCreation)){if(peer)CloseHandle(peer);if(writer)CloseHandle(writer);return;}
 wchar_t name[96];dualInputName(name,s.host);HANDLE map=host?CreateFileMappingW(INVALID_HANDLE_VALUE,NULL,PAGE_READWRITE,0,sizeof(DualInputShared),name):OpenFileMappingW(FILE_MAP_ALL_ACCESS,FALSE,name);
 if(!map||(host&&GetLastError()==ERROR_ALREADY_EXISTS)){if(map)CloseHandle(map);CloseHandle(peer);CloseHandle(writer);return;}
 DualInputShared *view=MapViewOfFile(map,FILE_MAP_ALL_ACCESS,0,0,sizeof(*view));if(!view){CloseHandle(map);CloseHandle(peer);CloseHandle(writer);return;}
 if(host){memset(view,0,sizeof(*view));view->session=s;}else if(memcmp(&view->session,&s,sizeof(s))){UnmapViewOfFile(view);CloseHandle(map);CloseHandle(peer);CloseHandle(writer);return;}
 const Sheet_inputFrameProof *p=host?&sheet_inputFrameProof_host:&sheet_inputFrameProof_donor;unsigned char code[6000];char sha[65],expected[65];
 bool proof=p->size<=6000&&worldRead(base+p->rva,code,(size_t)p->size)&&hashBytes(code,(ULONG)p->size,sha)&&WideCharToMultiByte(CP_UTF8,0,p->sha256,-1,expected,65,NULL,NULL)&&!strcmp(sha,expected);
 if(proof&&!host){uint8_t slots[21];proof=worldRead(base+0x5dcdf8,slots,sizeof(slots));
  for(unsigned i=0;proof&&i<sheet_dualInputDonorSlots_count;i++){const Sheet_dualInputDonorSlots *r=sheet_dualInputDonorSlots_rows[i];proof=r->index>=0&&r->index<21&&r->slot>0&&r->slot<26&&slots[r->index]==r->slot;}}
 if(!proof){UnmapViewOfFile(view);CloseHandle(map);CloseHandle(peer);CloseHandle(writer);return;}
 MH_STATUS init=MH_Initialize();PVOID target=(PVOID)(base+p->rva);
 if((init!=MH_OK&&init!=MH_ERROR_ALREADY_INITIALIZED)||MH_CreateHook(target,(PVOID)dualFrame,(PVOID*)&dualOriginal)!=MH_OK){UnmapViewOfFile(view);CloseHandle(map);CloseHandle(peer);CloseHandle(writer);return;}
 dualHost=host;dualBase=base;dualSession=s;dualView=view;dualMap=map;dualPeer=peer;dualWriter=writer;dualBegin=now;
 if(MH_EnableHook(target)==MH_OK){dualTarget=target;InterlockedExchange(&dualEnabled,1);if(host)srUnifiedInput=dualPhysicalRead;logLine("DUAL_INPUT installed host=%u; completed-frame original-once; manual gameplay pending",host);}
 else {MH_RemoveHook(target);UnmapViewOfFile(view);CloseHandle(map);CloseHandle(peer);CloseHandle(writer);dualView=NULL;}
}
static void dualInputStop(void){
 InterlockedExchange(&dualEnabled,0);if(dualHost&&dualView)InterlockedExchange(&dualView->revoked,1);
 // Keep the forwarding detour until process exit: its next original call
 // restores borrowed input on the game thread. Never free an in-flight hook.
}
#include "dual-input-runtime-selftest.h"
