// SPDX-License-Identifier: GPL-3.0-or-later
#define WIN32_LEAN_AND_MEAN
#include "sr1-ground-shared.h"
#include <stdio.h>
#include <stdlib.h>
#include <io.h>
#include <fcntl.h>
int main(int argc,char **argv){
 char *end=NULL;unsigned long pid=argc==2?strtoul(argv[1],&end,10):0;if(!pid||!end||*end||GetFileType(GetStdHandle(STD_INPUT_HANDLE))!=FILE_TYPE_PIPE)return 1;
 HANDLE host=OpenProcess(SYNCHRONIZE,FALSE,pid);if(!host)return 2;wchar_t name[96];skeletonGroundName(name,pid);SetLastError(0);HANDLE map=CreateFileMappingW(INVALID_HANDLE_VALUE,NULL,PAGE_READWRITE,0,sizeof(SkeletonGroundShared),name);bool exists=GetLastError()==ERROR_ALREADY_EXISTS;SkeletonGroundShared *view=map&&!exists?MapViewOfFile(map,FILE_MAP_WRITE|FILE_MAP_READ,0,0,sizeof(SkeletonGroundShared)):NULL;
 if(!view){if(map)CloseHandle(map);CloseHandle(host);return 3;}_setmode(_fileno(stdin),_O_BINARY);SkeletonGroundPacket s={0};unsigned frames=0;uint64_t sequence=0,epoch=0;int result=4;size_t got;
 while((got=fread(&s,1,sizeof(s),stdin))==sizeof(s)){if(WaitForSingleObject(host,0)!=WAIT_TIMEOUT||s.writerPid!=GetCurrentProcessId()||!skeletonGroundValid(&s,pid,GetTickCount64())||s.sequence<=sequence||(epoch&&s.epoch!=epoch))goto done;sequence=s.sequence;epoch=s.epoch;skeletonGroundStore(view,&s);frames++;}
 result=got==0&&feof(stdin)&&!ferror(stdin)&&frames?0:5;
done:memset(&s,0,sizeof(s));skeletonGroundStore(view,&s);fprintf(stderr,"Ground scalar RAM packets=%u exit=%d; mapping cleared\n",frames,result);UnmapViewOfFile(view);CloseHandle(map);CloseHandle(host);return result;
}
