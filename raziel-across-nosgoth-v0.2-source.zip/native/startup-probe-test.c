#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <stdint.h>
#include <stdbool.h>
#include <stdio.h>
#include <string.h>
#include <math.h>
#include "MinHook.h"
#define PROBE_REPORT_DIR L"."
#include "movement-packet.h"
static PVOID volatile verifiedSr1Module=(PVOID)0x10000000;
static uint32_t overlayLivePid;static ULONGLONG overlayLiveTick;
static uintptr_t fixturePlayer;static bool rootValid=true;static unsigned calls;static uintptr_t lastState;static int32_t lastSection;
static bool worldRead(uintptr_t at,void *out,size_t size){if(at==0x10000000+0x2a89628&&size==4){int32_t time=4096;memcpy(out,&time,4);return true;}if(at<0x100000000)return false;memcpy(out,(void *)at,size);return true;}
static bool worldRoot(float root[16],uintptr_t *player){memset(root,0,64);root[10]=1;*player=fixturePlayer;return rootValid;}
static bool movementReadPacket(unsigned char packet[80]){(void)packet;return false;}
static bool hashBytes(const void *p,ULONG n,char *out){(void)p;(void)n;(void)out;return false;}
static void logLine(const char *fmt,...){(void)fmt;}
#include "startup-probe.h"
static int32_t __fastcall mockApply(uintptr_t state,int32_t section){++calls;lastState=state;lastSection=section;return -123;}
#define CHECK(x) do{if(!(x)){printf("FAIL line %d\n",__LINE__);return 1;}}while(0)
int main(void){
 unsigned char instance[1400]={0},saved[1400];fixturePlayer=(uintptr_t)instance;uintptr_t state=fixturePlayer;
 memcpy(saved,instance,sizeof(saved));originalStartup=mockApply;
 CHECK(startupObserve((uintptr_t)&state,0,0x10000000+0xf3a15)==-123&&calls==1&&lastState==(uintptr_t)&state&&lastSection==0&&startupHead==0);
 startupEnabled=1;
 CHECK(startupObserve((uintptr_t)&state,0,0x10000000+0xf3a15)==-123&&calls==2&&startupHead==1&&startupQueue[0].result==-123&&startupQueue[0].player==fixturePlayer);
 CHECK(!memcmp(instance,saved,sizeof(saved))&&!startupQueue[0].ready);
 startupObserve((uintptr_t)&state,1,0x10000000+0xf3a15);CHECK(calls==3&&lastSection==1&&startupHead==1);
 startupObserve((uintptr_t)&state,0,0x10000000+0xf3a16);CHECK(calls==4&&startupHead==1);
 state=fixturePlayer+4;startupObserve((uintptr_t)&state,0,0x10000000+0xf3a15);CHECK(calls==5&&startupHead==1);state=fixturePlayer;
 rootValid=false;startupObserve((uintptr_t)&state,0,0x10000000+0xf3a15);CHECK(calls==6&&startupHead==1);rootValid=true;
 startupRecords=4000;startupObserve((uintptr_t)&state,0,0x10000000+0xf3a15);CHECK(calls==7&&startupHead==1);
 startupStop();startupTick();startupInstall(NULL);CHECK(!startupEnabled&&!memcmp(instance,saved,sizeof(saved)));
 puts("Startup observer: original arguments/signed result preserved, actor/caller/section/root scope, limits, no actor writes PASS");return 0;
}
