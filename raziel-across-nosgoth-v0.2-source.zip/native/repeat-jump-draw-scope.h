// SPDX-License-Identifier: GPL-3.0-or-later
#pragma once
#include "host-draw-receipt.h"
// Input admission uses a fresh original-render receipt for resource identity.
// It does NOT consume its pose or authorize its old action: the caller reads
// the current coherent native context separately. Landing -> ground between
// render and input is expected and must not erase a queued landing press.
static inline bool repeatJumpDrawScope(const HostDrawReceipt *s,DWORD pid,uint64_t creation,uint64_t now,const HostRig *current){
 return s&&hostDrawAccept(s,pid,creation,now,current,&s->context);
}
