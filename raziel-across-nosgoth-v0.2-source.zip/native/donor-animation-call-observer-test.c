// SPDX-License-Identifier: GPL-3.0-or-later
#include <stdio.h>
#include <MinHook.h>
#include "donor-animation-call-observer.h"
static DonorAnimationCallObserver observer;
static DonorMessageObserverThread tls;
static struct {DonorMessageLease lease;bool beforeFails,afterFails,changeSession,lockCheck;unsigned calls,errors,reads,nested,wanted;void *actor,*descriptor;int32_t section,a,b,c;} f;
static bool lease(void *unused,DonorMessageLease *out){(void)unused;*out=f.lease;SetLastError(0xaaaaaaaa);return true;}
static bool snapshot(void *unused,void *actor,int32_t section,void *descriptor,DonorAnimationCallMetadata *out){
 (void)unused;f.reads++;if(actor!=f.actor||descriptor!=f.descriptor||section!=f.section)f.errors++;
 if(f.beforeFails||(f.afterFails&&f.reads%2==0))return false;
 *out=(DonorAnimationCallMetadata){65,82,0x12345678,true};SetLastError(0xbbbbbbbb);return true;
}
static uintptr_t __fastcall original(void *actor,int32_t section,void *descriptor,int32_t a,int32_t b,int32_t c){
 f.calls++;if(actor!=f.actor||descriptor!=f.descriptor||section!=f.section||a!=f.a||b!=f.b||c!=f.c||GetLastError()!=0x12345678)f.errors++;
 if(f.lockCheck){if(!TryAcquireSRWLockExclusive(&observer.lock))f.errors++;else ReleaseSRWLockExclusive(&observer.lock);}
 if(++f.nested<f.wanted){SetLastError(0x12345678);uintptr_t r=donorAnimationCallForward(&observer,&tls,original,actor,section,descriptor,a,b,c,0x114eee,2);if(r!=UINT64_C(0xfedcba9876543210)||GetLastError()!=0x87654321)f.errors++;}f.nested--;
 if(f.changeSession)f.lease.session++;
 SetLastError(0x87654321);return UINT64_C(0xfedcba9876543210);
}
static void setup(void){memset(&f,0,sizeof(f));memset(&tls,0,sizeof(tls));f.lease=(DonorMessageLease){true,17,1000,1000,1000};f.lockCheck=true;f.wanted=1;f.actor=(void *)0x1000;f.descriptor=(void *)0x2000;f.section=2;f.a=INT32_MIN;f.b=-1;f.c=INT32_MAX;donorAnimationCallInit(&observer,NULL,lease,snapshot);}
static bool run(void){SetLastError(0x12345678);uintptr_t r=donorAnimationCallForward(&observer,&tls,original,f.actor,f.section,f.descriptor,f.a,f.b,f.c,0x114eee,2);return r==UINT64_C(0xfedcba9876543210)&&GetLastError()==0x87654321&&!f.errors;}
static DonorNativeAnimationSelect trampoline;
static uintptr_t __fastcall hook(void *actor,int32_t section,void *descriptor,int32_t a,int32_t b,int32_t c){return donorAnimationCallForward(&observer,&tls,trampoline,actor,section,descriptor,a,b,c,0x114eee,2);}
#define CHECK(c,n) do{if(!(c)){printf("FAIL %u\n",(unsigned)(n));return n;}}while(0)
int main(void){
 DonorAnimationCallEvent e;
 setup();CHECK(run()&&f.calls==1&&observer.published==2&&tls.depth==0,1);CHECK(donorAnimationCallPop(&observer,&e)&&e.phase==1&&e.overrides[0]==INT32_MIN&&e.overrides[1]==-1&&e.overrides[2]==INT32_MAX&&e.messageDepth==2,2);CHECK(donorAnimationCallPop(&observer,&e)&&e.phase==2&&e.afterValid&&e.sameState&&e.descriptorMatches,3);
 setup();f.lease.enabled=false;CHECK(run()&&f.calls==1&&!observer.published,4);
 setup();f.lease.nowTick=2500;CHECK(run()&&f.calls==1&&!observer.published&&observer.dropped,5);
 setup();f.beforeFails=true;CHECK(run()&&f.calls==1&&!observer.published,6);
 setup();f.afterFails=true;CHECK(run()&&f.calls==1&&observer.published==2,7);CHECK(donorAnimationCallPop(&observer,&e)&&donorAnimationCallPop(&observer,&e)&&!e.afterValid&&!e.key&&!e.sameState&&!e.descriptorMatches,8);
 setup();f.changeSession=true;CHECK(run()&&f.calls==1&&observer.published==1&&observer.dropped,9);
 setup();f.wanted=3;CHECK(run()&&f.calls==3&&observer.published==6&&!observer.dropped&&tls.depth==0,10);
 setup();f.lockCheck=false;AcquireSRWLockExclusive(&observer.lock);bool ok=run();ReleaseSRWLockExclusive(&observer.lock);CHECK(ok&&f.calls==1&&!observer.published&&observer.dropped,11);
 setup();observer.published=4096;CHECK(run()&&f.calls==1&&observer.published==4096&&observer.dropped,12);
 setup();f.actor=NULL;f.section=-1;CHECK(run()&&f.calls==1&&!observer.published,13);
 setup();tls.depth=UINT32_MAX;CHECK(run()&&f.calls==1&&tls.depth==UINT32_MAX&&!observer.published,14);
 setup();tls.ownerThread=(LONG)GetCurrentThreadId()+1;CHECK(run()&&f.calls==1&&!observer.published,15);
 // A real MinHook trampoline verifies the Windows x64 stack-passed fifth/sixth
 // arguments too, in a separate owned test executable (no game is accessed).
 setup();CHECK(MH_Initialize()==MH_OK,16);CHECK(MH_CreateHook((PVOID)original,(PVOID)hook,(PVOID *)&trampoline)==MH_OK,17);CHECK(MH_EnableHook((PVOID)original)==MH_OK,18);
 DonorNativeAnimationSelect volatile target=original;SetLastError(0x12345678);uintptr_t result=target(f.actor,f.section,f.descriptor,f.a,f.b,f.c);DWORD last=GetLastError();
 CHECK(MH_DisableHook((PVOID)original)==MH_OK,19);CHECK(MH_RemoveHook((PVOID)original)==MH_OK&&MH_Uninitialize()==MH_OK,20);
 CHECK(result==UINT64_C(0xfedcba9876543210)&&last==0x87654321&&f.calls==1&&!f.errors&&observer.published==2,21);
 puts("PASS: production six-argument forwarding and real MinHook trampoline, opaque64-bit result/LastError, recursion, lease/failure/budget/contention guards; original once, no lock across native call");return 0;
}
