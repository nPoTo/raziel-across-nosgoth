// SPDX-License-Identifier: GPL-3.0-or-later
#include "host-contact-source.h"
#include "host-contact-reader.h"
#include <assert.h>
#include <stdlib.h>
static void eventName(wchar_t name[128],DWORD owner,const wchar_t *suffix){
 _snwprintf(name,128,L"Local\\LOKContactTest-%lu-%ls",owner,suffix);
}
int wmain(int argc,wchar_t **argv){
 if(argc==2){
  DWORD parent=(DWORD)wcstoul(argv[1],NULL,10);wchar_t name[128];
  eventName(name,parent,L"ready");HANDLE ready=OpenEventW(EVENT_MODIFY_STATE,FALSE,name);
  eventName(name,parent,L"finish");HANDLE finish=OpenEventW(SYNCHRONIZE,FALSE,name);assert(ready&&finish);
  HostContactSource source={0};assert(hostContactSourceOpen(&source,GetTickCount64()));
  HostContactSnapshot s={.tick=source.epoch,.sequence=1,.actor=0x1234,.phase=1,.control=0x519,.coherent=1};
  hostContactSourcePublish(&source,s);assert(SetEvent(ready));
  assert(WaitForSingleObject(finish,10000)==WAIT_OBJECT_0);
  // Exit without explicit revocation to exercise the peer process-liveness
  // check while the peer's view keeps the last packet mapped.
  CloseHandle(ready);CloseHandle(finish);return 0;
 }
 assert(argc==1);wchar_t name[128],exe[32768],command[32800];DWORD owner=GetCurrentProcessId();
 eventName(name,owner,L"ready");HANDLE ready=CreateEventW(NULL,TRUE,FALSE,name);assert(ready);
 eventName(name,owner,L"finish");HANDLE finish=CreateEventW(NULL,TRUE,FALSE,name);assert(finish);
 assert(GetModuleFileNameW(NULL,exe,32768));_snwprintf(command,32800,L"\"%ls\" %lu",exe,owner);
 STARTUPINFOW start={.cb=sizeof(start)};PROCESS_INFORMATION child={0};
 assert(CreateProcessW(exe,command,NULL,NULL,FALSE,CREATE_NO_WINDOW,NULL,NULL,&start,&child));
 assert(WaitForSingleObject(ready,10000)==WAIT_OBJECT_0);
 uint64_t creation=0;assert(bridgeProcessCreation(child.hProcess,&creation));
 hostContactMappingName(name,child.dwProcessId);HANDLE m=OpenFileMappingW(FILE_MAP_READ,FALSE,name);assert(m);
 const HostContactShared *view=MapViewOfFile(m,FILE_MAP_READ,0,0,sizeof(*view));assert(view);
 HostContactSnapshot s;assert(hostContactCopy(view,&s));
 HostContactLease expected={.pid=child.dwProcessId,.creation=creation,.epoch=s.epoch,.actor=0x1234};
 HostContactReader reader={0};bool fresh=false;assert(hostContactReaderOpen(&reader,expected));
 // Use packet tick here so process scheduling on a loaded build host cannot
 // turn this lifecycle test into a timing flake; freshness is tested separately.
 assert(hostContactReaderRead(&reader,s.tick,&s,&fresh)&&fresh);
 assert(SetEvent(finish));assert(WaitForSingleObject(child.hProcess,10000)==WAIT_OBJECT_0);
 DWORD code=1;assert(GetExitCodeProcess(child.hProcess,&code)&&code==0);
 uint64_t tick=s.tick;assert(hostContactCopy(view,&s));
 assert(!hostContactReaderRead(&reader,tick,&s,&fresh)&&reader.lease.revoked&&!s.actor);
 hostContactReaderClose(&reader);UnmapViewOfFile(view);CloseHandle(m);
 CloseHandle(child.hThread);CloseHandle(child.hProcess);CloseHandle(ready);CloseHandle(finish);
 puts("PASS actual two-process RAM contact: pinned lifetime, read-only view, process-exit rejection despite retained packet");
 return 0;
}
