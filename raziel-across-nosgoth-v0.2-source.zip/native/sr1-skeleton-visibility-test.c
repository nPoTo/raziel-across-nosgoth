// SPDX-License-Identifier: GPL-3.0-or-later
#include <windows.h>
#include <stdint.h>
#include <stdbool.h>
#include <stdio.h>
#include <string.h>
#include <wchar.h>
#include "exploration-sheets.h"
#define CHECK(x,n) do{if(!(x)){printf("visibility scope failed %d\n",n);return n;}}while(0)
static PVOID volatile verifiedSr1Module=(PVOID)(uintptr_t)0x100000;
static volatile LONG probeBoundedComplete;
static uint64_t clockTick=1000,leaseBegin=1000,leaseSession=123;
static uint32_t leaseWriter=17;
static bool leaseHealthy=true,identityReadable=true;
static unsigned flags=15,identityQueries;
static uintptr_t currentActor=0x10000,currentObject=0x20000,currentModel=0x40000;
static int16_t modelIndex;static int32_t modelCount=66;
static uint64_t mockTick(void){return clockTick;}
static DWORD mockAttributes(const wchar_t *p){
 const wchar_t *names[]={L"\\sr1-skeleton.enable",L"\\hide-reaver-sr1.enable",L"\\hide-reaver-light-sr1.enable",L"\\hide-reaver-ribbon-sr1.enable"};
 for(unsigned i=0;i<4;i++)if(!wcscmp(p,names[i]))return flags&(1u<<i)?FILE_ATTRIBUTE_NORMAL:INVALID_FILE_ATTRIBUTES;
 return INVALID_FILE_ATTRIBUTES;
}
static bool sr1SkeletonGuidanceLease(uint32_t *writer,uint64_t *session,uint64_t *begin){if(!leaseHealthy)return false;*writer=leaseWriter;*session=leaseSession;*begin=leaseBegin;return true;}
static bool worldActorRead(uintptr_t base,uintptr_t *out){identityQueries++;if(!identityReadable||base!=0x100000)return false;*out=currentActor;return true;}
static bool worldRead(uintptr_t p,void *out,SIZE_T n){
 uintptr_t value=0;
 if(p==currentActor+0x1c6&&n==2){memcpy(out,&modelIndex,2);return true;}
 if(p==currentModel+0x30&&n==4){memcpy(out,&modelCount,4);return true;}
 if(n!=8)return false;
 if(p==0x100000+0x2a89310)value=currentActor;
 else if(p==currentActor+0x30)value=currentObject;
 else if(p==currentObject+0x10)value=0x30000;
 else if(p==0x30000)value=currentModel;
 else return false;
 memcpy(out,&value,8);return true;
}
#define PROBE_PATH(p) (p)
#define GetTickCount64 mockTick
#define GetFileAttributesW mockAttributes
#include "sr1-skeleton-visibility.h"
#undef GetFileAttributesW
#undef GetTickCount64
static void reset(void){
 memset(&sr1SkeletonVisibilitySession,0,sizeof(sr1SkeletonVisibilitySession));InitializeSRWLock(&sr1SkeletonVisibilityLock);
 clockTick=leaseBegin=1000;leaseSession=123;leaseWriter=17;leaseHealthy=identityReadable=true;flags=15;probeBoundedComplete=0;currentActor=0x10000;currentObject=0x20000;currentModel=0x40000;modelIndex=0;modelCount=66;identityQueries=0;
}
int main(void){
 reset();CHECK(sr1SkeletonCurrentVisibility(),1);CHECK(sr1SkeletonVisibilitySession.pinned&&sr1SkeletonVisibilitySession.writer==17&&sr1SkeletonVisibilitySession.session==123,2);
 // Exercise the actual production scope through preparation/native/final
 // timing. No body admission state or donor packet is supplied to this code.
 const uint64_t deadline=1000+tutorialWallBudgetMs((unsigned)sheet_nativeHandoffVisibilityPolicy_bounded_session.seconds);
 for(clockTick=1001;clockTick<deadline;clockTick+=17)CHECK(sr1SkeletonVisibilityScope(currentActor),3);
 CHECK(identityQueries>6700,4);clockTick=deadline;CHECK(!sr1SkeletonCurrentVisibility()&&sr1SkeletonVisibilitySession.ended,5);
 reset();CHECK(sr1SkeletonCurrentVisibility(),6);leaseHealthy=false;CHECK(!sr1SkeletonCurrentVisibility(),7);leaseHealthy=true;CHECK(!sr1SkeletonCurrentVisibility(),8);
 for(unsigned i=0;i<4;i++){reset();CHECK(sr1SkeletonCurrentVisibility(),9);flags&=~(1u<<i);CHECK(!sr1SkeletonCurrentVisibility(),10);flags=15;CHECK(!sr1SkeletonCurrentVisibility(),11);}
 reset();CHECK(sr1SkeletonCurrentVisibility(),12);leaseSession++;CHECK(!sr1SkeletonCurrentVisibility(),13);leaseSession--;CHECK(!sr1SkeletonCurrentVisibility(),14);
 reset();CHECK(sr1SkeletonCurrentVisibility(),15);leaseWriter++;CHECK(!sr1SkeletonCurrentVisibility(),16);
 reset();CHECK(sr1SkeletonCurrentVisibility(),17);currentModel+=0x1000;CHECK(!sr1SkeletonCurrentVisibility(),18);
 reset();CHECK(sr1SkeletonCurrentVisibility(),19);currentObject+=0x1000;CHECK(!sr1SkeletonCurrentVisibility(),20);
 reset();CHECK(sr1SkeletonCurrentVisibility(),21);currentActor+=0x1000;CHECK(!sr1SkeletonCurrentVisibility(),22);
 reset();CHECK(sr1SkeletonCurrentVisibility(),23);CHECK(!sr1SkeletonVisibilityScope(0x99999),24);CHECK(sr1SkeletonCurrentVisibility(),25);
 reset();CHECK(sr1SkeletonCurrentVisibility(),26);identityReadable=false;CHECK(!sr1SkeletonCurrentVisibility(),27);identityReadable=true;CHECK(sr1SkeletonCurrentVisibility(),28);
 reset();modelIndex=1;CHECK(!sr1SkeletonCurrentVisibility(),29);modelIndex=0;modelCount=65;CHECK(!sr1SkeletonCurrentVisibility(),30);
 reset();CHECK(sr1SkeletonCurrentVisibility(),31);probeBoundedComplete=1;CHECK(!sr1SkeletonCurrentVisibility(),32);probeBoundedComplete=0;CHECK(!sr1SkeletonCurrentVisibility(),33);
 reset();clockTick=999;CHECK(!sr1SkeletonCurrentVisibility(),34);clockTick=1001;CHECK(sr1SkeletonCurrentVisibility(),35);clockTick=1000;CHECK(!sr1SkeletonCurrentVisibility(),36);
 puts("PASS: actual skeleton weapon scope pins validated HUD session/writer/original actor/object/model; preparation/native/final coverage, foreign identity/session, all3 flags, expiry/stop restoration; no pose/source dependency");return 0;
}
