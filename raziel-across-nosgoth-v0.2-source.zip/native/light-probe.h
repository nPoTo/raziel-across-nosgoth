#include "report-path.h"
// SPDX-License-Identifier: GPL-3.0-or-later
// Read-only snapshot of known vec4 light arrays in camera-observed shaders.
typedef struct {GLuint program,index;GLint block,offset,stride,count;const char *kind;char name[256];} LightField;
static LightField lightFields[128];
static unsigned int lightFieldCount,lightSamples;
static ULONGLONG lightLast;
static void lightDiscover(void) {
    lightFieldCount=0;
    for(unsigned int p=0;p<cameraFieldCount;++p) {
        GLuint program=cameraFields[p].program;bool earlier=false;
        for(unsigned int j=0;j<p;++j)if(cameraFields[j].program==program)earlier=true;
        if(earlier||!cglIsProgram(program))continue;
        GLint count=0;pglGetProgramiv(program,GL_ACTIVE_UNIFORMS,&count);if(count<0||count>1024)continue;
        for(GLuint i=0;i<(GLuint)count&&lightFieldCount<128;++i) {
            char name[256]={0};GLsizei length=0;GLint size=0;GLenum type=0;
            cglGetActiveUniform(program,i,sizeof(name),&length,&size,&type,name);
            if(type!=GL_FLOAT_VEC4||size<1||size>4||length<=0||length>=255)continue;
            const char *label=strrchr(name,'.');label=label?label+1:name;
            const char *kind=!strcmp(label,"uLightPos[0]")?"position":!strcmp(label,"uLightCol[0]")?"color":!strcmp(label,"uModelSpotLocation[0]")?"spotPosition":!strcmp(label,"uModelSpotColor[0]")?"spotColor":NULL;
            if(!kind)continue;
            LightField f={0};f.program=program;f.index=i;f.kind=kind;f.count=size;strcpy(f.name,name);
            cglGetActiveUniformsiv(program,1,&i,GL_UNIFORM_BLOCK_INDEX,&f.block);
            if(f.block>=0) {
                cglGetActiveUniformsiv(program,1,&i,GL_UNIFORM_OFFSET,&f.offset);
                cglGetActiveUniformsiv(program,1,&i,GL_UNIFORM_ARRAY_STRIDE,&f.stride);
                if(f.offset<0||f.offset>16777152||f.stride<16||f.stride>1024)continue;
            }
            lightFields[lightFieldCount++]=f;
        }
    }
    logLine("LIGHT_PROBE arrays=%u; observation only, ownership unverified",lightFieldCount);
}
static bool lightRead(const LightField *f,float values[16]) {
    for(int i=0;i<16;++i)values[i]=i<f->count*4?NAN:0;
    if(f->count<1||f->count>4)return false;
    GLint count=0,size=0,block=0;GLenum type=0;char name[256]={0};GLsizei length=0;
    if(!cglIsProgram(f->program))return false;
    pglGetProgramiv(f->program,GL_ACTIVE_UNIFORMS,&count);if(count<0||f->index>=(GLuint)count)return false;
    cglGetActiveUniform(f->program,f->index,sizeof(name),&length,&size,&type,name);
    if(type!=GL_FLOAT_VEC4||size!=f->count||length<=0||length>=255||strcmp(name,f->name))return false;
    cglGetActiveUniformsiv(f->program,1,&f->index,GL_UNIFORM_BLOCK_INDEX,&block);if(block!=f->block)return false;
    if(block<0) {
        size_t lengthName=strlen(name);if(lengthName<3||strcmp(name+lengthName-3,"[0]"))return false;
        for(int i=0;i<f->count;++i) {name[lengthName-2]=(char)('0'+i);GLint location=pglGetUniformLocation(f->program,name);if(location<0)return false;cglGetUniformfv(f->program,location,values+i*4);}
    } else {
        GLint offset=0,stride=0,binding=0,maxBindings=0,buffer=0,bufferSize=0;
        cglGetActiveUniformsiv(f->program,1,&f->index,GL_UNIFORM_OFFSET,&offset);
        cglGetActiveUniformsiv(f->program,1,&f->index,GL_UNIFORM_ARRAY_STRIDE,&stride);
        if(offset!=f->offset||stride!=f->stride)return false;
        cglGetActiveUniformBlockiv(f->program,(GLuint)block,GL_UNIFORM_BLOCK_BINDING,&binding);
        glGetIntegerv(GL_MAX_UNIFORM_BUFFER_BINDINGS,&maxBindings);if(binding<0||binding>=maxBindings)return false;
        cglGetIntegeri_v(GL_UNIFORM_BUFFER_BINDING,(GLuint)binding,&buffer);if(!buffer)return false;
        GLint64 start=0,range=0;cglGetInteger64i_v(GL_UNIFORM_BUFFER_START,(GLuint)binding,&start);cglGetInteger64i_v(GL_UNIFORM_BUFFER_SIZE,(GLuint)binding,&range);
        pglBindBuffer(GL_UNIFORM_BUFFER,(GLuint)buffer);cglGetBufferParameteriv(GL_UNIFORM_BUFFER,GL_BUFFER_SIZE,&bufferSize);
        GLint64 bytes=(GLint64)stride*(f->count-1)+16;
        if(start<0||start>16777216||bufferSize<=0||bufferSize>16777216||start+offset+bytes>bufferSize||(range>0&&(GLint64)offset+bytes>range))return false;
        for(int i=0;i<f->count;++i)cglGetBufferSubData(GL_UNIFORM_BUFFER,(GLintptr)(start+offset+i*stride),16,values+i*4);
    }
    for(int i=0;i<16;++i)if(!isfinite(values[i])||fabsf(values[i])>1e9f)return false;
    return true;
}
static void lightObserve(HGLRC context) {
    if(!cameraReady||context!=cameraContext||lightSamples>=120||GetFileAttributesW(PROBE_PATH(L"\\light-capture.enable"))==INVALID_FILE_ATTRIBUTES)return;
    ULONGLONG now=GetTickCount64();if(now-lightLast<500)return;lightLast=now;
    if(lightSamples%10==0)lightDiscover();
    GLint saved=0;glGetIntegerv(GL_UNIFORM_BUFFER_BINDING,&saved);
    wchar_t path[32768];_snwprintf(path,ARRAYSIZE(path),PROBE_PATH(L"\\sr1-lights-%lu.jsonl"),GetCurrentProcessId());
    FILE *out=_wfopen(path,lightSamples?L"ab":L"wb");if(!out)return;
    float root[16];uintptr_t player=0;bool rootValid=worldRoot(root,&player);
    ReaverEvent event={0};
    if(!InterlockedCompareExchange(&reaverLock,1,0)){event=latestReaver;InterlockedExchange(&reaverLock,0);}
    fprintf(out,"{\"sample\":%u,\"tickMs\":%llu,\"player\":\"0x%llx\",\"root\":",lightSamples,(unsigned long long)now,(unsigned long long)player);
    if(rootValid)drawMatrix(out,root);else fprintf(out,"null");
    fprintf(out,",\"reaver\":\"0x%llx\",\"reaverValid\":%s,\"rawColors\":[",(unsigned long long)event.instance,event.valid?"true":"false");
    for(int i=0;i<3;++i){uint32_t value=0;memcpy(&value,event.data+16+i*4,4);if(i)fputc(',',out);fprintf(out,"%u",value);}
    fprintf(out,"],\"arrays\":[");unsigned int written=0;
    for(unsigned int i=0;i<lightFieldCount;++i){float values[16];if(!lightRead(&lightFields[i],values))continue;
        if(written++)fputc(',',out);fprintf(out,"{\"program\":%u,\"kind\":\"%s\",\"count\":%d,\"values\":",lightFields[i].program,lightFields[i].kind,lightFields[i].count);drawMatrix(out,values);fputc('}',out);
    }
    pglBindBuffer(GL_UNIFORM_BUFFER,(GLuint)saved);GLint after=0;glGetIntegerv(GL_UNIFORM_BUFFER_BINDING,&after);
    fprintf(out,"],\"restored\":%s}\n",after==saved?"true":"false");fclose(out);++lightSamples;
    if(lightSamples==1||lightSamples%20==0)logLine("LIGHT_PROBE sample=%u arrays=%u restored=%d",lightSamples,written,after==saved);
}

// Capture on the render thread before the forwarded host draw. Disk I/O stays on
// the worker; the bounded queue can drop records without blocking rendering.
typedef struct {const char *kind;GLint count;float values[16];} LightDrawArray;
typedef struct {
    ULONGLONG tick;unsigned int frame,arrayCount;
    GLenum mode,type;GLsizei count;GLint program,vao,ebo,fbo;
    uintptr_t indexOffset,player,reaver;uint32_t rawColors[3];
    bool rootValid,reaverValid,restored,truncated,jointsValid;float root[16],joints[8];
    GLboolean blend,depthTest,depthMask,colorMask[4];GLint blendSrc,blendDst,blendEquation,depthFunc;
    LightDrawArray arrays[8];
} LightDrawRecord;
static LightDrawRecord lightDrawQueue[512];
static unsigned int lightDrawHead,lightDrawTail,lightDrawBudget,lightDrawFrames,lightDrawRecords;
static volatile LONG lightDrawLock,lightDrawDrops;
static ULONGLONG lightDrawBegin,lightDrawLast;
static HGLRC lightDrawContext;
static FILE *lightDrawFile;
static bool lightPlayerJoints(uintptr_t player,float joints[8]) {
    // Indices 39/40 are used by this hash-accepted SR1 Reaver renderer. They
    // remain candidate attachment joints, not portable skeleton definitions.
    uintptr_t matrix=0,after=0,current=0;
    unsigned char raw[2][32];float decoded[16];
    if(!player||!worldRead(player+0x68,&matrix,8)||!matrix||matrix>UINTPTR_MAX-0x520||
       !worldRead(matrix+39*32,raw[0],32)||!worldRead(matrix+40*32,raw[1],32))return false;
    for(int i=0;i<2;++i){if(!decodeHostRoot(raw[i],decoded))return false;for(int j=0;j<4;++j)joints[i*4+j]=decoded[12+j];}
    uintptr_t base=(uintptr_t)InterlockedCompareExchangePointer(&verifiedSr1Module,NULL,NULL);
    return base&&worldRead(player+0x68,&after,8)&&after==matrix&&worldRead(base+0x2a89310,&current,8)&&current==player;
}
static void lightDrawArm(HGLRC context) {
    lightDrawBudget=0;
    if(!cameraReady||!context||context!=cameraContext||!originalDraw||lightDrawRecords>=15360||
       GetFileAttributesW(PROBE_PATH(L"\\light-draw.enable"))==INVALID_FILE_ATTRIBUTES)return;
    ULONGLONG now=GetTickCount64();
    if(!lightDrawBegin){lightDrawBegin=now;lightDrawContext=context;}
    if(context!=lightDrawContext||now-lightDrawBegin>=60000||now-lightDrawLast<500)return;
    lightDrawLast=now;
    if(lightDrawFrames%10==0)lightDiscover();
    shaderInit();
    ++lightDrawFrames;lightDrawBudget=128;
}
static void lightDrawObserve(GLenum mode,GLsizei count,GLenum type,const void *indices) {
    if(!lightDrawBudget||lightDrawRecords>=15360||!cameraReady||wglGetCurrentContext()!=lightDrawContext||count<=0||count>6000000)return;
    LightDrawRecord record={0};
    glGetIntegerv(GL_CURRENT_PROGRAM,&record.program);
    if(record.program==(GLint)overlayProgram)return;
    bool known=false;
    for(unsigned int i=0;i<lightFieldCount;++i)if(lightFields[i].program==(GLuint)record.program)known=true;
    if(!known)return;
    --lightDrawBudget;record.tick=GetTickCount64();record.frame=lightDrawFrames;
    record.mode=mode;record.type=type;record.count=count;record.indexOffset=(uintptr_t)indices;
    glGetIntegerv(GL_VERTEX_ARRAY_BINDING,&record.vao);glGetIntegerv(GL_ELEMENT_ARRAY_BUFFER_BINDING,&record.ebo);glGetIntegerv(GL_DRAW_FRAMEBUFFER_BINDING,&record.fbo);
    record.blend=glIsEnabled(GL_BLEND);record.depthTest=glIsEnabled(GL_DEPTH_TEST);glGetBooleanv(GL_DEPTH_WRITEMASK,&record.depthMask);glGetBooleanv(GL_COLOR_WRITEMASK,record.colorMask);
    glGetIntegerv(GL_BLEND_SRC_RGB,&record.blendSrc);glGetIntegerv(GL_BLEND_DST_RGB,&record.blendDst);glGetIntegerv(GL_BLEND_EQUATION_RGB,&record.blendEquation);glGetIntegerv(GL_DEPTH_FUNC,&record.depthFunc);
    shaderCollect((GLuint)record.program);
    GLint saved=0;glGetIntegerv(GL_UNIFORM_BUFFER_BINDING,&saved);
    for(unsigned int i=0;i<lightFieldCount;++i) {
        const LightField *field=&lightFields[i];if(field->program!=(GLuint)record.program)continue;
        if(record.arrayCount==ARRAYSIZE(record.arrays)){record.truncated=true;break;}
        LightDrawArray *array=&record.arrays[record.arrayCount];
        if(!lightRead(field,array->values))continue;
        array->kind=field->kind;array->count=field->count;++record.arrayCount;
    }
    pglBindBuffer(GL_UNIFORM_BUFFER,(GLuint)saved);GLint after=0;glGetIntegerv(GL_UNIFORM_BUFFER_BINDING,&after);record.restored=after==saved;
    if(!record.restored)lightDrawBudget=0;
    if(!record.arrayCount)return;
    record.rootValid=worldRoot(record.root,&record.player);
    if(record.rootValid)record.jointsValid=lightPlayerJoints(record.player,record.joints);
    ReaverEvent event={0};
    if(!InterlockedCompareExchange(&reaverLock,1,0)){event=latestReaver;InterlockedExchange(&reaverLock,0);}
    record.reaver=event.instance;record.reaverValid=event.valid;
    memcpy(record.rawColors,event.data+16,sizeof(record.rawColors));
    if(InterlockedCompareExchange(&lightDrawLock,1,0)){InterlockedIncrement(&lightDrawDrops);return;}
    unsigned int next=(lightDrawHead+1)%ARRAYSIZE(lightDrawQueue);
    if(next==lightDrawTail)InterlockedIncrement(&lightDrawDrops);
    else {lightDrawQueue[lightDrawHead]=record;lightDrawHead=next;++lightDrawRecords;}
    InterlockedExchange(&lightDrawLock,0);
}
static void lightDrawFlush(void) {
    LightDrawRecord records[512];unsigned int count=0;
    if(InterlockedCompareExchange(&lightDrawLock,1,0))return;
    while(lightDrawTail!=lightDrawHead){records[count++]=lightDrawQueue[lightDrawTail];lightDrawTail=(lightDrawTail+1)%ARRAYSIZE(lightDrawQueue);}
    InterlockedExchange(&lightDrawLock,0);
    if(!count)return;
    if(!lightDrawFile){wchar_t path[32768];_snwprintf(path,ARRAYSIZE(path),PROBE_PATH(L"\\sr1-light-draws-%lu.jsonl"),GetCurrentProcessId());lightDrawFile=_wfopen(path,L"wb");}
    if(!lightDrawFile){InterlockedExchangeAdd(&lightDrawDrops,(LONG)count);return;}
    for(unsigned int i=0;i<count;++i){const LightDrawRecord *r=&records[i];
        fprintf(lightDrawFile,"{\"tickMs\":%llu,\"frame\":%u,\"program\":%d,\"vao\":%d,\"ebo\":%d,\"fbo\":%d,\"primitive\":%u,\"indexType\":%u,\"count\":%d,\"indexOffset\":%llu,\"player\":\"0x%llx\",\"root\":",
            (unsigned long long)r->tick,r->frame,r->program,r->vao,r->ebo,r->fbo,r->mode,r->type,r->count,(unsigned long long)r->indexOffset,(unsigned long long)r->player);
        if(r->rootValid)drawMatrix(lightDrawFile,r->root);else fprintf(lightDrawFile,"null");
        fprintf(lightDrawFile,",\"jointIndices\":[39,40],\"jointPositions\":");
        if(r->jointsValid){fputc('[',lightDrawFile);for(int j=0;j<8;++j){if(j)fputc(',',lightDrawFile);fprintf(lightDrawFile,"%.9g",r->joints[j]);}fputc(']',lightDrawFile);}else fprintf(lightDrawFile,"null");
        fprintf(lightDrawFile,",\"reaver\":\"0x%llx\",\"reaverValid\":%s,\"rawColors\":[%u,%u,%u],\"arrays\":[",(unsigned long long)r->reaver,r->reaverValid?"true":"false",r->rawColors[0],r->rawColors[1],r->rawColors[2]);
        for(unsigned int a=0;a<r->arrayCount;++a){if(a)fputc(',',lightDrawFile);fprintf(lightDrawFile,"{\"program\":%d,\"kind\":\"%s\",\"count\":%d,\"values\":",r->program,r->arrays[a].kind,r->arrays[a].count);drawMatrix(lightDrawFile,r->arrays[a].values);fputc('}',lightDrawFile);}
        fprintf(lightDrawFile,"],\"restored\":%s,\"truncated\":%s,\"pass\":{\"blend\":%s,\"srcRgb\":%d,\"dstRgb\":%d,\"equationRgb\":%d,\"depthTest\":%s,\"depthWrite\":%s,\"depthFunc\":%d,\"colorMask\":[%d,%d,%d,%d]}}\n",r->restored?"true":"false",r->truncated?"true":"false",r->blend?"true":"false",r->blendSrc,r->blendDst,r->blendEquation,r->depthTest?"true":"false",r->depthMask?"true":"false",r->depthFunc,r->colorMask[0],r->colorMask[1],r->colorMask[2],r->colorMask[3]);
    }
    fflush(lightDrawFile);
    logLine("LIGHT_DRAW records_flushed=%u dropped=%ld; before forwarded draw, ownership unverified",count,InterlockedCompareExchange(&lightDrawDrops,0,0));
}
