// SPDX-License-Identifier: GPL-3.0-or-later
#include <stdbool.h>
#include <stdint.h>
#include <string.h>
#include <math.h>
#include <assert.h>
#include <stdio.h>
#include <wchar.h>
#include "exploration-sheets.h"
#include "host-transform.h"
#include "reaver-submitted-hand.h"
#include "reaver-current-camera.h"
int main(void){
 float pose[66][13]={0};for(unsigned i=0;i<66;i++)pose[i][0]=pose[i][4]=pose[i][8]=1;
 pose[49][10]=10;pose[49][11]=20;pose[49][12]=-30;
 ReaverSubmittedHand hand;assert(reaverHandCapture(&hand,pose,pose,1,2,3,4,5,true,true,1));
 ReaverCameraSample a={.frame=4,.context=6,.program=7};a.view[0]=a.view[5]=a.view[10]=a.view[15]=1;memcpy(a.inverse,a.view,64);
 a.view[12]=-10;a.inverse[12]=10;a.projection[0]=a.projection[5]=1;a.projection[10]=-1;a.projection[11]=-1;a.projection[14]=-2;
 ReaverCameraSample b=a;float result[16];
#define RUN(scope) reaverCameraMvp(result,&a,&b,&hand,1,2,3,4,6,7,scope)
 assert(RUN(true));assert(result[12]==0&&result[13]==20&&result[14]==28&&result[15]==30);
 assert(!RUN(false));b.frame=5;assert(!RUN(true));b=a;b.context=8;assert(!RUN(true));b=a;b.program=8;assert(!RUN(true));
 b=a;b.view[12]+=1;assert(!RUN(true));b=a;hand.frame=3;assert(!RUN(true));hand.frame=4;
 a.inverse[12]=0;b=a;assert(!RUN(true));a.inverse[12]=10;b=a;a.projection[15]=1;b=a;assert(!RUN(true));a.projection[15]=0;b=a;
 a.view[0]=NAN;b=a;assert(!RUN(true));for(unsigned i=0;i<16;i++)assert(result[i]==0);
 puts("PASS current camera: host hand placement, frame/context/program/player scope, coherent inverse and perspective, invalid/stale rejection. Not host gameplay proof.");return 0;
}
