// SPDX-License-Identifier: GPL-3.0-or-later
#pragma once
#include <stdint.h>
#include <stdbool.h>
#include <string.h>

// Stack-scoped accumulator, owned by one collision invocation/thread.
// Never carries a query forward into the next host update.
typedef struct {
 uintptr_t actor;
 uint64_t sequence;
 unsigned queries;
 uint32_t before,after,result;
 bool poisoned;
} HostContactFrame;
typedef enum { HOST_CONTACT_UNKNOWN, HOST_CONTACT_GROUND, HOST_CONTACT_AIR } HostContact;
typedef struct { HostContact contact; uint64_t sequence,tick; bool queryDisabledJump; } HostContactResult;

static inline void hostContactBegin(HostContactFrame *f,uintptr_t actor,uint64_t sequence){
 memset(f,0,sizeof(*f));f->actor=actor;f->sequence=sequence;
}
static inline void hostContactQuery(HostContactFrame *f,uintptr_t actor,unsigned depth,
 bool completed,bool sameActor,uint32_t before,uint32_t after,uint32_t result){
 if(!f)return;
 if(++f->queries!=1||actor!=f->actor||depth!=1||!completed||!sameActor){f->poisoned=true;return;}
 f->before=before;f->after=after;f->result=result;
}
static inline HostContactResult hostContactFinish(const HostContactFrame *f,uintptr_t actor,
 uint64_t tick,bool coherent,uint32_t control,const uintptr_t callbacks[3]){
 HostContactResult r={.sequence=f->sequence,.tick=tick};
 if(!f->actor||actor!=f->actor||!f->sequence||!coherent||f->poisoned||(control&0x4000000))return r;
 if(f->queries){
  if(f->queries!=1||f->after!=control||!(f->before&8)||!(f->after&8)||((f->before|f->after)&0x4000000))return r;
  r.contact=(f->result&1)?HOST_CONTACT_GROUND:HOST_CONTACT_AIR;return r;
 }
 // Both measured no-query Jump variants; bit4 does not enable a floor query.
 if((control==0x511||control==0x515)&&callbacks&&callbacks[0]==0xf2ae0&&callbacks[1]==0xf2ae0&&callbacks[2]==0xf2ae0){
  r.contact=HOST_CONTACT_AIR;r.queryDisabledJump=true;
 }
 return r;
}
