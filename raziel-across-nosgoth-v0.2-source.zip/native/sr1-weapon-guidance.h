// SPDX-License-Identifier: GPL-3.0-or-later
#pragma once
#include "recording-status.h"
#include "guidance-plan.h"
// A failed read can consume an already validated heartbeat's remaining lease,
// but can never renew it. Immutable foreign descriptors and missing files revoke.
typedef struct {
 bool descriptorRead,statusRead,missing,invalidShape,hudActive;
 uint32_t pid,hudWriter,hudPlan;uint64_t now,hudSession,hudBegin;
 RecordingStatus status;GuidanceDescriptor descriptor;
} Sr1WeaponGuidanceObservation;
typedef struct {
 bool pinned,revoked;uint32_t writer,plan;uint64_t session,begin,heartbeat,lastNow;
} Sr1WeaponGuidance;
static inline bool sr1WeaponGuidanceStep(Sr1WeaponGuidance *s,const Sr1WeaponGuidanceObservation *o){
 if(!s||!o||s->revoked)return false;
 uint32_t plan=s->pinned?s->plan:o->hudPlan;
 unsigned seconds=guidanceSeconds(plan);
 bool supported=plan==13&&(seconds==100||seconds==120||seconds==170);
#ifdef SR1_REPEAT_JUMP_HUD
 supported|=plan==14&&(seconds==50||seconds==170);
#endif
 if(!supported)return false;
 bool end=o->missing||o->invalidShape||(s->pinned&&o->now<s->lastNow);
 if(s->pinned&&o->hudSession&&(o->hudSession!=s->session||o->hudWriter!=s->writer||o->hudPlan!=plan||o->hudBegin!=s->begin))end=true;
 const RecordingStatus *r=&o->status;const GuidanceDescriptor *d=&o->descriptor;
 if(o->descriptorRead&&(!guidanceDescriptorValid(d,o->pid,d->writerPid,seconds*10)||d->plan!=plan||d->seconds!=seconds||(s->pinned&&(d->writerPid!=s->writer||d->session!=s->session))))end=true;
 if(o->statusRead&&(r->magic!=0x31434552||r->version!=1||r->gamePid!=o->pid||!r->writerPid||r->total!=seconds*10||(s->pinned&&r->writerPid!=s->writer)||r->completed>=r->total))end=true;
 if(end){if(s->pinned)s->revoked=true;return false;}
 bool valid=o->descriptorRead&&o->statusRead&&recordingStatusValid(r,o->pid,o->now)&&guidanceDescriptorValid(d,o->pid,r->writerPid,r->total)&&d->plan==plan&&d->seconds==seconds;
 if(valid&&!s->pinned){
  if(!o->hudActive||o->hudPlan!=plan||o->hudWriter!=d->writerPid||o->hudSession!=d->session||!o->hudBegin||o->now<o->hudBegin)return false;
  s->pinned=true;s->plan=plan;s->writer=d->writerPid;s->session=d->session;s->begin=o->hudBegin;
 }
 if(!s->pinned)return false;
 s->lastNow=o->now;
 if(valid&&r->tick>=s->heartbeat)s->heartbeat=r->tick;
 bool fresh=s->heartbeat&&o->now>=s->heartbeat&&o->now-s->heartbeat<1500&&guidanceWithinBudget(o->now,s->begin,seconds);
 if(!fresh)s->revoked=true;
 return fresh;
}
