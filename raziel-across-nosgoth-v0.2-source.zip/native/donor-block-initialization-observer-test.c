// SPDX-License-Identifier: GPL-3.0-or-later
#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <stdio.h>
#include <limits.h>
#include <MinHook.h>
#include "donor-block-initialization-observer.h"
static DonorBlockInitializationObserver observer;static _Thread_local uint32_t depth;
static struct {unsigned calls,preReads,postReads,errors,nesting,wanted;bool fail,race,cleanup;HANDLE entered,release;} f;
static uintptr_t __fastcall original(uintptr_t actor);static DonorBlockInitializationNative trampoline;
static uintptr_t invoke(uintptr_t a){return donorBlockInitializationForward(&observer,&depth,original,a,0xec579);}
static bool snapshot(void *c,uintptr_t actor,bool after,DonorBlockInitializationMetadata *m){(void)c;if(after)f.postReads++;else f.preReads++;if(actor!=UINT64_C(0xfedcba9876543210))f.errors++;SetLastError(17);if(after&&f.race)InterlockedIncrement64(&observer.epoch);*m=(DonorBlockInitializationMetadata){.knownType=true,.cleanup=f.cleanup,.initialized=after&&!f.cleanup};return !f.fail;}
static uintptr_t __fastcall original(uintptr_t actor){f.calls++;if(actor!=UINT64_C(0xfedcba9876543210)||GetLastError()!=0x12345678)f.errors++;if(f.entered){SetEvent(f.entered);WaitForSingleObject(f.release,2000);}if(++f.nesting<f.wanted){SetLastError(0x12345678);uintptr_t r=invoke(actor);if(r!=UINT64_C(0xabcdef0123456789))f.errors++;}f.nesting--;SetLastError(0x87654321);return UINT64_C(0xabcdef0123456789);}
static uintptr_t __fastcall hook(uintptr_t a){return donorBlockInitializationForward(&observer,&depth,trampoline,a,0xec579);}
static void setup(void){memset(&f,0,sizeof(f));depth=0;f.wanted=1;donorBlockInitializationInit(&observer,GetTickCount64(),NULL,snapshot);}
static bool run(void){SetLastError(0x12345678);uintptr_t r=invoke(UINT64_C(0xfedcba9876543210));return r==UINT64_C(0xabcdef0123456789)&&GetLastError()==0x87654321&&!f.errors;}
static DWORD WINAPI parallel(LPVOID p){(void)p;return run()?0:1;}
static uintptr_t __fastcall secondOriginal(uintptr_t a){f.calls++;if(a!=UINT64_C(0xfedcba9876543210)||GetLastError()!=0x12345678)f.errors++;SetLastError(0x87654321);return UINT64_C(0xabcdef0123456789);}
#define CHECK(c,n) do{if(!(c)){printf("FAIL %u\n",(unsigned)n);return n;}}while(0)
int main(void){DonorBlockInitializationEvent e;setup();CHECK(run()&&f.calls==1&&f.preReads==1&&f.postReads==1&&!depth&&!observer.active,1);CHECK(donorBlockInitializationPop(&observer,&e)&&e.phase==1&&e.knownType&&!e.initialized,2);CHECK(donorBlockInitializationPop(&observer,&e)&&e.phase==2&&e.initialized&&e.current,3);
 CHECK(run()&&observer.epoch==2&&!donorBlockInitializationCurrent(&observer,1,GetTickCount64()),4);
 setup();f.cleanup=true;CHECK(run()&&f.preReads==1&&!f.postReads&&observer.epoch==1,5);CHECK(donorBlockInitializationPop(&observer,&e)&&e.cleanup&&donorBlockInitializationPop(&observer,&e)&&e.cleanup&&!e.initialized,6);
 setup();f.fail=true;CHECK(run()&&!f.postReads&&donorBlockInitializationPop(&observer,&e)&&!e.beforeValid&&donorBlockInitializationPop(&observer,&e)&&!e.initialized,7);
 setup();f.race=true;CHECK(run()&&donorBlockInitializationPop(&observer,&e)&&donorBlockInitializationPop(&observer,&e)&&!e.initialized&&!e.current,8);
 setup();f.wanted=3;CHECK(run()&&f.calls==3&&observer.epoch==3&&observer.published==6&&!f.postReads&&!observer.active&&!depth,9);
 setup();AcquireSRWLockExclusive(&observer.lock);CHECK(run()&&f.calls==1&&observer.dropped==2&&!observer.published,10);ReleaseSRWLockExclusive(&observer.lock);
 setup();observer.head=255;CHECK(run()&&f.calls==1&&observer.dropped==2,11);
 setup();observer.start-=600000;CHECK(run()&&observer.stopped&&!observer.epoch&&!f.preReads,12);
 setup();observer.calls=1024;CHECK(run()&&observer.stopped&&!observer.active&&!observer.published,13);
 setup();observer.epoch=LLONG_MAX;CHECK(run()&&observer.stopped&&!observer.active&&!f.preReads,14);
 setup();depth=32;CHECK(run()&&observer.stopped&&depth==32&&!observer.active,15);depth=0;
 setup();CHECK(MH_Initialize()==MH_OK&&MH_CreateHook((PVOID)original,(PVOID)hook,(PVOID *)&trampoline)==MH_OK&&MH_EnableHook((PVOID)original)==MH_OK,16);
 DonorBlockInitializationNative volatile target=original;SetLastError(0x12345678);uintptr_t r=target(UINT64_C(0xfedcba9876543210));DWORD last=GetLastError();CHECK(MH_DisableHook((PVOID)original)==MH_OK&&MH_RemoveHook((PVOID)original)==MH_OK&&MH_Uninitialize()==MH_OK,17);CHECK(r==UINT64_C(0xabcdef0123456789)&&last==0x87654321&&!f.errors&&f.calls==1&&observer.published==2,18);
 setup();f.entered=CreateEventW(NULL,TRUE,FALSE,NULL);f.release=CreateEventW(NULL,TRUE,FALSE,NULL);HANDLE t=CreateThread(NULL,0,parallel,NULL,0,NULL);CHECK(t&&WaitForSingleObject(f.entered,1000)==WAIT_OBJECT_0,19);uint64_t epoch=(uint64_t)observer.epoch;CHECK(epoch==1&&observer.active==1&&!donorBlockInitializationCurrent(&observer,epoch,GetTickCount64()),20);
 SetLastError(0x12345678);r=donorBlockInitializationForward(&observer,&depth,secondOriginal,UINT64_C(0xfedcba9876543210),0xec579);CHECK(r==UINT64_C(0xabcdef0123456789)&&GetLastError()==0x87654321&&observer.epoch==2&&observer.active==1&&!f.postReads,21);
 SetEvent(f.release);CHECK(WaitForSingleObject(t,2000)==WAIT_OBJECT_0,22);DWORD code=1;CHECK(GetExitCodeThread(t,&code)&&code==0&&!observer.active&&f.calls==2&&!f.postReads&&!donorBlockInitializationCurrent(&observer,epoch,GetTickCount64()),23);CHECK(CloseHandle(t)&&CloseHandle(f.entered)&&CloseHandle(f.release),24);
 puts("PASS: original opaque1arg/RAX/LastError through real MinHook; cleanup forbids post-read, same-address epoch, nested/cross-thread overlap, metadata race/failure, nonblocking queue and time/call/depth/epoch refusal");return 0;}
