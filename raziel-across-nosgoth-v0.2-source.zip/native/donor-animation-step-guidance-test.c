// SPDX-License-Identifier: GPL-3.0-or-later
#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <stdio.h>
#include <stdbool.h>
#include <stdint.h>
#include <string.h>
#include "exploration-sheets.h"
#include "guidance-plan.h"
int main(void){const unsigned begin[]={0,20,35,50,55},end[]={20,35,50,55,60};if(guidanceSeconds(11)!=60)return 1;for(unsigned i=0;i<5;i++)for(unsigned t=begin[i];t<end[i];t++){const TutorialStage *s=guidanceStageAt(11,t);if(!s||s->begin!=begin[i]||s->end!=end[i])return 2;}if(guidanceStageAt(11,60))return 3;puts("PASS: compiled native HUD has20s preparation then exact grab/push/release/finish boundaries,60s total");return 0;}
