// SPDX-License-Identifier: GPL-3.0-or-later
#pragma once
#ifndef WIN32_LEAN_AND_MEAN
#define WIN32_LEAN_AND_MEAN
#endif
#include <windows.h>
#include "donor-action-state.h"
typedef struct {bool valid,actorPresent,objectReadable,actorStable,registryAvailable,modelMatchesRaziel;} DonorIdentityObservation;
static inline DonorIdentityObservation donorIdentityRead(void *c,DonorActionStateRead read,uintptr_t base,uint32_t imageSize,uintptr_t knownRazielModel){
 DonorIdentityObservation out={0};const Sheet_donorActorIdentityProbe *p=&sheet_donorActorIdentityProbe_current;
 if(!read||!base||base>UINTPTR_MAX-imageSize||imageSize<0xc5aa80||p->actorPointerRva!=0xc5aa78||p->actorObjectOffset!=0x88||p->pointerBytes!=8||p->stableReads!=2||p->samples!=20||p->intervalMs!=100||p->serializePointers||p->serializeNames)return out;
 out.registryAvailable=knownRazielModel!=0;uintptr_t actor=0,after=0,object=0,objectAfter=0;
 if(!read(c,base+(uintptr_t)p->actorPointerRva,&actor,8))return out;
 out.actorPresent=actor!=0;
 if(!actor||actor%8||actor>UINTPTR_MAX-(uintptr_t)p->actorObjectOffset-8)return out;
 if(!read(c,actor+(uintptr_t)p->actorObjectOffset,&object,8)||!object)return out;
 out.objectReadable=true;
 if(!read(c,actor+(uintptr_t)p->actorObjectOffset,&objectAfter,8)||objectAfter!=object||!read(c,base+(uintptr_t)p->actorPointerRva,&after,8)||after!=actor)return out;
 out.actorStable=true;out.modelMatchesRaziel=knownRazielModel&&object==knownRazielModel;out.valid=true;return out;
}
