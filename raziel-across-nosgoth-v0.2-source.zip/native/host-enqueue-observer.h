// SPDX-License-Identifier: GPL-3.0-or-later
#pragma once
#include "donor-message-observer.h"
#include "host-enqueue-reader.h"
typedef uintptr_t (__fastcall *HostNativeEnqueue)(void *,uint32_t,uintptr_t);
typedef int (*HostEnqueueSnapshot)(void *,void *,HostEnqueueMetadata *);
typedef struct {uint64_t session,callId,tickMs;uint32_t phase,threadId,depth,callerRva,section,queueKind,messageId,payloadZero,index,handlerRva,afterValid,sameActor;} HostEnqueueEvent;
_Static_assert(sizeof(HostEnqueueEvent)==72,"Scalar host enqueue record, no native pointers");
typedef struct {
 HostEnqueueEvent queue[512];volatile LONG readCursor,writeCursor,producerThread,consumerThread;
 volatile LONG64 forwarded,published,dropped,nextCallId,unrelated,boundaryRejected;
 volatile LONG64 leaseDrops,metadataDrops,depthDrops,producerDrops,queueDrops,budgetDrops;
 void *context;DonorMessageLeaseRead lease;HostEnqueueSnapshot snapshot;bool configured;
} HostEnqueueObserver;
static inline void hostEnqueueInit(HostEnqueueObserver *o,void *c,DonorMessageLeaseRead l,HostEnqueueSnapshot r){
 memset(o,0,sizeof(*o));o->context=c;o->lease=l;o->snapshot=r;const Sheet_hostNativeEnqueuePolicy *p=&sheet_hostNativeEnqueuePolicy_bounded;
 o->configured=l&&r&&p->rva==0x10ccc0&&p->bodyBytes==42&&p->plan==11&&p->seconds==60&&p->queueCapacity==512&&p->maxRecords==65536&&p->maxDepth==32&&p->requireSingleProducer&&!p->serializePointers&&!p->serializePayloads&&!p->syntheticCalls;
}
static inline void hostEnqueueDrop(HostEnqueueObserver *o,volatile LONG64 *reason){InterlockedIncrement64(reason);InterlockedIncrement64(&o->dropped);}
static inline bool hostEnqueuePush(HostEnqueueObserver *o,const HostEnqueueEvent *e){
 DWORD tid=GetCurrentThreadId();LONG owner=InterlockedCompareExchange(&o->producerThread,(LONG)tid,0);
 if(owner&&(DWORD)owner!=tid){hostEnqueueDrop(o,&o->producerDrops);return false;}
 uint32_t w=(uint32_t)InterlockedCompareExchange(&o->writeCursor,0,0),r=(uint32_t)InterlockedCompareExchange(&o->readCursor,0,0);
 if((uint64_t)InterlockedCompareExchange64(&o->published,0,0)>=(uint64_t)sheet_hostNativeEnqueuePolicy_bounded.maxRecords){hostEnqueueDrop(o,&o->budgetDrops);return false;}
 if(w<r||w-r>=512){hostEnqueueDrop(o,&o->queueDrops);return false;}
 o->queue[w%512]=*e;InterlockedIncrement64(&o->published);InterlockedExchange(&o->writeCursor,(LONG)(w+1));return true;
}
static inline bool hostEnqueuePop(HostEnqueueObserver *o,HostEnqueueEvent *e){
 DWORD tid=GetCurrentThreadId();LONG owner=InterlockedCompareExchange(&o->consumerThread,(LONG)tid,0);if(owner&&(DWORD)owner!=tid)return false;
 uint32_t r=(uint32_t)InterlockedCompareExchange(&o->readCursor,0,0),w=(uint32_t)InterlockedCompareExchange(&o->writeCursor,0,0);if(w<=r||w-r>512)return false;
 *e=o->queue[r%512];InterlockedExchange(&o->readCursor,(LONG)(r+1));return true;
}
static inline bool hostEnqueueLease(HostEnqueueObserver *o,const DonorMessageLease *start,DonorMessageLease *now){return o->lease(o->context,now)&&donorMessageLeaseValid(now)&&now->session==start->session&&now->startTick==start->startTick&&now->heartbeatTick>=start->heartbeatTick&&now->nowTick>=start->nowTick;}
static inline bool hostEnqueueOutsideDeadline(const DonorMessageLease *l){return l->enabled&&l->session&&l->startTick&&l->nowTick>=l->startTick&&l->nowTick-l->startTick>=(uint64_t)sheet_hostNativeEnqueuePolicy_bounded.seconds*1000;}
// Original is invoked exactly once in every path. Payload is passed unchanged
// and never dereferenced. Only the six exact player queue addresses are observed.
static inline uintptr_t hostEnqueueForward(HostEnqueueObserver *o,DonorMessageObserverThread *tls,HostNativeEnqueue original,void *queue,uint32_t id,uintptr_t payload,uint32_t caller){
 DWORD incoming=GetLastError(),tid=GetCurrentThreadId();uint32_t depth=0;bool tracked=false,entered=false;
 DonorMessageLease start={0},now={0};HostEnqueueMetadata before={0};HostEnqueueEvent e={0};
 if(tls){LONG owner=InterlockedCompareExchange(&tls->ownerThread,(LONG)tid,0);tracked=owner==0||(DWORD)owner==tid;if(tracked){depth=tls->depth;tls->depth=depth<UINT32_MAX?depth+1:UINT32_MAX;}}
 if(o)InterlockedIncrement64(&o->forwarded);
 if(o&&o->configured&&tracked&&o->lease(o->context,&start)&&start.enabled){
  if(hostEnqueueOutsideDeadline(&start))InterlockedIncrement64(&o->boundaryRejected);
  else if(!donorMessageLeaseValid(&start))hostEnqueueDrop(o,&o->leaseDrops);
  else if(depth>=(uint32_t)sheet_hostNativeEnqueuePolicy_bounded.maxDepth)hostEnqueueDrop(o,&o->depthDrops);
  else{
   int status=o->snapshot(o->context,queue,&before);
   if(status==0)InterlockedIncrement64(&o->unrelated);
   else if(status!=1)hostEnqueueDrop(o,&o->metadataDrops);
   else if(!hostEnqueueLease(o,&start,&now)){if(hostEnqueueOutsideDeadline(&now))InterlockedIncrement64(&o->boundaryRejected);else hostEnqueueDrop(o,&o->leaseDrops);}
   else{e=(HostEnqueueEvent){start.session,(uint64_t)InterlockedIncrement64(&o->nextCallId),now.nowTick,1,tid,depth+1,caller,before.section,before.queueKind,id,payload==0,before.index,before.handlerRva,0,0};entered=hostEnqueuePush(o,&e);}
  }
 }
 SetLastError(incoming);uintptr_t result=original(queue,id,payload);DWORD outgoing=GetLastError();
 if(entered){
  HostEnqueueMetadata after={0};
  if(hostEnqueueLease(o,&start,&now)){
   int status=o->snapshot(o->context,queue,&after);
   if(hostEnqueueLease(o,&start,&now)){e.phase=2;e.tickMs=now.nowTick;e.afterValid=status==1&&before.section==after.section&&before.queueKind==after.queueKind;e.sameActor=e.afterValid&&before.opaqueActor==after.opaqueActor;e.index=e.afterValid?after.index:0;e.handlerRva=e.afterValid?after.handlerRva:0;hostEnqueuePush(o,&e);}else hostEnqueueDrop(o,&o->leaseDrops);
  }else hostEnqueueDrop(o,&o->leaseDrops);
 }
 if(tracked)tls->depth=depth;SetLastError(outgoing);return result;
}
