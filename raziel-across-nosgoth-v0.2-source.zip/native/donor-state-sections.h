// SPDX-License-Identifier: GPL-3.0-or-later
#pragma once
#include "donor-action-state.h"
typedef struct {uint32_t firstRva,secondRva;bool secondValid;} DonorStateSection;
typedef struct {bool valid,ownerMatches;DonorStateSection sections[3];} DonorStateSections;
static inline DonorStateSections donorStateSectionsRead(void *context,DonorActionStateRead read,DonorActionStateCode code,uintptr_t base,uint32_t imageSize,uintptr_t actor,uintptr_t currentAddress){
 DonorStateSections out={0};const Sheet_donorStateSectionsProbe *p=&sheet_donorStateSectionsProbe_current;
 const Sheet_donorActionStateProbe *f=&sheet_donorActionStateProbe_current;
 if(!read||!code||!base||!actor||actor%8||p->ownerOffset!=0||p->sectionStride!=0x250||p->sectionCount!=3||p->prefixBytes!=32||p->stableReads!=2||!p->requireExecutableImage||p->serializePointers||f->firstCallbackOffset!=16||f->secondCallbackOffset!=24||base>UINTPTR_MAX-imageSize||actor>UINTPTR_MAX-(uintptr_t)f->actorStateOffset-8)return out;
 uintptr_t state=0,again=0,current=0,owner=0;unsigned char prefix[3][32],after[32];
 const uintptr_t span=(uintptr_t)(p->sectionCount-1)*(uintptr_t)p->sectionStride+(uintptr_t)p->prefixBytes;
 if(!read(context,currentAddress,&current,8)||current!=actor||!read(context,actor+(uintptr_t)f->actorStateOffset,&state,8)||!state||state%8||state>UINTPTR_MAX-span)return out;
 for(unsigned i=0;i<3;i++){
  uintptr_t first=0,second=0;if(!read(context,state+i*(uintptr_t)p->sectionStride,prefix[i],sizeof(prefix[i])))return out;
  memcpy(&first,prefix[i]+(size_t)f->firstCallbackOffset,8);memcpy(&second,prefix[i]+(size_t)f->secondCallbackOffset,8);
  if(first<base||first-base>=imageSize||!code(context,first,base))return out;
  out.sections[i].firstRva=(uint32_t)(first-base);
  out.sections[i].secondValid=second>=base&&second-base<imageSize&&code(context,second,base);
  if(out.sections[i].secondValid)out.sections[i].secondRva=(uint32_t)(second-base);
 }
 for(unsigned i=0;i<3;i++)if(!read(context,state+i*(uintptr_t)p->sectionStride,after,sizeof(after))||memcmp(prefix[i],after,sizeof(after)))return (DonorStateSections){0};
 if(!read(context,actor+(uintptr_t)f->actorStateOffset,&again,8)||again!=state||!read(context,currentAddress,&current,8)||current!=actor)return (DonorStateSections){0};
 memcpy(&owner,prefix[0]+(size_t)p->ownerOffset,8);out.ownerMatches=owner==actor;out.valid=true;return out;
}
