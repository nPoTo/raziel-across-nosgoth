// SPDX-License-Identifier: GPL-3.0-or-later
#pragma once
#include <windows.h>
#include <stdbool.h>
#include <stdint.h>
#include <string.h>
#include "exploration-sheets.h"
typedef bool (*DonorAnimationContextRead)(void *,uintptr_t,void *,SIZE_T);
typedef struct {bool valid,registryAvailable,actorMatchesRaziel,stateOwned,contextMatches;uint32_t availableMask,supportedMask,cachedMatchMask,selectionKeys[3];} DonorAnimationContextObservation;
typedef struct {uintptr_t actor,object,state,owner,context,global,map,descriptors,cached[3];uint32_t keys[3];int16_t indices[6];} DonorAnimationContextSnapshot;
static inline bool donorAnimationContextField(void *c,DonorAnimationContextRead read,uintptr_t base,uintptr_t offset,void *out,SIZE_T n){return base&&offset<=UINTPTR_MAX-base&&n<=UINTPTR_MAX-base-offset&&read(c,base+offset,out,n);}
static inline bool donorAnimationContextSnapshot(void *c,DonorAnimationContextRead read,uintptr_t base,uintptr_t knownModel,DonorAnimationContextSnapshot *s){
 const Sheet_donorAnimationContextProbe *p=&sheet_donorAnimationContextProbe_current;memset(s,0,sizeof(*s));
 if(!read(c,base+(uintptr_t)p->actorPointerRva,&s->actor,8)||!s->actor||s->actor%8||!donorAnimationContextField(c,read,s->actor,p->actorObjectOffset,&s->object,8))return false;
 if(s->object!=knownModel)return true;
 if(!donorAnimationContextField(c,read,s->actor,p->actorStateOffset,&s->state,8)||!s->state||s->state%8||!read(c,s->state,&s->owner,8)||!donorAnimationContextField(c,read,s->actor,p->actorContextOffset,&s->context,8)||!s->context||s->context%8||!read(c,base+(uintptr_t)p->globalContextRva,&s->global,8))return false;
 if(s->owner!=s->actor||s->context!=s->global)return true;
 if(!donorAnimationContextField(c,read,s->context,p->keyMapOffset,&s->map,8)||!donorAnimationContextField(c,read,s->context,p->descriptorBaseOffset,&s->descriptors,8)||!s->map||s->map%2||!s->descriptors||s->descriptors%8)return false;
 for(unsigned i=0;i<3;i++)if(!donorAnimationContextField(c,read,s->state,p->selectionKeyOffset+i*(uintptr_t)p->stateSectionStride,&s->keys[i],4)||!donorAnimationContextField(c,read,s->state,p->cachedDescriptorOffset+i*(uintptr_t)p->stateSectionStride,&s->cached[i],8))return false;
 for(unsigned i=0;i<6;i++)if(!donorAnimationContextField(c,read,s->map,(uintptr_t)sheet_donorAnimationContextKeys_rows[i]->key*2,&s->indices[i],2))return false;
 return true;
}
static inline DonorAnimationContextObservation donorAnimationContextRead(void *c,DonorAnimationContextRead read,uintptr_t base,uint32_t size,uintptr_t knownModel){
 DonorAnimationContextObservation out={0};out.registryAvailable=knownModel!=0;const Sheet_donorAnimationContextProbe *p=&sheet_donorAnimationContextProbe_current;
 if(!read||!base||base>UINTPTR_MAX-size||size<0x1140498||p->actorPointerRva!=0xc5aa78||p->globalContextRva!=0x1140490||p->actorObjectOffset!=0x88||p->actorStateOffset!=0x3f8||p->actorContextOffset!=0x310||p->keyMapOffset!=0xd0||p->descriptorBaseOffset!=0x78||p->descriptorBytes!=16||p->keyBytes!=2||p->maxDescriptorIndex!=4095||p->stateSectionStride!=0x250||p->selectionKeyOffset!=0x248||p->cachedDescriptorOffset!=0x250||p->sectionCount!=3||p->serializePointers||p->serializeDescriptors)return out;
 if(!knownModel||sheet_donorAnimationContextKeys_count!=6)return out;
 DonorAnimationContextSnapshot a,b;if(!donorAnimationContextSnapshot(c,read,base,knownModel,&a))return out;
 out.actorMatchesRaziel=knownModel&&a.object==knownModel;out.stateOwned=a.owner&&a.owner==a.actor;out.contextMatches=a.context&&a.context==a.global;
 if(!out.actorMatchesRaziel||!out.stateOwned||!out.contextMatches)return out;
 uintptr_t resolved[6]={0};unsigned char scratch[16];
 for(unsigned i=0;i<6;i++)if(a.indices[i]>=0&&a.indices[i]<=p->maxDescriptorIndex){uintptr_t offset=(uintptr_t)a.indices[i]*16;if(donorAnimationContextField(c,read,a.descriptors,offset,scratch,sizeof(scratch))){resolved[i]=a.descriptors+offset;out.availableMask|=1U<<i;}}
 if(!donorAnimationContextSnapshot(c,read,base,knownModel,&b)||memcmp(&a,&b,sizeof(a)))return (DonorAnimationContextObservation){.registryAvailable=knownModel!=0};
 for(unsigned i=0;i<3;i++){out.selectionKeys[i]=a.keys[i];for(unsigned j=0;j<6;j++)if(a.keys[i]==(uint32_t)sheet_donorAnimationContextKeys_rows[j]->key){out.supportedMask|=1U<<i;if(resolved[j]&&resolved[j]==a.cached[i])out.cachedMatchMask|=1U<<i;}}
 out.valid=true;return out;
}
