// SPDX-License-Identifier: GPL-3.0-or-later
#pragma once
#include "donor-animation-context-reader.h"
typedef struct {bool valid;uint32_t baseMask,alternativeMask,classifiedMask,rows,availableMask,keys[3];} DonorAlternativeObservation;
typedef struct {uintptr_t table,rows[64],descriptors[64];uint32_t count;} DonorAlternativeSnapshot;
static inline bool donorAlternativeSnapshot(void *c,DonorAnimationContextRead read,uintptr_t context,DonorAlternativeSnapshot *s){
 memset(s,0,sizeof(*s));if(!donorAnimationContextField(c,read,context,0x58,&s->table,8)||!s->table||s->table%8)return false;
 for(unsigned i=0;i<=64;i++){uintptr_t row=0;if(!donorAnimationContextField(c,read,s->table,i*8,&row,8))return false;if(!row)return true;if(i==64||row%8)return false;s->rows[i]=row;
  uintptr_t descriptor=0;unsigned char scratch[16];if(!read(c,row,&descriptor,8)||!descriptor||descriptor%8||descriptor>UINTPTR_MAX-16||!read(c,descriptor,scratch,16))return false;s->descriptors[i]=descriptor;s->count++;
 }return false;
}
static inline DonorAlternativeObservation donorAlternativeRead(void *c,DonorAnimationContextRead read,uintptr_t base,uint32_t size,uintptr_t knownModel){
 DonorAlternativeObservation out={0};const Sheet_donorAlternativeDescriptorProbe *p=&sheet_donorAlternativeDescriptorProbe_bounded;
 if(!read||!base||base>UINTPTR_MAX-size||size<0x1140498||!knownModel||p->tableOffset!=0x58||p->rowBytes!=8||p->descriptorOffset!=0||p->maxRows!=64||p->descriptorBytes!=16||p->samples!=200||p->intervalMs!=100||p->serializePointers||p->serializeDescriptors||p->syntheticCalls)return out;
 DonorAnimationContextSnapshot a,z;if(!donorAnimationContextSnapshot(c,read,base,knownModel,&a)||a.object!=knownModel||a.owner!=a.actor||!a.context||a.context!=a.global)return out;
 DonorAnimationContextObservation current=donorAnimationContextRead(c,read,base,size,knownModel);if(!current.valid)return out;
 DonorAlternativeSnapshot first,after;if(!donorAlternativeSnapshot(c,read,a.context,&first))return out;uint32_t mask=0;
 for(unsigned i=0;i<3;i++)for(unsigned j=0;j<first.count;j++)if(a.cached[i]&&a.cached[i]==first.descriptors[j])mask|=1U<<i;
 if(!donorAlternativeSnapshot(c,read,a.context,&after)||memcmp(&first,&after,sizeof(first))||!donorAnimationContextSnapshot(c,read,base,knownModel,&z)||memcmp(&a,&z,sizeof(a)))return out;
 out.valid=true;out.baseMask=current.cachedMatchMask;out.alternativeMask=mask;out.classifiedMask=out.baseMask|mask;out.rows=first.count;out.availableMask=current.availableMask;memcpy(out.keys,current.selectionKeys,sizeof(out.keys));return out;
}
