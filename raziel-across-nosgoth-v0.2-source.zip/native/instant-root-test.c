#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <stdint.h>
#include <stdbool.h>
#include <stdio.h>
#include <string.h>
#include <math.h>
#include "MinHook.h"
#define PROBE_REPORT_DIR L"."
#include "movement-packet.h"
typedef uintptr_t (__fastcall *MotionVectorFn)(uintptr_t,int32_t,int32_t,uintptr_t);
static MotionVectorFn originalMotion[2];static volatile LONG movementEnabled;
static uintptr_t fixturePlayer,worldLastInstance;static ULONGLONG worldLastDraw,overlayLiveTick;static uint32_t overlayLivePid=4242;
static unsigned char fixtureActor[1400],fixtureState[1024],pools[2][1024],packet[80];
static int32_t fixtureTime=4096;static float fixtureUp=1;static bool fixtureInput=true,packetAvailable=true,stalePacket,wrongForeground,failEnable,failSet,nativeActive,releaseSeen;
static unsigned calls,switches,enables,disables,sets;static uintptr_t lastArgs[3];
static uintptr_t fixtureNextProcess;
static unsigned kindOf(uintptr_t anim){return anim==fixturePlayer+0x448?1:0;}
static bool srGroundMovingInput(void){return fixtureInput;}
static DWORD mockForeground(HWND h,LPDWORD pid){(void)h;*pid=wrongForeground?0:GetCurrentProcessId();return 1;}
#define GetWindowThreadProcessId mockForeground
static bool worldRoot(float root[16],uintptr_t *player){memset(root,0,64);root[0]=root[5]=root[15]=1;root[10]=fixtureUp;*player=fixturePlayer;return true;}
static bool worldRead(uintptr_t at,void *out,size_t size){
 if(at==0x10000000+0x2a89628&&size==4){memcpy(out,&fixtureTime,4);return true;}
 for(unsigned k=0;k<2;k++)if(at==0x10000000+(k?0x2bea48:0x2bea30)&&size==8){uintptr_t pool=(uintptr_t)pools[k];memcpy(out,&pool,8);return true;}
 if(at<0x100000000)return false;memcpy(out,(void *)at,size);return true;
}
static bool movementReadPacket(unsigned char out[80]){if(!packetAvailable)return false;memcpy(out,packet,80);uint64_t tick=GetTickCount64()-(stalePacket?500:0);memcpy(out+16,&tick,8);return true;}
static bool hashBytes(const void *p,ULONG n,char *out){(void)p;(void)n;(void)out;return false;}
static void logLine(const char *fmt,...){(void)fmt;}
#include "instant-root.h"
static uintptr_t __fastcall mockSet(uintptr_t anim,int32_t section,int32_t type,uintptr_t values){
 ++sets;if(section||type!=34)return 0;unsigned k=kindOf(anim);if(failSet&&k)return 0;
 memcpy(pools[k]+(k?64:48)+0x20,(void *)values,k?12:6);return 0xf00d;
}
static uintptr_t __fastcall mockEnable(uintptr_t anim,int32_t section,int32_t type){
 ++enables;unsigned k=kindOf(anim);if(section||type!=34||(failEnable&&k))return 0;uint16_t head[2]={1,0};memcpy((void *)(anim+2),head,4);memset(pools[k]+(k?64:48)+0x20,0,k?12:6);return 1;
}
static uintptr_t __fastcall mockDisable(uintptr_t anim,int32_t section,int32_t type){
 ++disables;if(section||type!=34)return 0;uint16_t head[2]={0,1};memcpy((void *)(anim+2),head,4);return 1;
}
static uintptr_t __fastcall mockState(uintptr_t state,int32_t section,uintptr_t data){
 ++calls;lastArgs[0]=state;lastArgs[1]=(uintptr_t)section;lastArgs[2]=data;
 if(section==0&&fixtureNextProcess){memcpy((void *)(state+0x10),&fixtureNextProcess,8);fixtureNextProcess=0;}
 if(section==0&&calls>1&&*(uint16_t *)(fixtureActor+0x32a)==0&&*(uint16_t *)(fixtureActor+0x44a)==0)releaseSeen=true;
 if(nativeActive&&section==0){int16_t small[3]={0,-35,0};float wide[3]={0,-35,0};mockEnable(fixturePlayer+0x328,0,34);mockEnable(fixturePlayer+0x448,0,34);mockSet(fixturePlayer+0x328,0,34,(uintptr_t)small);mockSet(fixturePlayer+0x448,0,34,(uintptr_t)wide);}
 return 0xabcd;
}
static uintptr_t __fastcall mockSwitch(uintptr_t state,uintptr_t target,uintptr_t data){
 ++switches;if(target!=instantRootModule+0xf3280||data)return 0;
 for(int section=0;section<3;section++)rootStateObserve(0,state,section,0);
 memcpy((void *)(state+0x10),&target,8);return 0xfedc;
}
#define CHECK(x) do{if(!(x)){printf("FAIL line %d\n",__LINE__);return 1;}}while(0)
static void reset(void){
 memset(fixtureActor,0,sizeof(fixtureActor));memset(fixtureState,0,sizeof(fixtureState));memset(pools,0,sizeof(pools));
 fixturePlayer=(uintptr_t)fixtureActor;worldLastInstance=fixturePlayer;memcpy(fixtureState,&fixturePlayer,8);
 instantRootModule=0x10000000;uintptr_t proc=instantRootModule+0xf2180;memcpy(fixtureState+0x10,&proc,8);
 for(unsigned k=0;k<2;k++){unsigned stride=k?64:48;pools[k][stride+2]=34;uint16_t heads[2]={0,1};memcpy(fixtureActor+(k?0x44a:0x32a),heads,4);rootEnable[k]=mockEnable;rootDisable[k]=mockDisable;originalMotion[k]=mockSet;}
 for(unsigned k=0;k<4;k++)originalRootState[k]=mockState;
 int16_t position[3]={11,22,-4828};memcpy(fixtureActor+0x9c,position,6);
 rootCharacterSwitch=mockSwitch;instantRootBegin=worldLastDraw=overlayLiveTick=GetTickCount64();instantRootOwned=0;instantRootOwner=0;instantRootFailed=false;instantRootEnabled=0;instantRootBusy=0;movementEnabled=1;
 calls=switches=enables=disables=sets=0;fixtureNextProcess=0;instantRootFrames=0;instantRootWasMoving=false;packetAvailable=fixtureInput=true;stalePacket=wrongForeground=failEnable=failSet=nativeActive=releaseSeen=false;fixtureTime=4096;fixtureUp=1;
}
int main(int argc,char **argv){
 CHECK(argc==2);FILE *in=fopen(argv[1],"rb");CHECK(in&&fread(packet,80,1,in)==1);fclose(in);reset();
 CHECK(rootStationary((uintptr_t)fixtureState,0,0x9876)==0xabcd&&calls==1&&switches==0&&sets==0&&lastArgs[2]==0x9876);
 instantRootEnabled=1;CHECK(rootStationary((uintptr_t)fixtureState,0,0x9876)==0xabcd&&switches==1&&calls==5&&sets==2&&instantRootOwned==3&&instantRootFrames==1);
 RootController c;CHECK(rootControllerRead(instantRootModule,fixturePlayer+0x448,1,&c)&&c.found&&c.active&&((float *)c.vector)[1]==-60);
 CHECK(rootMoving((uintptr_t)fixtureState,0,0x888)==0xabcd&&releaseSeen&&disables==2&&sets==4&&instantRootFrames==2);
 fixtureInput=false;rootMoving((uintptr_t)fixtureState,0,0);CHECK(!instantRootOwned&&disables==4&&sets==4);
 int16_t pos[3];memcpy(pos,fixtureActor+0x9c,6);CHECK(pos[0]==11&&pos[1]==22&&pos[2]==-4828);
 // Original stationary callback may transition to turning before our post-hook.
 reset();instantRootEnabled=1;fixtureNextProcess=instantRootModule+0xf5340;rootStationary((uintptr_t)fixtureState,0,0);CHECK(switches==0&&sets==2&&instantRootFrames==1);
 CHECK(*(uintptr_t *)(fixtureState+0x10)==instantRootModule+0xf5340);
 for(unsigned k=0;k<2;k++){CHECK(rootControllerRead(instantRootModule,fixturePlayer+(k?0x448:0x328),k,&c));unsigned char zero[12]={0};CHECK(!memcmp(c.vector,zero,k?12:6));}
 // Native turn exits to StartMove: full-speed onset resumes in that callback.
 fixtureNextProcess=instantRootModule+0xf4dc0;rootTurning((uintptr_t)fixtureState,0,0);CHECK(switches==1&&sets==4);
 CHECK(rootControllerRead(instantRootModule,fixturePlayer+0x448,1,&c)&&((float *)c.vector)[1]==-60);
 // Both early transition handlers must work even without a stationary call.
 for(unsigned k=2;k<4;k++){reset();instantRootEnabled=1;uintptr_t p=instantRootModule+rootStateRvas[k];memcpy(fixtureState+0x10,&p,8);CHECK(rootStateObserve(k,(uintptr_t)fixtureState,0,0x55)==0xabcd&&switches==(k==2?1u:0u)&&sets==2&&instantRootFrames==1);}
 // Preserve native action transitions and released input instead of forcing Move.
 reset();instantRootEnabled=1;fixtureNextProcess=instantRootModule+0xedb40;rootStationary((uintptr_t)fixtureState,0,0);CHECK(!switches&&!sets&&*(uintptr_t *)(fixtureState+0x10)==instantRootModule+0xedb40);
 reset();instantRootEnabled=1;fixtureInput=false;uintptr_t turning=instantRootModule+0xf5340;memcpy(fixtureState+0x10,&turning,8);rootTurning((uintptr_t)fixtureState,0,0);CHECK(!switches&&!sets&&*(uintptr_t *)(fixtureState+0x10)==turning);
 reset();instantRootEnabled=1;fixtureNextProcess=instantRootModule+0xf4dc0;rootStationary((uintptr_t)fixtureState,0,0);CHECK(switches==1&&sets==2);
 reset();instantRootEnabled=1;nativeActive=true;rootStationary((uintptr_t)fixtureState,0,0);CHECK(instantRootFrames==1&&!instantRootOwned);
 instantRootEnabled=0;rootMoving((uintptr_t)fixtureState,0,0);CHECK(!disables&&rootControllerRead(instantRootModule,fixturePlayer+0x448,1,&c)&&((float *)c.vector)[1]==-35);
 reset();instantRootEnabled=1;failEnable=true;rootStationary((uintptr_t)fixtureState,0,0);CHECK(instantRootFailed&&!instantRootEnabled&&!instantRootOwned&&disables==1);
 reset();instantRootEnabled=1;failSet=true;rootStationary((uintptr_t)fixtureState,0,0);CHECK(instantRootFailed&&!instantRootOwned&&disables==2);
 reset();instantRootEnabled=1;packetAvailable=false;rootStationary((uintptr_t)fixtureState,0,0);CHECK(!sets&&!switches);packetAvailable=true;stalePacket=true;rootStationary((uintptr_t)fixtureState,0,0);CHECK(!sets);stalePacket=false;
 fixtureInput=false;rootStationary((uintptr_t)fixtureState,0,0);CHECK(!sets);fixtureInput=true;wrongForeground=true;rootStationary((uintptr_t)fixtureState,0,0);CHECK(!sets);wrongForeground=false;
 *(int32_t *)(fixtureActor+0x2d4)=10;rootStationary((uintptr_t)fixtureState,0,0);CHECK(!sets);*(int32_t *)(fixtureActor+0x2d4)=0;
 fixtureTime=0;rootStationary((uintptr_t)fixtureState,0,0);CHECK(!sets);fixtureTime=4096;fixtureUp=.5f;rootStationary((uintptr_t)fixtureState,0,0);CHECK(!sets);fixtureUp=1;
 rootStationary((uintptr_t)fixtureState,1,0);CHECK(!sets);instantRootBegin=GetTickCount64()-(uint64_t)sheet_diagnosticLimits_controls.durationMs-1;rootStationary((uintptr_t)fixtureState,0,0);CHECK(!sets);
 reset();RootController bad;uint16_t loop=1;memcpy(pools[0]+48,&loop,2);CHECK(!rootControllerRead(instantRootModule,fixturePlayer+0x328,0,&bad));
 reset();uint16_t duplicate=2;memcpy(pools[0]+48,&duplicate,2);pools[0][96+2]=34;CHECK(!rootControllerRead(instantRootModule,fixturePlayer+0x328,0,&bad));
 reset();float nan=NAN;memcpy(pools[1]+64+0x20,&nan,4);CHECK(!rootControllerRead(instantRootModule,fixturePlayer+0x448,1,&bad));
 reset();instantRootTick();instantRootStop();instantRootInstall(NULL);
 puts("Instant root: original args/result, stationary/start/turn transitions, native action/release preservation, early paired vectors, activation ownership/release before original, recursion, fallback/failure restore, bounded/cyclic/ambiguous controller rejection PASS");return 0;
}
