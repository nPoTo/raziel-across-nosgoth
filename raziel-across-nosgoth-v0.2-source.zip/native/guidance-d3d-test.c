// SPDX-License-Identifier: GPL-3.0-or-later
#define WIN32_LEAN_AND_MEAN
#define COBJMACROS
#include <windows.h>
#include <stdint.h>
#include <stdbool.h>
#include <stdio.h>
#include <string.h>
#include <wchar.h>
#include <stddef.h>
#include <stdarg.h>
#include <MinHook.h>
static HMODULE self;
static void logLine(const char *format,...){va_list args;va_start(args,format);vprintf(format,args);puts("");va_end(args);}
#include "recording-status.h"
#include "guidance.h"
#include "guidance-present.h"
static unsigned forwards;static UINT seenInterval,seenFlags;static const DXGI_PRESENT_PARAMETERS *seenParameters;
static HRESULT STDMETHODCALLTYPE testPresent(IDXGISwapChain *c,UINT interval,UINT flags){(void)c;forwards++;seenInterval=interval;seenFlags=flags;return DXGI_ERROR_WAS_STILL_DRAWING;}
static HRESULT STDMETHODCALLTYPE testPresent1(IDXGISwapChain1 *c,UINT interval,UINT flags,const DXGI_PRESENT_PARAMETERS *p){(void)c;forwards++;seenInterval=interval;seenFlags=flags;seenParameters=p;return DXGI_STATUS_OCCLUDED;}
#define CHECK(c,n) do{if(!(c)){printf("FAIL %d\n",n);return n;}}while(0)
int main(void){
 setvbuf(stdout,NULL,_IONBF,0);
 self=GetModuleHandleW(NULL);guidanceDraw(NULL);guidanceOriginalPresent=testPresent;guidanceOriginalPresent1=testPresent1;
 CHECK(guidancePresent(NULL,5,DXGI_PRESENT_TEST)==DXGI_ERROR_WAS_STILL_DRAWING&&forwards==1&&seenInterval==5&&seenFlags==DXGI_PRESENT_TEST,1);
 DXGI_PRESENT_PARAMETERS parameters={0};parameters.DirtyRectsCount=1;
 CHECK(guidancePresent1(NULL,7,DXGI_PRESENT_DO_NOT_WAIT,&parameters)==DXGI_STATUS_OCCLUDED&&forwards==2&&seenInterval==7&&seenParameters==&parameters,2);
 CHECK(guidancePresentInstall(),3);
 WNDCLASSW wc={0};wc.lpfnWndProc=DefWindowProcW;wc.hInstance=self;wc.lpszClassName=L"LOKGuidanceD3DTest";CHECK(RegisterClassW(&wc),4);
 HWND window=CreateWindowW(wc.lpszClassName,L"Hidden owned D3D HUD test",WS_POPUP,0,0,1280,720,NULL,NULL,self,NULL);CHECK(window,5);
 DXGI_SWAP_CHAIN_DESC sd={0};sd.BufferDesc.Width=1280;sd.BufferDesc.Height=720;sd.BufferDesc.Format=DXGI_FORMAT_R8G8B8A8_UNORM;sd.SampleDesc.Count=1;sd.BufferUsage=DXGI_USAGE_RENDER_TARGET_OUTPUT;sd.BufferCount=1;sd.OutputWindow=window;sd.Windowed=TRUE;
 IDXGISwapChain *chain=NULL;ID3D11Device *device=NULL;ID3D11DeviceContext *context=NULL;CHECK(SUCCEEDED(D3D11CreateDeviceAndSwapChain(NULL,D3D_DRIVER_TYPE_WARP,NULL,0,NULL,0,D3D11_SDK_VERSION,&sd,&chain,&device,NULL,&context)),6);
 CHECK(SUCCEEDED(guidanceD3DInit(&guidanceD3D,device)),7);
 ID3D11Texture2D *buffer=NULL;ID3D11RenderTargetView *target=NULL;CHECK(SUCCEEDED(IDXGISwapChain_GetBuffer(chain,0,&IID_ID3D11Texture2D,(void **)&buffer)),8);
 CHECK(SUCCEEDED(ID3D11Device_CreateRenderTargetView(device,(ID3D11Resource *)buffer,NULL,&target)),9);
 float clear[4]={.1f,.2f,.4f,1};ID3D11DeviceContext_ClearRenderTargetView(context,target,clear);ID3D11DeviceContext_OMSetRenderTargets(context,1,&target,NULL);
 ID3D11DeviceContext_IASetPrimitiveTopology(context,D3D11_PRIMITIVE_TOPOLOGY_LINELIST);ID3D11DeviceContext_VSSetShader(context,guidanceD3D.vs,NULL,0);ID3D11DeviceContext_PSSetShader(context,guidanceD3D.ps,NULL,0);
 ID3D11DeviceContext_VSSetConstantBuffers(context,6,1,&guidanceD3D.bounds);ID3D11DeviceContext_PSSetShaderResources(context,5,1,&guidanceD3D.view);ID3D11DeviceContext_PSSetSamplers(context,3,1,&guidanceD3D.sampler);
 D3D11_VIEWPORT viewport={9,7,700,300,.2f,.8f};ID3D11DeviceContext_RSSetViewports(context,1,&viewport);D3D11_RASTERIZER_DESC rd={0};rd.FillMode=D3D11_FILL_WIREFRAME;rd.CullMode=D3D11_CULL_FRONT;rd.ScissorEnable=TRUE;ID3D11RasterizerState *raster=NULL;CHECK(SUCCEEDED(ID3D11Device_CreateRasterizerState(device,&rd,&raster)),10);ID3D11DeviceContext_RSSetState(context,raster);
 HRESULT error=E_FAIL;CHECK(guidanceD3DRender(chain,10,3,&error),11);
 ID3D11RenderTargetView *actualTarget=NULL;ID3D11DeviceContext_OMGetRenderTargets(context,1,&actualTarget,NULL);CHECK(actualTarget==target,12);GUIDANCE_RELEASE(actualTarget,ID3D11RenderTargetView);
 ID3D11RasterizerState *actualRaster=NULL;ID3D11DeviceContext_RSGetState(context,&actualRaster);CHECK(actualRaster==raster,13);GUIDANCE_RELEASE(actualRaster,ID3D11RasterizerState);
 D3D11_VIEWPORT actualViewport;UINT count=1;ID3D11DeviceContext_RSGetViewports(context,&count,&actualViewport);CHECK(count==1&&!memcmp(&viewport,&actualViewport,sizeof(viewport)),14);
 D3D11_PRIMITIVE_TOPOLOGY topology;ID3D11DeviceContext_IAGetPrimitiveTopology(context,&topology);CHECK(topology==D3D11_PRIMITIVE_TOPOLOGY_LINELIST,15);
 ID3D11VertexShader *actualVs=NULL;ID3D11PixelShader *actualPs=NULL;ID3D11DeviceContext_VSGetShader(context,&actualVs,NULL,NULL);ID3D11DeviceContext_PSGetShader(context,&actualPs,NULL,NULL);CHECK(actualVs==guidanceD3D.vs&&actualPs==guidanceD3D.ps,16);GUIDANCE_RELEASE(actualVs,ID3D11VertexShader);GUIDANCE_RELEASE(actualPs,ID3D11PixelShader);
 ID3D11Buffer *actualCb=NULL;ID3D11ShaderResourceView *actualView=NULL;ID3D11SamplerState *actualSampler=NULL;ID3D11DeviceContext_VSGetConstantBuffers(context,6,1,&actualCb);ID3D11DeviceContext_PSGetShaderResources(context,5,1,&actualView);ID3D11DeviceContext_PSGetSamplers(context,3,1,&actualSampler);CHECK(actualCb==guidanceD3D.bounds&&actualView==guidanceD3D.view&&actualSampler==guidanceD3D.sampler,17);GUIDANCE_RELEASE(actualCb,ID3D11Buffer);GUIDANCE_RELEASE(actualView,ID3D11ShaderResourceView);GUIDANCE_RELEASE(actualSampler,ID3D11SamplerState);
 D3D11_TEXTURE2D_DESC td;ID3D11Texture2D_GetDesc(buffer,&td);td.Usage=D3D11_USAGE_STAGING;td.BindFlags=0;td.CPUAccessFlags=D3D11_CPU_ACCESS_READ;ID3D11Texture2D *readback=NULL;CHECK(SUCCEEDED(ID3D11Device_CreateTexture2D(device,&td,NULL,&readback)),18);ID3D11DeviceContext_CopyResource(context,(ID3D11Resource *)readback,(ID3D11Resource *)buffer);
 D3D11_MAPPED_SUBRESOURCE mapped;CHECK(SUCCEEDED(ID3D11DeviceContext_Map(context,(ID3D11Resource *)readback,0,D3D11_MAP_READ,0,&mapped)),19);
 unsigned white=0;for(unsigned y=0;y<720;y++)for(unsigned x=0;x<1280;x++){const unsigned char *p=(const unsigned char *)mapped.pData+y*mapped.RowPitch+x*4;if(p[0]>220&&p[1]>220&&p[2]>220)white++;}
 const unsigned char *outside=(const unsigned char *)mapped.pData+2*mapped.RowPitch+8;CHECK(white>200&&outside[0]>=24&&outside[0]<=27&&outside[1]==51&&outside[2]==102,20);
 FILE *out=fopen("reports/build-tasks/native-guidance-d3d-preview.bmp","wb");CHECK(out,21);BITMAPFILEHEADER bh={0};BITMAPINFOHEADER bi={0};bh.bfType=0x4d42;bh.bfOffBits=sizeof(bh)+sizeof(bi);bh.bfSize=bh.bfOffBits+1280*720*4;bi.biSize=sizeof(bi);bi.biWidth=1280;bi.biHeight=-720;bi.biPlanes=1;bi.biBitCount=32;fwrite(&bh,sizeof(bh),1,out);fwrite(&bi,sizeof(bi),1,out);
 for(unsigned y=0;y<720;y++)for(unsigned x=0;x<1280;x++){const unsigned char *p=(const unsigned char *)mapped.pData+y*mapped.RowPitch+x*4;unsigned char bgra[4]={p[2],p[1],p[0],p[3]};fwrite(bgra,4,1,out);}fclose(out);
 ID3D11DeviceContext_Unmap(context,(ID3D11Resource *)readback,0);GUIDANCE_RELEASE(readback,ID3D11Texture2D);ID3D11DeviceContext_ClearState(context);GUIDANCE_RELEASE(target,ID3D11RenderTargetView);GUIDANCE_RELEASE(buffer,ID3D11Texture2D);GUIDANCE_RELEASE(raster,ID3D11RasterizerState);
 CHECK(SUCCEEDED(IDXGISwapChain_ResizeBuffers(chain,1,960,540,DXGI_FORMAT_UNKNOWN,0)),22);CHECK(guidanceD3DRender(chain,1,216,&error)&&guidanceD3D.second==216,23);CHECK(!guidanceD3DRender(chain,10,20,&error),24);
 CHECK(SUCCEEDED(IDXGISwapChain_Present(chain,0,DXGI_PRESENT_TEST)),25);
 // The default game context has no HUD work when there is no owned descriptor/heartbeat.
 IDXGISwapChain_Present(chain,0,0);CHECK(guidancePresentCalls>0&&!guidanceActive,26);
 CHECK(guidanceDXGITarget((PVOID)chain->lpVtbl->Present)&&!guidanceDXGITarget((PVOID)&main),34);
 wchar_t descriptorPath[512],ackPath[512],statusPath[512];DWORD ownPid=GetCurrentProcessId();
 _snwprintf(descriptorPath,512,PROBE_PATH(L"\\guidance-%lu.bin"),ownPid);_snwprintf(ackPath,512,PROBE_PATH(L"\\guidance-visible-%lu.bin"),ownPid);recordingStatusPath(statusPath,ownPid);
 CHECK(GetFileAttributesW(descriptorPath)==INVALID_FILE_ATTRIBUTES&&GetFileAttributesW(ackPath)==INVALID_FILE_ATTRIBUTES&&GetFileAttributesW(statusPath)==INVALID_FILE_ATTRIBUTES,27);
 GuidanceDescriptor descriptor={0x31445548,1,ownPid,ownPid,10,20,200,0,77,{0}};
 for(unsigned i=0;i<32;i++)descriptor.sheetHash[i]=(unsigned char)(guidanceHex(EXPLORATION_SHEET_SHA256[i*2])*16+guidanceHex(EXPLORATION_SHEET_SHA256[i*2+1]));
 HANDLE file=CreateFileW(descriptorPath,GENERIC_WRITE,FILE_SHARE_READ,NULL,CREATE_NEW,FILE_ATTRIBUTE_NORMAL,NULL);DWORD written=0;CHECK(file!=INVALID_HANDLE_VALUE&&WriteFile(file,&descriptor,sizeof(descriptor),&written,NULL)&&written==sizeof(descriptor),28);CloseHandle(file);
 recordingWriteStatus(ownPid,1,200);guidancePoll=0;IDXGISwapChain_Present(chain,0,0);CHECK(guidanceActive&&guidanceFrames>0,29);
 file=CreateFileW(ackPath,GENERIC_READ,FILE_SHARE_READ|FILE_SHARE_WRITE|FILE_SHARE_DELETE,NULL,OPEN_EXISTING,FILE_ATTRIBUTE_NORMAL,NULL);GuidanceVisible ack={0};CHECK(file!=INVALID_HANDLE_VALUE&&ReadFile(file,&ack,sizeof(ack),&written,NULL)&&written==sizeof(ack),30);CloseHandle(file);CHECK(ack.magic==0x31534956&&ack.session==77&&ack.writerPid==ownPid&&ack.plan==10&&ack.tick&&ack.frames,31);
 unsigned long frames=guidanceFrames;IDXGISwapChain_Present(chain,0,DXGI_PRESENT_TEST);CHECK(guidanceFrames==frames,32);
 recordingStopStatus(ownPid);DeleteFileW(descriptorPath);guidancePoll=0;IDXGISwapChain_Present(chain,0,0);CHECK(!guidanceActive&&guidanceFrames==frames,33);DeleteFileW(ackPath);
 guidanceD3DRelease(&guidanceD3D);GUIDANCE_RELEASE(context,ID3D11DeviceContext);GUIDANCE_RELEASE(device,ID3D11Device);GUIDANCE_RELEASE(chain,IDXGISwapChain);DestroyWindow(window);
 printf("PASS: D3D11 HUD white pixels=%u, public DXGI hook, exact HRESULT/args forwarding, context-state restoration, ResizeBuffers, real heartbeat/descriptor draw acknowledgement and ended/idle gates\n",white);return 0;
}
