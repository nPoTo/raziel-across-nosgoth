// SPDX-License-Identifier: GPL-3.0-or-later
#pragma once
#include "host-contact-shared.h"
#include "bridge-process-identity.h"

// Attach on the worker, never in a draw/collision hook. The owner must first
// validate the installed executable/module and obtain these exact host tokens.
// This reader cannot discover or adopt a replacement host session by itself.
typedef struct {
 HANDLE process,mapping;
 const HostContactShared *view;
 HostContactLease lease;
 bool attempted;
} HostContactReader;
static inline void hostContactReaderClose(HostContactReader *r){
 if(!r)return;
 r->lease.revoked=true;
 if(r->view){UnmapViewOfFile(r->view);r->view=NULL;}
 if(r->mapping){CloseHandle(r->mapping);r->mapping=NULL;}
 if(r->process){CloseHandle(r->process);r->process=NULL;}
}
static inline bool hostContactReaderOpen(HostContactReader *r,HostContactLease expected){
 if(!r||r->attempted)return false;
 r->attempted=true;r->lease=expected;
 if(!expected.pid||!expected.creation||!expected.epoch||!expected.actor||expected.seen||expected.revoked)goto fail;
 r->process=OpenProcess(PROCESS_QUERY_LIMITED_INFORMATION|SYNCHRONIZE,FALSE,expected.pid);
 uint64_t creation=0;
 if(!r->process||WaitForSingleObject(r->process,0)!=WAIT_TIMEOUT||!bridgeProcessCreation(r->process,&creation)||creation!=expected.creation)goto fail;
 wchar_t name[96];hostContactMappingName(name,expected.pid);
 r->mapping=OpenFileMappingW(FILE_MAP_READ,FALSE,name);
 if(!r->mapping)goto fail;
 r->view=MapViewOfFile(r->mapping,FILE_MAP_READ,0,0,sizeof(*r->view));
 if(!r->view)goto fail;
 return true;
fail:
 hostContactReaderClose(r);return false;
}
// Single worker owns read/close. Return no old snapshot on a failed/torn read.
// Revocation stays latched until the owner explicitly creates a NEW reader.
static inline bool hostContactReaderRead(HostContactReader *r,uint64_t now,HostContactSnapshot *out,bool *fresh){
 if(out)memset(out,0,sizeof(*out));if(fresh)*fresh=false;
 if(!r||!out||!fresh||r->lease.revoked)return false;
 HostContactSnapshot next={0};
 if(!hostContactCopy(r->view,&next)||!hostContactAccept(&r->lease,&next,now,r->process&&WaitForSingleObject(r->process,0)==WAIT_TIMEOUT,fresh)){
  r->lease.revoked=true;return false;
 }
 *out=next;return true;
}
