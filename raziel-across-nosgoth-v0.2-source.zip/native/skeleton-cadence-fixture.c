// SPDX-License-Identifier: GPL-3.0-or-later
// Synthetic0-mode packets only; mapping owner is the parent test process.
#define WIN32_LEAN_AND_MEAN
#include "sr1-skeleton-shared.h"
#include "capture-cadence.h"
#include <stdio.h>
#include <stdlib.h>
#include <io.h>
#include <fcntl.h>
int main(int argc,char **argv){
 if(argc!=3||GetFileType(GetStdHandle(STD_OUTPUT_HANDLE))!=FILE_TYPE_PIPE)return 1;
 char *e=NULL;unsigned long host=strtoul(argv[1],&e,10);if(!host||*e)return 1;unsigned long writer=strtoul(argv[2],&e,10);if(!writer||*e||writer==host)return 1;
 LARGE_INTEGER frequency,origin;if(!QueryPerformanceFrequency(&frequency)||!QueryPerformanceCounter(&origin))return 2;
 HANDLE timer=CreateWaitableTimerExW(NULL,NULL,2,TIMER_ALL_ACCESS);if(!timer)timer=CreateWaitableTimerW(NULL,FALSE,NULL);
 _setmode(_fileno(stdout),_O_BINARY);SkeletonSnapshot s={.magic=SKELETON_MAGIC,.version=1,.hostPid=host,.sourcePid=GetCurrentProcessId(),.writerPid=writer,.mode=0,.actor=1,.object=2,.model=3,.epoch=GetTickCount64()};memcpy(s.policyHash,skeletonPolicyHash,32);
 for(unsigned i=0;i<180;i++){
  s.tick=s.hostTick=s.sourceTick=GetTickCount64();s.sequence=i+1;if(fwrite(&s,1,sizeof(s),stdout)!=sizeof(s)){if(timer)CloseHandle(timer);return 3;}fflush(stdout);
  if(i+1<180){LARGE_INTEGER now;QueryPerformanceCounter(&now);uint64_t due=captureNext60(origin.QuadPart,now.QuadPart,frequency.QuadPart),remain=due-now.QuadPart;LARGE_INTEGER wait;wait.QuadPart=-(LONGLONG)(remain*10000000/(uint64_t)frequency.QuadPart);if(timer&&SetWaitableTimer(timer,&wait,0,NULL,NULL,FALSE))WaitForSingleObject(timer,50);else Sleep((DWORD)(remain*1000/(uint64_t)frequency.QuadPart));}
 }
 if(timer)CloseHandle(timer);return 0;
}
