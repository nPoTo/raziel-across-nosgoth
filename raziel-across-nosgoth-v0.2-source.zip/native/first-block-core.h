// SPDX-License-Identifier: GPL-3.0-or-later
#pragma once
#include <windows.h>
#include <stdint.h>
#include <stdbool.h>
#include <string.h>
#include "exploration-sheets.h"
enum {FB_UNKNOWN,FB_IDLE,FB_ENTRY,FB_HELD_ENTRY,FB_STILL,FB_LOWER,FB_A,FB_B};
enum {FB_CLEAR,FB_HOLD,FB_MOVE_A,FB_MOVE_B};
typedef struct {uint64_t session,sequence,tick;uint32_t valid,desired,phases[3],reserved;} FirstBlockIntent;
typedef struct {uint64_t sequence,tick,frames;uint32_t owned,held,pressed,released,desired,primary[3],keys[3],overrides[4],failure,pressTrue,releaseTrue,heldTrue,gates,targetValid,targetHandler;} FirstBlockAck;
typedef struct {uint64_t session,lastSequence,started,releaseTick;bool owns,releaseSent,needIdle,pressed,held,released,suppress;uint32_t desired,failure;unsigned queryCount[4];uint32_t motionEpisodeDesired;bool motionReady,motionRequested,motionAccepted;} FirstBlockControl;
static inline unsigned firstBlockPhase(uint32_t handler,uint16_t clip,unsigned section){
 if(section>=3)return FB_UNKNOWN;
 for(unsigned i=0;i<sheet_firstBlockHostPhases_count;i++){const Sheet_firstBlockHostPhases *r=sheet_firstBlockHostPhases_rows[i];if(r->handlerRva==handler&&r->clip==clip&&(r->sectionMask&(1u<<section))){
  const wchar_t *s=r->phase;if(!wcscmp(s,L"idle"))return FB_IDLE;if(!wcscmp(s,L"entry"))return FB_ENTRY;if(!wcscmp(s,L"held-entry"))return FB_HELD_ENTRY;if(!wcscmp(s,L"held-upper-still"))return FB_STILL;if(!wcscmp(s,L"held-lower"))return FB_LOWER;if(!wcscmp(s,L"motion-a"))return FB_A;if(!wcscmp(s,L"motion-b"))return FB_B;
 }}return FB_UNKNOWN;
}
static inline bool firstBlockDesired(const unsigned p[3],unsigned *desired){
 *desired=FB_CLEAR;
 if(p[0]==FB_IDLE&&p[1]==FB_IDLE&&(p[2]==FB_IDLE||p[2]==FB_LOWER))return true; // original lower-section release lag
 if(p[0]==FB_ENTRY&&p[1]==FB_ENTRY&&p[2]==FB_ENTRY){*desired=FB_HOLD;return true;}
 if(p[0]==FB_HELD_ENTRY&&p[1]==FB_HELD_ENTRY&&p[2]==FB_HELD_ENTRY){*desired=FB_HOLD;return true;}
 if(p[2]==FB_LOWER&&p[0]==p[1]){if(p[0]==FB_STILL)*desired=FB_HOLD;else if(p[0]==FB_A)*desired=FB_MOVE_A;else if(p[0]==FB_B)*desired=FB_MOVE_B;else return false;return true;}return false;
}
static inline bool firstBlockIntentValid(const FirstBlockIntent *c,uint64_t now){
 unsigned desired=0;return c&&c->session&&c->sequence&&c->tick&&now>=c->tick&&now-c->tick<=(uint64_t)sheet_firstBlockPilotPolicy_bounded.freshMs&&c->reserved==0&&c->valid==1&&c->desired<=FB_MOVE_B&&firstBlockDesired(c->phases,&desired)&&desired==c->desired;
}
// A contended slot is not an invalid publication. Reuse only the last complete
// scalar snapshot within the same150ms deadline; explicit invalid data or peer
// loss replaces/revokes it immediately. No native pointers are cached.
static inline void firstBlockSnapshot(FirstBlockIntent *cache,bool ready,bool copied,const FirstBlockIntent *incoming,uint64_t session,FirstBlockIntent *out){if(!ready||(copied&&incoming->session!=session))*cache=(FirstBlockIntent){0};else if(copied)*cache=*incoming;*out=*cache;}
static inline void firstBlockBegin(FirstBlockControl *s,const FirstBlockIntent *c,uint64_t now,bool nativeSupported,bool nativeIdle,bool targetReady){
 s->pressed=s->released=s->held=false;memset(s->queryCount,0,sizeof(s->queryCount));
 bool valid=firstBlockIntentValid(c,now)&&nativeSupported;
 if(valid&&s->session&&s->session!=c->session)valid=false;
 if(valid&&s->lastSequence>c->sequence)valid=false;
 if(valid){s->session=c->session;s->lastSequence=c->sequence;}
 s->desired=valid?c->desired:FB_CLEAR;s->suppress=valid||s->owns;
 // Rearm from observed host phase edges, never from an invented cycle timer.
 if(s->desired<=FB_HOLD||s->motionEpisodeDesired!=s->desired){s->motionEpisodeDesired=s->desired>FB_HOLD?s->desired:FB_CLEAR;s->motionReady=s->motionRequested=s->motionAccepted=false;}
 if(s->desired==FB_CLEAR){if(valid)s->needIdle=false;if(s->owns){s->released=!s->releaseSent;if(!s->releaseSent)s->releaseTick=now;s->releaseSent=true;if(now>=s->releaseTick&&now-s->releaseTick>(uint64_t)sheet_firstBlockPilotPolicy_bounded.cancelDeadlineMs)s->failure=2;}return;}
 if(s->failure||s->needIdle)return;
 if(!s->owns){if(!nativeIdle||!targetReady)return;s->owns=true;s->started=now;s->pressed=true;s->releaseSent=false;}
 if(s->owns&&s->releaseSent)return;
 if(s->owns&&nativeIdle&&now>=s->started&&now-s->started>(uint64_t)sheet_firstBlockPilotPolicy_bounded.entryDeadlineMs){s->failure=1;s->released=!s->releaseSent;s->releaseTick=now;s->releaseSent=true;s->needIdle=true;return;}
 s->held=s->owns;s->suppress=s->suppress||s->owns;
}
static inline void firstBlockAfter(FirstBlockControl *s,bool nativeIdle){if(s->owns&&s->releaseSent&&nativeIdle){s->owns=false;s->needIdle=true;s->held=false;}}
static inline void firstBlockMotionBefore(FirstBlockControl *s,bool valid,const uint32_t keys[3]){
 const Sheet_firstBlockMotionPolicy *p=&sheet_firstBlockMotionPolicy_phase_latch;
 s->motionReady=false;
 if(!p->enabled||!p->requireNativeNeutral||!p->oncePerObservedHostEpisode||!valid||!keys||!s->owns||!s->held||s->releaseSent||s->failure||s->desired<=FB_HOLD||s->motionAccepted)return;
 bool neutral=keys[0]==(uint32_t)p->neutralUpperKey&&keys[1]==(uint32_t)p->neutralUpperKey&&keys[2]==(uint32_t)p->neutralLowerKey;
 bool entry=keys[0]==(uint32_t)p->entryUpperKey&&keys[1]==(uint32_t)p->entryUpperKey&&keys[2]==(uint32_t)p->entryLowerKey;
 s->motionReady=neutral||entry;
}
static inline void firstBlockMotionAfter(FirstBlockControl *s,bool valid,const uint32_t keys[3]){
 const Sheet_firstBlockMotionPolicy *p=&sheet_firstBlockMotionPolicy_phase_latch;
 if(!valid||!keys||!s->owns||!s->held||s->releaseSent||s->failure||!s->motionRequested||s->desired<=FB_HOLD)return;
 uint32_t upper=(uint32_t)(s->desired==FB_MOVE_A?p->motionAUpperKey:p->motionBUpperKey);
 if(keys[0]==upper&&keys[1]==upper&&keys[2]==(uint32_t)p->motionLowerKey){s->motionAccepted=true;s->motionReady=false;}
}
// Native original always runs once. Change only its scalar result inside the
// verified current-Raziel frame and exact logical-query/caller scope.
static inline uintptr_t firstBlockQueryResult(FirstBlockControl *s,unsigned kind,unsigned query,bool scope,uintptr_t original){
 if(!scope||!s->suppress||(query!=69&&query!=73)||kind>2)return original;
 ++s->queryCount[kind];bool value=query==69&&(kind==0?s->pressed:kind==1?s->released:s->held);
 return (original&~(uintptr_t)255)|(value?1:0);
}
static inline uintptr_t firstBlockDirectionResult(FirstBlockControl *s,bool scope,uintptr_t original){
 if(!scope||!s->suppress)return original;++s->queryCount[3];uint32_t value=0;
 if(s->held&&s->motionReady&&!s->motionAccepted){if(s->desired==FB_MOVE_A)value=(uint32_t)sheet_firstBlockPilotPolicy_bounded.motionA;if(s->desired==FB_MOVE_B)value=(uint32_t)sheet_firstBlockPilotPolicy_bounded.motionB;}
 if(value)s->motionRequested=true;
 return (original&~(uintptr_t)UINT32_MAX)|value;
}
