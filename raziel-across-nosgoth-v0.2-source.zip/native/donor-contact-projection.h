// SPDX-License-Identifier: GPL-3.0-or-later
#pragma once
#include <stdint.h>
#include <stdbool.h>
#include <stddef.h>
#include <math.h>
#include <string.h>

// Installed Defiance 1039f0/103160/22410 layout, not an SR1 structure.
// Virtual flat support is only a donor animation contact. It never represents
// host terrain geometry or changes the actual SR1 collision calculation.
typedef struct {
 float normal[4];
 uint32_t kind,segment;
 uintptr_t primitive,owner;
 float start[4],end[4];
 uint32_t flags,reserved;
 uintptr_t actor;
} DonorContactLine;
_Static_assert(sizeof(DonorContactLine)==0x58,"Native line size");
_Static_assert(offsetof(DonorContactLine,kind)==0x10,"Native hit kind");
_Static_assert(offsetof(DonorContactLine,start)==0x28,"Native line start");
_Static_assert(offsetof(DonorContactLine,end)==0x38,"Native line end");
_Static_assert(offsetof(DonorContactLine,actor)==0x50,"Native actor");

typedef struct {
 uintptr_t actor;
 unsigned phase; // 1 completed host ground, 2 completed host air only
 bool admitted,poisoned;
 unsigned lineCalls,cachedCalls;
} DonorContactProjection;

static inline bool donorContactSkipCached(DonorContactProjection *scope,uintptr_t callerRva){
 if(!scope||!scope->admitted||scope->poisoned||!scope->actor||callerRva!=0x103b4d||
    (scope->phase!=1&&scope->phase!=2))return false;
 ++scope->cachedCalls;return true;
}
// Caller must pin the fresh host receipt and exact owned donor ground-query
// scope before entering the original native query. No runtime hook uses this
// candidate yet. Foreign calls must continue to the original untouched.
static inline bool donorContactProjectLine(DonorContactProjection *scope,uintptr_t callerRva,uintptr_t actor,
                                          DonorContactLine *line,const float actorPosition[3]){
 if(!scope||!line||!actorPosition||!scope->admitted||scope->poisoned||!scope->actor||
    (callerRva!=0x103bf5&&callerRva!=0x103c47)||actor!=scope->actor||line->flags!=0x3f||
    (scope->phase!=1&&scope->phase!=2))return false;
 // Only the proved vertical, ordinary support ray. Reject rather than use a
 // wall/ledge query, negative extents, NaN or a different actor's line.
 for(unsigned i=0;i<3;i++)if(!isfinite(actorPosition[i])||!isfinite(line->start[i])||!isfinite(line->end[i]))return false;
 if(line->start[0]!=actorPosition[0]||line->start[1]!=actorPosition[1]||
    line->end[0]!=actorPosition[0]||line->end[1]!=actorPosition[1]||
    line->start[2]<actorPosition[2]||line->end[2]>actorPosition[2])return false;
 DonorContactLine out=*line;out.actor=actor;
 memset(out.normal,0,sizeof(out.normal));out.kind=0;out.segment=0;out.primitive=0;out.owner=0;
 if(scope->phase==1){
  // 1039f0 accepts kind2 as support without dereferencing a terrain face or
  // level pointer. Up normal avoids the steep-slope secondary ray. A point at
  // the donor actor's origin yields zero positional correction in this query.
  out.kind=2;out.normal[2]=1.0f;out.end[2]=actorPosition[2];
 }
 *line=out;++scope->lineCalls;return true;
}
