// SPDX-License-Identifier: GPL-3.0-or-later
#pragma once
#include "first-block-core.h"
typedef struct {uint32_t magic,version,bytes,hostPid,donorPid,writerPid;uint64_t hostCreation,donorCreation,writerCreation,session,beginTick;unsigned char sheetHash[32];} FirstBlockHeader;
typedef struct {FirstBlockHeader header;volatile LONG intentLock;FirstBlockIntent intent;volatile LONG ackLock;FirstBlockAck ack;} FirstBlockMemory;
_Static_assert(sizeof(FirstBlockHeader)==96&&sizeof(FirstBlockIntent)==48&&sizeof(FirstBlockAck)==112&&sizeof(FirstBlockMemory)==272,"Version1 scalar pilot wire layout");
static inline void firstBlockName(wchar_t out[160],DWORD donor,uint64_t creation){swprintf(out,160,L"Local\\LOKBlockPilot1-%lu-%llu",(unsigned long)donor,(unsigned long long)creation);}
static inline bool firstBlockHash(const unsigned char value[32]){const char *s=EXPLORATION_SHEET_SHA256;for(unsigned i=0;i<32;i++){unsigned a=s[2*i]<='9'?s[2*i]-'0':s[2*i]-'a'+10,b=s[2*i+1]<='9'?s[2*i+1]-'0':s[2*i+1]-'a'+10;if(a>15||b>15||value[i]!=a*16+b)return false;}return true;}
static inline bool firstBlockHeaderValid(const FirstBlockHeader *h,DWORD donor,uint64_t creation){return h->magic==0x314b4c42&&h->version==1&&h->bytes==sizeof(FirstBlockMemory)&&h->hostPid&&h->donorPid==donor&&h->writerPid&&h->hostPid!=h->donorPid&&h->writerPid!=h->hostPid&&h->writerPid!=h->donorPid&&h->hostCreation&&h->donorCreation==creation&&h->writerCreation&&h->session&&h->beginTick&&firstBlockHash(h->sheetHash);}
// Separate try-locks, one owner per slot. Never hold either across native calls.
// An abandoned external producer leaves an unavailable slot, which expires.
static inline bool firstBlockReadIntent(FirstBlockMemory *m,FirstBlockIntent *c){if(!m||InterlockedCompareExchange(&m->intentLock,1,0))return false;*c=m->intent;InterlockedExchange(&m->intentLock,0);return true;}
static inline bool firstBlockWriteIntent(FirstBlockMemory *m,const FirstBlockIntent *c){if(!m||InterlockedCompareExchange(&m->intentLock,1,0))return false;m->intent=*c;InterlockedExchange(&m->intentLock,0);return true;}
static inline bool firstBlockReadAck(FirstBlockMemory *m,FirstBlockAck *a){if(!m||InterlockedCompareExchange(&m->ackLock,1,0))return false;*a=m->ack;InterlockedExchange(&m->ackLock,0);return true;}
static inline bool firstBlockWriteAck(FirstBlockMemory *m,const FirstBlockAck *a){if(!m||InterlockedCompareExchange(&m->ackLock,1,0))return false;m->ack=*a;InterlockedExchange(&m->ackLock,0);return true;}
