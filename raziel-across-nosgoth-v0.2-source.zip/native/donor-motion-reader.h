// Exact supported Defiance controller-pool layout; caller validates active Raziel.
typedef bool (*DonorMotionReadFn)(void *,uintptr_t,void *,size_t);

// Select the player's frame factor exactly as the supported instance loop does.
// Root-translation multiplication uses the selected factor at RVA112136.
typedef struct {bool valid;float factor;uint32_t selectedRva;} DonorTimeCandidate;
static DonorTimeCandidate donorTimeRead(DonorMotionReadFn read,void *ctx,uintptr_t base,uintptr_t instance){
    DonorTimeCandidate out={0};float after=0;uintptr_t owner=0,object=0,objectAfter=0;uint32_t objectFlags=0,instanceFlags=0,objectFlagsAfter=0,instanceFlagsAfter=0;
    // Exact selectors at RVA65805/6580b and7c642/7c648 use Object+4,
    // Instance+ac bit27, and normal/material/spectral frame-factor slots.
    if(!base||!instance||!read(ctx,instance+0x88,&object,8)||!object||!read(ctx,object+4,&objectFlags,4)||!read(ctx,instance+0xac,&instanceFlags,4))return out;
    out.selectedRva=(objectFlags&0x10)?((instanceFlags&0x08000000)?0xc5abc8:0xc5abcc):0xc5abc4;
    if(!read(ctx,base+out.selectedRva,&out.factor,4)||!isfinite(out.factor)||out.factor<=0||out.factor>8||
        !read(ctx,base+0xc5aa78,&owner,8)||owner!=instance||!read(ctx,base+out.selectedRva,&after,4)||memcmp(&after,&out.factor,4)||
        !read(ctx,instance+0x88,&objectAfter,8)||objectAfter!=object||!read(ctx,object+4,&objectFlagsAfter,4)||objectFlagsAfter!=objectFlags||
        !read(ctx,instance+0xac,&instanceFlagsAfter,4)||instanceFlagsAfter!=instanceFlags)return out;
    out.valid=true;return out;
}
typedef struct {bool valid,complete,stable;uintptr_t pool,node;uint16_t head,index,flags;unsigned visited;float vector[3];} DonorMotion;
static DonorMotion donorMotionRead(DonorMotionReadFn read,void *ctx,uintptr_t base,uintptr_t instance){
    DonorMotion out={0};uintptr_t poolAfter=0,playerAfter=0;uint16_t headAfter=0;
    if(!base||!instance||!read(ctx,base+0x10aa650,&out.pool,8)||!out.pool||!read(ctx,instance+0x1ba,&out.head,2))return out;
    uint16_t current=out.head,seen[128];unsigned matches=0;unsigned char chosen[72]={0};
    while(current){
        if(current>4096||out.visited>=128||out.pool>UINTPTR_MAX-(uintptr_t)current*72)return out;
        for(unsigned i=0;i<out.visited;i++)if(seen[i]==current)return out;
        seen[out.visited++]=current;unsigned char node[72];uintptr_t address=out.pool+(uintptr_t)current*72;
        if(!read(ctx,address,node,sizeof(node)))return out;
        if(node[2]==0x22&&node[3]==0){++matches;out.node=address;out.index=current;memcpy(chosen,node,sizeof(chosen));}
        memcpy(&current,node,2);
    }
    out.complete=true;
    if(!read(ctx,base+0x10aa650,&poolAfter,8)||poolAfter!=out.pool||!read(ctx,instance+0x1ba,&headAfter,2)||headAfter!=out.head||
        !read(ctx,base+0xc5aa78,&playerAfter,8)||playerAfter!=instance)return out;
    out.stable=true;if(matches!=1)return out;
    unsigned char after[72];if(!read(ctx,out.node,after,sizeof(after))||memcmp(after,chosen,4)||memcmp(after+0x10,chosen+0x10,2)||memcmp(after+0x28,chosen+0x28,12)){out.stable=false;return out;}
    memcpy(out.vector,chosen+0x28,sizeof(out.vector));memcpy(&out.flags,chosen+0x10,2);
    for(unsigned i=0;i<3;i++)if(!isfinite(out.vector[i])||fabsf(out.vector[i])>10000)return out;
    out.valid=true;return out;
}
