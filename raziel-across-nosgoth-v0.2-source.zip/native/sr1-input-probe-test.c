#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <stdint.h>
#include <stdbool.h>
#include <stdio.h>
#include <string.h>
#include "MinHook.h"
#define PROBE_REPORT_DIR L"."
static ULONGLONG testNow=1000;
static ULONGLONG testTick(void){return testNow;}
#define GetTickCount64 testTick
static bool testFlag;
static DWORD testAttributes(LPCWSTR path){return testFlag&&wcsstr(path,L"input-sr1.enable")?FILE_ATTRIBUTE_NORMAL:INVALID_FILE_ATTRIBUTES;}
#define GetFileAttributesW testAttributes
static void logLine(const char *fmt,...){(void)fmt;}
static bool worldRead(uintptr_t p,void *out,size_t n){if(!p)return false;memcpy(out,(void *)p,n);return true;}
static ULONGLONG worldLastDraw;static uintptr_t worldLastInstance;
static bool testActor;static uintptr_t testCaller;static DWORD testForeground;
static bool worldRoot(float *root,uintptr_t *player){memset(root,0,64);root[14]=-4828;*player=testActor?123:0;return testActor;}
static DWORD testWindowPid(HWND window,LPDWORD pid){(void)window;*pid=testForeground;return 1;}
#define GetWindowThreadProcessId testWindowPid
#define __builtin_return_address(n) ((void *)testCaller)
#include "sr1-input-probe.h"
static unsigned calls;static DWORD returnCode;
static XINPUT_STATE expected;
static bool authorityEligible;
static bool mockAuthorityScope(ULONGLONG now,uintptr_t caller,DWORD foreground){return authorityEligible&&now==testNow&&caller==testCaller&&foreground==testForeground;}
static DWORD WINAPI mockInput(DWORD index,XINPUT_STATE *state){
    (void)index;++calls;if(returnCode==ERROR_SUCCESS&&state)*state=expected;return returnCode;
}
static unsigned deviceMask;static int badSlot=-1;
static DWORD WINAPI mockDevices(DWORD index,XINPUT_STATE *state){
 ++calls;if((int)index==badSlot)return ERROR_GEN_FAILURE;
 if(!(deviceMask&(1u<<index)))return ERROR_DEVICE_NOT_CONNECTED;
 *state=expected;return ERROR_SUCCESS;
}
#define CHECK(x) do{if(!(x)){printf("FAIL line %d\n",__LINE__);return 1;}}while(0)
int main(void){
    originalSrInput=mockDevices;XINPUT_STATE chosen={0};
    memset(&expected,0,sizeof(expected));expected.Gamepad.sThumbLY=16000;
    for(unsigned slot=0;slot<XUSER_MAX_COUNT;slot++){
      deviceMask=1u<<slot;CHECK(srPhysicalInput(&chosen)&&chosen.Gamepad.sThumbLY==16000);
      CHECK(srGroundMovementInput()&&srGroundMovingInput());
    }
    deviceMask=0;CHECK(!srPhysicalInput(&chosen));
    deviceMask=3;CHECK(!srGroundMovementInput()&&!srGroundMovingInput());
    deviceMask=2;badSlot=3;CHECK(!srPhysicalInput(&chosen));badSlot=-1;
    expected.Gamepad.sThumbLY=7849;CHECK(srGroundMovementInput()&&!srGroundMovingInput());
    expected.Gamepad.sThumbLY=7850;CHECK(srGroundMovingInput());
    expected.Gamepad.wButtons=XINPUT_GAMEPAD_A;CHECK(!srGroundMovementInput());expected.Gamepad.wButtons=0;
    expected.Gamepad.bLeftTrigger=30;CHECK(!srGroundMovingInput());expected.Gamepad.bLeftTrigger=0;
    expected.Gamepad.bRightTrigger=30;CHECK(!srGroundMovementInput());expected.Gamepad.bRightTrigger=0;
    originalSrInput=NULL;CHECK(!srPhysicalInput(&chosen));calls=0;
    originalSrInput=mockInput;XINPUT_STATE state;
    memset(&expected,0,sizeof(expected));expected.dwPacketNumber=17;
    expected.Gamepad.wButtons=XINPUT_GAMEPAD_Y|XINPUT_GAMEPAD_X;
    expected.Gamepad.sThumbLX=-32768;expected.Gamepad.sThumbRY=32767;
    CHECK(observeSrInput(0,&state)==0&&calls==1&&!memcmp(&state,&expected,sizeof(state))&&srInputHead==0);
    srInputEnabled=1;
    CHECK(observeSrInput(0,&state)==0&&calls==2&&srInputHead==1&&!memcmp(&state,&expected,sizeof(state)));
    CHECK(!memcmp(&srInputQueue[0].state,&expected,sizeof(state))&&srInputRecording(testNow));
    observeSrInput(0,&state);CHECK(calls==3&&srInputHead==1);
    testNow+=16;observeSrInput(0,&state);CHECK(srInputHead==2);
    returnCode=ERROR_DEVICE_NOT_CONNECTED;memset(&state,0xa5,sizeof(state));XINPUT_STATE sentinel=state;
    CHECK(observeSrInput(1,&state)==ERROR_DEVICE_NOT_CONNECTED&&!memcmp(&state,&sentinel,sizeof(state)));
    CHECK(srInputHead==2); // Disconnected extra ports do not exhaust the capture.
    unsigned before=srInputHead;observeSrInput(4,&state);CHECK(srInputHead==before);
    srInputLock=1;observeSrInput(0,&state);srInputLock=0;CHECK(srInputDrops==1);
    testNow+=16;srInputTail=(srInputHead+1)%ARRAYSIZE(srInputQueue);observeSrInput(0,&state);CHECK(srInputDrops==2&&srInputHead==before);
    srInputTail=srInputHead;testNow=181001;observeSrInput(0,&state);CHECK(srInputHead==before&&!srInputRecording(testNow));
    srInputTick();CHECK(!srInputEnabled);
    testFlag=true;srInputTick();CHECK(srInputEnabled&&srInputBegin==0&&srInputRecords==0);
    returnCode=0;observeSrInput(0,&state);CHECK(srInputRecords==1&&srInputRecording(testNow));
    srInputTick();CHECK(srInputRecords==1&&srInputBegin==testNow);
    testFlag=false;srInputTick();CHECK(!srInputEnabled&&!srInputRecording(testNow));
    testFlag=true;srInputLock=1;srInputTick();CHECK(!srInputEnabled);
    srInputLock=0;srInputTick();CHECK(srInputEnabled&&srInputRecords==0);
    srInputStop();CHECK(!srInputEnabled);
    // Combat scope must never suppress LB in menus, other callers/processes,
    // stale draws, wrong actors, clock reversal, expiry, or default-off mode.
    testNow=2000;srInputMainBase=0x10000000;worldLastDraw=1990;worldLastInstance=123;srCombatBegin=1900;
    CHECK(!srCombatScope(testNow,srInputMainBase+0x5bc9,GetCurrentProcessId(),true,123));
    srCombatEnabled=1;CHECK(srCombatScope(testNow,srInputMainBase+0x5bc9,GetCurrentProcessId(),true,123));
    CHECK(srCombatScope(testNow,srInputMainBase+0x5047,GetCurrentProcessId(),true,123));
    WORD raw=0xffff;CHECK(srCombatButtons(raw,raw,true)==(WORD)(raw&~(0x100|0x1000))&&srCombatButtons(raw,raw,false)==raw);
    CHECK(srCombatButtons(XINPUT_GAMEPAD_A,XINPUT_GAMEPAD_A,true)==XINPUT_GAMEPAD_A);
    CHECK(srCombatButtons(XINPUT_GAMEPAD_LEFT_SHOULDER,XINPUT_GAMEPAD_LEFT_SHOULDER,true)==XINPUT_GAMEPAD_RIGHT_SHOULDER);
    CHECK(srCombatButtons(XINPUT_GAMEPAD_B,XINPUT_GAMEPAD_B,true)==XINPUT_GAMEPAD_Y);
    CHECK(srCombatButtons(XINPUT_GAMEPAD_RIGHT_SHOULDER,XINPUT_GAMEPAD_RIGHT_SHOULDER,true)==XINPUT_GAMEPAD_B);
    CHECK(srCombatButtons(XINPUT_GAMEPAD_LEFT_SHOULDER|XINPUT_GAMEPAD_RIGHT_SHOULDER|XINPUT_GAMEPAD_B,XINPUT_GAMEPAD_LEFT_SHOULDER|XINPUT_GAMEPAD_RIGHT_SHOULDER|XINPUT_GAMEPAD_B,true)==(XINPUT_GAMEPAD_RIGHT_SHOULDER|XINPUT_GAMEPAD_B|XINPUT_GAMEPAD_Y));
    // Generated Y lift A is distinct from the hardware LB+A evasion chord.
    CHECK(srCombatButtons(XINPUT_GAMEPAD_A|XINPUT_GAMEPAD_LEFT_SHOULDER,XINPUT_GAMEPAD_Y|XINPUT_GAMEPAD_LEFT_SHOULDER,true)==(XINPUT_GAMEPAD_A|XINPUT_GAMEPAD_RIGHT_SHOULDER));
    CHECK(!srCombatScope(testNow,srInputMainBase+0x1234,GetCurrentProcessId(),true,123));
    CHECK(!srCombatScope(testNow,srInputMainBase+0x5bc9,0,true,123));
    CHECK(!srCombatScope(testNow,srInputMainBase+0x5bc9,GetCurrentProcessId(),false,123));
    CHECK(!srCombatScope(testNow,srInputMainBase+0x5bc9,GetCurrentProcessId(),true,124));
    CHECK(!srCombatScope(2240,srInputMainBase+0x5bc9,GetCurrentProcessId(),true,123));
    CHECK(!srCombatScope(1800,srInputMainBase+0x5bc9,GetCurrentProcessId(),true,123));
    worldLastDraw=srCombatBegin+(uint64_t)sheet_diagnosticLimits_controls.durationMs-1;
    CHECK(srCombatScope(worldLastDraw,srInputMainBase+0x5bc9,GetCurrentProcessId(),true,123));
    worldLastDraw++;CHECK(!srCombatScope(worldLastDraw,srInputMainBase+0x5bc9,GetCurrentProcessId(),true,123));
    testNow=2100;worldLastDraw=2090;srCombatBegin=2000;testActor=true;testCaller=srInputMainBase+0x5bc9;testForeground=GetCurrentProcessId();
    expected.Gamepad.wButtons=XINPUT_GAMEPAD_LEFT_SHOULDER|XINPUT_GAMEPAD_A|XINPUT_GAMEPAD_X;
    expected.Gamepad.bLeftTrigger=41;expected.Gamepad.bRightTrigger=99;XINPUT_STATE originalExpected=expected;
    returnCode=0;unsigned callBefore=calls;CHECK(observeSrInput(0,&state)==0&&calls==callBefore+1);
    CHECK(state.Gamepad.wButtons==(XINPUT_GAMEPAD_X|XINPUT_GAMEPAD_RIGHT_SHOULDER)&&state.Gamepad.bLeftTrigger==41&&state.Gamepad.bRightTrigger==99&&state.dwPacketNumber==expected.dwPacketNumber&&state.Gamepad.sThumbLX==expected.Gamepad.sThumbLX);
    CHECK(!memcmp(&expected,&originalExpected,sizeof(expected))); // raw donor input source unchanged
    // Releasing LB restores A immediately; there is no delayed suppression.
    expected.Gamepad.wButtons=XINPUT_GAMEPAD_A|XINPUT_GAMEPAD_X;observeSrInput(0,&state);CHECK(!memcmp(&state,&expected,sizeof(state)));
    expected=originalExpected;observeSrInput(0,&state);CHECK(state.Gamepad.wButtons==(XINPUT_GAMEPAD_X|XINPUT_GAMEPAD_RIGHT_SHOULDER));
    // Feed and TK destinations are based on hardware, not remapped bits.
    expected.Gamepad.wButtons=XINPUT_GAMEPAD_RIGHT_SHOULDER|XINPUT_GAMEPAD_B;observeSrInput(0,&state);CHECK(state.Gamepad.wButtons==(XINPUT_GAMEPAD_B|XINPUT_GAMEPAD_Y));
    expected=originalExpected;
    testCaller=srInputMainBase+0x1234;observeSrInput(0,&state);CHECK(!memcmp(&state,&expected,sizeof(state)));
    testCaller=srInputMainBase+0x5047;testActor=false;observeSrInput(0,&state);CHECK(!memcmp(&state,&expected,sizeof(state)));
    testActor=true;returnCode=ERROR_DEVICE_NOT_CONNECTED;memset(&state,0xa5,sizeof(state));sentinel=state;observeSrInput(0,&state);CHECK(!memcmp(&state,&sentinel,sizeof(state)));
    returnCode=ERROR_SUCCESS;srAuthorityInputScope=mockAuthorityScope;authorityEligible=true;expected=originalExpected;expected.Gamepad.wButtons|=XINPUT_GAMEPAD_START;
    XINPUT_STATE physical=expected;observeSrInput(0,&state);CHECK(state.Gamepad.wButtons==XINPUT_GAMEPAD_START&&state.Gamepad.sThumbLX==0&&state.Gamepad.sThumbLY==0&&state.Gamepad.sThumbRX==0&&state.Gamepad.sThumbRY==0&&state.Gamepad.bLeftTrigger==0&&state.Gamepad.bRightTrigger==0&&state.dwPacketNumber==expected.dwPacketNumber);CHECK(!memcmp(&physical,&expected,sizeof(expected)));
    authorityEligible=false;testCaller=srInputMainBase+0x1234;observeSrInput(0,&state);CHECK(!memcmp(&state,&expected,sizeof(state)));srAuthorityInputScope=NULL;
    srInputStop();CHECK(!srCombatEnabled);
    // Exercise missing-module install path without loading any XInput library.
    srInputInstall();
    puts("SR1 input observer: original forwarding/error, scoped B/RB/LB action mapping without chord cascades, LB+A jump suppression, standalone A restored on LB release, generated Y pulse preserved, unchanged donor/raw/other controls, menu/caller/actor/focus/expiry fallback, recording bounds PASS");return 0;
}
