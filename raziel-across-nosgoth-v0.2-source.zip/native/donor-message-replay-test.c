// SPDX-License-Identifier: GPL-3.0-or-later
// Immutable played SCALAR metadata replay only. Does not access any game.
#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <stdint.h>
#include <stdbool.h>
#include <stddef.h>
#include <stdio.h>
#include <string.h>
#include <io.h>
#include <fcntl.h>
#include "donor-message-collector.h"
#define FIELD_AT(field,at) _Static_assert(offsetof(DonorMessageEvent,field)==at,"Scalar wire offset " #field)
FIELD_AT(session,0);FIELD_AT(callId,8);FIELD_AT(tickMs,16);FIELD_AT(threadId,24);FIELD_AT(depth,28);FIELD_AT(phase,32);FIELD_AT(section,36);FIELD_AT(messageId,40);FIELD_AT(payloadZero,44);FIELD_AT(afterValid,48);FIELD_AT(beforeFirstRva,52);FIELD_AT(beforeSecondRva,64);FIELD_AT(beforeSecondMask,76);FIELD_AT(afterFirstRva,80);FIELD_AT(afterSecondRva,92);FIELD_AT(afterSecondMask,104);
_Static_assert(sizeof(DonorMessageEvent)==112,"Full scalar replay ABI");
typedef struct {
 uint64_t count,changed,nestedEnter,nestedExit,minTick,maxTick;
 uint64_t changedIds[128],nestedEnterIds[128],nestedExitIds[128];
 bool overflow;
} ReplayStats;
static DonorMessageCollector collector;
static ReplayStats input,retained;
static bool changed(const DonorMessageEvent *e){return e->phase==DONOR_MESSAGE_EXIT&&(!donorMessageSampleStateEqual(e->beforeFirstRva,e->beforeSecondRva,e->beforeSecondMask,e->afterFirstRva,e->afterSecondRva,e->afterSecondMask));}
static void count(ReplayStats *s,const DonorMessageEvent *e){
 if(!s->count||e->tickMs<s->minTick)s->minTick=e->tickMs;if(!s->count||e->tickMs>s->maxTick)s->maxTick=e->tickMs;s->count++;
 if(changed(e)){if(s->changed<ARRAYSIZE(s->changedIds))s->changedIds[s->changed]=e->callId;else s->overflow=true;s->changed++;}
 if(e->depth>1&&e->phase==DONOR_MESSAGE_ENTER){if(s->nestedEnter<ARRAYSIZE(s->nestedEnterIds))s->nestedEnterIds[s->nestedEnter]=e->callId;else s->overflow=true;s->nestedEnter++;}
 if(e->depth>1&&e->phase==DONOR_MESSAGE_EXIT){if(s->nestedExit<ARRAYSIZE(s->nestedExitIds))s->nestedExitIds[s->nestedExit]=e->callId;else s->overflow=true;s->nestedExit++;}
}
static void emit(void *context,const DonorMessageEvent *e){count(context,e);}
static void ids(const char *name,const uint64_t *values,uint64_t n){printf(",\"%s\":[",name);for(uint64_t i=0;i<n;i++)printf("%s%llu",i?",":"",(unsigned long long)values[i]);putchar(']');}
int main(void){
 if(_setmode(_fileno(stdin),_O_BINARY)==-1)return 2;
 donorMessageCollectorInit(&collector,&retained,emit);if(!collector.configured)return 3;
 for(;;){DonorMessageEvent e={0};size_t n=fread(&e,1,sizeof(e),stdin);if(!n){if(ferror(stdin))return 4;break;}if(n!=sizeof(e)||input.count>=(uint64_t)sheet_donorMessageObservationPolicy_bounded.rawMaxRecords)return 5;count(&input,&e);donorMessageCollectorAccept(&collector,&e);}
 donorMessageCollectorFinish(&collector);
 bool conserved=collector.seen==collector.logged+collector.sampled+collector.discarded&&collector.seen==input.count&&collector.logged==retained.count;
 if(input.overflow||retained.overflow)return 6;
 printf("{\"seen\":%llu,\"wire\":%llu,\"sampled\":%llu,\"discarded\":%llu,\"pending\":%u,\"orphans\":%llu,\"conserved\":%s,\"inputStateChangingExits\":%llu,\"retainedStateChangingExits\":%llu,\"inputNestedEntries\":%llu,\"retainedNestedEntries\":%llu,\"inputNestedExits\":%llu,\"retainedNestedExits\":%llu,\"inputFirstTick\":%llu,\"inputLastTick\":%llu,\"inputSpanMs\":%llu,\"retainedFirstTick\":%llu,\"retainedLastTick\":%llu,\"algorithmReplayOnly\":true,\"newGameplayEvidence\":false",
 (unsigned long long)collector.seen,(unsigned long long)collector.logged,(unsigned long long)collector.sampled,(unsigned long long)collector.discarded,collector.pendingCount,(unsigned long long)collector.orphanEntries,conserved?"true":"false",(unsigned long long)input.changed,(unsigned long long)retained.changed,(unsigned long long)input.nestedEnter,(unsigned long long)retained.nestedEnter,(unsigned long long)input.nestedExit,(unsigned long long)retained.nestedExit,(unsigned long long)input.minTick,(unsigned long long)input.maxTick,(unsigned long long)(input.maxTick-input.minTick),(unsigned long long)retained.minTick,(unsigned long long)retained.maxTick);
 ids("inputChangedCallIds",input.changedIds,input.changed);ids("retainedChangedCallIds",retained.changedIds,retained.changed);ids("inputNestedEntryCallIds",input.nestedEnterIds,input.nestedEnter);ids("retainedNestedEntryCallIds",retained.nestedEnterIds,retained.nestedEnter);ids("inputNestedExitCallIds",input.nestedExitIds,input.nestedExit);ids("retainedNestedExitCallIds",retained.nestedExitIds,retained.nestedExit);puts("}");
 return conserved&&!collector.discarded&&!collector.orphanEntries?0:7;
}
