// SPDX-License-Identifier: GPL-3.0-or-later
#define SR1_NATIVE_JUMP_POSE 1
#define SR1_AIR_COMBAT_POSE 1
#include <assert.h>
#include <stdio.h>
#include "sr1-retarget-gate.h"
#include "sr1-free-attack-owner.h"
int main(void){
 Sr1RetargetContext c={.identity=true,.foreground=true,.verticalVelocityKnown=true,.verticalVelocity=100,.callbacks={0xf2ae0,0xf2ae0,0xef480}};
 assert(sr1RetargetJumpContextAllowed(&c));
 c.callbacks[0]=c.callbacks[1]=0xef480;assert(sr1RetargetJumpContextAllowed(&c));
 const uint32_t native[]={0xefb50,0xf4490,0xee600,0xeb990};
 for(unsigned i=0;i<sizeof(native)/sizeof(*native);i++){c.callbacks[0]=native[i];assert(!sr1RetargetJumpContextAllowed(&c));}c.callbacks[0]=0xef480;
 c.crouchHeld=true;assert(!sr1RetargetJumpContextAllowed(&c));c.crouchHeld=false;
 c.foreground=false;assert(!sr1RetargetJumpContextAllowed(&c));c.foreground=true;
 c.mode=12;assert(!sr1RetargetJumpContextAllowed(&c));c.mode=0;
 for(unsigned i=0;i<3;i++)c.callbacks[i]=0xedb40;
 assert(!sr1RetargetJumpContextAllowed(&c));c.ordinaryAirTransition=true;assert(sr1RetargetJumpContextAllowed(&c));
 for(unsigned i=0;i<3;i++)c.callbacks[i]=0xee600;
 assert(sr1RetargetJumpContextAllowed(&c));c.crouchHeld=true;assert(!sr1RetargetJumpContextAllowed(&c));c.crouchHeld=false;
 assert(sr1OrdinaryAirClip(0xedb40,0x22)&&sr1OrdinaryAirClip(0xedb40,0x1a));
 assert(sr1OrdinaryAirClip(0xee600,0x25)&&sr1OrdinaryAirClip(0xee600,0x1d));
 assert(!sr1OrdinaryAirClip(0xee600,0x29)&&!sr1OrdinaryAirClip(0xedb40,0x29));
 for(unsigned mask=1;mask<7;mask++){
  for(unsigned i=0;i<3;i++)c.callbacks[i]=(mask&(1u<<i))?0xee600:0xf2180;
  assert(sr1RetargetJumpContextAllowed(&c));
  for(unsigned i=0;i<3;i++){uint32_t save=c.callbacks[i];c.callbacks[i]=0xefb50;assert(!sr1RetargetJumpContextAllowed(&c));c.callbacks[i]=save;}
 }
 for(unsigned i=0;i<3;i++)c.callbacks[i]=0xf2180;assert(!sr1RetargetJumpContextAllowed(&c));
 SrFreeAttackOwner o={0};srFreeAttackStep(&o,1000,1,true,true,0,0,0x4000);
 assert(srFreeAttackStep(&o,1016,1,true,true,0x5000,0x5000,0x4000)==0x1000);
 assert(srFreeAttackStep(&o,1032,1,true,true,0x4000,0x4000,0x4000)==0);
 srFreeAttackStep(&o,1048,1,true,false,0,0,0x4000);
 assert(srFreeAttackStep(&o,1064,1,true,false,0x5000,0x5000,0x4000)==0x5000);
 puts("PASS Jump/Fall and mixed air sections; glide/crouch/landing/native rejection; X consumed while A preserved; not gameplay");return 0;
}
