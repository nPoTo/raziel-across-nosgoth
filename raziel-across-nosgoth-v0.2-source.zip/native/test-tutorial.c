// Passive overlay: no focus, mouse interception, keyboard/controller injection.
#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <stdint.h>
#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <wchar.h>
#include "recording-status.h"
#include "test-tutorial-plan.h"
static DWORD tutorialPid;static HWND gameWindow;static RECT bestRect;
static RecordingStatus status;static HFONT titleFont,detailFont;static unsigned elapsed;
static bool nativeRecordingDot;
static bool groundPlan;
static bool cameraPlan;
static bool visibilityPlan;
static bool walkJumpPlan;
static bool lifetimePlan;
static bool interactionPlan;
static bool glidePlan;
static bool roomPlan;
static unsigned tutorialSeconds(void){return roomPlan?tutorialRoomSeconds():interactionPlan?tutorialInteractionSeconds():lifetimePlan?tutorialLifetimeSeconds():walkJumpPlan?tutorialWalkJumpSeconds():TUTORIAL_SECONDS;}
static BOOL CALLBACK findWindow(HWND hwnd,LPARAM unused){
 (void)unused;DWORD pid=0;GetWindowThreadProcessId(hwnd,&pid);RECT r;
 if(pid!=tutorialPid||!IsWindowVisible(hwnd)||GetWindow(hwnd,GW_OWNER)||!GetClientRect(hwnd,&r)||r.right<512||r.bottom<384)return TRUE;
 if((int64_t)r.right*r.bottom>(int64_t)bestRect.right*bestRect.bottom){gameWindow=hwnd;bestRect=r;}return TRUE;
}
static void drawTextShadow(HDC dc,const wchar_t *text,RECT r,HFONT font){
 HGDIOBJ old=SelectObject(dc,font);SetBkMode(dc,TRANSPARENT);RECT shadow=r;OffsetRect(&shadow,2,2);SetTextColor(dc,RGB(1,1,1));DrawTextW(dc,text,-1,&shadow,DT_CENTER|DT_SINGLELINE|DT_VCENTER);SetTextColor(dc,RGB(255,255,255));DrawTextW(dc,text,-1,&r,DT_CENTER|DT_SINGLELINE|DT_VCENTER);SelectObject(dc,old);
}
static void tutorialPaint(HDC dc,int width,int height,unsigned seconds){
 RECT all={0,0,width,height};FillRect(dc,&all,(HBRUSH)GetStockObject(BLACK_BRUSH));
 const TutorialStage *stage=roomPlan?tutorialRoomStageAt(seconds):glidePlan?tutorialGlideStageAt(seconds):interactionPlan?tutorialInteractionStageAt(seconds):lifetimePlan?tutorialLifetimeStageAt(seconds):walkJumpPlan?tutorialWalkJumpStageAt(seconds):visibilityPlan?tutorialVisibilityStageAt(seconds):cameraPlan?tutorialCameraStageAt(seconds):groundPlan?tutorialGroundStageAt(seconds):tutorialStageAt(seconds);if(!stage)return;
 if(!nativeRecordingDot){HBRUSH red=CreateSolidBrush(RGB(245,40,45));HGDIOBJ old=SelectObject(dc,red),pen=SelectObject(dc,GetStockObject(NULL_PEN));Ellipse(dc,width-35,18,width-21,32);SelectObject(dc,pen);SelectObject(dc,old);DeleteObject(red);}
 wchar_t counter[96];_snwprintf(counter,96,L"REC   %us",tutorialSeconds()-seconds);RECT rec={width-160,12,width-45,39};drawTextShadow(dc,counter,rec,detailFont);
 RECT title={40,50,width-40,92},detail={40,98,width-40,129},time={40,137,width-40,164};drawTextShadow(dc,stage->title,title,titleFont);drawTextShadow(dc,stage->detail,detail,detailFont);
 _snwprintf(counter,96,roomPlan?L"Остават %u секунди":L"%u seconds remaining",stage->end-seconds);drawTextShadow(dc,counter,time,detailFont);
}
static LRESULT CALLBACK tutorialProc(HWND hwnd,UINT message,WPARAM wParam,LPARAM lParam){
 if(message==WM_NCHITTEST)return HTTRANSPARENT;if(message==WM_MOUSEACTIVATE)return MA_NOACTIVATE;
 if(message==WM_PAINT){PAINTSTRUCT ps;HDC dc=BeginPaint(hwnd,&ps);RECT r;GetClientRect(hwnd,&r);tutorialPaint(dc,r.right,r.bottom,elapsed);EndPaint(hwnd,&ps);return 0;}
 if(message==WM_ERASEBKGND)return 1;if(message==WM_DESTROY){PostQuitMessage(0);return 0;}return DefWindowProcW(hwnd,message,wParam,lParam);
}
static bool preview(const wchar_t *path){
 int width=1280,height=720;BITMAPINFO info={0};info.bmiHeader.biSize=sizeof(BITMAPINFOHEADER);info.bmiHeader.biWidth=width;info.bmiHeader.biHeight=-height;info.bmiHeader.biPlanes=1;info.bmiHeader.biBitCount=32;info.bmiHeader.biCompression=BI_RGB;
 void *pixels=NULL;HDC dc=CreateCompatibleDC(NULL);HBITMAP bmp=CreateDIBSection(dc,&info,DIB_RGB_COLORS,&pixels,NULL,0);if(!dc||!bmp)return false;HGDIOBJ old=SelectObject(dc,bmp);tutorialPaint(dc,width,height,21);
 BITMAPFILEHEADER header={0};header.bfType=0x4d42;header.bfOffBits=sizeof(header)+sizeof(info.bmiHeader);header.bfSize=header.bfOffBits+width*height*4;FILE *out=_wfopen(path,L"wb");bool ok=out&&fwrite(&header,sizeof(header),1,out)==1&&fwrite(&info.bmiHeader,sizeof(info.bmiHeader),1,out)==1&&fwrite(pixels,width*height*4,1,out)==1;if(out)fclose(out);SelectObject(dc,old);DeleteObject(bmp);DeleteDC(dc);return ok;
}
int wmain(int argc,wchar_t **argv){
 titleFont=CreateFontW(32,0,0,0,FW_BOLD,FALSE,FALSE,FALSE,DEFAULT_CHARSET,OUT_DEFAULT_PRECIS,CLIP_DEFAULT_PRECIS,ANTIALIASED_QUALITY,DEFAULT_PITCH,L"Segoe UI");detailFont=CreateFontW(20,0,0,0,FW_SEMIBOLD,FALSE,FALSE,FALSE,DEFAULT_CHARSET,OUT_DEFAULT_PRECIS,CLIP_DEFAULT_PRECIS,ANTIALIASED_QUALITY,DEFAULT_PITCH,L"Segoe UI");
 if(argc==3&&(!wcscmp(argv[1],L"--preview")||!wcscmp(argv[1],L"--preview-walk-jump")||!wcscmp(argv[1],L"--preview-interaction")||!wcscmp(argv[1],L"--preview-glide")||!wcscmp(argv[1],L"--preview-room"))){walkJumpPlan=!wcscmp(argv[1],L"--preview-walk-jump");roomPlan=!wcscmp(argv[1],L"--preview-room");glidePlan=!wcscmp(argv[1],L"--preview-glide");interactionPlan=roomPlan||glidePlan||!wcscmp(argv[1],L"--preview-interaction");bool ok=preview(argv[2]);DeleteObject(titleFont);DeleteObject(detailFont);return ok?0:1;}
 if(argc!=2&&argc!=3)return 2;if(argc==3){if(!wcscmp(argv[2],L"--room")){roomPlan=true;interactionPlan=true;}else if(!wcscmp(argv[2],L"--glide")){glidePlan=true;interactionPlan=true;}else if(!wcscmp(argv[2],L"--interaction"))interactionPlan=true;else if(!wcscmp(argv[2],L"--lifetime")){lifetimePlan=true;walkJumpPlan=true;}else if(!wcscmp(argv[2],L"--walk-jump"))walkJumpPlan=true;else if(!wcscmp(argv[2],L"--ground"))groundPlan=true;else if(!wcscmp(argv[2],L"--camera"))cameraPlan=true;else if(!wcscmp(argv[2],L"--visibility"))visibilityPlan=true;else return 2;}wchar_t *end;tutorialPid=wcstoul(argv[1],&end,10);if(!tutorialPid||*end)return 2;
 HANDLE game=OpenProcess(PROCESS_QUERY_LIMITED_INFORMATION|SYNCHRONIZE,FALSE,tutorialPid);if(!game)return 3;
 wchar_t executable[32768];DWORD length=ARRAYSIZE(executable);if(!QueryFullProcessImageNameW(game,0,executable,&length)||!wcsrchr(executable,L'\\')||(_wcsicmp(wcsrchr(executable,L'\\')+1,L"defiance.exe")&&_wcsicmp(wcsrchr(executable,L'\\')+1,L"SRX.exe"))){CloseHandle(game);return 4;}
 nativeRecordingDot=!interactionPlan&&wcsstr(executable,L"SRX.exe")!=NULL;
 SetProcessDPIAware();WNDCLASSW wc={0};wc.lpfnWndProc=tutorialProc;wc.hInstance=GetModuleHandleW(NULL);wc.lpszClassName=L"LOKTestTutorial";if(!RegisterClassW(&wc))return 5;
 HWND hwnd=CreateWindowExW(WS_EX_LAYERED|WS_EX_TRANSPARENT|WS_EX_TOPMOST|WS_EX_TOOLWINDOW|WS_EX_NOACTIVATE,wc.lpszClassName,L"LOK recording tutorial",WS_POPUP,0,0,1280,720,NULL,NULL,wc.hInstance,NULL);if(!hwnd)return 5;SetLayeredWindowAttributes(hwnd,RGB(0,0,0),255,LWA_COLORKEY);
 uint64_t started=GetTickCount64(),lastValid=0;bool seen=false;
 while(GetTickCount64()-started<tutorialWallBudgetMs(tutorialSeconds())&&WaitForSingleObject(game,0)!=WAIT_OBJECT_0){
  MSG message;while(PeekMessageW(&message,NULL,0,0,PM_REMOVE)){TranslateMessage(&message);DispatchMessageW(&message);}
  bool recording=recordingReadStatus(tutorialPid,&status)&&recordingStatusValid(&status,tutorialPid,GetTickCount64());
  if(recording){seen=true;lastValid=GetTickCount64();elapsed=(unsigned)((uint64_t)status.completed*tutorialSeconds()/status.total);if(elapsed>=tutorialSeconds())elapsed=tutorialSeconds()-1;}
  else if(seen&&GetTickCount64()-lastValid>=1500)break;
  DWORD foreground=0;GetWindowThreadProcessId(GetForegroundWindow(),&foreground);gameWindow=NULL;bestRect=(RECT){0};EnumWindows(findWindow,0);
  if(recording&&foreground==tutorialPid&&gameWindow&&!IsIconic(gameWindow)){POINT top={0,0};ClientToScreen(gameWindow,&top);SetWindowPos(hwnd,HWND_TOPMOST,top.x,top.y,bestRect.right,bestRect.bottom,SWP_NOACTIVATE|SWP_SHOWWINDOW);InvalidateRect(hwnd,NULL,FALSE);UpdateWindow(hwnd);}
  else ShowWindow(hwnd,SW_HIDE);
  Sleep(100);
 }
 DestroyWindow(hwnd);DeleteObject(titleFont);DeleteObject(detailFont);CloseHandle(game);return 0;
}

