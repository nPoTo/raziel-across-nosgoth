#include "report-path.h"
// SPDX-License-Identifier: GPL-3.0-or-later
// Explicit SR1 replacement preview: remove only the verified Reaver point-light
// color during one host draw, then restore it. The geometry is always forwarded.
static PFNGLUNIFORM4FVPROC lightUniform4fv;
static bool lightReplaceRequested,lightReplaceFailed;
static unsigned int lightReplaced;
static volatile LONG64 lightGateCounts[8];
static ULONGLONG lightGateLogged;
static void lightReplaceLog(void) {
    if(GetFileAttributesW(PROBE_PATH(L"\\hide-reaver-light-sr1.enable"))==INVALID_FILE_ATTRIBUTES)return;
    ULONGLONG now=GetTickCount64();if(now-lightGateLogged<2000)return;lightGateLogged=now;
    LONG64 counts[8];for(int i=0;i<8;++i)counts[i]=InterlockedCompareExchange64(&lightGateCounts[i],0,0);
    logLine("REAVER_LIGHT_GATE requested=%d failed=%d fields=%u stages=%lld,%lld,%lld,%lld,%lld,%lld,%lld,%lld",lightReplaceRequested,lightReplaceFailed,lightFieldCount,counts[0],counts[1],counts[2],counts[3],counts[4],counts[5],counts[6],counts[7]);
}
typedef struct {GLuint program;LONG64 frame;bool allowed;} LightShaderProof;
static LightShaderProof lightProofs[64];
static unsigned int lightProofCount;
static bool lightShaderHashesAllowed(const char *vertex,const char *fragment) {
    return !strcmp(vertex,"2e9d8aca544f52c43f0577a1e694b9ee99e4d9c71ec95e90c6538b049f0e6de6")&&
        (!strcmp(fragment,"c5409ef638c1b75b951e2d5117a52b53fb59aceea26310acf202dfbf09daf33b")||
         !strcmp(fragment,"f169337c2bfffbd23b9c18102175bd50efa5adb24f7733c4bfcdb73eedfe0715")||
         !strcmp(fragment,"edc9f50076f29e9ccc7a586517515c8222ed7ed02321a62942680af3a355f333"));
}
static bool lightShaderAllowed(GLuint program) {
    LightShaderProof *proof=NULL;LONG64 frame=InterlockedCompareExchange64(&swapCalls,0,0);
    for(unsigned int i=0;i<lightProofCount;++i)if(lightProofs[i].program==program)proof=&lightProofs[i];
    if(!proof){if(lightProofCount==ARRAYSIZE(lightProofs))return false;proof=&lightProofs[lightProofCount++];proof->program=program;proof->frame=-1;}
    if(proof->frame==frame)return proof->allowed;
    proof->frame=frame;proof->allowed=false;
    GLint linked=0,attached=0;pglGetProgramiv(program,GL_LINK_STATUS,&linked);pglGetProgramiv(program,GL_ATTACHED_SHADERS,&attached);
    if(!linked||attached!=2)return false;
    GLuint shaders[2]={0};GLsizei count=0;shaderAttached(program,2,&count,shaders);if(count!=2)return false;
    char vertex[65]={0},fragment[65]={0};bool valid=true;
    for(int i=0;i<2;++i){ShaderRecord r={0};if(!shaderRead(program,shaders[i],&r)){valid=false;break;}
        char *target=r.type==GL_VERTEX_SHADER?vertex:r.type==GL_FRAGMENT_SHADER?fragment:NULL;
        if(!target||target[0]||!hashBytes(r.source,(ULONG)r.length,target))valid=false;
        HeapFree(GetProcessHeap(),0,r.source);if(!valid)break;
    }
    proof->allowed=valid&&lightShaderHashesAllowed(vertex,fragment);return proof->allowed;
}
static bool lightAttachmentMatches(const float position[16],const float color[16],const float joints[8],uint32_t packed) {
    if(!packed||!isfinite(position[3])||fabsf(position[3]-512)>0.01f||!isfinite(color[3])||fabsf(color[3])>1e-6f)return false;
    for(int i=0;i<3;++i){float expected=(float)((packed>>(i*8))&255)*4.0f/255.0f;
        if(!isfinite(position[i])||!isfinite(joints[4+i])||fabsf(position[i]-joints[4+i])>0.1f||!isfinite(color[i])||fabsf(color[i]-expected)>1e-5f)return false;
    }
    return true;
}
static bool lightRecentReaver(const ReaverEvent *event,uintptr_t player,ULONGLONG now) {
    return event->valid&&event->tick&&now>=event->tick&&now-event->tick<250&&event->player==player&&player&&
        event->instance&&event->instance!=player&&event->object&&event->extraData&&!memcmp(event->name,"sreavr__",8);
}
static bool lightReaverColor(uintptr_t player,ULONGLONG now,uint32_t *packed) {
    ReaverEvent event={0};
    if(InterlockedCompareExchange(&reaverLock,1,0))return false;
    event=latestReaver;InterlockedExchange(&reaverLock,0);
    if(!lightRecentReaver(&event,player,now))return false;
    uintptr_t base=(uintptr_t)InterlockedCompareExchangePointer(&verifiedSr1Module,NULL,NULL),global=0,object=0,extra=0,name=0,after=0,currentPlayer=0;unsigned char data[32];char objectName[9]={0};
    // The render registration is transient; zero between callbacks is normal.
    // A nonzero registration for a different object must always reject the match.
    if(!base||!worldRead(base+0x2bcd18,&global,8)||(global&&global!=event.instance)||
       !worldRead(event.instance+0x30,&object,8)||object!=event.object||!worldRead(event.instance+0x2c0,&extra,8)||extra!=event.extraData||
       !worldRead(object+0x30,&name,8)||!worldRead(name,objectName,8)||memcmp(objectName,"sreavr__",8)||!worldRead(extra,data,sizeof(data))||
       !worldRead(event.instance+0x30,&after,8)||after!=object||!worldRead(event.instance+0x2c0,&after,8)||after!=extra||
       !worldRead(base+0x2bcd18,&after,8)||(after&&after!=event.instance)||!worldRead(base+0x2a89310,&currentPlayer,8)||currentPlayer!=player)return false;
    memcpy(packed,data+24,4);return true;
}
static void lightReplaceArm(HGLRC context) {
    lightReplaceRequested=!lightReplaceFailed&&context==cameraContext&&
#ifdef SR1_NATIVE_SKELETON_ADAPTER
        sr1SkeletonCurrentVisibility()&&
#elif defined(SR1_RETARGET_PREVIEW)
        context==overlayContext&&sr1RetargetWeaponScope(overlayHostActor)&&
#else
        drawReplacementRequested&&
#endif
        GetFileAttributesW(PROBE_PATH(L"\\hide-reaver-light-sr1.enable"))!=INVALID_FILE_ATTRIBUTES;
    if(!lightReplaceRequested)return;
    shaderInit();
    if(!lightUniform4fv){PROC fn=wglGetProcAddress("glUniform4fv");if(fn&&(uintptr_t)fn>3&&(uintptr_t)fn!=UINTPTR_MAX)lightUniform4fv=(PFNGLUNIFORM4FVPROC)fn;}
    if(!shaderReady||!lightUniform4fv)lightReplaceRequested=false;
    // Metadata is read on this GL context. Refresh when starting or changing the
    // camera's discovered programs; actual type/count/location is rechecked below.
    if(!lightFieldCount)lightDiscover();
}
static bool lightUniformDraw(GLuint program,GLint location,const float saved[4],GLenum mode,GLsizei count,GLenum type,const void *indices) {
    const float zero[4]={0};float check[4]={NAN,NAN,NAN,NAN};
    lightUniform4fv(location,1,zero);cglGetUniformfv(program,location,check);
    if(memcmp(check,zero,sizeof(check))){
        lightUniform4fv(location,1,saved);for(int i=0;i<4;++i)check[i]=NAN;cglGetUniformfv(program,location,check);
        if(memcmp(check,saved,sizeof(check)))lightReplaceFailed=true;
        return false;
    }
    originalDraw(mode,count,type,indices);
    // glDrawElements itself preserves the bound program and uniform values.
    lightUniform4fv(location,1,saved);for(int i=0;i<4;++i)check[i]=NAN;cglGetUniformfv(program,location,check);
    if(memcmp(check,saved,sizeof(check)))lightReplaceFailed=true;
    ++lightReplaced;
    if(lightReplaced==1||lightReplaced%1200==0||lightReplaceFailed)logLine("REAVER_LIGHT draws=%u program=%u uniform_restored=%d; geometry forwarded",lightReplaced,program,!lightReplaceFailed);
    return true;
}
static bool lightDrawReplace(GLenum mode,GLsizei count,GLenum type,const void *indices) {
    if(!lightReplaceRequested||lightReplaceFailed||!cameraReady||!shaderReady||!lightUniform4fv||mode!=GL_TRIANGLES||type!=GL_UNSIGNED_INT||count<=0||count>6000000||wglGetCurrentContext()!=cameraContext)return false;
    InterlockedIncrement64(&lightGateCounts[0]);
    ULONGLONG now=GetTickCount64();
#ifdef SR1_NATIVE_SKELETON_ADAPTER
    {uintptr_t player=0,base=(uintptr_t)InterlockedCompareExchangePointer(&verifiedSr1Module,NULL,NULL);if(!base||!worldRead(base+0x2a89310,&player,8)||!sr1SkeletonVisibilityScope(player))return false;}
#elif defined(SR1_RETARGET_PREVIEW)
    if(!sr1RetargetWeaponScope(overlayHostActor))return false;
#else
    if(!worldLastDraw||now<worldLastDraw||now-worldLastDraw>=250)return false;
#endif
    GLint program=0,fbo=0;glGetIntegerv(GL_CURRENT_PROGRAM,&program);glGetIntegerv(GL_DRAW_FRAMEBUFFER_BINDING,&fbo);
    if(program<=0||program==(GLint)overlayProgram||fbo||!cglIsProgram((GLuint)program))return false;
    InterlockedIncrement64(&lightGateCounts[1]);
    const LightField *positionField=NULL,*colorField=NULL;
    for(unsigned int i=0;i<lightFieldCount;++i){const LightField *f=&lightFields[i];if(f->program!=(GLuint)program||f->block>=0||f->count!=1)continue;
        if(!strcmp(f->kind,"position"))positionField=f;if(!strcmp(f->kind,"color"))colorField=f;
    }
    if(!positionField||!colorField)return false;InterlockedIncrement64(&lightGateCounts[2]);
    if(!lightShaderAllowed((GLuint)program))return false;InterlockedIncrement64(&lightGateCounts[3]);
    float joints[8],position[16],color[16];uintptr_t player=0;
    if(!reaverPlayerIdentity(&player)||
#ifdef SR1_NATIVE_SKELETON_ADAPTER
       !sr1SkeletonVisibilityScope(player)||
#elif defined(SR1_RETARGET_PREVIEW)
       !sr1RetargetWeaponScope(player)||
#else
       player!=worldLastInstance||
#endif
       !lightPlayerJoints(player,joints)||!lightRead(positionField,position)||!lightRead(colorField,color))return false;
    InterlockedIncrement64(&lightGateCounts[4]);
    uint32_t packed=0;
    if(!lightReaverColor(player,now,&packed))return false;InterlockedIncrement64(&lightGateCounts[5]);
    if(!lightAttachmentMatches(position,color,joints,packed))return false;InterlockedIncrement64(&lightGateCounts[6]);
    GLint location=pglGetUniformLocation((GLuint)program,colorField->name);if(location<0)return false;
    InterlockedIncrement64(&lightGateCounts[7]);
    return lightUniformDraw((GLuint)program,location,color,mode,count,type,indices);
}
