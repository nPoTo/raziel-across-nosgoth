// SPDX-License-Identifier: GPL-3.0-or-later
// Build-local diagnostic callback on the already-proved successful anchor boundary.
#include "combat-local-step.h"
typedef struct {uint64_t tick;uint32_t primary[3],secondary[3];float dx,dy,factor;double side,forward;bool valid;} CombatAnchorEvent;
static CombatAnchorEvent combatAnchorEvents[4096];static unsigned combatAnchorHead,combatAnchorTail,combatAnchorDropped;static volatile LONG combatAnchorLock,combatAnchorEnabled;
static void combatAnchorSample(uintptr_t actor,const float current[3],const float anchor[2],uint64_t tick){
 directMotionSample(actor,current,anchor,tick);
 if(!InterlockedCompareExchange(&combatAnchorEnabled,0,0))return;
 CombatAnchorEvent e={.tick=tick,.dx=current[0]-anchor[0],.dy=current[1]-anchor[1]};uintptr_t state=0,again=0,buffer=0;float root[16];double local[2];
 bool ok=donorProcessIdentity(actor)&&worldRead(actor+0x3f8,&state,8)&&state&&state%8==0&&state<=UINTPTR_MAX-0x500&&donorProcessMotion(actor,&e.factor,root,&buffer);
 for(unsigned i=0;i<3&&ok;i++){uintptr_t pair[2]={0};ok=worldRead(state+i*0x250+0x10,pair,sizeof(pair));for(unsigned k=0;k<2&&ok;k++)ok=pair[k]>=donorProcessBase&&pair[k]-donorProcessBase<0x200000;if(ok){e.primary[i]=(uint32_t)(pair[0]-donorProcessBase);e.secondary[i]=(uint32_t)(pair[1]-donorProcessBase);}}
 ok=ok&&worldRead(actor+0x3f8,&again,8)&&again==state&&donorProcessIdentity(actor)&&combatLocalStep(root,current,anchor,local);
 if(ok){e.valid=true;e.side=local[0];e.forward=local[1];}
 if(InterlockedCompareExchange(&combatAnchorLock,1,0))return;
 unsigned next=(combatAnchorHead+1)%4096;if(next==combatAnchorTail)combatAnchorDropped++;else{combatAnchorEvents[combatAnchorHead]=e;combatAnchorHead=next;}InterlockedExchange(&combatAnchorLock,0);
}
static void combatAnchorTick(void){
 bool active=GetFileAttributesW(PROBE_PATH(L"\\combat-anchor-observe.enable"))!=INVALID_FILE_ATTRIBUTES&&InterlockedCompareExchange(&donorAnchorEnabled,0,0)&&!InterlockedCompareExchange(&probeBoundedComplete,0,0);InterlockedExchange(&combatAnchorEnabled,active);
 CombatAnchorEvent events[256];unsigned n=0;if(InterlockedCompareExchange(&combatAnchorLock,1,0))return;while(combatAnchorTail!=combatAnchorHead&&n<256){events[n++]=combatAnchorEvents[combatAnchorTail];combatAnchorTail=(combatAnchorTail+1)%4096;}unsigned dropped=combatAnchorDropped;InterlockedExchange(&combatAnchorLock,0);
 for(unsigned i=0;i<n;i++){CombatAnchorEvent *e=&events[i];logLine("COMBAT_ANCHOR tick=%llu valid=%u primary=%x,%x,%x secondary=%x,%x,%x delta=%.9g,%.9g local=%.9g,%.9g factor=%.9g dropped=%u; observation only",e->tick,e->valid,e->primary[0],e->primary[1],e->primary[2],e->secondary[0],e->secondary[1],e->secondary[2],e->dx,e->dy,e->side,e->forward,e->factor,dropped);}
}
