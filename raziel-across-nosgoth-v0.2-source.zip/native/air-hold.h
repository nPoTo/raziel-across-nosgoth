#include "session-budget.h"
#include "exploration-sheets.h"
typedef struct {
 bool enabled,hint,focused;uint64_t now,begin,packet,draw,launch;
 uintptr_t player,launchPlayer,renderPlayer;float height,upright;
 int32_t segment,time,clamp,velocity,acceleration;
} AirHoldScope;
typedef struct {uintptr_t player;uint64_t launch,start;bool blocked;} AirHoldTimer;
static bool airScopeValid(const AirHoldScope *s){
 return s->enabled&&s->hint&&s->focused&&s->player&&s->player==s->launchPlayer&&s->player==s->renderPlayer&&
 s->begin&&s->now>=s->begin&&sessionBudget(s->begin,s->now,(uint64_t)sheet_diagnosticLimits_controls.durationMs)&&s->packet&&s->now>=s->packet&&s->now-s->packet<250&&
 s->draw&&s->now>=s->draw&&s->now-s->draw<250&&s->launch&&s->now>=s->launch&&s->now-s->launch<6000&&
 s->height>100&&s->height<1600&&s->upright>.99f&&s->upright<1.01f&&s->segment==0&&s->clamp==0&&s->time>0&&s->time<=8192&&
 s->velocity>=-2048&&s->velocity<=2048&&s->acceleration>=-256&&s->acceleration<=256;
}
static bool airHoldStep(AirHoldTimer *timer,const AirHoldScope *s){
 if(!airScopeValid(s)){memset(timer,0,sizeof(*timer));return false;}
 if(timer->player!=s->player||timer->launch!=s->launch){*timer=(AirHoldTimer){s->player,s->launch,s->now,false};}
 if(s->now<timer->start||s->now-timer->start>=2000)timer->blocked=true;
 return !timer->blocked;
}

