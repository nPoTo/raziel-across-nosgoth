// SPDX-License-Identifier: GPL-3.0-or-later
#pragma once
#include "donor-animation-selection-reader.h"
typedef struct {uintptr_t callback,context,sourceObject,eventTable,clipResource,blend;} DonorAnimationEventOpaque;
typedef struct {bool callbackPresent,callbackKnown,contextPresent,sourceObjectPresent,sourceObjectMatchesActor,eventTablePresent,clipResourcePresent,blendPresent;uint32_t callbackRva;} DonorAnimationEventSection;
typedef struct {bool valid;DonorAnimationSelection selection;DonorAnimationEventSection sections[3];} DonorAnimationEventContext;
static inline DonorAnimationEventContext donorAnimationEventRead(void *c,DonorActionStateRead read,DonorActionStateCode code,uintptr_t base,uint32_t imageSize,uintptr_t actor){
 DonorAnimationEventContext out={0};const Sheet_donorAnimationEventProbe *p=&sheet_donorAnimationEventProbe_current;
 if(!read||!code||!actor||actor%8||!base||base>UINTPTR_MAX-imageSize||imageSize<0xc5aa80||p->actorObjectOffset!=0x88||p->sectionBaseOffset!=0x1d0||p->sectionStride!=0x68||p->callbackOffset!=0x30||p->contextOffset!=0x38||p->sourceObjectOffset!=0x40||p->eventTableOffset!=0x48||p->clipResourceOffset!=0x50||p->blendOffset!=0x58||p->pointerBytes!=8||p->stableReads!=2||p->serializePointers||p->dereferenceResources)return out;
 DonorAnimationEventOpaque a[3]={0},b[3]={0};uintptr_t object=0,afterObject=0;
 if(!donorSelectionField(c,read,actor,(uintptr_t)p->actorObjectOffset,&object,8)||!object)return out;
 for(unsigned pass=0;pass<2;pass++){
  DonorAnimationEventOpaque *s=pass?b:a;
  for(unsigned i=0;i<3;i++){
   uintptr_t section=(uintptr_t)p->sectionBaseOffset+i*(uintptr_t)p->sectionStride;
   if(!donorSelectionField(c,read,actor,section+(uintptr_t)p->callbackOffset,&s[i].callback,8)||!donorSelectionField(c,read,actor,section+(uintptr_t)p->contextOffset,&s[i].context,8)||!donorSelectionField(c,read,actor,section+(uintptr_t)p->sourceObjectOffset,&s[i].sourceObject,8)||!donorSelectionField(c,read,actor,section+(uintptr_t)p->eventTableOffset,&s[i].eventTable,8)||!donorSelectionField(c,read,actor,section+(uintptr_t)p->clipResourceOffset,&s[i].clipResource,8)||!donorSelectionField(c,read,actor,section+(uintptr_t)p->blendOffset,&s[i].blend,8))return out;
  }
  if(!pass){out.selection=donorAnimationSelectionRead(c,read,code,base,imageSize,actor);if(!out.selection.valid)return (DonorAnimationEventContext){0};}
 }
 uintptr_t current=0;
 if(memcmp(a,b,sizeof(a))||!donorSelectionField(c,read,actor,(uintptr_t)p->actorObjectOffset,&afterObject,8)||object!=afterObject||!read(c,base+0xc5aa78,&current,8)||current!=actor)return (DonorAnimationEventContext){0};
 // Bracket the outer snapshot too: callbacks/owner/key/clip must remain stable.
 DonorAnimationSelection after=donorAnimationSelectionRead(c,read,code,base,imageSize,actor);
 if(!after.valid)return (DonorAnimationEventContext){0};
 for(unsigned i=0;i<3;i++){
  const DonorAnimationSelectionSection *x=&out.selection.sections[i],*y=&after.sections[i];
  if(x->selectionKeyRaw!=y->selectionKeyRaw||x->animationId!=y->animationId||x->descriptorPresent!=y->descriptorPresent||x->state.firstRva!=y->state.firstRva||x->state.secondRva!=y->state.secondRva||x->state.secondValid!=y->state.secondValid)return (DonorAnimationEventContext){0};
  DonorAnimationEventSection *s=&out.sections[i];s->callbackPresent=a[i].callback!=0;s->callbackKnown=a[i].callback>=base&&a[i].callback-base<imageSize&&code(c,a[i].callback,base);
  if(s->callbackKnown)s->callbackRva=(uint32_t)(a[i].callback-base);
  s->contextPresent=a[i].context!=0;s->sourceObjectPresent=a[i].sourceObject!=0;s->sourceObjectMatchesActor=a[i].sourceObject==object;s->eventTablePresent=a[i].eventTable!=0;s->clipResourcePresent=a[i].clipResource!=0;s->blendPresent=a[i].blend!=0;
 }
 out.valid=true;return out;
}
