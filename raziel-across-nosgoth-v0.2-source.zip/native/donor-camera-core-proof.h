// Exact-build camera-frame argument; candidate core fields not yet classified.
#define DONOR_CAMERA_CORE_RVA 0x86ef40
#define DONOR_CAMERA_CORE_BYTES 0x8b0
