#include "general-test-budget.h"
// SPDX-License-Identifier: GPL-3.0-or-later
// Anonymous stdin pipe -> private pagefile mapping. No assets or game writes.
#include <stdio.h>
#include <stdlib.h>
#include <errno.h>
#include "exploration-sheets.h"
#include "reaver-presentation-memory.h"
#include "reaver-texture-memory.h"
static bool number(const wchar_t *s,uint64_t *v){
 if(!s||!*s)return false;for(const wchar_t *p=s;*p;p++)if(*p<L'0'||*p>L'9')return false;
 wchar_t *end;errno=0;unsigned long long n=wcstoull(s,&end,10);if(errno||*end||!n)return false;*v=n;return true;
}
static bool readBounded(HANDLE pipe,void *target,DWORD count,uint64_t deadline,HANDLE host,HANDLE donor){
 unsigned char *out=target;DWORD done=0;
 while(done<count){
  if(GetTickCount64()>=deadline||WaitForSingleObject(host,0)!=WAIT_TIMEOUT||WaitForSingleObject(donor,0)!=WAIT_TIMEOUT)return false;
  DWORD available=0;if(!PeekNamedPipe(pipe,NULL,0,NULL,&available,NULL))return false;
  if(!available){Sleep(2);continue;}
  DWORD got=0,want=count-done;if(want>available)want=available;
  if(!ReadFile(pipe,out+done,want,&got,NULL)||!got)return false;done+=got;
 }
 return true;
}
int wmain(int argc,wchar_t **argv){
 if(argc!=9||GetFileType(GetStdHandle(STD_INPUT_HANDLE))!=FILE_TYPE_PIPE||GetFileType(GetStdHandle(STD_OUTPUT_HANDLE))!=FILE_TYPE_PIPE)return 1;
 uint64_t values[8];for(unsigned i=0;i<8;i++)if(!number(argv[i+1],values+i))return 2;
 if(values[0]>UINT32_MAX||values[2]>UINT32_MAX)return 2;
 FILETIME born,exit,kernel,user;if(!GetProcessTimes(GetCurrentProcess(),&born,&exit,&kernel,&user))return 3;
 ReaverPacketSession s={(uint32_t)values[0],GetCurrentProcessId(),(uint32_t)values[2],values[1],((uint64_t)born.dwHighDateTime<<32)|born.dwLowDateTime,values[3],values[4],values[5],values[6],values[7]};
 if(!reaverPresentationProcess(s.hostPid,s.hostCreation)||!reaverPresentationProcess(s.donorPid,s.donorCreation))return 3;
 wchar_t name[160],lockName[160];reaverPresentationNames(&s,name,lockName);
 HANDLE lock=CreateMutexW(NULL,FALSE,lockName);if(!lock)return 4;if(GetLastError()==ERROR_ALREADY_EXISTS){CloseHandle(lock);return 4;}
 HANDLE map=CreateFileMappingW(INVALID_HANDLE_VALUE,NULL,PAGE_READWRITE,0,sizeof(ReaverPresentationMemory),name);
 if(!map||GetLastError()==ERROR_ALREADY_EXISTS){if(map)CloseHandle(map);CloseHandle(lock);return 4;}
 ReaverPresentationMemory *view=MapViewOfFile(map,FILE_MAP_WRITE,0,0,sizeof(*view));
 wchar_t textureName[192];reaverTextureMemoryName(&s,textureName);HANDLE textureMap=CreateFileMappingW(INVALID_HANDLE_VALUE,NULL,PAGE_READWRITE,0,sizeof(ReaverTextureMemory),textureName);
 bool textureOwner=textureMap&&GetLastError()!=ERROR_ALREADY_EXISTS;ReaverTextureMemory *textureView=textureOwner?MapViewOfFile(textureMap,FILE_MAP_WRITE,0,0,sizeof(*textureView)):NULL;
 ReaverPresentationLease *lease=calloc(1,sizeof(*lease));unsigned char *packet=malloc(REAVER_TEXTURE_PACKET_CAPACITY);int result=5;
 if(view&&textureView&&lease&&packet){
  lease->session=s;memset(view,0,sizeof(*view));view->magic=0x314d5752;view->version=1;
  memset(textureView,0,16);textureView->magic=0x314d5452;textureView->version=1;
  printf("{\"writerPid\":%lu,\"writerCreation\":\"%llu\",\"tick\":%llu}\n",(unsigned long)s.writerPid,(unsigned long long)s.writerCreation,(unsigned long long)GetTickCount64());fflush(stdout);
  HANDLE host=OpenProcess(SYNCHRONIZE,FALSE,s.hostPid),donor=OpenProcess(SYNCHRONIZE,FALSE,s.donorPid);
  uint64_t deadline=GetTickCount64()+GENERAL_OR_SHORT_MS(sheet_reaverPresentationPacket_weapon_frame_v1.maxLifetimeMs);result=0;
  for(;;){
   uint32_t size=0;if(!readBounded(GetStdHandle(STD_INPUT_HANDLE),&size,4,deadline,host,donor))break;
   if(size<128||size>REAVER_TEXTURE_PACKET_CAPACITY||!readBounded(GetStdHandle(STD_INPUT_HANDLE),packet,size,deadline,host,donor)){result=6;break;}
   bool texture=reaverPacketU32(packet)==0x31545752;
   if(texture?(textureView->online||!reaverTexturePacket(packet,size,&s)):!reaverPresentationAccept(lease,packet,size,GetTickCount64())){result=6;break;}
   // A reader may be copying the immutable texture bundle. Drop a transient
   // frame rather than terminate the session; its timestamp is never renewed.
   DWORD wait=WaitForSingleObject(lock,texture?100:0);if(wait==WAIT_TIMEOUT&&!texture)continue;
   if(wait!=WAIT_OBJECT_0){if(wait==WAIT_ABANDONED)ReleaseMutex(lock);result=7;break;}
   if(texture){textureView->size=size;memcpy(textureView->packet,packet,size);textureView->online=1;}
   else{view->online=0;view->size=size;memcpy(view->packet,lease->bytes,size);view->online=1;}ReleaseMutex(lock);
  }
  // EOF, process exit, malformed input and timeout revoke our mapping.
  DWORD wait=WaitForSingleObject(lock,0);if(wait==WAIT_OBJECT_0||wait==WAIT_ABANDONED){view->online=0;view->size=0;textureView->online=0;textureView->size=0;ReleaseMutex(lock);}
  if(host)CloseHandle(host);if(donor)CloseHandle(donor);
 }
 if(textureView)UnmapViewOfFile(textureView);if(textureMap)CloseHandle(textureMap);if(view)UnmapViewOfFile(view);if(map)CloseHandle(map);if(lock)CloseHandle(lock);free(lease);free(packet);return result;
}
