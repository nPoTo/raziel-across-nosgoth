// SPDX-License-Identifier: GPL-3.0-or-later
#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <stdbool.h>
#include <stdint.h>
#include <stdio.h>
#include <string.h>
#include <wchar.h>
#include "guidance-text.h"
int main(void){
 if(guidanceSeconds(15)!=80||guidanceSeconds(11)!=60)return 1;
 for(unsigned i=0;i<80;i++){const TutorialStage *s=guidanceStageAt(15,i);if(!s||i<s->begin||i>=s->end||!s->title[0]||!s->detail[0]||!guidanceRaster(15,i))return 2;}
 if(guidanceStageAt(15,19)->begin!=0||guidanceStageAt(15,20)->begin!=20||guidanceStageAt(15,80))return 3;
 size_t pixels=(size_t)sheet_guidanceRenderPolicy_native.rasterWidth*sheet_guidanceRenderPolicy_native.rasterHeight,visible=0,empty=0;
 for(size_t i=0;i<pixels;i++){unsigned char *p=guidancePixels+i*4;if(p[0]||p[1]||p[2]){if(!p[3])return 4;visible++;}else{if(p[3])return 5;empty++;}}
 if(!visible||!empty)return 6;
 puts("PASS all80 HUD seconds covered,20s preparation, text alpha only, no background.");return 0;
}
