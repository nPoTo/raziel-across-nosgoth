// SPDX-License-Identifier: GPL-3.0-or-later
#include <assert.h>
#include <stdio.h>
#include "first-block-core.h"
static const uint32_t neutral[3]={67,67,53},entry[3]={65,65,65},a[3]={87,87,53},b[3]={75,75,53};
static uint64_t seq=0,tick=100;
static FirstBlockIntent make(unsigned phase){FirstBlockIntent c={.session=77,.sequence=++seq,.tick=tick+=16,.valid=1};if(phase==FB_IDLE||phase==FB_ENTRY||phase==FB_HELD_ENTRY)c.phases[0]=c.phases[1]=c.phases[2]=phase;else{c.phases[0]=c.phases[1]=phase;c.phases[2]=FB_LOWER;}assert(firstBlockDesired(c.phases,&c.desired));return c;}
static uintptr_t step(FirstBlockControl *s,unsigned phase,const uint32_t before[3],const uint32_t after[3]){FirstBlockIntent c=make(phase);firstBlockBegin(s,&c,c.tick,true,false,true);firstBlockMotionBefore(s,true,before);uintptr_t r=firstBlockDirectionResult(s,true,UINT64_C(0xfedcba98765432ff));assert((r>>32)==UINT64_C(0xfedcba98));firstBlockMotionAfter(s,true,after);return (uint32_t)r;}
int main(void){
 FirstBlockControl s={.owns=true,.held=true,.suppress=true};
 assert(step(&s,FB_A,neutral,a)==0x10000001&&s.motionAccepted&&s.motionRequested);
 // Finishing a native cycle while the host still has the same phase must not
 // issue another directional start. This fixture does NOT prove host clocks.
 for(unsigned i=0;i<100;i++)assert(step(&s,FB_A,neutral,neutral)==0&&s.motionAccepted&&s.held);
 assert(step(&s,FB_STILL,neutral,neutral)==0&&!s.motionAccepted&&!s.motionRequested);
 assert(step(&s,FB_A,neutral,a)==0x10000001&&s.motionAccepted);
 // Opposite motion still running: wait for a known neutral; do not mistake
 // the old motion for a newly accepted request or force an animation state.
 assert(step(&s,FB_B,a,a)==0&&!s.motionAccepted&&!s.motionRequested);
 assert(step(&s,FB_B,a,neutral)==0&&!s.motionAccepted);
 assert(step(&s,FB_B,neutral,b)==0x10000003&&s.motionAccepted);
 // Queue latency: original direction and its resulting state can be observed
 // in different native frames. Remember only a scalar pending request.
 assert(step(&s,FB_STILL,neutral,neutral)==0);
 assert(step(&s,FB_A,entry,neutral)==0x10000001&&s.motionRequested&&!s.motionAccepted);
 assert(step(&s,FB_A,a,a)==0&&s.motionAccepted);
 // A host phase change invalidates pending acceptance of the old direction.
 assert(step(&s,FB_STILL,neutral,neutral)==0);
 assert(step(&s,FB_A,neutral,neutral)==0x10000001);
 assert(step(&s,FB_B,a,a)==0&&!s.motionRequested&&!s.motionAccepted);
 assert(step(&s,FB_B,neutral,neutral)==0x10000003);
 firstBlockMotionAfter(&s,false,b);assert(!s.motionAccepted);firstBlockMotionAfter(&s,true,b);assert(s.motionAccepted);
 // Foreign call scopes and unknown metadata never manufacture a request.
 assert(step(&s,FB_STILL,neutral,neutral)==0);FirstBlockIntent c=make(FB_A);firstBlockBegin(&s,&c,c.tick,true,false,true);firstBlockMotionBefore(&s,false,neutral);assert(!s.motionReady);uintptr_t raw=UINT64_C(0xfedcba98765432ff);assert(firstBlockDirectionResult(&s,false,raw)==raw&&!s.motionRequested);assert((uint32_t)firstBlockDirectionResult(&s,true,raw)==0&&!s.motionRequested);
 firstBlockMotionBefore(&s,true,neutral);assert((uint32_t)firstBlockDirectionResult(&s,true,raw)==0x10000001);firstBlockMotionAfter(&s,true,a);assert(s.motionAccepted);
 // The new latch must not retain movement/held ownership across expiry. The
 // original host-release rearm rule remains stronger than motion phase edges.
 firstBlockBegin(&s,&c,c.tick+151,true,false,true);firstBlockMotionBefore(&s,true,neutral);assert(!s.held&&s.released&&!s.motionAccepted&&!s.motionRequested);assert((uint32_t)firstBlockDirectionResult(&s,true,raw)==0);firstBlockAfter(&s,true);assert(!s.owns&&s.needIdle);
 c=make(FB_A);firstBlockBegin(&s,&c,c.tick,true,true,true);firstBlockMotionBefore(&s,true,neutral);assert(!s.owns&&!s.motionReady);c=make(FB_IDLE);firstBlockBegin(&s,&c,c.tick,true,true,true);c=make(FB_ENTRY);firstBlockBegin(&s,&c,c.tick,true,true,true);assert(s.owns&&s.held&&s.pressed&&!s.motionAccepted);
 puts("PASS production motion latch: native neutral admission, delayed acceptance, no repeated start in one host episode, opposite busy motion, phase-edge rearm, invalid metadata, foreign scope, full high-RAX and expired-owner release. Fixtures are not synchronized gameplay evidence.");return 0;
}
