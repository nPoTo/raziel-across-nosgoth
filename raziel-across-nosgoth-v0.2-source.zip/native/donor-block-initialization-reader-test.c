// SPDX-License-Identifier: GPL-3.0-or-later
#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <stdio.h>
#include "donor-block-initialization-reader.h"
static const uintptr_t base=0x10000000,actor=0x20000000,resource=0x30000000,userdata=0x40000000;
static unsigned resourceReads,userdataReads,flagReads;static int defect;static bool cleanup;
static bool readFixture(void *c,uintptr_t a,void *out,SIZE_T n){(void)c;uintptr_t v=0;
 if(a==actor+0xa8&&n==4){uint32_t f=cleanup?0x20000:0;if(defect==1&&++flagReads>1)f^=1;memcpy(out,&f,4);return true;}
 if(a==actor+0x310&&n==8){v=resource;if(defect==2&&++resourceReads>1)v+=8;}
 else if(a==resource+4&&n==2){uint16_t h=defect==3?0:0xb00b;memcpy(out,&h,2);return true;}
 else if(a==resource+2&&n==2){uint16_t t=defect==4?2:1;memcpy(out,&t,2);return true;}
 else if(a==actor+0x3a8&&n==8)v=base+(defect==5?0xee388:0xee380);
 else if(a==actor+0x3f8&&n==8){userdataReads++;v=defect==6?userdata+1:userdata;}
 else if(a==userdata+8&&n==8){userdataReads++;if(defect==7)return false;v=base+(defect==8?0xce4c0:0xce270);}
 else return false;memcpy(out,&v,n);return true;
}
static bool codeFixture(void *c,uintptr_t a,uintptr_t b){(void)c;return defect!=9&&b==base&&(a==base+0xee380||a==base+0xce270);}
static bool inspect(bool after,DonorBlockInitializationMetadata *m){resourceReads=userdataReads=flagReads=0;return donorBlockInitializationRead(NULL,readFixture,codeFixture,base,0x2000000,actor,after,m);}
#define CHECK(c,n) do{if(!(c)){printf("FAIL %u\n",(unsigned)n);return n;}}while(0)
int main(void){DonorBlockInitializationMetadata m;CHECK(inspect(false,&m)&&m.knownType&&!m.cleanup&&!m.initialized&&!userdataReads,1);CHECK(inspect(true,&m)&&m.knownType&&m.initialized&&userdataReads==4,2);cleanup=true;CHECK(inspect(true,&m)&&m.knownType&&m.cleanup&&!m.initialized&&!userdataReads,3);cleanup=false;
 for(defect=1;defect<=2;defect++)CHECK(!inspect(true,&m),10+defect);
 for(defect=3;defect<=4;defect++)CHECK(inspect(true,&m)&&!m.knownType&&!m.initialized&&!userdataReads,10+defect);
 for(defect=5;defect<=9;defect++)CHECK(!inspect(true,&m),10+defect);defect=0;
 CHECK(!donorBlockInitializationRead(NULL,readFixture,codeFixture,base,0x1000,actor,true,&m),20);
 CHECK(!donorBlockInitializationRead(NULL,readFixture,codeFixture,UINTPTR_MAX-1,0x2000000,actor,true,&m),21);
 CHECK(!donorBlockInitializationRead(NULL,readFixture,codeFixture,base,0x2000000,actor+1,true,&m),22);
 puts("PASS: typed subtype1 boundary reader, stable resource/flags, exact callbacks, no pre-init or cleanup userdata reads, unavailable/type/code/alignment/overflow rejection");return 0;}
