#define WIN32_LEAN_AND_MEAN
#include <stdio.h>
#include "bridge-protocol.h"
#include "bridge-process-identity.h"
#define CHECK(x) do{if(!(x)){printf("FAIL bridge protocol line%d\n",__LINE__);return 1;}}while(0)
int main(int argc,char **argv){
 CHECK(argc==2);unsigned char b[BRIDGE_HEADER_BYTES+80],bad[sizeof(b)],encoded[BRIDGE_HEADER_BYTES];FILE *f=fopen(argv[1],"rb");CHECK(f&&fread(b,1,sizeof(b),f)==sizeof(b));fclose(f);
 BridgeIdentity expected={.sourcePid=99,.hostPid=42,.sourceCreation=111,.hostCreation=222,.sessionGeneration=7,.levelGeneration=9,.actorId=1,.actorGeneration=2,.capabilities=3};
 CHECK(bridgeHex(sheet_bridgeProtocol_session_v2.sourceBuild,expected.sourceBuild)&&bridgeHex(sheet_bridgeProtocol_session_v2.hostBuild,expected.hostBuild));
 BridgeHeader h;CHECK(bridgeDecode(b,BRIDGE_HEADER_BYTES,sizeof(b),1000,&expected,&h));CHECK(h.sequence==3&&h.tick==950&&h.type==BRIDGE_MOVEMENT);
 CHECK(bridgeEncodeHeader(encoded,sizeof(encoded),&h)&&!memcmp(encoded,b,sizeof(encoded)));
 BridgeLedger ledger;bridgeLedgerBegin(&ledger,&expected);CHECK(bridgeAccept(&ledger,&h)&&!bridgeAccept(&ledger,&h));
 BridgeHeader hello=h;hello.type=BRIDGE_HELLO;hello.sequence=1;hello.payloadBytes=0;CHECK(bridgeAccept(&ledger,&hello));
 hello.identity.levelGeneration++;CHECK(!bridgeAccept(&ledger,&hello));
 BridgeIdentity wrong=expected;wrong.sourceCreation++;CHECK(!bridgeDecode(b,BRIDGE_HEADER_BYTES,sizeof(b),1000,&wrong,&h));wrong=expected;wrong.hostCreation++;CHECK(!bridgeDecode(b,BRIDGE_HEADER_BYTES,sizeof(b),1000,&wrong,&h));
 wrong=expected;wrong.levelGeneration++;CHECK(!bridgeDecode(b,BRIDGE_HEADER_BYTES,sizeof(b),1000,&wrong,&h));
 CHECK(!bridgeDecode(b,151,sizeof(b),1000,&expected,&h)&&!bridgeDecode(b,152,sizeof(b)-1,1000,&expected,&h));
 memcpy(bad,b,sizeof(b));bad[0]^=1;CHECK(!bridgeDecode(bad,152,sizeof(b),1000,&expected,&h));
 memcpy(bad,b,sizeof(b));bridgePut(bad+12,UINT32_MAX,4);CHECK(!bridgeDecode(bad,152,UINT64_MAX,1000,&expected,&h));
 memcpy(bad,b,sizeof(b));bridgePut(bad+72,1001,8);CHECK(!bridgeDecode(bad,152,sizeof(b),1000,&expected,&h));bridgePut(bad+72,499,8);CHECK(!bridgeDecode(bad,152,sizeof(b),1000,&expected,&h));
 memcpy(bad,b,sizeof(b));bad[88]^=1;CHECK(!bridgeDecode(bad,152,sizeof(b),1000,&expected,&h));
 uint32_t mask=0;CHECK(bridgeNegotiate(15,3,&mask)&&mask==3&&!bridgeNegotiate(15,16,&mask));
 uint64_t creation=0;CHECK(bridgeProcessCreation(GetCurrentProcess(),&creation)&&creation);
 puts("PASS: native/JS exact-byte roundtrip, per-stream ledger, creation identity, bounds/build/generation/freshness and capability gates; Windows creation query");return 0;
}
