#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <stdbool.h>
#include <stdio.h>
#include <string.h>
static void logLine(const char *fmt,...) {(void)fmt;}
#include "background-input.h"
static char value[256];static bool present,fail;static int sets,resets;
static const char *get(const char *key) {(void)key;return present?value:NULL;}
static bool set(const char *key,const char *v) {(void)key;++sets;if(fail)return false;strcpy(value,v);present=true;return true;}
static bool reset(const char *key) {(void)key;++resets;present=false;return true;}
int main(void) {
 backgroundInit();backgroundGet=get;backgroundSet=set;backgroundReset=reset;
 backgroundTick(true);if(!backgroundOwned||strcmp(value,"1"))return 1;
 backgroundTick(true);if(sets!=1)return 2;
 backgroundTick(false);if(present||backgroundOwned||resets!=1)return 3;
 strcpy(value,"0");present=true;backgroundTick(true);backgroundTick(false);if(strcmp(value,"0"))return 4;
 strcpy(value,"1");backgroundTick(true);if(backgroundOwned)return 5;backgroundTick(false);if(strcmp(value,"1"))return 6;
 strcpy(value,"0");backgroundTick(true);strcpy(value,"external");backgroundTick(false);if(strcmp(value,"external"))return 7;
 fail=true;backgroundTick(true);if(backgroundOwned||strcmp(value,"external"))return 8;backgroundTick(false);
 memset(value,'x',255);value[255]=0;fail=false;backgroundTick(true);backgroundTick(false);if(strlen(value)!=255)return 9;
 puts("Background hint: enable, idempotence, null/value restore, prior enable, external changes, failure PASS");return 0;
}
