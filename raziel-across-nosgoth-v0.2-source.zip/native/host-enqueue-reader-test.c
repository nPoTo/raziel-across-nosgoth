// SPDX-License-Identifier: GPL-3.0-or-later
#include <stdio.h>
#include "host-enqueue-reader.h"
static const uintptr_t base=0x10000000,actor=0x20000000;
static struct {unsigned reads,actorReads,ownerReads,callbackReads;bool badOwner,badCode,raceActor,raceOwner,raceCode;int32_t index;} f;
static bool fixtureRead(void *unused,uintptr_t address,void *out,SIZE_T n){
 (void)unused;f.reads++;const Sheet_hostBlockStateProbe *p=&sheet_hostBlockStateProbe_current;uintptr_t value=0;
 if(address==base+(uintptr_t)p->currentActorRva&&n==8){value=actor+(f.raceActor&&f.actorReads++>0?8:0);memcpy(out,&value,8);return true;}
 if(address==base+(uintptr_t)p->stateRva&&n==8){value=actor+((f.badOwner||(f.raceOwner&&f.ownerReads++>0))?8:0);memcpy(out,&value,8);return true;}
 for(unsigned i=0;i<3;i++){
  uintptr_t s=base+(uintptr_t)p->stateRva+i*0x228;
  if(address==s+0x10&&n==8){value=base+0xeeb40+(f.raceCode&&f.callbackReads++>0?16:0);memcpy(out,&value,8);return true;}
  if((address==s+0x18+4||address==s+0x120+4)&&n==4){memcpy(out,&f.index,4);return true;}
 }return false;
}
static bool code(void *unused,uintptr_t address,uintptr_t image){(void)unused;return !f.badCode&&image==base&&address>=base&&address<base+0x3000000;}
static int run(uintptr_t q){HostEnqueueMetadata m={0};return hostEnqueueRead(NULL,fixtureRead,code,base,0x3000000,q,&m);}
#define CHECK(c,n) do{if(!(c)){printf("FAIL %u\n",(unsigned)(n));return n;}}while(0)
int main(void){
 uintptr_t q=base+0x2a88588+0x18;HostEnqueueMetadata m={0};
 for(unsigned i=0;i<3;i++)for(unsigned kind=0;kind<2;kind++){memset(&f,0,sizeof(f));CHECK(hostEnqueueRead(NULL,fixtureRead,code,base,0x3000000,base+0x2a88588+i*0x228+(kind?0x120:0x18),&m)==1&&m.section==i&&m.queueKind==kind&&m.handlerRva==0xeeb40&&m.opaqueActor==actor,1);}
 memset(&f,0,sizeof(f));CHECK(run(q+1)==0&&f.reads==0,2);
 memset(&f,0,sizeof(f));f.badOwner=true;CHECK(run(q)==-1,3);
 memset(&f,0,sizeof(f));f.badCode=true;CHECK(run(q)==-1,4);
 memset(&f,0,sizeof(f));f.raceActor=true;CHECK(run(q)==-1,5);
 memset(&f,0,sizeof(f));f.raceOwner=true;CHECK(run(q)==-1,6);
 memset(&f,0,sizeof(f));f.raceCode=true;CHECK(run(q)==-1,7);
 memset(&f,0,sizeof(f));f.index=-1;CHECK(run(q)==-1,8);f.index=16;CHECK(run(q)==-1,9);f.index=15;CHECK(run(q)==1,10);
 CHECK(hostEnqueueRead(NULL,fixtureRead,code,UINTPTR_MAX-1,0x3000000,q,&m)==-1,11);
 puts("PASS: actual host enqueue reader exact six queue addresses, unrelated no-read filter, section/kind, actor/owner/code/index/race/overflow checks; no payload access");return 0;
}
