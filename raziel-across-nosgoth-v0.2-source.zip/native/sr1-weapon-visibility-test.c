// SPDX-License-Identifier: GPL-3.0-or-later
#include <stdio.h>
#include <stddef.h>
#include "sr1-weapon-visibility.h"
#include "sr1-weapon-session.h"
#define CHECK(x,n) do{if(!(x)){printf("failed %d\n",n);return n;}}while(0)
int main(void){
 Sr1WeaponVisibility s={.requested=true,.healthyLease=true,.originalModel=true,.actor=1,.object=2,.model=3,.expectedActor=1,.expectedObject=2,.expectedModel=3};
 CHECK(sr1WeaponVisibilityAllowed(&s),1);
 // There is deliberately no pose/ground/draw freshness field in this contract.
 // Native flight/yield can keep weapon visuals hidden without suppressing body.
 s.requested=false;CHECK(!sr1WeaponVisibilityAllowed(&s),2);s.requested=true;
 s.healthyLease=false;CHECK(!sr1WeaponVisibilityAllowed(&s),3);s.healthyLease=true;
 s.complete=true;CHECK(!sr1WeaponVisibilityAllowed(&s),4);s.complete=false;
 s.originalModel=false;CHECK(!sr1WeaponVisibilityAllowed(&s),5);s.originalModel=true;
 s.actor=4;CHECK(!sr1WeaponVisibilityAllowed(&s),6);s.actor=1;
 s.object=4;CHECK(!sr1WeaponVisibilityAllowed(&s),7);s.object=2;
 s.model=4;CHECK(!sr1WeaponVisibilityAllowed(&s),8);s.model=3;
 s.actor=0;CHECK(!sr1WeaponVisibilityAllowed(&s),9);CHECK(!sr1WeaponVisibilityAllowed(NULL),10);
 Sr1WeaponSession owner={0};Sr1WeaponSessionObservation o={.requested=true,.healthy=true,.originalModel=true,.writer=4,.session=5,.begin=100,.now=100,.actor=1,.object=2,.model=3};
 CHECK(sr1WeaponSessionStep(&owner,&o,100000),11);o.now=100099;CHECK(sr1WeaponSessionStep(&owner,&o,100000),12);o.now=100100;CHECK(!sr1WeaponSessionStep(&owner,&o,100000)&&owner.ended,13);
 o.now=100;CHECK(!sr1WeaponSessionStep(&owner,&o,100000),14);CHECK(!sr1WeaponSessionStep(NULL,&o,100000)&&!sr1WeaponSessionStep(&owner,NULL,100000),15);
 puts("Weapon visibility lease: native body/flight independent; expiry, cancellation, actor/object/model and original-model refusal PASS; no contact/physics writes");return 0;
}
