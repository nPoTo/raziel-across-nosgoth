// SPDX-License-Identifier: GPL-3.0-or-later
// Isolated, original-once input-frame detour. No input/state modification.
#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <bcrypt.h>
#include <stdint.h>
#include <stdbool.h>
#include <stdio.h>
#include <string.h>
#include "MinHook.h"
#include "input-frame-sheets.h"
typedef void (*FrameFn)(void);
static FrameFn original;
static uintptr_t base;
static bool host;
static volatile LONG enabled,lock,started,drops;
static unsigned head,tail;
static LONG64 calls;
typedef struct {uint64_t tick,call;DWORD thread,foreground;unsigned char keys[112];uint32_t mask,pad;unsigned char donorKeys[512],mouse[9];bool readable;} Sample;
static Sample queue[512];
static bool readAt(uintptr_t at,void *out,SIZE_T size){SIZE_T got=0;return ReadProcessMemory(GetCurrentProcess(),(void*)at,out,size,&got)&&got==size;}
static bool digest(uintptr_t at,unsigned size,const wchar_t *expected){
 unsigned char bytes[6000],hash[32];if(size>sizeof(bytes)||!readAt(at,bytes,size))return false;
 BCRYPT_ALG_HANDLE alg=NULL;BCRYPT_HASH_HANDLE h=NULL;bool ok=false;
 if(BCryptOpenAlgorithmProvider(&alg,BCRYPT_SHA256_ALGORITHM,NULL,0)<0)return false;
 if(BCryptCreateHash(alg,&h,NULL,0,NULL,0,0)>=0&&BCryptHashData(h,bytes,size,0)>=0&&BCryptFinishHash(h,hash,sizeof(hash),0)>=0){wchar_t hex[65];for(unsigned i=0;i<32;i++)swprintf(hex+2*i,65-2*i,L"%02x",hash[i]);ok=!wcscmp(hex,expected);}
 if(h)BCryptDestroyHash(h);
 BCryptCloseAlgorithmProvider(alg,0);return ok;
}
static void observe(void){
 original(); // Preserve the complete original call, including event pumping.
 LONG64 call=InterlockedIncrement64(&calls);
 if(!InterlockedCompareExchange(&enabled,0,0))return;
 Sample s={0};s.tick=GetTickCount64();s.call=(uint64_t)call;s.thread=GetCurrentThreadId();GetWindowThreadProcessId(GetForegroundWindow(),&s.foreground);
 if(host)s.readable=readAt(base+sheet_dualInputObservation_srx.keyRva,s.keys,sizeof(s.keys))&&readAt(base+sheet_dualInputObservation_srx.keyboardMaskRva,&s.mask,4)&&readAt(base+sheet_dualInputObservation_srx.padMaskRva,&s.pad,4);
 else s.readable=readAt(base+sheet_inputFrameDonor_sdl.keyRva,s.donorKeys,sizeof(s.donorKeys))&&readAt(base+sheet_inputFrameDonor_sdl.mouseRva,s.mouse,sizeof(s.mouse));
 if(InterlockedCompareExchange(&lock,1,0)){InterlockedIncrement(&drops);return;}
 unsigned next=(head+1)%512;if(next==tail)InterlockedIncrement(&drops);else{queue[head]=s;head=next;}InterlockedExchange(&lock,0);
}
static void flush(FILE *f){
 Sample local[512];unsigned n=0;if(InterlockedCompareExchange(&lock,1,0))return;
 while(tail!=head){local[n++]=queue[tail];tail=(tail+1)%512;}InterlockedExchange(&lock,0);
 for(unsigned i=0;i<n;i++){Sample *s=&local[i];fprintf(f,"{\"tick\":%llu,\"call\":%llu,\"thread\":%lu,\"foreground\":%lu,\"readable\":%s,\"mask\":%u,\"pad\":%u,\"held\":[",(unsigned long long)s->tick,(unsigned long long)s->call,s->thread,s->foreground,s->readable?"true":"false",s->mask,s->pad);unsigned count=0;for(unsigned k=0;k<(host?112:512);k++)if(host?s->keys[k]:s->donorKeys[k])fprintf(f,"%s%u",count++?",":"",k);fprintf(f,"],\"mouse\":[");for(unsigned k=0;k<9;k++)fprintf(f,"%s%u",k?",":"",s->mouse[k]);fprintf(f,"]}\n");}if(n)fflush(f);
}
static DWORD WINAPI worker(void *unused){
 (void)unused;wchar_t name[32768];if(!GetModuleFileNameW(NULL,name,32768))return 1;
 wchar_t *leaf=wcsrchr(name,L'\\');if(!leaf)return 2;host=!_wcsicmp(leaf+1,L"SRX.exe");if(!host&&_wcsicmp(leaf+1,L"defiance.exe"))return 2;
 base=(uintptr_t)GetModuleHandleW(NULL);const Sheet_inputFrameProof *p=host?&sheet_inputFrameProof_host:&sheet_inputFrameProof_donor;
 wchar_t report[32768];swprintf(report,32768,L"@RAZIEL_SOURCE_ROOT@\\reports\\build-tasks\\input-frame-%ls-%lu.jsonl",host?L"host":L"donor",GetCurrentProcessId());FILE *f=_wfopen(report,L"wx");if(!f)return 3;
 if(!digest(base+p->rva,(unsigned)p->size,p->sha256)){fputs("{\"error\":\"code_identity\"}\n",f);fclose(f);return 4;}
 PVOID target=(PVOID)(base+p->rva);MH_STATUS init=MH_Initialize();if(init!=MH_OK&&init!=MH_ERROR_ALREADY_INITIALIZED){fclose(f);return 5;}
 if(MH_CreateHook(target,(PVOID)observe,(PVOID*)&original)!=MH_OK||MH_EnableHook(target)!=MH_OK){fputs("{\"error\":\"hook\"}\n",f);fclose(f);return 6;}
 fprintf(f,"{\"type\":\"session\",\"pid\":%lu,\"host\":%s,\"readOnly\":true}\n",GetCurrentProcessId(),host?"true":"false");fflush(f);
 uint64_t start=GetTickCount64(),active=0;bool saw=false;
 while(GetTickCount64()-start<600000){
  bool request=GetFileAttributesW(L"@RAZIEL_SOURCE_ROOT@\\reports\\runtime\\input-frame-observe.enable")!=INVALID_FILE_ATTRIBUTES;
  if(request&&!saw){saw=true;active=GetTickCount64();InterlockedExchange(&enabled,1);}
  if(saw&&(!request||GetTickCount64()-active>=200000))break;
  flush(f);Sleep(10);
 }
 InterlockedExchange(&enabled,0);MH_STATUS stop=MH_DisableHook(target);flush(f);
 fprintf(f,"{\"type\":\"end\",\"calls\":%lld,\"drops\":%ld,\"hookDisabled\":%s}\n",InterlockedCompareExchange64(&calls,0,0),InterlockedCompareExchange(&drops,0,0),stop==MH_OK?"true":"false");fclose(f);
 // Keep the trampoline and module alive: a concurrent original call may return.
 return 0;
}
static unsigned mockCalls;static __declspec(noinline) void mock(void){mockCalls++;}
__declspec(dllexport) int LOKProbeSelfTest(void){
 original=mock;enabled=0;observe();observe();if(mockCalls!=2||calls!=2)return 1;
 const char abc[]="abc";if(!digest((uintptr_t)abc,3,L"ba7816bf8f01cfea414140de5dae2223b00361a396177a9cb410ff61f20015ad"))return 2;
 if(digest((uintptr_t)abc,3,L"bad")||digest(0,6001,L"bad"))return 3;
 host=true;base=0;enabled=1;observe();enabled=0;
 if(mockCalls!=3||head!=1||queue[0].readable)return 4;
 for(unsigned i=0;i<112;i++)if(queue[0].keys[i])return 5;
 head=tail=0;calls=0;mockCalls=0;original=NULL;
 if(MH_Initialize()!=MH_OK)return 6;
 if(MH_CreateHook((PVOID)mock,(PVOID)observe,(PVOID*)&original)!=MH_OK)return 7;
 if(MH_EnableHook((PVOID)mock)!=MH_OK)return 8;
 FrameFn volatile invoke=mock;invoke();if(mockCalls!=1||calls!=1)return 9;
 if(MH_DisableHook((PVOID)mock)!=MH_OK)return 10;invoke();if(mockCalls!=2||calls!=1)return 11;
 MH_RemoveHook((PVOID)mock);MH_Uninitialize();original=NULL;calls=0;mockCalls=0;return 0;
}
__declspec(dllexport) void InitializeASI(void){if(InterlockedCompareExchange(&started,1,0))return;HANDLE t=CreateThread(NULL,0,worker,NULL,0,NULL);if(t)CloseHandle(t);}
BOOL WINAPI DllMain(HINSTANCE h,DWORD why,LPVOID reserved){(void)reserved;if(why==DLL_PROCESS_ATTACH)DisableThreadLibraryCalls(h);return TRUE;}
