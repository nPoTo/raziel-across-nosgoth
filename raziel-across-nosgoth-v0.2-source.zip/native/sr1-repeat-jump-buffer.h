// SPDX-License-Identifier: GPL-3.0-or-later
#pragma once
#include <stdint.h>
#include <stdbool.h>
#include <string.h>
// Intent only. Never enters a native state or writes position/velocity.
// Caller must supply a coherent current actor, native ground/landing scope,
// foreground, unpaused game, unique device and a fresh bounded owner lease.
typedef enum {REPEAT_JUMP_OTHER,REPEAT_JUMP_LANDING,REPEAT_JUMP_GROUND} RepeatJumpPhase;
typedef struct {uint64_t last,pressed,releaseBegin,pulseBegin;uintptr_t actor;uint16_t raw;bool seen,pending,releasing,pulsing;} RepeatJumpBuffer;
typedef struct {bool active;uint32_t value,raw;uint16_t buttons;} RepeatJumpPacket;
static inline uint32_t repeatJumpPacket(RepeatJumpPacket *p,uint32_t raw,uint16_t hardware,uint16_t delivered){
 if(!p->active&&hardware==delivered)return raw;
 if(p->active&&hardware==delivered){uint32_t restore=raw==p->value?raw+1:raw;p->active=false;return restore;}
 if(!p->active){p->active=true;p->value=raw+1;}
 else if(p->raw!=raw||p->buttons!=delivered)p->value++;
 p->raw=raw;p->buttons=delivered;
 return p->value;
}
static inline uint16_t repeatJumpStep(RepeatJumpBuffer *b,uint64_t now,uintptr_t actor,
 bool eligible,RepeatJumpPhase phase,uint16_t raw,uint32_t intentMs,uint32_t releaseMs,uint32_t pulseMs){
 const uint16_t A=0x1000;
 if(!eligible||!actor||phase==REPEAT_JUMP_OTHER||intentMs!=350||releaseMs!=32||pulseMs!=64){memset(b,0,sizeof(*b));return raw;}
 if(!b->seen||b->actor!=actor||now<b->last||now-b->last>100){memset(b,0,sizeof(*b));b->seen=true;b->actor=actor;b->raw=raw;b->last=now;return raw;}
 bool edge=(raw&A)&&!(b->raw&A);b->raw=raw;b->last=now;
 if(edge&&phase==REPEAT_JUMP_LANDING){b->pending=true;b->pressed=now;b->releasing=b->pulsing=false;}
 if(edge&&phase==REPEAT_JUMP_GROUND){b->pending=b->releasing=b->pulsing=false;return raw;}
 if(b->pending&&!b->pulsing&&now-b->pressed>intentMs){b->pending=b->releasing=false;return raw;}
 if(phase==REPEAT_JUMP_LANDING)return raw;
 if(!b->pending)return raw;
 // A held through landing needs a clean up edge before replay. A released
 // by the player already has that edge and can be delivered immediately.
 if(!b->pulsing&&(raw&A)&&!b->releasing){b->releasing=true;b->releaseBegin=now;}
 if(b->releasing){if(now-b->releaseBegin<releaseMs)return raw&~A;b->releasing=false;}
 if(!b->pulsing){b->pulsing=true;b->pulseBegin=now;}
 if(now-b->pulseBegin<pulseMs)return raw|A;
 b->pending=b->pulsing=false;return raw;
}
