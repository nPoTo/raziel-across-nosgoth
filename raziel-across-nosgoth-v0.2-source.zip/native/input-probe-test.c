#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <stdint.h>
#include <stdbool.h>
#include <stdio.h>
#include <wchar.h>
#define PROBE_REPORT_DIR L"."
static void logLine(const char *fmt,...) {(void)fmt;}
#include "input-probe.h"
static uint32_t ids[]={42,0};static int freeCalls;
static uint32_t *pads(int *count) {*count=1;return ids;}
static void *handle(uint32_t id) {return id==42?(void *)(uintptr_t)1:NULL;}
static int16_t axis(void *p,int k) {(void)p;return k==0?-32768:k==5?32767:0;}
static bool button(void *p,int k) {(void)p;return k==0||k==14;}
static int type(void *p) {(void)p;return 1;}
static void release(void *p) {(void)p;++freeCalls;}
int main(void) {
 inputInit();inputPads=pads;inputHandle=handle;inputAxis=axis;inputButton=button;inputType=type;inputFree=release;
 inputEnabled=true;inputFlagCheck=inputBegin=GetTickCount64();inputObserve();
 if(inputHead!=1||inputQueue[0].buttons!=16385||inputQueue[0].axes[0]!=-32768||inputQueue[0].axes[5]!=32767||freeCalls!=1)return 1;
 inputObserve();if(inputHead!=1)return 2;
 inputLast=0;inputTail=2;inputObserve();if(inputHead!=1||inputDrops!=1)return 3;
 inputLock=1;inputObserve();inputLock=0;if(inputDrops!=2)return 4;
 inputBegin=GetTickCount64()-120001;inputLast=0;inputObserve();if(freeCalls!=2)return 5;
 inputFlush();puts("Input observer: endpoints, buttons, rate limit, full queue, reentrancy, expiry PASS");return 0;
}
