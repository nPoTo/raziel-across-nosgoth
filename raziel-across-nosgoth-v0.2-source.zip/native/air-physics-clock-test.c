// SPDX-License-Identifier: GPL-3.0-or-later
#include "air-physics-clock.h"
#include <assert.h>
#include <stdio.h>
int main(void){
 AirPhysicsClock c={0};AirPhysicsClockInput s={.enabled=true,.identity=true,.hostAir=true,.donorAttack=true,.epoch=1000,.now=1100,.sourceTick=1100,.scalar=50,.time=4096};
 assert(airPhysicsClockStep(&c,&s)==50);
 s.scalar=4096;assert(airPhysicsClockStep(&c,&s)==4096);
 s.scalar=50;s.nativeAction=true;assert(airPhysicsClockStep(&c,&s)==4096&&!c.active);
 s.nativeAction=false;s.hostAir=false;assert(airPhysicsClockStep(&c,&s)==4096);
 s.hostAir=true;s.sourceTick=999;assert(airPhysicsClockStep(&c,&s)==4096);
 s.sourceTick=1101;assert(airPhysicsClockStep(&c,&s)==4096);
 s.sourceTick=1100;s.now=1201;assert(airPhysicsClockStep(&c,&s)==4096);
 s.now=s.sourceTick=1200;assert(airPhysicsClockStep(&c,&s)==50);
 s.now=s.sourceTick=4200;assert(airPhysicsClockStep(&c,&s)==4096&&c.exhausted);
 s.donorAttack=false;assert(airPhysicsClockStep(&c,&s)==4096);s.donorAttack=true;
 s.now=s.sourceTick=4210;assert(airPhysicsClockStep(&c,&s)==4096);
 c=(AirPhysicsClock){0};s.now=s.sourceTick=1500;s.scalar=123;s.time=1000;
 int total=0;for(int i=0;i<100;i++)total+=airPhysicsClockStep(&c,&s);
 assert(total==100000*123/4096);
 s.clamp=1;assert(airPhysicsClockStep(&c,&s)==1000);s.clamp=0;
 s.segment=1;assert(airPhysicsClockStep(&c,&s)==1000);
 puts("PASS fractional time, exact release, native/ground/stale/foreign gates and session-latched bound; no runtime/gameplay claim");
}
