// RZL2 transport validation, independent of GL and process memory.
#ifndef LIVE_PACKET_H
#define LIVE_PACKET_H
#ifdef SR1_RETARGET_PREVIEW
#include "sr1-render-profile.h"
static const unsigned char sr1ProfileHash[32]=SR1_PROFILE_HASH_BYTES;
#define LIVE_HEADER_BYTES 96u
#else
#define LIVE_HEADER_BYTES 64u
#endif
static inline bool livePoseFresh(uint64_t tick,uint64_t now){return tick&&tick<=now&&now-tick<=500;}
static bool liveHeaderValid(const uint32_t h[16],uint32_t vertices,uint64_t size,uint64_t now,uint64_t previousTick) {
#ifdef SR1_RETARGET_PREVIEW
    uint64_t tick;memcpy(&tick,&h[4],8);
    return vertices==SR1_PROFILE_VERTICES&&size==LIVE_HEADER_BYTES+(uint64_t)vertices*12&&h[0]==SR1_PROFILE_POSE_MAGIC&&h[1]==vertices&&h[2]==3&&h[6]&&h[7]==1&&
        !memcmp(&h[8],sr1ProfileHash,32)&&tick<=now&&now-tick<=500&&tick>previousTick;
#else
    static const unsigned char hash[32]={0x40,0x59,0xa8,0x3f,0x3d,0x47,0xa1,0x98,0x71,0x4b,0x21,0x5a,0xae,0xdc,0x21,0xc8,0x91,0x93,0x14,0xc7,0xd4,0xfc,0xd6,0x79,0x55,0x0f,0x89,0x60,0xc1,0xd8,0xda,0x0c};
    uint64_t tick; memcpy(&tick,&h[4],8);
    return vertices && vertices<=100000 && size==64+(uint64_t)vertices*12 && h[0]==0x324c5a52 && h[1]==vertices && h[2]==2 && h[6] && (h[7]==1||h[7]==5||h[7]==9||h[7]==13) &&
        !memcmp(&h[8],hash,32) && tick<=now && now-tick<=500 && tick>previousTick;
#endif
}
#endif
