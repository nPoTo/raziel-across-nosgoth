// Diagnostic probe: public-API IAT counters and model-init observation; no gameplay state writes.
// SPDX-License-Identifier: GPL-3.0-or-later
#define WIN32_LEAN_AND_MEAN
#define COBJMACROS
#include <windows.h>
#include <tlhelp32.h>
#include <bcrypt.h>
#include <stdint.h>
#include <stdio.h>
#include <stdarg.h>
#include <stdbool.h>
#include <string.h>
#include <wchar.h>
#include <MinHook.h>
#include <GL/gl.h>
#include "profiles.h"

static HMODULE self;
static FILE *logFile;
static SRWLOCK logLock = SRWLOCK_INIT;
static HGLRC loggedContext;
static unsigned int contextLogs;
static PVOID volatile verifiedSr1Module;
static volatile LONG64 swapCalls, pollCalls;
static volatile LONG probeBoundedComplete;
typedef BOOL (WINAPI *SwapFn)(HDC);
typedef bool (__cdecl *PollFn)(void *);
static SwapFn originalSwap;
static PollFn originalPoll;
static PVOID *patchedSlot;
static PVOID originalTarget;
static PVOID hookTarget;
typedef int64_t (__fastcall *CharFn)(int64_t, int64_t, int64_t);
static CharFn originalChar;
static PVOID charTarget;
static volatile LONG eventLock;
static volatile LONG64 charCalls, droppedEvents;
typedef struct {
    int64_t args[3], result;
    unsigned char prefix[3][64];
    SIZE_T readable[3];
    LONG64 sequence;
} CharEvent;
static CharEvent latestCharEvent;
static int64_t __fastcall observeChar(int64_t a, int64_t b, int64_t c) {
    CharEvent event = {0}; event.args[0] = a; event.args[1] = b; event.args[2] = c;
    event.sequence = InterlockedIncrement64(&charCalls);
    for (int i = 0; i < 3; ++i) {
        SIZE_T copied = 0;
        if (ReadProcessMemory(GetCurrentProcess(), (LPCVOID)(uintptr_t)event.args[i],
                              event.prefix[i], sizeof(event.prefix[i]), &copied)) event.readable[i] = copied;
    }
    event.result = originalChar(a, b, c);
    if (!InterlockedCompareExchange(&eventLock, 1, 0)) {
        latestCharEvent = event;
        InterlockedExchange(&eventLock, 0);
    } else InterlockedIncrement64(&droppedEvents);
    return event.result;
}
static bool mockSwapSeen, mockPollSeen, mockDrawSeen;
static unsigned int mockSwapForwards;
static void WINAPI mockDraw(GLenum mode,GLsizei count,GLenum type,const void *indices) {mockDrawSeen=mode==GL_TRIANGLES&&count==9&&type==GL_UNSIGNED_INT&&indices==(void *)(uintptr_t)0x2468;}
static BOOL WINAPI mockSwap(HDC dc) { ++mockSwapForwards;mockSwapSeen = dc == (HDC)(uintptr_t)0x1234; return FALSE; }
static bool __cdecl mockPoll(void *event) { mockPollSeen = event == (void *)(uintptr_t)0x5678; return true; }
static void logLine(const char *fmt, ...) {
    AcquireSRWLockExclusive(&logLock);
    if (!logFile) { ReleaseSRWLockExclusive(&logLock); return; }
    fprintf(logFile, "[%llu] ", (unsigned long long)GetTickCount64());
    va_list args; va_start(args, fmt); vfprintf(logFile, fmt, args); va_end(args);
    fputc('\n', logFile); fflush(logFile);
    ReleaseSRWLockExclusive(&logLock);
}
static void closeLog(void) {
    AcquireSRWLockExclusive(&logLock);
    if(logFile) fclose(logFile); logFile=NULL;
    ReleaseSRWLockExclusive(&logLock);
}
static bool hashFile(const wchar_t *file,char output[65]);
static bool hashBytes(const void *data,ULONG length,char output[65]);
#include "bounded-sha256.h"
#include "session-lifetime.h"
#include "overlay.h"
#include "camera-probe.h"
#include "world-probe.h"
#ifdef HOST_GROUND_OBSERVER
#include "host-ground-observer.h"
#endif
#ifdef SR1_NATIVE_POSE_OBSERVER
#include "sr1-native-pose-observer.h"
#endif
#ifdef SR1_NATIVE_SKELETON_ADAPTER
static bool sr1SkeletonGuidanceLease(uint32_t *,uint64_t *,uint64_t *);
#include "sr1-skeleton-adapter.h"
#endif
#include "session-runtime.h"
static void lightDrawObserve(GLenum mode,GLsizei count,GLenum type,const void *indices);
static bool lightDrawReplace(GLenum mode,GLsizei count,GLenum type,const void *indices);
#include "draw-probe.h"
#include "reaver-function-bytes.h"
#include "reaver-probe.h"
#include "shader-probe.h"
#include "light-probe.h"
#include "light-replace.h"
#include "ribbon-code-proof.h"
#include "ribbon-replace.h"
#include "ribbon-replace-test.h"
#include "recording-status.h"
#include "sr1-input-probe.h"
#include "physics-probe.h"
#include "motion-probe.h"
#include "startup-probe.h"
#include "instant-root.h"
#ifdef SR1_NATIVE_GROUND_DRIVER
#include "sr1-skeleton-ground-driver.h"
#endif
#include "evade-root.h"
#include "direct-host.h"
#include "host-camera-authority.h"
#include "recording-indicator.h"
#include "guidance.h"
#ifdef SR1_NATIVE_SKELETON_ADAPTER
#include "sr1-weapon-guidance.h"
static SRWLOCK sr1SkeletonGuidanceLock=SRWLOCK_INIT;
static Sr1WeaponGuidance sr1SkeletonGuidance;
static uint64_t sr1SkeletonGuidancePoll;
static bool sr1SkeletonLeaseFile(const wchar_t *path,void *out,DWORD bytes,bool *missing,bool *invalid){
 HANDLE f=CreateFileW(path,GENERIC_READ,FILE_SHARE_READ|FILE_SHARE_WRITE|FILE_SHARE_DELETE,NULL,OPEN_EXISTING,FILE_ATTRIBUTE_NORMAL,NULL);
 if(f==INVALID_HANDLE_VALUE){DWORD error=GetLastError();*missing|=error==ERROR_FILE_NOT_FOUND||error==ERROR_PATH_NOT_FOUND;return false;}
 LARGE_INTEGER size;DWORD count=0;bool ok=GetFileSizeEx(f,&size)!=0;
 if(ok&&size.QuadPart!=bytes){*invalid=true;ok=false;}
 if(ok)ok=ReadFile(f,out,bytes,&count,NULL)&&count==bytes;
 CloseHandle(f);return ok;
}
// Reuse the existing exact HUD descriptor+heartbeat validation. The visibility
// owner pins this identity separately; body/source freshness cannot toggle it.
static bool sr1SkeletonGuidanceLease(uint32_t *writer,uint64_t *session,uint64_t *begin){
 if(!writer||!session||!begin||(guidanceSeconds(13)!=100&&guidanceSeconds(13)!=120&&guidanceSeconds(13)!=170))return false;
 AcquireSRWLockExclusive(&sr1SkeletonGuidanceLock);
 uint64_t now=GetTickCount64();bool active=guidanceRefresh();
 Sr1WeaponGuidanceObservation o={.pid=GetCurrentProcessId(),.now=now,.hudActive=active,.hudPlan=guidancePlan,.hudWriter=guidanceWriter,.hudSession=guidanceSession,.hudBegin=guidanceBegin};
 wchar_t statusPath[512],descriptorPath[512];recordingStatusPath(statusPath,o.pid);_snwprintf(descriptorPath,512,PROBE_PATH(L"\\guidance-%lu.bin"),o.pid);
 const wchar_t *paths[]={statusPath,descriptorPath};for(unsigned i=0;i<2;i++)if(GetFileAttributesW(paths[i])==INVALID_FILE_ATTRIBUTES){DWORD e=GetLastError();o.missing|=e==ERROR_FILE_NOT_FOUND||e==ERROR_PATH_NOT_FOUND;}
 if(!sr1SkeletonGuidancePoll||now<sr1SkeletonGuidancePoll||now-sr1SkeletonGuidancePoll>=100){
  sr1SkeletonGuidancePoll=now;
  o.descriptorRead=sr1SkeletonLeaseFile(descriptorPath,&o.descriptor,sizeof(o.descriptor),&o.missing,&o.invalidShape);
  o.statusRead=sr1SkeletonLeaseFile(statusPath,&o.status,sizeof(o.status),&o.missing,&o.invalidShape);
 }
 bool allowed=sr1WeaponGuidanceStep(&sr1SkeletonGuidance,&o);
 if(allowed){*writer=sr1SkeletonGuidance.writer;*session=sr1SkeletonGuidance.session;*begin=sr1SkeletonGuidance.begin;}
 ReleaseSRWLockExclusive(&sr1SkeletonGuidanceLock);return allowed;
}
#endif
#include "guidance-present.h"
#include "input-probe.h"
#include "background-input.h"
#include "donor-process-probe.h"
#include "donor-message-lifecycle.h"
#ifdef FIRST_BLOCK_PILOT
#include "first-block-runtime.h"
#endif
#ifdef DONOR_ANIMATION_STEP_OBSERVER
#include "donor-animation-step-lifecycle.h"
#endif
#ifdef DONOR_CONTROL_QUERY_OBSERVER
#include "donor-control-query-lifecycle.h"
#endif
#ifdef DONOR_BLOCK_INITIALIZATION_OBSERVER
#include "donor-block-initialization-lifecycle.h"
#endif
#ifdef DONOR_BLOCK_MOTION_OBSERVER
#include "donor-block-motion-lifecycle.h"
#endif
#ifdef DONOR_INITIALIZATION_OBSERVER
#include "donor-initialization-lifecycle.h"
#endif
#ifdef HOST_NATIVE_ENQUEUE_OBSERVER
#include "host-enqueue-lifecycle.h"
#endif
#ifdef HOST_NATIVE_TRANSITION_OBSERVER
#ifdef HOST_NATIVE_ENQUEUE_OBSERVER
#error Select one host diagnostic observer per build
#endif
#include "host-transition-lifecycle.h"
#endif
#ifdef DONOR_ANIMATION_CALL_OBSERVER
#include "donor-animation-call-lifecycle.h"
#endif
#ifdef DONOR_ANIMATION_MARKER_OBSERVER
#ifndef DONOR_ANIMATION_CALL_OBSERVER
#error Marker observer requires the original selector observer
#endif
#include "donor-animation-marker-lifecycle.h"
#endif
#include "donor-animation-probe.h"
#ifdef DONOR_CONTACT_RUNTIME
#include "donor-contact-runtime.h"
#include "donor-contact-frame-owner.h"
#endif
#ifdef HOST_LED_HEADING
#include "donor-host-heading.h"
#endif
#include "donor-anchor.h"
#include "direct-motion-source.h"
#ifdef SR1_COMBAT_TRAVEL
#include "combat-travel-source.h"
#endif
static BOOL WINAPI countSwap(HDC dc) {
#ifdef SR1_REAVER_PRESENTATION
    reaverHostPresentationFlush(dc);
#endif
    InterlockedIncrement64(&swapCalls);
    HGLRC context=wglGetCurrentContext();
    if(InterlockedCompareExchange(&probeBoundedComplete,0,0)){
        if(wglGetCurrentDC()==dc){indicatorDraw(context);guidanceDraw(context);}
        return originalSwap(dc);
    }
    if(context && context!=loggedContext && contextLogs<8) {
        loggedContext=context; ++contextLogs;
        const char *version=(const char *)glGetString(GL_VERSION);
        GLint viewport[4]={0}; glGetIntegerv(GL_VIEWPORT,viewport);
        int major=0,minor=0; if(version) sscanf(version,"%d.%d",&major,&minor);
        GLint program=0,vao=0,fbo=0,profile=0;
        if(major>=2) glGetIntegerv(0x8b8d,&program);
        if(major>=3) { glGetIntegerv(0x85b5,&vao); glGetIntegerv(0x8ca6,&fbo); }
        if(major>3 || (major==3 && minor>=2)) glGetIntegerv(0x9126,&profile);
        logLine("GL_CONTEXT context=%p dc_matches=%d version=%s vendor=%s renderer=%s viewport=%d,%d,%d,%d profile=%d program=%d vao=%d draw_fbo=%d depth=%d blend=%d",
            (void *)context,wglGetCurrentDC()==dc,version?version:"unknown",glGetString(GL_VENDOR),glGetString(GL_RENDERER),
            viewport[0],viewport[1],viewport[2],viewport[3],profile,program,vao,fbo,glIsEnabled(GL_DEPTH_TEST),glIsEnabled(GL_BLEND));
    }
    if(wglGetCurrentDC()==dc) { if(!sessionRuntimeHealthy()){worldLastDraw=0;overlayLiveTick=0;overlayAirSupport=false;}overlayDraw(context); cameraObserve(context); lightObserve(context); lightDrawArm(context);
#if !defined(SR1_RETARGET_PREVIEW) && !defined(SR1_NATIVE_SKELETON_ADAPTER)
    worldDraw(context);
#elif defined(SR1_NATIVE_SKELETON_ADAPTER)
    (void)worldDraw; // Legacy symbol retained for macro-off compatibility; never invoked here.
#endif
    drawArm(context); lightReplaceArm(context); indicatorDraw(context); }
    if(wglGetCurrentDC()==dc)guidanceDraw(context);
    return originalSwap(dc);
}
static bool __cdecl countPoll(void *event) {
    InterlockedIncrement64(&pollCalls);
    bool result=originalPoll(event);
    inputObserve();
    return result;
}

// Caller supplies readable buffers. Includes the final possible starting offset.
static size_t scan(const unsigned char *data, size_t length, const char *pattern, size_t *first) {
    unsigned char bytes[256], mask[256]; size_t n = 0;
    const char *p = pattern;
    while (*p) {
        while (*p == ' ') ++p;
        if (!*p) break;
        if (n == sizeof(bytes)) return 0;
        if (*p == '?') { bytes[n] = 0; mask[n++] = 0; while (*p == '?') ++p; }
        else {
            unsigned int value; int consumed = 0;
            if (sscanf(p, "%2x%n", &value, &consumed) != 1 || consumed != 2) return 0;
            bytes[n] = (unsigned char)value; mask[n++] = 1; p += consumed;
        }
        if (*p && *p != ' ') return 0;
    }
    if (!n || length < n) return 0;
    size_t count = 0;
    for (size_t i = 0; i <= length - n; ++i) {
        bool equal = true;
        for (size_t j = 0; j < n; ++j) if (mask[j] && data[i+j] != bytes[j]) { equal = false; break; }
        if (equal) { if (!count && first) *first = i; ++count; }
    }
    return count;
}
static bool hashFile(const wchar_t *file, char output[65]) {
    HANDLE h = CreateFileW(file, GENERIC_READ, FILE_SHARE_READ | FILE_SHARE_WRITE | FILE_SHARE_DELETE,
        NULL, OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, NULL);
    if (h == INVALID_HANDLE_VALUE) return false;
    BCRYPT_ALG_HANDLE alg = NULL; BCRYPT_HASH_HANDLE hash = NULL;
    unsigned char digest[32], buffer[65536]; DWORD read = 0; bool ok = false;
    if (BCryptOpenAlgorithmProvider(&alg, BCRYPT_SHA256_ALGORITHM, NULL, 0) < 0) goto done;
    if (BCryptCreateHash(alg, &hash, NULL, 0, NULL, 0, 0) < 0) goto done;
    for (;;) {
        if (!ReadFile(h, buffer, sizeof(buffer), &read, NULL)) goto done;
        if (!read) break;
        if (BCryptHashData(hash, buffer, read, 0) < 0) goto done;
    }
    if (BCryptFinishHash(hash, digest, sizeof(digest), 0) < 0) goto done;
    for (int i = 0; i < 32; ++i) sprintf(output + i * 2, "%02x", digest[i]);
    output[64] = 0; ok = true;
done:
    if (hash) BCryptDestroyHash(hash);
    if (alg) BCryptCloseAlgorithmProvider(alg, 0);
    CloseHandle(h); return ok;
}
static bool hashBytes(const void *data,ULONG length,char output[65]) {
    return boundedSha256(data,length,65536,output);
}
static bool knownModule(HMODULE module, const wchar_t *name) {
    wchar_t file[32768]; char hash[65];
    if (!GetModuleFileNameW(module, file, ARRAYSIZE(file)) || !hashFile(file, hash)) return false;
    for (size_t i = 0; i < ARRAYSIZE(profiles); ++i) {
        if (!_wcsicmp(name, profiles[i].name)) {
            bool match = !strcmp(hash, profiles[i].sha256);
            logLine("MODULE %ls base=%p sha256=%s supported=%d", name, (void *)module, hash, match);
            return match;
        }
    }
    return false;
}
static IMAGE_NT_HEADERS64 *ntHeaders(HMODULE module) {
    IMAGE_DOS_HEADER *dos = (IMAGE_DOS_HEADER *)module;
    if (dos->e_magic != IMAGE_DOS_SIGNATURE || dos->e_lfanew <= 0 || dos->e_lfanew > 0x100000) return NULL;
    IMAGE_NT_HEADERS64 *nt = (IMAGE_NT_HEADERS64 *)((unsigned char *)module + dos->e_lfanew);
    if (nt->Signature != IMAGE_NT_SIGNATURE || nt->OptionalHeader.Magic != IMAGE_NT_OPTIONAL_HDR64_MAGIC) return NULL;
    return nt;
}
static bool replaceSlot(PVOID *slot, PVOID expected, PVOID replacement) {
    DWORD oldProtect;
    if (!VirtualProtect(slot, sizeof(*slot), PAGE_READWRITE, &oldProtect)) return false;
    PVOID previous = InterlockedCompareExchangePointer(slot, replacement, expected);
    DWORD ignored;
    bool restoredProtection = VirtualProtect(slot, sizeof(*slot), oldProtect, &ignored) != 0;
    if (!restoredProtection) logLine("ERROR restoring IAT page protection error=%lu", GetLastError());
    return previous == expected;
}
static bool installIAT(HMODULE module, const char *dll, const char *symbol, PVOID replacement, PVOID *original) {
    IMAGE_NT_HEADERS64 *nt = ntHeaders(module);
    if (!nt) return false;
    DWORD rva = nt->OptionalHeader.DataDirectory[IMAGE_DIRECTORY_ENTRY_IMPORT].VirtualAddress;
    if (!rva) return false;
    unsigned char *base = (unsigned char *)module;
    IMAGE_IMPORT_DESCRIPTOR *desc = (IMAGE_IMPORT_DESCRIPTOR *)(base + rva);
    for (; desc->Name; ++desc) {
        if (_stricmp((const char *)(base + desc->Name), dll)) continue;
        if (!desc->OriginalFirstThunk) return false;
        IMAGE_THUNK_DATA64 *names = (IMAGE_THUNK_DATA64 *)(base + desc->OriginalFirstThunk);
        IMAGE_THUNK_DATA64 *iat = (IMAGE_THUNK_DATA64 *)(base + desc->FirstThunk);
        for (; names->u1.AddressOfData; ++names, ++iat) {
            if (IMAGE_SNAP_BY_ORDINAL64(names->u1.Ordinal)) continue;
            IMAGE_IMPORT_BY_NAME *import = (IMAGE_IMPORT_BY_NAME *)(base + names->u1.AddressOfData);
            if (strcmp((const char *)import->Name, symbol)) continue;
            PVOID expected = (PVOID)(uintptr_t)iat->u1.Function;
            HMODULE provider = GetModuleHandleA(dll);
            // Refuse to replace another mod's hook or a missing API.
            if (!provider || expected != (PVOID)GetProcAddress(provider, symbol)) return false;
            *original = expected; // Publish before the game can enter the wrapper.
            PVOID *slot = (PVOID *)&iat->u1.Function;
            if (!replaceSlot(slot, expected, replacement)) return false;
            patchedSlot = slot; originalTarget = expected; hookTarget = replacement;
            logLine("IAT_COUNTER %s!%s installed", dll, symbol);
            return true;
        }
    }
    return false;
}
static bool installDrawObserver(HMODULE module) {
    PVOID *previousSlot=patchedSlot;PVOID previousTarget=originalTarget,previousHook=hookTarget;
    bool installed=installIAT(module,"OPENGL32.dll","glDrawElements",(PVOID)&observeDraw,(PVOID *)&originalDraw);
    if(installed)drawSlot=patchedSlot;
    patchedSlot=previousSlot;originalTarget=previousTarget;hookTarget=previousHook;
    return installed;
}
static void logSignatures(HMODULE module) {
    IMAGE_NT_HEADERS64 *nt = ntHeaders(module);
    if (!nt) return;
    IMAGE_SECTION_HEADER *s = IMAGE_FIRST_SECTION(nt);
    for (unsigned int i = 0; i < nt->FileHeader.NumberOfSections; ++i) {
        if (memcmp(s[i].Name, ".text\0", 6)) continue;
        unsigned char *text = (unsigned char *)module + s[i].VirtualAddress;
        size_t length = s[i].Misc.VirtualSize;
        for (size_t j = 0; j < ARRAYSIZE(signatures); ++j) {
            size_t first = 0;
            size_t count = scan(text, length, signatures[j].pattern, &first);
            logLine("SIGNATURE %s matches=%zu rva=0x%zx", signatures[j].name, count, count ? s[i].VirtualAddress + first : 0);
            if (!strcmp(signatures[j].name, "CharInit") && count == 1) charTarget = text + first;
        }
    }
}
static void logCharacterEvent(LONG64 *lastSequence) {
    CharEvent event;
    if (InterlockedCompareExchange(&eventLock, 1, 0)) return;
    event = latestCharEvent;
    InterlockedExchange(&eventLock, 0);
    if (!event.sequence || event.sequence == *lastSequence) return;
    *lastSequence = event.sequence;
    logLine("CHAR_INIT_OBSERVATION sequence=%lld args=%p,%p,%p result=%p; NOT identified as player controller",
        event.sequence, (void *)(uintptr_t)event.args[0], (void *)(uintptr_t)event.args[1],
        (void *)(uintptr_t)event.args[2], (void *)(uintptr_t)event.result);
    for (int i = 0; i < 3; ++i) {
        char text[129];
        for (SIZE_T j = 0; j < event.readable[i]; ++j) sprintf(text + j * 2, "%02x", event.prefix[i][j]);
        text[event.readable[i] * 2] = 0;
        logLine("CHAR_ARG%d readable=%zu prefix=%s", i + 1, (size_t)event.readable[i], text);
    }
}
static void logModules(void) {
    HANDLE snapshot = CreateToolhelp32Snapshot(TH32CS_SNAPMODULE, GetCurrentProcessId());
    if (snapshot == INVALID_HANDLE_VALUE) return;
    MODULEENTRY32W entry = {0}; entry.dwSize = sizeof(entry);
    if (Module32FirstW(snapshot, &entry)) do {
        if (!_wcsicmp(entry.szModule, L"sr1.dll") || !_wcsicmp(entry.szModule, L"sr2.dll")) {
            bool match=knownModule(entry.hModule, entry.szModule);
            if(!_wcsicmp(entry.szModule,L"sr1.dll")) {
                InterlockedExchangePointer(&verifiedSr1Module,match?entry.hModule:NULL);
#ifdef HOST_GROUND_OBSERVER
                if(match)hostGroundInstall(entry.hModule);
#endif
#ifdef SR1_NATIVE_POSE_OBSERVER
                if(match)sr1NativePoseInstall(entry.hModule);
#endif
#ifdef SR1_NATIVE_SKELETON_ADAPTER
                if(match)sr1SkeletonInstall(entry.hModule);
#endif
#ifdef HOST_NATIVE_ENQUEUE_OBSERVER
                if(match)hostEnqueueInstall(entry.hModule);
#endif
#ifdef HOST_NATIVE_TRANSITION_OBSERVER
                if(match)hostTransitionInstall(entry.hModule);
#endif
                if(match){reaverInstall(entry.hModule);ribbonInstall(entry.hModule);physicsInstall(entry.hModule);motionInstall(entry.hModule);startupInstall(entry.hModule);instantRootInstall(entry.hModule);evadeInstall(entry.hModule);directHostInstall();hostCameraInstall(entry.hModule);}
            }
        }
        else if (!_wcsicmp(entry.szModule, L"d3d11.dll") || !_wcsicmp(entry.szModule, L"dxgi.dll") ||
                 !_wcsicmp(entry.szModule, L"opengl32.dll") || !_wcsicmp(entry.szModule, L"SDL3.dll"))
            logLine("DEPENDENCY %ls base=%p", entry.szModule, (void *)entry.hModule);
    } while (Module32NextW(snapshot, &entry));
    CloseHandle(snapshot);
}
// Called by ASI loader after LoadLibrary, outside the loader lock.
#ifdef SR1_DUAL_INPUT
#include "dual-input-runtime.h"
#endif
static DWORD WINAPI worker(LPVOID unused) {
    (void)unused;
    wchar_t exe[32768]; GetModuleFileNameW(NULL, exe, ARRAYSIZE(exe));
    const wchar_t *name = wcsrchr(exe, L'\\'); name = name ? name + 1 : exe;
    CreateDirectoryW(PROBE_REPORT_DIR, NULL);
    wchar_t file[32768];
    _snwprintf(file, ARRAYSIZE(file), L"%ls\\%ls-%lu.log", PROBE_REPORT_DIR, name, GetCurrentProcessId());
    logFile = _wfopen(file, L"wb");
    if (!logFile) return 1;
    logLine("LOKProbe v0.3 pid=%lu executable=%ls", GetCurrentProcessId(), name);
    logLine("SHEETS source_sha256=%s; generated active records", EXPLORATION_SHEET_SHA256);
    logLine("CAPABILITIES gameplay=0 character_state=0 presentation_counter=0 input_poll_counter=0");
    HMODULE module = GetModuleHandleW(NULL);
    bool supported = knownModule(module, name);
    if (!supported) { logLine("UNSUPPORTED_BUILD counters disabled"); closeLog(); return 2; }
    // This module must stay loaded: a thread might still be inside a counter on shutdown.
    HMODULE pinned;
    if (!GetModuleHandleExW(GET_MODULE_HANDLE_EX_FLAG_FROM_ADDRESS | GET_MODULE_HANDLE_EX_FLAG_PIN,
                           (LPCWSTR)(uintptr_t)&worker, &pinned)) {
        logLine("ERROR pinning probe"); closeLog(); return 3;
    }
    if (!_wcsicmp(name, L"defiance.exe")) {
        logSignatures(module);
        if (charTarget) {
            MH_STATUS init = MH_Initialize();
            MH_STATUS create = init == MH_OK ? MH_CreateHook(charTarget, (PVOID)&observeChar, (PVOID *)&originalChar) : init;
            MH_STATUS enable = create == MH_OK ? MH_EnableHook(charTarget) : create;
            logLine("CHAR_INIT_OBSERVER init=%d create=%d enable=%d", init, create, enable);
            if (enable != MH_OK) charTarget = NULL;
        }
        inputInit();
        backgroundInit();
#ifdef FIRST_BLOCK_PILOT
        // The pilot owns the inner156EA0 frame. Leave157170 unhooked so its
        // exact native call return remains verifiable (no relocated caller).
        donorProcessBase=(uintptr_t)module;(void)donorProcessInstall;
#else
        donorProcessInstall(module);
#endif
#ifdef DONOR_BLOCK_INITIALIZATION_OBSERVER
        logLine("CAPABILITY donor_block_initialization_observation=%d; original subtype1 boundary only, no synthetic calls",donorBlockInitializationInstall(module));
#endif
#ifdef DONOR_INITIALIZATION_OBSERVER
        logLine("CAPABILITY donor_initialization_observation=%d; original one-argument calls, no synthetic calls",donorInitializationInstall(module));
#endif
        logLine("CAPABILITY donor_message_observation=%d; forwarding-only scalar metadata, no gameplay commands",donorMessageInstall(module));
#ifdef FIRST_BLOCK_PILOT
        logLine("CAPABILITY first_block_pilot=%d; scoped original input route, host object authority, gameplay acceptance pending",firstBlockInstall());
#endif
#ifdef DONOR_ANIMATION_STEP_OBSERVER
        logLine("CAPABILITY donor_animation_step_observation=%d; original float steps only, no commands",donorAnimationStepInstall());
#endif
#ifdef DONOR_CONTROL_QUERY_OBSERVER
        logLine("CAPABILITY donor_control_query_observation=%d; original logical0x45/0x49 results, no input override",donorControlQueryInstall());
#endif
#ifdef DONOR_BLOCK_MOTION_OBSERVER
        logLine("CAPABILITY donor_block_motion_observation=%d; original one-argument target helpers, no synthetic calls",donorBlockMotionInstall());
#endif
#ifdef DONOR_ANIMATION_CALL_OBSERVER
        logLine("CAPABILITY donor_animation_call_observation=%d; original native calls only",donorAnimationCallInstall());
#endif
#ifdef DONOR_ANIMATION_MARKER_OBSERVER
        logLine("CAPABILITY donor_animation_marker_observation=%d; original callbacks only, opaque payloads",donorAnimationMarkerInstall());
#endif
#ifdef DONOR_CONTACT_RUNTIME
        // Both observers target 1560d0. The bounded contact build owns it
        // exclusively; installing the older observer first alters the proof
        // bytes and prevents contact admission. Other builds retain it.
        (void)donorAnimationInstall;
        logLine("CAPABILITY donor_contact_hooks=%d; activation requires owning frame admission",donorContactRuntimeInstall(module));
#else
        donorAnimationInstall(module);
#endif
        donorAnchorInstall(module);
        donorAnchorMotionSample=directMotionSample;
#ifdef SR1_COMBAT_TRAVEL
        donorAnchorMotionSample=combatTravelSample;
#endif
        bool installed = installIAT(module, "SDL3.dll", "SDL_PollEvent", (PVOID)&countPoll, (PVOID *)&originalPoll);
        logLine("CAPABILITY input_poll_counter=%d; polls are NOT simulation ticks", installed);
        logLine("CAPABILITY native_donor_guidance=%d; actual presentation/visibility proof required",guidancePresentInstall());
    } else if (!_wcsicmp(name, L"SRX.exe")) {
        renderMemoryAlternateCopy=sessionRuntimeCopy;renderMemoryAlternateIsActive=sessionRuntimeRequested;renderMemoryAlternateReady=sessionRuntimeHealthy;movementReadPacket=sessionRuntimeMovement;
        sessionRuntimeThread=CreateThread(NULL,0,sessionRuntimeWorker,NULL,0,NULL);
        bool installed = installIAT(module, "GDI32.dll", "SwapBuffers", (PVOID)&countSwap, (PVOID *)&originalSwap);
        logLine("CAPABILITY presentation_counter=%d; presents are NOT simulation ticks", installed);
        drawInit();
        srInputInstall();
        if(drawFile)logLine("DRAW_OBSERVER installed=%d; all draws forwarded unchanged",installDrawObserver(module));
    }
    logModules();
    sessionBudgetExtended=lifetimeBudgetStatus;
    LONG64 lastSwap = 0, lastPoll = 0;
    LONG64 lastSequence = 0;
    for (int second = 1; second <= 600 || lifetimeRequested(); ++second) {
        Sleep(1000);
        lifetimePoll();
        LONG64 s = InterlockedCompareExchange64(&swapCalls, 0, 0);
        LONG64 p = InterlockedCompareExchange64(&pollCalls, 0, 0);
        logLine("COUNTERS second=%d swap_total=%lld swap_delta=%lld poll_total=%lld poll_delta=%lld", second, s, s-lastSwap, p, p-lastPoll);
        lastSwap = s; lastPoll = p;
        logCharacterEvent(&lastSequence);
#ifdef SR1_DUAL_INPUT
        dualInputTick(!_wcsicmp(name,L"SRX.exe"),(uintptr_t)module);
#endif
        reaverLog();
#ifdef HOST_GROUND_OBSERVER
        if(!_wcsicmp(name,L"SRX.exe"))hostGroundTick();
#endif
        if(!_wcsicmp(name,L"SRX.exe")){srInputInstall();srInputTick();physicsTick();motionTick();startupTick();instantRootTick();evadeTick();directHostTick();}
#ifdef SR1_NATIVE_GROUND_DRIVER
        if(!_wcsicmp(name,L"SRX.exe"))sr1GroundTick();
#endif
#ifdef SR1_NATIVE_POSE_OBSERVER
        if(!_wcsicmp(name,L"SRX.exe"))sr1NativePoseTick();
#endif
#ifdef SR1_NATIVE_SKELETON_ADAPTER
        if(!_wcsicmp(name,L"SRX.exe"))sr1SkeletonTick();
#endif
        if(!_wcsicmp(name,L"defiance.exe")){donorProcessTick();donorAnimationTick();donorAnchorTick();directMotionSourceTick();
#ifdef DONOR_CONTACT_RUNTIME
            donorContactOwnerTick();
#endif
#ifdef SR1_COMBAT_TRAVEL
combatTravelSourceTick();
#endif
}
#ifdef FIRST_BLOCK_PILOT
        if(!_wcsicmp(name,L"defiance.exe"))firstBlockTick();
#endif
#ifdef DONOR_INITIALIZATION_OBSERVER
        if(!_wcsicmp(name,L"defiance.exe"))donorInitializationTick();
#endif
#ifdef DONOR_BLOCK_INITIALIZATION_OBSERVER
        if(!_wcsicmp(name,L"defiance.exe"))donorBlockInitializationTick();
#endif
        ribbonLog();
        inputFlush();
        drawFlush();
        worldGateFlush();
        lightDrawFlush();
        shaderFlush();
        lightReplaceLog();
        backgroundTick(GetFileAttributesW(PROBE_PATH(L"\\defiance-background.enable"))!=INVALID_FILE_ATTRIBUTES&&(!lifetimeRequested()||lifetimeBudgetStatus(GetTickCount64())==1));
        if (second % 10 == 0) logModules();
    }
    InterlockedExchange(&probeBoundedComplete,1);
#ifdef HOST_GROUND_OBSERVER
    hostGroundStop();
#endif
#ifdef SR1_NATIVE_POSE_OBSERVER
    sr1NativePoseStop();
#endif
#ifdef SR1_NATIVE_SKELETON_ADAPTER
    sr1SkeletonStop();
#ifdef SR1_NATIVE_GROUND_DRIVER
    sr1GroundStop();
#endif
#endif
    InterlockedExchange(&sessionRuntimeStopRequested,1);
    if(sessionRuntimeThread){WaitForSingleObject(sessionRuntimeThread,5000);CloseHandle(sessionRuntimeThread);sessionRuntimeThread=NULL;}
    if (patchedSlot && _wcsicmp(name,L"SRX.exe")) {
        bool restored = replaceSlot(patchedSlot, hookTarget, originalTarget);
        logLine("IAT_COUNTER restored=%d", restored);
    }
    else if(patchedSlot)logLine("IAT_COUNTER diagnostic probes ended; presentation forwarding retained for optional recording indicator only");
    if(drawSlot)logLine("DRAW_OBSERVER restored=%d drops=%ld",replaceSlot(drawSlot,(PVOID)&observeDraw,(PVOID)originalDraw),InterlockedCompareExchange(&drawDrops,0,0));
    drawFlush();
    lightDrawFlush();
    shaderFlush();
    if (charTarget) {
        MH_STATUS status = MH_DisableHook(charTarget);
        logLine("CHAR_INIT_OBSERVER disabled=%d calls=%lld dropped=%lld", status == MH_OK,
            InterlockedCompareExchange64(&charCalls, 0, 0), InterlockedCompareExchange64(&droppedEvents, 0, 0));
        // Keep trampolines alive for any in-flight callback until process termination.
    }
    InterlockedExchange(&reaverHideEnabled,0);
    ribbonStop();
#ifdef HOST_NATIVE_ENQUEUE_OBSERVER
    hostEnqueueStop();
#endif
#ifdef HOST_NATIVE_TRANSITION_OBSERVER
    hostTransitionStop();
#endif
#ifdef SR1_DUAL_INPUT
    dualInputStop();
#endif
    srInputStop();
    physicsStop();
    motionStop();
    startupStop();
    instantRootStop();
    evadeStop();
    directHostStop();
    hostCameraStop();
    donorProcessStop();
#ifdef FIRST_BLOCK_PILOT
    firstBlockStop();
#endif
#ifdef DONOR_INITIALIZATION_OBSERVER
    donorInitializationStop();
#endif
#ifdef DONOR_BLOCK_INITIALIZATION_OBSERVER
    donorBlockInitializationStop();
#endif
#ifdef DONOR_CONTROL_QUERY_OBSERVER
    donorControlQueryStop();
#endif
#ifdef DONOR_ANIMATION_STEP_OBSERVER
    donorAnimationStepStop();
#endif
#ifdef DONOR_ANIMATION_MARKER_OBSERVER
    donorAnimationMarkerStop();
#endif
#ifdef DONOR_ANIMATION_CALL_OBSERVER
    donorAnimationCallStop();
#endif
#ifdef DONOR_BLOCK_MOTION_OBSERVER
    donorBlockMotionStop();
#endif
    donorMessageStop();
    donorAnimationStop();
#ifdef DONOR_CONTACT_RUNTIME
    if(donorContactOwnerStop())donorContactRuntimeStop();
#endif
    donorAnchorStop();
    directMotionSourceStop();
    if(reaverTarget)logLine("REAVER_OBSERVER disabled=%d calls=%lld drops=%lld",MH_DisableHook(reaverTarget)==MH_OK,InterlockedCompareExchange64(&reaverCalls,0,0),InterlockedCompareExchange64(&reaverDrops,0,0));
    backgroundRestore();
    lifetimeClose();
    inputFlush();
    logLine("INPUT dropped_samples=%ld",InterlockedCompareExchange(&inputDrops,0,0));
    logLine("COMPLETE bounded observation ended; gameplay remained disabled");
    closeLog();
    return 0;
}
static bool mockIndexReadFail;
static unsigned char mockIndexData[216000];
static void APIENTRY mockIndexSize(GLenum target,GLenum parameter,GLint *value) {
    (void)target;(void)parameter;*value=sizeof(mockIndexData);
}
static void APIENTRY mockIndexRead(GLenum target,GLintptr offset,GLsizeiptr size,void *out) {
    (void)target;if(!mockIndexReadFail)memcpy(out,mockIndexData+(size_t)offset,(size_t)size);
}
static int mockLightSize=4,mockLightReads;
static bool mockLightReadFail;
static GLboolean APIENTRY mockLightProgram(GLuint program) {return program==1;}
static void APIENTRY mockLightProgramiv(GLuint program,GLenum field,GLint *value) {(void)program;(void)field;*value=1;}
static void APIENTRY mockLightActive(GLuint program,GLuint index,GLsizei cap,GLsizei *length,GLint *size,GLenum *type,GLchar *name) {
    (void)program;(void)index;(void)cap;strcpy(name,"uLightPos[0]");*length=12;*size=mockLightSize;*type=GL_FLOAT_VEC4;
}
static void APIENTRY mockLightBlock(GLuint program,GLsizei count,const GLuint *indices,GLenum field,GLint *value) {(void)program;(void)count;(void)indices;(void)field;*value=-1;}
static GLint APIENTRY mockLightLocation(GLuint program,const GLchar *name) {(void)program;return 100+(name[10]-'0')*7;}
static void APIENTRY mockLightValues(GLuint program,GLint location,GLfloat *values) {(void)program;++mockLightReads;if(!mockLightReadFail)for(int i=0;i<4;++i)values[i]=(float)(((location-100)/7)*4+i+1);}
static bool testLightReads(void) {
    cglIsProgram=mockLightProgram;pglGetProgramiv=mockLightProgramiv;cglGetActiveUniform=mockLightActive;
    cglGetActiveUniformsiv=mockLightBlock;pglGetUniformLocation=mockLightLocation;cglGetUniformfv=mockLightValues;
    LightField field={0};field.program=1;field.block=-1;field.count=4;strcpy(field.name,"uLightPos[0]");float values[16];
    bool ok=lightRead(&field,values)&&mockLightReads==4&&values[0]==1&&values[15]==16;
    mockLightSize=1;ok=ok&&!lightRead(&field,values)&&mockLightReads==4;
    field.count=1;ok=ok&&lightRead(&field,values)&&mockLightReads==5&&values[0]==1&&values[4]==0;
    field.count=4;mockLightSize=4;
    mockLightReadFail=true;ok=ok&&!lightRead(&field,values);mockLightReadFail=false;
    field.program=2;ok=ok&&!lightRead(&field,values);
    cglIsProgram=NULL;pglGetProgramiv=NULL;cglGetActiveUniform=NULL;cglGetActiveUniformsiv=NULL;pglGetUniformLocation=NULL;cglGetUniformfv=NULL;
    return ok;
}
static GLint mockShaderSize=32,mockShaderType=GL_FRAGMENT_SHADER;
static int mockShaderMode,mockShaderReads;
static void APIENTRY mockShaderIv(GLuint shader,GLenum field,GLint *value) {(void)shader;*value=field==GL_SHADER_SOURCE_LENGTH?mockShaderSize:mockShaderType;}
static void APIENTRY mockShaderSource(GLuint shader,GLsizei size,GLsizei *length,GLchar *source) {
    (void)shader;++mockShaderReads;
    if(mockShaderMode==1){*length=size;return;}
    memcpy(source,"void main(){}",13);*length=13;
    if(mockShaderMode==2)source[4]=0;
}
static bool testShaderReads(void) {
    ShaderRecord record={0};
    bool ok=!shaderRead(1,2,&record);
    shaderQuery=mockShaderIv;shaderSource=mockShaderSource;shaderReady=true;
    ok=ok&&shaderRead(1,2,&record)&&record.length==13&&!strcmp(record.source,"void main(){}");
    if(record.source)HeapFree(GetProcessHeap(),0,record.source);record.source=NULL;
    mockShaderSize=65537;ok=ok&&!shaderRead(1,2,&record)&&mockShaderReads==1;
    mockShaderSize=0;ok=ok&&!shaderRead(1,2,&record)&&mockShaderReads==1;
    mockShaderSize=32;mockShaderMode=1;ok=ok&&!shaderRead(1,2,&record);
    mockShaderMode=2;ok=ok&&!shaderRead(1,2,&record);
    mockShaderMode=0;mockShaderType=0;ok=ok&&!shaderRead(1,2,&record);
    shaderQuery=NULL;shaderSource=NULL;shaderReady=false;mockShaderType=GL_FRAGMENT_SHADER;
    return ok;
}
static float mockUniformState[4];
static int mockUniformWrites,mockUniformDrawCalls,mockUniformFailure;
static bool mockUniformDrawValid;
static void APIENTRY mockUniformSet(GLint location,GLsizei count,const GLfloat *value) {
    ++mockUniformWrites;if(location!=7||count!=1)return;
    if((mockUniformFailure==1&&mockUniformWrites==1)||(mockUniformFailure==2&&mockUniformWrites==2))return;
    memcpy(mockUniformState,value,sizeof(mockUniformState));
}
static void APIENTRY mockUniformGet(GLuint program,GLint location,GLfloat *value) {if(program==1&&location==7)memcpy(value,mockUniformState,sizeof(mockUniformState));}
static void WINAPI mockUniformDraw(GLenum mode,GLsizei count,GLenum type,const void *indices) {
    ++mockUniformDrawCalls;const float zero[4]={0};mockUniformDrawValid=mode==GL_TRIANGLES&&count==9&&type==GL_UNSIGNED_INT&&indices==(void *)(uintptr_t)0x2468&&!memcmp(mockUniformState,zero,sizeof(zero));
}
static bool testLightReplacement(void) {
    char hash[65];bool ok=hashBytes("abc",3,hash)&&!strcmp(hash,"ba7816bf8f01cfea414140de5dae2223b00361a396177a9cb410ff61f20015ad");
    const char *vertex="2e9d8aca544f52c43f0577a1e694b9ee99e4d9c71ec95e90c6538b049f0e6de6",*fragment="c5409ef638c1b75b951e2d5117a52b53fb59aceea26310acf202dfbf09daf33b";
    ok=ok&&lightShaderHashesAllowed(vertex,fragment)&&!lightShaderHashesAllowed(fragment,vertex)&&!lightShaderHashesAllowed(vertex,"unknown");
    ReaverEvent event={0};event.valid=true;event.tick=999;event.player=1;event.instance=2;event.object=3;event.extraData=4;memcpy(event.name,"sreavr__",8);
    ok=ok&&lightRecentReaver(&event,1,1000)&&!lightRecentReaver(&event,5,1000)&&!lightRecentReaver(&event,1,998)&&!lightRecentReaver(&event,1,1249);
    event.valid=false;ok=ok&&!lightRecentReaver(&event,1,1000);event.valid=true;event.name[0]='x';ok=ok&&!lightRecentReaver(&event,1,1000);
    float position[16]={1,2,3,512},color[16]={20*4.0f/255,40*4.0f/255,20*4.0f/255,0},joints[8]={0,0,0,1,1,2,3,1};
    ok=ok&&lightAttachmentMatches(position,color,joints,0x00142814);
    position[0]=2;ok=ok&&!lightAttachmentMatches(position,color,joints,0x00142814);position[0]=1;
    ok=ok&&!lightAttachmentMatches(position,color,joints,0x0080542a);
    position[3]=511;ok=ok&&!lightAttachmentMatches(position,color,joints,0x00142814);position[3]=512;
    color[0]=NAN;ok=ok&&!lightAttachmentMatches(position,color,joints,0x00142814);color[0]=20*4.0f/255;
    lightUniform4fv=mockUniformSet;cglGetUniformfv=mockUniformGet;originalDraw=mockUniformDraw;memcpy(mockUniformState,color,sizeof(mockUniformState));
    ok=ok&&lightUniformDraw(1,7,color,GL_TRIANGLES,9,GL_UNSIGNED_INT,(void *)(uintptr_t)0x2468)&&mockUniformWrites==2&&mockUniformDrawCalls==1&&mockUniformDrawValid&&!memcmp(mockUniformState,color,sizeof(mockUniformState))&&!lightReplaceFailed;
    mockUniformWrites=0;mockUniformDrawCalls=0;mockUniformFailure=1;memcpy(mockUniformState,color,sizeof(mockUniformState));
    ok=ok&&!lightUniformDraw(1,7,color,GL_TRIANGLES,9,GL_UNSIGNED_INT,(void *)(uintptr_t)0x2468)&&mockUniformDrawCalls==0&&!lightReplaceFailed&&!memcmp(mockUniformState,color,sizeof(mockUniformState));
    mockUniformWrites=0;mockUniformDrawCalls=0;mockUniformFailure=2;memcpy(mockUniformState,color,sizeof(mockUniformState));
    ok=ok&&lightUniformDraw(1,7,color,GL_TRIANGLES,9,GL_UNSIGNED_INT,(void *)(uintptr_t)0x2468)&&mockUniformDrawCalls==1&&lightReplaceFailed;
    lightUniform4fv=NULL;cglGetUniformfv=NULL;originalDraw=NULL;lightReplaceFailed=false;lightReplaced=0;mockUniformFailure=0;
    return ok;
}
static bool testRecordingStatus(void) {
    RecordingStatus status={0x31434552,1,7,8,999,1,600};
    bool ok=recordingStatusValid(&status,7,1000)&&!recordingStatusValid(&status,6,1000)&&!recordingStatusValid(&status,7,998)&&!recordingStatusValid(&status,7,2499);
    status.completed=601;ok=ok&&!recordingStatusValid(&status,7,1000);status.completed=1;
    status.total=3601;ok=ok&&!recordingStatusValid(&status,7,1000);status.total=600;
    status.total=(uint32_t)sheet_sessionLifetime_session.testSeconds*10;ok=ok&&recordingStatusValid(&status,7,1000);status.total=600;
    status.magic=0;ok=ok&&!recordingStatusValid(&status,7,1000);status.magic=0x31434552;
    status.version=2;ok=ok&&!recordingStatusValid(&status,7,1000);
    return ok;
}
static uintptr_t mockReaverArgument;
static volatile LONG mockReaverCalls;
static __declspec(noinline) void __fastcall mockReaver(uintptr_t argument) {mockReaverArgument=argument;InterlockedIncrement(&mockReaverCalls);}
static volatile int64_t mockBias;
static __declspec(noinline) int64_t __fastcall mockCharacter(int64_t a, int64_t b, int64_t c) {
    return a + b * 2 + c * 3 + mockBias;
}
static volatile LONG started;
__declspec(dllexport) void InitializeASI(void) {
    if (InterlockedCompareExchange(&started, 1, 0)) return;
    HANDLE thread = CreateThread(NULL, 0, worker, NULL, 0, NULL);
    if (thread) CloseHandle(thread);
}
__declspec(dllexport) int LOKProbeSelfTest(void) {
#ifdef SR1_DUAL_INPUT
    {int result=dualRuntimeSelfTest();if(result)return result;}
#endif
    originalChar = mockCharacter;
    if (observeChar(1, 2, 3) != 14 || charCalls != 1 || latestCharEvent.args[1] != 2 ||
        latestCharEvent.readable[0] || latestCharEvent.readable[1] || latestCharEvent.readable[2]) return 8;
    originalChar = NULL; charCalls = 0; memset(&latestCharEvent, 0, sizeof(latestCharEvent));
    if (MH_Initialize() != MH_OK) return 9;
    if (MH_CreateHook((PVOID)&mockCharacter, (PVOID)&observeChar, (PVOID *)&originalChar) != MH_OK) return 10;
    if (MH_EnableHook((PVOID)&mockCharacter) != MH_OK) return 11;
    volatile CharFn invoke = mockCharacter;
    if (invoke(1, 2, 3) != 14 || charCalls != 1) return 12;
    if (MH_DisableHook((PVOID)&mockCharacter) != MH_OK) return 13;
    if (invoke(1, 2, 3) != 14 || charCalls != 1) return 14;
    if (MH_Uninitialize() != MH_OK) return 15;
    originalChar = NULL; charCalls = 0; memset(&latestCharEvent, 0, sizeof(latestCharEvent));
    originalReaver=mockReaver;observeReaver(0x13579);
    if(mockReaverCalls!=1||mockReaverArgument!=0x13579||latestReaver.valid)return 20;
    if(MH_Initialize()!=MH_OK||MH_CreateHook((PVOID)&mockReaver,(PVOID)&observeReaver,(PVOID *)&originalReaver)!=MH_OK||MH_EnableHook((PVOID)&mockReaver)!=MH_OK)return 21;
    volatile ReaverFn invokeReaver=mockReaver;invokeReaver(0x24680);
    if(mockReaverCalls!=2||mockReaverArgument!=0x24680||reaverCalls!=2)return 22;
    if(MH_DisableHook((PVOID)&mockReaver)!=MH_OK)return 23;
    invokeReaver(0xabcde);
    if(mockReaverCalls!=3||mockReaverArgument!=0xabcde||reaverCalls!=2||MH_Uninitialize()!=MH_OK)return 24;
    ReaverEvent reaverFixture={0};reaverFixture.valid=true;reaverFixture.player=1;reaverFixture.instance=2;reaverFixture.extraData=3;
    memcpy(reaverFixture.name,"sreavr__",8);
    if(!reaverCanHide(&reaverFixture,true,1000,999,1)||reaverCanHide(&reaverFixture,false,1000,999,1)||
       reaverCanHide(&reaverFixture,true,1000,750,1)||reaverCanHide(&reaverFixture,true,1000,1001,1)||
       reaverCanHide(&reaverFixture,true,1000,999,4))return 25;
    reaverFixture.valid=false;if(reaverCanHide(&reaverFixture,true,1000,999,1))return 26;
    reaverFixture.valid=true;reaverFixture.name[0]='x';if(reaverCanHide(&reaverFixture,true,1000,999,1))return 27;
    originalReaver=NULL;reaverCalls=0;memset(&latestReaver,0,sizeof(latestReaver));
    originalSwap = mockSwap; originalPoll = mockPoll;
    if (countSwap((HDC)(uintptr_t)0x1234) != FALSE || !countPoll((void *)(uintptr_t)0x5678) ||
        !mockSwapSeen || !mockPollSeen || swapCalls != 1 || pollCalls != 1 || mockSwapForwards!=1) return 7;
    InterlockedExchange(&probeBoundedComplete,1);
    if(countSwap((HDC)(uintptr_t)0x1234)!=FALSE||mockSwapForwards!=2||swapCalls!=2)return 32;
    InterlockedExchange(&probeBoundedComplete,0);mockSwapForwards=0;
    originalSwap = NULL; originalPoll = NULL; swapCalls = 0; pollCalls = 0;
    originalDraw=mockDraw;observeDraw(GL_TRIANGLES,9,GL_UNSIGNED_INT,(void *)(uintptr_t)0x2468);
    if(!mockDrawSeen)return 16;originalDraw=NULL;
    cglGetBufferParameteriv=mockIndexSize;cglGetBufferSubData=mockIndexRead;
    cameraReady=true;drawCanonicalReady=true;
    for(size_t i=0;i<sizeof(mockIndexData);++i)mockIndexData[i]=drawCanonicalIndices[i]=(unsigned char)(i*17+3);
    if(!drawIdentity(GL_TRIANGLES,102720,GL_UNSIGNED_SHORT,NULL,9)||
       !drawIdentity(GL_TRIANGLES,5280,GL_UNSIGNED_SHORT,(void *)(uintptr_t)205440,9))return 17;
    mockIndexData[100]^=1;
    if(drawIdentity(GL_TRIANGLES,102720,GL_UNSIGNED_SHORT,NULL,9))return 18;
    mockIndexData[100]^=1;mockIndexReadFail=true;
    if(drawIdentity(GL_TRIANGLES,102720,GL_UNSIGNED_SHORT,NULL,9)||
       drawIdentity(GL_TRIANGLES,5280,GL_UNSIGNED_SHORT,(void *)(uintptr_t)216000,9)||
       drawIdentity(GL_TRIANGLES,102720,GL_UNSIGNED_INT,NULL,9)||
       drawIdentity(GL_LINES,102720,GL_UNSIGNED_SHORT,NULL,9)||
       drawIdentity(GL_TRIANGLES,102720,GL_UNSIGNED_SHORT,NULL,0))return 19;
    mockIndexReadFail=false;cameraReady=false;drawCanonicalReady=false;
    cglGetBufferParameteriv=NULL;cglGetBufferSubData=NULL;
    if(!testLightReads())return 28;
    if(!testShaderReads())return 29;
    if(!testLightReplacement())return 30;
    if(!testRecordingStatus())return 31;
    if(!testRibbonReplacement())return 33;
    const unsigned char data[] = {0xaa, 0x10, 0xbb, 0xaa, 0x20, 0xbb};
    size_t first = 99;
    if (scan(data, sizeof(data), "AA ?? BB", &first) != 2 || first != 0) return 1;
    if (scan(data, sizeof(data), "AA 20 BB", &first) != 1 || first != 3) return 2;
    if (scan(data, sizeof(data), "", NULL) || scan(data, 2, "AA ?? BB", NULL)) return 3;
    if (scan(data, sizeof(data), "GG", NULL)) return 4;
    SYSTEM_INFO info; GetSystemInfo(&info);
    PVOID *slot = VirtualAlloc(NULL, info.dwPageSize, MEM_COMMIT | MEM_RESERVE, PAGE_READWRITE);
    if (!slot) return 5;
    *slot = (PVOID)(uintptr_t)0x1234;
    DWORD protection; VirtualProtect(slot, info.dwPageSize, PAGE_READONLY, &protection);
    bool a = replaceSlot(slot, (PVOID)(uintptr_t)0x1234, (PVOID)(uintptr_t)0x5678);
    bool b = !replaceSlot(slot, (PVOID)(uintptr_t)0x1234, (PVOID)(uintptr_t)0x9999);
    bool c = replaceSlot(slot, (PVOID)(uintptr_t)0x5678, (PVOID)(uintptr_t)0x1234);
    MEMORY_BASIC_INFORMATION memory; VirtualQuery(slot, &memory, sizeof(memory));
    bool d = memory.Protect == PAGE_READONLY;
    VirtualFree(slot, 0, MEM_RELEASE);
    return a && b && c && d ? 0 : 6;
}
BOOL WINAPI DllMain(HINSTANCE module, DWORD reason, LPVOID reserved) {
    (void)reserved;
    if (reason == DLL_PROCESS_ATTACH) { self = module; DisableThreadLibraryCalls(self); }
    return TRUE;
}
