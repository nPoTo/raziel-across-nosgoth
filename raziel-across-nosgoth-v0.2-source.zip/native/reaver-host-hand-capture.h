// SPDX-License-Identifier: GPL-3.0-or-later
#pragma once
#ifndef SR1_NATIVE_DRAW_RECEIPT
#error Reaver hand receipt requires the verified native draw scope
#endif
#include "reaver-submitted-hand.h"
#include "reaver-palm-frame.h"
// Thread-local to the actual native draw/GL thread; not the diagnostic receipt.
static _Thread_local ReaverSubmittedHand reaverHostHand;
static _Thread_local ReaverSubmittedHand reaverHostPalm;
static _Thread_local HGLRC reaverHostContext;
static _Thread_local uint64_t reaverHostDrawSerial;
#ifdef SR1_REAVER_GPU_RECEIPT
#include "reaver-host-palette-capture.h"
#endif
static inline void reaverHostCapture(const HostRig *original,const float submitted[66][13],uintptr_t forwarded,uintptr_t base,uint64_t frame,unsigned depth){
 HostRig after={0};float current[66][13],native[66][13];
 HGLRC context=wglGetCurrentContext();
 bool unchanged=context&&hostDrawCreation&&!InterlockedCompareExchange(&sr1SkeletonFailed,0,0)&&
  rigIdentitySnapshot(NULL,sr1SkeletonRead,base,&after)&&rigSameIdentity(original,&after)&&
  worldRead(original->render,native,sizeof(native))&&!memcmp(original->renderBytes,native,sizeof(native))&&
  worldRead(forwarded,current,sizeof(current));
 reaverHostContext=NULL;reaverHandClear(&reaverHostPalm);
 if(reaverHandCapture(&reaverHostHand,submitted,current,original->actor,original->model,hostDrawCreation,frame,
    ++reaverHostDrawSerial,true,unchanged,depth)){
  reaverHostContext=context;
  const Sheet_reaverPalmBasis *p=&sheet_reaverPalmBasis_anatomical;
  if(p->targetWrist==41&&p->targetFinger==42&&p->targetThumb==44&&p->targetSocket==49&&!p->nativeIntegrationEnabled){
   float points[9],matrix[16];const unsigned joints[]={41,42,44};
   for(unsigned j=0;j<3;j++)memcpy(points+j*3,submitted[joints[j]]+10,12);
   if(reaverPalmFrame(matrix,points,reaverHostHand.matrix+12)){reaverHostPalm=reaverHostHand;memcpy(reaverHostPalm.matrix,matrix,sizeof(matrix));}
  }
 }
#ifdef SR1_REAVER_GPU_RECEIPT
 reaverHostCapturePalette(base);
#endif
}
static inline bool reaverHostCurrentHand(float out[16],uint64_t actor,uint64_t model,uint64_t frame,HGLRC context){
 if(!context||context!=reaverHostContext||!reaverHandCurrent(&reaverHostHand,actor,model,hostDrawCreation,frame))return false;
 memcpy(out,reaverHostHand.matrix,16*sizeof(float));return true;
}
