// SPDX-License-Identifier: GPL-3.0-or-later
#pragma once
#include "first-block-memory.h"
#include "donor-block-targets.h"
#include "donor-block-initialization-reader.h"
#include "first-block-proof.h"
typedef uintptr_t (__fastcall *FirstBlockQueryFn)(uintptr_t,uintptr_t);
typedef uintptr_t (__fastcall *FirstBlockDirectionFn)(uintptr_t,uintptr_t,uintptr_t);
static FirstBlockQueryFn firstBlockOriginalQuery[3],firstBlockOriginalFrame;
static FirstBlockDirectionFn firstBlockOriginalDirection;
static PVOID firstBlockTargets[5];static FirstBlockMemory *firstBlockView;static HANDLE firstBlockMap,firstBlockHost,firstBlockWriter;
static FirstBlockHeader firstBlockHeader;static uint64_t firstBlockCreation;static volatile LONG firstBlockStopped,firstBlockAttached;
static FirstBlockControl firstBlockControl;static uint64_t firstBlockFrames;
static FirstBlockIntent firstBlockCachedIntent;
static volatile LONG firstBlockProducer;static uint32_t firstBlockTotals[4],firstBlockTrue[3];static _Thread_local uint64_t firstBlockFrameTick;
static volatile LONG firstBlockScopeFailure;
static _Thread_local bool firstBlockFrameScope;static _Thread_local unsigned firstBlockFrameDepth;
static void firstBlockFrameExpire(void){uint64_t now=GetTickCount64();if(firstBlockFrameScope&&(now<firstBlockFrameTick||now-firstBlockFrameTick>(uint64_t)sheet_firstBlockPilotPolicy_bounded.freshMs)){firstBlockControl.held=firstBlockControl.pressed=false;if(!firstBlockControl.releaseSent){firstBlockControl.releaseTick=now;firstBlockControl.released=firstBlockControl.owns;firstBlockControl.releaseSent=firstBlockControl.owns;}firstBlockControl.needIdle=true;firstBlockControl.desired=FB_CLEAR;}}
static bool firstBlockPeer(HANDLE h,uint64_t creation){FILETIME c,e,k,u;return h&&WaitForSingleObject(h,0)==WAIT_TIMEOUT&&GetProcessTimes(h,&c,&e,&k,&u)&&(((uint64_t)c.dwHighDateTime<<32)|c.dwLowDateTime)==creation;}
static bool firstBlockNativeState(uintptr_t actor,uint32_t primary[3],uint32_t keys[3],bool *idle,bool *target){
 *idle=*target=false;memset(primary,0,12);memset(keys,0,12);
 if(!donorProcessIdentity(actor))return false;
 DonorStateSections s=donorStateSectionsRead(NULL,donorMessageRead,donorMessageCode,donorMessageBase,donorMessageImageSize,actor,donorMessageBase+0xc5aa78);
 if(!s.valid||!s.ownerMatches)return false;uintptr_t state=0,owner=0;if(!worldRead(actor+0x3f8,&state,8)||!state||!worldRead(state,&owner,8)||owner!=actor)return false;
 bool supported=true;*idle=true;for(unsigned i=0;i<3;i++){primary[i]=s.sections[i].firstRva;*idle=*idle&&primary[i]==0x1090f0;supported=supported&&(primary[i]==0x1090f0||primary[i]==0x114b40||primary[i]==0x117e30);if(!worldRead(state+i*0x250+0x248,&keys[i],4))return false;}
 DonorBlockTargets t=donorBlockTargetsRead(NULL,donorMessageRead,donorMessageCode,donorMessageBase,donorMessageImageSize,actor);
 *target=t.valid&&t.entryCallbackKnown&&t.entryCallbackRva==0xee380&&t.entryHandlerKnown&&(t.entryHandlerRva==0xce270||t.entryHandlerRva==0xce4c0);
 if(*target){DonorBlockTargetSnapshot snap;DonorBlockInitializationMetadata type={0};*target=donorBlockTargetSnapshot(NULL,donorMessageRead,donorMessageBase,actor,&snap)&&snap.entry&&donorBlockInitializationRead(NULL,donorMessageRead,donorMessageCode,donorMessageBase,donorMessageImageSize,snap.entry,false,&type)&&type.knownType&&!type.cleanup;}
 uint32_t flags=0,af=0,of=0;unsigned char mode=0;uintptr_t object=0;
 bool ui=worldRead(donorMessageBase+0xc5ab38,&flags,4)&&worldRead(donorMessageBase+0xc5ab60,&mode,1)&&mode==0&&!(flags&0x1000)&&worldRead(actor+0xac,&af,4)&&!(af&0x24000000)&&worldRead(actor+0x88,&object,8)&&worldRead(object,&of,4)&&(!(flags&0x100000)||(of&0x800));
 return supported&&ui&&donorProcessIdentity(actor);
}
static bool firstBlockQueryCaller(unsigned kind,unsigned q,uint32_t caller){
 if(kind==0)return q==69&&caller==0x155715;
 if(kind==1)return(q==69&&caller==0x15576a)||(q==73&&caller==0x155778);
 static const uint32_t r[10]={0x114c49,0x114c57,0x118100,0x11810e,0x1187e8,0x1187fa,0x1189c0,0x1189d2,0x156f74,0x156f82};
 for(unsigned i=0;i<10;i++)if(r[i]==caller&&q==(i%2?73u:69u))return true;return false;
}
static uintptr_t firstBlockQueryForward(unsigned kind,uintptr_t a,uintptr_t b,uintptr_t caller){
 DWORD incoming=GetLastError();SetLastError(incoming);uintptr_t result=firstBlockOriginalQuery[kind](a,b);DWORD outgoing=GetLastError();
 uint32_t rva=caller>=donorMessageBase&&caller-donorMessageBase<donorMessageImageSize?(uint32_t)(caller-donorMessageBase):0;
 bool scope=firstBlockFrameScope&&firstBlockQueryCaller(kind,(unsigned)b,rva);
 if(scope)firstBlockFrameExpire();
 result=firstBlockQueryResult(&firstBlockControl,kind,(unsigned)b,scope,result);if(scope&&(uint8_t)result&&b==69)++firstBlockTrue[kind];SetLastError(outgoing);return result;
}
static uintptr_t __fastcall firstBlockPress(uintptr_t a,uintptr_t b){return firstBlockQueryForward(0,a,b,(uintptr_t)__builtin_return_address(0));}
static uintptr_t __fastcall firstBlockRelease(uintptr_t a,uintptr_t b){return firstBlockQueryForward(1,a,b,(uintptr_t)__builtin_return_address(0));}
static uintptr_t __fastcall firstBlockHeld(uintptr_t a,uintptr_t b){return firstBlockQueryForward(2,a,b,(uintptr_t)__builtin_return_address(0));}
static uintptr_t __fastcall firstBlockDirection(uintptr_t a,uintptr_t b,uintptr_t c){
 DWORD incoming=GetLastError();uintptr_t caller=(uintptr_t)__builtin_return_address(0);SetLastError(incoming);uintptr_t result=firstBlockOriginalDirection(a,b,c);DWORD outgoing=GetLastError();firstBlockFrameExpire();result=firstBlockDirectionResult(&firstBlockControl,firstBlockFrameScope&&caller==donorMessageBase+0x152eeb,result);SetLastError(outgoing);return result;
}
static uintptr_t __fastcall firstBlockFrame(uintptr_t actor,uintptr_t tracker){
 DWORD incoming=GetLastError();uintptr_t caller=(uintptr_t)__builtin_return_address(0);bool outer=firstBlockFrameDepth++==0,previous=firstBlockFrameScope;FirstBlockIntent c={0};uint32_t primary[3]={0},keys[3]={0},gates=0;bool idle=false,target=false;
 bool candidate=outer&&caller==donorMessageBase+0x15717d&&tracker==donorMessageBase+0xc5aa50&&donorProcessIdentity(actor)&&(InterlockedCompareExchange(&firstBlockAttached,0,0)||firstBlockControl.owns);
 LONG thread=(LONG)GetCurrentThreadId(),producer=candidate?InterlockedCompareExchange(&firstBlockProducer,thread,0):0;
 if(candidate&&producer&&producer!=thread){InterlockedExchange(&firstBlockScopeFailure,3);InterlockedExchange(&firstBlockStopped,1);}
 bool scope=candidate&&(!producer||producer==thread);
 firstBlockFrameScope=false;
 if(scope){bool supported=firstBlockNativeState(actor,primary,keys,&idle,&target),ready=InterlockedCompareExchange(&firstBlockAttached,0,0)&&!InterlockedCompareExchange(&firstBlockStopped,0,0)&&firstBlockView&&firstBlockPeer(firstBlockHost,firstBlockHeader.hostCreation)&&firstBlockPeer(firstBlockWriter,firstBlockHeader.writerCreation)&&!memcmp(&firstBlockHeader,&firstBlockView->header,sizeof(firstBlockHeader));
  uint64_t now=GetTickCount64();ready=ready&&now>=firstBlockHeader.beginTick&&now-firstBlockHeader.beginTick<(uint64_t)sheet_firstBlockPilotPolicy_bounded.maxSessionMs;
  FirstBlockIntent incomingIntent={0};bool copied=ready&&firstBlockReadIntent(firstBlockView,&incomingIntent);firstBlockSnapshot(&firstBlockCachedIntent,ready,copied,&incomingIntent,firstBlockHeader.session,&c);
  firstBlockFrameTick=c.tick;
  gates=(supported?1u:0)|(idle?2u:0)|(target?4u:0)|(ready?8u:0)|(firstBlockIntentValid(&c,now)?16u:0);
  firstBlockBegin(&firstBlockControl,&c,GetTickCount64(),supported,idle,target);firstBlockMotionBefore(&firstBlockControl,supported,keys);firstBlockFrameScope=firstBlockControl.suppress;
 }
 SetLastError(incoming);uintptr_t result=firstBlockOriginalFrame(actor,tracker);DWORD outgoing=GetLastError();firstBlockFrameScope=previous;--firstBlockFrameDepth;
 if(scope){bool valid=firstBlockNativeState(actor,primary,keys,&idle,&target);firstBlockMotionAfter(&firstBlockControl,valid,keys);firstBlockAfter(&firstBlockControl,valid&&idle);for(unsigned i=0;i<4;i++)firstBlockTotals[i]+=firstBlockControl.queryCount[i];FirstBlockAck ack={.sequence=firstBlockControl.lastSequence,.tick=GetTickCount64(),.frames=++firstBlockFrames,.owned=firstBlockControl.owns,.held=firstBlockControl.held,.pressed=firstBlockControl.pressed,.released=firstBlockControl.released,.desired=firstBlockControl.desired,.failure=firstBlockScopeFailure?(uint32_t)firstBlockScopeFailure:firstBlockControl.failure,.pressTrue=firstBlockTrue[0],.releaseTrue=firstBlockTrue[1],.heldTrue=firstBlockTrue[2],.gates=gates};DonorBlockTargets targets=donorBlockTargetsRead(NULL,donorMessageRead,donorMessageCode,donorMessageBase,donorMessageImageSize,actor);ack.targetValid=targets.valid&&((targets.heldHandlerKnown&&targets.heldCallbackRva==0xee380)||(targets.entryHandlerKnown&&targets.entryCallbackRva==0xee380));ack.targetHandler=ack.targetValid?(targets.heldHandlerKnown?targets.heldHandlerRva:targets.entryHandlerRva):0;memcpy(ack.primary,primary,12);memcpy(ack.keys,keys,12);memcpy(ack.overrides,firstBlockTotals,sizeof(ack.overrides));if(InterlockedCompareExchange(&firstBlockAttached,0,0))firstBlockWriteAck(firstBlockView,&ack);}
 SetLastError(outgoing);return result;
}
static bool firstBlockInstall(void){
 if(!donorMessageBase||!donorMessageTarget)return false;unsigned char body[5032];char sha[65];
 for(unsigned i=0;i<ARRAYSIZE(firstBlockProofs);i++){const FirstBlockProof *p=&firstBlockProofs[i];if(p->bytes>sizeof(body)||!worldRead(donorMessageBase+p->rva,body,p->bytes)||!hashBytes(body,p->bytes,sha)||strcmp(sha,p->sha256))return false;}
 FILETIME c,e,k,u;if(!GetProcessTimes(GetCurrentProcess(),&c,&e,&k,&u))return false;firstBlockCreation=((uint64_t)c.dwHighDateTime<<32)|c.dwLowDateTime;
 const uint32_t rvas[5]={0x79fc0,0x7a180,0x7a310,0x13e200,0x156ea0};PVOID hooks[5]={(PVOID)firstBlockPress,(PVOID)firstBlockRelease,(PVOID)firstBlockHeld,(PVOID)firstBlockDirection,(PVOID)firstBlockFrame};PVOID *originals[5]={(PVOID *)&firstBlockOriginalQuery[0],(PVOID *)&firstBlockOriginalQuery[1],(PVOID *)&firstBlockOriginalQuery[2],(PVOID *)&firstBlockOriginalDirection,(PVOID *)&firstBlockOriginalFrame};
 for(unsigned i=0;i<5;i++){firstBlockTargets[i]=(PVOID)(donorMessageBase+rvas[i]);if(MH_CreateHook(firstBlockTargets[i],hooks[i],originals[i])!=MH_OK||MH_EnableHook(firstBlockTargets[i])!=MH_OK){for(unsigned j=0;j<=i;j++)if(firstBlockTargets[j])MH_DisableHook(firstBlockTargets[j]);return false;}}
 return true;
}
static void firstBlockTick(void){
 if(InterlockedCompareExchange(&firstBlockStopped,0,0))return;
 bool enabled=GetFileAttributesW(PROBE_PATH(L"\\first-block-donor.enable"))!=INVALID_FILE_ATTRIBUTES;
 if(!enabled){if(InterlockedCompareExchange(&firstBlockAttached,0,0))InterlockedExchange(&firstBlockStopped,1);return;}
 donorProcessFindModel();if(firstBlockView)return;
 wchar_t name[160];firstBlockName(name,GetCurrentProcessId(),firstBlockCreation);HANDLE map=OpenFileMappingW(FILE_MAP_READ|FILE_MAP_WRITE,FALSE,name);if(!map)return;
 FirstBlockMemory *view=MapViewOfFile(map,FILE_MAP_READ|FILE_MAP_WRITE,0,0,sizeof(*view));FirstBlockHeader h={0};if(view)h=view->header;
 HANDLE host=NULL,writer=NULL;if(view&&firstBlockHeaderValid(&h,GetCurrentProcessId(),firstBlockCreation)){host=OpenProcess(SYNCHRONIZE|PROCESS_QUERY_LIMITED_INFORMATION,FALSE,h.hostPid);writer=OpenProcess(SYNCHRONIZE|PROCESS_QUERY_LIMITED_INFORMATION,FALSE,h.writerPid);}
 if(!firstBlockPeer(host,h.hostCreation)||!firstBlockPeer(writer,h.writerCreation)){if(host)CloseHandle(host);if(writer)CloseHandle(writer);if(view)UnmapViewOfFile(view);CloseHandle(map);return;}
 firstBlockMap=map;firstBlockHost=host;firstBlockWriter=writer;firstBlockHeader=h;firstBlockView=view;InterlockedExchange(&firstBlockAttached,1);logLine("FIRST_BLOCK attached session=%llu host=%u; host-owned native block pilot, no direct target/animation calls",(unsigned long long)h.session,h.hostPid);
}
static void firstBlockStop(void){InterlockedExchange(&firstBlockStopped,1);logLine("FIRST_BLOCK shutdown requested; input hooks/mapping/trampolines pinned for native-thread release until process exit; no forced game-state write");}
