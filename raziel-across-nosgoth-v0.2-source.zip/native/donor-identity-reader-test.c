// SPDX-License-Identifier: GPL-3.0-or-later
#include <stdio.h>
#include "donor-identity-reader.h"
static const uintptr_t base=0x10000000,actor=0x20000000,razielModel=0x30000000;
static unsigned defect,rootReads,objectReads;
static bool readFixture(void *unused,uintptr_t at,void *out,SIZE_T n){
 (void)unused;if(n!=8||defect==1)return false;
 uintptr_t value=0;if(at==base+0xc5aa78){rootReads++;value=defect==2?0:actor;if(defect==3&&rootReads>1)value+=8;}
 else if(at==actor+0x88){objectReads++;value=defect==4?razielModel+8:razielModel;if(defect==5&&objectReads>1)value+=8;if(defect==6)return false;}
 else return false;memcpy(out,&value,8);return true;
}
static DonorIdentityObservation get(uintptr_t model){rootReads=objectReads=0;return donorIdentityRead(NULL,readFixture,base,0x2000000,model);}
#define CHECK(c,n) do{if(!(c)){printf("FAIL %u\n",(unsigned)(n));return n;}}while(0)
int main(void){
 DonorIdentityObservation r=get(razielModel);CHECK(r.valid&&r.registryAvailable&&r.modelMatchesRaziel,1);
 defect=4;r=get(razielModel);CHECK(r.valid&&r.actorPresent&&r.actorStable&&r.registryAvailable&&!r.modelMatchesRaziel,2);
 defect=0;r=get(0);CHECK(r.valid&&!r.registryAvailable&&!r.modelMatchesRaziel,3);
 for(defect=1;defect<=6;defect++)if(defect!=4)CHECK(!get(razielModel).valid,10+defect);defect=0;
 CHECK(!donorIdentityRead(NULL,readFixture,UINTPTR_MAX-2,0x2000000,razielModel).valid,20);
 CHECK(!donorIdentityRead(NULL,readFixture,base,0x1000,razielModel).valid,21);
 puts("PASS: production current actor/model equality, missing registry vs other model, actor/object races, read failures and bounds; no pointer output");return 0;
}
