// SPDX-License-Identifier: GPL-3.0-or-later
#include <assert.h>
#include <stdio.h>
#include "host-ground-forward.h"
static unsigned calls;static uintptr_t expectedActor;static int16_t *expectedPayload;static uint16_t expectedFlags;static uint32_t result;
static uint32_t original(uintptr_t actor,int16_t *payload,uint16_t flags){
 ++calls;assert(actor==expectedActor&&payload==expectedPayload&&flags==expectedFlags);
 if(payload)payload[4]=-17;return result;
}
int main(void){
 int16_t payload[6]={0};expectedActor=(uintptr_t)0x12345678;expectedPayload=payload;
 const uint32_t results[]={0,1,0x100001,0x80001,0xffffffff};
 for(unsigned i=0;i<sizeof(results)/sizeof(results[0]);i++)for(unsigned f=0;f<65536;f++){
  expectedFlags=(uint16_t)f;result=results[i];unsigned before=calls;
  assert(hostGroundForward(original,expectedActor,expectedPayload,expectedFlags)==result);
  assert(calls==before+1&&payload[4]==-17);
 }
 expectedActor=0;expectedPayload=0;expectedFlags=0;assert(hostGroundForward(original,0,0,0)==result);
 puts("PASS ground ABI: original called once, every flag/return preserved, native payload mutations preserved");return 0;
}
