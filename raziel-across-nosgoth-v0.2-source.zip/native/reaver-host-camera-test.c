// SPDX-License-Identifier: GPL-3.0-or-later
// Exercise the actual camera wrapper through a fake GL/read seam, no game access.
#include <stdbool.h>
#include <stdint.h>
#include <string.h>
#include <math.h>
#include <assert.h>
#include <stdio.h>
#include <wchar.h>
#include "exploration-sheets.h"
#include "host-transform.h"
#include "reaver-submitted-hand.h"
typedef void *HGLRC;typedef int GLint;typedef unsigned GLuint;
#define GL_CURRENT_PROGRAM 1
#define GL_UNIFORM_BUFFER_BINDING 2
#define GL_UNIFORM_BUFFER 3
#define GL_DRAW_FRAMEBUFFER_BINDING 4
typedef struct {GLuint program;int rowMajor;const char *field;} CameraField;
static CameraField cameraFields[4]={{7,0,"uViewMatrix"},{7,0,"uViewInverseMatrix"},{7,0,"uProjMatrix"}};
static unsigned cameraFieldCount=3,reads;static bool cameraReady=true,deny,tear,changeFbo;static GLint currentProgram=7,binding=123,framebuffer;static HGLRC context=(HGLRC)(uintptr_t)6;
static HGLRC wglGetCurrentContext(void){return context;}
static bool cglIsProgram(GLuint p){return p==7;}
static void glGetIntegerv(unsigned name,GLint *v){*v=name==GL_CURRENT_PROGRAM?currentProgram:name==GL_DRAW_FRAMEBUFFER_BINDING?framebuffer:binding;}
static void pglBindBuffer(unsigned name,GLuint v){assert(name==GL_UNIFORM_BUFFER);binding=(GLint)v;}
static bool cameraRead(const CameraField *f,float out[16],GLint *buffer){
 binding=456;*buffer=456;++reads;if(deny)return false;memset(out,0,64);out[0]=out[5]=out[10]=out[15]=1;
 if(!strcmp(f->field,"uProjMatrix")){out[10]=-1;out[11]=-1;out[14]=-2;out[15]=0;}
 if(tear&&reads==4)out[12]=1;if(changeFbo)framebuffer=1;return true;
}
#include "reaver-host-camera.h"
int main(void){
 float pose[66][13]={0};for(unsigned i=0;i<66;i++)pose[i][0]=pose[i][4]=pose[i][8]=1;pose[49][12]=-30;
 ReaverSubmittedHand hand;assert(reaverHandCapture(&hand,pose,pose,1,2,3,4,5,true,true,1));float out[16];
#define RUN() reaverHostCameraMvp(out,&hand,(HGLRC)(uintptr_t)6,1,2,3,4,7,true)
 assert(RUN());assert(reads==6&&binding==123&&out[15]==30);
 framebuffer=1;assert(!RUN());framebuffer=0;changeFbo=true;assert(!RUN()&&binding==123);changeFbo=false;framebuffer=0;
 deny=true;assert(!RUN()&&binding==123);deny=false;
 reads=0;tear=true;assert(!RUN()&&binding==123);tear=false;
 cameraFields[3]=cameraFields[0];cameraFieldCount=4;assert(!RUN()&&binding==123);cameraFieldCount=3;
 currentProgram=8;assert(!RUN());currentProgram=7;context=(HGLRC)(uintptr_t)9;assert(!RUN());context=(HGLRC)(uintptr_t)6;
 cameraFieldCount=2;assert(!RUN()&&binding==123);cameraFieldCount=3;hand.frame=3;assert(!RUN());
 puts("PASS actual camera wrapper: double reads, duplicate/missing fields, stale hand, current program/context, UBO restoration on refusal. Synthetic seam only.");return 0;
}
