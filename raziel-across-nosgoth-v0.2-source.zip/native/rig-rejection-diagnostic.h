// SPDX-License-Identifier: GPL-3.0-or-later
#pragma once
#include "host-rig-reader.h"
// Scalar differences only. Buffer pointers are still part of strict identity;
// observing a change does NOT authorize treating it as double buffering.
static unsigned rigDiagnosticDiff(const HostRig *a,const HostRig *b){
 unsigned mask=0;
 const uintptr_t av[]={a->actor,a->object,a->name,a->list,a->model,a->segments,a->legacy,a->render};
 const uintptr_t bv[]={b->actor,b->object,b->name,b->list,b->model,b->segments,b->legacy,b->render};
 for(unsigned i=0;i<8;i++)if(av[i]!=bv[i])mask|=1u<<i;
 if(a->modelIndex!=b->modelIndex)mask|=256;
 if(a->count!=b->count)mask|=512;
 if(a->count<1||a->count>128||b->count!=a->count||memcmp(a->parents,b->parents,(SIZE_T)a->count*sizeof(a->parents[0])))mask|=1024;
 return mask;
}
typedef struct {RigRead read;void *context;uintptr_t address[24];SIZE_T bytes[24];unsigned char first[24][8];unsigned count,changed,failed;} RigContextTrace;
static bool rigContextTraceRead(void *opaque,uintptr_t at,void *out,SIZE_T n){
 RigContextTrace *t=opaque;unsigned i=0;for(;i<t->count;i++)if(t->address[i]==at&&t->bytes[i]==n)break;
 if(n>8||i>=24)return false;
 bool seen=i<t->count;
 if(!seen){t->address[i]=at;t->bytes[i]=n;t->count++;}
 if(!t->read(t->context,at,out,n)){t->failed|=1u<<i;return false;}
 if(seen){if(memcmp(t->first[i],out,n))t->changed|=1u<<i;}
 else memcpy(t->first[i],out,n);
 return true;
}
