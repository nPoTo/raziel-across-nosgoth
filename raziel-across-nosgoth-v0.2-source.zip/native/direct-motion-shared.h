// Same-session IPC. Cumulative observed world displacement, no time-factor scaling.
#ifndef DIRECT_MOTION_SHARED_H
#define DIRECT_MOTION_SHARED_H
typedef struct {
 uint32_t magic,version,pid,reserved;
 uint64_t epoch,tick,instance;
 double xy[2];float z,baseZ,root[9];uint32_t samples;
 unsigned char moduleHash[32];
} DirectMotionSnapshot;
typedef struct {volatile LONG sequence;DirectMotionSnapshot snapshot;} DirectMotionShared;
static const unsigned char directMotionHash[32]={0xfc,0x6a,0x40,0x6f,0xf7,0xac,0x9b,0x5e,0xb7,0x78,0x8d,0xc7,0xa6,0x5d,0x33,0x5e,0x1c,0x1a,0xad,0x92,0x36,0x61,0x81,0x12,0x67,0x19,0x75,0xb7,0x1d,0x2d,0xad,0xdc};
static inline void directMotionName(wchar_t out[96],DWORD pid){_snwprintf(out,96,L"Local\\LOKDirectMotion-%lu",pid);}
static inline bool directMotionValid(const DirectMotionSnapshot *s,uint32_t pid,uint64_t now){
 if(!s||s->magic!=0x31445a52||s->version!=1||s->pid!=pid||!pid||s->reserved||!s->epoch||s->epoch>s->tick||s->tick>now||now-s->tick>150||s->tick-s->epoch>=180000||!s->instance||!s->samples||memcmp(s->moduleHash,directMotionHash,32))return false;
 for(unsigned k=0;k<2;k++)if(!isfinite(s->xy[k])||fabs(s->xy[k])>1000000)return false;
 if(!isfinite(s->z)||!isfinite(s->baseZ)||fabsf(s->z)>100000||fabsf(s->baseZ)>100000)return false;
 for(unsigned k=0;k<9;k++)if(!isfinite(s->root[k]))return false;
 for(unsigned c=0;c<3;c++)for(unsigned d=c;d<3;d++){
  float dot=0;for(unsigned r=0;r<3;r++)dot+=s->root[c*3+r]*s->root[d*3+r];
  if(fabsf(dot-(c==d?1.0f:0.0f))>.03f)return false;
 }
 float det=s->root[0]*(s->root[4]*s->root[8]-s->root[5]*s->root[7])-s->root[3]*(s->root[1]*s->root[8]-s->root[2]*s->root[7])+s->root[6]*(s->root[1]*s->root[5]-s->root[2]*s->root[4]);
 return fabsf(det-1)<.03f;
}
static inline bool directMotionCopy(const DirectMotionShared *shared,DirectMotionSnapshot *out){
 if(!shared||!out)return false;
 for(unsigned k=0;k<3;k++){
  LONG begin=shared->sequence;if(begin&1)continue;
  MemoryBarrier();memcpy(out,&shared->snapshot,sizeof(*out));MemoryBarrier();
  if(begin==shared->sequence)return true;
 }return false;
}
static inline void directMotionStore(DirectMotionShared *shared,const DirectMotionSnapshot *s){
 InterlockedIncrement(&shared->sequence);MemoryBarrier();memcpy(&shared->snapshot,s,sizeof(*s));MemoryBarrier();InterlockedIncrement(&shared->sequence);
}
#endif
