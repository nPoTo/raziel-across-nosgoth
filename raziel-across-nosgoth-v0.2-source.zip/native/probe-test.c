#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <stdio.h>
typedef int (*TestFn)(void);
int wmain(int argc, wchar_t **argv) {
    if (argc != 2) { fprintf(stderr, "Usage: probe-test.exe path-to-asi\n"); return 1; }
    HMODULE module = LoadLibraryW(argv[1]);
    if (!module) { fprintf(stderr, "LoadLibrary failed: %lu\n", GetLastError()); return 2; }
    TestFn test = (TestFn)GetProcAddress(module, "LOKProbeSelfTest");
    if (!test) return 3;
    int result = test();
    printf("Probe self-test: %s (%d)\n", result ? "FAIL" : "PASS", result);
    FreeLibrary(module);
    return result;
}
