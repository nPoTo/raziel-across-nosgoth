// SPDX-License-Identifier: GPL-3.0-or-later
// Synthetic fixture only; stdout carries no installed game data.
#include "donor-reaver-graphics.h"
#include <stdio.h>
#include "donor-reaver-ram-output.h"
int main(void){
 ReaverGraphics g={0};g.bones=10;g.vertices=1046;g.indexCount=3;g.batchCount=1;
 g.source.actor=0x1000;g.source.weapon=0x2000;g.model=0x3000;g.source.drawState=1;
 g.objectFlags=0x0500103d;g.partMask2=4;g.partMask3=32;g.realmBlend=1;
 for(unsigned i=0;i<10;i++)g.pose[i][0]=g.pose[i][5]=g.pose[i][10]=g.pose[i][15]=1;
 g.hand[0]=g.hand[5]=g.hand[10]=g.hand[15]=1;g.hand[12]=3.25f;
 g.palm[5]=10;g.palm[6]=10;
 g.indices[0]=0;g.indices[1]=1;g.indices[2]=1045;g.batch[0]=(ReaverGraphicsBatch){.count=3,.part=2,.material=335968,.textureId=670};
 g.batch[0].scroll=.375f;g.batch[0].textureFlags=16;
 g.color[3]=0xfedcba98;reaverRamOutput(&g,true,1,100);
 g.failureStage=8;reaverRamOutput(&g,false,2,101);return 0;
}
