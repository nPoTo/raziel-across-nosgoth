#include "report-path.h"
// Experimental static mesh inset. Own FBO/VAO/program; never writes gameplay state.
// SPDX-License-Identifier: GPL-3.0-or-later
#include <GL/glext.h>
#include <math.h>
#include "live-packet.h"
#include "smooth-normals.h"
#include "pose-blend.h"
#include "cover-topology.h"
#include "render-memory-reader.h"
#define OVERLAY_FUNCTIONS(X) \
 X(PFNGLCREATESHADERPROC,glCreateShader) X(PFNGLSHADERSOURCEPROC,glShaderSource) \
 X(PFNGLCOMPILESHADERPROC,glCompileShader) X(PFNGLGETSHADERIVPROC,glGetShaderiv) \
 X(PFNGLGETSHADERINFOLOGPROC,glGetShaderInfoLog) X(PFNGLCREATEPROGRAMPROC,glCreateProgram) \
 X(PFNGLATTACHSHADERPROC,glAttachShader) X(PFNGLBINDATTRIBLOCATIONPROC,glBindAttribLocation) \
 X(PFNGLLINKPROGRAMPROC,glLinkProgram) X(PFNGLGETPROGRAMIVPROC,glGetProgramiv) \
 X(PFNGLGETPROGRAMINFOLOGPROC,glGetProgramInfoLog) X(PFNGLUSEPROGRAMPROC,glUseProgram) \
 X(PFNGLGETUNIFORMLOCATIONPROC,glGetUniformLocation) X(PFNGLUNIFORMMATRIX4FVPROC,glUniformMatrix4fv) \
 X(PFNGLUNIFORM1IPROC,glUniform1i) X(PFNGLTEXIMAGE3DPROC,glTexImage3D) \
 X(PFNGLGENVERTEXARRAYSPROC,glGenVertexArrays) X(PFNGLBINDVERTEXARRAYPROC,glBindVertexArray) \
 X(PFNGLGENBUFFERSPROC,glGenBuffers) X(PFNGLBINDBUFFERPROC,glBindBuffer) X(PFNGLBUFFERDATAPROC,glBufferData) \
 X(PFNGLVERTEXATTRIBPOINTERPROC,glVertexAttribPointer) X(PFNGLENABLEVERTEXATTRIBARRAYPROC,glEnableVertexAttribArray) \
 X(PFNGLGENFRAMEBUFFERSPROC,glGenFramebuffers) X(PFNGLBINDFRAMEBUFFERPROC,glBindFramebuffer) \
 X(PFNGLFRAMEBUFFERTEXTURE2DPROC,glFramebufferTexture2D) X(PFNGLCHECKFRAMEBUFFERSTATUSPROC,glCheckFramebufferStatus) \
 X(PFNGLGENRENDERBUFFERSPROC,glGenRenderbuffers) X(PFNGLBINDRENDERBUFFERPROC,glBindRenderbuffer) \
 X(PFNGLRENDERBUFFERSTORAGEPROC,glRenderbufferStorage) X(PFNGLFRAMEBUFFERRENDERBUFFERPROC,glFramebufferRenderbuffer) \
 X(PFNGLBLITFRAMEBUFFERPROC,glBlitFramebuffer) X(PFNGLCOLORMASKIPROC,glColorMaski) 
// Indexed draw-buffer state: only output0 belongs to our pass.
static PFNGLENABLEIPROC overlayEnablei;
static PFNGLDISABLEIPROC overlayDisablei;
static PFNGLBINDSAMPLERPROC overlayBindSampler;
static PFNGLGETINTEGERI_VPROC overlayGetIntegeri;
#define DECLARE_GL(type,name) static type p##name;
OVERLAY_FUNCTIONS(DECLARE_GL)
#undef DECLARE_GL
typedef struct {
    GLint program,vao,array,drawFbo,readFbo,renderbuffer,texture,textureArray,sampler,pack,unpack,viewport[4],polygon[2],depthFunc;
    GLboolean depth,blend,cull,scissor,srgb,discard,depthMask,colorMask[4];
    GLfloat clearColor[4]; GLdouble clearDepth;
} OverlayState;
static HGLRC overlayContext;
static bool overlayAttempted,overlayReady,overlayReported;
static GLuint overlayProgram,overlayVao,overlayVbo,overlayEbo,overlayFbo,overlayTexture,overlayDepth;
static GLsizei overlayIndices;
static float overlayView[16];
static ULONGLONG overlayBegin;
static float *overlayLivePositions,*overlayNormals;
static uint32_t *overlayTopology;
static GLuint overlayNormalVbo;
static uint32_t overlayVertices,overlayLiveSequence,overlayLivePid;
static ULONGLONG overlayLivePoll,overlayLiveTick;
static bool overlayLiveReported;
#ifdef SR1_RETARGET_PREVIEW
static uintptr_t overlayHostActor,overlayHostObject,overlayHostModel;
static uint64_t overlayHostTick;
#endif
static bool overlayAirSupport;
static bool overlayCoverOpen,overlayCoverTopology;
static unsigned int overlayLiveFrames;
static PoseBlend overlayBlendPose;
static unsigned int overlayBlendFrames;
static bool overlayReadLive(void) {
    ULONGLONG now=GetTickCount64();
    if(now-overlayLivePoll<16) return false;
    overlayLivePoll=now;
    uint32_t header[16]; uint64_t tick=0;
    size_t bytes=(size_t)overlayVertices*12;
    static unsigned char packet[RM_LIVE_BYTES];
    bool received=LIVE_HEADER_BYTES+bytes==sizeof(packet)&&renderMemoryCopy(2,packet,sizeof(packet));
#ifdef SR1_RETARGET_PREVIEW
    // A busy nonblocking mutex is not an invalid new pose. Keep the previous
    // explicitly paired host frame for at most its200ms admission window.
    // A received cancellation packet below still releases immediately.
    if(!received)return false;
#endif
    bool valid=received;
    if(valid)memcpy(header,packet,sizeof(header));
    if(valid) {
        memcpy(&tick,&header[4],8);
        valid=liveHeaderValid(header,overlayVertices,sizeof(packet),now,
#ifdef SR1_RETARGET_PREVIEW
        0
#else
        overlayLiveTick
#endif
        );
    }
#ifdef SR1_RETARGET_PREVIEW
    uintptr_t actor=0,object=0,model=0;uint64_t hostTick=0;
    if(valid){memcpy(&actor,packet+64,8);memcpy(&object,packet+72,8);memcpy(&model,packet+80,8);memcpy(&hostTick,packet+88,8);valid=actor&&object&&model&&hostTick&&hostTick<=now&&now-hostTick<=200&&tick>=overlayLiveTick;}
    if(!valid){overlayLiveTick=0;overlayBlendPose.ready=false;overlayBlendPose.active=false;return false;}
    if(tick==overlayLiveTick)return false;
    overlayHostActor=actor;overlayHostObject=object;overlayHostModel=model;overlayHostTick=hostTick;
#endif
    if(valid)memcpy(overlayLivePositions,packet+LIVE_HEADER_BYTES,bytes);
    if(valid) for(size_t i=0;i<bytes/4;++i) if(!isfinite(overlayLivePositions[i]) || fabsf(overlayLivePositions[i])>100000) { valid=false; break; }
    if(!valid||!poseBlendAccept(&overlayBlendPose,overlayLivePositions,header[6],tick,now)) return false;
    overlayLivePid=header[6]; overlayLiveSequence=header[3]; overlayLiveTick=tick;
    overlayAirSupport=(header[7]&4)!=0;
    bool coverOpen=(header[7]&8)!=0;
    if(coverOpen!=overlayCoverOpen)logLine("COVER_VARIANT open=%u source_pid=%u sequence=%u; cloth-pose selection",coverOpen,header[6],header[3]);
    overlayCoverOpen=coverOpen;
    ++overlayLiveFrames;
    if(!overlayLiveReported) { logLine("OVERLAY live packet accepted source_pid=%u sequence=%u age_ms=%llu; INSET ONLY",header[6],header[3],(unsigned long long)(now-tick)); overlayLiveReported=true; }
    if(overlayLiveFrames%60==0) logLine("OVERLAY live uploads=%u sequence=%u age_ms=%llu",overlayLiveFrames,header[3],(unsigned long long)(now-tick));
    return true;
}
static void overlayUpdateLive(void) {
    // Advance even if the file is absent, unchanged or invalid. Finish the last
    // valid transition, then hold; never blend corrupt/unvalidated read scratch.
    bool changed=overlayReadLive();
    changed=poseBlendStep(&overlayBlendPose,GetTickCount64())||changed;
    if(!changed||!overlayBlendPose.ready)return;
    size_t bytes=(size_t)overlayVertices*12;
    pglBindBuffer(GL_ARRAY_BUFFER,overlayVbo);
    pglBufferData(GL_ARRAY_BUFFER,(GLsizeiptr)bytes,overlayBlendPose.display,GL_STREAM_DRAW);
    smoothNormals(overlayBlendPose.display,overlayTopology,overlayVertices,(uint32_t)overlayIndices,overlayNormals);
    pglBindBuffer(GL_ARRAY_BUFFER,overlayNormalVbo);
    pglBufferData(GL_ARRAY_BUFFER,(GLsizeiptr)bytes,overlayNormals,GL_STREAM_DRAW);
    ++overlayBlendFrames;
    if(overlayBlendFrames%120==0)logLine("OVERLAY interpolated_frames=%u packets=%u transition_ms=%u",overlayBlendFrames,overlayLiveFrames,overlayBlendPose.duration);
}
static void overlaySave(OverlayState *s) {
    glGetIntegerv(GL_CURRENT_PROGRAM,&s->program); glGetIntegerv(GL_VERTEX_ARRAY_BINDING,&s->vao);
    glGetIntegerv(GL_ARRAY_BUFFER_BINDING,&s->array); glGetIntegerv(GL_DRAW_FRAMEBUFFER_BINDING,&s->drawFbo);
    glGetIntegerv(GL_READ_FRAMEBUFFER_BINDING,&s->readFbo); glGetIntegerv(GL_RENDERBUFFER_BINDING,&s->renderbuffer);
    glGetIntegerv(GL_TEXTURE_BINDING_2D,&s->texture); glGetIntegerv(GL_PIXEL_PACK_BUFFER_BINDING,&s->pack);
    glGetIntegerv(GL_TEXTURE_BINDING_2D_ARRAY,&s->textureArray);
    s->sampler=0;
    if(overlayBindSampler) {GLint active=0; glGetIntegerv(GL_ACTIVE_TEXTURE,&active); overlayGetIntegeri(GL_SAMPLER_BINDING,(GLuint)(active-GL_TEXTURE0),&s->sampler);}
    glGetIntegerv(GL_PIXEL_UNPACK_BUFFER_BINDING,&s->unpack); glGetIntegerv(GL_VIEWPORT,s->viewport);
    glGetIntegerv(GL_POLYGON_MODE,s->polygon); glGetIntegerv(GL_DEPTH_FUNC,&s->depthFunc);
    s->depth=glIsEnabled(GL_DEPTH_TEST); s->blend=glIsEnabled(GL_BLEND); s->cull=glIsEnabled(GL_CULL_FACE);
    s->scissor=glIsEnabled(GL_SCISSOR_TEST); s->srgb=glIsEnabled(GL_FRAMEBUFFER_SRGB); s->discard=glIsEnabled(GL_RASTERIZER_DISCARD);
    glGetBooleanv(GL_DEPTH_WRITEMASK,&s->depthMask); glGetBooleanv(GL_COLOR_WRITEMASK,s->colorMask);
    glGetFloatv(GL_COLOR_CLEAR_VALUE,s->clearColor); glGetDoublev(GL_DEPTH_CLEAR_VALUE,&s->clearDepth);
}
static void overlayToggle(GLenum name,GLboolean value) { if(value) glEnable(name); else glDisable(name); }
static void overlayBlend(GLboolean value) { if(value) overlayEnablei(GL_BLEND,0); else overlayDisablei(GL_BLEND,0); }
static void overlayRestore(const OverlayState *s) {
    pglUseProgram((GLuint)s->program); pglBindVertexArray((GLuint)s->vao); pglBindBuffer(GL_ARRAY_BUFFER,(GLuint)s->array);
    pglBindFramebuffer(GL_DRAW_FRAMEBUFFER,(GLuint)s->drawFbo); pglBindFramebuffer(GL_READ_FRAMEBUFFER,(GLuint)s->readFbo);
    pglBindRenderbuffer(GL_RENDERBUFFER,(GLuint)s->renderbuffer); glBindTexture(GL_TEXTURE_2D,(GLuint)s->texture);
    glBindTexture(GL_TEXTURE_2D_ARRAY,(GLuint)s->textureArray);
    if(overlayBindSampler) {GLint active=0; glGetIntegerv(GL_ACTIVE_TEXTURE,&active); overlayBindSampler((GLuint)(active-GL_TEXTURE0),(GLuint)s->sampler);}
    pglBindBuffer(GL_PIXEL_PACK_BUFFER,(GLuint)s->pack); pglBindBuffer(GL_PIXEL_UNPACK_BUFFER,(GLuint)s->unpack);
    glViewport(s->viewport[0],s->viewport[1],s->viewport[2],s->viewport[3]); glPolygonMode(GL_FRONT_AND_BACK,(GLenum)s->polygon[0]);
    glDepthFunc((GLenum)s->depthFunc); glDepthMask(s->depthMask); pglColorMaski(0,s->colorMask[0],s->colorMask[1],s->colorMask[2],s->colorMask[3]);
    glClearColor(s->clearColor[0],s->clearColor[1],s->clearColor[2],s->clearColor[3]); glClearDepth(s->clearDepth);
    overlayToggle(GL_DEPTH_TEST,s->depth); overlayBlend(s->blend); overlayToggle(GL_CULL_FACE,s->cull);
    overlayToggle(GL_SCISSOR_TEST,s->scissor); overlayToggle(GL_FRAMEBUFFER_SRGB,s->srgb); overlayToggle(GL_RASTERIZER_DISCARD,s->discard);
}
static GLuint overlayShader(GLenum kind,const char *source) {
    GLuint shader=pglCreateShader(kind); pglShaderSource(shader,1,&source,NULL); pglCompileShader(shader);
    GLint ok=0; pglGetShaderiv(shader,GL_COMPILE_STATUS,&ok);
    if(!ok) { char info[2048]={0}; pglGetShaderInfoLog(shader,sizeof(info),NULL,info); logLine("OVERLAY shader failed: %s",info); return 0; }
    return shader;
}
#include "texture-overlay.h"
static void overlayGeometryDraw(void){
    CoverRange ranges[3];unsigned count=coverRanges(overlayCoverTopology,overlayCoverOpen,ranges);
    if(!count){glDrawElements(GL_TRIANGLES,overlayIndices,GL_UNSIGNED_INT,NULL);return;}
    for(unsigned i=0;i<count;i++)glDrawElements(GL_TRIANGLES,(GLsizei)ranges[i].count,GL_UNSIGNED_INT,(const void *)(uintptr_t)(ranges[i].offset*4));
}
static bool overlayInit(void) {
#define LOAD_GL(type,name) do { PROC fn=wglGetProcAddress(#name); if(!fn || (uintptr_t)fn<=3 || (uintptr_t)fn==UINTPTR_MAX) return false; p##name=(type)fn; } while(0);
    OVERLAY_FUNCTIONS(LOAD_GL)
#undef LOAD_GL
    unsigned char *packet=malloc(RM_GEOMETRY_BYTES);
    if(!packet)return false;
    if(!renderMemoryCopy(0,packet,RM_GEOMETRY_BYTES)){free(packet);return false;}
    uint32_t header[4];
    memcpy(header,packet,sizeof(header));
#ifdef SR1_RETARGET_PREVIEW
    if(header[0]!=SR1_PROFILE_GEOMETRY_MAGIC||header[3]!=3||header[1]!=SR1_PROFILE_VERTICES||header[2]!=SR1_PROFILE_INDICES){free(packet);return false;}
#else
    if(header[0]!=0x314c5a52 || header[3]!=1 || header[1]!=24135 || header[2]!=125790) {free(packet);return false;}
#endif
    size_t positionBytes=(size_t)header[1]*12,indexBytes=(size_t)header[2]*4;
    float *positions=malloc(positionBytes); uint32_t *indices=malloc(indexBytes);
    bool valid=positions && indices;
    if(valid){memcpy(positions,packet+16,positionBytes);memcpy(indices,packet+16+positionBytes,indexBytes);}
    free(packet);
    if(valid) for(size_t i=0;i<positionBytes/4;++i) if(!isfinite(positions[i]) || fabsf(positions[i])>100000) valid=false;
    if(valid) for(uint32_t i=0;i<header[2];++i) if(indices[i]>=header[1]) valid=false;
    if(!valid) { free(positions); free(indices); return false; }
    char coverHash[65]={0};overlayCoverTopology=header[1]==24135&&header[2]==125790&&boundedSha256(indices,(ULONG)indexBytes,600000*4,coverHash)&&!strcmp(coverHash,COVER_INDEX_SHA);
    logLine("COVER_TOPOLOGY verified=%u index_bytes=%llu sha256=%s; one cloth variant, common body preserved",overlayCoverTopology,(unsigned long long)indexBytes,coverHash);
    const char *vs="#version 150\nin vec3 position;in vec3 texData;in vec3 normal;out vec3 surfaceNormal;out vec2 uv;flat out float layer;uniform mat4 view;void main(){surfaceNormal=normal;uv=texData.xy;layer=texData.z;gl_Position=view*vec4(position,1);}";
    const char *fs="#version 150\nin vec3 surfaceNormal;in vec2 uv;flat in float layer;out vec4 color;uniform sampler2DArray diffuse;uniform bool textured;void main(){vec3 n=normalize(surfaceNormal);float l=0.35+0.65*abs(dot(n,normalize(vec3(.35,-.7,.6))));vec4 base=textured?texture(diffuse,vec3(uv,layer)):vec4(.49,.75,.82,1);if(base.a<0.5)discard;color=vec4(base.rgb*l,1);}";
    GLuint vertex=overlayShader(GL_VERTEX_SHADER,vs),fragment=overlayShader(GL_FRAGMENT_SHADER,fs);
    if(!vertex || !fragment) { free(positions); free(indices); return false; }
    overlayProgram=pglCreateProgram(); pglAttachShader(overlayProgram,vertex); pglAttachShader(overlayProgram,fragment);
    pglBindAttribLocation(overlayProgram,0,"position"); pglBindAttribLocation(overlayProgram,1,"texData"); pglBindAttribLocation(overlayProgram,2,"normal"); pglLinkProgram(overlayProgram);
    GLint linked=0; pglGetProgramiv(overlayProgram,GL_LINK_STATUS,&linked);
    if(!linked) { char info[2048]={0}; pglGetProgramInfoLog(overlayProgram,sizeof(info),NULL,info); logLine("OVERLAY link failed: %s",info); free(positions); free(indices); return false; }
    float c=cosf(.7f),s=sinf(.7f),ct=cosf(.12f),st=sinf(.12f),low[3]={INFINITY,INFINITY,INFINITY},high[3]={-INFINITY,-INFINITY,-INFINITY};
    float basis[3][3]={{c,s,0},{-s*st,c*st,ct},{s*ct,-c*ct,st}};
    for(uint32_t i=0;i<header[1];++i) for(int row=0;row<3;++row) {
        float v=0; for(int j=0;j<3;++j) v+=positions[i*3+j]*basis[row][j];
        if(v<low[row]) low[row]=v; if(v>high[row]) high[row]=v;
    }
    float span=fmaxf(high[0]-low[0],high[1]-low[1])*1.12f; if(span<1) span=1;
    memset(overlayView,0,sizeof(overlayView)); overlayView[15]=1;
    for(int row=0;row<3;++row) {
        float scale=row==2?-1.0f/span:2.0f/span;
        for(int j=0;j<3;++j) overlayView[j*4+row]=basis[row][j]*scale;
        overlayView[12+row]=-(low[row]+high[row])*.5f*scale;
    }
    pglGenVertexArrays(1,&overlayVao); pglBindVertexArray(overlayVao);
    pglGenBuffers(1,&overlayVbo); pglBindBuffer(GL_ARRAY_BUFFER,overlayVbo); pglBufferData(GL_ARRAY_BUFFER,positionBytes,positions,GL_STATIC_DRAW);
    pglGenBuffers(1,&overlayEbo); pglBindBuffer(GL_ELEMENT_ARRAY_BUFFER,overlayEbo); pglBufferData(GL_ELEMENT_ARRAY_BUFFER,indexBytes,indices,GL_STATIC_DRAW);
    pglEnableVertexAttribArray(0); pglVertexAttribPointer(0,3,GL_FLOAT,GL_FALSE,12,NULL);
    overlayTextured=overlayLoadTextures(header[1]);
#ifdef SR1_RETARGET_PREVIEW
    if(!overlayTextured){free(positions);free(indices);return false;}
#endif
    overlayNormals=malloc(positionBytes);
    if(!overlayNormals) {free(positions);free(indices);return false;}
    smoothNormals(positions,indices,header[1],header[2],overlayNormals);
    pglGenBuffers(1,&overlayNormalVbo); pglBindBuffer(GL_ARRAY_BUFFER,overlayNormalVbo);
    pglBufferData(GL_ARRAY_BUFFER,positionBytes,overlayNormals,GL_STATIC_DRAW);
    pglEnableVertexAttribArray(2); pglVertexAttribPointer(2,3,GL_FLOAT,GL_FALSE,12,NULL);
    overlayTopology=indices;
    logLine("OVERLAY area-weighted smooth normals; vertex splits retained, live normals recomputed");
    free(positions); overlayIndices=(GLsizei)header[2];
    overlayVertices=header[1]; overlayLivePositions=malloc(positionBytes);
    if(!overlayLivePositions) return false;
    overlayBlendPose.count=(size_t)overlayVertices*3;
    overlayBlendPose.from=malloc(positionBytes);overlayBlendPose.target=malloc(positionBytes);overlayBlendPose.display=malloc(positionBytes);
    if(!overlayBlendPose.from||!overlayBlendPose.target||!overlayBlendPose.display)return false;
    pglGenFramebuffers(1,&overlayFbo); pglBindFramebuffer(GL_FRAMEBUFFER,overlayFbo);
    glGenTextures(1,&overlayTexture); glBindTexture(GL_TEXTURE_2D,overlayTexture); pglBindBuffer(GL_PIXEL_UNPACK_BUFFER,0);
    glTexImage2D(GL_TEXTURE_2D,0,GL_RGBA8,512,512,0,GL_RGBA,GL_UNSIGNED_BYTE,NULL);
    glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MIN_FILTER,GL_LINEAR); glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MAG_FILTER,GL_LINEAR);
    pglFramebufferTexture2D(GL_FRAMEBUFFER,GL_COLOR_ATTACHMENT0,GL_TEXTURE_2D,overlayTexture,0);
    pglGenRenderbuffers(1,&overlayDepth); pglBindRenderbuffer(GL_RENDERBUFFER,overlayDepth); pglRenderbufferStorage(GL_RENDERBUFFER,GL_DEPTH_COMPONENT24,512,512);
    pglFramebufferRenderbuffer(GL_FRAMEBUFFER,GL_DEPTH_ATTACHMENT,GL_RENDERBUFFER,overlayDepth);
    GLenum status=pglCheckFramebufferStatus(GL_FRAMEBUFFER); logLine("OVERLAY init vertices=%u indices=%u fbo_status=0x%x; static fallback + optional LIVE poses, gameplay=0",header[1],header[2],status);
    return status==GL_FRAMEBUFFER_COMPLETE;
}
static void overlaySnapshot(void) {
    unsigned char *pixels=malloc(512*512*4); if(!pixels) return;
    GLint alignment=0,rowLength=0,skipRows=0,skipPixels=0;
    glGetIntegerv(GL_PACK_ALIGNMENT,&alignment); glGetIntegerv(GL_PACK_ROW_LENGTH,&rowLength);
    glGetIntegerv(GL_PACK_SKIP_ROWS,&skipRows); glGetIntegerv(GL_PACK_SKIP_PIXELS,&skipPixels);
    glPixelStorei(GL_PACK_ALIGNMENT,1); glPixelStorei(GL_PACK_ROW_LENGTH,0); glPixelStorei(GL_PACK_SKIP_ROWS,0); glPixelStorei(GL_PACK_SKIP_PIXELS,0);
    pglBindFramebuffer(GL_READ_FRAMEBUFFER,overlayFbo); pglBindBuffer(GL_PIXEL_PACK_BUFFER,0);
    glReadPixels(0,0,512,512,GL_BGRA,GL_UNSIGNED_BYTE,pixels);
    glPixelStorei(GL_PACK_ALIGNMENT,alignment); glPixelStorei(GL_PACK_ROW_LENGTH,rowLength); glPixelStorei(GL_PACK_SKIP_ROWS,skipRows); glPixelStorei(GL_PACK_SKIP_PIXELS,skipPixels);
    wchar_t path[32768]; _snwprintf(path,ARRAYSIZE(path),PROBE_PATH(L"\\srx-overlay-%lu.bmp"),GetCurrentProcessId());
    FILE *out=_wfopen(path,L"wb");
    if(out) {
        BITMAPFILEHEADER file={0}; BITMAPINFOHEADER info={0}; file.bfType=0x4d42; file.bfOffBits=sizeof(file)+sizeof(info); file.bfSize=file.bfOffBits+512*512*4;
        info.biSize=sizeof(info); info.biWidth=512; info.biHeight=512; info.biPlanes=1; info.biBitCount=32; info.biSizeImage=512*512*4;
        fwrite(&file,sizeof(file),1,out); fwrite(&info,sizeof(info),1,out); fwrite(pixels,512*512*4,1,out); fclose(out);
        logLine("OVERLAY own-FBO snapshot saved");
    }
    free(pixels);
}
static void overlayDraw(HGLRC context) {
    if(!context || (overlayContext && overlayContext!=context)) return;
    if(!overlayAttempted) {
        // Wait for the publisher without opening old extracted asset files.
        if(renderMemoryAlternateIsActive&&renderMemoryAlternateIsActive()){
            if(!renderMemoryAlternateReady||!renderMemoryAlternateReady())return;
        }else {if(!renderMemoryLock())return;ReleaseMutex(renderMemoryMutex);}
        const char *version=(const char *)glGetString(GL_VERSION); int major=0,minor=0;
        if(version) sscanf(version,"%d.%d",&major,&minor);
        if(major<3 || (major==3 && minor<2)) return;
        overlayContext=context; overlayAttempted=true;
        // All required functions must load before saving/changing state.
#define CHECK_GL(type,name) do { PROC fn=wglGetProcAddress(#name); if(!fn || (uintptr_t)fn<=3 || (uintptr_t)fn==UINTPTR_MAX) return; p##name=(type)fn; } while(0);
        OVERLAY_FUNCTIONS(CHECK_GL)
#undef CHECK_GL
        PROC enablei=wglGetProcAddress("glEnablei"),disablei=wglGetProcAddress("glDisablei");
        if(!enablei || (uintptr_t)enablei<=3 || (uintptr_t)enablei==UINTPTR_MAX || !disablei || (uintptr_t)disablei<=3 || (uintptr_t)disablei==UINTPTR_MAX) return;
        overlayEnablei=(PFNGLENABLEIPROC)enablei; overlayDisablei=(PFNGLDISABLEIPROC)disablei;
        PFNGLGETSTRINGIPROC getStringi=(PFNGLGETSTRINGIPROC)wglGetProcAddress("glGetStringi");
        bool samplerSupport=major>3 || (major==3 && minor>=3);
        if(getStringi && (uintptr_t)getStringi>3 && (uintptr_t)getStringi!=UINTPTR_MAX) {
            GLint extensions=0; glGetIntegerv(GL_NUM_EXTENSIONS,&extensions);
            if(extensions>=0 && extensions<=4096) for(GLint i=0;i<extensions;i++) {const char *name=(const char *)getStringi(GL_EXTENSIONS,(GLuint)i); if(name && !strcmp(name,"GL_ARB_sampler_objects")) samplerSupport=true;}
        }
        if(samplerSupport) {
            PROC bind=wglGetProcAddress("glBindSampler"),get=wglGetProcAddress("glGetIntegeri_v");
            if(bind && (uintptr_t)bind>3 && (uintptr_t)bind!=UINTPTR_MAX && get && (uintptr_t)get>3 && (uintptr_t)get!=UINTPTR_MAX) {overlayBindSampler=(PFNGLBINDSAMPLERPROC)bind; overlayGetIntegeri=(PFNGLGETINTEGERI_VPROC)get;}
        }
        OverlayState saved; overlaySave(&saved); overlayReady=overlayInit(); overlayRestore(&saved); overlayBegin=GetTickCount64();
    }
    if(!overlayReady || !sessionBudget(overlayBegin,GetTickCount64(),300001)) return;
    OverlayState saved; overlaySave(&saved);
    if(saved.drawFbo!=0 || saved.viewport[2]<512 || saved.viewport[3]<512) return;
    overlayUpdateLive();
#ifdef SR1_RETARGET_PREVIEW
    // No diagnostic inset or asset snapshot in the original-model profile.
    overlayRestore(&saved);return;
#endif
    // Normal gameplay retains the world mesh, not the diagnostic inset.
    // The world replacement uses this mesh/pose but does not need the legacy
    // inset pass. All RZB2 gameplay sessions require an explicit developer flag
    // to draw that diagnostic pass, including bounded regression sessions.
    if((GetFileAttributesW(PROBE_PATH(L"\\session-v2.enable"))!=INVALID_FILE_ATTRIBUTES||lifetimeRequested())&&GetFileAttributesW(PROBE_PATH(L"\\developer-inset.enable"))==INVALID_FILE_ATTRIBUTES){overlayRestore(&saved);return;}
    pglBindFramebuffer(GL_FRAMEBUFFER,overlayFbo); glViewport(0,0,512,512);
    overlayBlend(GL_FALSE); glDisable(GL_CULL_FACE); glDisable(GL_SCISSOR_TEST); glDisable(GL_FRAMEBUFFER_SRGB); glDisable(GL_RASTERIZER_DISCARD);
    glEnable(GL_DEPTH_TEST); glDepthFunc(GL_LESS); glDepthMask(GL_TRUE); pglColorMaski(0,GL_TRUE,GL_TRUE,GL_TRUE,GL_TRUE); glPolygonMode(GL_FRONT_AND_BACK,GL_FILL);
    glClearColor(.035f,.05f,.075f,1); glClearDepth(1); glClear(GL_COLOR_BUFFER_BIT|GL_DEPTH_BUFFER_BIT);
    pglUseProgram(overlayProgram); pglBindVertexArray(overlayVao); pglUniformMatrix4fv(pglGetUniformLocation(overlayProgram,"view"),1,GL_FALSE,overlayView);
    overlayAppearance();
    overlayGeometryDraw();
    if(!overlayReported) overlaySnapshot();
    pglBindFramebuffer(GL_DRAW_FRAMEBUFFER,0); pglBindFramebuffer(GL_READ_FRAMEBUFFER,overlayFbo);
    int side=saved.viewport[3]/3; if(side>512) side=512;
    int x=saved.viewport[0]+saved.viewport[2]-side-20,y=saved.viewport[1]+20;
    pglBlitFramebuffer(0,0,512,512,x,y,x+side,y+side,GL_COLOR_BUFFER_BIT,GL_NEAREST);
    overlayRestore(&saved);
    if(!overlayReported) {
        OverlayState after; overlaySave(&after);
        bool same=after.program==saved.program && after.vao==saved.vao && after.array==saved.array && after.drawFbo==saved.drawFbo && after.readFbo==saved.readFbo &&
            after.texture==saved.texture && after.textureArray==saved.textureArray && after.sampler==saved.sampler && after.pack==saved.pack && after.unpack==saved.unpack && after.renderbuffer==saved.renderbuffer &&
            !memcmp(after.viewport,saved.viewport,sizeof(saved.viewport)) && after.depth==saved.depth && after.blend==saved.blend && after.cull==saved.cull &&
            after.scissor==saved.scissor && after.srgb==saved.srgb && after.discard==saved.discard && after.depthFunc==saved.depthFunc && after.depthMask==saved.depthMask &&
            !memcmp(after.colorMask,saved.colorMask,sizeof(saved.colorMask)) && !memcmp(after.clearColor,saved.clearColor,sizeof(saved.clearColor)) && after.clearDepth==saved.clearDepth &&
            !memcmp(after.polygon,saved.polygon,sizeof(saved.polygon));
        logLine("OVERLAY first draw restored_state=%d duration_limit=300s; INSET ONLY",same); overlayReported=true;
        if(!same) overlayReady=false;
    }
}
