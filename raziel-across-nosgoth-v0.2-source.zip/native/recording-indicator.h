#include "report-path.h"
// A 13-pixel red circle in the upper-right corner of the default framebuffer.
// Only color pixels inside the circle are touched; GL write/scissor/clear state
// is restored. The optional heartbeat is independent of the 600s probe window.
static ULONGLONG indicatorLastPoll;
static bool indicatorActive;
static unsigned int indicatorTransitions;
static bool indicatorNativeRecording(ULONGLONG now) {
    if(InterlockedCompareExchange(&probeBoundedComplete,0,0))return false;
    return srInputRecording(now)||(cameraReady&&cameraSamples<120&&GetFileAttributesW(PROBE_PATH(L"\\camera-capture.enable"))!=INVALID_FILE_ATTRIBUTES)||
        (cameraReady&&lightSamples<120&&GetFileAttributesW(PROBE_PATH(L"\\light-capture.enable"))!=INVALID_FILE_ATTRIBUTES)||
        (lightDrawBegin&&now>=lightDrawBegin&&now-lightDrawBegin<60000&&lightDrawRecords<15360&&GetFileAttributesW(PROBE_PATH(L"\\light-draw.enable"))!=INVALID_FILE_ATTRIBUTES)||
        (drawBegin&&now>=drawBegin&&now-drawBegin<60000&&drawRecords<4096&&GetFileAttributesW(PROBE_PATH(L"\\draw-sr1.enable"))!=INVALID_FILE_ATTRIBUTES)||
        (latestReaver.tick&&now>=latestReaver.tick&&now-latestReaver.tick<1500&&GetFileAttributesW(PROBE_PATH(L"\\reaver-capture.enable"))!=INVALID_FILE_ATTRIBUTES);
}
static void indicatorDraw(HGLRC context) {
    if(!context||context!=overlayContext||!pglColorMaski)return;
    ULONGLONG now=GetTickCount64();
    if(now-indicatorLastPoll>=100){indicatorLastPoll=now;RecordingStatus status={0};
        bool active=indicatorNativeRecording(now)||(recordingReadStatus(GetCurrentProcessId(),&status)&&recordingStatusValid(&status,GetCurrentProcessId(),now));
        if(active!=indicatorActive&&indicatorTransitions<20){logLine("RECORDING_INDICATOR active=%d",active);++indicatorTransitions;}
        indicatorActive=active;
    }
    if(!indicatorActive)return;
    GLint fbo=0,viewport[4]={0},scissor[4]={0};GLboolean mask[4]={0};GLfloat clear[4]={0};
    glGetIntegerv(GL_DRAW_FRAMEBUFFER_BINDING,&fbo);glGetIntegerv(GL_VIEWPORT,viewport);
    if(fbo||viewport[2]<64||viewport[3]<64)return;
    glGetIntegerv(GL_SCISSOR_BOX,scissor);glGetBooleanv(GL_COLOR_WRITEMASK,mask);glGetFloatv(GL_COLOR_CLEAR_VALUE,clear);
    GLboolean scissorEnabled=glIsEnabled(GL_SCISSOR_TEST);
    pglColorMaski(0,GL_TRUE,GL_TRUE,GL_TRUE,GL_TRUE);glEnable(GL_SCISSOR_TEST);glClearColor(1,0,0,1);
    const int radius=6,cx=viewport[0]+viewport[2]-20,cy=viewport[1]+viewport[3]-20;
    for(int dy=-radius;dy<=radius;++dy){int half=(int)sqrtf((float)(radius*radius-dy*dy));glScissor(cx-half,cy+dy,half*2+1,1);glClear(GL_COLOR_BUFFER_BIT);}
    glClearColor(clear[0],clear[1],clear[2],clear[3]);pglColorMaski(0,mask[0],mask[1],mask[2],mask[3]);glScissor(scissor[0],scissor[1],scissor[2],scissor[3]);
    if(!scissorEnabled)glDisable(GL_SCISSOR_TEST);
}
