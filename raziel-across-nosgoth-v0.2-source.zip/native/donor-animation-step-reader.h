// SPDX-License-Identifier: GPL-3.0-or-later
#pragma once
#include "donor-state-sections.h"
typedef struct {
 uintptr_t opaqueActor,opaqueState,opaqueSection,opaqueResource;
 uint32_t section,clip,flags,callbackRva,workspace,cursor,time[4],rate;
} DonorAnimationStepMetadata;
// Pure scope test: only the current actor's three exact section addresses.
// Invalid metadata for such a candidate is still a counted refusal later.
static inline bool donorAnimationStepCurrentSection(uintptr_t actor,uintptr_t section){
 const Sheet_donorAnimationStepPolicy *p=&sheet_donorAnimationStepPolicy_bounded;
 if(!actor||actor%8||actor>UINTPTR_MAX-0x400||section<actor+p->actorOffset)return false;
 uintptr_t offset=section-actor-p->actorOffset;return offset%p->sectionStride==0&&offset/p->sectionStride<3;
}
static inline bool donorAnimationStepRead(void *c,DonorActionStateRead read,DonorActionStateCode code,uintptr_t base,uint32_t size,uintptr_t actor,uintptr_t section,DonorAnimationStepMetadata *out){
 memset(out,0,sizeof(*out));const Sheet_donorAnimationStepPolicy *p=&sheet_donorAnimationStepPolicy_bounded;
 if(!read||!code||base>UINTPTR_MAX-size||size<p->cursorRva+4||size<p->scratchSlotRva+8||!donorAnimationStepCurrentSection(actor,section))return false;
 uintptr_t offset=section-actor-p->actorOffset;
 uintptr_t current=0,state=0,owner=0,again=0,workspace[2]={0},resource=0,callback=0;uint32_t cursor[2]={0};uint8_t count=0;unsigned char first[44],last[44];
 if(!read(c,base+0xc5aa78,&current,8)||current!=actor||!read(c,actor+0x3f8,&state,8)||!state||state%8||!read(c,state,&owner,8)||owner!=actor||!read(c,actor+0x1b8,&count,1)||count!=3||!read(c,base+p->scratchSlotRva,&workspace[0],8)||!read(c,base+p->cursorRva,&cursor[0],4)||!read(c,section,first,sizeof(first))||first[1]!=offset/p->sectionStride||!read(c,section+0x50,&resource,8)||!resource||!read(c,section+0x30,&callback,8))return false;
 if(callback&&(callback<base||callback-base>=size||!code(c,callback,base)))return false;
 uintptr_t resourceAgain=0,callbackAgain=0;uint8_t countAgain=0;
 if(!read(c,section,last,sizeof(last))||memcmp(first,last,sizeof(first))||!read(c,section+0x50,&resourceAgain,8)||resourceAgain!=resource||!read(c,section+0x30,&callbackAgain,8)||callbackAgain!=callback||!read(c,actor+0x1b8,&countAgain,1)||countAgain!=count||!read(c,base+p->scratchSlotRva,&workspace[1],8)||workspace[0]!=workspace[1]||!read(c,base+p->cursorRva,&cursor[1],4)||cursor[0]!=cursor[1]||!read(c,actor+0x3f8,&again,8)||again!=state||!read(c,state,&owner,8)||owner!=actor||!read(c,base+0xc5aa78,&current,8)||current!=actor)return false;
 out->opaqueActor=actor;out->opaqueState=state;out->opaqueSection=section;out->opaqueResource=resource;out->section=(uint32_t)(offset/p->sectionStride);out->flags=first[0];uint16_t clip=0;memcpy(&clip,first+0x24,2);out->clip=clip;out->callbackRva=callback?(uint32_t)(callback-base):0;memcpy(out->time,first+4,16);memcpy(&out->rate,first+0x20,4);out->cursor=cursor[0];
 if(workspace[0]==base+p->scratchDefaultRva)out->workspace=1;
 else if(cursor[0]>=p->arenaChunkBytes&&cursor[0]<=p->arenaEndRva-p->arenaBeginRva&&cursor[0]%p->arenaChunkBytes==0&&workspace[0]==base+p->arenaBeginRva+cursor[0]-p->arenaChunkBytes)out->workspace=2;
 // Unknown/mid-transition workspace is recorded as0, never dereferenced.
 return true;
}
