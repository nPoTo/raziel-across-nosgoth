// SPDX-License-Identifier: GPL-3.0-or-later
#include <assert.h>
#include <stdio.h>
#include "sr1-skeleton-shared.h"
#include "sr1-native-pose-forward.h"
static float originalBones[66][13],localBones[66][13],scratch[66][13];static unsigned calls;static uintptr_t expected[8];
static uintptr_t original(uintptr_t a,uintptr_t b,uintptr_t c,uintptr_t d,uintptr_t e,uintptr_t f,uintptr_t g,uintptr_t h){
 const uintptr_t v[8]={a,b,c,d,e,f,g,h};for(unsigned i=0;i<8;i++)assert(v[i]==expected[i]);assert(d==(uintptr_t)scratch);assert(!memcmp((void *)d,originalBones,sizeof(originalBones)));calls++;return UINTPTR_MAX-7;
}
int main(int argc,char **argv){
 if(argc==2){FILE *f=fopen(argv[1],"rb");SkeletonSnapshot s;assert(f&&fread(&s,1,sizeof(s),f)==sizeof(s)&&fgetc(f)==EOF);fclose(f);assert(skeletonPacketValid(&s,12,1101)&&s.mode==2&&s.bones[65][10]==65);puts("JS/native3552byte skeleton-only packet interop PASS");return 0;}
 for(unsigned i=0;i<66;i++){originalBones[i][0]=originalBones[i][4]=originalBones[i][8]=1;originalBones[i][9]=(float)i;localBones[i][0]=localBones[i][4]=localBones[i][8]=1;localBones[i][10]=(float)i;}
 originalBones[0][0]=0;originalBones[0][1]=-1;originalBones[0][3]=1;originalBones[0][4]=0;originalBones[0][10]=100;originalBones[0][11]=200;originalBones[0][12]=300;
 float saved[66][13];memcpy(saved,originalBones,sizeof(saved));assert(skeletonRebase(scratch,originalBones,localBones));assert(!memcmp(scratch[0],originalBones[0],52));assert(scratch[3][10]==100&&scratch[3][11]==203&&scratch[3][12]==300&&scratch[3][9]==3);assert(!memcmp(saved,originalBones,sizeof(saved)));
 assert(!skeletonRebase(originalBones,originalBones,localBones));localBones[0][10]=1;assert(!skeletonRebase(scratch,originalBones,localBones));localBones[0][10]=0;localBones[12][0]=2;assert(!skeletonRebase(scratch,originalBones,localBones));localBones[12][0]=1;
 SkeletonSnapshot s={.magic=SKELETON_MAGIC,.version=1,.hostPid=12,.sourcePid=13,.writerPid=14,.mode=1,.epoch=1000,.tick=1100,.hostTick=1090,.sourceTick=1090,.sequence=1,.actor=10,.object=20,.model=30};memcpy(s.policyHash,skeletonPolicyHash,32);assert(skeletonPacketValid(&s,12,1101));assert(!skeletonPacketValid(&s,11,1101));assert(!skeletonPacketValid(&s,12,1251));s.mode=2;memcpy(s.bones,localBones,sizeof(localBones));assert(skeletonPacketValid(&s,12,1101));s.policyHash[0]^=1;assert(!skeletonPacketValid(&s,12,1101));s.policyHash[0]^=1;
 SkeletonShared shared={0};skeletonStore(&shared,&s);SkeletonSnapshot copy;assert(skeletonCopy(&shared,&copy));assert(!memcmp(&s,&copy,sizeof(s)));shared.sequence|=1;assert(!skeletonCopy(&shared,&copy));
 SkeletonAdmission a={0};assert(!skeletonAdmit(&a,&s,7,1101,true));s.mode=1;assert(skeletonAdmit(&a,&s,7,1101,true));s.mode=2;assert(!skeletonAdmit(&a,&s,7,1101,true));a.copies=20;assert(skeletonAdmit(&a,&s,7,1101,true));assert(!skeletonAdmit(&a,&s,8,1101,true));assert(!skeletonAdmit(&a,&s,7,1101,false));assert(!skeletonAdmit(&a,&s,7,1102,true));s.hostTick=s.sourceTick=1102;s.tick=1102;s.sequence++;assert(skeletonAdmit(&a,&s,7,1102,true));a.failed=true;assert(!skeletonAdmit(&a,&s,7,1102,true));
 // Reproduce the played starvation: foreign objects interleave at every frame,
 // while valid telemetry receipts precede that draw by46ms. Foreign calls may
 // not move the player's native-action boundary, including on another thread.
 a.failed=false;SkeletonAdmission old=a;unsigned admitted=0,oldAdmitted=0;
 for(uint64_t tick=1200;tick<7600;tick+=16){s.hostTick=s.sourceTick=s.tick=tick-46;s.sequence++;skeletonMarkDrawYield(&a,false,7,tick-1);skeletonMarkDrawYield(&a,true,8,tick-1);old.lastYield=tick-1;admitted+=skeletonAdmit(&a,&s,7,tick,true);oldAdmitted+=skeletonAdmit(&old,&s,7,tick,true);}
 assert(admitted==400&&oldAdmitted==0&&a.lastYield==1101);
 skeletonMarkDrawYield(&a,true,7,7700);assert(a.lastYield==7700);assert(!skeletonAdmit(&a,&s,7,7701,true));s.hostTick=s.sourceTick=s.tick=7701;s.sequence++;assert(skeletonAdmit(&a,&s,7,7701,true));
 assert(!skeletonRootMoved(originalBones[0],originalBones[0]));memcpy(scratch[0],originalBones[0],52);scratch[0][10]+=1;assert(skeletonRootMoved(originalBones[0],scratch[0]));scratch[0][10]=NAN;assert(!skeletonRootMoved(originalBones[0],scratch[0]));
 memcpy(scratch,originalBones,sizeof(scratch));uintptr_t args[8]={101,202,303,(uintptr_t)scratch,505,606,707,808};memcpy(expected,args,sizeof(args));assert(sr1NativePoseForward(original,args)==UINTPTR_MAX-7&&calls==1);assert(!memcmp(saved,originalBones,sizeof(saved)));
 puts("skeleton-only wire/seqlock/freshness/foreign identity/root rebase/padding/copy-before-align/reentry-thread/native yield-fresh rearm/original8slot once+return PASS; fixtures only");return 0;
}
