// SPDX-License-Identifier: GPL-3.0-or-later
#pragma once
#include <math.h>
#include <stdbool.h>
static inline float headingWrap(float a){return a-floorf(a);}
static inline float headingDelta(float to,float from){return headingWrap(to-from+.5f)-.5f;}
static inline bool headingRoot(const float m[16],float *out){
 for(unsigned i=0;i<16;i++)if(!isfinite(m[i]))return false;
 for(unsigned c=0;c<3;c++)for(unsigned d=c;d<3;d++){
  float dot=0;for(unsigned r=0;r<3;r++)dot+=m[c*4+r]*m[d*4+r];
  if(fabsf(dot-(c==d?1:0))>.03f)return false;
 }
 float det=m[0]*(m[5]*m[10]-m[9]*m[6])-m[4]*(m[1]*m[10]-m[9]*m[2])+m[8]*(m[1]*m[6]-m[5]*m[2]);
 if(fabsf(det-1)>.05f||hypotf(m[0],m[1])<.8f)return false;
 *out=headingWrap(atan2f(m[1],m[0])/(2*3.14159265358979323846f));return true;
}
// Preserve cached world-heading differences; do not flatten authored turns.
static inline bool headingRebase(const float before[5],float desired,float after[5]){
 if(!isfinite(desired))return false;
 for(unsigned i=0;i<5;i++)if(!isfinite(before[i])||fabsf(before[i])>4)return false;
 float delta=headingDelta(desired,before[0]);
 for(unsigned i=0;i<5;i++)after[i]=headingWrap(before[i]+delta);
 after[0]=headingWrap(desired);return true;
}
// After acquisition only a HOST heading change changes the external frame.
// Rejecting a native root turn must not repeatedly wind previous/cached angles.
static inline bool headingFollowFrame(const float before[5],float desired,float previousAuthority,float after[5]){
 if(!isfinite(desired)||!isfinite(previousAuthority))return false;
 for(unsigned i=0;i<5;i++)if(!isfinite(before[i])||fabsf(before[i])>4)return false;
 float delta=headingDelta(desired,previousAuthority);
 after[0]=headingWrap(desired);
 for(unsigned i=1;i<5;i++)after[i]=headingWrap(before[i]+delta);
 return true;
}
