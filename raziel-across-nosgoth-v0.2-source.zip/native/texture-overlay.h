// Bounded RZT1 diffuse sidecar. GPU textures and UV buffer belong only to our VAO.
static GLuint overlayDiffuse,overlayUvVbo;
static bool overlayTextured;
static bool overlayLoadTextures(uint32_t vertices) {
    unsigned char *packet=malloc(RM_APPEARANCE_BYTES);if(!packet)return false;
    if(!renderMemoryCopy(1,packet,RM_APPEARANCE_BYTES)){free(packet);return false;}
    uint32_t header[12];
    memcpy(header,packet,sizeof(header));
#ifdef SR1_RETARGET_PREVIEW
    if(vertices!=SR1_PROFILE_VERTICES||header[0]!=SR1_PROFILE_APPEARANCE_MAGIC||header[1]!=vertices||header[2]!=SR1_PROFILE_TEXTURES||header[3]!=512||memcmp(&header[4],sr1ProfileHash,32)){free(packet);return false;}
    const unsigned layersExpected=SR1_PROFILE_TEXTURES;
    size_t uvBytes=(size_t)vertices*12,pixelBytes=(size_t)512*512*SR1_PROFILE_TEXTURES;
#else
    static const unsigned char hash[32]={0x40,0x59,0xa8,0x3f,0x3d,0x47,0xa1,0x98,0x71,0x4b,0x21,0x5a,0xae,0xdc,0x21,0xc8,0x91,0x93,0x14,0xc7,0xd4,0xfc,0xd6,0x79,0x55,0x0f,0x89,0x60,0xc1,0xd8,0xda,0x0c};
    if(vertices!=24135 || header[0]!=0x31545a52 || header[1]!=vertices || header[2]!=8 || header[3]!=512 || memcmp(&header[4],hash,32)) {free(packet); return false;}
    const unsigned layersExpected=8;
    size_t uvBytes=(size_t)vertices*12,pixelBytes=(size_t)512*512*8*4;
#endif
    float *uv=malloc(uvBytes); unsigned char *pixels=malloc(pixelBytes);
    bool valid=uv && pixels;
    if(valid){memcpy(uv,packet+48,uvBytes);memcpy(pixels,packet+48+uvBytes,pixelBytes);}free(packet);
    if(valid) for(uint32_t i=0;i<vertices;i++) {
        float layer=uv[i*3+2];
        if(!isfinite(uv[i*3]) || !isfinite(uv[i*3+1]) || fabsf(uv[i*3])>128 || fabsf(uv[i*3+1])>128 || !isfinite(layer) || layer<0 || layer>=layersExpected || layer!=floorf(layer)) {valid=false; break;}
    }
    if(!valid) {free(uv); free(pixels); return false;}
#ifdef SR1_RETARGET_PREVIEW
    GLint compressedCount=0,formats[256];glGetIntegerv(GL_NUM_COMPRESSED_TEXTURE_FORMATS,&compressedCount);
    bool bc7=false;if(compressedCount>0&&compressedCount<=256){glGetIntegerv(GL_COMPRESSED_TEXTURE_FORMATS,formats);for(int i=0;i<compressedCount;i++)if(formats[i]==GL_COMPRESSED_RGBA_BPTC_UNORM)bc7=true;}
    PROC address=wglGetProcAddress("glCompressedTexImage3D");
    if(!bc7||!address||(uintptr_t)address<=3||(uintptr_t)address==UINTPTR_MAX){free(uv);free(pixels);return false;}
    PFNGLCOMPRESSEDTEXIMAGE3DPROC compressedImage=(PFNGLCOMPRESSEDTEXIMAGE3DPROC)address;
#endif
    pglGenBuffers(1,&overlayUvVbo); pglBindBuffer(GL_ARRAY_BUFFER,overlayUvVbo); pglBufferData(GL_ARRAY_BUFFER,(GLsizeiptr)uvBytes,uv,GL_STATIC_DRAW);
    pglEnableVertexAttribArray(1); pglVertexAttribPointer(1,3,GL_FLOAT,GL_FALSE,12,NULL);
    glGenTextures(1,&overlayDiffuse); glBindTexture(GL_TEXTURE_2D_ARRAY,overlayDiffuse); pglBindBuffer(GL_PIXEL_UNPACK_BUFFER,0);
    const GLenum states[]={GL_UNPACK_ALIGNMENT,GL_UNPACK_ROW_LENGTH,GL_UNPACK_IMAGE_HEIGHT,GL_UNPACK_SKIP_PIXELS,GL_UNPACK_SKIP_ROWS,GL_UNPACK_SKIP_IMAGES};
    GLint unpack[6]; for(int i=0;i<6;i++) {glGetIntegerv(states[i],&unpack[i]); glPixelStorei(states[i],i==0?1:0);}
#ifdef SR1_RETARGET_PREVIEW
    compressedImage(GL_TEXTURE_2D_ARRAY,0,GL_COMPRESSED_RGBA_BPTC_UNORM,512,512,(GLsizei)layersExpected,0,(GLsizei)pixelBytes,pixels);
#else
    pglTexImage3D(GL_TEXTURE_2D_ARRAY,0,GL_RGBA8,512,512,8,0,GL_RGBA,GL_UNSIGNED_BYTE,pixels);
#endif
    for(int i=0;i<6;i++) glPixelStorei(states[i],unpack[i]);
    glTexParameteri(GL_TEXTURE_2D_ARRAY,GL_TEXTURE_MIN_FILTER,GL_LINEAR); glTexParameteri(GL_TEXTURE_2D_ARRAY,GL_TEXTURE_MAG_FILTER,GL_LINEAR);
    glTexParameteri(GL_TEXTURE_2D_ARRAY,GL_TEXTURE_BASE_LEVEL,0); glTexParameteri(GL_TEXTURE_2D_ARRAY,GL_TEXTURE_MAX_LEVEL,0);
    glTexParameteri(GL_TEXTURE_2D_ARRAY,GL_TEXTURE_WRAP_S,GL_REPEAT); glTexParameteri(GL_TEXTURE_2D_ARRAY,GL_TEXTURE_WRAP_T,GL_REPEAT);
    GLint width=0,height=0,layers=0; glGetTexLevelParameteriv(GL_TEXTURE_2D_ARRAY,0,GL_TEXTURE_WIDTH,&width);
    glGetTexLevelParameteriv(GL_TEXTURE_2D_ARRAY,0,GL_TEXTURE_HEIGHT,&height); glGetTexLevelParameteriv(GL_TEXTURE_2D_ARRAY,0,GL_TEXTURE_DEPTH,&layers);
    free(uv); free(pixels); valid=width==512 && height==512 && layers==(GLint)layersExpected;
    logLine("TEXTURES diffuse layers=%d width=%d height=%d verified=%d isolated_sampler=%d; normal/specular/glow not implemented",layers,width,height,valid,overlayBindSampler!=NULL);
    return valid;
}
static void overlayAppearance(void) {
    GLint active=0; glGetIntegerv(GL_ACTIVE_TEXTURE,&active);
    if(overlayBindSampler) overlayBindSampler((GLuint)(active-GL_TEXTURE0),0);
    if(overlayTextured) glBindTexture(GL_TEXTURE_2D_ARRAY,overlayDiffuse);
    pglUniform1i(pglGetUniformLocation(overlayProgram,"diffuse"),active-GL_TEXTURE0);
    pglUniform1i(pglGetUniformLocation(overlayProgram,"textured"),overlayTextured?1:0);
}
