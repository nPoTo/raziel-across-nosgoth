// Read-only, build-specific Defiance telemetry. No injection or game writes.
// SPDX-License-Identifier: GPL-3.0-or-later
#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <tlhelp32.h>
#include <bcrypt.h>
#include <stdbool.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <wchar.h>
#include <math.h>
#include "source-camera-shared.h"
#include "capture-cadence.h"
#include "donor-action-state.h"
#include "donor-state-sections.h"
#include "donor-block-targets.h"
#ifdef DONOR_ANIMATION_SELECTION_OBSERVER
#include "donor-animation-selection-reader.h"
#endif
#ifdef DONOR_ANIMATION_EVENT_OBSERVER
#include "donor-animation-event-reader.h"
#endif

static bool donorStateRead(void *context,uintptr_t address,void *out,SIZE_T size){SIZE_T n=0;return ReadProcessMemory((HANDLE)context,(LPCVOID)address,out,size,&n)&&n==size;}
static bool donorStateCode(void *context,uintptr_t address,uintptr_t base){
 MEMORY_BASIC_INFORMATION m={0};return VirtualQueryEx((HANDLE)context,(LPCVOID)address,&m,sizeof(m))==sizeof(m)&&m.State==MEM_COMMIT&&m.Type==MEM_IMAGE&&(uintptr_t)m.AllocationBase==base&&!(m.Protect&(PAGE_GUARD|PAGE_NOACCESS))&&(m.Protect&(PAGE_EXECUTE|PAGE_EXECUTE_READ|PAGE_EXECUTE_READWRITE|PAGE_EXECUTE_WRITECOPY));
}

static const char *supportedHash = "fc6a406ff7ac9b5eb7788dc7a65d335e1c1aad9236618112671975b71d2daddc";
static bool hashFile(const wchar_t *file, char output[65]) {
    HANDLE h = CreateFileW(file, GENERIC_READ, FILE_SHARE_READ | FILE_SHARE_WRITE | FILE_SHARE_DELETE,
        NULL, OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, NULL);
    if (h == INVALID_HANDLE_VALUE) return false;
    BCRYPT_ALG_HANDLE alg = NULL; BCRYPT_HASH_HANDLE hash = NULL;
    unsigned char digest[32], buffer[65536]; DWORD read = 0; bool ok = false;
    if (BCryptOpenAlgorithmProvider(&alg, BCRYPT_SHA256_ALGORITHM, NULL, 0) < 0) goto done;
    if (BCryptCreateHash(alg, &hash, NULL, 0, NULL, 0, 0) < 0) goto done;
    for (;;) {
        if (!ReadFile(h, buffer, sizeof(buffer), &read, NULL)) goto done;
        if (!read) break;
        if (BCryptHashData(hash, buffer, read, 0) < 0) goto done;
    }
    if (BCryptFinishHash(hash, digest, sizeof(digest), 0) < 0) goto done;
    for (int i = 0; i < 32; ++i) sprintf(output + i * 2, "%02x", digest[i]);
    output[64] = 0; ok = true;
done:
    if (hash) BCryptDestroyHash(hash);
    if (alg) BCryptCloseAlgorithmProvider(alg, 0);
    CloseHandle(h); return ok;
}
static bool readAt(HANDLE p, uintptr_t address, void *out, SIZE_T size) {
    SIZE_T actual = 0;
    return address && ReadProcessMemory(p, (LPCVOID)address, out, size, &actual) && actual == size;
}
static uint32_t word(const unsigned char *p) { uint32_t v; memcpy(&v,p,4); return v; }
static float real(const unsigned char *p) { float v; memcpy(&v,p,4); return v; }
static uintptr_t pointer(const unsigned char *p) { uintptr_t v; memcpy(&v,p,8); return v; }
static bool motionRead(void *ctx,uintptr_t at,void *out,size_t size){return readAt((HANDLE)ctx,at,out,size);}
#include "donor-motion-reader.h"
#include "donor-camera-core-proof.h"
#include "recording-status.h"
static bool razielModel(HANDLE p, uintptr_t context, uintptr_t *model) {
    uintptr_t namePointer=0; char name[7];
    return readAt(p,context,&namePointer,8) && readAt(p,namePointer,name,sizeof(name)) &&
        !memcmp(name,"raziel",7) && readAt(p,context+8,model,8) && *model;
}
static uintptr_t findContext(HANDLE p, uintptr_t base) {
    uintptr_t found=0, model=0;
    for(unsigned int i=0;i<512;++i) {
        uintptr_t at=base+0xc88020+i*64;
        if(razielModel(p,at,&model)) { if(found) return 0; found=at; }
    }
    return found;
}
static bool number(const wchar_t *text, unsigned long max, unsigned long *result) {
    wchar_t *end; if (!*text || *text < L'0' || *text > L'9') return false;
    *result = wcstoul(text,&end,10); return !*end && *result && *result <= max;
}
static bool affine(const float *v) {
    for(int i=0;i<16;++i) if(!isfinite(v[i])) return false;
    return fabsf(v[3])<0.00001f && fabsf(v[7])<0.00001f && fabsf(v[11])<0.00001f && fabsf(v[15]-1)<0.00001f;
}
static void matrixJson(FILE *out,const float *v) {
    fputc('[',out); for(int i=0;i<16;++i) { if(i) fputc(',',out); fprintf(out,"%.9g",v[i]); } fputc(']',out);
}
static void poseJson(FILE *out,HANDLE p,uintptr_t globalAddress,uintptr_t instance,const unsigned char *bytes) {
    uintptr_t address=pointer(bytes+0x60), rootAddress=pointer(bytes+0x70), after=0, rootAfter=0, instanceAfter=0, modelAfter=0;
    uintptr_t animationModel=pointer(bytes+0x1c0), modelList=0; uint16_t modelCount=0;
    uint32_t counts[2]={0}; unsigned int sectionEnd=0;
    float matrices[128][16], root[16];
    bool member=false;
    bool metadata=readAt(p,pointer(bytes+0x88)+0x20,&modelCount,2) && modelCount && modelCount<=16 &&
        readAt(p,pointer(bytes+0x88)+0x28,&modelList,8) && readAt(p,animationModel+4,counts,sizeof(counts));
    if(metadata) for(unsigned int i=0;i<modelCount;++i) {
        uintptr_t candidate=0; if(readAt(p,modelList+i*8,&candidate,8) && candidate==animationModel) member=true;
    }
    // Candidate count is cross-checked against all three animation section byte ranges.
    for(unsigned int i=0;i<3;++i) {
        unsigned int offset=0x1d0+i*0x68;
        unsigned int end=bytes[offset+2]+bytes[offset+3]; if(end>sectionEnd) sectionEnd=end;
    }
    unsigned int count=counts[0]+counts[1];
    bool bounded=counts[0] && counts[0]<=128 && counts[1]<=128 && count<=128 && counts[0]==sectionEnd;
    unsigned char segments[128][40]; int32_t parents[128]; uintptr_t segmentList=0;
    bool hierarchy=metadata && member && bounded && readAt(p,animationModel+0x10,&segmentList,8) &&
        readAt(p,segmentList,segments,counts[0]*sizeof(segments[0]));
    if(hierarchy) for(unsigned int i=0;i<counts[0];++i) {
        memcpy(&parents[i],segments[i]+24,4);
        if(parents[i]<-1 || parents[i]>=(int32_t)counts[0] || parents[i]==(int32_t)i) hierarchy=false;
        for(unsigned int j=0;j<3;++j) if(!isfinite(real(segments[i]+j*4))) hierarchy=false;
        if(fabsf(real(segments[i]+12)-1)>0.00001f) hierarchy=false;
    }
    if(hierarchy) for(unsigned int i=0;i<counts[0];++i) {
        int32_t at=(int32_t)i; unsigned int depth=0;
        while(at!=-1 && depth<=counts[0]) { at=parents[at]; ++depth; }
        if(at!=-1) hierarchy=false;
    }
    // Preserve the original short-circuit checks and admission. Report the
    // first failed boundary; never renew or reuse a previous pose here.
    const char *readReason="ok";
    int invalidMatrix=-1;
    if(!metadata) readReason="metadata_read";
    else if(!member) readReason="model_membership";
    else if(!bounded) readReason="matrix_count";
    else if(!address||!rootAddress) readReason="missing_buffer";
    else if(!readAt(p,address,matrices,count*sizeof(matrices[0]))) readReason="matrix_read";
    else if(!readAt(p,rootAddress,root,sizeof(root))) readReason="root_read";
    else if(!readAt(p,instance+0x60,&after,8)) readReason="matrix_pointer_read";
    else if(after!=address) readReason="matrix_pointer_changed";
    else if(!readAt(p,instance+0x70,&rootAfter,8)) readReason="root_pointer_read";
    else if(rootAfter!=rootAddress) readReason="root_pointer_changed";
    else if(!readAt(p,instance+0x88,&modelAfter,8)) readReason="model_pointer_read";
    else if(modelAfter!=pointer(bytes+0x88)) readReason="model_changed";
    else if(!readAt(p,globalAddress,&instanceAfter,8)) readReason="actor_pointer_read";
    else if(instanceAfter!=instance) readReason="actor_changed";
    else if(!affine(root)) readReason="root_affine";
    bool valid=!strcmp(readReason,"ok");
    if(valid) for(unsigned int i=0;i<count;++i) if(!affine(matrices[i])) {valid=false;readReason="matrix_affine";invalidMatrix=(int)i;break;}
    fprintf(out,",\"poseCandidate\":{\"valid\":%s,\"readReason\":\"%s\",\"invalidMatrix\":%d,\"matrixLimit\":128,\"completeSkeleton\":false",valid?"true":"false",readReason,invalidMatrix);
    if(valid) {
        fprintf(out,",\"baseCountCandidate\":%u,\"extraCountCandidate\":%u,\"matrixCountCandidate\":%u,\"buffer\":\"0x%llx\",\"rootBuffer\":\"0x%llx\",\"rootMatrix\":",counts[0],counts[1],count,(unsigned long long)address,(unsigned long long)rootAddress);
        matrixJson(out,root); fprintf(out,",\"matrices\":[");
        for(unsigned int i=0;i<count;++i) { if(i) fputc(',',out); matrixJson(out,matrices[i]); }
        fputc(']',out);
        fprintf(out,",\"baseHierarchyCandidate\":{\"valid\":%s",hierarchy?"true":"false");
        if(hierarchy) {
            fprintf(out,",\"parents\":[");
            for(unsigned int i=0;i<counts[0];++i) { if(i) fputc(',',out); fprintf(out,"%d",parents[i]); }
            fprintf(out,"],\"bindLocalPositions\":[");
            for(unsigned int i=0;i<counts[0];++i) {
                if(i) fputc(',',out);
                fprintf(out,"[%.9g,%.9g,%.9g]",real(segments[i]),real(segments[i]+4),real(segments[i]+8));
            }
            fputc(']',out);
        }
        fputc('}',out);
    }
    fputc('}',out);
}
int wmain(int argc, wchar_t **argv) {
    unsigned long pid, samples, interval, skeletonMaxSamples=7200;uint64_t skeletonMaxWall=120000;
    bool captureAppearance=argc==9&&!wcscmp(argv[8],L"--appearance");
#ifdef SR1_SKELETON_CADENCE60
    bool captureSkeleton60=argc==9&&!wcscmp(argv[8],L"--skeleton-60");
    const Sheet_skeletonCadencePolicy *cadencePolicy=&sheet_skeletonCadencePolicy_capture;skeletonMaxSamples=(unsigned long)cadencePolicy->maxSamples;skeletonMaxWall=(uint64_t)cadencePolicy->maxWallMs;
    if(cadencePolicy->targetHz!=60||!((cadencePolicy->maxSamples==7200&&cadencePolicy->maxWallMs==120000)||(cadencePolicy->maxSamples==8400&&cadencePolicy->maxWallMs==140000)||(cadencePolicy->maxSamples==12000&&cadencePolicy->maxWallMs==200000))||!cadencePolicy->helperOnly||cadencePolicy->gameWrites)return 1;
#else
    bool captureSkeleton60=false;
#endif
    bool publishCamera=argc==8&&!wcscmp(argv[7],L"--camera-live");
    bool captureCamera=argc==8&&!wcscmp(argv[5],L"--pose")&&!wcscmp(argv[6],L"--input")&&(!wcscmp(argv[7],L"--camera")||publishCamera);
    bool captureMotion=(argc==8||captureAppearance||captureSkeleton60)&&!wcscmp(argv[5],L"--pose")&&!wcscmp(argv[6],L"--input")&&!wcscmp(argv[7],L"--motion");
    // Scalar action discovery reads existing input/animation words, without
    // reading or outputting pose matrices, hierarchies or appearance buffers.
#ifdef DONOR_ANIMATION_EVENT_OBSERVER
    bool captureEvents=argc==6&&!wcscmp(argv[5],L"--animation-events");
#else
    bool captureEvents=false;
#endif
#ifdef DONOR_ANIMATION_SELECTION_OBSERVER
    bool captureSelection=(argc==6&&!wcscmp(argv[5],L"--selection"))||captureEvents;
#else
    bool captureSelection=false;
#endif
    bool captureActions=(argc==6&&!wcscmp(argv[5],L"--actions"))||captureSelection||captureEvents;
    bool captureInput=captureActions||((argc==7||captureMotion||captureCamera) && !wcscmp(argv[5],L"--pose") && !wcscmp(argv[6],L"--input"));
    bool capturePose=!captureActions&&(argc==6 || captureInput) && !wcscmp(argv[5],L"--pose");
    if ((argc != 5 && !capturePose && !captureActions) || !number(argv[1],0xffffffffUL,&pid) || !number(argv[2],captureSkeleton60?skeletonMaxSamples:publishCamera?8400:(unsigned long)(GetEnvironmentVariableW(L"RAZIEL_LIFETIME_TEST",NULL,0)?sheet_sessionLifetime_session.maxSamples:sheet_diagnosticLimits_controls.maxSamples),&samples) || !number(argv[3],1000,&interval)) {
        fprintf(stderr,"Usage: raziel-telemetry PID SAMPLES(1..3600) INTERVAL_MS(1..1000) OUTPUT_JSONL [--actions | --pose [--input [--motion [--appearance]]]]\n"); return 1;
    }
    HANDLE p = OpenProcess(PROCESS_VM_READ | PROCESS_QUERY_LIMITED_INFORMATION,FALSE,pid);
    if (!p) { fprintf(stderr,"OpenProcess: %lu\n",GetLastError()); return 2; }
    wchar_t path[32768]; DWORD length = ARRAYSIZE(path); char hash[65];
    wchar_t expectedPath[32768];DWORD expectedLength=GetEnvironmentVariableW(L"RAZIEL_DEFIANCE_EXE",expectedPath,ARRAYSIZE(expectedPath));
    if (!QueryFullProcessImageNameW(p,0,path,&length) ||
        (expectedLength && (expectedLength>=ARRAYSIZE(expectedPath)||_wcsicmp(path,expectedPath))) ||
        !wcsrchr(path,L'\\') || _wcsicmp(wcsrchr(path,L'\\')+1,L"defiance.exe") || !hashFile(path,hash) || strcmp(hash,supportedHash)) {
        fprintf(stderr,"Refusing unsupported executable path or SHA-256.\n"); CloseHandle(p); return 3;
    }
    HANDLE modules = CreateToolhelp32Snapshot(TH32CS_SNAPMODULE,pid);
    MODULEENTRY32W m = {0}; m.dwSize = sizeof(m); uintptr_t base = 0; DWORD imageSize = 0;
    if (modules != INVALID_HANDLE_VALUE) {
        if (Module32FirstW(modules,&m)) do {
            if (!_wcsicmp(m.szExePath,path)) { base = (uintptr_t)m.modBaseAddr; imageSize = m.modBaseSize; break; }
        } while (Module32NextW(modules,&m));
        CloseHandle(modules);
    }
    // RVAs apply only to the exact hash above. Resolve ASLR every invocation.
    if (!base || imageSize < 0xc88020+512*64) { CloseHandle(p); return 4; }
    if(captureMotion&&imageSize<0x10aa658){CloseHandle(p);return 4;}
    // '-' keeps live game data in an anonymous pipe, never an asset file.
    bool pipeOutput=!wcscmp(argv[4],L"-");
    if(captureSkeleton60&&(!pipeOutput||!captureMotion||interval!=16)){CloseHandle(p);return 5;}
    if(captureSelection&&!pipeOutput){fputs("Selection observation requires anonymous-pipe output\n",stderr);CloseHandle(p);return 5;}
    FILETIME processCreated={0},processExited={0},processKernel={0},processUser={0};
    if(captureEvents&&!GetProcessTimes(p,&processCreated,&processExited,&processKernel,&processUser)){CloseHandle(p);return 5;}
    FILE *out = pipeOutput ? stdout : _wfopen(argv[4],L"wb"); if (!out) { CloseHandle(p); return 5; }
    fprintf(out,"{\"type\":\"session\",\"schema\":1,\"pid\":%lu,\"sha256\":\"%s\",\"base\":\"0x%llx\",\"mode\":\"read-only\",\"semantics\":\"position-candidate; animation fields raw\"",pid,hash,(unsigned long long)base);
    if(captureEvents)fprintf(out,",\"processCreation\":\"%llu\"",(unsigned long long)(((uint64_t)processCreated.dwHighDateTime<<32)|processCreated.dwLowDateTime));
    fputs("}\n",out);
    unsigned int valid = 0;
    uintptr_t context=0;
    uint64_t cameraStart=GetTickCount64(),cameraHeartbeat=0;
    HANDLE cameraMapping=NULL;SourceCameraShared *cameraView=NULL;
    if(publishCamera){wchar_t cameraName[96];sourceCameraName(cameraName,pid);SetLastError(0);cameraMapping=CreateFileMappingW(INVALID_HANDLE_VALUE,NULL,PAGE_READWRITE,0,sizeof(SourceCameraShared),cameraName);bool exists=GetLastError()==ERROR_ALREADY_EXISTS;
        if(cameraMapping&&!exists)cameraView=MapViewOfFile(cameraMapping,FILE_MAP_READ|FILE_MAP_WRITE,0,0,sizeof(SourceCameraShared));
        if(!cameraView){if(cameraMapping)CloseHandle(cameraMapping);fclose(out);CloseHandle(p);return 7;}
    }
    LARGE_INTEGER cadenceFrequency,cadenceOrigin;
    HANDLE cadenceTimer=NULL;
    if(publishCamera||captureSkeleton60){
        if(!QueryPerformanceFrequency(&cadenceFrequency)||!QueryPerformanceCounter(&cadenceOrigin)){if(cameraView)UnmapViewOfFile(cameraView);if(cameraMapping)CloseHandle(cameraMapping);fclose(out);CloseHandle(p);return 8;}
        cadenceTimer=CreateWaitableTimerExW(NULL,NULL,2,TIMER_ALL_ACCESS);
        if(!cadenceTimer)cadenceTimer=CreateWaitableTimerW(NULL,FALSE,NULL);
    }
    for (unsigned long seq = 0; seq < samples; ++seq) {
        if(captureSkeleton60&&GetTickCount64()-cameraStart>=skeletonMaxWall)break;
        if(captureCamera){uint64_t now=GetTickCount64();if(now-cameraStart>=138000)break;if(!cameraHeartbeat||now-cameraHeartbeat>=250){recordingWriteStatus(pid,(uint32_t)((now-cameraStart)/100)+1,1380);cameraHeartbeat=now;}}
        uintptr_t instance = 0, after = 0, model = 0;
        unsigned char bytes[1024];
        if (!context || !razielModel(p,context,&model)) context=findContext(p,base);
        bool ok = readAt(p,base+0xc5aa78,&instance,8) && readAt(p,instance,bytes,sizeof(bytes)) &&
            context && razielModel(p,context,&model) && pointer(bytes+0x88)==model &&
            readAt(p,base+0xc5aa78,&after,8) && after==instance;
        if (ok) for (unsigned int offset=0x20;offset<=0x38;offset+=4) {
            if (offset==0x2c) continue;
            if (!isfinite(real(bytes+offset))) ok=false;
        }
        fprintf(out,"{\"type\":\"sample\",\"sequence\":%lu,\"tickMs\":%llu,\"valid\":%s",seq,(unsigned long long)GetTickCount64(),ok?"true":"false");
        DWORD foregroundPid=0;
        GetWindowThreadProcessId(GetForegroundWindow(),&foregroundPid);
        fprintf(out,",\"foregroundPid\":%lu",foregroundPid);
        if(captureInput) {
            int16_t slots[26],axes[4];
            bool inputOk=readAt(p,base+0x113ec00,slots,sizeof(slots)) && readAt(p,base+0x17c2e10,axes,sizeof(axes));
            fprintf(out,",\"inputCandidate\":{\"valid\":%s",inputOk?"true":"false");
            if(inputOk) {
                fprintf(out,",\"buttonSlots\":[");
                for(int i=0;i<26;++i) {if(i)fputc(',',out);fprintf(out,"%d",slots[i]);}
                fprintf(out,"],\"stickAxes\":[%d,%d,%d,%d]",axes[0],axes[1],axes[2],axes[3]);
            }
            fputc('}',out);
        }
        if (ok) {
            ++valid;
            fprintf(out,",\"instance\":\"0x%llx\",\"model\":\"0x%llx\",\"positionCandidate\":[%.9g,%.9g,%.9g],\"previousPositionCandidate\":[%.9g,%.9g,%.9g],\"animationRaw\":[",
                (unsigned long long)instance,(unsigned long long)model,real(bytes+0x20),real(bytes+0x24),real(bytes+0x28),real(bytes+0x30),real(bytes+0x34),real(bytes+0x38));
            for (int section=0;section<3;++section) {
                unsigned int offset=0x1d0+(unsigned int)section*0x68;
                if(section) fputc(',',out);
                // Preserve bit patterns; no unverified meanings assigned to IDs/clocks.
                fprintf(out,"{\"section\":%d,\"word0\":%u,\"word4\":%u,\"word8\":%u,\"word24\":%u,\"word28\":%u}",section,word(bytes+offset),word(bytes+offset+4),word(bytes+offset+8),word(bytes+offset+0x24),word(bytes+offset+0x28));
            }
            fputc(']',out);
            if(captureActions){
                DonorActionState state=donorActionStateRead(p,donorStateRead,donorStateCode,base,imageSize,instance,base+0xc5aa78);
                fprintf(out,",\"nativeActionState\":{\"valid\":%s",state.valid?"true":"false");
                if(state.valid){fprintf(out,",\"firstRva\":\"0x%x\",\"secondValid\":%s",state.firstRva,state.secondValid?"true":"false");if(state.secondValid)fprintf(out,",\"secondRva\":\"0x%x\"",state.secondRva);}
                DonorStateSections sections=donorStateSectionsRead(p,donorStateRead,donorStateCode,base,imageSize,instance,base+0xc5aa78);
                if(!state.valid||sections.sections[0].firstRva!=state.firstRva||sections.sections[0].secondValid!=state.secondValid||(state.secondValid&&sections.sections[0].secondRva!=state.secondRva))sections.valid=false;
                fprintf(out,",\"layout\":{\"valid\":%s",sections.valid?"true":"false");
                if(sections.valid){fprintf(out,",\"ownerMatches\":%s,\"sections\":[",sections.ownerMatches?"true":"false");for(unsigned k=0;k<3;k++){if(k)fputc(',',out);fprintf(out,"{\"section\":%u,\"firstRva\":\"0x%x\",\"secondValid\":%s",k,sections.sections[k].firstRva,sections.sections[k].secondValid?"true":"false");if(sections.sections[k].secondValid)fprintf(out,",\"secondRva\":\"0x%x\"",sections.sections[k].secondRva);fputc('}',out);}fputc(']',out);}
                fputc('}',out);
                fputc('}',out);
                DonorBlockTargets targets=donorBlockTargetsRead(p,donorStateRead,donorStateCode,base,imageSize,instance);
                fprintf(out,",\"nativeBlockTargets\":{\"valid\":%s",targets.valid?"true":"false");
                if(targets.valid)fprintf(out,",\"flagsMask\":%u,\"engagementPresent\":%s,\"entryPresent\":%s,\"heldPresent\":%s,\"slotsEqual\":%s,\"entryCallbackKnown\":%s,\"heldCallbackKnown\":%s,\"entryCallbackRva\":%u,\"heldCallbackRva\":%u,\"relationKnown\":%s,\"relationEqual\":%s,\"ownerRelationZero\":%s,\"targetRelationZero\":%s",targets.flagsMask,targets.engagementPresent?"true":"false",targets.entryPresent?"true":"false",targets.heldPresent?"true":"false",targets.slotsEqual?"true":"false",targets.entryCallbackKnown?"true":"false",targets.heldCallbackKnown?"true":"false",targets.entryCallbackRva,targets.heldCallbackRva,targets.relationKnown?"true":"false",targets.relationEqual?"true":"false",targets.ownerRelationZero?"true":"false",targets.targetRelationZero?"true":"false");
                if(targets.valid)fprintf(out,",\"entryHandlerKnown\":%s,\"heldHandlerKnown\":%s,\"entryHandlerRva\":%u,\"heldHandlerRva\":%u",targets.entryHandlerKnown?"true":"false",targets.heldHandlerKnown?"true":"false",targets.entryHandlerRva,targets.heldHandlerRva);
                fputc('}',out);
#ifdef DONOR_ANIMATION_SELECTION_OBSERVER
                if(captureSelection){
#ifdef DONOR_ANIMATION_EVENT_OBSERVER
                    DonorAnimationEventContext eventContext={0};
                    if(captureEvents)eventContext=donorAnimationEventRead(p,donorStateRead,donorStateCode,base,imageSize,instance);
                    DonorAnimationSelection selection=captureEvents?eventContext.selection:donorAnimationSelectionRead(p,donorStateRead,donorStateCode,base,imageSize,instance);
#else
                    DonorAnimationSelection selection=donorAnimationSelectionRead(p,donorStateRead,donorStateCode,base,imageSize,instance);
#endif
                    if(!sections.valid||!sections.ownerMatches)selection.valid=false;
                    if(selection.valid)for(unsigned k=0;k<3;k++)if(selection.sections[k].state.firstRva!=sections.sections[k].firstRva||selection.sections[k].state.secondValid!=sections.sections[k].secondValid||selection.sections[k].state.secondRva!=sections.sections[k].secondRva)selection.valid=false;
                    fprintf(out,",\"nativeAnimationSelection\":{\"valid\":%s",selection.valid?"true":"false");
                    if(selection.valid){fputs(",\"sections\":[",out);for(unsigned k=0;k<3;k++){const DonorAnimationSelectionSection *s=&selection.sections[k];if(k)fputc(',',out);fprintf(out,"{\"section\":%u,\"firstCallbackRva\":%u,\"secondCallbackKnown\":%s,\"secondCallbackRva\":%u,\"selectionKeyRaw\":%u,\"animationId\":%u,\"descriptorPresent\":%s}",k,s->state.firstRva,s->state.secondValid?"true":"false",s->state.secondRva,s->selectionKeyRaw,(unsigned)s->animationId,s->descriptorPresent?"true":"false");}fputc(']',out);}fputc('}',out);
#ifdef DONOR_ANIMATION_EVENT_OBSERVER
                    if(captureEvents){
                        bool eventValid=selection.valid&&eventContext.valid;
                        fprintf(out,",\"nativeAnimationEvents\":{\"valid\":%s",eventValid?"true":"false");
                        if(eventValid){fputs(",\"sections\":[",out);for(unsigned k=0;k<3;k++){const DonorAnimationEventSection *s=&eventContext.sections[k];if(k)fputc(',',out);fprintf(out,"{\"section\":%u,\"callbackPresent\":%s,\"callbackKnown\":%s,\"callbackRva\":%u,\"contextPresent\":%s,\"sourceObjectPresent\":%s,\"sourceObjectMatchesActor\":%s,\"eventTablePresent\":%s,\"clipResourcePresent\":%s,\"blendPresent\":%s}",k,s->callbackPresent?"true":"false",s->callbackKnown?"true":"false",s->callbackRva,s->contextPresent?"true":"false",s->sourceObjectPresent?"true":"false",s->sourceObjectMatchesActor?"true":"false",s->eventTablePresent?"true":"false",s->clipResourcePresent?"true":"false",s->blendPresent?"true":"false");}fputc(']',out);}fputc('}',out);
                    }
#endif
                }
#endif
            }
            if(capturePose){
                poseJson(out,p,base+0xc5aa78,instance,bytes);
                // Reuse the already proved read-only owner/section reader.
                // Scalar compatibility only: do not dispatch or infer contact.
                DonorStateSections sections=donorStateSectionsRead(p,donorStateRead,donorStateCode,base,imageSize,instance,base+0xc5aa78);
                bool stateValid=sections.valid&&sections.ownerMatches;
                fprintf(out,",\"sourcePoseState\":{\"valid\":%s",stateValid?"true":"false");
                if(stateValid)fprintf(out,",\"primary\":[%u,%u,%u],\"secondary\":[%u,%u,%u]",sections.sections[0].firstRva,sections.sections[1].firstRva,sections.sections[2].firstRva,sections.sections[0].secondRva,sections.sections[1].secondRva,sections.sections[2].secondRva);
                fputc('}',out);
            }
            if(captureCamera){
                unsigned char camera[DONOR_CAMERA_CORE_BYTES],again[DONOR_CAMERA_CORE_BYTES];uintptr_t owner=0;
                bool cameraOk=readAt(p,base+DONOR_CAMERA_CORE_RVA,camera,sizeof(camera))&&readAt(p,base+DONOR_CAMERA_CORE_RVA,again,sizeof(again))&&!memcmp(camera,again,sizeof(camera))&&readAt(p,base+0xc5aa78,&owner,8)&&owner==instance;
                fprintf(out,",\"cameraCoreCandidate\":{\"valid\":%s,\"rva\":\"0x86ef40\",\"coreOffsets\":[0,752,1480]",cameraOk?"true":"false");
                if(cameraOk){fprintf(out,",\"rawHex\":\"");for(unsigned j=0;j<sizeof(camera);j++)fprintf(out,"%02x",camera[j]);fputc('"',out);}fputc('}',out);
                if(cameraView){SourceCameraSnapshot snapshot={0};
                    if(cameraOk){snapshot.magic=0x31435a52;snapshot.version=1;snapshot.pid=pid;snapshot.epoch=cameraStart;snapshot.tick=GetTickCount64();snapshot.instance=instance;
                        for(unsigned k=0;k<3;k++)snapshot.actor[k]=real(bytes+0x20+k*4);
                        memcpy(snapshot.view,camera+0x1a0,64);memcpy(snapshot.inverse,camera+0x1e0,64);memcpy(snapshot.hash,directMotionHash,32);
                        if(!sourceCameraValid(&snapshot,pid,snapshot.tick))memset(&snapshot,0,sizeof(snapshot));
                    }
                    // A read race must not switch the host to its native camera
                    // for one frame. Keep the previous validated sample; its
                    // existing 150ms freshness bound still forces fallback.
                    if(snapshot.magic)sourceCameraStore(cameraView,&snapshot);
                }
            }
            if(captureAppearance){
                unsigned char data[2048];uintptr_t dataAddress=pointer(bytes+0x310),ownerAfter=0;
                bool dataValid=readAt(p,dataAddress,data,sizeof(data))&&readAt(p,base+0xc5aa78,&ownerAfter,8)&&ownerAfter==instance;
                fprintf(out,",\"appearanceRaw\":{\"instanceHex\":\"");for(size_t i=0;i<sizeof(bytes);i++)fprintf(out,"%02x",bytes[i]);
                fprintf(out,"\",\"data310\":\"0x%llx\",\"dataValid\":%s",(unsigned long long)dataAddress,dataValid?"true":"false");
                if(dataValid){fprintf(out,",\"dataHex\":\"");for(size_t i=0;i<sizeof(data);i++)fprintf(out,"%02x",data[i]);fputc('"',out);}fputc('}',out);
            }
            if(captureMotion){
                DonorMotion motion=donorMotionRead(motionRead,p,base,instance);
                fprintf(out,",\"motionCandidate\":{\"valid\":%s,\"complete\":%s,\"stable\":%s,\"visited\":%u,\"index\":%u,\"pool\":\"0x%llx\",\"node\":\"0x%llx\",\"flagsRaw\":%u",
                    motion.valid?"true":"false",motion.complete?"true":"false",motion.stable?"true":"false",motion.visited,motion.index,(unsigned long long)motion.pool,(unsigned long long)motion.node,motion.flags);
                if(motion.valid)fprintf(out,",\"vector\":[%.9g,%.9g,%.9g]",motion.vector[0],motion.vector[1],motion.vector[2]);
                fputc('}',out);
                DonorTimeCandidate time=donorTimeRead(motionRead,p,base,instance);
                fprintf(out,",\"motionTimeCandidate\":{\"valid\":%s",time.valid?"true":"false");
                if(time.valid)fprintf(out,",\"factorRaw\":%.9g,\"selectedRva\":%u",time.factor,time.selectedRva);
                fputc('}',out);
            }
        }
        fprintf(out,"}\n"); fflush(out);
        if(seq+1<samples){
            if(publishCamera||captureSkeleton60){
                LARGE_INTEGER now;QueryPerformanceCounter(&now);
                uint64_t due=captureNext60((uint64_t)cadenceOrigin.QuadPart,(uint64_t)now.QuadPart,(uint64_t)cadenceFrequency.QuadPart);
                uint64_t remaining=due-(uint64_t)now.QuadPart;
                LARGE_INTEGER wait;wait.QuadPart=-(LONGLONG)(remaining*10000000/(uint64_t)cadenceFrequency.QuadPart);
                if(cadenceTimer&&SetWaitableTimer(cadenceTimer,&wait,0,NULL,NULL,FALSE))WaitForSingleObject(cadenceTimer,50);
                else Sleep((DWORD)(remaining*1000/(uint64_t)cadenceFrequency.QuadPart));
            }else Sleep(interval);
        }
    }
    if(captureCamera)recordingStopStatus(pid);
    if(cadenceTimer)CloseHandle(cadenceTimer);
    if(cameraView){SourceCameraSnapshot empty={0};sourceCameraStore(cameraView,&empty);UnmapViewOfFile(cameraView);}if(cameraMapping)CloseHandle(cameraMapping);
    bool outputFailed=ferror(out)!=0;
    if(pipeOutput)fflush(out);else if(fclose(out))outputFailed=true;
    CloseHandle(p); fprintf(pipeOutput?stderr:stdout,"Validated Raziel samples: %u/%lu\n",valid,samples); return outputFailed ? 9 : valid ? 0 : 6;
}

