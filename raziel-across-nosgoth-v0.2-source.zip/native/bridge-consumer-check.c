// SPDX-License-Identifier: GPL-3.0-or-later
// Real OS integration fixture. No game hooks, synthetic payloads only.
#include <stdlib.h>
#include <io.h>
#include <fcntl.h>
#include "bridge-consumer.h"
int main(void){
 int result=1;BridgeMemory memory={0};BridgeConsumer *consumer=malloc(sizeof(*consumer));unsigned char *pose=malloc(RM_LIVE_BYTES),movement[80],hello[BRIDGE_HEADER_BYTES];uint64_t ownCreation=0;
 if(!consumer||!pose||!bridgeProcessCreation(GetCurrentProcess(),&ownCreation))goto done;
 printf("PID %lu\n",GetCurrentProcessId());fflush(stdout);_setmode(_fileno(stdin),_O_BINARY);
 if(fread(hello,1,sizeof(hello),stdin)!=sizeof(hello))goto done;
 BridgeIdentity identity={.sourcePid=bridgeU32(hello+16),.hostPid=GetCurrentProcessId(),.sourceCreation=bridgeU64(hello+24),.hostCreation=ownCreation,.sessionGeneration=bridgeU64(hello+40),.levelGeneration=1,.actorId=1,.actorGeneration=1,.capabilities=15};
 if(!bridgeHex(sheet_bridgeProtocol_session_v2.sourceBuild,identity.sourceBuild)||!bridgeHex(sheet_bridgeProtocol_session_v2.hostBuild,identity.hostBuild))goto done;
 BridgeHeader h;if(!bridgeDecode(hello,sizeof(hello),sizeof(hello),GetTickCount64(),&identity,&h)||h.type!=BRIDGE_HELLO)goto done;
 uint64_t deadline=GetTickCount64()+5000;while(GetTickCount64()<deadline&&!bridgeMemoryOpen(&memory,&identity,false))Sleep(2);if(!memory.view)goto done;
 bridgeConsumerBegin(consumer,&identity);deadline=GetTickCount64()+5000;bool accepted=false;
 while(GetTickCount64()<deadline&&!(accepted=bridgeConsumerRead(consumer,&memory,pose,movement,GetTickCount64())))Sleep(2);
 if(!accepted||!consumer->poseReady||!consumer->movementReady)goto done;
 puts("ACCEPTED");fflush(stdout);deadline=GetTickCount64()+5000;
 while(GetTickCount64()<deadline){
  bridgeConsumerRead(consumer,&memory,pose,movement,GetTickCount64());
  if(memory.status==BM_PEER_LOST&&!consumer->poseReady&&!consumer->movementReady){result=0;puts("PASS: production writer to real native consumer; validated paired pose/control and invalidation on writer exit");break;}
  Sleep(2);
 }
done:bridgeMemoryClose(&memory);free(consumer);free(pose);return result;
}
