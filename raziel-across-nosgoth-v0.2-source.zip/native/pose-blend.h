// Display-space interpolation of validated local skinned vertices. No game writes.
typedef struct {
    float *from,*target,*display;
    size_t count;
    uint64_t sourceTick,start,lastRender;
    uint32_t sourcePid,duration;
    bool ready,active;
} PoseBlend;
static bool poseBlendStep(PoseBlend *b,uint64_t now) {
    if(!b->ready||!b->active||now<b->start||now==b->lastRender)return false;
    uint64_t elapsed=now-b->start;
    float alpha=elapsed>=b->duration?1.0f:(float)elapsed/(float)b->duration;
    for(size_t i=0;i<b->count;++i)b->display[i]=b->from[i]+(b->target[i]-b->from[i])*alpha;
    b->lastRender=now;if(alpha>=1)b->active=false;return true;
}
static bool poseBlendAccept(PoseBlend *b,const float *positions,uint32_t pid,uint64_t tick,uint64_t now) {
    if(!b->count||!pid||tick>now||now-tick>500||(b->ready&&pid==b->sourcePid&&tick<=b->sourceTick))return false;
    for(size_t i=0;i<b->count;++i)if(!isfinite(positions[i])||fabsf(positions[i])>100000)return false;
    bool reset=!b->ready||pid!=b->sourcePid||tick-b->sourceTick>500;
    if(reset){memcpy(b->display,positions,b->count*sizeof(float));b->active=false;}
    else {
        poseBlendStep(b,now);
        memcpy(b->from,b->display,b->count*sizeof(float));
        uint64_t interval=tick-b->sourceTick;
        b->duration=(uint32_t)(interval<16?16:interval>100?100:interval);
        b->active=true;
    }
    memcpy(b->target,positions,b->count*sizeof(float));
    b->sourcePid=pid;b->sourceTick=tick;b->start=now;b->lastRender=now;b->ready=true;
    return true;
}
