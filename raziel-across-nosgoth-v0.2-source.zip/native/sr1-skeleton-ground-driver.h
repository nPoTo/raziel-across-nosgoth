// SPDX-License-Identifier: GPL-3.0-or-later
// Native SR1 forward controllers only. No actor XYZ, facing or donor world root.
#include "sr1-ground-shared.h"
static HANDLE sr1GroundMapping;static const SkeletonGroundShared *sr1GroundView;
static volatile LONG sr1GroundEnabled,sr1GroundFailed,sr1GroundThread;
static uint64_t sr1GroundEpoch,sr1GroundLastYield;static bool sr1GroundInstalled;
static unsigned sr1GroundFrames,sr1GroundSwitches,sr1GroundReleases,sr1GroundForeign,sr1GroundGates[10];
typedef struct {uintptr_t actor,object,model;unsigned pending;RootController before[2];unsigned char applied[2][12];} Sr1GroundLease;
static Sr1GroundLease sr1GroundLease;
#ifdef SR1_COMBAT_TRAVEL
#include "combat-travel-cursor.h"
static CombatTravelCursor srCombatCursor;
#endif
static bool sr1GroundOwns(void){return sr1GroundLease.pending!=0;}
static bool sr1GroundIdentity(uintptr_t state,uintptr_t actor,HostRig *rig){
 uintptr_t instance=0;return instantRootModule&&worldRead(state,&instance,8)&&instance==actor&&hostRigRead(NULL,sr1SkeletonRead,instantRootModule,rig)&&rig->actor==actor&&rig->modelIndex==0&&rig->count==66;
}
static void sr1GroundRelease(uintptr_t state){
 if(!sr1GroundLease.pending)return;DWORD thread=GetCurrentThreadId();if((DWORD)InterlockedCompareExchange(&sr1GroundThread,0,0)!=thread){InterlockedExchange(&sr1GroundFailed,1);return;}
 HostRig r;if(!sr1GroundIdentity(state,sr1GroundLease.actor,&r)||r.object!=sr1GroundLease.object||r.model!=sr1GroundLease.model){sr1GroundLease.pending=0;InterlockedExchange(&sr1GroundFailed,1);++sr1GroundForeign;return;}
 for(unsigned k=0;k<2;k++)if(sr1GroundLease.pending&(1u<<k)){
  uintptr_t anim=r.actor+(k?0x448:0x328);RootController current,after;unsigned bytes=k?12:6;
  if(!rootControllerRead(instantRootModule,anim,k,&current)){InterlockedExchange(&sr1GroundFailed,1);continue;}
  // Preserve any controller state changed by native code or another owner.
  if(!current.found||current.node!=sr1GroundLease.before[k].node||!current.active||memcmp(current.vector,sr1GroundLease.applied[k],bytes)){sr1GroundLease.pending&=~(1u<<k);++sr1GroundForeign;continue;}
  if(sr1GroundLease.before[k].active)originalMotion[k](anim,0,34,(uintptr_t)sr1GroundLease.before[k].vector);else rootDisable[k](anim,0,34);
  bool ok=rootControllerRead(instantRootModule,anim,k,&after)&&after.found&&after.node==current.node&&after.active==sr1GroundLease.before[k].active&&(!after.active||!memcmp(after.vector,sr1GroundLease.before[k].vector,bytes));
  if(ok){sr1GroundLease.pending&=~(1u<<k);++sr1GroundReleases;}else InterlockedExchange(&sr1GroundFailed,1);
 }
}
static unsigned sr1GroundScope(uintptr_t state,int32_t section,uint64_t now,HostRig *r,float *step,uint64_t *source){
 if(!InterlockedCompareExchange(&sr1GroundEnabled,0,0)||InterlockedCompareExchange(&sr1GroundFailed,0,0)||InterlockedCompareExchange(&probeBoundedComplete,0,0)||section)return 1;
 uintptr_t actor=0,process=0;if(!worldRead(state,&actor,8)||!sr1GroundIdentity(state,actor,r))return 2;
 if(!worldRead(state+0x10,&process,8)||!rootEligibleProcess(process))return 3;
 bool context=sr1SkeletonContext(instantRootModule,r->actor);
 const SkeletonShared *bones=(const SkeletonShared *)InterlockedCompareExchangePointer(&sr1SkeletonView,NULL,NULL);const SkeletonGroundShared *ground=(const SkeletonGroundShared *)InterlockedCompareExchangePointer((PVOID volatile *)&sr1GroundView,NULL,NULL);SkeletonSnapshot pose;SkeletonGroundPacket s;
 if(!skeletonCopy(bones,&pose)||!skeletonPacketValid(&pose,GetCurrentProcessId(),now)||!skeletonGroundCopy(ground,&s)||!skeletonGroundValid(&s,GetCurrentProcessId(),now))return 5;
 
 if(pose.actor!=r->actor||pose.object!=r->object||pose.model!=r->model||s.actor!=r->actor||s.object!=r->object||s.model!=r->model||s.sourcePid!=pose.sourcePid||s.epoch!=pose.epoch||s.hostTick<sr1GroundLastYield||s.sourceTick<sr1GroundLastYield)return 7;
 if(sr1GroundEpoch&&sr1GroundEpoch!=s.epoch)return 7;sr1GroundEpoch=s.epoch;
 if(InterlockedCompareExchange(&sr1SkeletonCopies,0,0)<20||InterlockedCompareExchange(&sr1SkeletonFailed,0,0))return 8;
 #ifdef SR1_COMBAT_TRAVEL
 if(s.active==2||s.active==3){
  bool owned=GetFileAttributesW(PROBE_PATH(L"\\free-attack-sr1.enable"))!=INVALID_FILE_ATTRIBUTES;
  bool allowed=owned&&context&&pose.mode==2;
  if(!combatTravelStep(&srCombatCursor,s.epoch,s.sequence,s.sourceTick,r->actor,s.sourcePid,s.forwardPerFactor,allowed,step))return 9;
  if(!allowed||s.active!=3)return 6;
  *source=s.sourceTick;return 0;
 }
#endif
 if(!context||!srGroundMovingInput()){sr1GroundLastYield=now;return 4;}
 if(pose.mode!=2||!s.active){sr1GroundLastYield=now;return 6;}
 int32_t time=0;if(!worldRead(instantRootModule+0x2a89628,&time,4)||!skeletonGroundStep(&s,time,step))return 9;
 *source=s.sourceTick;return 0;
}
static bool sr1GroundAfter(uintptr_t state,int32_t section){
 if(section||!InterlockedCompareExchange(&sr1GroundEnabled,0,0))return false;
 if(sr1GroundLease.pending||InterlockedCompareExchange(&sr1GroundFailed,0,0))return true;
 HostRig r;float step=0;uint64_t source=0,now=GetTickCount64();unsigned gate=sr1GroundScope(state,section,now,&r,&step,&source);++sr1GroundGates[gate];if(gate){
#ifdef SR1_COMBAT_TRAVEL
 if(gate!=6)srCombatCursor.ready=false;
#endif
 return true;}
 LONG thread=(LONG)GetCurrentThreadId(),owner=InterlockedCompareExchange(&sr1GroundThread,thread,0);if(owner&&owner!=thread){InterlockedExchange(&sr1GroundFailed,1);return true;}
 uintptr_t process=0;if(!worldRead(state+0x10,&process,8))return true;bool pivot=process==instantRootModule+0xf5340;
 if(pivot)step=0;else if(process!=instantRootModule+0xf3280){rootCharacterSwitch(state,instantRootModule+0xf3280,0);if(!worldRead(state+0x10,&process,8)||process!=instantRootModule+0xf3280){InterlockedExchange(&sr1GroundFailed,1);return true;}++sr1GroundSwitches;}
 HostRig after;if(!sr1GroundIdentity(state,r.actor,&after)||after.object!=r.object||after.model!=r.model){InterlockedExchange(&sr1GroundFailed,1);return true;}
 Sr1GroundLease lease={.actor=r.actor,.object=r.object,.model=r.model};
 for(unsigned k=0;k<2;k++)if(!rootControllerRead(instantRootModule,r.actor+(k?0x448:0x328),k,&lease.before[k])||!lease.before[k].found){InterlockedExchange(&sr1GroundFailed,1);return true;}
 sr1GroundLease=lease;bool ok=true;
 for(unsigned k=0;k<2&&ok;k++){
  uintptr_t anim=r.actor+(k?0x448:0x328);RootController current=lease.before[k];
  if(!lease.before[k].active){rootEnable[k](anim,0,34);ok=rootControllerRead(instantRootModule,anim,k,&current)&&current.found&&current.active&&current.node==lease.before[k].node;if(ok){sr1GroundLease.pending|=1u<<k;memcpy(sr1GroundLease.applied[k],current.vector,k?12:6);}}
  if(ok){int16_t small[3]={0,(int16_t)step,0};float wide[3]={0,step,0};const void *values=k?(const void *)wide:(const void *)small;unsigned char previous[12];memcpy(previous,current.vector,k?12:6);sr1GroundLease.pending|=1u<<k;memcpy(sr1GroundLease.applied[k],values,k?12:6);originalMotion[k](anim,0,34,(uintptr_t)values);bool read=rootControllerRead(instantRootModule,anim,k,&current)&&current.found&&current.active&&current.node==lease.before[k].node;ok=read&&!memcmp(current.vector,values,k?12:6);if(!ok&&read&&!memcmp(current.vector,previous,k?12:6))memcpy(sr1GroundLease.applied[k],previous,k?12:6);}
 }
 if(!ok){sr1GroundRelease(state);InterlockedExchange(&sr1GroundFailed,1);}else ++sr1GroundFrames;
 if(sr1GroundFrames<=12||sr1GroundFrames%60==0||!ok)logLine("SR1_SKELETON_GROUND tick=%llu source=%llu step=%.9g pivot=%u ok=%u frames=%u; native forward controllers only",now,source,step,pivot,ok,sr1GroundFrames);
 return true;
}
static void sr1GroundTick(void){
 if(!sr1GroundInstalled&&instantRootModule&&rootStateTargets[0]&&rootStateTargets[1]&&rootStateTargets[2]&&rootStateTargets[3]){
  if(rootExternalAfter||rootExternalRelease||rootExternalOwnsControllers){InterlockedExchange(&sr1GroundFailed,1);return;}
  InterlockedExchangePointer((PVOID volatile *)&rootExternalOwnsControllers,(PVOID)sr1GroundOwns);InterlockedExchangePointer((PVOID volatile *)&rootExternalRelease,(PVOID)sr1GroundRelease);InterlockedExchangePointer((PVOID volatile *)&rootExternalAfter,(PVOID)sr1GroundAfter);sr1GroundInstalled=true;logLine("CAPABILITY sr1_skeleton_ground=1; existing proved root handlers/controllers; host heading native");
 }
 bool requested=sr1GroundInstalled&&!InterlockedCompareExchange(&probeBoundedComplete,0,0)&&GetFileAttributesW(PROBE_PATH(L"\\sr1-skeleton.enable"))!=INVALID_FILE_ATTRIBUTES&&GetFileAttributesW(PROBE_PATH(L"\\sr1-locomotion.enable"))!=INVALID_FILE_ATTRIBUTES;
 if(requested&&!sr1GroundView){wchar_t name[96];skeletonGroundName(name,GetCurrentProcessId());HANDLE m=OpenFileMappingW(FILE_MAP_READ,FALSE,name);if(m){PVOID v=MapViewOfFile(m,FILE_MAP_READ,0,0,sizeof(SkeletonGroundShared));if(v){sr1GroundMapping=m;InterlockedExchangePointer((PVOID volatile *)&sr1GroundView,v);}else CloseHandle(m);}}
 InterlockedExchange(&sr1GroundEnabled,requested);logLine("SR1_SKELETON_GROUND_STATUS enabled=%u frames=%u switches=%u releases=%u foreign_preserved=%u pending=%u failed=%ld gates=%u,%u,%u,%u,%u,%u,%u,%u,%u,%u",requested,sr1GroundFrames,sr1GroundSwitches,sr1GroundReleases,sr1GroundForeign,sr1GroundLease.pending,InterlockedCompareExchange(&sr1GroundFailed,0,0),sr1GroundGates[0],sr1GroundGates[1],sr1GroundGates[2],sr1GroundGates[3],sr1GroundGates[4],sr1GroundGates[5],sr1GroundGates[6],sr1GroundGates[7],sr1GroundGates[8],sr1GroundGates[9]);
}
static void sr1GroundStop(void){InterlockedExchange(&sr1GroundEnabled,0);logLine("SR1_SKELETON_GROUND stopped; native handler-thread lease release remains pinned");}
