// SPDX-License-Identifier: GPL-3.0-or-later
#include <stdlib.h>
#include "bridge-consumer.h"
#define CHECK(x) do{if(!(x)){fprintf(stderr,"FAIL bridge consumer line%d\n",__LINE__);result=1;goto done;}}while(0)
static void poseHeader(unsigned char *pose,uint32_t pid,uint32_t sequence,uint64_t tick){
 memset(pose,0,RM_LIVE_BYTES);bridgePut(pose,0x324c5a52,4);bridgePut(pose+4,24135,4);bridgePut(pose+8,2,4);bridgePut(pose+12,sequence,4);bridgePut(pose+16,tick,8);bridgePut(pose+24,pid,4);bridgePut(pose+28,1,4);
 static const unsigned char hash[32]={0x40,0x59,0xa8,0x3f,0x3d,0x47,0xa1,0x98,0x71,0x4b,0x21,0x5a,0xae,0xdc,0x21,0xc8,0x91,0x93,0x14,0xc7,0xd4,0xfc,0xd6,0x79,0x55,0x0f,0x89,0x60,0xc1,0xd8,0xda,0x0c};memcpy(pose+32,hash,32);
}
static void command(unsigned char *movement,uint32_t pid,uint32_t sequence,uint64_t tick,const unsigned char hash[32]){
 memset(movement,0,RM_MOVEMENT_BYTES);bridgePut(movement,0x314d5a52,4);bridgePut(movement+4,1,4);bridgePut(movement+8,pid,4);bridgePut(movement+12,sequence,4);bridgePut(movement+16,tick,8);float factor=1,v=-20;memcpy(movement+24,&factor,4);memcpy(movement+32,&v,4);bridgePut(movement+40,1,4);memcpy(movement+48,hash,32);
}
int main(void){
 int result=0;BridgeConsumer *c=malloc(sizeof(*c));unsigned char *pose=malloc(RM_LIVE_BYTES),movement[80];CHECK(c&&pose);
 BridgeIdentity i={.sourcePid=99,.hostPid=42,.sourceCreation=111,.hostCreation=222,.sessionGeneration=7,.levelGeneration=9,.actorId=1,.actorGeneration=2,.capabilities=15};
 CHECK(bridgeHex(sheet_bridgeProtocol_session_v2.sourceBuild,i.sourceBuild)&&bridgeHex(sheet_bridgeProtocol_session_v2.hostBuild,i.hostBuild));
 BridgeHeader p={.identity=i,.type=BRIDGE_POSE,.payloadBytes=RM_LIVE_BYTES,.sequence=1,.tick=950},m=p;m.type=BRIDGE_MOVEMENT;m.payloadBytes=80;
 poseHeader(pose,i.sourcePid,10,950);command(movement,i.sourcePid,10,950,i.sourceBuild);bridgeConsumerBegin(c,&i);
 CHECK(bridgeConsumerAccept(c,&p,pose,&m,movement,1000)&&c->poseReady&&c->movementReady);
 CHECK(!bridgeConsumerAccept(c,&p,pose,&m,movement,1001)&&c->poseReady&&c->movementReady); // no duplicate event/flicker
 CHECK(!bridgeConsumerAccept(c,&p,pose,&m,movement,1101)&&c->poseReady&&!c->movementReady);
 CHECK(!bridgeConsumerAccept(c,&p,pose,&m,movement,1102)&&c->poseReady&&!c->movementReady); // repeated expired command cannot flicker visual
 bridgeConsumerExpire(c,1103);CHECK(c->poseReady&&!c->movementReady); // bounded hold during mutex contention
 bridgeConsumerExpire(c,1451);CHECK(!c->poseReady&&!c->movementReady);
 CHECK(!bridgeConsumerAccept(c,&p,pose,&m,movement,1451)&&!c->poseReady&&!c->movementReady);
 for(unsigned defect=0;defect<12;defect++){
  bridgeConsumerBegin(c,&i);p.sequence=m.sequence=2;p.tick=m.tick=950;p.identity=m.identity=i;poseHeader(pose,i.sourcePid,11,950);command(movement,i.sourcePid,11,950,i.sourceBuild);
  switch(defect){case 0:m.sequence++;break;case 1:m.tick++;break;case 2:m.identity.actorGeneration++;break;case 3:bridgePut(movement+12,12,4);break;case 4:bridgePut(movement+16,949,8);break;case 5:pose[32]^=1;break;case 6:bridgePut(pose+24,98,4);break;case 7:bridgePut(pose+16,949,8);break;case 8:{float n=NAN;memcpy(pose+64,&n,4);break;}case 9:{float n=100001;memcpy(pose+64,&n,4);break;}case 10:movement[48]^=1;break;default:bridgePut(movement+44,1,4);break;}
  CHECK(!bridgeConsumerAccept(c,&p,pose,&m,movement,1000)&&!c->poseReady&&!c->movementReady&&c->sequence==0);
 }
 bridgeConsumerBegin(c,&i);p.identity=m.identity=i;p.sequence=m.sequence=3;p.tick=m.tick=950;poseHeader(pose,i.sourcePid,12,950);memset(movement,0,80);
 CHECK(bridgeConsumerAccept(c,&p,pose,&m,movement,1000)&&c->poseReady&&!c->movementReady);
 p.sequence=m.sequence=4;p.tick=m.tick=960;poseHeader(pose,i.sourcePid,11,960);CHECK(!bridgeConsumerAccept(c,&p,pose,&m,movement,1000)&&!c->poseReady); // inner replay
 puts("PASS: paired consumer inner pose/command validation, exact outer/inner frame binding, zero command visual fallback, duplicate snapshot retention, control expiry, stale/actor/hash/NaN/range/replay rejection");
done:free(c);free(pose);return result;
}
