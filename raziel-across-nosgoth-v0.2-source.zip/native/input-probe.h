#include "report-path.h"
// SPDX-License-Identifier: GPL-3.0-or-later
// Read SDL's existing gamepad handles after the game's own PollEvent.
// Never opens a device, pumps events or changes input state.
typedef uint32_t *(__cdecl *InputPadsFn)(int *);
typedef void *(__cdecl *InputHandleFn)(uint32_t);
typedef int16_t (__cdecl *InputAxisFn)(void *,int);
typedef bool (__cdecl *InputButtonFn)(void *,int);
typedef void (__cdecl *InputFreeFn)(void *);
typedef const char *(__cdecl *InputNameFn)(void *);
typedef int (__cdecl *InputTypeFn)(void *);
static InputPadsFn inputPads;
static InputHandleFn inputHandle;
static InputAxisFn inputAxis;
static InputButtonFn inputButton;
static InputFreeFn inputFree;
static InputNameFn inputName;
static InputTypeFn inputType;
typedef struct {uint64_t tick;uint32_t id,buttons;int16_t axes[6];int type;} InputSample;
static InputSample inputQueue[512];
static unsigned int inputHead,inputTail;
static volatile LONG inputLock,inputDrops;
static ULONGLONG inputLast,inputFlagCheck,inputBegin;
static bool inputEnabled;
static FILE *inputFile;
static void inputInit(void) {
    HMODULE sdl=GetModuleHandleW(L"SDL3.dll");
    if(!sdl) return;
    inputPads=(InputPadsFn)GetProcAddress(sdl,"SDL_GetGamepads");
    inputHandle=(InputHandleFn)GetProcAddress(sdl,"SDL_GetGamepadFromID");
    inputAxis=(InputAxisFn)GetProcAddress(sdl,"SDL_GetGamepadAxis");
    inputButton=(InputButtonFn)GetProcAddress(sdl,"SDL_GetGamepadButton");
    inputFree=(InputFreeFn)GetProcAddress(sdl,"SDL_free");
    inputName=(InputNameFn)GetProcAddress(sdl,"SDL_GetGamepadName");
    inputType=(InputTypeFn)GetProcAddress(sdl,"SDL_GetGamepadType");
    if(!inputPads||!inputHandle||!inputAxis||!inputButton||!inputFree||!inputName||!inputType) {inputPads=NULL;return;}
    wchar_t path[32768];_snwprintf(path,ARRAYSIZE(path),PROBE_PATH(L"\\defiance-input-%lu.jsonl"),GetCurrentProcessId());
    inputFile=_wfopen(path,L"wb");
    if(!inputFile) {inputPads=NULL;return;}
    fprintf(inputFile,"{\"type\":\"session\",\"schema\":1,\"pid\":%lu,\"mode\":\"read-only\",\"axes\":6,\"buttons\":15,\"limitSeconds\":120}\n",GetCurrentProcessId());fflush(inputFile);
    logLine("INPUT SDL gamepad observer ready; explicit enable required, first15 standard buttons, gameplay=0");
}
static void inputObserve(void) {
    if(!inputPads) return;
    ULONGLONG now=GetTickCount64();
    // Game's PollEvent is expected on one thread; lock also protects timing state.
    if(InterlockedCompareExchange(&inputLock,1,0)) {InterlockedIncrement(&inputDrops);return;}
    if(now-inputFlagCheck>=250) {
        inputFlagCheck=now;
        inputEnabled=GetFileAttributesW(PROBE_PATH(L"\\defiance-input.enable"))!=INVALID_FILE_ATTRIBUTES;
        if(inputEnabled&&!inputBegin) inputBegin=now;
    }
    if(!inputEnabled||now-inputBegin>120000||now-inputLast<16) {InterlockedExchange(&inputLock,0);return;}
    inputLast=now;
    int count=0;uint32_t *ids=inputPads(&count);
    if(ids && count>=0 && count<=16) for(int i=0;i<count && i<4;++i) {
        void *pad=inputHandle(ids[i]);if(!pad) continue;
        InputSample s={0};s.tick=now;s.id=ids[i];s.type=inputType(pad);
        for(int k=0;k<6;++k) s.axes[k]=inputAxis(pad,k);
        for(int k=0;k<15;++k) if(inputButton(pad,k)) s.buttons|=1u<<k;
        unsigned int next=(inputHead+1)%ARRAYSIZE(inputQueue);
        if(next==inputTail) InterlockedIncrement(&inputDrops);
        else {inputQueue[inputHead]=s;inputHead=next;}
    }
    if(ids) inputFree(ids);
    InterlockedExchange(&inputLock,0);
}
static void inputFlush(void) {
    if(!inputFile) return;
    InputSample samples[512];unsigned int count=0;
    if(InterlockedCompareExchange(&inputLock,1,0)) return;
    while(inputTail!=inputHead) {samples[count++]=inputQueue[inputTail];inputTail=(inputTail+1)%ARRAYSIZE(inputQueue);}
    InterlockedExchange(&inputLock,0);
    for(unsigned int i=0;i<count;++i) {
        InputSample *s=&samples[i];
        fprintf(inputFile,"{\"type\":\"sample\",\"tickMs\":%llu,\"id\":%u,\"padType\":%d,\"buttons\":%u,\"axes\":[%d,%d,%d,%d,%d,%d]}\n",
            (unsigned long long)s->tick,s->id,s->type,s->buttons,s->axes[0],s->axes[1],s->axes[2],s->axes[3],s->axes[4],s->axes[5]);
    }
    if(count) fflush(inputFile);
}
