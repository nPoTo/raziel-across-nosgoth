// SPDX-License-Identifier: GPL-3.0-or-later
#pragma once
#include "donor-state-sections.h"
typedef struct {uintptr_t opaqueActor,opaqueState;uint32_t primaryRva,key1,key2,pad;} DonorControlQueryMetadata;
static inline bool donorControlQueryRead(void *c,DonorActionStateRead read,DonorActionStateCode code,uintptr_t base,uint32_t size,uintptr_t actor,uint32_t query,DonorControlQueryMetadata *out){
 memset(out,0,sizeof(*out));const Sheet_donorControlQueryPolicy *p=&sheet_donorControlQueryPolicy_bounded;
 if(!read||!code||(query!=p->queryFirst&&query!=p->querySecond)||!actor||actor%8||actor>UINTPTR_MAX-0x400||base>UINTPTR_MAX-size||size<=p->keyboardMapperRva||size<p->keyboardMapperSlotRva+8||size<0xc5aa80||p->bindingTableRva>size||query>(size-p->bindingTableRva)/12||p->bindingTableRva+(uint64_t)query*12+12>size)return false;
 uintptr_t mapper=0,again=0,state=0,stateAgain=0,current=0;if(!read(c,base+p->keyboardMapperSlotRva,&mapper,8)||mapper!=base+p->keyboardMapperRva||!code(c,mapper,base)||!read(c,base+0xc5aa78,&current,8)||current!=actor||!read(c,actor+0x3f8,&state,8))return false;
 DonorStateSections sections=donorStateSectionsRead(c,read,code,base,size,actor,base+0xc5aa78);if(!sections.valid||!sections.ownerMatches||(sections.sections[0].firstRva!=0x114b40&&sections.sections[0].firstRva!=0x117e30))return false;
 uint32_t keys[2][2];uint8_t pad[2];uintptr_t row=base+p->bindingTableRva+(uintptr_t)query*12;
 for(unsigned i=0;i<2;i++)if(!read(c,row,keys[i],8)||!read(c,row+8,&pad[i],1))return false;
 if(memcmp(keys[0],keys[1],8)||pad[0]!=pad[1]||!read(c,base+p->keyboardMapperSlotRva,&again,8)||again!=mapper||!read(c,actor+0x3f8,&stateAgain,8)||stateAgain!=state||!read(c,base+0xc5aa78,&current,8)||current!=actor)return false;
 out->opaqueActor=actor;out->opaqueState=state;out->primaryRva=sections.sections[0].firstRva;out->key1=keys[0][0];out->key2=keys[0][1];out->pad=pad[0];return true;
}
