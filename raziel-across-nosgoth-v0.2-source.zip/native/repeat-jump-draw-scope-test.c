// SPDX-License-Identifier: GPL-3.0-or-later
#include <assert.h>
#include <stdio.h>
#include "repeat-jump-draw-scope.h"
#include "sr1-repeat-jump-buffer.h"
int main(void){
 HostDrawReceipt s={.magic=0x31524448,.version=1,.pid=12,.valid=1,.creation=99,.tick=1000,.serial=1};
 memcpy(s.policy,skeletonPolicyHash,32);s.rig.count=66;s.rig.actor=1;s.rig.object=2;s.rig.model=3;
 s.context.identity=s.context.foreground=s.context.verticalVelocityKnown=true;
 for(unsigned i=0;i<3;i++)s.context.callbacks[i]=0xee600;
 HostRig current=s.rig;RepeatJumpBuffer b={0};
 // No replacement-model draw exists in skeleton-only rendering (old gate fails).
 uint64_t oldWorldDraw=0;assert(!oldWorldDraw);
 assert(repeatJumpDrawScope(&s,12,99,1010,&current));
 repeatJumpStep(&b,1010,1,true,REPEAT_JUMP_LANDING,0,350,32,64);
 repeatJumpStep(&b,1020,1,true,REPEAT_JUMP_LANDING,0x1000,350,32,64);
 repeatJumpStep(&b,1030,1,true,REPEAT_JUMP_LANDING,0,350,32,64);
 Sr1RetargetContext ground=s.context;for(unsigned i=0;i<3;i++)ground.callbacks[i]=0xf2180;
 assert(!hostDrawContextSame(&s.context,&ground));
 assert(repeatJumpDrawScope(&s,12,99,1040,&current));
 assert(repeatJumpStep(&b,1040,1,true,REPEAT_JUMP_GROUND,0,350,32,64)==0x1000);
 assert(!repeatJumpDrawScope(&s,12,99,1151,&current));
 assert(!repeatJumpDrawScope(&s,13,99,1040,&current));
 assert(!repeatJumpDrawScope(&s,12,100,1040,&current));
 current.object++;assert(!repeatJumpDrawScope(&s,12,99,1040,&current));current=s.rig;
 current.parents[4]++;assert(!repeatJumpDrawScope(&s,12,99,1040,&current));current=s.rig;
 s.valid=0;assert(!repeatJumpDrawScope(&s,12,99,1040,&current));
 puts("repeat jump native receipt: no clone draw, landing-ground boundary, stale/foreign/resource rejection PASS");return 0;
}
