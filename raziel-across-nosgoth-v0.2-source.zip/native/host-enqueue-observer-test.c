// SPDX-License-Identifier: GPL-3.0-or-later
#include <stdio.h>
#include <MinHook.h>
#include "host-enqueue-observer.h"
static HostEnqueueObserver observer;static DonorMessageObserverThread tls;
static struct {DonorMessageLease lease;unsigned calls,errors,nested,wanted,reads;int snapshotResult;bool afterFails,changeSession;uint32_t index;void *queue;uint32_t id;uintptr_t payload;} f;
static bool lease(void *unused,DonorMessageLease *out){(void)unused;*out=f.lease;SetLastError(0xaaaaaaaa);return true;}
static int snapshot(void *unused,void *queue,HostEnqueueMetadata *m){(void)unused;f.reads++;if(queue!=f.queue)f.errors++;*m=(HostEnqueueMetadata){2,1,f.index,0xeeb40,0x20000000};SetLastError(0xbbbbbbbb);return f.afterFails&&f.reads%2==0?-1:f.snapshotResult;}
static uintptr_t __fastcall original(void *queue,uint32_t id,uintptr_t payload){
 f.calls++;if(queue!=f.queue||id!=f.id||payload!=f.payload||GetLastError()!=0x12345678)f.errors++;f.index=(f.index+1)%16;
 if(++f.nested<f.wanted){SetLastError(0x12345678);uintptr_t r=hostEnqueueForward(&observer,&tls,original,queue,id,payload,0xf4580);if(r!=UINT64_C(0xfedcba9876543210))f.errors++;}f.nested--;
 if(f.changeSession)f.lease.session++;SetLastError(0x87654321);return UINT64_C(0xfedcba9876543210);
}
static void setup(void){memset(&f,0,sizeof(f));memset(&tls,0,sizeof(tls));f.lease=(DonorMessageLease){true,17,1000,1000,1000};f.wanted=1;f.snapshotResult=1;f.queue=(void *)0x1000;f.id=0xffffffff;f.payload=UINT64_C(0xabcdef0123456789);f.index=15;hostEnqueueInit(&observer,NULL,lease,snapshot);}
static bool run(void){SetLastError(0x12345678);uintptr_t r=hostEnqueueForward(&observer,&tls,original,f.queue,f.id,f.payload,0xf4580);return r==UINT64_C(0xfedcba9876543210)&&GetLastError()==0x87654321&&!f.errors;}
static HostNativeEnqueue trampoline;
static uintptr_t __fastcall hook(void *queue,uint32_t id,uintptr_t payload){return hostEnqueueForward(&observer,&tls,trampoline,queue,id,payload,0xf4580);}
static DWORD WINAPI producer(LPVOID unused){(void)unused;for(uint64_t i=1;i<=4000;i++){HostEnqueueEvent e={0};e.callId=i;e.messageId=(uint32_t)(i^0x55aa);while(!hostEnqueuePush(&observer,&e))SwitchToThread();}return 0;}
#define CHECK(c,n) do{if(!(c)){printf("FAIL %u\n",(unsigned)(n));return n;}}while(0)
int main(void){
 HostEnqueueEvent e;setup();CHECK(run()&&f.calls==1&&observer.published==2&&tls.depth==0,1);CHECK(hostEnqueuePop(&observer,&e)&&e.phase==1&&e.index==15&&e.messageId==UINT32_MAX&&!e.payloadZero&&e.section==2&&e.queueKind==1,2);CHECK(hostEnqueuePop(&observer,&e)&&e.phase==2&&e.index==0&&e.afterValid&&e.sameActor,3);
 setup();f.snapshotResult=0;CHECK(run()&&f.calls==1&&!observer.published&&!observer.dropped&&observer.unrelated==1,4);
 setup();f.snapshotResult=-1;CHECK(run()&&f.calls==1&&observer.metadataDrops==1&&!observer.published,5);
 setup();f.lease.nowTick=61000;f.lease.heartbeatTick=61000;CHECK(run()&&f.calls==1&&observer.boundaryRejected==1&&!observer.dropped,6);
 setup();f.lease.nowTick=2500;CHECK(run()&&f.calls==1&&observer.leaseDrops==1,7);
 setup();f.changeSession=true;CHECK(run()&&f.calls==1&&observer.leaseDrops==1&&observer.published==1,8);
 setup();f.afterFails=true;CHECK(run()&&hostEnqueuePop(&observer,&e)&&hostEnqueuePop(&observer,&e)&&!e.afterValid&&!e.sameActor&&!e.handlerRva,9);
 setup();f.wanted=3;CHECK(run()&&f.calls==3&&observer.published==6&&tls.depth==0,10);
 setup();observer.producerThread=(LONG)GetCurrentThreadId()+1;CHECK(run()&&observer.producerDrops==1&&!observer.published,11);
 setup();observer.writeCursor=512;CHECK(run()&&observer.queueDrops==1&&!observer.published,12);
 setup();observer.published=65536;CHECK(run()&&observer.budgetDrops==1,13);
 setup();tls.depth=UINT32_MAX;CHECK(run()&&observer.depthDrops==1&&tls.depth==UINT32_MAX,14);
 setup();f.lease.enabled=false;CHECK(run()&&!observer.published&&!observer.dropped,15);
 setup();CHECK(MH_Initialize()==MH_OK&&MH_CreateHook((PVOID)original,(PVOID)hook,(PVOID *)&trampoline)==MH_OK&&MH_EnableHook((PVOID)original)==MH_OK,16);HostNativeEnqueue volatile target=original;SetLastError(0x12345678);uintptr_t r=target(f.queue,f.id,f.payload);DWORD last=GetLastError();CHECK(MH_DisableHook((PVOID)original)==MH_OK&&MH_RemoveHook((PVOID)original)==MH_OK&&MH_Uninitialize()==MH_OK,17);CHECK(r==UINT64_C(0xfedcba9876543210)&&last==0x87654321&&f.calls==1&&!f.errors&&observer.published==2,18);
 setup();HANDLE t=CreateThread(NULL,0,producer,NULL,0,NULL);CHECK(t,19);uint64_t wanted=1,deadline=GetTickCount64()+5000;while(wanted<=4000&&GetTickCount64()<deadline){if(hostEnqueuePop(&observer,&e)){CHECK(e.callId==wanted&&e.messageId==(uint32_t)(wanted^0x55aa),20);wanted++;}else SwitchToThread();}CHECK(wanted==4001&&WaitForSingleObject(t,1000)==WAIT_OBJECT_0&&CloseHandle(t)&&observer.published==4000,21);
 puts("PASS: production host enqueue forwarding original3args/opaque64 payload/return/LastError; actual MinHook fixture; queue wrap, unrelated filter, lease deadline vs stale, metadata/nesting/queue/producer/budget failures; concurrent4000 ordered SPSC rows");return 0;
}
