// SPDX-License-Identifier: GPL-3.0-or-later
#pragma once
#include <stdbool.h>
#include <stdint.h>
static inline bool srInputPreparationLease(bool requested,bool valid,uint32_t total,uint32_t completed,bool duringPreparation){
 return requested&&valid&&(total==500||total==1700)&&completed<total&&(duringPreparation||completed>=200);
}
