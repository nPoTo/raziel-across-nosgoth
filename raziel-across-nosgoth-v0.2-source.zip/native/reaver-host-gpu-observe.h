// SPDX-License-Identifier: GPL-3.0-or-later
#pragma once
// Bounded opt-in scalar observation, no drawing, suppression or camera writes.
// Included after exact drawIdentity and the original submitted hand capture.
#include "reaver-host-camera.h"
#include "reaver-gpu-palette.h"
static _Thread_local uint64_t reaverGpuLastFrame,reaverGpuBegin;
static _Thread_local unsigned reaverGpuSamples;
static bool reaverHostGpuCameraInit(HGLRC context){
 if(!context||(cameraContext&&cameraContext!=context))return false;
 if(cameraReady)return true;
 GLint major=0,minor=0;glGetIntegerv(GL_MAJOR_VERSION,&major);glGetIntegerv(GL_MINOR_VERSION,&minor);
 if(major<3||(major==3&&minor<2))return false;
 // Load reflection only: no retired overlay mesh, program or framebuffer.
#define LOAD_CAMERA(type,name) do{PROC fn=wglGetProcAddress(#name);if(!fn||(uintptr_t)fn<=3||(uintptr_t)fn==UINTPTR_MAX)return false;c##name=(type)fn;}while(0);
 CAMERA_GL(LOAD_CAMERA)
#undef LOAD_CAMERA
#define LOAD_COMMON(type,name) do{PROC fn=wglGetProcAddress(#name);if(!fn||(uintptr_t)fn<=3||(uintptr_t)fn==UINTPTR_MAX)return false;p##name=(type)fn;}while(0)
 LOAD_COMMON(PFNGLGETPROGRAMIVPROC,glGetProgramiv);LOAD_COMMON(PFNGLGETUNIFORMLOCATIONPROC,glGetUniformLocation);LOAD_COMMON(PFNGLBINDBUFFERPROC,glBindBuffer);
#undef LOAD_COMMON
 cameraContext=context;cameraAttempted=true;cameraReady=true;cameraDiscover();return true;
}
static void reaverHostGpuObserve(GLenum mode,GLsizei count,GLenum type,const void *indices){
 const Sheet_reaverPalettePolicy *policy=&sheet_reaverPalettePolicy_submitted_gpu_palette;
 if(policy->nativeIntegrationEnabled||mode!=GL_TRIANGLES||count!=102720||type!=GL_UNSIGNED_SHORT||reaverGpuSamples>=(unsigned)policy->maxSamples||
 GetFileAttributesW(PROBE_PATH(L"\\reaver-gpu-receipt-sr1.enable"))==INVALID_FILE_ATTRIBUTES)return;
 uint64_t frame=(uint64_t)InterlockedCompareExchange64(&swapCalls,0,0)+1,now=GetTickCount64();
 if(frame==reaverGpuLastFrame||(reaverGpuBegin&&now-reaverGpuBegin>(uint64_t)policy->maxObservationMs))return;
 GLint fbo=0,ebo=0,program=0;glGetIntegerv(GL_DRAW_FRAMEBUFFER_BINDING,&fbo);if(fbo)return;
 if(!reaverHostGpuCameraInit(wglGetCurrentContext()))return;
 glGetIntegerv(GL_ELEMENT_ARRAY_BUFFER_BINDING,&ebo);if(!drawIdentity(mode,count,type,indices,ebo))return;
 if(!reaverGpuBegin)reaverGpuBegin=now;reaverGpuLastFrame=frame;++reaverGpuSamples;
 glGetIntegerv(GL_CURRENT_PROGRAM,&program);HGLRC context=wglGetCurrentContext();
 HostRig current={0};uintptr_t base=(uintptr_t)GetModuleHandleW(L"sr1.dll");
 bool identity=base&&rigIdentitySnapshot(NULL,sr1SkeletonRead,base,&current)&&current.actor==reaverHostPalette.hand.actor&&current.model==reaverHostPalette.hand.model;
 bool hand=identity&&reaverHostHand.valid&&reaverHostPalette.valid&&reaverHostHand.draw==reaverHostPalette.hand.draw&&
 reaverHandCurrent(&reaverHostPalette.hand,current.actor,current.model,hostDrawCreation,frame);
 bool palette=hand&&reaverGpuPaletteMatches(&reaverHostPalette,context,(GLuint)program,current.actor,current.model,hostDrawCreation,frame);
 float mvp[16];bool camera=palette&&reaverHostCameraMvp(mvp,&reaverHostPalette.hand,reaverHostContext,current.actor,current.model,hostDrawCreation,frame,(GLuint)program,true);
 logLine("REAVER_GPU_RECEIPT tick=%llu frame=%llu sample=%u identity=%u hand=%u palette=%u camera=%u joints=%u; observe_only=1",
 (unsigned long long)now,(unsigned long long)frame,reaverGpuSamples,(unsigned)identity,(unsigned)hand,(unsigned)palette,(unsigned)camera,reaverHostPalette.valid?reaverHostPalette.joints:0);
}
