// SPDX-License-Identifier: GPL-3.0-or-later
// Bounded contact-integration candidate. No automatic host discovery/adoption.
#include "host-contact-reader.h"
#include "exploration-sheets.h"
#include "donor-vertical-lease.h"
#ifdef SR1_LIFT_FOLLOW
#include "donor-lift-signal.h"
#endif
#ifdef SR1_AIR_PHYSICS_CLOCK
#include "donor-air-clock.h"
#endif
static HostContactReader donorContactReader;
static DonorVerticalLease donorContactVertical;
static volatile LONG donorContactReady,donorContactCancel,donorContactFinished;
static DWORD donorContactOwnerThread;
static bool donorContactOwnedFrame,donorContactProjectedFrame;
static HostContactSnapshot donorContactFrameReceipt;
static uint64_t donorContactOwnerEpoch;
typedef struct {uint64_t tick,sequence;unsigned phase,queries,acquired,valid;float z,vz;} DonorContactFrameEvent;
static DonorContactFrameEvent donorContactEvents[128];static unsigned donorContactHead,donorContactTail;
static volatile LONG donorContactEventLock,donorContactDropped;

// Worker transfers this reader exactly once. After publication only the frame
// reads it. Handles/view remain pinned until process exit; no close/read race.
static bool donorContactOwnerArm(HostContactLease expected){
 if(!sheet_donorContactProjection_host_contact_projection.compressionNoLocalFloor)return false;
 if(donorContactReader.attempted||InterlockedCompareExchange(&donorContactCancel,0,0)||
    !donorContactTargets[0]||!hostContactReaderOpen(&donorContactReader,expected))return false;
 donorProcessFindModel();
#ifdef SR1_LIFT_FOLLOW
 if(!donorLiftOpen(expected))return false;
#endif
#ifdef SR1_AIR_PHYSICS_CLOCK
 if(!donorAirClockOpen(expected))return false;
#endif
 donorContactOwnerEpoch=expected.epoch;MemoryBarrier();InterlockedExchange(&donorContactReady,1);return true;
}
static bool donorContactVerticalRead(void *unused,uintptr_t actor,uint64_t generation,float out[3]){
 (void)unused;
 return GetCurrentThreadId()==donorContactOwnerThread&&generation==donorContactOwnerEpoch&&donorProcessIdentity(actor)&&
  worldRead(actor+0x28,out,4)&&worldRead(actor+0x38,out+1,4)&&worldRead(actor+0x170,out+2,4);
}
static bool donorContactVerticalWrite(void *unused,uintptr_t actor,uint64_t generation,unsigned field,float value){
 (void)unused;const uintptr_t offsets[3]={0x28,0x38,0x170};SIZE_T written=0;
 return field<3&&isfinite(value)&&GetCurrentThreadId()==donorContactOwnerThread&&generation==donorContactOwnerEpoch&&donorProcessIdentity(actor)&&
  WriteProcessMemory(GetCurrentProcess(),(void *)(actor+offsets[field]),&value,4,&written)&&written==4;
}
static void donorContactOwnerRelease(void){
#ifdef SR1_LIFT_FOLLOW
 donorLiftRevoke();
#endif
#ifdef SR1_AIR_PHYSICS_CLOCK
 donorAirClockRevoke();
#endif
 InterlockedExchange(&donorContactCancel,1);
 if(donorContactVertical.acquired&&!donorContactVertical.released){
  // Retry only within this owned boundary, before another native frame.
  for(unsigned i=0;i<3&&!donorContactVertical.released;i++)
   (void)donorVerticalRelease(&donorContactVertical,NULL,donorContactVerticalRead,donorContactVerticalWrite);
 }
 InterlockedExchange(&donorContactReady,0);InterlockedExchange(&donorContactFinished,1);
 logLine("DONOR_CONTACT released=%u failed=%u attempts=%u; owning frame cleanup",donorContactVertical.released,donorContactVertical.failed,donorContactVertical.releaseAttempts);
}
static bool donorContactOwnerBefore(void){
 if(!InterlockedCompareExchange(&donorContactReady,0,0))return false;
 DWORD thread=GetCurrentThreadId();
 if(!donorContactOwnerThread)donorContactOwnerThread=thread;
 if(thread!=donorContactOwnerThread||donorContactOwnedFrame){InterlockedExchange(&donorContactCancel,1);return false;}
 donorContactProjectedFrame=false;
 if(InterlockedCompareExchange(&donorContactCancel,0,0)){donorContactOwnerRelease();return false;}
 bool fresh=false;
 if(!hostContactReaderRead(&donorContactReader,GetTickCount64(),&donorContactFrameReceipt,&fresh)){
  donorContactOwnerRelease();return false;
 }
 uintptr_t actor=0;
 if(!worldRead(donorProcessBase+0xc5aa78,&actor,8)||!donorProcessIdentity(actor)||
    (donorContactVertical.acquired&&actor!=donorContactVertical.actor)){donorContactOwnerRelease();return false;}
 donorContactObservedActor=0;donorContactObservedGround=false;donorContactOwnedFrame=true;
 if(donorContactVertical.acquired&&donorContactFrameReceipt.phase!=4){
  // Proved host jump compression is not permission to use the donor room's
  // floor. Suppress that support while the host prepares takeoff; retain phase3
  // in the receipt/log rather than claiming the host is already airborne.
  unsigned projection=donorContactFrameReceipt.phase==3?2:donorContactFrameReceipt.phase;
  donorContactProjectedFrame=donorContactRuntimeBegin(actor,projection,donorContactFrameReceipt.sequence,donorContactFrameReceipt.tick);
  if(!donorContactProjectedFrame){donorContactOwnedFrame=false;donorContactOwnerRelease();}
 }
 return donorContactOwnedFrame;
}
static void donorContactOwnerAfter(void){
 if(!donorContactOwnedFrame)return;
 bool valid=true;unsigned queries=0;
 if(donorContactProjectedFrame)valid=donorContactRuntimeEnd(&queries);
 if(!donorContactVertical.acquired){
  if(valid&&donorContactFrameReceipt.phase==1&&donorContactObservedActor&&donorContactObservedGround)
   (void)donorVerticalAcquire(&donorContactVertical,NULL,donorContactVerticalRead,donorContactObservedActor,donorContactOwnerEpoch,true);
 }else if(!donorVerticalPin(&donorContactVertical,NULL,donorContactVerticalRead,donorContactVerticalWrite))valid=false;
 DonorContactFrameEvent event={.tick=GetTickCount64(),.sequence=donorContactFrameReceipt.sequence,.phase=donorContactFrameReceipt.phase,
  .queries=queries,.acquired=donorContactVertical.acquired,.valid=valid};float values[3];
#ifdef SR1_LIFT_FOLLOW
 donorLiftPublish(&donorContactReader.lease,donorContactVertical.actor,valid&&donorContactFrameReceipt.phase!=4&&donorContactVertical.acquired&&!InterlockedCompareExchange(&donorContactCancel,0,0));
#endif
#ifdef SR1_AIR_PHYSICS_CLOCK
 donorAirClockPublish(&donorContactReader.lease,donorContactVertical.actor,valid&&donorContactFrameReceipt.phase!=4&&donorContactVertical.acquired&&!InterlockedCompareExchange(&donorContactCancel,0,0));
#endif
 if(donorContactVertical.acquired&&donorContactVerticalRead(NULL,donorContactVertical.actor,donorContactOwnerEpoch,values)){event.z=values[0];event.vz=values[2];}
 if(!InterlockedCompareExchange(&donorContactEventLock,1,0)){
  unsigned next=(donorContactHead+1)%ARRAYSIZE(donorContactEvents);
  if(next!=donorContactTail){donorContactEvents[donorContactHead]=event;donorContactHead=next;}else InterlockedIncrement(&donorContactDropped);
  InterlockedExchange(&donorContactEventLock,0);
 }else InterlockedIncrement(&donorContactDropped);
 if(!valid||InterlockedCompareExchange(&donorContactCancel,0,0))donorContactOwnerRelease();
 donorContactOwnedFrame=false;
 (void)queries;
}
// 7c570 updates instance animation/processing but does NOT enclose the player
// collision callback. Scope ownership at the actual 1560d0 callback instead.
// Preserve both opaque arguments, invoke native collision once, then release
// the scope after its ground messages and context support flag are complete.
static void donorContactCollision(uintptr_t actor,uint64_t opaque2,uint64_t opaque3){
 bool owned=donorProcessIdentity(actor)&&donorContactOwnerBefore();
 donorContactOriginalCollision(actor,opaque2,opaque3);
 if(owned)donorContactOwnerAfter();
}
// Worker may request cleanup, but never restores game fields itself. If paused,
// retain the frame hook until the next frame can perform owned restoration.
static bool donorContactOwnerStop(void){
 InterlockedExchange(&donorContactCancel,1);
 if(!InterlockedCompareExchange(&donorContactReady,0,0)||InterlockedCompareExchange(&donorContactFinished,0,0))return true;
 logLine("DONOR_CONTACT cleanup pending next owning frame; hooks retained");return false;
}
typedef struct {
 uint32_t magic,version,hostPid,reserved;
 uint64_t hostCreation,hostEpoch,hostActor,donorCreation;
} DonorContactDescriptor;
_Static_assert(sizeof(DonorContactDescriptor)==48,"Contact descriptor ABI");
static bool donorContactDescriptorSeen;
static void donorContactOwnerTick(void){
 DonorContactFrameEvent events[128];unsigned n=0;
 if(!InterlockedCompareExchange(&donorContactEventLock,1,0)){
  while(donorContactTail!=donorContactHead){events[n++]=donorContactEvents[donorContactTail];donorContactTail=(donorContactTail+1)%ARRAYSIZE(donorContactEvents);}
  InterlockedExchange(&donorContactEventLock,0);
 }
 for(unsigned i=0;i<n;i++){DonorContactFrameEvent *e=events+i;
  logLine("DONOR_CONTACT_FRAME tick=%llu sequence=%llu phase=%u queries=%u acquired=%u valid=%u z=%.9g vz=%.9g dropped=%ld",e->tick,e->sequence,e->phase,e->queries,e->acquired,e->valid,e->z,e->vz,InterlockedCompareExchange(&donorContactDropped,0,0));
 }
 wchar_t file[512];_snwprintf(file,512,PROBE_PATH(L"\\donor-contact-%lu.bin"),GetCurrentProcessId());
 if(GetFileAttributesW(file)==INVALID_FILE_ATTRIBUTES){
  if(donorContactDescriptorSeen)InterlockedExchange(&donorContactCancel,1);
  return;
 }
 if(donorContactDescriptorSeen)return;
 donorContactDescriptorSeen=true;
 DonorContactDescriptor d={0};DWORD got=0;LARGE_INTEGER size={0};
 HANDLE f=CreateFileW(file,GENERIC_READ,FILE_SHARE_READ,NULL,OPEN_EXISTING,FILE_ATTRIBUTE_NORMAL,NULL);
 bool ok=f!=INVALID_HANDLE_VALUE&&GetFileSizeEx(f,&size)&&size.QuadPart==sizeof(d)&&ReadFile(f,&d,sizeof(d),&got,NULL)&&got==sizeof(d);
 if(f!=INVALID_HANDLE_VALUE)CloseHandle(f);
 uint64_t creation=0,now=GetTickCount64();
 ok=ok&&d.magic==0x31434448&&d.version==1&&!d.reserved&&d.hostPid&&d.hostPid!=GetCurrentProcessId()&&
  bridgeProcessCreation(GetCurrentProcess(),&creation)&&d.donorCreation==creation&&d.hostEpoch<=now&&now-d.hostEpoch<HOST_CONTACT_MAX_MS;
 HANDLE p=ok?OpenProcess(PROCESS_QUERY_LIMITED_INFORMATION|SYNCHRONIZE,FALSE,d.hostPid):NULL;
 wchar_t image[1024];DWORD length=ARRAYSIZE(image);char sha[65];uint64_t hostCreation=0;
 ok=ok&&p&&bridgeProcessCreation(p,&hostCreation)&&hostCreation==d.hostCreation&&WaitForSingleObject(p,0)==WAIT_TIMEOUT&&
  QueryFullProcessImageNameW(p,0,image,&length)&&hashFile(image,sha)&&!strcmp(sha,"0fb3aef0530ebf0510191f934dc371b69b43574331d3623eda694b72f060db93");
 if(p)CloseHandle(p);
 if(ok){
  wchar_t *slash=wcsrchr(image,L'\\');
  ok=slash&&((size_t)(slash-image)+12<ARRAYSIZE(image));
  if(ok){wcscpy(slash+1,L"1\\sr1.dll");ok=hashFile(image,sha)&&!strcmp(sha,"c006dea45509cdc3fbfab3a4230b47869c306ecdd7df8b4fd2499fd3654a2205");}
 }
 if(ok){HostContactLease expected={.pid=d.hostPid,.creation=d.hostCreation,.epoch=d.hostEpoch,.actor=d.hostActor};ok=donorContactOwnerArm(expected);}
 if(!ok)InterlockedExchange(&donorContactCancel,1);
 logLine("DONOR_CONTACT armed=%u host=%lu epoch=%llu; explicit bounded descriptor",ok,(unsigned long)d.hostPid,d.hostEpoch);
}
