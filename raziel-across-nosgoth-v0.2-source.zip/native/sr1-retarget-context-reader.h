// SPDX-License-Identifier: GPL-3.0-or-later
#pragma once
#include "host-rig-reader.h"
#include "sr1-retarget-gate.h"
#ifdef SR1_NATIVE_CROUCH_HOLD
#include "sr1-crouch-hold.h"
#endif
static inline bool sr1RetargetReadContext(void *p,RigRead read,uintptr_t base,uintptr_t actor,bool foreground,Sr1RetargetContext *s){
 uintptr_t owner=0,again=0,cb[3],cbAfter=0;uint16_t mode=0,mode2=0;uint32_t flags=0,flags2=0;int32_t velocity=0,velocityAfter=0;memset(s,0,sizeof(*s));s->foreground=foreground;
 const Sheet_retargetNativeAirGuard *air=&sheet_retargetNativeAirGuard_sr1;
 if(air->verticalVelocityOffset!=0x2d4||air->verticalVelocityBytes!=4||!air->zeroVerticalVelocityRequired||air->hostWrites||!read(p,base+0x2a88588,&owner,8)||owner!=actor||!read(p,base+0x2a89536,&mode,2)||!read(p,base+0x2a8950c,&flags,4)||!read(p,actor+air->verticalVelocityOffset,&velocity,4))return false;
 for(unsigned i=0;i<3;i++){if(!read(p,base+0x2a88598+i*0x228,cb+i,8)||cb[i]<base||cb[i]-base>UINT32_MAX)return false;s->callbacks[i]=(uint32_t)(cb[i]-base);}
 if(!read(p,base+0x2a88588,&again,8)||again!=owner||!read(p,base+0x2a89536,&mode2,2)||mode2!=mode||!read(p,base+0x2a8950c,&flags2,4)||flags2!=flags||!read(p,actor+air->verticalVelocityOffset,&velocityAfter,4)||velocityAfter!=velocity)return false;
 for(unsigned i=0;i<3;i++)if(!read(p,base+0x2a88598+i*0x228,&cbAfter,8)||cbAfter!=cb[i])return false;
#ifdef SR1_NATIVE_CROUCH_HOLD
 if(!sr1CrouchHeld(p,read,base,&s->crouchHeld))return false;
#endif
#ifdef SR1_AIR_COMBAT_POSE
 // Only the ordinary clips proved by the native Landing/Compression handlers.
 // Read both legacy and HD sections twice; heavy/crouched transitions remain native.
 uint16_t airClips[6]={0};bool hasAirSections=false;
 for(unsigned i=0;i<3;i++)hasAirSections=hasAirSections||s->callbacks[i]==0xedb40||s->callbacks[i]==0xee600;
 for(unsigned i=0;i<3&&hasAirSections;i++){
  for(unsigned hd=0;hd<2;hd++){
   uintptr_t at=actor+(hd?0x480:0x358)+i*0x50+0x1c;uint16_t clip=0,check=0;
   if(!read(p,at,&clip,2)||!read(p,at,&check,2)||clip!=check)return false;
   airClips[hd*3+i]=clip;
  }
 }
 s->ordinaryAirTransition=sr1OrdinaryAirPattern(s->callbacks,airClips);
 for(unsigned i=0;i<3;i++)if(!read(p,base+0x2a88598+i*0x228,&cbAfter,8)||cbAfter!=cb[i])return false;
#endif
 s->identity=true;s->mode=mode;s->flags=flags;s->verticalVelocityKnown=true;s->verticalVelocity=velocity;return true;
}
