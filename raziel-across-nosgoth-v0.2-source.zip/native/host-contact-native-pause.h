// SPDX-License-Identifier: GPL-3.0-or-later
#pragma once
#include <stdint.h>
#include <stdbool.h>
// Read-only classification of previously proved native actions. No inference
// from zero velocity or an absent floor query. Not a grounded/airborne claim.
static inline bool hostContactNativePause(const uint64_t callbacks[3]) {
 bool native=false;
 if(!callbacks)return false;
 for(unsigned i=0;i<3;i++) {
  switch(callbacks[i]) {
   case 0xeded0: case 0xefb50: case 0xf48e0: case 0xf1ad0:
   case 0xecf70: // Measured v36 spectral bars, control 0x8001.
   case 0xf8c80: case 0xf8e90: // Exact remaster wall grab / climbing loop.
   case 0xf0240: native=true;break; // Native glyph/realm transition handler.
   case 0xf2180: case 0xf3280: case 0xf4dc0: case 0xf5340:
   case 0xf54d0: case 0xedb40: case 0xee600: case 0xf2ae0:
   case 0xef480: break;
   default:return false;
  }
 }
 return native;
}
// Completed Hang receipts in v34r1: all sections f1ad0, c001501 then c001101.
// Only this exact native suspension may carry the otherwise refused bit.
static inline bool hostContactNativeHangControl(uint32_t control,const uint64_t callbacks[3]) {
 return (control==0x0c001101u||control==0x0c001501u)&&callbacks&&callbacks[0]==0xf1ad0&&callbacks[1]==0xf1ad0&&callbacks[2]==0xf1ad0;
}
