// Exact supported StartMove, Move and character state switch.
static const struct {uint32_t rva,size;const char *sha256;} instantStartProofs[]={
{0xf48e0,2645,"cc5e1370c009f245427e923c7dc69d2bd56dbecbcd6d8fc1898969e83ec8dcc6"},
{0xf3280,1415,"46855583078b552abda6035af7e9c1ab618de7fef1107fc8f2191d792589fbdb"},
{0x10ffc0,163,"63eb4bed3b211f66b7a81f4e0ff1d3705e7883fcfcc1ab6362bcc3bffb576202"},
};
