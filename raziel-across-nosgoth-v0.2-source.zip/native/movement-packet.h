// RZM1 limited ground-translation command, separate from visual pose transport.
#ifndef MOVEMENT_PACKET_H
#define MOVEMENT_PACKET_H
static bool movementPacketTarget(const unsigned char *bytes,size_t size,uint64_t now,uint32_t posePid,uint64_t poseTick,int32_t hostTime,float *target,uint64_t *sourceTick){
 static const unsigned char hash[32]={0xfc,0x6a,0x40,0x6f,0xf7,0xac,0x9b,0x5e,0xb7,0x78,0x8d,0xc7,0xa6,0x5d,0x33,0x5e,0x1c,0x1a,0xad,0x92,0x36,0x61,0x81,0x12,0x67,0x19,0x75,0xb7,0x1d,0x2d,0xad,0xdc};
 if(size!=80||!bytes||!posePid||!poseTick||hostTime<=0||hostTime>8192)return false;
 uint32_t words[20];memcpy(words,bytes,80);uint64_t tick;memcpy(&tick,bytes+16,8);float factor,v[3];memcpy(&factor,bytes+24,4);memcpy(v,bytes+28,12);
 if(words[0]!=0x314d5a52||words[1]!=1||words[2]!=posePid||(words[10]!=1&&words[10]!=2)||words[11]||memcmp(bytes+48,hash,32)||
  tick>now||now-tick>150||poseTick>now||now-poseTick>250||(tick>poseTick?tick-poseTick:poseTick-tick)>100||
  !isfinite(factor)||factor<.01f||factor>2||!isfinite(v[0])||!isfinite(v[1])||!isfinite(v[2])||fabsf(v[0])>.001f||fabsf(v[2])>.001f||v[1]>0||v[1]/factor < -120)return false;
 if(words[10]==2&&(v[0]!=0||v[1]!=0||v[2]!=0))return false;
 *target=v[1]/factor*((float)hostTime/4096);*sourceTick=tick;return isfinite(*target)&&*target>=-240&&*target<=0;
}
#endif
