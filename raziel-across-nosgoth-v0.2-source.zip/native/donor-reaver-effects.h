// SPDX-License-Identifier: GPL-3.0-or-later
#pragma once
#include "donor-reaver-reader.h"
typedef struct {unsigned type;uint32_t callbackRva;bool weaponOwner;} ReaverEffectMetadata;
typedef struct {bool valid;unsigned reason,visited,owned;ReaverEffectMetadata items[64];} ReaverEffects;
// Scalar census only. No native calls, asset bytes or process addresses leave here.
static inline ReaverEffects reaverEffects(void *c,ReaverRead read,uintptr_t base,uint32_t size,uintptr_t actor,uintptr_t weapon){
 ReaverEffects out={0};out.reason=1;
 const Sheet_reaverEffectObservation *p=&sheet_reaverEffectObservation_bounded_effects;
 if(!read||!base||!actor||!weapon||size<8||base>UINTPTR_MAX-size||p->nativeIntegrationEnabled||p->maxNodes<=0||p->maxNodes>256||p->maxOwned<=0||p->maxOwned>64||p->headerBytes!=25||p->headRva>size-8||p->nextOffset!=0||p->callbackOffset!=8||p->ownerOffset!=16||p->typeOffset!=24)return out;
 uintptr_t head=0,node=0,seen[256]={0},again=0;unsigned char headers[256][25];
 out.reason=2;if(!reaverField(c,read,base,p->headRva,&head,8))return out;node=head;
 while(node){
  out.reason=3;if(node%8||out.visited>=(unsigned)p->maxNodes)return out;
  for(unsigned i=0;i<out.visited;i++)if(seen[i]==node){out.reason=4;return out;}
  seen[out.visited++]=node;
  unsigned char a[25],b[25];uintptr_t next=0,callback=0,owner=0;
  out.reason=5;if(!reaverField(c,read,node,0,a,sizeof(a))||!reaverField(c,read,node,0,b,sizeof(b))||memcmp(a,b,sizeof(a)))return out;
  memcpy(headers[out.visited-1],a,sizeof(a));
  memcpy(&next,a+p->nextOffset,8);memcpy(&callback,a+p->callbackOffset,8);memcpy(&owner,a+p->ownerOffset,8);
  if(owner==weapon||owner==actor){
   out.reason=6;if(out.owned>=(unsigned)p->maxOwned||callback<base||callback-base>=size)return out;
   out.items[out.owned++]=(ReaverEffectMetadata){.type=a[p->typeOffset],.callbackRva=(uint32_t)(callback-base),.weaponOwner=owner==weapon};
  }
  node=next;
 }
 out.reason=7;if(!reaverField(c,read,base,p->headRva,&again,8)||again!=head)return out;
 // Revalidate links/owners after traversal: allocator reuse must not look coherent.
 for(unsigned i=0;i<out.visited;i++){
  unsigned char current[25];out.reason=8;if(!reaverField(c,read,seen[i],0,current,sizeof(current))||memcmp(current,headers[i],sizeof(current)))return out;
 }
 out.valid=true;out.reason=0;return out;
}
