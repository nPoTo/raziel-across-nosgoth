// SPDX-License-Identifier: GPL-3.0-or-later
#define WIN32_LEAN_AND_MEAN
#include <string.h>
#include <stdlib.h>
#include "render-memory-reader.h"
int main(void) {
    printf("PID %lu\n",GetCurrentProcessId());fflush(stdout);
    unsigned char *buffer=malloc(RM_APPEARANCE_BYTES),movement[RM_MOVEMENT_BYTES];if(!buffer)return 1;
    ULONGLONG deadline=GetTickCount64()+10000;bool online=false;
    while(GetTickCount64()<deadline) {
        if(renderMemoryCopy(1,buffer,RM_APPEARANCE_BYTES)) {
            for(size_t i=0;i<RM_APPEARANCE_BYTES;i++)if(buffer[i]!=0x5a)return 2;
            if(!renderMemoryCopy(0,buffer,RM_GEOMETRY_BYTES))continue;
            for(size_t i=0;i<RM_GEOMETRY_BYTES;i++)if(buffer[i]!=0xa5)return 3;
            if(!renderMemoryCopy(2,buffer,RM_LIVE_BYTES))continue;
            for(size_t i=0;i<RM_LIVE_BYTES;i++)if(buffer[i]!=0x3c)return 4;
            if(!renderMemoryMovementCopy(movement))continue;
            for(size_t i=0;i<sizeof(movement);i++)if(movement[i]!=0x69)return 7;
            online=true;printf("ONLINE\n");fflush(stdout);break;
        }Sleep(5);
    }
    if(!online)return 5;
    deadline=GetTickCount64()+5000;
    bool cleared=false;
    while(GetTickCount64()<deadline) {
        if(!cleared&&renderMemoryMovementCopy(movement)&&movement[0]==0){
            for(size_t i=0;i<sizeof(movement);i++)if(movement[i])return 8;
            cleared=true;puts("CLEARED");fflush(stdout);
        }
        if(!renderMemoryCopy(2,buffer,RM_LIVE_BYTES)&&!renderMemoryView){
            if(renderMemoryMovementCopy(movement))return 9;
            free(buffer);puts("PASS: exact static/live/command bytes, command clearing, publisher loss and handle cleanup");return 0;
        }Sleep(5);
    }
    free(buffer);renderMemoryClose();return 6;
}
