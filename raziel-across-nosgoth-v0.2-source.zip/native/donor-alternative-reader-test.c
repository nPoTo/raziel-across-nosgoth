// SPDX-License-Identifier: GPL-3.0-or-later
#define main contextFixtureMainUnused
#include "donor-animation-context-reader-test.c"
#undef main
#include "donor-alternative-reader.h"
static int change;static unsigned tableReads;
static const uintptr_t list=0x80000000,row=0x81000000,alternate=0x82000000;
static bool variant(void *c,uintptr_t address,void *out,SIZE_T n){
 uintptr_t v=0;
 if(address==context+0x58&&n==8){v=change==7?UINTPTR_MAX-7:list;if(change==4&&++tableReads>1)v+=8;}
 else if(address>=list&&address<=list+64*8&&n==8){unsigned index=(unsigned)((address-list)/8);v=index==0?row:0;if(change==3)v=row;if(change==6)v=0;if(change==8&&index==0)return false;}
 else if(address==row&&n==8)v=change==9?UINTPTR_MAX-7:alternate;
 else if(address==alternate&&n==16){if(change==5)return false;memset(out,0,n);return true;}
 else{for(unsigned i=0;i<3;i++){if(address==state+0x248+i*0x250&&n==4){uint32_t k=53;memcpy(out,&k,4);return true;}if(address==state+0x250+i*0x250&&n==8){v=change==1?alternate:change==2&&i==1?alternate:descriptors;memcpy(out,&v,8);return true;}}return fixture(c,address,out,n);}
 memcpy(out,&v,n);return true;
}
static DonorAlternativeObservation inspect(void){reads=actorReads=tableReads=0;return donorAlternativeRead(NULL,variant,base,0x2000000,model);}
int main(void){DonorAlternativeObservation r=inspect();CHECK(r.valid&&r.rows==1&&r.baseMask==7&&!r.alternativeMask&&r.classifiedMask==7,1);change=1;r=inspect();CHECK(r.valid&&!r.baseMask&&r.alternativeMask==7&&r.classifiedMask==7,2);change=2;r=inspect();CHECK(r.valid&&r.baseMask==5&&r.alternativeMask==2&&r.classifiedMask==7,3);
 for(change=3;change<=5;change++)CHECK(!inspect().valid,change+1);change=6;r=inspect();CHECK(r.valid&&!r.rows&&r.baseMask==7&&!r.alternativeMask,7);for(change=7;change<=9;change++)CHECK(!inspect().valid,change+1);change=0;defect=1;CHECK(!inspect().valid,11);defect=2;CHECK(!inspect().valid,12);defect=0;CHECK(!donorAlternativeRead(NULL,variant,base,0x1000000,model).valid,13);
 puts("PASS: production base/alternative/mixed descriptor membership, empty table, bounded unterminated table, table/actor/model race, unreadable/overflow refusal; scalar-only output");return 0;}
