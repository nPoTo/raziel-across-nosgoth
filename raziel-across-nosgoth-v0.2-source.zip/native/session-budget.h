// SPDX-License-Identifier: GPL-3.0-or-later
#ifndef SESSION_BUDGET_H
#define SESSION_BUDGET_H
#include <stdint.h>
#include <stdbool.h>
// -1 diagnostic mode; 0 expired normal lease; 1 healthy normal lease.
static int (*sessionBudgetExtended)(uint64_t);
static inline bool sessionBudget(uint64_t begin,uint64_t now,uint64_t duration){
 if(!begin||now<begin)return false;
 int lease=sessionBudgetExtended?sessionBudgetExtended(now):-1;
 return lease>=0?lease==1:now-begin<duration;
}
#endif
