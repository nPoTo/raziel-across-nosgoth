#include <stdint.h>
#include <string.h>
#include <math.h>
#include <stdio.h>
#include "smooth-normals.h"
int main(void) {
    float p[]={0,0,0, 1,0,0, 0,1,0, 0,0,1, 9,9,9};
    uint32_t t[]={0,1,2, 0,3,1, 4,4,4}; float n[15];
    smoothNormals(p,t,5,9,n);
    if(fabsf(n[1]-.70710678f)>1e-6f || fabsf(n[2]-.70710678f)>1e-6f || n[8]!=1 || n[10]!=1 || n[14]!=1) return 1;
    p[11]=2; smoothNormals(p,t,5,9,n);
    if(fabsf(n[1]-.89442719f)>1e-6f || fabsf(n[2]-.44721359f)>1e-6f) return 2;
    puts("Smooth normals: shared edge, unequal area, changed pose, degenerate/isolated PASS"); return 0;
}
