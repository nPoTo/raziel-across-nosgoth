// SPDX-License-Identifier: GPL-3.0-or-later
#include <stdint.h>
#include <stdbool.h>
#include <stdio.h>
#include <string.h>
static unsigned char actorBytes[384],objectBytes[96],matrixBytes[32],nextMatrix[32];
static char actorName[9]="raziel__";
static uintptr_t actorPointer;static unsigned ownerReads;static bool replaceOwner,denyMatrix,advanceMatrix;
static bool worldRead(uintptr_t p,void *out,size_t size){
 if(p==0x10000000+0x2a89310&&size==8){uintptr_t v=replaceOwner&&ownerReads++?0:actorPointer;memcpy(out,&v,8);return true;}
 if(p>=(uintptr_t)actorBytes&&p+size<=(uintptr_t)actorBytes+sizeof(actorBytes)){memcpy(out,(void *)p,size);if(advanceMatrix&&p==(uintptr_t)actorBytes+0x68&&size==8){uintptr_t next=(uintptr_t)nextMatrix;memcpy(actorBytes+0x68,&next,8);}return true;}
 if(p>=(uintptr_t)objectBytes&&p+size<=(uintptr_t)objectBytes+sizeof(objectBytes)){memcpy(out,(void *)p,size);return true;}
 if(p==(uintptr_t)actorName&&size==9){memcpy(out,actorName,9);return true;}
 if(p==(uintptr_t)matrixBytes&&size==32&&!denyMatrix){memcpy(out,matrixBytes,32);return true;}
 return false;
}
#include "world-actor.h"
#define CHECK(x) do{if(!(x)){printf("FAIL actor line%d\n",__LINE__);return 1;}}while(0)
int main(void){
 actorPointer=(uintptr_t)actorBytes;uintptr_t obj=(uintptr_t)objectBytes,name=(uintptr_t)actorName,matrix=(uintptr_t)matrixBytes,out=0;
 memcpy(actorBytes+0x30,&obj,8);memcpy(objectBytes+0x30,&name,8);memcpy(actorBytes+0x68,&matrix,8);
 // Readable changing/non-orthogonal physics data does not mean actor absence.
 memset(matrixBytes,0xa5,sizeof(matrixBytes));CHECK(worldActorRead(0x10000000,&out)&&out==actorPointer);
 advanceMatrix=true;CHECK(worldActorRead(0x10000000,&out)&&out==actorPointer);advanceMatrix=false;memcpy(actorBytes+0x68,&matrix,8);
 CHECK(!worldActorRead(0,&out)&&!worldActorRead(0x10000000,NULL));
 actorName[0]='k';CHECK(!worldActorRead(0x10000000,&out));actorName[0]='r';
 denyMatrix=true;CHECK(!worldActorRead(0x10000000,&out));denyMatrix=false;
 replaceOwner=true;ownerReads=0;CHECK(!worldActorRead(0x10000000,&out));replaceOwner=false;
 uintptr_t zero=0;memcpy(actorBytes+0x30,&zero,8);CHECK(!worldActorRead(0x10000000,&out));memcpy(actorBytes+0x30,&obj,8);
 memcpy(actorBytes+0x68,&zero,8);CHECK(!worldActorRead(0x10000000,&out));memcpy(actorBytes+0x68,&matrix,8);
 puts("PASS: actual actor identity predicate, changing transform independent, wrong name/missing/unreadable/replaced actor rejection");return 0;
}
