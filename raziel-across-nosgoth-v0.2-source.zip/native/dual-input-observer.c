// SPDX-License-Identifier: GPL-3.0-or-later
// Read-only, foreground-only SRX input boundary observation. No hooks/injection.
#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <tlhelp32.h>
#include <stdint.h>
#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <wchar.h>
#include <string.h>
#include "dual-input-sheets.h"
static DWORD pid;static HWND game,overlay;static unsigned elapsed;static HFONT font;
#ifdef INPUT_FRAME_SCENARIO
#define OBSERVE_SECONDS 55
static const wchar_t *title(unsigned s){return s<20?L"ПОДГОТОВКА — ЧАКАЙ НЕПОДВИЖНО":s<50?L"КЛАВИАТУРА И МИШКА — SR1":L"ОТПУСНИ ВСИЧКО";}
static const wchar_t *detail(unsigned s){return s<20?L"Само наблюдение. Действията започват след подготовката.":s<50?L"WASD, Space, ляв/десен клик, Shift, Ctrl, E — поотделно, с отпускане.":L"Изчакай края. Контролер не е нужен.";}
#else
#define OBSERVE_SECONDS 65
static const wchar_t *title(unsigned s){return s<20?L"ПОДГОТОВКА — ЧАКАЙ НЕПОДВИЖНО":s<40?L"КЛАВИАТУРА И МИШКА — SR1":s<60?L"КОНТРОЛЕР — SR1":L"ОТПУСНИ ВСИЧКО";}
static const wchar_t *detail(unsigned s){return s<20?L"Само наблюдение. Модът не е включен.":s<40?L"W, Space, Ctrl, Shift, ляв/десен клик, E — поотделно, с отпускане.":s<60?L"Стик, A, LT, RB, X, Y, B — поотделно, с отпускане.":L"Изчакай края на записа.";}
#endif
static LRESULT CALLBACK proc(HWND w,UINT m,WPARAM a,LPARAM b){
 if(m==WM_NCHITTEST)return HTTRANSPARENT;if(m==WM_MOUSEACTIVATE)return MA_NOACTIVATE;
 if(m==WM_PAINT){PAINTSTRUCT p;HDC dc=BeginPaint(w,&p);RECT r;GetClientRect(w,&r);FillRect(dc,&r,GetStockObject(BLACK_BRUSH));SetBkMode(dc,TRANSPARENT);SetTextColor(dc,RGB(255,255,255));HGDIOBJ old=SelectObject(dc,font);RECT t={12,8,r.right-12,45};DrawTextW(dc,title(elapsed),-1,&t,DT_CENTER|DT_SINGLELINE);t.top=50;t.bottom=90;DrawTextW(dc,detail(elapsed),-1,&t,DT_CENTER|DT_SINGLELINE);wchar_t count[80];swprintf(count,80,L"Остават %u сек.",OBSERVE_SECONDS-elapsed);t.top=95;t.bottom=130;DrawTextW(dc,count,-1,&t,DT_CENTER|DT_SINGLELINE);SelectObject(dc,old);EndPaint(w,&p);return 0;}
 return DefWindowProcW(w,m,a,b);
}
static BOOL CALLBACK find(HWND w,LPARAM unused){(void)unused;DWORD owner=0;GetWindowThreadProcessId(w,&owner);RECT r;if(owner==pid&&IsWindowVisible(w)&&!GetWindow(w,GW_OWNER)&&GetClientRect(w,&r)&&r.right>=512&&r.bottom>=384)game=w;return TRUE;}
static bool readAt(HANDLE p,uintptr_t a,void *out,SIZE_T size){SIZE_T n=0;return ReadProcessMemory(p,(void*)a,out,size,&n)&&n==size;}
int wmain(int argc,wchar_t **argv){
 if(argc==2&&!wcscmp(argv[1],L"--self-test")){uint32_t x=123,y=0;if(!readAt(GetCurrentProcess(),(uintptr_t)&x,&y,4)||y!=x)return 20;if(wcscmp(title(19),title(20))==0||wcscmp(title(OBSERVE_SECONDS-6),title(OBSERVE_SECONDS-5))==0)return 21;puts("PASS read-only read and 20/40/60 stage boundaries");return 0;}
 if(argc!=3)return 2;wchar_t *end;pid=wcstoul(argv[1],&end,10);if(!pid||*end)return 2;
 HANDLE p=OpenProcess(PROCESS_VM_READ|PROCESS_QUERY_LIMITED_INFORMATION|SYNCHRONIZE,FALSE,pid);if(!p)return 3;
 wchar_t exe[32768];DWORD n=32768;if(!QueryFullProcessImageNameW(p,0,exe,&n)||_wcsicmp(exe,L"C:\\Program Files (x86)\\Steam\\steamapps\\common\\Soul Reaver I-II\\SRX.exe"))return 4;
 uintptr_t base=0;HANDLE snap=CreateToolhelp32Snapshot(TH32CS_SNAPMODULE,pid);MODULEENTRY32W mod={.dwSize=sizeof(mod)};if(snap!=INVALID_HANDLE_VALUE){if(Module32FirstW(snap,&mod))do{if(!_wcsicmp(mod.szModule,L"SRX.exe"))base=(uintptr_t)mod.modBaseAddr;}while(Module32NextW(snap,&mod));CloseHandle(snap);}if(!base)return 5;
 // All RVAs from the hash-gated REA dossiers; external launcher validates image hash.
 const Sheet_dualInputObservation *policy=&sheet_dualInputObservation_srx;
 if(policy->bindingCount!=13||policy->keyCount!=112)return 6;
 uint32_t bindings[13][3],second[13][3];if(!readAt(p,base+policy->bindingRva,bindings,sizeof(bindings))||!readAt(p,base+policy->bindingRva,second,sizeof(second))||memcmp(bindings,second,sizeof(bindings)))return 6;
 FILE *out=_wfopen(argv[2],L"wx");if(!out)return 7;
 fprintf(out,"{\"type\":\"session\",\"pid\":%lu,\"readOnly\":true,\"bindings\":[",pid);for(unsigned i=0;i<13;i++)fprintf(out,"%s[%u,%u,%u]",i?",":"",bindings[i][0],bindings[i][1],bindings[i][2]);fprintf(out,"]}\n");fflush(out);
 SetProcessDPIAware();WNDCLASSW wc={0};wc.lpfnWndProc=proc;wc.hInstance=GetModuleHandleW(NULL);wc.lpszClassName=L"SR1DualInputReadOnly";if(!RegisterClassW(&wc))return 8;
 font=CreateFontW(22,0,0,0,FW_BOLD,0,0,0,DEFAULT_CHARSET,0,0,ANTIALIASED_QUALITY,0,L"Segoe UI");
 overlay=CreateWindowExW(WS_EX_LAYERED|WS_EX_TRANSPARENT|WS_EX_TOPMOST|WS_EX_TOOLWINDOW|WS_EX_NOACTIVATE,wc.lpszClassName,L"SR1 input observation",WS_POPUP,0,0,1200,140,0,0,wc.hInstance,0);if(!overlay)return 9;SetLayeredWindowAttributes(overlay,0,255,LWA_COLORKEY);
 uint64_t waiting=GetTickCount64(),start=0,lastPaint=0;unsigned samples=0,rejected=0;bool complete=false;
 while(WaitForSingleObject(p,0)!=WAIT_OBJECT_0){
  MSG msg;while(PeekMessageW(&msg,NULL,0,0,PM_REMOVE)){TranslateMessage(&msg);DispatchMessageW(&msg);}
  uint64_t now=GetTickCount64();DWORD foreground=0;GetWindowThreadProcessId(GetForegroundWindow(),&foreground);
  if(foreground!=pid){ShowWindow(overlay,SW_HIDE);if(start){fprintf(out,"{\"type\":\"stop\",\"reason\":\"focus_lost\"}\n");break;}if(now-waiting>120000)break;Sleep(20);continue;}
  if(!start)start=now;elapsed=(unsigned)((now-start)/1000);if(elapsed>=OBSERVE_SECONDS){complete=true;break;}
  if((samples+rejected)%64==0&&(!readAt(p,base+policy->bindingRva,second,sizeof(second))||memcmp(bindings,second,sizeof(bindings)))){fprintf(out,"{\"type\":\"stop\",\"reason\":\"bindings_changed\"}\n");break;}
  if(now-lastPaint>=100){game=NULL;EnumWindows(find,0);RECT r;POINT pt={0};if(game&&GetClientRect(game,&r)&&ClientToScreen(game,&pt)){SetWindowPos(overlay,HWND_TOPMOST,pt.x,pt.y,r.right,140,SWP_NOACTIVATE|SWP_SHOWWINDOW);InvalidateRect(overlay,NULL,FALSE);UpdateWindow(overlay);}lastPaint=now;}
  unsigned char keys[112],again[112];uint32_t keyboard=0,pad=0;
  uint32_t keyboardAgain=0,padAgain=0;
  bool ok=readAt(p,base+policy->keyRva,keys,sizeof(keys))&&readAt(p,base+policy->keyboardMaskRva,&keyboard,4)&&readAt(p,base+policy->padMaskRva,&pad,4)&&readAt(p,base+policy->keyRva,again,sizeof(again))&&readAt(p,base+policy->keyboardMaskRva,&keyboardAgain,4)&&readAt(p,base+policy->padMaskRva,&padAgain,4)&&keyboard==keyboardAgain&&pad==padAgain&&!memcmp(keys,again,sizeof(keys));
  if(ok){fprintf(out,"{\"type\":\"sample\",\"tick\":%llu,\"elapsedMs\":%llu,\"keyboardMask\":%u,\"padMask\":%u,\"held\":[",(unsigned long long)now,(unsigned long long)(now-start),keyboard,pad);unsigned count=0;for(unsigned i=0;i<112;i++)if(keys[i])fprintf(out,"%s%u",count++?",":"",i);fprintf(out,"]}\n");samples++;}else rejected++;
  Sleep(16);
 }
 fprintf(out,"{\"type\":\"end\",\"complete\":%s,\"samples\":%u,\"incoherent\":%u}\n",complete?"true":"false",samples,rejected);fclose(out);DestroyWindow(overlay);DeleteObject(font);CloseHandle(p);return complete?0:10;
}
