// SPDX-License-Identifier: GPL-3.0-or-later
#include "host-contact-shared.h"
#include <assert.h>
#include <stdio.h>
int main(void){
 HostContactLease l={.pid=42,.creation=123,.epoch=1000,.actor=0x1000};
 HostContactSnapshot s={.magic=HOST_CONTACT_MAGIC,.version=HOST_CONTACT_VERSION,.pid=42,.phase=1,.creation=123,.epoch=1000,.tick=1000,.sequence=1,.actor=0x1000,.control=0x519,.coherent=1};
 bool fresh;assert(hostContactAccept(&l,&s,s.tick,true,&fresh));
 const uint64_t actions[]={0xeded0,0xefb50,0xf48e0,0xf1ad0,0xecf70,0xf8c80,0xf8e90,0xf0240};
 for(unsigned a=0;a<sizeof(actions)/sizeof(actions[0]);a++){
  for(unsigned part=0;part<3;part++){
   for(unsigned i=0;i<3;i++)s.callbacks[i]=i==part?actions[a]:0xf2180;
   s.tick+=100;s.sequence++;s.phase=4;
   assert(hostContactAccept(&l,&s,s.tick,true,&fresh)&&fresh&&!l.revoked);
   assert(l.last.phase==4); // Never reported as a ground contact.
  }
  s.tick+=100;s.sequence++;s.phase=1;
  for(unsigned i=0;i<3;i++)s.callbacks[i]=0xf2180;
  assert(hostContactAccept(&l,&s,s.tick,true,&fresh)&&!l.revoked);
 }
 s.tick+=100;s.sequence++;s.phase=4;s.control=0x0c001101;
 for(unsigned i=0;i<3;i++)s.callbacks[i]=0xf1ad0;
 assert(hostContactAccept(&l,&s,s.tick,true,&fresh));
 s.control=0x0c001501;s.sequence++;s.tick++;assert(hostContactAccept(&l,&s,s.tick,true,&fresh));
 for(unsigned fault=0;fault<3;fault++){
  HostContactLease x=l;HostContactSnapshot b=s;b.sequence++;
  if(fault==0)b.callbacks[1]=0xf2180;
  if(fault==1)b.control^=1;
  if(fault==2)b.phase=2;
  assert(!hostContactAccept(&x,&b,b.tick,true,&fresh));
 }
 s.control=0x519;s.phase=1;for(unsigned i=0;i<3;i++)s.callbacks[i]=0xf2180;
 s.tick=190000;s.sequence++;assert(hostContactAccept(&l,&s,s.tick,true,&fresh));
 for(unsigned fault=0;fault<6;fault++){
  HostContactLease x=l;HostContactSnapshot b=s;b.sequence++;b.phase=4;b.callbacks[0]=0xefb50;
  if(fault==0)b.callbacks[1]=0xdead;
  if(fault==1)b.coherent=0;
  if(fault==2)b.version=1;
  if(fault==3)b.tick=201001;
  if(fault==4)b.actor++;
  if(fault==5)b.callbacks[0]=0xf2180;
  assert(!hostContactAccept(&x,&b,b.tick,true,&fresh)&&x.revoked);
 }
 s.phase=4;s.callbacks[0]=0xefb50;s.sequence++;
 assert(!hostContactAccept(&l,&s,s.tick+151,true,&fresh)&&l.revoked);
 puts("PASS ground/native/ground suspension, mixed sections, late session, unknown/stale/foreign/version/deadline refusal");
}
