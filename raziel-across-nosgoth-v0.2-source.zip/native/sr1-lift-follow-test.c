#include <assert.h>
#include <stdio.h>
#include <xinput.h>
#include "host-contact-source.h"
#include "sr1-skeleton-shared.h"
static HostContactSource hostContactSource;
static PVOID sr1SkeletonView;
typedef struct {bool ordinaryAirTransition;uintptr_t callbacks[3];bool ground;} Sr1RetargetContext;
static bool sr1RetargetContextAllowed(const Sr1RetargetContext *c){return c->ground;}
#define logLine(...) ((void)0)
#include "sr1-lift-follow.h"
int main(void){
 uint64_t now=GetTickCount64();assert(hostContactSourceOpen(&hostContactSource,now));uintptr_t actor=0x123400;
 SkeletonShared skeleton={0};sr1SkeletonView=&skeleton;
 SkeletonSnapshot s={.magic=SKELETON_MAGIC,.version=1,.hostPid=GetCurrentProcessId(),.sourcePid=991,.writerPid=992,.mode=2,.epoch=now,.tick=now,.hostTick=now,.sourceTick=now,.sequence=1,.actor=actor,.object=1,.model=2};
 memcpy(s.policyHash,skeletonPolicyHash,32);for(unsigned i=0;i<66;i++)s.bones[i][0]=s.bones[i][4]=s.bones[i][8]=1;skeletonStore(&skeleton,&s);
 AirClockShared shared={0};srLiftView=&shared;
 AirClockPacket a={.magic=0x314c4341,.version=1,.hostPid=GetCurrentProcessId(),.donorPid=991,.hostCreation=hostContactSource.creation,.epoch=now,.tick=now,.actor=actor,.sequence=1,.active=0};airClockStore(&shared,&a);
 Sr1RetargetContext c={.ground=true};
 assert(srLiftApply(0,now,actor,true,&c,0,0)==0);
 assert(srLiftApply(0,now+1,actor,true,&c,0x8000,0)==0);
 a.active=1;airClockStore(&shared,&a);
 assert(srLiftApply(0,now+2,actor,true,&c,0x8000,0)==0x1000);
 c.ground=false;assert(srLiftApply(0,now+3,actor,true,&c,0x8000,0)==0);
 c.ground=true;assert(srLiftApply(0,now+70,actor,true,&c,0x8000,0)==0);
 srLiftApply(0,now+71,actor,true,&c,0,0);
 a.donorPid=993;airClockStore(&shared,&a);assert(srLiftApply(0,now+72,actor,true,&c,0x8000,0)==0);
 a.donorPid=991;airClockStore(&shared,&a);assert(srLiftApply(0,now+73,actor,true,&c,0x8000,0)==0);
 srLiftApply(0,now+74,actor,true,&c,0,0);assert(srLiftApply(0,now+101,actor,true,&c,0x8000,0)==0);
 a.tick=now+102;airClockStore(&shared,&a);srLiftApply(0,now+102,actor,true,&c,0,0);
 InterlockedExchange(&shared.revoked,1);assert(srLiftApply(0,now+103,actor,true,&c,0x8000,0)==0);
 assert(srLiftApply(4,now,actor,true,&c,0x8000,0)==0);
 hostContactSourceStop(&hostContactSource);(void)srLiftTick;
 puts("PASS host lift RAM receipt: neutral arm, rising source, one jump, no airborne A, source mismatch/freshness/revocation");
}
