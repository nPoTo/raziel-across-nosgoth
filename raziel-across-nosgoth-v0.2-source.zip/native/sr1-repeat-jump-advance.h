// SPDX-License-Identifier: GPL-3.0-or-later
#pragma once
#include "repeat-jump-advance.h"
#ifdef SR1_NATIVE_SKELETON_ADAPTER
#include "repeat-jump-advance-proof.h"
typedef uintptr_t (__fastcall *RepeatStateFn)(uintptr_t,int32_t,uintptr_t);
typedef void (__fastcall *RepeatQueueFn)(uintptr_t,uint32_t,uintptr_t);
typedef int (__fastcall *RepeatClipFn)(uintptr_t,int32_t);
static RepeatStateFn srFastOriginal[2];static PVOID srFastTargets[2];
static uintptr_t srFastBase;static bool srFastAttempted;
static RepeatJumpAdvance srFastState;static volatile LONG srFastBusy;
static unsigned srFastEnds[2],srFastRejected;
static uintptr_t srFastObserve(unsigned kind,uintptr_t state,int32_t section,uintptr_t data){
 if(InterlockedCompareExchange(&srFastBusy,1,0))return srFastOriginal[kind](state,section,data);
 uintptr_t result=srFastOriginal[kind](state,section,data);
 if(section!=2||InterlockedCompareExchange(&srRepeatLock,1,0)){InterlockedExchange(&srFastBusy,0);return result;}
 uint64_t now=GetTickCount64();uintptr_t actor=0,object=0,owner=0;int32_t count=0,time=0;uint32_t mode=0;DWORD foreground=0;Sr1RetargetContext c;XINPUT_STATE raw={0};
 GetWindowThreadProcessId(GetForegroundWindow(),&foreground);
 bool scope=srRepeatRequested&&srRepeatWriter&&now>=srRepeatBegin&&now-srRepeatBegin<120000&&now>=srRepeatHeartbeat&&now-srRepeatHeartbeat<1500&&
  !InterlockedCompareExchange(&probeBoundedComplete,0,0)&&foreground==GetCurrentProcessId()&&
  srRepeatNativeIdentity(srFastBase,now,&actor,&object)&&worldRead(state,&owner,8)&&owner==actor&&worldRead(state+8,&count,4)&&count==3&&
  worldRead(srFastBase+0x2a89628,&time,4)&&time>0&&time<=8192&&worldRead(srFastBase+0x2a88c10,&mode,4)&&
  srPhysicalInput(&raw)&&!(raw.Gamepad.wButtons&~XINPUT_GAMEPAD_A)&&raw.Gamepad.bLeftTrigger<30&&raw.Gamepad.bRightTrigger<30&&
  sr1RetargetReadContext(NULL,srRepeatRead,srFastBase,actor,true,&c)&&!c.mode&&!c.crouchHeld&&!(c.flags&0x10000000u)&&c.verticalVelocityKnown&&!c.verticalVelocity;
 uint32_t callback=kind?0xedb40:0xee600;
 if(scope)for(unsigned i=0;i<3;i++)if(c.callbacks[i]!=callback)scope=false;
 bool pending=false,empty=scope;
 if(scope)for(unsigned i=0;i<SR_INPUT_CHANNELS;i++)if(srRepeatObjects[i]==object&&srRepeatPads[i].actor==actor&&srRepeatPads[i].pending&&now>=srRepeatPads[i].pressed&&now-srRepeatPads[i].pressed<=350)pending=true;
 // The native queue has sixteen entries. Add only to all three EMPTY queues
 // after their original handlers ran; never overwrite or fabricate queue state.
 if(scope)for(unsigned i=0;i<3;i++){int32_t q[2];if(!worldRead(state+0x18+i*0x228,q,sizeof(q))||q[0]<0||q[0]>15||q[1]!=q[0])empty=false;}
 int clip=scope?((RepeatClipFn)(srFastBase+0x10dc10))(state,0):-1;
 bool advance=repeatJumpAdvanceStep(&srFastState,now,actor,scope,kind,pending,mode,clip,empty);
 if(advance){
  RepeatQueueFn enqueue=(RepeatQueueFn)(srFastBase+0x10ccc0);
  for(unsigned i=0;i<3;i++)enqueue(state+0x18+i*0x228,0x08000000,0);
  ++srFastEnds[kind];
 }else if(pending)++srFastRejected;
 InterlockedExchange(&srRepeatLock,0);InterlockedExchange(&srFastBusy,0);return result;
}
static uintptr_t __fastcall srFastLanding(uintptr_t s,int32_t section,uintptr_t data){return srFastObserve(0,s,section,data);}
static uintptr_t __fastcall srFastCompression(uintptr_t s,int32_t section,uintptr_t data){return srFastObserve(1,s,section,data);}
static void srFastTick(void){
 if(!srFastAttempted&&srRepeatRequested){
  srFastAttempted=true;uintptr_t base=(uintptr_t)InterlockedCompareExchangePointer(&verifiedSr1Module,NULL,NULL);if(!base)return;
  const Sheet_repeatJumpAdvancePolicy *p=&sheet_repeatJumpAdvancePolicy_native_completion;
  if(p->landingRva!=0xee600||p->compressionRva!=0xedb40||p->queueRva!=0x10ccc0||p->clipRva!=0x10dc10||p->eventId!=0x08000000||p->maxAgeMs!=350||!p->emptyQueuesRequired||!p->normalClipsOnly||p->enabled||p->directPhysicsWrites)return;
  for(unsigned i=0;i<ARRAYSIZE(repeatJumpAdvanceProofs);i++){unsigned char code[4096];char sha[65];
   if(repeatJumpAdvanceProofs[i].size>sizeof(code)||!worldRead(base+repeatJumpAdvanceProofs[i].rva,code,repeatJumpAdvanceProofs[i].size)||!hashBytes(code,repeatJumpAdvanceProofs[i].size,sha)||strcmp(sha,repeatJumpAdvanceProofs[i].sha256)){logLine("SR1_REPEAT_ADVANCE code gate failed=%u",i);return;}}
  srFastBase=base;const uintptr_t rvas[]={0xee600,0xedb40};PVOID hooks[]={(PVOID)srFastLanding,(PVOID)srFastCompression};
  for(unsigned i=0;i<2;i++){PVOID target=(PVOID)(base+rvas[i]);MH_STATUS created=MH_CreateHook(target,hooks[i],(PVOID *)&srFastOriginal[i]);MH_STATUS enabled=created==MH_OK?MH_EnableHook(target):created;
   if(enabled==MH_OK)srFastTargets[i]=target;else{for(unsigned k=0;k<i;k++)MH_DisableHook(srFastTargets[k]);logLine("SR1_REPEAT_ADVANCE hook failed=%u status=%d",i,enabled);return;}}
 }
 if(!srRepeatRequested&&!InterlockedCompareExchange(&srRepeatLock,1,0)){memset(&srFastState,0,sizeof(srFastState));InterlockedExchange(&srRepeatLock,0);}
 if(srRepeatRequested)logLine("SR1_REPEAT_ADVANCE installed=%u landing=%u compression=%u rejected=%u",srFastTargets[0]&&srFastTargets[1],srFastEnds[0],srFastEnds[1],srFastRejected);
}
static void srFastStop(void){for(unsigned i=0;i<2;i++)if(srFastTargets[i])MH_DisableHook(srFastTargets[i]);}
#else
static void srFastTick(void){}
static void srFastStop(void){}
#endif
