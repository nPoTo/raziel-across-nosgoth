// Exact supported razApplyMotion, contiguous unwind fragments.
#define STARTUP_RVA 0xfc6d0
#define STARTUP_SIZE 464
#define STARTUP_SHA "f55e483c7192f5247d9a8363d2300d465233fab6f0b765a553f543726dab3740"
