// SPDX-License-Identifier: GPL-3.0-or-later
#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <stdbool.h>
#include <stdint.h>
#include <stdio.h>
#include <string.h>
#include <math.h>
#include "donor-combat-phase.h"
static unsigned char memory[0x1141000];static const uintptr_t base=0x10000000,actor=0x10001000,context=0x10003000,model=0x10005000,state=0x10007000,desc=0x10009000;
static int defect;static unsigned scalarReads,descriptorReads;
static bool rd(void *c,uintptr_t at,void *out,SIZE_T n){(void)c;if(defect==1||at<base||at-base>sizeof(memory)||n>sizeof(memory)-(at-base))return false;memcpy(out,memory+at-base,n);if(at==context+0xc4){scalarReads++;if(defect==2)*(int32_t *)out=(int32_t)scalarReads;}if(at==desc+0x3c){descriptorReads++;if(defect==3)*(uint16_t *)out=(uint16_t)descriptorReads;}return true;}
static bool code(void *c,uintptr_t at,uintptr_t b){(void)c;return b==base&&at>=base&&at<base+sizeof(memory);}
static void ptr(size_t off,uintptr_t v){memcpy(memory+off,&v,8);}static void u32(size_t off,uint32_t v){memcpy(memory+off,&v,4);}static void fl(size_t off,float v){memcpy(memory+off,&v,4);}
static CombatPhaseObservation get(void){scalarReads=descriptorReads=0;return combatPhaseObserve(NULL,rd,code,base,sizeof(memory),model);}
#define CHECK(x) do{if(!(x)){printf("FAIL line %d\n",__LINE__);return 1;}}while(0)
int main(void){
 ptr(0xc5aa78,actor);ptr(0xc67120,context);ptr(0x1088,model);ptr(0x13f8,state);ptr(0x3470,desc);u32(0x113fff4,10);u32(0x30c4,1024);fl(0x11f0,1);fl(0xc5abbc,1);
 for(unsigned i=0;i<3;i++){ptr(0x7000+i*0x250,actor);ptr(0x7010+i*0x250,base+0x1319c0);ptr(0x7018+i*0x250,base+0x131a30);}uint16_t v=1024;memcpy(memory+0x903c,&v,2);
 CombatPhaseObservation o=get();CHECK(o.valid&&o.attempts==1&&o.data.scalar==1024&&o.data.initial==1024&&o.data.physicsMode==10);
 for(defect=1;defect<=3;defect++){o=get();CHECK(!o.valid&&o.attempts==3);}defect=0;
 fl(0x1168,NAN);CHECK(!get().valid);fl(0x1168,0);
 ptr(0x1088,model+8);CHECK(!get().valid);ptr(0x1088,model);
 ptr(0x7000,actor+8);CHECK(!get().valid);ptr(0x7000,actor);
 // Non-air states must never dereference an arbitrary/stale descriptor.
 for(unsigned i=0;i<3;i++)ptr(0x7010+i*0x250,base+0x125340);
 ptr(0x3470,UINTPTR_MAX-1);CHECK(get().valid&&descriptorReads==0);
 CHECK(!combatPhaseObserve(NULL,rd,code,UINTPTR_MAX-1,sizeof(memory),model).valid);
 puts("PASS coherent scalar/descriptor double reads, bounded retry, identity/owner/NaN refusal, non-air descriptor isolation; no game writes");return 0;
}
