// SPDX-License-Identifier: GPL-3.0-or-later
#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <stdint.h>
#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "render-memory.h"
#include "live-packet.h"
#include "sr1-retarget-gate.h"
#include "guidance-plan.h"
#define CHECK(v,n) do{if(!(v)){printf("failed %d\n",n);return n;}}while(0)
int main(void){
 CHECK(guidanceSeconds(13)==100&&guidanceStageAt(13,0)->end==20&&!guidanceStageAt(13,100),18);for(unsigned i=0;i<100;i++){const TutorialStage *stage=guidanceStageAt(13,i);CHECK(stage&&i>=stage->begin&&i<stage->end&&stage->title[0]&&stage->detail[0],19);}
 uint32_t h[16]={SR1_PROFILE_POSE_MAGIC,SR1_PROFILE_VERTICES,3,1};uint64_t tick=1000;memcpy(h+4,&tick,8);h[6]=12;h[7]=1;memcpy(h+8,sr1ProfileHash,32);
 CHECK(liveHeaderValid(h,SR1_PROFILE_VERTICES,RM_LIVE_BYTES,1200,999),1);h[2]=2;CHECK(!liveHeaderValid(h,SR1_PROFILE_VERTICES,RM_LIVE_BYTES,1200,999),2);h[2]=3;h[8]^=1;CHECK(!liveHeaderValid(h,SR1_PROFILE_VERTICES,RM_LIVE_BYTES,1200,999),3);h[8]^=1;CHECK(!liveHeaderValid(h,SR1_PROFILE_VERTICES,RM_LIVE_BYTES,1600,999),4);
 Sr1RetargetContext s={.identity=true,.foreground=true,.verticalVelocityKnown=true,.callbacks={0xf2180,0xf3280,0xf4dc0}};CHECK(sr1RetargetContextAllowed(&s),5);
 s.verticalVelocity=1;CHECK(!sr1RetargetContextAllowed(&s),22);s.verticalVelocity=-1;CHECK(!sr1RetargetContextAllowed(&s),23);s.verticalVelocity=0;s.verticalVelocityKnown=false;CHECK(!sr1RetargetContextAllowed(&s),24);s.verticalVelocityKnown=true;CHECK(sr1RetargetContextAllowed(&s),25);
 for(unsigned i=0;i<3;i++){uint32_t old=s.callbacks[i];s.callbacks[i]=0xf5340;CHECK(!sr1RetargetContextAllowed(&s),6);s.callbacks[i]=old;}
 CHECK(sheet_retargetPreviewPolicy_bounded.flightNative&&sheet_retargetPreviewPolicy_bounded.glideNative,20);
 // Every callback outside the four measured ground states is native, including
 // unclassified air callbacks. A donor timeout/landing cannot whitelist it.
 for(unsigned section=0;section<3;section++){
  uint32_t saved=s.callbacks[section];
  for(uint32_t rva=0;rva<0x100000;rva++){bool listed=false;for(unsigned j=0;j<sheet_retargetGroundStates_count;j++)if(sheet_retargetGroundStates_rows[j]->rva==rva)listed=true;s.callbacks[section]=rva;CHECK(sr1RetargetContextAllowed(&s)==listed,21);}
  s.callbacks[section]=saved;
 }
 s.mode=6;CHECK(!sr1RetargetContextAllowed(&s),7);s.mode=0;s.flags=0x10000000;CHECK(!sr1RetargetContextAllowed(&s),8);s.flags=0;s.foreground=false;CHECK(!sr1RetargetContextAllowed(&s),9);s.foreground=true;s.callbacks[1]=0xeeb40;CHECK(!sr1RetargetContextAllowed(&s),10);s.callbacks[1]=0xf0240;CHECK(!sr1RetargetContextAllowed(&s),11);
 DWORD pid=GetCurrentProcessId();wchar_t name[96],lockName[96];renderMemoryNames(pid,name,lockName);CHECK(wcsstr(name,L"Sr1Retarget")!=NULL,12);
 HANDLE mapping=CreateFileMappingW(INVALID_HANDLE_VALUE,NULL,PAGE_READWRITE,0,sizeof(RenderMemory),name);CHECK(mapping&&GetLastError()!=ERROR_ALREADY_EXISTS,13);
 RenderMemory *writer=MapViewOfFile(mapping,FILE_MAP_WRITE,0,0,sizeof(RenderMemory));const RenderMemory *reader=MapViewOfFile(mapping,FILE_MAP_READ,0,0,sizeof(RenderMemory));CHECK(writer&&reader,14);
 memset(writer,0,sizeof(*writer));writer->magic=RM_MAGIC;writer->version=3;writer->hostPid=pid;writer->writerPid=pid;writer->online=1;writer->geometryBytes=RM_GEOMETRY_BYTES;writer->appearanceBytes=RM_APPEARANCE_BYTES;writer->liveBytes=RM_LIVE_BYTES;writer->live[64]=71;CHECK(renderMemoryHeader(reader,pid)&&reader->live[64]==71,15);writer->version=2;CHECK(!renderMemoryHeader(reader,pid),16);writer->version=3;writer->online=0;CHECK(!renderMemoryHeader(reader,pid),17);
 UnmapViewOfFile(reader);UnmapViewOfFile(writer);CloseHandle(mapping);puts("SR1 profile: distinct real RAM views, original hash/counts, expiry and immediate native crouch/block/menu/focus fallback PASS; no game activation");return 0;
}
