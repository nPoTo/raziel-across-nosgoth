// SPDX-License-Identifier: GPL-3.0-or-later
#define main originalHostRigFixture
#include "host-rig-reader-test.c"
#undef main
#include "host-rig-continuity.h"
static unsigned mutation;
static bool changingRead(void *c,uintptr_t at,void *out,SIZE_T n){
 if(at==0x100000+0x2a89310&&globalReads==1){
  if(mutation==1)i32(8,0,0x3f800000); // finite render matrix changes, same identity
  if(mutation==2)i32(7,0,123); // legacy matrix changes too
  if(mutation==3)i16(6,32+18,-1); // valid different topology, never bridge
 }
 return readFixture(c,at,out,n);
}
int main(void){
 HostRig r={0},raceRig={0},out={0};bool matrixRace=false,held=false;uint64_t tick=0;setup();
 CHECK(hostRigRead(NULL,readFixture,0x100000,&r),101);
 for(mutation=1;mutation<=2;mutation++){setup();CHECK(!hostRigReadClassified(NULL,changingRead,0x100000,&out,&raceRig,&matrixRace)&&rigReadFailure==14&&matrixRace&&rigSameIdentity(&raceRig,&r),102);}
 mutation=3;setup();CHECK(!hostRigReadClassified(NULL,changingRead,0x100000,&out,&raceRig,&matrixRace)&&rigReadFailure==14&&!matrixRace,103);
 HostRigContinuity cache={0};Sr1RetargetContext c={.identity=true,.foreground=true,.verticalVelocityKnown=true,.callbacks={0xf2180,0xf2180,0xf2180},.flags=64};
#define SELECT(coherent,race,reason,current,now) hostRigContinuitySelect(&cache,&r,coherent,race,reason,current,&c,now,&out,&tick,&held)
 CHECK(!SELECT(false,true,14,true,100)&&!cache.ready,104); // no initial coherent rig
 CHECK(SELECT(true,false,0,true,100)&&!held&&tick==100,105);
 CHECK(SELECT(false,true,14,true,116)&&held&&tick==100&&!memcmp(&out,&r,sizeof(r)),106);
 CHECK(SELECT(false,true,14,true,183)&&held&&tick==100,107);
 CHECK(SELECT(false,true,14,true,250)&&held&&tick==100,108);
 CHECK(!SELECT(false,true,14,true,251)&&!cache.ready,109);
 CHECK(SELECT(true,false,0,true,300),110);CHECK(!SELECT(false,true,14,false,316)&&!cache.ready,111);
 CHECK(SELECT(true,false,0,true,400),112);c.foreground=false;CHECK(!SELECT(false,true,14,true,416)&&!cache.ready,113);c.foreground=true;
 CHECK(SELECT(true,false,0,true,500),114);c.callbacks[0]=c.callbacks[1]=c.callbacks[2]=0xefb50;CHECK(!SELECT(false,true,14,true,516)&&!cache.ready,115);
 // A coherent native observation remains observable but cannot seed a cache.
 CHECK(SELECT(true,false,0,true,533)&&!cache.ready&&!held&&tick==533,116);
 c.callbacks[0]=c.callbacks[1]=c.callbacks[2]=0xf2180;CHECK(!SELECT(false,true,14,true,550),117);CHECK(SELECT(true,false,0,true,566),118);
 c.callbacks[0]=c.callbacks[1]=c.callbacks[2]=0xf3280;CHECK(!SELECT(false,true,14,true,583),119);c.callbacks[0]=c.callbacks[1]=c.callbacks[2]=0xf2180;
 for(unsigned reason=1;reason<=15;reason++)if(reason!=14){CHECK(SELECT(true,false,0,true,600),120);CHECK(!SELECT(false,false,reason,true,616)&&!cache.ready,121);}
 // Every metadata pointer and parent belongs to the receipt identity.
 HostRig original=r;const size_t offsets[]={offsetof(HostRig,actor),offsetof(HostRig,object),offsetof(HostRig,name),offsetof(HostRig,list),offsetof(HostRig,model),offsetof(HostRig,segments),offsetof(HostRig,legacy),offsetof(HostRig,render)};
 for(unsigned i=0;i<sizeof(offsets)/sizeof(offsets[0]);i++){r=original;CHECK(SELECT(true,false,0,true,700),122);uintptr_t pointer;memcpy(&pointer,(unsigned char *)&r+offsets[i],sizeof(pointer));pointer+=8;memcpy((unsigned char *)&r+offsets[i],&pointer,sizeof(pointer));CHECK(!SELECT(false,true,14,true,716),123);}
 r=original;CHECK(SELECT(true,false,0,true,800),124);r.parents[1]=-1;CHECK(!SELECT(false,true,14,true,816),125);
 r=original;CHECK(SELECT(true,false,0,true,900),126);r.modelIndex=1;CHECK(!SELECT(false,true,14,true,916),127);
 r=original;CHECK(SELECT(true,false,0,true,1000),128);r.count=1;CHECK(!SELECT(false,true,14,true,1016),129);
 r=original;CHECK(SELECT(true,false,0,true,1100),130);CHECK(!SELECT(false,true,14,true,1099),131);
 // Short matrix race pulses do not create mode0 in an unchanged live context.
 unsigned pulses=0;uint64_t now=2000;for(unsigned i=0;i<1306;i++){CHECK(SELECT(true,false,0,true,now),132);for(unsigned gap=1;gap<=5;gap++){CHECK(SELECT(false,true,14,true,now+gap*17)&&held&&tick==now,133);pulses++;}now+=102;}
 printf("PASS: actual dual-read matrix-only classification; %u bounded held pulses preserve original receipts; identity/topology/native/context/error/expiry reject. Synthetic regression, not gameplay.\n",pulses);return 0;
}
