// SPDX-License-Identifier: GPL-3.0-or-later
#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <stdint.h>
#include <stdbool.h>
#include <string.h>
#include <stdio.h>
#include "donor-state-sections.h"
static const uintptr_t base=0x10000000,actor=0x20000000,state=0x30000000,currentAddress=0x40000000;
static unsigned char data[3][32];static unsigned prefixReads[3],actorReads,stateReads;static int defect;
static bool fixtureRead(void *unused,uintptr_t address,void *out,SIZE_T size){
 (void)unused;if(defect==1)return false;
 if(address==currentAddress&&size==8){uintptr_t v=actor;actorReads++;if(defect==2&&actorReads>1)v+=8;memcpy(out,&v,8);return true;}
 if(address==actor+0x3f8&&size==8){uintptr_t v=state;stateReads++;if(defect==3&&stateReads>1)v+=8;memcpy(out,&v,8);return true;}
 for(unsigned i=0;i<3;i++)if(address==state+i*0x250&&size==32){prefixReads[i]++;memcpy(out,data[i],32);if(defect==(int)(4+i)&&prefixReads[i]>1)((unsigned char *)out)[0]^=1;return true;}return false;
}
static bool fixtureCode(void *unused,uintptr_t address,uintptr_t module){(void)unused;return module==base&&address>=base&&address<base+0x100000&&defect!=7;}
static DonorStateSections get(void){memset(prefixReads,0,sizeof(prefixReads));actorReads=stateReads=0;return donorStateSectionsRead(NULL,fixtureRead,fixtureCode,base,0x100000,actor,currentAddress);}
#define CHECK(c,n) do{if(!(c)){printf("FAIL %u\n",(unsigned)(n));return n;}}while(0)
int main(void){
 memcpy(data[0],&actor,8);for(unsigned i=0;i<3;i++){uintptr_t a=base+0x100+i*0x10,b=base+0x200+i*0x10;memcpy(data[i]+16,&a,8);memcpy(data[i]+24,&b,8);}
 DonorStateSections r=get();CHECK(r.valid&&r.ownerMatches,1);for(unsigned i=0;i<3;i++)CHECK(r.sections[i].firstRva==0x100+i*0x10&&r.sections[i].secondValid&&r.sections[i].secondRva==0x200+i*0x10,2+i);
 for(defect=1;defect<=7;defect++)CHECK(!get().valid,10+defect);defect=0;
 uintptr_t value=actor+8;memcpy(data[0],&value,8);r=get();CHECK(r.valid&&!r.ownerMatches,20);memcpy(data[0],&actor,8);
 value=0;memcpy(data[1]+24,&value,8);r=get();CHECK(r.valid&&r.ownerMatches&&!r.sections[1].secondValid&&r.sections[1].secondRva==0,21);
 value=base+0x100000;memcpy(data[2]+16,&value,8);CHECK(!get().valid,22);
 CHECK(!donorStateSectionsRead(NULL,fixtureRead,fixtureCode,UINTPTR_MAX-10,0x100000,actor,currentAddress).valid,23);
 CHECK(!donorStateSectionsRead(NULL,fixtureRead,fixtureCode,base,0x100000,actor+1,currentAddress).valid,24);
 puts("PASS: production three-section reader, actor-owner comparison, executable code bounds, per-section/current-actor/state races, optional secondary identity and no native pointer output");return 0;
}
