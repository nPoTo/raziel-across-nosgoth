// SPDX-License-Identifier: GPL-3.0-or-later
// Read-only candidate globals preceding supported animation dispatch.
// No semantic menu classification, game writes, injection or resource output.
#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <tlhelp32.h>
#include <bcrypt.h>
#include <stdint.h>
#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <wchar.h>
static bool sha(const wchar_t *file,char out[65]){
 HANDLE f=CreateFileW(file,GENERIC_READ,FILE_SHARE_READ|FILE_SHARE_WRITE|FILE_SHARE_DELETE,NULL,OPEN_EXISTING,0,NULL);
 if(f==INVALID_HANDLE_VALUE)return false;
 BCRYPT_ALG_HANDLE a=NULL;BCRYPT_HASH_HANDLE h=NULL;unsigned char buf[65536],digest[32];DWORD n;bool ok=false;
 if(BCryptOpenAlgorithmProvider(&a,BCRYPT_SHA256_ALGORITHM,NULL,0)<0||BCryptCreateHash(a,&h,NULL,0,NULL,0,0)<0)goto done;
 for(;;){if(!ReadFile(f,buf,sizeof(buf),&n,NULL))goto done;if(!n)break;if(BCryptHashData(h,buf,n,0)<0)goto done;}
 if(BCryptFinishHash(h,digest,32,0)<0)goto done;
 for(unsigned i=0;i<32;i++)sprintf(out+i*2,"%02x",digest[i]);out[64]=0;ok=true;
done:if(h)BCryptDestroyHash(h);if(a)BCryptCloseAlgorithmProvider(a,0);CloseHandle(f);return ok;
}
static bool readAt(HANDLE p,uintptr_t at,void *out,SIZE_T size){SIZE_T n=0;return at&&ReadProcessMemory(p,(void*)at,out,size,&n)&&n==size;}
int wmain(int argc,wchar_t **argv){
 if(argc!=2)return 1;
 wchar_t *end=NULL;unsigned long value=wcstoul(argv[1],&end,10);if(!value||*end)return 1;
 HANDLE p=OpenProcess(PROCESS_QUERY_LIMITED_INFORMATION|PROCESS_VM_READ,FALSE,(DWORD)value);if(!p)return 2;
 wchar_t file[32768];DWORD len=32768;char hash[65];FILETIME created,exited,kernel,user;
 if(!QueryFullProcessImageNameW(p,0,file,&len)||!sha(file,hash)||strcmp(hash,"fc6a406ff7ac9b5eb7788dc7a65d335e1c1aad9236618112671975b71d2daddc")||!GetProcessTimes(p,&created,&exited,&kernel,&user)){CloseHandle(p);return 3;}
 HANDLE snap=CreateToolhelp32Snapshot(TH32CS_SNAPMODULE|TH32CS_SNAPMODULE32,(DWORD)value);uintptr_t base=0;unsigned matches=0;
 if(snap!=INVALID_HANDLE_VALUE){MODULEENTRY32W m={0};m.dwSize=sizeof(m);if(Module32FirstW(snap,&m))do{if(!_wcsicmp(m.szExePath,file)){base=(uintptr_t)m.modBaseAddr;matches++;}}while(Module32NextW(snap,&m));CloseHandle(snap);}
 if(matches!=1){CloseHandle(p);return 4;}
 uint64_t creation=((uint64_t)created.dwHighDateTime<<32)|created.dwLowDateTime;
 printf("{\"type\":\"session\",\"pid\":%lu,\"creation\":\"%llu\",\"sha256\":\"%s\",\"mode\":\"read-only-candidate\"}\n",value,(unsigned long long)creation,hash);
 unsigned valid=0,generation=0;uintptr_t previousActor=0;
 for(unsigned i=0;i<30;i++){
  uintptr_t actor=0,again=0,object=0,objectAgain=0;uint32_t flags=0,check=0,actorFlags=0,objectFlags=0,objectCheck=0,actorCheck=0;unsigned char mode=0,modeCheck=0;
  bool ok=readAt(p,base+0xc5aa78,&actor,8)&&actor&&readAt(p,actor+0x88,&object,8)&&object&&readAt(p,object,&objectFlags,4)&&readAt(p,base+0xc5ab38,&flags,4)&&readAt(p,base+0xc5ab60,&mode,1)&&readAt(p,actor+0xac,&actorFlags,4)&&readAt(p,base+0xc5ab38,&check,4)&&check==flags&&readAt(p,base+0xc5ab60,&modeCheck,1)&&mode==modeCheck&&readAt(p,actor+0xac,&actorCheck,4)&&actorCheck==actorFlags&&readAt(p,object,&objectCheck,4)&&objectCheck==objectFlags&&readAt(p,actor+0x88,&objectAgain,8)&&objectAgain==object&&readAt(p,base+0xc5aa78,&again,8)&&again==actor;
  if(ok){valid++;if(actor!=previousActor){generation++;previousActor=actor;}}else previousActor=0;
  printf("{\"type\":\"sample\",\"sequence\":%u,\"tickMs\":%llu,\"valid\":%s,\"actorGeneration\":%u,\"globalFlagsRaw\":%u,\"modeRaw\":%u,\"actorFlagsRaw\":%u,\"objectFlagsRaw\":%u}\n",i,(unsigned long long)GetTickCount64(),ok?"true":"false",ok?generation:0,ok?flags:0,ok?mode:0,ok?actorFlags:0,ok?objectFlags:0);fflush(stdout);if(i<29)Sleep(50);
 }
 CloseHandle(p);return valid?0:5;
}
