#include "report-path.h"
// Native paired camera pose, after interpolation and before view/frustum construction.
#include "host-camera-proof.h"
#include "source-camera-shared.h"
typedef uintptr_t (__fastcall *HostCameraInterpFn)(uintptr_t,int32_t);
static HostCameraInterpFn originalHostCameraInterp;static PVOID hostCameraTarget;
static uintptr_t hostCameraModule;static bool hostCameraAttempted,hostCameraFailed;
static HANDLE hostCameraMapping;static const SourceCameraShared *hostCameraView;static uint32_t hostCameraPid;
static unsigned hostCameraFrames;static volatile LONG hostCameraBusy;
typedef struct {float hdPosition[3],hdRotation[3];int16_t position[3],rotation[3];} HostCameraPose;
static HostCameraPose hostCameraBefore,hostCameraLast;static bool hostCameraOwned;
static SourceCameraBlend hostCameraBlend;
static float hostCameraRootUsed[3];static uint64_t hostCameraRootTick,hostCameraSourceTick;
static uintptr_t hostCameraRootOwner;static unsigned hostCameraAuditCalls,hostCameraAuditSamples;
static bool hostCameraDisplayRoot(float model[16],uintptr_t instance,uint64_t now){
 if(!hostCameraOwned||instance!=hostCameraRootOwner||now<hostCameraRootTick||now-hostCameraRootTick>100||
    GetFileAttributesW(PROBE_PATH(L"\\camera-host-sr1.enable"))==INVALID_FILE_ATTRIBUTES||
    !directHostInputScope(now,srInputMainBase+0x5bc9,GetCurrentProcessId()))return false;
 // Display only: use the actor root against which this frame's native camera
 // was built. Never change host simulation position or collision controllers.
 memcpy(model+12,hostCameraRootUsed,12);return true;
}
static unsigned hostCameraDisplayFrames;
static void hostCameraModelFrame(float model[16],uintptr_t instance){
 uint64_t now=GetTickCount64();
 if(hostCameraDisplayRoot(model,instance,now)){
  ++hostCameraDisplayFrames;
  if(hostCameraDisplayFrames<=4||hostCameraDisplayFrames%120==0)logLine("SR1_CAMERA_DISPLAY_ROOT tick=%llu frames=%u hook_tick=%llu root=%.9g,%.9g,%.9g; display only, simulation unchanged",now,hostCameraDisplayFrames,hostCameraRootTick,model[12],model[13],model[14]);
 }
}
static void hostCameraAuditFrame(const float model[16],const float inverse[16],uintptr_t instance){
 uint64_t now=GetTickCount64();
 if(!hostCameraOwned||instance!=hostCameraRootOwner||now<hostCameraRootTick||now-hostCameraRootTick>100||
    GetFileAttributesW(PROBE_PATH(L"\\camera-host-sr1.enable"))==INVALID_FILE_ATTRIBUTES||hostCameraAuditSamples>=2400)return;
 if(++hostCameraAuditCalls%4)return;++hostCameraAuditSamples;
 // Read-only trace on the drawing thread: compare camera-hook root to actual
 // drawn root, and paired camera fields to the shader's current inverse view.
 logLine("SR1_CAMERA_FRAME_AUDIT tick=%llu frame=%u source=%llu pose=%llu hook_tick=%llu hook_root=%.9g,%.9g,%.9g draw_root=%.9g,%.9g,%.9g applied=%.9g,%.9g,%.9g shader=%.9g,%.9g,%.9g",
 now,hostCameraFrames,hostCameraSourceTick,overlayLiveTick,hostCameraRootTick,
 hostCameraRootUsed[0],hostCameraRootUsed[1],hostCameraRootUsed[2],model[12],model[13],model[14],
 hostCameraLast.hdPosition[0],hostCameraLast.hdPosition[1],hostCameraLast.hdPosition[2],inverse[12],inverse[13],inverse[14]);
 unsigned char legacy[256];
 if(worldRead(hostCameraModule+HOST_CAMERA_LEGACY_RVA,legacy,sizeof(legacy))){
  int16_t p[3];memcpy(p,legacy,6);const unsigned normals[5]={8,0x0e,0x14,0x28,0x2e},constants[5]={0x48,0x4c,0x50,0x54,0x58};
  unsigned active=0;int32_t maximum=0;
  for(unsigned i=0;i<5;i++){
   int16_t n[3];int32_t constant;memcpy(n,legacy+normals[i],6);memcpy(&constant,legacy+constants[i],4);
   if(!n[0]&&!n[1]&&!n[2])continue;++active;
   int64_t sum=0;for(unsigned k=0;k<3;k++)sum+=(int64_t)n[k]*p[k];
   int32_t expected=((int32_t)(uint32_t)sum)>>12;int64_t error=(int64_t)expected-constant;if(error<0)error=-error;
   if(error>INT32_MAX)error=INT32_MAX;if(error>maximum)maximum=(int32_t)error;
  }
  logLine("SR1_CAMERA_VISIBILITY_AUDIT tick=%llu frame=%u planes=%u integer_dot_error=%d legacy_position=%d,%d,%d applied_legacy=%d,%d,%d; read-only draw-thread decoded 1bb60/12faf0",now,hostCameraFrames,active,maximum,p[0],p[1],p[2],hostCameraLast.position[0],hostCameraLast.position[1],hostCameraLast.position[2]);
 }
}
static bool hostCameraReadPose(HostCameraPose *s){return worldRead(hostCameraModule+HOST_CAMERA_HD_RVA,s->hdPosition,12)&&worldRead(hostCameraModule+HOST_CAMERA_HD_RVA+0x118,s->hdRotation,12)&&worldRead(hostCameraModule+HOST_CAMERA_LEGACY_RVA,s->position,6)&&worldRead(hostCameraModule+HOST_CAMERA_LEGACY_RVA+0xc0,s->rotation,6);}
typedef uintptr_t (__fastcall *HostCameraRegionFn)(void);
static HostCameraRegionFn originalHostCameraRegion;
static PVOID hostCameraRegionTarget;
static unsigned hostCameraRegionCalls[2],hostCameraRegionSamples;
static uintptr_t hostCameraRegionObserve(uintptr_t caller){
 // Preserve the native choice. In particular, never force a region or bypass
 // portal/collision checks in this diagnostic.
 uintptr_t result=originalHostCameraRegion();
 unsigned lane=caller==hostCameraModule+0x6cf59?0:1;
 uint64_t now=GetTickCount64();
 if((lane==1&&caller!=hostCameraModule+0x6f02b)||!hostCameraOwned||
    now<hostCameraRootTick||now-hostCameraRootTick>100||hostCameraRegionSamples>=4800||
    GetFileAttributesW(PROBE_PATH(L"\\camera-host-sr1.enable"))==INVALID_FILE_ATTRIBUTES)return result;
 if(++hostCameraRegionCalls[lane]%4)return result;
 HostCameraPose current;uint16_t id=0;uintptr_t level=0;
 if(!hostCameraReadPose(&current)||!worldRead(result,&id,2)||!worldRead(result+8,&level,8))return result;
 ++hostCameraRegionSamples;
 logLine("SR1_CAMERA_REGION_AUDIT tick=%llu frame=%u caller=%llx region=%p id=%u level=%p camera=%d,%d,%d applied=%d,%d,%d hook_tick=%llu; read-only native result preserved",
 now,hostCameraFrames,(unsigned long long)(caller-hostCameraModule),(void *)result,id,(void *)level,
 current.position[0],current.position[1],current.position[2],hostCameraLast.position[0],hostCameraLast.position[1],hostCameraLast.position[2],hostCameraRootTick);
 return result;
}
static uintptr_t __fastcall hostCameraRegion(void){return hostCameraRegionObserve((uintptr_t)__builtin_return_address(0));}
static void hostCameraRegionInstall(void){
 unsigned char bytes[HOST_CAMERA_REGION_SIZE];char sha[65];
 if(!worldRead(hostCameraModule+HOST_CAMERA_REGION_RVA,bytes,sizeof(bytes))||!hashBytes(bytes,sizeof(bytes),sha)||strcmp(sha,HOST_CAMERA_REGION_SHA))return;
 PVOID target=(void *)(hostCameraModule+HOST_CAMERA_REGION_RVA);
 MH_STATUS create=MH_CreateHook(target,(void *)&hostCameraRegion,(void **)&originalHostCameraRegion),enable=create==MH_OK?MH_EnableHook(target):create;
 if(enable==MH_OK)hostCameraRegionTarget=target;
 logLine("SR1_CAMERA_REGION_AUDIT create=%d enable=%d full-code proof=1; read-only, bounded, default off",create,enable);
}
static bool hostCameraWriteAt(uintptr_t at,const void *p,size_t n){SIZE_T written=0;return WriteProcessMemory(GetCurrentProcess(),(void *)at,p,n,&written)&&written==n;}
static bool hostCameraWritePose(const HostCameraPose *s){return hostCameraWriteAt(hostCameraModule+HOST_CAMERA_HD_RVA,s->hdPosition,12)&&hostCameraWriteAt(hostCameraModule+HOST_CAMERA_HD_RVA+0x118,s->hdRotation,12)&&hostCameraWriteAt(hostCameraModule+HOST_CAMERA_LEGACY_RVA,s->position,6)&&hostCameraWriteAt(hostCameraModule+HOST_CAMERA_LEGACY_RVA+0xc0,s->rotation,6);}
static bool hostCameraRestore(void){
 if(!hostCameraOwned)return true;HostCameraPose current;bool ok=hostCameraReadPose(&current);
 if(ok){
  // Native control may already have updated a field. Restore only our values.
  if(!memcmp(current.hdPosition,hostCameraLast.hdPosition,12))ok=hostCameraWriteAt(hostCameraModule+HOST_CAMERA_HD_RVA,hostCameraBefore.hdPosition,12)&&ok;
  if(!memcmp(current.hdRotation,hostCameraLast.hdRotation,12))ok=hostCameraWriteAt(hostCameraModule+HOST_CAMERA_HD_RVA+0x118,hostCameraBefore.hdRotation,12)&&ok;
  if(!memcmp(current.position,hostCameraLast.position,6))ok=hostCameraWriteAt(hostCameraModule+HOST_CAMERA_LEGACY_RVA,hostCameraBefore.position,6)&&ok;
  if(!memcmp(current.rotation,hostCameraLast.rotation,6))ok=hostCameraWriteAt(hostCameraModule+HOST_CAMERA_LEGACY_RVA+0xc0,hostCameraBefore.rotation,6)&&ok;
 }
 if(ok)hostCameraOwned=false;return ok;
}
static bool hostCameraSource(SourceCameraSnapshot *s){
 uint32_t pid=overlayLivePid;
 if(pid!=hostCameraPid){if(hostCameraView)UnmapViewOfFile(hostCameraView);if(hostCameraMapping)CloseHandle(hostCameraMapping);hostCameraView=NULL;hostCameraMapping=NULL;hostCameraPid=pid;}
 if(pid&&!hostCameraView){wchar_t name[96];sourceCameraName(name,pid);hostCameraMapping=OpenFileMappingW(FILE_MAP_READ,FALSE,name);if(hostCameraMapping)hostCameraView=MapViewOfFile(hostCameraMapping,FILE_MAP_READ,0,0,sizeof(SourceCameraShared));if(hostCameraMapping&&!hostCameraView){CloseHandle(hostCameraMapping);hostCameraMapping=NULL;}}
 return sourceCameraCopy(hostCameraView,s)&&sourceCameraValid(s,pid,GetTickCount64());
}
static bool (*hostCameraRead)(SourceCameraSnapshot *)=hostCameraSource;
static void hostCameraApply(void){
 uint64_t now=GetTickCount64();SourceCameraSnapshot source;float root[16];uintptr_t player=0;DWORD foreground=0;
 GetWindowThreadProcessId(GetForegroundWindow(),&foreground);
 bool scope=!hostCameraFailed&&GetFileAttributesW(PROBE_PATH(L"\\camera-host-sr1.enable"))!=INVALID_FILE_ATTRIBUTES&&directHostInputScope(now,srInputMainBase+0x5bc9,foreground)&&worldRenderRoot(root,&player)&&player==directHostPlayer&&hostCameraRead(&source)&&source.instance==directHostAlignmentInstance;
 HostCameraPose next={0};
 if(!scope)hostCameraBlend.ready=false;
 if(scope&&sourceCameraBlendPose(&hostCameraBlend,&source,overlayLivePid,now,root,directHostCos,directHostSin,next.hdPosition,next.hdRotation)&&sourceCameraFrameActor(root,next.hdPosition,next.hdRotation)&&hostCameraReadPose(&hostCameraBefore)){
  for(unsigned k=0;k<3;k++){next.position[k]=(int16_t)next.hdPosition[k];next.rotation[k]=(int16_t)next.hdRotation[k];}
  hostCameraLast=next;hostCameraOwned=true;
  HostCameraPose check;bool ok=hostCameraWritePose(&next)&&hostCameraReadPose(&check)&&!memcmp(&next,&check,sizeof(next));
  if(!ok){hostCameraFailed=true;hostCameraRestore();}else {++hostCameraFrames;memcpy(hostCameraRootUsed,root+12,12);hostCameraRootTick=now;hostCameraSourceTick=source.tick;hostCameraRootOwner=player;}
  if(hostCameraFrames<=4||hostCameraFrames%120==0||!ok)logLine("SR1_CAMERA_AUTHORITY frames=%u source=%llu position=%.9g,%.9g,%.9g angles=%.9g,0,%.9g ok=%u; native paired camera before view/frustum",hostCameraFrames,source.tick,next.hdPosition[0],next.hdPosition[1],next.hdPosition[2],next.hdRotation[0],next.hdRotation[2],ok);
 }
}
static uintptr_t hostCameraObserve(uintptr_t camera,int32_t factor,uintptr_t caller){
 if(camera!=hostCameraModule+HOST_CAMERA_HD_RVA||caller!=hostCameraModule+HOST_CAMERA_INTERP_CALLER||InterlockedCompareExchange(&hostCameraBusy,1,0))return originalHostCameraInterp(camera,factor);
 if(!hostCameraRestore())hostCameraFailed=true;
 uintptr_t result=originalHostCameraInterp(camera,factor);
 hostCameraApply();
 InterlockedExchange(&hostCameraBusy,0);return result;
}
static uintptr_t __fastcall hostCameraInterpolate(uintptr_t camera,int32_t factor){return hostCameraObserve(camera,factor,(uintptr_t)__builtin_return_address(0));}
typedef uintptr_t (__fastcall *HostCameraBuildFn)(uintptr_t);
static HostCameraBuildFn originalHostCameraBuild;static PVOID hostCameraBuildTarget;
static uintptr_t hostCameraBuildObserve(uintptr_t camera,uintptr_t caller){
 bool known=caller==hostCameraModule+0x6f559||caller==hostCameraModule+0x6f6c4;
 if(camera!=hostCameraModule+HOST_CAMERA_LEGACY_RVA||!known||InterlockedCompareExchange(&hostCameraBusy,1,0))return originalHostCameraBuild(camera);
 if(!hostCameraRestore())hostCameraFailed=true;
 hostCameraApply();
 uintptr_t result=originalHostCameraBuild(camera);
 InterlockedExchange(&hostCameraBusy,0);return result;
}
static uintptr_t __fastcall hostCameraBuild(uintptr_t camera){return hostCameraBuildObserve(camera,(uintptr_t)__builtin_return_address(0));}
static void hostCameraInstall(HMODULE module){
 if(!module||hostCameraAttempted)return;hostCameraAttempted=true;unsigned char bytes[HOST_CAMERA_INTERP_SIZE],actual[32];char sha[65];uintptr_t base=(uintptr_t)module;
 if(!worldRead(base+HOST_CAMERA_INTERP_RVA,bytes,sizeof(bytes))||!hashBytes(bytes,sizeof(bytes),sha)||strcmp(sha,HOST_CAMERA_INTERP_SHA))return;
 for(unsigned k=0;k<ARRAYSIZE(hostCameraChecks);k++)if(!worldRead(base+hostCameraChecks[k].rva,actual,hostCameraChecks[k].length)||memcmp(actual,hostCameraChecks[k].bytes,hostCameraChecks[k].length))return;
 MH_STATUS init=MH_Initialize();if(init!=MH_OK&&init!=MH_ERROR_ALREADY_INITIALIZED)return;
 PVOID target=(void *)(base+HOST_CAMERA_INTERP_RVA);hostCameraModule=base;
 MH_STATUS create=MH_CreateHook(target,(void *)&hostCameraInterpolate,(void **)&originalHostCameraInterp),enable=create==MH_OK?MH_EnableHook(target):create;
 if(enable==MH_OK){
 unsigned char buildBytes[HOST_CAMERA_BUILD_SIZE];
 if(worldRead(base+HOST_CAMERA_BUILD_RVA,buildBytes,sizeof(buildBytes))&&hashBytes(buildBytes,sizeof(buildBytes),sha)&&!strcmp(sha,HOST_CAMERA_BUILD_SHA)){
  PVOID buildTarget=(void *)(base+HOST_CAMERA_BUILD_RVA);
  MH_STATUS bc=MH_CreateHook(buildTarget,(void *)&hostCameraBuild,(void **)&originalHostCameraBuild);
  if(bc==MH_OK&&MH_EnableHook(buildTarget)==MH_OK)hostCameraBuildTarget=buildTarget;
 }
 if(!hostCameraBuildTarget)hostCameraFailed=true;
 hostCameraTarget=target;worldFrameAudit=hostCameraAuditFrame;worldCameraModel=hostCameraModelFrame;hostCameraRegionInstall();}logLine("SR1_CAMERA_AUTHORITY create=%d enable=%d full-code proof=1; default off",create,enable);
}
static void hostCameraStop(void){
 if(hostCameraRegionTarget)MH_DisableHook(hostCameraRegionTarget);
 // In-flight restoration stays on the native render thread, not the worker.
 if(!hostCameraOwned&&hostCameraTarget)MH_DisableHook(hostCameraTarget);
 if(!hostCameraOwned&&hostCameraBuildTarget)MH_DisableHook(hostCameraBuildTarget);
}
