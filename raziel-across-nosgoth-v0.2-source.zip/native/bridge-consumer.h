// SPDX-License-Identifier: GPL-3.0-or-later
// Worker-owned validation adapter. Native callback publication is a separate step.
#ifndef BRIDGE_CONSUMER_H
#define BRIDGE_CONSUMER_H
#include <math.h>
#include "bridge-memory.h"
#include "live-packet.h"
#include "movement-packet.h"
typedef struct {
 BridgeIdentity identity;
 uint64_t sequence,tick;
 bool poseReady,movementReady;
 uint32_t sourceSequence;
 unsigned char pose[RM_LIVE_BYTES],movement[RM_MOVEMENT_BYTES],sourceMovement[RM_MOVEMENT_BYTES];
} BridgeConsumer;
static inline void bridgeConsumerBegin(BridgeConsumer *c,const BridgeIdentity *identity){memset(c,0,sizeof(*c));c->identity=*identity;}
static inline void bridgeConsumerInvalidate(BridgeConsumer *c){c->poseReady=false;c->movementReady=false;memset(c->movement,0,sizeof(c->movement));}
static inline void bridgeConsumerExpire(BridgeConsumer *c,uint64_t now){
 if(!livePoseFresh(c->tick,now)){bridgeConsumerInvalidate(c);return;}
 if(now-c->tick>150){c->movementReady=false;memset(c->movement,0,RM_MOVEMENT_BYTES);}
}
// Called with a stable paired snapshot on a single owning worker, not from two
// callbacks concurrently. No incoming pointer becomes retained runtime identity.
static inline bool bridgeConsumerAccept(BridgeConsumer *c,const BridgeHeader *p,const unsigned char *pose,const BridgeHeader *m,const unsigned char *movement,uint64_t now){
 // Identical snapshots are not new events. Keep validated visual data until
 // freshness expires, rather than toggling body cover at render frequency.
 if(p&&m&&pose&&movement&&c->poseReady&&p->sequence==c->sequence&&p->tick==c->tick&&p->type==BRIDGE_POSE&&m->type==BRIDGE_MOVEMENT&&p->payloadBytes==RM_LIVE_BYTES&&m->payloadBytes==RM_MOVEMENT_BYTES&&
    bridgeSameIdentity(&c->identity,&p->identity)&&bridgeSameIdentity(&c->identity,&m->identity)&&m->sequence==p->sequence&&m->tick==p->tick&&livePoseFresh(p->tick,now)&&!memcmp(c->pose,pose,RM_LIVE_BYTES)&&!memcmp(c->sourceMovement,movement,RM_MOVEMENT_BYTES)){
  if(c->movementReady&&now-c->tick>150){c->movementReady=false;memset(c->movement,0,sizeof(c->movement));}return false;
 }
 bridgeConsumerInvalidate(c);
 if(!bridgeIdentityValid(&c->identity)||(c->identity.capabilities&(BRIDGE_VISUAL|BRIDGE_GROUND))!=(BRIDGE_VISUAL|BRIDGE_GROUND)||!p||!m||!pose||!movement||p->type!=BRIDGE_POSE||m->type!=BRIDGE_MOVEMENT||p->payloadBytes!=RM_LIVE_BYTES||m->payloadBytes!=RM_MOVEMENT_BYTES||
    !bridgeSameIdentity(&c->identity,&p->identity)||!bridgeSameIdentity(&c->identity,&m->identity)||p->sequence!=m->sequence||p->tick!=m->tick||p->sequence<=c->sequence||p->tick<=c->tick||!livePoseFresh(p->tick,now))return false;
 uint32_t header[16];memcpy(header,pose,sizeof(header));uint64_t innerTick=bridgeU64(pose+16);
 if(header[6]!=c->identity.sourcePid||innerTick!=p->tick||!header[3]||header[3]<=c->sourceSequence||!liveHeaderValid(header,24135,RM_LIVE_BYTES,now,c->tick))return false;
 if((header[7]&4)&&!(c->identity.capabilities&BRIDGE_AIR_HINT))return false;
 if((header[7]&8)&&!(c->identity.capabilities&BRIDGE_COVER))return false;
 for(size_t offset=64;offset<RM_LIVE_BYTES;offset+=4){float coordinate;memcpy(&coordinate,pose+offset,4);if(!isfinite(coordinate)||fabsf(coordinate)>100000)return false;}
 // A zero command explicitly clears control but still permits a valid visual.
 bool zero=true;for(unsigned n=0;n<RM_MOVEMENT_BYTES;n++)if(movement[n]){zero=false;break;}
 float target=0;uint64_t sourceTick=0;bool command=false;
 if(!zero){
  if(bridgeU32(movement+12)!=header[3]||bridgeU64(movement+16)!=innerTick||!movementPacketTarget(movement,RM_MOVEMENT_BYTES,now,header[6],innerTick,4096,&target,&sourceTick))return false;
  command=true;
 }
 memcpy(c->pose,pose,RM_LIVE_BYTES);memcpy(c->sourceMovement,movement,RM_MOVEMENT_BYTES);if(command)memcpy(c->movement,movement,RM_MOVEMENT_BYTES);
 c->sequence=p->sequence;c->tick=p->tick;c->sourceSequence=header[3];c->poseReady=true;c->movementReady=command;return true;
}
static inline bool bridgeConsumerRead(BridgeConsumer *c,BridgeMemory *memory,unsigned char scratchPose[RM_LIVE_BYTES],unsigned char scratchMovement[RM_MOVEMENT_BYTES],uint64_t now){
 BridgeHeader p,m;if(!bridgeMemoryFrame(memory,scratchPose,scratchMovement,now,&p,&m)){
  if(memory->status==BM_BUSY)bridgeConsumerExpire(c,now);else bridgeConsumerInvalidate(c);return false;
 }
 return bridgeConsumerAccept(c,&p,scratchPose,&m,scratchMovement,now);
}
#endif
