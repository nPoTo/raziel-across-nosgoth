// SPDX-License-Identifier: GPL-3.0-or-later
#include "sr1-free-attack-owner.h"
#include <assert.h>
#include <stdio.h>
int main(void){
 SrFreeAttackOwner s={0};const uint16_t x=0x4000,a=0x1000;
 assert(srFreeAttackStep(&s,1,7,true,true,x,x,x)==x); // held on acquisition
 assert(srFreeAttackStep(&s,2,7,true,true,0,0,x)==0);
 assert(srFreeAttackStep(&s,3,7,true,true,x|a,x|a,x)==a);
 assert(srFreeAttackStep(&s,4,7,true,false,x,x,x)==0); // no delayed native attack
 assert(srFreeAttackStep(&s,5,7,true,false,0,0,x)==0);
 assert(srFreeAttackStep(&s,6,7,true,false,x,x,x)==x); // native owns new press
 assert(srFreeAttackStep(&s,7,7,true,true,x,x,x)==x); // cannot acquire mid-press
 srFreeAttackStep(&s,8,7,true,true,0,0,x);
 assert(srFreeAttackStep(&s,9,7,true,true,x,x,x)==0);
 assert(srFreeAttackStep(&s,10,8,true,true,x,x,x)==x); // new actor, no ownership
 srFreeAttackStep(&s,11,8,true,true,0,0,x);
 assert(srFreeAttackStep(&s,12,8,true,true,x,x,x)==0);
 assert(srFreeAttackStep(&s,13,8,false,true,x,x,x)==x); // lease/focus ends
 assert(srFreeAttackStep(&s,14,8,true,true,x,x,x)==x);
 srFreeAttackStep(&s,15,8,true,true,0,0,x);
 assert(srFreeAttackStep(&s,14,8,true,true,x,x,x)==x); // regressed time
 SrFreeAttackOwner pair[2]={0};const uint16_t lb=0x100;
 assert(srFreeAttackPairStep(pair,20,9,true,true,0,0)==0);
 assert(srFreeAttackPairStep(pair,21,9,true,true,x,x)==0);
 assert(srFreeAttackPairStep(pair,22,9,true,true,x|lb,x|lb)==0);
 assert(srFreeAttackPairStep(pair,23,9,true,false,lb,lb)==0);
 assert(srFreeAttackPairStep(pair,24,9,true,false,0,0)==0);
 assert(srFreeAttackPairStep(pair,25,9,true,false,lb,lb)==lb);
 assert(srFreeAttackPairStep(pair,26,9,true,true,lb,lb)==lb);
 assert(srFreeAttackPairStep(pair,27,9,true,true,0,0)==0);
 assert(srFreeAttackPairStep(pair,28,9,true,true,x|lb|a,x|lb|a)==a);
 assert(srFreeAttackPairStep(pair,29,9,false,true,lb,lb)==lb);
 puts("PASS independent X/LB acquisition, native handoff, stale press drain, unrelated buttons and lease cancellation; no gameplay proof");return 0;
}
