#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <bcrypt.h>
#include <stdint.h>
#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "bounded-sha256.h"
#include "cover-topology.h"
int wmain(int argc,wchar_t **argv){
 if(argc!=2)return 1;FILE *in=_wfopen(argv[1],L"rb");if(!in)return 2;
 uint32_t h[4];if(fread(h,sizeof(h),1,in)!=1||h[0]!=0x314c5a52||h[1]!=24135||h[2]!=125790||h[3]!=1){fclose(in);return 3;}
 if(fseek(in,(long)(16+h[1]*12),SEEK_SET)){fclose(in);return 4;}
 ULONG length=h[2]*4;uint32_t *indices=malloc(length);if(!indices){fclose(in);return 5;}
 bool read=fread(indices,length,1,in)==1&&fgetc(in)==EOF;fclose(in);char sha[65];
 bool ok=read&&boundedSha256(indices,length,600000*4,sha)&&!strcmp(sha,COVER_INDEX_SHA);
 // Regression: this payload exceeds the code-proof hash limit of 64 KiB.
 ok=ok&&length>65536&&!boundedSha256(indices,length,65536,sha);
 if(ok){indices[0]^=1;ok=boundedSha256(indices,length,600000*4,sha)&&strcmp(sha,COVER_INDEX_SHA);indices[0]^=1;}
 CoverRange ranges[3];ok=ok&&coverRanges(true,false,ranges)==3&&ranges[1].offset==7830;
 ok=ok&&!boundedSha256(NULL,length,600000*4,sha)&&!boundedSha256(indices,0,600000*4,sha);
 free(indices);if(!ok)return 6;
 puts("Actual render packet: >64KiB index hash accepted, modified topology rejected, code-proof limit retained PASS");return 0;
}
