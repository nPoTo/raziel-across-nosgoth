// SPDX-License-Identifier: GPL-3.0-or-later
#pragma once
#include <d3d11_1.h>
#include <dxgi1_2.h>
#include <d3dcompiler.h>
#include "guidance-text.h"
typedef struct {
 ID3D11Device *device;ID3D11Device1 *device1;ID3D11DeviceContext *context;ID3D11DeviceContext1 *context1;
 ID3DDeviceContextState *state;ID3D11VertexShader *vs;ID3D11PixelShader *ps;ID3D11Buffer *bounds;
 ID3D11Texture2D *texture;ID3D11ShaderResourceView *view;ID3D11SamplerState *sampler;ID3D11RasterizerState *raster;
 unsigned plan,second;bool failed;
} GuidanceD3D;
static GuidanceD3D guidanceD3D;
static HMODULE guidanceCompiler;
#define GUIDANCE_RELEASE(p,type) do{if(p){type##_Release(p);p=NULL;}}while(0)
static void guidanceD3DRelease(GuidanceD3D *g){
 GUIDANCE_RELEASE(g->state,ID3DDeviceContextState);GUIDANCE_RELEASE(g->raster,ID3D11RasterizerState);GUIDANCE_RELEASE(g->sampler,ID3D11SamplerState);GUIDANCE_RELEASE(g->view,ID3D11ShaderResourceView);GUIDANCE_RELEASE(g->texture,ID3D11Texture2D);GUIDANCE_RELEASE(g->bounds,ID3D11Buffer);GUIDANCE_RELEASE(g->ps,ID3D11PixelShader);GUIDANCE_RELEASE(g->vs,ID3D11VertexShader);GUIDANCE_RELEASE(g->context1,ID3D11DeviceContext1);GUIDANCE_RELEASE(g->context,ID3D11DeviceContext);GUIDANCE_RELEASE(g->device1,ID3D11Device1);GUIDANCE_RELEASE(g->device,ID3D11Device);
}
static HRESULT guidanceCompile(const char *source,const char *target,ID3DBlob **out){
 if(!guidanceCompiler)guidanceCompiler=LoadLibraryExW(L"d3dcompiler_47.dll",NULL,LOAD_LIBRARY_SEARCH_SYSTEM32);if(!guidanceCompiler)return E_NOINTERFACE;
 typedef HRESULT (WINAPI *CompileFn)(LPCVOID,SIZE_T,LPCSTR,const D3D_SHADER_MACRO *,ID3DInclude *,LPCSTR,LPCSTR,UINT,UINT,ID3DBlob **,ID3DBlob **);
 CompileFn compile=(CompileFn)(uintptr_t)GetProcAddress(guidanceCompiler,"D3DCompile");ID3DBlob *errors=NULL;HRESULT hr=compile?compile(source,strlen(source),NULL,NULL,NULL,"main",target,D3DCOMPILE_ENABLE_STRICTNESS,0,out,&errors):E_NOINTERFACE;
 // Blob methods live in this module. One bounded module reference stays valid until process exit.
 GUIDANCE_RELEASE(errors,ID3D10Blob);return hr;
}
static HRESULT guidanceD3DInit(GuidanceD3D *g,ID3D11Device *device){
 HRESULT hr=E_FAIL;ID3DBlob *vs=NULL,*ps=NULL;ID3D11Device_AddRef(device);g->device=device;g->second=UINT32_MAX;
 hr=ID3D11Device_QueryInterface(device,&IID_ID3D11Device1,(void **)&g->device1);if(FAILED(hr))goto done;
 ID3D11Device_GetImmediateContext(device,&g->context);hr=ID3D11DeviceContext_QueryInterface(g->context,&IID_ID3D11DeviceContext1,(void **)&g->context1);if(FAILED(hr))goto done;
 D3D_FEATURE_LEVEL level=ID3D11Device_GetFeatureLevel(device);if(level<D3D_FEATURE_LEVEL_10_0){hr=E_NOINTERFACE;goto done;}
 hr=ID3D11Device1_CreateDeviceContextState(g->device1,0,&level,1,D3D11_SDK_VERSION,&IID_ID3D11Device,NULL,&g->state);if(FAILED(hr))goto done;
 const char *vertex="cbuffer C:register(b0){float4 bounds;}struct V{float4 p:SV_Position;float2 uv:TEXCOORD0;};V main(uint i:SV_VertexID){float2 p[6]={float2(0,0),float2(1,0),float2(0,1),float2(0,1),float2(1,0),float2(1,1)};V v;v.uv=p[i];v.p=float4(bounds.x+p[i].x*bounds.z,bounds.y-p[i].y*bounds.w,0,1);return v;}";
 const char *pixel="Texture2D glyphs:register(t0);SamplerState sampleText:register(s0);float4 main(float4 p:SV_Position,float2 uv:TEXCOORD0):SV_Target{return glyphs.Sample(sampleText,uv);}";
 hr=guidanceCompile(vertex,"vs_4_0",&vs);if(FAILED(hr))goto done;hr=guidanceCompile(pixel,"ps_4_0",&ps);if(FAILED(hr))goto done;
 hr=ID3D11Device_CreateVertexShader(device,ID3D10Blob_GetBufferPointer(vs),ID3D10Blob_GetBufferSize(vs),NULL,&g->vs);if(FAILED(hr))goto done;
 hr=ID3D11Device_CreatePixelShader(device,ID3D10Blob_GetBufferPointer(ps),ID3D10Blob_GetBufferSize(ps),NULL,&g->ps);if(FAILED(hr))goto done;
 D3D11_BUFFER_DESC cb={0};cb.ByteWidth=16;cb.Usage=D3D11_USAGE_DEFAULT;cb.BindFlags=D3D11_BIND_CONSTANT_BUFFER;hr=ID3D11Device_CreateBuffer(device,&cb,NULL,&g->bounds);if(FAILED(hr))goto done;
 D3D11_TEXTURE2D_DESC td={0};td.Width=(UINT)sheet_guidanceRenderPolicy_native.rasterWidth;td.Height=(UINT)sheet_guidanceRenderPolicy_native.rasterHeight;td.MipLevels=td.ArraySize=1;td.Format=DXGI_FORMAT_B8G8R8A8_UNORM;td.SampleDesc.Count=1;td.Usage=D3D11_USAGE_DEFAULT;td.BindFlags=D3D11_BIND_SHADER_RESOURCE;
 hr=ID3D11Device_CreateTexture2D(device,&td,NULL,&g->texture);if(FAILED(hr))goto done;hr=ID3D11Device_CreateShaderResourceView(device,(ID3D11Resource *)g->texture,NULL,&g->view);if(FAILED(hr))goto done;
 D3D11_SAMPLER_DESC sd={0};sd.Filter=D3D11_FILTER_MIN_MAG_MIP_LINEAR;sd.AddressU=sd.AddressV=sd.AddressW=D3D11_TEXTURE_ADDRESS_CLAMP;sd.ComparisonFunc=D3D11_COMPARISON_NEVER;sd.MaxLOD=D3D11_FLOAT32_MAX;hr=ID3D11Device_CreateSamplerState(device,&sd,&g->sampler);if(FAILED(hr))goto done;
 D3D11_RASTERIZER_DESC rd={0};rd.FillMode=D3D11_FILL_SOLID;rd.CullMode=D3D11_CULL_NONE;rd.DepthClipEnable=TRUE;hr=ID3D11Device_CreateRasterizerState(device,&rd,&g->raster);
done:GUIDANCE_RELEASE(vs,ID3D10Blob);GUIDANCE_RELEASE(ps,ID3D10Blob);if(FAILED(hr)){guidanceD3DRelease(g);g->failed=true;}return hr;
}
static bool guidanceD3DRender(IDXGISwapChain *chain,unsigned plan,unsigned elapsed,HRESULT *error){
 GuidanceD3D *g=&guidanceD3D;ID3D11Device *device=NULL;ID3D11Texture2D *buffer=NULL;ID3D11RenderTargetView *target=NULL;ID3DDeviceContextState *previous=NULL;
 HRESULT hr=E_FAIL;bool drawn=false;if(g->failed||!guidanceStageAt(plan,elapsed))return false;
 hr=IDXGISwapChain_GetDevice(chain,&IID_ID3D11Device,(void **)&device);if(FAILED(hr))goto done;
 if(g->device&&g->device!=device){hr=E_NOINTERFACE;goto done;} // One bounded device; no silent context replacement.
 if(!g->device){hr=guidanceD3DInit(g,device);if(FAILED(hr))goto done;}
 hr=IDXGISwapChain_GetBuffer(chain,0,&IID_ID3D11Texture2D,(void **)&buffer);if(FAILED(hr))goto done;
 D3D11_TEXTURE2D_DESC td;ID3D11Texture2D_GetDesc(buffer,&td);if(td.Width<320||td.Height<240){hr=E_INVALIDARG;goto done;}
 hr=ID3D11Device_CreateRenderTargetView(device,(ID3D11Resource *)buffer,NULL,&target);if(FAILED(hr))goto done;
 // All D3D pipeline state remains owned by the original context state object.
 ID3D11DeviceContext1_SwapDeviceContextState(g->context1,g->state,&previous);
 ID3D11DeviceContext_ClearState(g->context);
 if(g->plan!=plan||g->second!=elapsed){
  if(!guidanceRaster(plan,elapsed)){hr=E_FAIL;goto restore;}
  ID3D11DeviceContext_UpdateSubresource(g->context,(ID3D11Resource *)g->texture,0,NULL,guidancePixels,(UINT)sheet_guidanceRenderPolicy_native.rasterWidth*4,0);g->plan=plan;g->second=elapsed;
 }
 float width=(float)td.Width-(float)sheet_guidanceRenderPolicy_native.marginPixels*2;if(width>sheet_guidanceRenderPolicy_native.maxDisplayWidth)width=(float)sheet_guidanceRenderPolicy_native.maxDisplayWidth;
 float height=width*(float)sheet_guidanceRenderPolicy_native.rasterHeight/(float)sheet_guidanceRenderPolicy_native.rasterWidth;
 float bounds[4]={-width/td.Width,1-2*(float)sheet_guidanceRenderPolicy_native.topPixels/td.Height,2*width/td.Width,2*height/td.Height};
 ID3D11DeviceContext_UpdateSubresource(g->context,(ID3D11Resource *)g->bounds,0,NULL,bounds,0,0);
 D3D11_VIEWPORT viewport={0,0,(FLOAT)td.Width,(FLOAT)td.Height,0,1};ID3D11DeviceContext_RSSetViewports(g->context,1,&viewport);ID3D11DeviceContext_RSSetState(g->context,g->raster);
 ID3D11DeviceContext_OMSetRenderTargets(g->context,1,&target,NULL);ID3D11DeviceContext_IASetPrimitiveTopology(g->context,D3D11_PRIMITIVE_TOPOLOGY_TRIANGLELIST);
 ID3D11DeviceContext_VSSetShader(g->context,g->vs,NULL,0);ID3D11DeviceContext_VSSetConstantBuffers(g->context,0,1,&g->bounds);ID3D11DeviceContext_PSSetShader(g->context,g->ps,NULL,0);ID3D11DeviceContext_PSSetShaderResources(g->context,0,1,&g->view);ID3D11DeviceContext_PSSetSamplers(g->context,0,1,&g->sampler);ID3D11DeviceContext_Draw(g->context,6,0);drawn=true;hr=S_OK;
restore:
 // Clear our state before switching back: no hidden reference to the game back buffer survives Present/ResizeBuffers.
 ID3D11DeviceContext_ClearState(g->context);ID3D11DeviceContext1_SwapDeviceContextState(g->context1,previous,NULL);
done:GUIDANCE_RELEASE(previous,ID3DDeviceContextState);GUIDANCE_RELEASE(target,ID3D11RenderTargetView);GUIDANCE_RELEASE(buffer,ID3D11Texture2D);GUIDANCE_RELEASE(device,ID3D11Device);if(error)*error=hr;return drawn;
}
