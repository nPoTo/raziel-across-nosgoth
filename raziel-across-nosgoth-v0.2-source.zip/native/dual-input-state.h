// SPDX-License-Identifier: GPL-3.0-or-later
#pragma once
#include <stdint.h>
#include <stdbool.h>
// Semantic input, independent of XInput device presence and polling frequency.
// Integration must supply verified foreground/gameplay/actor ownership.
typedef struct {uint64_t session,sequence,tick;uint32_t held;int16_t x,y;bool valid;} DualInputSample;
typedef struct {uint64_t session,sequence,tick;uint32_t held,blocked,physical;int16_t x,y;bool active,axisBlocked;} DualInputConsumer;
typedef struct {uint32_t held,pressed,released;int16_t x,y;bool active;} DualInputResult;
static inline DualInputResult dualInputConsume(DualInputConsumer *c,const DualInputSample *s,uint64_t now,uint64_t expectedSession,unsigned freshMs,bool owner){
 DualInputResult r={0};
 bool valid=owner&&s&&s->valid&&expectedSession&&s->session==expectedSession&&s->sequence&&s->tick<=now&&now-s->tick<=freshMs;
 if(valid&&c->active&&c->session==s->session&&(s->sequence<c->sequence||s->tick<c->tick))valid=false;
 if(valid&&c->active&&s->sequence==c->sequence&&(s->tick!=c->tick||s->held!=c->physical||s->x!=c->x||s->y!=c->y))valid=false;
 if(!valid){r.released=c->held;c->held=0;c->active=false;return r;}
 bool reset=!c->active||c->session!=s->session;
 if(reset){r.released=c->held;c->held=0;c->blocked=s->held;c->axisBlocked=true;}
 // Held inputs at activation/reacquisition must be released before admission.
 c->blocked&=s->held;
 r.held=s->held&~c->blocked;r.pressed=r.held&~c->held;r.released|=c->held&~r.held;
 if(!s->x&&!s->y)c->axisBlocked=false;
 r.x=reset||c->axisBlocked?0:s->x;r.y=reset||c->axisBlocked?0:s->y;r.active=true;
 c->session=s->session;c->sequence=s->sequence;c->tick=s->tick;c->held=r.held;c->physical=s->held;c->x=s->x;c->y=s->y;c->active=true;return r;
}
