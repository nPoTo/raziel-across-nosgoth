// SPDX-License-Identifier: GPL-3.0-or-later
#pragma once
#include "reaver-presentation-packet.h"
#define REAVER_PRESENTATION_CAPACITY (128u+2048u*36u+8192u*2u+16u*32u)
// Owned RAM cache. Feed only after releasing the IPC lock. GPU consumers may
// read it repeatedly; they may never renew the source timestamp.
typedef struct {ReaverPacketSession session;uint64_t highest;size_t size;bool admitted;ReaverPacketView view;unsigned char bytes[REAVER_PRESENTATION_CAPACITY];} ReaverPresentationLease;
static void reaverPresentationClear(ReaverPresentationLease *l){l->admitted=false;l->size=0;memset(&l->view,0,sizeof(l->view));}
static bool reaverPresentationAccept(ReaverPresentationLease *l,const unsigned char *b,size_t n,uint64_t now){
 if(!l)return false;
 ReaverPacketView v;
 if(n>sizeof(l->bytes)||!reaverPacketValidate(b,n,&l->session,now,l->highest,&v)){reaverPresentationClear(l);return false;}
 if(v.sequence==l->highest){
  // An identical copy can be observed again but cannot revive a cleared lease.
  if(!l->admitted||n!=l->size||memcmp(b,l->bytes,n)){reaverPresentationClear(l);return false;}
  return true;
 }
 l->highest=v.sequence;memcpy(l->bytes,b,n);l->size=n;l->view=v;l->admitted=true;return true;
}
static bool reaverPresentationCurrent(ReaverPresentationLease *l,uint64_t now){
 if(!l||!l->admitted)return false;
 const Sheet_reaverPresentationPacket *p=&sheet_reaverPresentationPacket_weapon_frame_v1;
 if(now<l->view.tick||now-l->view.tick>(uint64_t)p->maxAgeMs){reaverPresentationClear(l);return false;}
 return l->view.visible;
}
