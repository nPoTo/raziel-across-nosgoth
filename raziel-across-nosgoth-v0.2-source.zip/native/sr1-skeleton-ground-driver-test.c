// SPDX-License-Identifier: GPL-3.0-or-later
#define main legacyInstantRootFixture
#include "instant-root-test.c"
#undef main
#include "sr1-skeleton-shared.h"
#include "sr1-ground-shared.h"
typedef struct {uintptr_t actor,object,model;unsigned count,modelIndex;} HostRig;
static bool fixtureContext=true,fixtureRig=true;
static volatile LONG probeBoundedComplete,sr1SkeletonCopies=20,sr1SkeletonFailed;
static SkeletonShared fixtureBones;static SkeletonGroundShared fixtureGround;
static PVOID volatile sr1SkeletonView=&fixtureBones;
static bool sr1SkeletonRead(void *unused,uintptr_t p,void *out,SIZE_T n){(void)unused;return worldRead(p,out,n);}
static bool hostRigRead(void *c,bool (*read)(void *,uintptr_t,void *,SIZE_T),uintptr_t base,HostRig *r){(void)c;(void)read;(void)base;if(!fixtureRig)return false;*r=(HostRig){fixturePlayer,2,3,66,0};return true;}
static bool sr1SkeletonContext(uintptr_t base,uintptr_t actor){(void)base;return fixtureContext&&!wrongForeground&&fixtureUp>.8f&&actor==fixturePlayer&&*(int32_t *)(fixtureActor+0x2d4)==0;}
#include "sr1-skeleton-ground-driver.h"
static void fresh(void){
 uint64_t now=GetTickCount64();SkeletonSnapshot s={.magic=SKELETON_MAGIC,.version=1,.hostPid=GetCurrentProcessId(),.sourcePid=4242,.writerPid=1234,.mode=2,.epoch=now-10000,.tick=now,.hostTick=now,.sourceTick=now,.sequence=1,.actor=fixturePlayer,.object=2,.model=3};memcpy(s.policyHash,skeletonPolicyHash,32);for(unsigned i=0;i<66;i++)s.bones[i][0]=s.bones[i][4]=s.bones[i][8]=1;skeletonStore(&fixtureBones,&s);
 SkeletonGroundPacket g={.magic=0x31475a52,.version=1,.hostPid=GetCurrentProcessId(),.sourcePid=4242,.writerPid=5678,.active=1,.epoch=s.epoch,.tick=now,.hostTick=now,.sourceTick=now,.sequence=1,.actor=fixturePlayer,.object=2,.model=3,.forwardPerFactor=60};memcpy(g.policyHash,skeletonPolicyHash,32);skeletonGroundStore(&fixtureGround,&g);
}
static void setup(void){
 reset();fixtureContext=fixtureRig=true;probeBoundedComplete=sr1SkeletonFailed=0;sr1SkeletonCopies=20;sr1GroundEnabled=1;sr1GroundFailed=sr1GroundThread=0;sr1GroundEpoch=sr1GroundLastYield=0;sr1GroundLease=(Sr1GroundLease){0};sr1GroundView=&fixtureGround;sr1GroundFrames=sr1GroundSwitches=sr1GroundReleases=sr1GroundForeign=0;memset(sr1GroundGates,0,sizeof(sr1GroundGates));rootExternalRelease=sr1GroundRelease;rootExternalAfter=sr1GroundAfter;rootExternalOwnsControllers=sr1GroundOwns;fresh();
}
#ifndef SR1_GROUND_DRIVER_TEST_ENTRY
#define SR1_GROUND_DRIVER_TEST_ENTRY main
#endif
int SR1_GROUND_DRIVER_TEST_ENTRY(void){
 setup();CHECK(rootStationary((uintptr_t)fixtureState,0,0x9876)==0xabcd&&calls==4&&switches==1&&sets==2&&sr1GroundFrames==1&&sr1GroundLease.pending==3);
 RootController c;CHECK(rootControllerRead(instantRootModule,fixturePlayer+0x448,1,&c)&&((float *)c.vector)[1]==-60);int16_t xyz[3];memcpy(xyz,fixtureActor+0x9c,6);CHECK(xyz[0]==11&&xyz[1]==22&&xyz[2]==-4828);
 // EOF/source loss must restore borrowed controllers before native decisions.
 sr1GroundEnabled=0;rootMoving((uintptr_t)fixtureState,0,0);CHECK(!sr1GroundLease.pending&&disables==2&&sr1GroundReleases==2);
 // Controllers that were already native-active are restored, never disabled.
 setup();nativeActive=true;rootStationary((uintptr_t)fixtureState,0,0);CHECK(sr1GroundLease.pending==3&&!disables);sr1GroundEnabled=0;rootMoving((uintptr_t)fixtureState,0,0);CHECK(!sr1GroundLease.pending&&!disables&&rootControllerRead(instantRootModule,fixturePlayer+0x448,1,&c)&&c.active&&((float *)c.vector)[1]==-35);
 // Native writes after our frame belong to native; preserve their value.
 setup();rootStationary((uintptr_t)fixtureState,0,0);float foreign[3]={0,-77,0};mockSet(fixturePlayer+0x448,0,34,(uintptr_t)foreign);sr1GroundEnabled=0;rootMoving((uintptr_t)fixtureState,0,0);CHECK(!sr1GroundLease.pending&&sr1GroundForeign==1&&rootControllerRead(instantRootModule,fixturePlayer+0x448,1,&c)&&c.active&&((float *)c.vector)[1]==-77);
 // Native StartTurn preserves heading and zero forward motion until it exits.
 setup();uintptr_t turn=instantRootModule+0xf5340;memcpy(fixtureState+0x10,&turn,8);rootTurning((uintptr_t)fixtureState,0,0);CHECK(!switches&&rootControllerRead(instantRootModule,fixturePlayer+0x448,1,&c)&&((float *)c.vector)[1]==0);fixtureNextProcess=instantRootModule+0xf4dc0;rootTurning((uintptr_t)fixtureState,0,0);CHECK(switches==1&&rootControllerRead(instantRootModule,fixturePlayer+0x448,1,&c)&&((float *)c.vector)[1]==-60);
 // Ground original handler may enter an interaction; never force it back.
 setup();rootStationary((uintptr_t)fixtureState,0,0);unsigned was=switches;fixtureNextProcess=instantRootModule+0xedb40;rootMoving((uintptr_t)fixtureState,0,0);CHECK(!sr1GroundLease.pending&&switches==was&&*(uintptr_t *)(fixtureState+0x10)==instantRootModule+0xedb40);
 // A jump pose is presentation only, including at zero-velocity apex. Release
 // the prior ground lease before the original call; never apply speed in mode3.
 setup();rootStationary((uintptr_t)fixtureState,0,0);unsigned previousFrames=sr1GroundFrames;fixtureBones.snapshot.mode=3;rootMoving((uintptr_t)fixtureState,0,0);CHECK(!sr1GroundLease.pending&&sr1GroundFrames==previousFrames&&sr1GroundGates[6]==1);
 for(unsigned why=0;why<7;why++){setup();if(why==0)fixtureInput=false;if(why==1)wrongForeground=true;if(why==2)*(int32_t *)(fixtureActor+0x2d4)=1;if(why==3)fixtureContext=false;if(why==4)sr1SkeletonCopies=19;if(why==5)fixtureRig=false;if(why==6)probeBoundedComplete=1;rootStationary((uintptr_t)fixtureState,0,0);CHECK(!sets&&!switches&&!sr1GroundLease.pending);}
 setup();fixtureGround.packet.tick-=500;rootStationary((uintptr_t)fixtureState,0,0);CHECK(!sets&&!switches);
 setup();fixtureGround.packet.sourcePid++;rootStationary((uintptr_t)fixtureState,0,0);CHECK(!sets&&!switches);
 setup();fixtureGround.packet.epoch--;rootStationary((uintptr_t)fixtureState,0,0);CHECK(!sets&&!switches);
 setup();fixtureGround.packet.active=0;fixtureGround.packet.forwardPerFactor=0;rootStationary((uintptr_t)fixtureState,0,0);CHECK(!sets&&!switches);
 setup();fixtureTime=8193;rootStationary((uintptr_t)fixtureState,0,0);CHECK(!sets&&!switches);
 setup();failEnable=true;rootStationary((uintptr_t)fixtureState,0,0);CHECK(sr1GroundFailed&&!sr1GroundLease.pending&&disables==1);
 setup();failSet=true;rootStationary((uintptr_t)fixtureState,0,0);CHECK(sr1GroundFailed&&!sr1GroundLease.pending&&disables==2);
 setup();rootStationary((uintptr_t)fixtureState,0,0);CHECK(sr1GroundOwns());sr1GroundStop();rootMoving((uintptr_t)fixtureState,0,0);CHECK(!sr1GroundOwns());sr1GroundTick();
 puts("Skeleton ground: original once+return, immediate native Move/paired vectors, native turn/no heading or XYZ write, owned-active restore, foreign preserve, native-action/source-loss/air/focus/identity/time/copy gates, partial failure cleanup PASS; fixtures only");return 0;
}
