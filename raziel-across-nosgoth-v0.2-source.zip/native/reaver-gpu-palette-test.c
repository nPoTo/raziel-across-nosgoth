// SPDX-License-Identifier: GPL-3.0-or-later
#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <stdint.h>
#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <wchar.h>
#include "guidance-render.h"
#include "host-transform.h"
#include "reaver-submitted-hand.h"
#include "reaver-joint-palette.h"
#define REQUIRE(x) do{if(!(x)){fprintf(stderr,"FAIL line%d: %s\n",__LINE__,#x);return 1;}}while(0)
#define PAL_API(X) \
 X(PFNGLISPROGRAMPROC,cglIsProgram,"glIsProgram") \
 X(PFNGLGETACTIVEUNIFORMPROC,cglGetActiveUniform,"glGetActiveUniform") \
 X(PFNGLGETACTIVEUNIFORMSIVPROC,cglGetActiveUniformsiv,"glGetActiveUniformsiv") \
 X(PFNGLGETACTIVEUNIFORMBLOCKIVPROC,cglGetActiveUniformBlockiv,"glGetActiveUniformBlockiv") \
 X(PFNGLGETINTEGERI_VPROC,cglGetIntegeri_v,"glGetIntegeri_v") \
 X(PFNGLGETINTEGER64I_VPROC,cglGetInteger64i_v,"glGetInteger64i_v") \
 X(PFNGLGETBUFFERSUBDATAPROC,cglGetBufferSubData,"glGetBufferSubData") \
 X(PFNGLGETBUFFERPARAMETERIVPROC,cglGetBufferParameteriv,"glGetBufferParameteriv") \
 X(PFNGLGETUNIFORMFVPROC,cglGetUniformfv,"glGetUniformfv") \
 X(PFNGLUNIFORM4FVPROC,setVec4,"glUniform4fv") \
 X(PFNGLGENBUFFERSPROC,genBuffers,"glGenBuffers") \
 X(PFNGLDELETEBUFFERSPROC,deleteBuffers,"glDeleteBuffers") \
 X(PFNGLBUFFERDATAPROC,bufferData,"glBufferData") \
 X(PFNGLBINDBUFFERRANGEPROC,bindRange,"glBindBufferRange") \
 X(PFNGLUNIFORMBLOCKBINDINGPROC,blockBinding,"glUniformBlockBinding") \
 X(PFNGLGETUNIFORMBLOCKINDEXPROC,blockIndex,"glGetUniformBlockIndex")
#define DECLARE(t,n,s) static t n;
PAL_API(DECLARE)
#undef DECLARE
#define pglGetProgramiv ghGetProgramiv
#define pglGetUniformLocation ghGetUniformLocation
#define pglBindBuffer ghBindBuffer
static bool cameraReady=true;
#include "reaver-gpu-palette.h"
static GLuint program(bool ubo){
 const char *plain="#version 330 core\nuniform vec4 uJoints[288];void main(){gl_Position=uJoints[gl_VertexID%288];}";
 const char *block="#version 330 core\nlayout(std140) uniform JointBlock{vec4 uJoints[288];};void main(){gl_Position=uJoints[gl_VertexID%288];}";
 GLuint v=guidanceShader(GL_VERTEX_SHADER,ubo?block:plain),f=guidanceShader(GL_FRAGMENT_SHADER,"#version 330 core\nout vec4 c;void main(){c=vec4(1);}");
 if(!v||!f)return 0;GLuint p=ghCreateProgram();ghAttachShader(p,v);ghAttachShader(p,f);ghLinkProgram(p);ghDeleteShader(v);ghDeleteShader(f);GLint linked=0;ghGetProgramiv(p,GL_LINK_STATUS,&linked);return linked?p:0;
}
int main(void){
 WNDCLASSW wc={0};wc.lpfnWndProc=DefWindowProcW;wc.hInstance=GetModuleHandleW(NULL);wc.lpszClassName=L"ReaverPaletteTest";REQUIRE(RegisterClassW(&wc));
 HWND w=CreateWindowW(wc.lpszClassName,L"Hidden palette test",WS_POPUP,0,0,32,32,NULL,NULL,wc.hInstance,NULL);REQUIRE(w);HDC dc=GetDC(w);
 PIXELFORMATDESCRIPTOR pf={0};pf.nSize=sizeof(pf);pf.nVersion=1;pf.dwFlags=PFD_DRAW_TO_WINDOW|PFD_SUPPORT_OPENGL|PFD_DOUBLEBUFFER;pf.iPixelType=PFD_TYPE_RGBA;pf.cColorBits=32;
 int fmt=ChoosePixelFormat(dc,&pf);REQUIRE(fmt&&SetPixelFormat(dc,fmt,&pf));HGLRC context=wglCreateContext(dc);REQUIRE(context&&wglMakeCurrent(dc,context)&&guidanceLoadGL());
#define LOAD(t,n,s) n=(t)wglGetProcAddress(s);REQUIRE(n);
 PAL_API(LOAD)
#undef LOAD
 float pose[66][13]={0};for(unsigned i=0;i<66;i++)pose[i][0]=pose[i][4]=pose[i][8]=1;
 ReaverSubmittedHand hand;REQUIRE(reaverHandCapture(&hand,pose,pose,1,2,3,4,5,true,true,1));
 float palette[96*12];for(unsigned i=0;i<96*12;i++)palette[i]=(float)i*.125f;
 ReaverJointPalette receipt;REQUIRE(reaverPaletteCapture(&receipt,&hand,(uint64_t)(uintptr_t)context,palette,96,palette,96,true));
 float changed[96*12];memcpy(changed,palette,sizeof(changed));changed[20]+=1;
 ReaverJointPalette bad;REQUIRE(!reaverPaletteCapture(&bad,&hand,1,palette,96,changed,96,true));REQUIRE(!bad.valid);
 REQUIRE(!reaverPaletteCapture(&bad,&hand,1,palette,97,palette,97,true));
 GLuint plain=program(false),block=program(true);REQUIRE(plain&&block);ghUseProgram(plain);GLint location=ghGetUniformLocation(plain,"uJoints[0]");REQUIRE(location>=0);setVec4(location,288,palette);
#define MATCH(p,f) reaverGpuPaletteMatches(&receipt,context,p,1,2,3,f)
 REQUIRE(MATCH(plain,4));REQUIRE(!MATCH(plain,5));REQUIRE(!MATCH(block,4));
 setVec4(location,288,changed);REQUIRE(!MATCH(plain,4));setVec4(location,288,palette);REQUIRE(MATCH(plain,4));
 GLuint buffers[2];genBuffers(2,buffers);ghBindBuffer(GL_UNIFORM_BUFFER,buffers[0]);
 GLint alignment=0;glGetIntegerv(GL_UNIFORM_BUFFER_OFFSET_ALIGNMENT,&alignment);REQUIRE(alignment>0&&alignment<=65536);
 size_t bytes=(size_t)alignment+sizeof(palette);unsigned char *memory=calloc(1,bytes);REQUIRE(memory);memcpy(memory+alignment,palette,sizeof(palette));bufferData(GL_UNIFORM_BUFFER,(GLsizeiptr)bytes,memory,GL_STATIC_DRAW);free(memory);
 ghUseProgram(block);GLuint bi=blockIndex(block,"JointBlock");REQUIRE(bi!=GL_INVALID_INDEX);blockBinding(block,bi,3);bindRange(GL_UNIFORM_BUFFER,3,buffers[0],alignment,sizeof(palette));ghBindBuffer(GL_UNIFORM_BUFFER,buffers[1]);
 REQUIRE(MATCH(block,4));GLint restored=0;glGetIntegerv(GL_UNIFORM_BUFFER_BINDING,&restored);REQUIRE((GLuint)restored==buffers[1]);
 bindRange(GL_UNIFORM_BUFFER,3,buffers[0],alignment,16);ghBindBuffer(GL_UNIFORM_BUFFER,buffers[1]);REQUIRE(!MATCH(block,4));glGetIntegerv(GL_UNIFORM_BUFFER_BINDING,&restored);REQUIRE((GLuint)restored==buffers[1]);
 REQUIRE(glGetError()==GL_NO_ERROR);ghUseProgram(0);ghDeleteProgram(plain);ghDeleteProgram(block);deleteBuffers(2,buffers);
 wglMakeCurrent(NULL,NULL);wglDeleteContext(context);ReleaseDC(w,dc);DestroyWindow(w);
 puts("PASS hidden real GL: ordinary/UBO palette equality, all96 joints, changed pose/frame/program refusal, bounded UBO range and generic binding restoration. Synthetic only.");return 0;
}
