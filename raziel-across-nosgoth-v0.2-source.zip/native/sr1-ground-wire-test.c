// SPDX-License-Identifier: GPL-3.0-or-later
#include "sr1-ground-shared.h"
#include <stdio.h>
#define CHECK(x) do{if(!(x)){printf("FAIL ground wire line%u\n",__LINE__);return 1;}}while(0)
int main(int argc,char **argv){
 CHECK(argc==2);FILE *f=fopen(argv[1],"rb");SkeletonGroundPacket s;CHECK(f&&fread(&s,sizeof(s),1,f)==1&&fgetc(f)==EOF);fclose(f);CHECK(s.hostPid==7&&s.sourcePid==8&&s.writerPid==9&&s.active==1&&s.actor==1&&s.object==2&&s.model==3&&skeletonGroundValid(&s,7,2000));float step=0;CHECK(skeletonGroundStep(&s,4096,&step)&&step==-60);CHECK(skeletonGroundStep(&s,2048,&step)&&step==-30);CHECK(!skeletonGroundStep(&s,8193,&step));CHECK(!skeletonGroundValid(&s,6,2000)&&!skeletonGroundValid(&s,7,2151));SkeletonGroundPacket bad=s;bad.reserved=1;CHECK(!skeletonGroundValid(&bad,7,2000));bad=s;bad.forwardPerFactor=NAN;CHECK(!skeletonGroundValid(&bad,7,2000));bad=s;bad.sourceTick=2001;CHECK(!skeletonGroundValid(&bad,7,2000));
 SkeletonGroundShared shared={0};skeletonGroundStore(&shared,&s);SkeletonGroundPacket out;CHECK(skeletonGroundCopy(&shared,&out)&&!memcmp(&s,&out,sizeof(s)));shared.sequence++;CHECK(!skeletonGroundCopy(&shared,&out));shared.sequence++;memset(&s,0,sizeof(s));skeletonGroundStore(&shared,&s);CHECK(skeletonGroundCopy(&shared,&out)&&out.magic==0);
 puts("Ground128byte JS/C wire, native time conversion, root-free scalar command, freshness/foreign/NaN/time/reserved/seqlock/clear PASS; fixtures only");return 0;
}
