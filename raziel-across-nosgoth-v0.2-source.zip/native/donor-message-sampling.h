// SPDX-License-Identifier: GPL-3.0-or-later
#pragma once
#include "donor-message-observer.h"

#define DONOR_MESSAGE_SAMPLE_STORAGE_KEYS 128U
typedef struct {
 uint64_t session,lastKeptTick,lastSeenTick;
 uint32_t threadId,section,messageId,payloadZero;
 uint32_t firstRva[3],secondRva[3],secondMask;
} DonorMessageSampleKey;
typedef struct {
 DonorMessageSampleKey keys[DONOR_MESSAGE_SAMPLE_STORAGE_KEYS];
 uint64_t lastSeenTick;
 uint32_t used;
 bool configured;
} DonorMessageSampler;

// Single collector owner only. This sampler never pairs records, forwards a
// native function, touches game memory, allocates, locks or performs file I/O.
// A false return means ONLY that this completed observation pair is redundant.
static inline bool donorMessageSamplerPolicyValid(const Sheet_donorMessageObservationPolicy *p){
 return p&&p->sampleMs==100&&p->sampleKeys==DONOR_MESSAGE_SAMPLE_STORAGE_KEYS&&p->pendingPairs==128&&p->rawMaxRecords==120000&&p->maxRecords==20000;
}
static inline void donorMessageSamplerInit(DonorMessageSampler *s){
 if(!s)return;memset(s,0,sizeof(*s));s->configured=donorMessageSamplerPolicyValid(&sheet_donorMessageObservationPolicy_bounded);
}
static inline bool donorMessageSampleFloodId(uint32_t id){
 for(unsigned i=0;i<ARRAYSIZE(sheet_donorMessageSampleIds_rows);i++)if(id==(uint32_t)sheet_donorMessageSampleIds_rows[i]->messageId)return true;
 return false;
}
static inline bool donorMessageSampleStateValid(const uint32_t first[3],const uint32_t second[3],uint32_t mask){
 if(mask>7)return false;
 for(unsigned i=0;i<3;i++)if(!first[i]||((mask&(1U<<i))?second[i]==0:second[i]!=0))return false;
 return true;
}
static inline bool donorMessageSampleStateEqual(const uint32_t aFirst[3],const uint32_t aSecond[3],uint32_t aMask,const uint32_t bFirst[3],const uint32_t bSecond[3],uint32_t bMask){
 return aMask==bMask&&!memcmp(aFirst,bFirst,3*sizeof(uint32_t))&&!memcmp(aSecond,bSecond,3*sizeof(uint32_t));
}
static inline bool donorMessageSamplePairValid(const DonorMessageEvent *entry,const DonorMessageEvent *exit){
 if(!entry||!exit||entry->phase!=DONOR_MESSAGE_ENTER||exit->phase!=DONOR_MESSAGE_EXIT||entry->afterValid||exit->afterValid!=1||!entry->session||entry->session!=exit->session||!entry->callId||entry->callId!=exit->callId||!entry->threadId||entry->threadId!=exit->threadId||entry->section>2||entry->section!=exit->section||!entry->depth||entry->depth>32||entry->depth!=exit->depth||entry->messageId!=exit->messageId||entry->payloadZero>1||entry->payloadZero!=exit->payloadZero||!entry->tickMs||exit->tickMs<entry->tickMs||entry->afterSecondMask)return false;
 for(unsigned i=0;i<3;i++)if(entry->afterFirstRva[i]||entry->afterSecondRva[i])return false;
 return donorMessageSampleStateValid(entry->beforeFirstRva,entry->beforeSecondRva,entry->beforeSecondMask)&&donorMessageSampleStateValid(exit->afterFirstRva,exit->afterSecondRva,exit->afterSecondMask)&&donorMessageSampleStateEqual(entry->beforeFirstRva,entry->beforeSecondRva,entry->beforeSecondMask,exit->beforeFirstRva,exit->beforeSecondRva,exit->beforeSecondMask);
}
static inline bool donorMessageSampleKeyEqual(const DonorMessageSampleKey *k,const DonorMessageEvent *e){
 return k->session==e->session&&k->threadId==e->threadId&&k->section==e->section&&k->messageId==e->messageId&&k->payloadZero==e->payloadZero&&donorMessageSampleStateEqual(k->firstRva,k->secondRva,k->secondMask,e->beforeFirstRva,e->beforeSecondRva,e->beforeSecondMask);
}
static inline bool donorMessagePairKeep(DonorMessageSampler *s,const DonorMessageEvent *entry,const DonorMessageEvent *exit,uint32_t intervalMs){
 const Sheet_donorMessageObservationPolicy *p=&sheet_donorMessageObservationPolicy_bounded;
 if(!s||!s->configured||!donorMessageSamplerPolicyValid(p)||intervalMs!=(uint32_t)p->sampleMs||s->used>(uint32_t)p->sampleKeys||!donorMessageSamplePairValid(entry,exit))return true;
 // Concurrent native producers may enqueue completed pairs out of clock order.
 // Keep those pairs even if their individual key appears recently sampled.
 if(exit->tickMs<s->lastSeenTick)return true;
 s->lastSeenTick=exit->tickMs;
 // Changes and nested/rare messages carry transition evidence. Never sample them
 // merely because an outer completed pair looks equal before and after.
 if(entry->depth>1||!donorMessageSampleFloodId(entry->messageId)||!donorMessageSampleStateEqual(entry->beforeFirstRva,entry->beforeSecondRva,entry->beforeSecondMask,exit->afterFirstRva,exit->afterSecondRva,exit->afterSecondMask))return true;
 const uint64_t tick=exit->tickMs;
 for(unsigned i=0;i<s->used;i++){
  DonorMessageSampleKey *k=&s->keys[i];if(!donorMessageSampleKeyEqual(k,entry))continue;
  // Backward time is evidence, never a reason to discard a record. Retain the
  // previous high-water mark until the observed clock catches up again.
  if(tick<k->lastSeenTick||tick<k->lastKeptTick)return true;
  k->lastSeenTick=tick;
  if(tick-k->lastKeptTick>=intervalMs){k->lastKeptTick=tick;return true;}
  return false;
 }
 // No eviction: a full cache makes later unseen keys pass through verbatim.
 if(s->used>=(uint32_t)p->sampleKeys)return true;
 DonorMessageSampleKey *k=&s->keys[s->used++];k->session=entry->session;k->lastKeptTick=tick;k->lastSeenTick=tick;k->threadId=entry->threadId;k->section=entry->section;k->messageId=entry->messageId;k->payloadZero=entry->payloadZero;k->secondMask=entry->beforeSecondMask;
 memcpy(k->firstRva,entry->beforeFirstRva,sizeof(k->firstRva));memcpy(k->secondRva,entry->beforeSecondRva,sizeof(k->secondRva));return true;
}
