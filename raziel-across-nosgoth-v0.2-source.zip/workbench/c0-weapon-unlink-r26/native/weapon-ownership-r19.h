// SPDX-License-Identifier: GPL-3.0-or-later
#pragma once
#include "exploration-sheets.h"
#include "r19-policy.h"
#include "r24-policy.h"
#include "r25-policy.h"

typedef enum {
    C0_WEAPON_IDLE,
    C0_WEAPON_REQUESTED,
    C0_WEAPON_PICKUP,
    C0_WEAPON_HELD,
    C0_WEAPON_THROW,
    C0_WEAPON_DETACHED,
    C0_WEAPON_UNRESOLVED
} C0WeaponPhase;

typedef struct {
    uint64_t epoch, step, boundaryStep, attackWitnessStep, acquisitionStep;
    uintptr_t actor, weapon;
    C0WeaponPhase phase;
    bool acquiredUnlinkPending;
} C0WeaponState;

typedef struct {
    uint64_t epoch, step, pickupForRequestStep, returnForDetachStep;
    uintptr_t actor, candidate, held, throwReference;
    uint32_t callbacks[3], pickupSense, heldQueryRva;
    uint16_t descriptorFamily, descriptorMarker;
    int32_t heldSegment;
    bool coherent, requestEligible, requestEdge, existingNativeRoute, returnComplete, inputNeutral;
    bool completedNativeAttack, pinnedAttackUnlink;
    bool pinnedOrdinaryUnlink, originalUnlinkReceipt;
} C0WeaponInput;

typedef struct {
    C0WeaponPhase phase;
    bool forwardPress, suppressLinked, handedBack;
} C0WeaponDecision;

static inline bool c0WeaponSections(const C0WeaponInput *in, uint32_t callback) {
    return in->callbacks[0] == callback && in->callbacks[1] == callback && in->callbacks[2] == callback;
}

// All sections must agree on one already accepted ordinary ground state.
// This helper is used only after a proved detach, never for pickup admission.
static inline bool c0WeaponReturnSections(const C0WeaponInput *in) {
    for (size_t i=0;i<sheet_c0OrdinaryReturnR19_count;++i)
        if (c0WeaponSections(in, (uint32_t)sheet_c0OrdinaryReturnR19_rows[i]->rva)) return true;
    return false;
}

static inline bool c0WeaponPinnedAttachment(const C0WeaponInput *in, uintptr_t weapon,
                                             const Sheet_c0WeaponOwnership *p) {
    return in->held == weapon && in->heldQueryRva == p->heldQueryRva && in->heldSegment == p->heldSegment;
}

static inline bool c0WeaponSafeThrowReference(const C0WeaponInput *in, uintptr_t weapon) {
    return !in->throwReference || in->throwReference == weapon;
}

static inline bool c0WeaponOriginalUnlinkOwner(const C0WeaponState *state) {
    return state->acquisitionStep && (state->phase == C0_WEAPON_HELD || state->phase == C0_WEAPON_THROW ||
        (state->phase == C0_WEAPON_UNRESOLVED && state->acquiredUnlinkPending));
}

// A zero-initialized state belongs to one authenticated actor epoch. Only its
// session owner may discard the state after authenticated teardown.
static inline C0WeaponDecision c0WeaponAdvance(C0WeaponState *state, const C0WeaponInput *in) {
    const Sheet_c0WeaponOwnership *p = &sheet_c0WeaponOwnership_family0;
    C0WeaponDecision out = {0};
    if (!state) return out;
    out.phase = state->phase;
    out.suppressLinked = state->phase != C0_WEAPON_IDLE;
    if (!in || !in->coherent || !in->epoch || !in->actor || !in->step ||
        (state->epoch && (state->epoch != in->epoch || state->actor != in->actor || state->step >= in->step))) return out;
    state->epoch = in->epoch;
    state->step = in->step;
    state->actor = in->actor;

    const bool ordinaryUnlink = in->pinnedOrdinaryUnlink && (state->phase == C0_WEAPON_HELD ||
        (state->phase == C0_WEAPON_UNRESOLVED && state->acquiredUnlinkPending));
    const bool originalUnlink = in->originalUnlinkReceipt && c0WeaponOriginalUnlinkOwner(state);
    if ((ordinaryUnlink || originalUnlink) && !in->held && c0WeaponSafeThrowReference(in, state->weapon) &&
        c0WeaponReturnSections(in)) {
        state->attackWitnessStep = 0;
        state->acquiredUnlinkPending = false;
        state->phase = C0_WEAPON_DETACHED;
        state->boundaryStep = in->step;
        out.phase = state->phase;
        return out;
    }

    switch (state->phase) {
    case C0_WEAPON_IDLE:
        if (in->requestEdge && in->requestEligible && !in->existingNativeRoute &&
            in->candidate && in->candidate != in->actor && !in->held &&
            c0WeaponSections(in, (uint32_t)p->idleCallbackRva) &&
            !(in->pickupSense & (uint32_t)p->pickupSenseMask) &&
            in->descriptorFamily == p->family && in->descriptorMarker == p->marker) {
            state->weapon = in->candidate;
            state->boundaryStep = in->step;
            state->phase = C0_WEAPON_REQUESTED;
            out.forwardPress = true;
        }
        break;
    case C0_WEAPON_REQUESTED:
        if (in->held || in->candidate != state->weapon) state->phase = C0_WEAPON_UNRESOLVED;
        else if (in->pickupForRequestStep == state->boundaryStep && in->callbacks[1] == p->pickupCallbackRva &&
            (in->pickupSense & (uint32_t)p->pickupSenseMask)) state->phase = C0_WEAPON_PICKUP;
        break;
    case C0_WEAPON_PICKUP:
        if (c0WeaponPinnedAttachment(in, state->weapon, p) &&
            in->callbacks[1] == p->pickupCallbackRva && !(in->pickupSense & (uint32_t)p->pickupSenseMask)) {
            state->acquisitionStep = in->step;
            state->phase = C0_WEAPON_HELD;
        } else if (in->held || in->callbacks[1] != p->pickupCallbackRva) state->phase = C0_WEAPON_UNRESOLVED;
        break;
    case C0_WEAPON_HELD: {
        const bool pinned = c0WeaponPinnedAttachment(in, state->weapon, p);
        const bool attack = in->completedNativeAttack && c0WeaponSafeThrowReference(in, state->weapon) &&
            c0WeaponSections(in, (uint32_t)sheet_c0AttackDetachR24_observed.callbackRva);
        const bool followsWitness = state->attackWitnessStep && in->step - state->attackWitnessStep == 1;
        state->attackWitnessStep = attack && pinned ? in->step : 0;
        if (attack && followsWitness && !in->held && in->pinnedAttackUnlink) {
            state->phase = C0_WEAPON_DETACHED;
            state->boundaryStep = in->step;
        } else if (!pinned) {
            state->acquiredUnlinkPending = !in->held && c0WeaponSafeThrowReference(in, state->weapon);
            state->phase = C0_WEAPON_UNRESOLVED;
        }
        else if (c0WeaponSections(in, (uint32_t)p->throwCallbackRva))
            state->phase = in->throwReference == state->weapon ? C0_WEAPON_THROW : C0_WEAPON_UNRESOLVED;
        break;
    }
    case C0_WEAPON_THROW:
        if (!c0WeaponSections(in, (uint32_t)p->throwCallbackRva) ||
            (in->throwReference && in->throwReference != state->weapon) ||
            (in->held && (!c0WeaponPinnedAttachment(in, state->weapon, p) || in->throwReference != state->weapon))) {
            state->acquiredUnlinkPending = !in->held && c0WeaponSafeThrowReference(in, state->weapon);
            state->phase = C0_WEAPON_UNRESOLVED;
        } else if (!in->held) {
            state->phase = C0_WEAPON_DETACHED;
            state->boundaryStep = in->step;
        }
        break;
    case C0_WEAPON_DETACHED:
        if (in->held || (in->throwReference && in->throwReference != state->weapon)) state->phase = C0_WEAPON_UNRESOLVED;
        else if (in->returnComplete && in->returnForDetachStep == state->boundaryStep && in->inputNeutral &&
            c0WeaponReturnSections(in)) {
            state->weapon = 0;
            state->boundaryStep = 0;
            state->acquisitionStep = 0;
            state->phase = C0_WEAPON_IDLE;
            out.handedBack = true;
        }
        break;
    case C0_WEAPON_UNRESOLVED:
        if (in->held || !c0WeaponSafeThrowReference(in, state->weapon)) state->acquiredUnlinkPending = false;
        break;
    }
    out.phase = state->phase;
    out.suppressLinked = state->phase != C0_WEAPON_IDLE;
    return out;
}
