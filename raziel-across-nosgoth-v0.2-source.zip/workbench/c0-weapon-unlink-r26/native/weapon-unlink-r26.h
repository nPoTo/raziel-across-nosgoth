// SPDX-License-Identifier: GPL-3.0-or-later
#pragma once
#include "r26-policy.h"

typedef struct {
    uint64_t tick, contactSequence;
} C0UnlinkReceiptR26;

typedef struct {
    uint64_t epoch, acquisitionStep;
    uintptr_t actor, weapon;
    DWORD thread;
    C0LinkIdentity identity;
} C0UnlinkTicketR26;

typedef void (*C0NativeUnlinkR26)(uintptr_t child);
static SRWLOCK sr1C0UnlinkLock = SRWLOCK_INIT;
static C0UnlinkTicketR26 sr1C0UnlinkTicket;
static C0UnlinkReceiptR26 sr1C0UnlinkReceipt;
static bool sr1C0UnlinkFailureLogged;
static volatile LONG sr1C0UnlinkAttempted, sr1C0UnlinkEnabled;
static uintptr_t sr1C0UnlinkBase;
static PVOID sr1C0UnlinkTarget;
static C0NativeUnlinkR26 sr1C0UnlinkOriginal;
static _Thread_local unsigned sr1C0UnlinkDepth;

static void sr1C0ClearUnlinkTicket(void) {
    AcquireSRWLockExclusive(&sr1C0UnlinkLock);
    sr1C0UnlinkTicket = (C0UnlinkTicketR26){0};
    sr1C0UnlinkReceipt = (C0UnlinkReceiptR26){0};
    sr1C0UnlinkFailureLogged = false;
    ReleaseSRWLockExclusive(&sr1C0UnlinkLock);
}

static bool sr1C0UnlinkLease(const C0UnlinkTicketR26 *ticket) {
    return InterlockedCompareExchange(&sr1C0UnlinkEnabled, 0, 0) &&
        ticket->epoch && ticket->acquisitionStep && ticket->actor && ticket->weapon &&
        ticket->epoch == (uint64_t)InterlockedCompareExchange64(&sr1C0Epoch, 0, 0) &&
        sr1C0NativeActive(ticket->actor) && ticket->thread == GetCurrentThreadId();
}

static void sr1C0PublishUnlinkTicket(uint64_t epoch, uintptr_t actor, uintptr_t weapon,
                                    uint64_t acquisitionStep, const C0LinkIdentity *identity) {
    if (!identity || !identity->actorId || !identity->targetId || actor == weapon) return;
    const C0UnlinkTicketR26 ticket = {epoch, acquisitionStep, actor, weapon, GetCurrentThreadId(), *identity};
    if (!sr1C0UnlinkLease(&ticket)) return;
    AcquireSRWLockExclusive(&sr1C0UnlinkLock);
    if (sr1C0UnlinkLease(&ticket)) {
        sr1C0UnlinkTicket = ticket;
        sr1C0UnlinkReceipt = (C0UnlinkReceiptR26){0};
        sr1C0UnlinkFailureLogged = false;
    }
    ReleaseSRWLockExclusive(&sr1C0UnlinkLock);
}

static bool sr1C0ReadUnlinkReceipt(uint64_t epoch, uintptr_t actor, uintptr_t weapon,
                                  uint64_t acquisitionStep, uint64_t now, C0UnlinkReceiptR26 *out) {
    *out = (C0UnlinkReceiptR26){0};
    if (!TryAcquireSRWLockShared(&sr1C0UnlinkLock)) return false;
    const C0UnlinkTicketR26 *ticket = &sr1C0UnlinkTicket;
    const C0UnlinkReceiptR26 receipt = sr1C0UnlinkReceipt;
    const bool valid = ticket->epoch == epoch && ticket->actor == actor && ticket->weapon == weapon &&
        ticket->acquisitionStep == acquisitionStep && sr1C0UnlinkLease(ticket) &&
        receipt.tick >= epoch && receipt.tick <= now && receipt.contactSequence >= acquisitionStep;
    if (valid) *out = receipt;
    ReleaseSRWLockShared(&sr1C0UnlinkLock);
    return valid;
}

static bool sr1C0UnlinkCurrentTicket(uintptr_t child, C0UnlinkTicketR26 *out) {
    if (!TryAcquireSRWLockShared(&sr1C0UnlinkLock)) return false;
    const bool valid = child && child == sr1C0UnlinkTicket.weapon && !sr1C0UnlinkReceipt.tick &&
        sr1C0UnlinkLease(&sr1C0UnlinkTicket);
    if (valid) *out = sr1C0UnlinkTicket;
    ReleaseSRWLockShared(&sr1C0UnlinkLock);
    return valid;
}

static bool sr1C0UnlinkRead(void *unused, uintptr_t address, void *out, size_t count) {
    (void)unused;
    return worldRead(address, out, count);
}

static bool sr1C0UnlinkClearLinks(const WeaponSource *source, const C0UnlinkTicketR26 *ticket) {
    const Sheet_c0WeaponObservation *p = &sheet_c0WeaponObservation_observation;
    const Sheet_c0PickupLinkProof *link = &sheet_c0PickupLinkProof_physical;
    uint32_t actorId, targetId;
    uintptr_t parent, sibling;
    return weaponReadAt(source, ticket->actor, link->instanceIdOffset, &actorId, sizeof(actorId)) &&
        actorId == ticket->identity.actorId &&
        weaponReadAt(source, ticket->weapon, link->instanceIdOffset, &targetId, sizeof(targetId)) &&
        targetId == ticket->identity.targetId &&
        weaponReadAt(source, ticket->weapon, p->parentOffset, &parent, sizeof(parent)) && !parent &&
        weaponReadAt(source, ticket->weapon, p->siblingOffset, &sibling, sizeof(sibling)) && !sibling;
}

static void sr1C0UnlinkRecord(const C0UnlinkTicketR26 *ticket, unsigned stage, C0UnlinkReceiptR26 receipt) {
    if (!TryAcquireSRWLockExclusive(&sr1C0UnlinkLock)) return;
    const C0UnlinkTicketR26 *current = &sr1C0UnlinkTicket;
    bool log = false;
    if (!sr1C0UnlinkReceipt.tick && current->epoch == ticket->epoch && current->actor == ticket->actor &&
        current->weapon == ticket->weapon && current->acquisitionStep == ticket->acquisitionStep &&
        current->thread == ticket->thread && sr1C0UnlinkLease(current) &&
        c0LinkSameIdentity(&current->identity, &ticket->identity)) {
        if (receipt.tick) {
            sr1C0UnlinkReceipt = receipt;
            log = true;
        } else if (!sr1C0UnlinkFailureLogged) {
            sr1C0UnlinkFailureLogged = true;
            log = true;
        }
    }
    ReleaseSRWLockExclusive(&sr1C0UnlinkLock);
    if (log) logLine("C0_NATIVE_UNLINK receipt=%u stage=%u tick=%llu contact=%llu acquisition=%llu",
        receipt.tick != 0, stage, (unsigned long long)receipt.tick,
        (unsigned long long)receipt.contactSequence, (unsigned long long)ticket->acquisitionStep);
}

static void sr1C0ObserveUnlink(uintptr_t child) {
    const DWORD entryError = GetLastError();
    const bool outer = sr1C0UnlinkDepth++ == 0;
    const Sheet_c0WeaponObservation *p = &sheet_c0WeaponObservation_observation;
    const WeaponSource source = {NULL, sr1C0UnlinkRead, sr1C0UnlinkBase, (uint32_t)p->imageBytes};
    C0UnlinkTicketR26 ticket;
    const bool observing = outer && sr1C0UnlinkCurrentTicket(child, &ticket);
    C0RawContact contact;
    WeaponSnapshot before;
    unsigned stage = 0;
    if (observing) {
        const C0PickupScope scope = {.actor=ticket.actor,.target=ticket.weapon};
        const C0LinkTicket linkTicket = {.scope=scope,.identity=ticket.identity};
        C0LinkState link;
        stage = 1;
        if (sr1C0ReadContact(ticket.actor, ticket.epoch, GetTickCount64(), &contact) &&
            contact.sequence >= ticket.acquisitionStep) {
            stage = 2;
            if (weaponPair(&source, &before) && before.actor == ticket.actor && before.realm == p->materialRealm &&
                c0LinkReciprocal(&linkTicket, &before)) {
                stage = 3;
                if (c0LinkReadPair(&source, &scope, &link) && link.parent == ticket.actor &&
                    c0LinkSameIdentity(&ticket.identity, &link.identity)) stage = 4;
            }
        }
    }

    SetLastError(entryError);
    sr1C0UnlinkOriginal(child);
    const DWORD originalError = GetLastError();

    if (observing) {
        C0UnlinkReceiptR26 receipt = {0};
        if (stage == 4) {
            const uint64_t eventTick = GetTickCount64();
            WeaponSnapshot after;
            C0RawContact latest;
            if (sr1C0UnlinkLease(&ticket) && sr1C0UnlinkClearLinks(&source, &ticket) &&
                weaponPair(&source, &after) && weaponSameActor(&before, &after) && after.realm == before.realm &&
                !after.effective && sr1C0UnlinkClearLinks(&source, &ticket) &&
                sr1C0ReadContact(ticket.actor, ticket.epoch, eventTick, &latest) &&
                latest.sequence >= contact.sequence) {
                receipt = (C0UnlinkReceiptR26){eventTick, latest.sequence};
            }
        }
        sr1C0UnlinkRecord(&ticket, stage, receipt);
    }
    --sr1C0UnlinkDepth;
    SetLastError(originalError);
}

static void sr1C0UnlinkInstall(HMODULE module) {
    if (InterlockedCompareExchange(&sr1C0UnlinkAttempted, 1, 0)) return;
    const Sheet_c0NativeUnlinkR26 *p = &sheet_c0NativeUnlinkR26_observed;
    unsigned char bytes[363];
    char digest[65];
    MEMORY_BASIC_INFORMATION memory;
    const uintptr_t target = (uintptr_t)module + (uintptr_t)p->targetRva;
    const bool verified = module && InterlockedCompareExchangePointer(&verifiedSr1Module, NULL, NULL) == module &&
        p->targetRva == 0x7b180 && p->targetBytes == sizeof(bytes) &&
        !wcscmp(p->moduleSha256, sheet_c0WeaponObservation_observation.moduleSha256);
    const bool executable = verified && VirtualQuery((const void *)target, &memory, sizeof(memory)) == sizeof(memory) &&
        memory.AllocationBase == module && memory.State == MEM_COMMIT &&
        (memory.Protect == PAGE_EXECUTE_READ || memory.Protect == PAGE_EXECUTE_READWRITE ||
         memory.Protect == PAGE_EXECUTE_WRITECOPY) && target >= (uintptr_t)memory.BaseAddress &&
        sizeof(bytes) <= memory.RegionSize && target - (uintptr_t)memory.BaseAddress <= memory.RegionSize - sizeof(bytes);
    const bool exact = executable && worldRead(target, bytes, sizeof(bytes)) &&
        hashBytes(bytes, sizeof(bytes), digest) && strlen(digest) == 64;
    bool match = exact;
    for (unsigned i = 0; match && i < 64; ++i) match = p->codeSha256[i] == (wchar_t)digest[i];
    MH_STATUS init = MH_UNKNOWN, create = MH_UNKNOWN, enable = MH_UNKNOWN;
    if (match && !p->codeSha256[64]) {
        init = MH_Initialize();
        if (init == MH_OK || init == MH_ERROR_ALREADY_INITIALIZED) {
            sr1C0UnlinkBase = (uintptr_t)module;
            create = MH_CreateHook((PVOID)target, (PVOID)&sr1C0ObserveUnlink, (PVOID *)&sr1C0UnlinkOriginal);
            if (create == MH_OK) {
                sr1C0UnlinkTarget = (PVOID)target;
                enable = MH_EnableHook(sr1C0UnlinkTarget);
                if (enable == MH_OK) InterlockedExchange(&sr1C0UnlinkEnabled, 1);
            }
        }
    }
    logLine("C0_NATIVE_UNLINK_INSTALL active=%u module=%u executable=%u body=%u init=%d create=%d enable=%d",
        enable == MH_OK, verified, executable, match, init, create, enable);
}

static void sr1C0UnlinkStop(void) {
    const bool enabled = InterlockedExchange(&sr1C0UnlinkEnabled, 0) != 0;
    sr1C0ClearUnlinkTicket();
    if (enabled && sr1C0UnlinkTarget) {
        const MH_STATUS status = MH_DisableHook(sr1C0UnlinkTarget);
        logLine("C0_NATIVE_UNLINK_STOP disable=%d", status);
    }
}
