// SPDX-License-Identifier: GPL-3.0-or-later
#pragma once
#include <stdbool.h>
#include <stdint.h>
#include <string.h>
#include "cathedral-bell-policy.h"

static inline bool cathedralBellIdentity(const char name[9], int32_t stream, uint32_t intro,
    uintptr_t base, uintptr_t collision, uintptr_t message) {
    return base && stream == CATHEDRAL_BELL_STREAM && intro == CATHEDRAL_BELL_INTRO &&
        collision == base + CATHEDRAL_BELL_COLLISION_RVA && message == base + CATHEDRAL_BELL_MESSAGE_RVA &&
        memcmp(name, CATHEDRAL_BELL_NAME, 9) == 0;
}

static inline bool cathedralBellSphere(const unsigned char sphere[16], unsigned segment) {
    uint16_t radius;
    memcpy(&radius, sphere + 14, sizeof(radius));
    return segment == 0 && (sphere[4] == 0 || sphere[4] == 1) && radius == CATHEDRAL_BELL_RADIUS;
}
