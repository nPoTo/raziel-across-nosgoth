// SPDX-License-Identifier: GPL-3.0-or-later
#include "cathedral-bell-contact.h"
#include <stdio.h>

int main(void) {
    const uintptr_t base = (uintptr_t)0x180000000ull;
    const uintptr_t collision = base + CATHEDRAL_BELL_COLLISION_RVA;
    const uintptr_t message = base + CATHEDRAL_BELL_MESSAGE_RVA;
    if (!cathedralBellIdentity("bellsc__", -4750, 5057, base, collision, message)) return 1;
    if (cathedralBellIdentity("bellsc__", -4731, 6041, base, collision, message) ||
        cathedralBellIdentity("bellsc__", -4750, 5058, base, collision, message) ||
        cathedralBellIdentity("ronin___", -4750, 5057, base, collision, message) ||
        cathedralBellIdentity("bellsc__", -4750, 5057, base, collision + 1, message) ||
        cathedralBellIdentity("bellsc__", -4750, 5057, base, collision, message + 1)) return 2;
    unsigned char sphere[16] = {0};
    const uint16_t radius = 281;
    memcpy(sphere + 14, &radius, sizeof(radius));
    if (!cathedralBellSphere(sphere, 0) || cathedralBellSphere(sphere, 1)) return 3;
    sphere[4] = 1;
    if (!cathedralBellSphere(sphere, 0)) return 4;
    sphere[4] = 8;
    if (cathedralBellSphere(sphere, 0)) return 5;
    sphere[4] = 0;
    sphere[14]++;
    if (cathedralBellSphere(sphere, 0)) return 6;
    puts("Cathedral bell contact identity: PASS");
    return 0;
}
