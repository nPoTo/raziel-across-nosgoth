// SPDX-License-Identifier: GPL-3.0-or-later
#pragma once
#include "r28-policy.h"

static bool sr1C0ReadNativePool(const WeaponSource *source, uintptr_t *manager, uintptr_t *pool) {
    const Sheet_c0RetiredPoolR28 *p = &sheet_c0RetiredPoolR28_observed;
    return weaponImageRead(source, sheet_c0PickupLinkProof_physical.instanceListRva, manager, sizeof(*manager)) &&
        weaponPointer(*manager) && weaponReadAt(source, *manager, p->poolOffset, pool, sizeof(*pool)) &&
        weaponPointer(*pool);
}

static void sr1C0PinRetiredPool(const WeaponSource *source) {
    uintptr_t manager, pool;
    if (sr1C0ReadNativePool(source, &manager, &pool)) {
        sr1C0RetiredManager = manager;
        sr1C0RetiredPool = pool;
    }
}

static bool sr1C0ReadFreedLinks(const WeaponSource *source, uintptr_t item, uint32_t *generation,
                               uintptr_t *parent, uintptr_t *sibling) {
    const Sheet_c0PickupLinkProof *link = &sheet_c0PickupLinkProof_physical;
    const Sheet_c0WeaponObservation *p = &sheet_c0WeaponObservation_observation;
    return weaponReadAt(source, item, link->instanceIdOffset, generation, sizeof(*generation)) &&
        weaponReadAt(source, item, p->parentOffset, parent, sizeof(*parent)) &&
        weaponReadAt(source, item, p->siblingOffset, sibling, sizeof(*sibling));
}

static bool sr1C0FindRetiredInFreeList(const WeaponSource *source, uintptr_t pool, uintptr_t item) {
    const Sheet_c0RetiredPoolR28 *p = &sheet_c0RetiredPoolR28_observed;
    const Sheet_c0NativeRetireR27 *list = &sheet_c0NativeRetireR27_observed;
    uint32_t count, countAfter;
    uintptr_t head, headAfter;
    if (!weaponReadAt(source, pool, p->freeCountOffset, &count, sizeof(count)) ||
        !count || count > (uint32_t)p->maxNodes ||
        !weaponReadAt(source, pool, p->freeHeadOffset, &head, sizeof(head))) return false;
    bool found = false;
    // Native allocation advances the head without clearing the new head's
    // previous link. The allocator follows only next links.
    uintptr_t node = head;
    for (uint32_t i = 0; i < count; ++i) {
        uintptr_t next;
        if (!weaponPointer(node) ||
            !weaponReadAt(source, node, list->listNextOffset, &next, sizeof(next))) return false;
        if (node == item) found = true;
        node = next;
    }
    return !node && found &&
        weaponReadAt(source, pool, p->freeCountOffset, &countAfter, sizeof(countAfter)) && countAfter == count &&
        weaponReadAt(source, pool, p->freeHeadOffset, &headAfter, sizeof(headAfter)) && headAfter == head;
}

static bool sr1C0ProveRetiredItem(const WeaponSource *source, const WeaponSnapshot *snapshot,
                                 const C0RawContact *contact, const C0WeaponInput *input, uint64_t now) {
    if (!c0WeaponOriginalUnlinkOwner(&sr1C0State) || !sr1C0Identity.targetId) return false;
    const uintptr_t item = sr1C0State.weapon;
    uint32_t generation = 0, generationAfter;
    uintptr_t parent = 0, sibling = 0, parentAfter, siblingAfter, manager, pool, managerAfter, poolAfter;
    C0RawContact latest;
    const bool read = sr1C0ReadFreedLinks(source, item, &generation, &parent, &sibling);
    const bool reset = read && !generation && !parent && !sibling;
    const bool samePool = sr1C0RetiredPool && sr1C0ReadNativePool(source, &manager, &pool) &&
        manager == sr1C0RetiredManager && pool == sr1C0RetiredPool;
    const bool inFreeList = reset && samePool && sr1C0FindRetiredInFreeList(source, pool, item);
    const bool proved = inFreeList && sr1C0SameWeaponSnapshot(source, snapshot) &&
        sr1C0ReadNativePool(source, &managerAfter, &poolAfter) && managerAfter == manager && poolAfter == pool &&
        sr1C0ReadFreedLinks(source, item, &generationAfter, &parentAfter, &siblingAfter) &&
        !generationAfter && !parentAfter && !siblingAfter &&
        sr1C0ActorGeneration(source, input->actor, sr1C0Identity.actorId) &&
        sr1C0ReadContact(input->actor, input->epoch, now, &latest) && latest.sequence == contact->sequence &&
        latest.tick == contact->tick && latest.phase == contact->phase &&
        sr1C0ContactSections(&latest, input->callbacks[0]) &&
        sr1C0NativeActive(input->actor) && input->epoch == (uint64_t)InterlockedCompareExchange64(&sr1C0Epoch, 0, 0);
    if (proved || !sr1C0UnlinkRefusalLogged)
        logLine("C0_RETIRED_POOL step=%llu acquisition=%llu witness=%llu proved=%u read=%u generation=%u sameGeneration=%u parent=%u sibling=%u pool=%u free=%u ticket=%u",
            (unsigned long long)contact->sequence, (unsigned long long)sr1C0State.acquisitionStep,
            (unsigned long long)sr1C0State.attackWitnessStep, proved, read, generation,
            read && generation == sr1C0Identity.targetId, !!parent, !!sibling, samePool, inFreeList, sr1C0UnlinkTicketPublished);
    return proved;
}
