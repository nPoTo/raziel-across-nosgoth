// SPDX-License-Identifier: GPL-3.0-or-later
#include "zephon-limb-contact.h"
#include <stdio.h>

int main(void) {
    const uintptr_t base = (uintptr_t)0x180000000ull;
    const uintptr_t collision = base + ZEPHON_LIMB_COLLISION_RVA;
    const uintptr_t message = base + ZEPHON_LIMB_MESSAGE_RVA;
    for (uint32_t intro = 1300; intro <= 1303; ++intro) {
        if (!zephonLimbIdentity("walbosb_", -4744, intro, base, collision, message)) return 1;
    }
    if (zephonLimbIdentity("walboss_", -4744, 1300, base, collision, message) ||
        zephonLimbIdentity("walbosb_", -4745, 1300, base, collision, message) ||
        zephonLimbIdentity("walbosb_", -4744, 1299, base, collision, message) ||
        zephonLimbIdentity("walbosb_", -4744, 1304, base, collision, message) ||
        zephonLimbIdentity("walbosb_", -4744, 1300, base, base + 0x990c0, message) ||
        zephonLimbIdentity("walbosb_", -4744, 1300, base, collision, base + 0x99760)) return 2;
    if (!zephonLimbVulnerable(1, 0, 6, 5888) || zephonLimbVulnerable(2, 0, 6, 5888) ||
        zephonLimbVulnerable(1, 1, 6, 5888) || zephonLimbVulnerable(1, 0, 13, 5888) ||
        zephonLimbVulnerable(1, 0, 8, 1792) || zephonLimbVulnerable(1, 0, 6, 0)) return 3;
    puts("Zephon limb eligibility: PASS");
    return 0;
}
