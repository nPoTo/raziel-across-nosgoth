// SPDX-License-Identifier: GPL-3.0-or-later
#pragma once
#include <stdbool.h>
#include <stdint.h>
#include <string.h>
#include "zephon-limb-policy.h"

static inline bool zephonLimbIdentity(const char name[9], int32_t stream, uint32_t intro,
    uintptr_t base, uintptr_t collision, uintptr_t message) {
    return base && stream == ZEPHON_LIMB_STREAM && intro >= ZEPHON_LIMB_FIRST_INTRO &&
        intro <= ZEPHON_LIMB_LAST_INTRO && collision == base + ZEPHON_LIMB_COLLISION_RVA &&
        message == base + ZEPHON_LIMB_MESSAGE_RVA && memcmp(name, ZEPHON_LIMB_NAME, 9) == 0;
}

static inline bool zephonLimbVulnerable(uint32_t realm, uint32_t airStrike, uint32_t state, int16_t hp) {
    return realm == ZEPHON_LIMB_REALM && airStrike == 0 && state == ZEPHON_LIMB_LIVE_STATE && hp > 0;
}
