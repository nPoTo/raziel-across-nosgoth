// SPDX-License-Identifier: GPL-3.0-or-later
#pragma once
#include "r31-policy.h"

static bool sr1C0ProveLiveDetach(const WeaponSource *source, const WeaponSnapshot *snapshot,
                                const C0RawContact *contact, const C0WeaponInput *input,
                                const C0LinkState *link, uint64_t now) {
    if (!sheet_c0LiveDetachR31_observed.allowSameGenerationAfterDetach || !sr1C0RetiredPool ||
        !c0WeaponOriginalUnlinkOwner(&sr1C0State) || !sr1C0Identity.targetId ||
        link->identity.actorId != sr1C0Identity.actorId ||
        link->identity.targetId != sr1C0Identity.targetId ||
        link->parent || (link->flags & (uint32_t)sheet_c0PickupLinkProof_physical.pendingFlag))
        return false;

    const C0PickupScope scope = {.actor=input->actor,.target=sr1C0State.weapon};
    const uint64_t siblingOffset = sheet_c0WeaponObservation_observation.siblingOffset;
    uintptr_t manager, pool, sibling;
    C0LinkState after;
    C0RawContact latest;
    const bool proved = sr1C0ReadNativePool(source, &manager, &pool) &&
        manager == sr1C0RetiredManager && pool == sr1C0RetiredPool &&
        weaponReadAt(source, scope.target, siblingOffset, &sibling, sizeof(sibling)) && !sibling &&
        sr1C0SameWeaponSnapshot(source, snapshot) &&
        c0LinkReadPair(source, &scope, &after) && c0LinkSameIdentity(&link->identity, &after.identity) &&
        !after.parent && !(after.flags & (uint32_t)sheet_c0PickupLinkProof_physical.pendingFlag) &&
        weaponReadAt(source, scope.target, siblingOffset, &sibling, sizeof(sibling)) && !sibling &&
        sr1C0ReadNativePool(source, &manager, &pool) && manager == sr1C0RetiredManager && pool == sr1C0RetiredPool &&
        sr1C0ReadContact(input->actor, input->epoch, now, &latest) && latest.sequence == contact->sequence &&
        latest.tick == contact->tick && latest.phase == contact->phase &&
        sr1C0ContactSections(&latest, input->callbacks[0]) &&
        sr1C0NativeActive(input->actor) &&
        input->epoch == (uint64_t)InterlockedCompareExchange64(&sr1C0Epoch, 0, 0);
    if (proved || !sr1C0UnlinkRefusalLogged)
        logLine("C0_LIVE_DETACH acquisition=%llu step=%llu generation=%u proved=%u",
            (unsigned long long)sr1C0State.acquisitionStep, (unsigned long long)contact->sequence,
            link->identity.targetId, proved);
    return proved;
}
