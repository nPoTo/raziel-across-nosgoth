// SPDX-License-Identifier: GPL-3.0-or-later
#pragma once
#include "c0-runtime-contact.h"
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wunused-function"
#include "../../c0-physical-weapon-read-r1/native/weapon-snapshot.h"
#include "../../c0-physical-weapon-admission-r1/native/weapon-descriptor.h"
#include "../../c0-native-pickup-receipt-r1/native/pickup-receipt.h"
#include "../../c0-native-pickup-live-r1/history/v5-live-confirmed-20261110/files/native/pickup-link-state.h"
#pragma clang diagnostic pop
#include "../../c0-weapon-unlink-r26/native/weapon-ownership-r19.h"
#ifdef C0_UNLINK_R26_FIXTURE
#include "../../c0-weapon-unlink-r26/native/unlink-receipt-fixture.h"
#else
#include "../../c0-weapon-unlink-r26/native/weapon-unlink-r26.h"
#endif

// The completed host input path is the sole writer of this owner.
static C0WeaponState sr1C0State;
static C0LinkIdentity sr1C0Identity;
static unsigned sr1C0ThrowGuardLogged;
static bool sr1C0UnlinkRefusalLogged;
static bool sr1C0UnlinkTicketPublished;
static uintptr_t sr1C0RetiredManager, sr1C0RetiredPool;
static bool sr1C0GenerationConflictLogged;

static void sr1C0RevokeUnlinkTicket(void) {
    if (!sr1C0UnlinkTicketPublished) return;
    sr1C0ClearUnlinkTicket();
    sr1C0UnlinkTicketPublished = false;
}

static void sr1C0ForgetAcquisition(const char *reason) {
    if (sr1C0RetiredPool)
        logLine("C0_POOL_SCOPE acquisition=%llu reason=%s",
            (unsigned long long)sr1C0State.acquisitionStep, reason);
    sr1C0RetiredManager = sr1C0RetiredPool = 0;
    sr1C0RevokeUnlinkTicket();
}

static void sr1C0Reset(void) {
    sr1C0ForgetAcquisition("reset");
    sr1C0State = (C0WeaponState){0};
    sr1C0Identity = (C0LinkIdentity){0};
    sr1C0ThrowGuardLogged = 0;
    sr1C0UnlinkRefusalLogged = false;
    InterlockedExchangePointer(&sr1C0Owner, NULL);
}

static bool sr1C0Read(void *unused, uintptr_t address, void *out, size_t count) {
    (void)unused;
    return worldRead(address, out, count);
}

static bool sr1C0ReadActorGeneration(const WeaponSource *source, uintptr_t actor, uint32_t *generation) {
    return weaponReadAt(source, actor, sheet_c0PickupLinkProof_physical.instanceIdOffset,
                        generation, sizeof(*generation));
}

static bool sr1C0ActorGeneration(const WeaponSource *source, uintptr_t actor, uint32_t expected) {
    uint32_t generation = 0;
    return expected && sr1C0ReadActorGeneration(source, actor, &generation) && generation == expected;
}

static bool sr1C0RuntimePending(const C0LinkState *link, uintptr_t actor) {
    const Sheet_c0PickupLinkProof *p = &sheet_c0PickupLinkProof_physical;
    return !link->parent && (link->flags & p->pendingFlag) && link->requestActor == actor &&
           link->segment == p->segment && link->duration == p->pendingDuration && link->elapsed <= link->duration;
}

static bool sr1C0CancelAttackWitness(void) {
    sr1C0State.attackWitnessStep = 0;
    return false;
}

static bool sr1C0ContactSections(const C0RawContact *contact, uint32_t callback) {
    return contact->callbacks[0] == callback && contact->callbacks[1] == callback && contact->callbacks[2] == callback;
}

static bool sr1C0CompletedAttack(const C0RawContact *contact, const C0WeaponInput *input) {
    const Sheet_c0AttackDetachR24 *policy = &sheet_c0AttackDetachR24_observed;
    const uint32_t attack = (uint32_t)policy->callbackRva;
    return contact->phase == (uint32_t)policy->contactPhase && c0WeaponSections(input, attack) &&
        sr1C0ContactSections(contact, attack);
}

static void sr1C0LogThrowGuard(uint64_t now, const C0RawContact *contact, const C0WeaponInput *input,
                               bool liveMatch, bool linkRead, bool linkIdentity, bool reciprocal) {
    // One record per stage per acquired lifetime. A torn first snapshot does
    // not prevent the later trustworthy reference and identity record.
    const unsigned stage = !input ? 1u : !liveMatch ? 2u : !linkIdentity ? 4u : 8u;
    if (sr1C0ThrowGuardLogged & stage) return;
    sr1C0ThrowGuardLogged |= stage;
    logLine("C0_THROW_GUARD tick=%llu step=%llu phase=%u snapshot=%u match=%u linkRead=%u linkIdentity=%u reciprocal=%u held=%u ownHeld=%u refPresent=%u refOwn=%u",
        (unsigned long long)now, (unsigned long long)contact->sequence, (unsigned)sr1C0State.phase,
        !!input, liveMatch, linkRead, linkIdentity, reciprocal, input && input->held,
        input && input->held == sr1C0State.weapon, input && input->throwReference,
        input && input->throwReference == sr1C0State.weapon);
}

static bool sr1C0SameWeaponSnapshot(const WeaponSource *source, const WeaponSnapshot *snapshot) {
    WeaponSnapshot after;
    return weaponPair(source, &after) && weaponSameActor(snapshot, &after) && !memcmp(snapshot, &after, sizeof(after));
}

#include "weapon-context-links-r27.h"
#include "weapon-retired-r28.h"
#include "r30-policy.h"
#include "weapon-live-detach-r31.h"

static void sr1C0HandleHeldLinkMismatch(const WeaponSource *source, uintptr_t actor, bool linkRead) {
    const uintptr_t item = sr1C0State.weapon;
    const uint32_t acquired = sr1C0Identity.targetId;
    uint32_t first = 0, second = 0;
    const bool readFirst = sr1C0ReadActorGeneration(source, item, &first);
    const bool readSecond = sr1C0ReadActorGeneration(source, item, &second);
    const bool replaced = sheet_c0GenerationR30_replacement.stableReplacementReads == 2 &&
        acquired && readFirst && readSecond && first && first == second && first != acquired &&
        sr1C0ActorGeneration(source, actor, sr1C0Identity.actorId);
    if (sr1C0RetiredPool && (replaced || !sr1C0GenerationConflictLogged)) {
        logLine("C0_POOL_GENERATION acquisition=%llu original=%u readFirst=%u first=%u readSecond=%u second=%u replaced=%u",
            (unsigned long long)sr1C0State.acquisitionStep, acquired, readFirst, first, readSecond, second, replaced);
        sr1C0GenerationConflictLogged = true;
    }
    if (replaced) sr1C0ForgetAcquisition("item_generation_changed");
    else if (linkRead) sr1C0RevokeUnlinkTicket();
}

static bool sr1C0ApplyOriginalUnlink(const WeaponSource *source, const WeaponSnapshot *snapshot,
                                    const C0RawContact *contact, const C0WeaponInput *input, uint64_t now) {
    if (!sr1C0UnlinkTicketPublished || !c0WeaponOriginalUnlinkOwner(&sr1C0State)) return false;
    const bool ordinary = contact->phase == (uint32_t)sheet_c0ReturnPolicyR19_detached_ground.contactPhase &&
        c0WeaponReturnSections(input) && sr1C0ContactSections(contact, input->callbacks[0]);
    if (!ordinary && !input->held) return false;
    C0UnlinkReceiptR26 receipt = {0};
    if (!sr1C0ReadUnlinkReceipt(input->epoch, input->actor, sr1C0State.weapon, sr1C0State.acquisitionStep,
                              now, &receipt) || !receipt.tick || !receipt.contactSequence ||
        receipt.tick > contact->tick || receipt.contactSequence >= contact->sequence) return false;
    if (input->held) {
        // A completed reattachment after the receipt defeats the old unlink.
        sr1C0RevokeUnlinkTicket();
        return false;
    }
    if (!c0WeaponSafeThrowReference(input, sr1C0State.weapon) ||
        !sr1C0SameWeaponSnapshot(source, snapshot) ||
        !sr1C0ActorGeneration(source, input->actor, sr1C0Identity.actorId) || !sr1C0NativeActive(input->actor) ||
        input->epoch != (uint64_t)InterlockedCompareExchange64(&sr1C0Epoch, 0, 0)) return false;
    logLine("C0_ORIGINAL_UNLINK tick=%llu step=%llu acquisition=%llu eventTick=%llu eventStep=%llu",
        (unsigned long long)now, (unsigned long long)contact->sequence,
        (unsigned long long)sr1C0State.acquisitionStep, (unsigned long long)receipt.tick,
        (unsigned long long)receipt.contactSequence);
    return true;
}

static bool sr1C0ActionStep(uint64_t epoch, uint64_t now, uintptr_t base, uintptr_t actor,
                            bool scope, bool eligibleEdge, bool existingNativeRoute, bool actionDown) {
    if (!epoch || !base || !actor || epoch != (uint64_t)InterlockedCompareExchange64(&sr1C0Epoch, 0, 0))
        return sr1C0CancelAttackWitness();
    if (sr1C0State.epoch && sr1C0State.epoch != epoch) sr1C0Reset();
    if (!scope || (sr1C0State.phase == C0_WEAPON_IDLE && !eligibleEdge) ||
        (sr1C0State.phase == C0_WEAPON_UNRESOLVED && !sr1C0State.acquiredUnlinkPending))
        return sr1C0CancelAttackWitness();

    const Sheet_c0WeaponObservation *p = &sheet_c0WeaponObservation_observation;
    const Sheet_c0WeaponOwnership *o = &sheet_c0WeaponOwnership_family0;
    WeaponSource source = {NULL, sr1C0Read, base, (uint32_t)p->imageBytes};
    C0RawContact contact;
    WeaponSnapshot snapshot;
    if (!sr1C0ReadContact(actor, epoch, now, &contact) || contact.sequence < sr1C0State.step)
        return sr1C0CancelAttackWitness();
    if (contact.sequence == sr1C0State.step) return false;
    const C0WeaponPhase before = sr1C0State.phase;
    const uint32_t throwCallback = (uint32_t)o->throwCallbackRva;
    const bool throwContact = (before == C0_WEAPON_HELD || before == C0_WEAPON_THROW) &&
        sr1C0ContactSections(&contact, throwCallback);
    if (!weaponPair(&source, &snapshot) || snapshot.actor != actor || snapshot.realm != p->materialRealm) {
        if (throwContact) sr1C0LogThrowGuard(now, &contact, NULL, false, false, false, false);
        return sr1C0CancelAttackWitness();
    }

    C0WeaponInput input = {
        .epoch=epoch,.step=contact.sequence,.actor=actor,.candidate=snapshot.candidate,
        .held=snapshot.effective,.throwReference=snapshot.throwRef,.pickupSense=snapshot.pickupGate,
        .heldQueryRva=snapshot.query ? (uint32_t)(snapshot.query - base) : 0,
        .heldSegment=snapshot.segment,.coherent=true,.inputNeutral=!actionDown
    };
    for (unsigned i=0;i<3;++i) input.callbacks[i]=(uint32_t)(snapshot.callback[i]-base);

    if (sr1C0State.phase == C0_WEAPON_IDLE) {
        WeaponDescriptor descriptor;
        C0LinkState link;
        const C0PickupScope candidate = {.actor=actor,.target=snapshot.candidate};
        if (existingNativeRoute || !contact.phase || !weaponImageMatches(&source) ||
            !weaponDescriptorPair(&source, &snapshot, &descriptor) || !descriptor.requestEligible ||
            descriptor.family != o->family || descriptor.marker != o->marker ||
            !c0LinkReadPair(&source, &candidate, &link) || !c0LinkFresh(&link)) return false;
        input.requestEdge = true;
        input.requestEligible = true;
        input.descriptorFamily = descriptor.family;
        input.descriptorMarker = descriptor.marker;
        const C0WeaponDecision decision = c0WeaponAdvance(&sr1C0State, &input);
        if (decision.forwardPress) {
            sr1C0Identity = link.identity;
            sr1C0ThrowGuardLogged = 0;
            sr1C0UnlinkRefusalLogged = false;
            InterlockedExchangePointer(&sr1C0Owner, (PVOID)actor);
            logLine("C0_WEAPON phase=requested step=%llu", (unsigned long long)contact.sequence);
        }
        return decision.forwardPress;
    }

    uint32_t actorGeneration = 0;
    const bool sameActor = sr1C0State.actor == actor;
    const bool generationRead = sameActor && sr1C0ReadActorGeneration(&source, actor, &actorGeneration);
    if (!generationRead || !actorGeneration || actorGeneration != sr1C0Identity.actorId) {
        if (!sameActor || (generationRead && actorGeneration && sr1C0ActorGeneration(&source, actor, actorGeneration)))
            sr1C0ForgetAcquisition("actor_changed");
        if (throwContact) sr1C0LogThrowGuard(now, &contact, &input, c0WeaponSections(&input, throwCallback), false, false, false);
        return sr1C0CancelAttackWitness();
    }
    const bool safeReference = c0WeaponSafeThrowReference(&input, sr1C0State.weapon);
    if (input.held && input.held != sr1C0State.weapon) sr1C0ForgetAcquisition("foreign_held");
    else if (!safeReference) sr1C0ForgetAcquisition("foreign_reference");
    if (before == C0_WEAPON_UNRESOLVED && (input.held || !safeReference)) {
        sr1C0State.acquiredUnlinkPending = false;
        sr1C0ForgetAcquisition("unresolved_conflict");
        return sr1C0CancelAttackWitness();
    }
    input.originalUnlinkReceipt = sr1C0ApplyOriginalUnlink(&source, &snapshot, &contact, &input, now);
    if (before != C0_WEAPON_DETACHED && !input.originalUnlinkReceipt) {
        const C0PickupScope owned = {.actor=actor,.target=sr1C0State.weapon};
        const C0LinkTicket ticket = {.scope=owned,.identity=sr1C0Identity};
        C0LinkState link;
        const bool linkRead = c0LinkReadPair(&source, &owned, &link);
        const bool linkIdentity = linkRead && c0LinkSameIdentity(&sr1C0Identity, &link.identity);
        const bool ownHeld = input.held == owned.target;
        const bool reciprocal = ownHeld && linkIdentity && c0LinkReciprocal(&ticket, &snapshot) && link.parent == actor;
        if (throwContact)
            sr1C0LogThrowGuard(now, &contact, &input, c0WeaponSections(&input, throwCallback), linkRead, linkIdentity, reciprocal);

        if ((before == C0_WEAPON_HELD || before == C0_WEAPON_UNRESOLVED) && !input.held &&
            contact.phase == (uint32_t)sheet_c0OrdinaryUnlinkR25_observed.contactPhase && c0WeaponReturnSections(&input)) {
            const bool callbacksMatch = sr1C0ContactSections(&contact, input.callbacks[0]);
            const bool parentNull = linkRead && !link.parent;
            const bool pending = linkRead && (link.flags & (uint32_t)sheet_c0PickupLinkProof_physical.pendingFlag);
            const bool bracket = callbacksMatch && linkIdentity && parentNull && !pending && safeReference &&
                sr1C0SameWeaponSnapshot(&source, &snapshot);
            input.pinnedOrdinaryUnlink = bracket && sr1C0ActorGeneration(&source, actor, sr1C0Identity.actorId) &&
                sr1C0NativeActive(actor) && epoch == (uint64_t)InterlockedCompareExchange64(&sr1C0Epoch, 0, 0);
            if (!linkIdentity && !input.pinnedOrdinaryUnlink && callbacksMatch && safeReference)
                input.pinnedOrdinaryUnlink = sr1C0ProveContextUnlink(&source, &snapshot, &contact, &input, now);
            if (!input.pinnedOrdinaryUnlink && callbacksMatch && safeReference)
                input.pinnedOrdinaryUnlink = sr1C0ProveRetiredItem(&source, &snapshot, &contact, &input, now);
            if (!input.pinnedOrdinaryUnlink && linkRead && callbacksMatch && safeReference)
                input.pinnedOrdinaryUnlink = sr1C0ProveLiveDetach(&source, &snapshot, &contact, &input, &link, now);
            if (input.pinnedOrdinaryUnlink || !sr1C0UnlinkRefusalLogged) {
                logLine("C0_ORDINARY_UNLINK tick=%llu step=%llu phase=%u proved=%u match=%u linkRead=%u linkIdentity=%u parentNull=%u pending=%u bracket=%u refPresent=%u refOwn=%u",
                    (unsigned long long)now, (unsigned long long)contact.sequence, (unsigned)before,
                    input.pinnedOrdinaryUnlink, callbacksMatch, linkRead, linkIdentity, parentNull, pending, bracket,
                    !!input.throwReference, input.throwReference == owned.target);
                if (!input.pinnedOrdinaryUnlink) sr1C0UnlinkRefusalLogged = true;
            }
        }

        const bool completedAttack = before == C0_WEAPON_HELD && sr1C0CompletedAttack(&contact, &input);
        input.completedNativeAttack = completedAttack &&
            sr1C0NativeActive(actor) && epoch == (uint64_t)InterlockedCompareExchange64(&sr1C0Epoch, 0, 0);
        if (completedAttack && sr1C0State.attackWitnessStep && !input.held) {
            const bool parentNull = linkRead && !link.parent;
            const bool adjacent = contact.sequence - sr1C0State.attackWitnessStep == 1;
            input.pinnedAttackUnlink = input.completedNativeAttack && adjacent && linkIdentity && parentNull &&
                c0WeaponSafeThrowReference(&input, owned.target);
            logLine("C0_ATTACK_DETACH tick=%llu step=%llu witness=%llu proved=%u owner=%u adjacent=%u linkRead=%u linkIdentity=%u parentNull=%u refPresent=%u refOwn=%u",
                (unsigned long long)now, (unsigned long long)contact.sequence,
                (unsigned long long)sr1C0State.attackWitnessStep, input.pinnedAttackUnlink,
                input.completedNativeAttack, adjacent, linkRead, linkIdentity, parentNull,
                !!input.throwReference, input.throwReference == owned.target);
        }
        if (!linkIdentity && !input.pinnedOrdinaryUnlink) {
            if (ownHeld && (sr1C0RetiredPool || sr1C0UnlinkTicketPublished))
                sr1C0HandleHeldLinkMismatch(&source, actor, linkRead);
            return sr1C0CancelAttackWitness();
        }
        if (before == C0_WEAPON_REQUESTED && sr1C0RuntimePending(&link, actor))
            input.pickupForRequestStep = sr1C0State.boundaryStep;
        if (ownHeld && !reciprocal) return sr1C0CancelAttackWitness();
        if (before == C0_WEAPON_HELD && ownHeld &&
            c0WeaponSections(&input, throwCallback) && !input.throwReference)
            return sr1C0CancelAttackWitness();
    } else if (before == C0_WEAPON_DETACHED && contact.phase == sheet_c0ReturnPolicyR19_detached_ground.contactPhase &&
               input.inputNeutral && c0WeaponReturnSections(&input)) {
        bool same = true;
        for (unsigned i=0;i<3;++i) same = same && contact.callbacks[i] == input.callbacks[i];
        Sr1NativeExitSample exit = {0};
        WeaponSnapshot after;
        if (same && sr1NativeExitRead(NULL, srRepeatRead, actor, &exit) && !sr1NativeExitBlending(&exit) &&
            weaponPair(&source, &after) && weaponSameActor(&snapshot, &after) &&
            !memcmp(&snapshot, &after, sizeof(snapshot)) &&
            sr1C0ActorGeneration(&source, actor, sr1C0Identity.actorId)) {
            input.returnComplete = true;
            input.returnForDetachStep = sr1C0State.boundaryStep;
        }
    }
    const C0WeaponDecision decision = c0WeaponAdvance(&sr1C0State, &input);
    if (before == C0_WEAPON_PICKUP && decision.phase == C0_WEAPON_HELD) {
        sr1C0GenerationConflictLogged = false;
        sr1C0PinRetiredPool(&source);
        logLine("C0_POOL_PIN acquisition=%llu valid=%u",
            (unsigned long long)sr1C0State.acquisitionStep, !!sr1C0RetiredPool);
        sr1C0PublishUnlinkTicket(epoch, actor, sr1C0State.weapon, sr1C0State.acquisitionStep, &sr1C0Identity);
        sr1C0UnlinkTicketPublished = true;
    }
    if (before != C0_WEAPON_DETACHED && decision.phase == C0_WEAPON_DETACHED)
        sr1C0ForgetAcquisition("detached");
    if (decision.phase != before)
        logLine("C0_WEAPON phase=%u step=%llu previous=%u neutral=%u held=%u ownHeld=%u throwRef=%u ownThrow=%u complete=%u cb=%x,%x,%x", (unsigned)decision.phase, (unsigned long long)contact.sequence,
            (unsigned)before, input.inputNeutral, !!input.held, input.held == sr1C0State.weapon,
            !!input.throwReference, input.throwReference == sr1C0State.weapon, input.returnComplete,
            input.callbacks[0], input.callbacks[1], input.callbacks[2]);
    if (decision.handedBack) {
        sr1C0ForgetAcquisition("returned");
        sr1C0Identity = (C0LinkIdentity){0};
        InterlockedExchangePointer(&sr1C0Owner, NULL);
    }
    return false;
}
