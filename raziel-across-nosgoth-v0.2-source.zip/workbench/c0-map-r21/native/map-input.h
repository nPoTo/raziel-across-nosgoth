// SPDX-License-Identifier: GPL-3.0-or-later
#pragma once
#include "r21-policy.h"

typedef struct {
    uint64_t session;
    uintptr_t actor;
    bool released;
} MapPressR21;

static inline bool mapPressR21(MapPressR21 *state, uint64_t session, uintptr_t actor, bool eligible, bool down) {
    if (!eligible || !session || !actor) {
        *state = (MapPressR21){0};
        return false;
    }
    if (state->session != session || state->actor != actor)
        *state = (MapPressR21){.session=session, .actor=actor};
    const bool pressed = down && state->released;
    state->released = !down;
    return pressed;
}

typedef struct {uint32_t keyboard, pad;} MapActionWordsR21;

static inline MapActionWordsR21 mapActionWordsR21(uint32_t keyboard, uint32_t pad, bool owner, bool request) {
    const Sheet_nativeMapR21 *policy = &sheet_nativeMapR21_owned;
    if (!owner) return (MapActionWordsR21){keyboard, pad};
    const uint32_t map = (uint32_t)policy->hostActionMask;
    const uint32_t mask = map | (uint32_t)policy->graphicsActionMask;
    return (MapActionWordsR21){(keyboard & ~mask) | (request ? map : 0), pad & ~mask};
}
