// SPDX-License-Identifier: GPL-3.0-or-later
#pragma once

typedef enum {
    WEAPON_DESCRIPTOR_UNKNOWN = 0,
    WEAPON_DESCRIPTOR_NO_CANDIDATE,
    WEAPON_DESCRIPTOR_OTHER_CALLBACK,
    WEAPON_DESCRIPTOR_QUERY_ZERO,
    WEAPON_DESCRIPTOR_QUERY_POSITIVE
} WeaponDescriptorStatus;

typedef struct {
    WeaponDescriptorStatus status;
    uint16_t family, marker;
    uint32_t queryValue;
    bool descriptorPresent, exclusionByteSet, exclusionInstanceSet;
    bool actorDisabled, controlDisabled, requestEligible;
} WeaponDescriptor;

typedef struct {
    WeaponDescriptor descriptor;
    uintptr_t callback, data;
    uint32_t actorFlags, controlFlags, instanceFlags;
    uint8_t exclusionByte;
} WeaponDescriptorRead;

static bool weaponDescriptorPolicy(void) {
    const Sheet_c0WeaponDescriptor *p = &sheet_c0WeaponDescriptor_supported;
    return p->callbackRva == 0xc0920 && p->dataOffset == 0x40 && p->flagsOffset == 0x24 &&
           p->familyOffset == 2 && p->markerOffset == 4 && p->exclusionByteOffset == 8 &&
           p->marker == 0xb00b && p->exclusionFamily == 6 && p->exclusionByteMask == 1 &&
           p->exclusionInstanceMask == 0x800 && p->queryValue == 0x20 &&
           p->pickupSenseMask == 0x80 && p->higherPriorityMask == 0x681f &&
           p->idleCallbackRva == 0xf2180 && p->disabledActorMask == 0x100 &&
           p->controlFlagsRva == 0x2a88568 && p->disabledControlMask == 0x800000;
}

static bool weaponDescriptorImageMatches(const WeaponSource *source) {
    if (!source || !source->read || !weaponDescriptorPolicy() ||
        !weaponPointer(source->base) || source->imageBytes != sheet_c0WeaponObservation_observation.imageBytes ||
        !sheet_c0WeaponDescriptorAnchor_count) return false;
    for (size_t i = 0; i < sheet_c0WeaponDescriptorAnchor_count; ++i) {
        const Sheet_c0WeaponDescriptorAnchor *anchor = sheet_c0WeaponDescriptorAnchor_rows[i];
        unsigned char bytes[64];
        const size_t length = wcslen(anchor->hex);
        if (!length || length % 2 || length / 2 > sizeof(bytes) ||
            !weaponImageRead(source, anchor->rva, bytes, length / 2)) return false;
        for (size_t j = 0; j < length / 2; ++j) {
            const int high = weaponHex(anchor->hex[2 * j]), low = weaponHex(anchor->hex[2 * j + 1]);
            if (high < 0 || low < 0 || bytes[j] != (high << 4 | low)) return false;
        }
    }
    return true;
}

static bool weaponDescriptorOnce(const WeaponSource *source, const WeaponSnapshot *host,
                                 WeaponDescriptorRead *sample) {
    const Sheet_c0WeaponDescriptor *p = &sheet_c0WeaponDescriptor_supported;
    const Sheet_c0WeaponObservation *h = &sheet_c0WeaponObservation_observation;
    WeaponDescriptor *out = &sample->descriptor;
    memset(sample, 0, sizeof(*sample));
    if (!weaponReadAt(source, host->actor, p->flagsOffset, &sample->actorFlags, sizeof(sample->actorFlags)) ||
        !weaponImageRead(source, p->controlFlagsRva, &sample->controlFlags, sizeof(sample->controlFlags)) ||
        !weaponReadAt(source, host->candidate, h->queryOffset, &sample->callback, sizeof(sample->callback)) ||
        (sample->callback && !weaponCode(source, sample->callback))) return false;
    out->actorDisabled = (sample->actorFlags & (uint32_t)p->disabledActorMask) != 0;
    out->controlDisabled = (sample->controlFlags & (uint32_t)p->disabledControlMask) != 0;
    if (sample->callback != source->base + (uintptr_t)p->callbackRva) {
        out->status = WEAPON_DESCRIPTOR_OTHER_CALLBACK;
        return true;
    }
    if (!weaponReadAt(source, host->candidate, p->dataOffset, &sample->data, sizeof(sample->data))) return false;
    out->status = WEAPON_DESCRIPTOR_QUERY_ZERO;
    if (!sample->data) return true;
    out->descriptorPresent = true;
    if (!weaponReadAt(source, sample->data, p->markerOffset, &out->marker, sizeof(out->marker)) ||
        !weaponReadAt(source, sample->data, p->familyOffset, &out->family, sizeof(out->family))) return false;
    if (out->marker != p->marker) return true;
    if (out->family == p->exclusionFamily) {
        if (!weaponReadAt(source, sample->data, p->exclusionByteOffset, &sample->exclusionByte,
                          sizeof(sample->exclusionByte))) return false;
        out->exclusionByteSet = (sample->exclusionByte & (uint8_t)p->exclusionByteMask) != 0;
        if (out->exclusionByteSet) {
            if (!weaponReadAt(source, host->candidate, p->flagsOffset, &sample->instanceFlags,
                              sizeof(sample->instanceFlags))) return false;
            out->exclusionInstanceSet = (sample->instanceFlags & (uint32_t)p->exclusionInstanceMask) != 0;
            if (out->exclusionInstanceSet) return true;
        }
    }
    out->status = WEAPON_DESCRIPTOR_QUERY_POSITIVE;
    out->queryValue = (uint32_t)p->queryValue;
    return true;
}

// The supplied host sample must come from weaponPair for this source. A new
// matching host pair after the duplicate descriptor read closes the bracket.
static bool weaponDescriptorPair(const WeaponSource *source, const WeaponSnapshot *host,
                                 WeaponDescriptor *out) {
    const Sheet_c0WeaponDescriptor *p = &sheet_c0WeaponDescriptor_supported;
    const Sheet_c0WeaponObservation *h = &sheet_c0WeaponObservation_observation;
    if (!out) return false;
    memset(out, 0, sizeof(*out));
    if (!source || !source->read || !host || !weaponPointer(host->actor) || !weaponDescriptorPolicy()) return false;
    if (!host->candidate) {
        out->status = WEAPON_DESCRIPTOR_NO_CANDIDATE;
        return true;
    }
    if (!weaponPointer(host->candidate) || host->candidate == host->actor || host->candidate == host->reaver ||
        !(host->flags & (uint32_t)h->pickupMask) || !weaponDescriptorImageMatches(source)) return false;
    WeaponDescriptorRead first, second;
    WeaponSnapshot current;
    if (!weaponDescriptorOnce(source, host, &first) || !weaponDescriptorOnce(source, host, &second) ||
        memcmp(&first, &second, sizeof(first)) || !weaponPair(source, &current) ||
        memcmp(host, &current, sizeof(current))) return false;

    *out = first.descriptor;
    bool allIdle = true;
    for (unsigned i = 0; i < 3; ++i)
        allIdle &= current.callback[i] == source->base + (uintptr_t)p->idleCallbackRva;
    out->requestEligible = out->status == WEAPON_DESCRIPTOR_QUERY_POSITIVE && allIdle &&
                           current.realm == h->materialRealm && !current.effective &&
                           !(current.flags & (uint32_t)p->higherPriorityMask) &&
                           !(current.pickupGate & (uint32_t)p->pickupSenseMask) &&
                           !out->actorDisabled && !out->controlDisabled;
    return true;
}
