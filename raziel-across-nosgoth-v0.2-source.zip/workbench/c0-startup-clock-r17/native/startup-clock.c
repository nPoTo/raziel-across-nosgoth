// SPDX-License-Identifier: GPL-3.0-or-later
// Independent system clock only: no process access, mappings, input or writes.
#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <stdio.h>

int main(int argc,char **argv){
 (void)argv;if(argc!=1)return 2;
#ifdef STARTUP_CLOCK_TEST_BEFORE_MS
 Sleep(STARTUP_CLOCK_TEST_BEFORE_MS);
#endif
 LARGE_INTEGER frequency={0},before={0},after={0};
 const BOOL frequencyOk=QueryPerformanceFrequency(&frequency);
 const BOOL beforeOk=QueryPerformanceCounter(&before);
 const ULONGLONG tick=GetTickCount64();
 const BOOL afterOk=QueryPerformanceCounter(&after);
 const BOOL valid=frequencyOk&&beforeOk&&afterOk&&frequency.QuadPart>0&&before.QuadPart>0&&after.QuadPart>=before.QuadPart;
#ifdef STARTUP_CLOCK_TEST_AFTER_MS
 Sleep(STARTUP_CLOCK_TEST_AFTER_MS);
#endif
 printf("{\"version\":1,\"readOnly\":true,\"observerClock\":{\"tick\":%llu,\"qpcBefore\":\"%llu\",\"qpcAfter\":\"%llu\",\"qpcFrequency\":\"%llu\",\"valid\":%s}}\n",
  (unsigned long long)tick,(unsigned long long)before.QuadPart,(unsigned long long)after.QuadPart,
  (unsigned long long)frequency.QuadPart,valid?"true":"false");
 return valid?0:3;
}
