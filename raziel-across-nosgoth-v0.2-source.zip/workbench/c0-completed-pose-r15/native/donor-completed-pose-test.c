// SPDX-License-Identifier: GPL-3.0-or-later
#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include <stdint.h>
#include <string.h>
#include <math.h>
#include "MinHook.h"
#include "exploration-sheets.h"
#include "bridge-process-identity.h"
#include "bridge-protocol.h"
static volatile LONG64 lifetimeTick;static unsigned char lifetimeIdentity[48];
static int lifetimeBudgetStatus(uint64_t n){return n>=1?1:0;}
#define PROBE_PATH(x) L"not-used-by-this-fixture" x
static bool hashBytes(const void *b,ULONG n,char out[65]){(void)b;(void)n;(void)out;return false;}
static void logLine(const char *format,...){(void)format;}
static unsigned char *game;static unsigned char actor[0x450],object[0x80],model[0x80],state[0x700],context[0xb00],resource[0x80],wrongObjectResource[0x80],nodes[144],segments[80];
static uintptr_t modelList[1];static char modelName[8]="raziel";static float palette[2][16],root[16];
static unsigned char weapon[0x450],weaponObject[0x80],weaponState[0x40],actorConfig[0x280];static char weaponName[8]="sreaver";
static bool range(uintptr_t a,SIZE_T n,const void *p,SIZE_T z){return a>=(uintptr_t)p&&a-(uintptr_t)p<=z&&n<=z-(a-(uintptr_t)p);}
static bool worldRead(uintptr_t a,void *v,SIZE_T n){
 bool ok=range(a,n,game,0x17c3000);
#define RANGE(x) ok=ok||range(a,n,x,sizeof(x))
 RANGE(actor);RANGE(object);RANGE(model);RANGE(state);RANGE(context);RANGE(resource);RANGE(wrongObjectResource);RANGE(nodes);RANGE(segments);RANGE(modelList);RANGE(modelName);RANGE(palette);RANGE(root);
 RANGE(weapon);RANGE(weaponObject);RANGE(weaponState);RANGE(actorConfig);RANGE(weaponName);
#undef RANGE
 if(ok)memcpy(v,(void *)a,n);return ok;
}
static SIZE_T fakeQuery(LPCVOID a,PMEMORY_BASIC_INFORMATION m,SIZE_T n){(void)a;(void)n;memset(m,0,sizeof(*m));m->State=MEM_COMMIT;m->Type=MEM_IMAGE;m->AllocationBase=game;m->Protect=PAGE_EXECUTE_READ;return sizeof(*m);}
#define VirtualQuery fakeQuery
#include "donor-completed-pose-runtime.h"
#undef VirtualQuery
MH_STATUS WINAPI MH_Initialize(void){return MH_OK;}
MH_STATUS WINAPI MH_CreateHook(LPVOID a,LPVOID b,LPVOID *c){(void)a;(void)b;(void)c;return MH_ERROR_UNSUPPORTED_FUNCTION;}
MH_STATUS WINAPI MH_RemoveHook(LPVOID a){(void)a;return MH_OK;}
MH_STATUS WINAPI MH_DisableHook(LPVOID a){(void)a;return MH_OK;}
MH_STATUS WINAPI MH_QueueEnableHook(LPVOID a){(void)a;return MH_OK;}
MH_STATUS WINAPI MH_ApplyQueued(void){return MH_OK;}
static unsigned failures,checks;static unsigned originals[6],scenario;static uintptr_t seenContext;
#define CHECK(x) do{checks++;if(!(x)){fprintf(stderr,"FAIL %u: %s\n",__LINE__,#x);failures++;}}while(0)
static void ptr(void *p,uintptr_t v){memcpy(p,&v,8);}static void u32(void *p,uint32_t v){memcpy(p,&v,4);}static void f32(void *p,float v){memcpy(p,&v,4);}
static uintptr_t __fastcall fakePrepare(uintptr_t a){CHECK(a==(uintptr_t)actor);originals[2]++;SetLastError(202);return 0x222;}
static uintptr_t __fastcall fakeMatrix(uintptr_t a){CHECK(a==(uintptr_t)actor);originals[3]++;palette[1][12]+=1;if(scenario==10){dcpExtraMatrixPassR13(a);CHECK(!dcpPendingReadyR13);palette[1][12]+=4;}SetLastError(203);return 0x333;}
static uintptr_t __fastcall fakeAltMatrix(uintptr_t a){CHECK(a==(uintptr_t)actor);originals[4]++;palette[1][12]+=2;SetLastError(204);return 0x444;}
static uintptr_t __fastcall fakeExtraMatrix(uintptr_t a){CHECK(a==(uintptr_t)actor);originals[5]++;palette[1][12]+=8;SetLastError(205);return 0x555;}
static uintptr_t __fastcall fakeAlternate(void){originals[0]++;dcpPreparePassR13((uintptr_t)actor);SetLastError(200);return 0xabc;}
static DWORD WINAPI foreignPass(void *p){(void)p;dcpAlternatePassR13();return 0;}
static uintptr_t __fastcall fakeGame(uintptr_t c){
 originals[1]++;seenContext=c;uint64_t beforeSerial=dcpSharedR13->snapshot.serial;
 if(scenario!=4)dcpPreparePassR13((uintptr_t)actor);
 if(scenario==1){dcpAlternateMatrixPassR13((uintptr_t)actor);dcpMatrixPassR13((uintptr_t)actor);}
 else if(scenario!=4&&scenario!=7)dcpMatrixPassR13((uintptr_t)actor);
 if(scenario==9){palette[1][12]=20;dcpExtraMatrixPassR13((uintptr_t)actor);}
 if(scenario==7||scenario==8||scenario==9){ptr(state+0x10,(uintptr_t)game+0x3000);f32(context+0x70,90);f32(actor+0x20,50);game[0x113ec00]=33;}
 if(scenario==2)dcpAlternatePassR13();
 if(scenario==3)u32(context+0x410,2);
 if(scenario==5){HANDLE t=CreateThread(NULL,0,foreignPass,NULL,0,NULL);CHECK(t!=NULL);if(t){CHECK(WaitForSingleObject(t,1000)==WAIT_OBJECT_0);CloseHandle(t);}}
 if(scenario==6)InterlockedExchange(&dcpActiveR13,0);
 if(scenario==11)dcpPendingR13.actorAddress^=8;
 CHECK(dcpSharedR13->snapshot.serial==beforeSerial);
 SetLastError(201);return 0xdef;
}
static void fixture(void){
 game=calloc(1,0x17c3000);CHECK(game!=NULL);dcpBaseR13=(uintptr_t)game;dcpImageSizeR13=0x17c3000;
 ptr(game+0xc5aa78,(uintptr_t)actor);ptr(game+0xc67120,(uintptr_t)context);
 ptr(actor+0x88,(uintptr_t)object);ptr(actor+0x1c0,(uintptr_t)model);ptr(actor+0x3f8,(uintptr_t)state);ptr(actor+0x60,(uintptr_t)palette);ptr(actor+0x70,(uintptr_t)root);
 ptr(object+0x50,(uintptr_t)modelName);ptr(object+0x68,(uintptr_t)wrongObjectResource);u32(object+0x70,2549292112u);u32(wrongObjectResource+4,118);ptr(model+0x68,(uintptr_t)resource);u32(model+0x70,121);u32(resource+4,121);object[0x20]=1;ptr(object+0x28,(uintptr_t)modelList);modelList[0]=(uintptr_t)model;
 u32(model+4,2);u32(model+8,0);ptr(model+0x10,(uintptr_t)segments);
 for(unsigned k=0;k<3;k++){actor[0x1d0+k*0x68+3]=2;ptr(state+k*0x250+0x10,(uintptr_t)game+0x1000+k*16);ptr(state+k*0x250+0x18,(uintptr_t)game+0x2000+k*16);}
 ptr(state,(uintptr_t)actor);u32(context+0x410,1);ptr(context,123);u32(context+0x400,3);
 for(unsigned k=0;k<2;k++){palette[k][0]=palette[k][5]=palette[k][10]=palette[k][15]=1;u32(segments+k*40+24,k?0:UINT32_MAX);f32(segments+k*40+12,1);}
 memcpy(root,palette[0],64);f32(actor+0x1f0,1);f32(game+0xc5abbc,1);f32(game+0xc5abc4,1);
 ptr(game+0x10aa650,(uintptr_t)nodes);actor[0x1ba]=1;nodes[74]=0x22;f32(nodes+72+0x28,3);f32(nodes+72+0x2c,4);f32(nodes+72+0x30,5);
 dcpOriginalAlternateR13=fakeAlternate;dcpOriginalGameR13=fakeGame;dcpOriginalPrepareR13=fakePrepare;dcpOriginalMatrixR13=fakeMatrix;dcpOriginalAltMatrixR13=fakeAltMatrix;dcpOriginalExtraMatrixR13=fakeExtraMatrix;
 dcpSharedR13=calloc(1,sizeof(*dcpSharedR13));CHECK(dcpSharedR13!=NULL);dcpBirthR13=123;dcpFrequencyR13=10000000;dcpEpochR13=GetTickCount64();lifetimeTick=dcpEpochR13;dcpActiveR13=1;
}
int main(void){
 (void)&donorCompletedPoseTick;(void)&donorCompletedPoseInstall;
 fixture();DonorCompletedPoseSnapshotR13 s,previous;SetLastError(19);
 CHECK(dcpGamePassR13(0x1234)==0xdef&&seenContext==0x1234&&GetLastError()==201);
 CHECK(donorCompletedPoseCopyR13(dcpSharedR13,&s)&&s.valid&&s.reason==0&&s.prepareCalls==1&&s.matrixBuilds==1&&s.alternateBuilds==0&&s.realm==1&&s.matrices[1][12]==1);
 CHECK(s.primary[0]==0x1000&&s.secondary[0]==0x2000&&s.motionValid&&s.timeValid&&s.motionVector[1]==4&&s.reaver.valid&&!s.reaver.present);
 CHECK(donorCompletedPoseValidR13(&s,GetCurrentProcessId(),123,GetTickCount64()));CHECK(!donorCompletedPoseValidR13(&s,GetCurrentProcessId(),124,GetTickCount64()));CHECK(!donorCompletedPoseValidR13(&s,GetCurrentProcessId(),123,s.tickMs+151));
 CHECK(s.version==2&&s.actorAddress==(uint64_t)(uintptr_t)actor&&s.objectAddress==(uint64_t)(uintptr_t)object&&s.modelAddress==(uint64_t)(uintptr_t)model);
 CHECK(s.actorToken==1&&s.modelToken==2&&s.actorAddress!=s.actorToken&&s.modelAddress!=s.modelToken&&s.objectAddress!=s.modelAddress);
 previous=s;previous.version=1;CHECK(!donorCompletedPoseValidR13(&previous,GetCurrentProcessId(),123,GetTickCount64()));
 previous=s;previous.actorAddress=0;CHECK(!donorCompletedPoseValidR13(&previous,GetCurrentProcessId(),123,GetTickCount64()));
 previous=s;previous.objectAddress=0;CHECK(!donorCompletedPoseValidR13(&previous,GetCurrentProcessId(),123,GetTickCount64()));
 previous=s;previous.modelAddress=0;CHECK(!donorCompletedPoseValidR13(&previous,GetCurrentProcessId(),123,GetTickCount64()));
 previous=s;previous.actorAddress++;CHECK(!donorCompletedPoseValidR13(&previous,GetCurrentProcessId(),123,GetTickCount64()));
 previous=s;previous.matrixBuilds=previous.alternateBuilds=previous.extraBuilds=0;CHECK(!donorCompletedPoseValidR13(&previous,GetCurrentProcessId(),123,GetTickCount64()));
 ptr(context+0x3f8,(uintptr_t)weapon);context[0xaea]=1;ptr(weapon+0x88,(uintptr_t)weaponObject);ptr(weaponObject+0x50,(uintptr_t)weaponName);ptr(weapon+0x3f8,(uintptr_t)weaponState);ptr(actor+0x310,(uintptr_t)actorConfig);u32(actorConfig+0x254,54);ptr(weapon+0xb8,(uintptr_t)actor);weapon[0xc0]=54;u32(weapon+0xa8,128);u32(weapon+0x418,7);weaponState[6]=2;weaponState[7]=3;weaponState[8]=1;f32(weapon+0x428,0.25f);f32(weapon+0x42c,0.75f);
 previous=s;scenario=1;CHECK(dcpGamePassR13(9)==0xdef);CHECK(donorCompletedPoseCopyR13(dcpSharedR13,&s)&&s.valid&&s.serial==previous.serial+1&&s.generation==previous.generation&&s.alternateBuilds==1&&s.matrixBuilds==1&&s.matrices[1][12]==4);CHECK(previous.matrices[1][12]==1);
 CHECK(s.reaver.present&&s.reaver.nameMatches&&s.reaver.enabled&&s.reaver.attachedToActor&&s.reaver.attachedBone==54&&s.reaver.configuredHand==54&&s.reaver.flags==128&&s.reaver.partMask==7&&s.reaver.drawState==2&&s.reaver.coilState==3&&s.reaver.fadeCurrent==0.25f&&s.reaver.fadeTarget==0.75f);
 scenario=2;CHECK(dcpGamePassR13(9)==0xdef);CHECK(donorCompletedPoseCopyR13(dcpSharedR13,&s)&&!s.valid&&s.reason==103&&s.tickMs==0);
 scenario=0;dcpGamePassR13(9);CHECK(donorCompletedPoseCopyR13(dcpSharedR13,&s)&&s.valid&&s.generation>previous.generation&&s.actorToken==previous.actorToken&&s.modelToken==previous.modelToken);
 scenario=3;dcpGamePassR13(9);CHECK(donorCompletedPoseCopyR13(dcpSharedR13,&s)&&!s.valid&&s.reason==1);u32(context+0x410,1);
 scenario=4;dcpGamePassR13(9);CHECK(donorCompletedPoseCopyR13(dcpSharedR13,&s)&&!s.valid&&s.reason==106);
 scenario=5;dcpGamePassR13(9);CHECK(!donorCompletedPoseCopyR13(dcpSharedR13,&s)&&dcpSharedR13->snapshot.reason==104);
 // Worker rearm is required after a foreign pass; callbacks never clear a
 // concurrent worker revocation. Simulate that already-authorized rearm here.
 dcpInvalidateR13(108);InterlockedExchange(&dcpSharedR13->revoked,0);
 scenario=0;dcpGamePassR13(9);CHECK(donorCompletedPoseCopyR13(dcpSharedR13,&s)&&s.valid);
 previous=s;scenario=7;dcpGamePassR13(9);CHECK(donorCompletedPoseCopyR13(dcpSharedR13,&s)&&!memcmp(&s,&previous,sizeof(s)));
 ptr(state+0x10,(uintptr_t)game+0x1000);f32(context+0x70,0);f32(actor+0x20,0);game[0x113ec00]=0;
 scenario=8;dcpGamePassR13(9);CHECK(donorCompletedPoseCopyR13(dcpSharedR13,&s)&&s.valid&&s.primary[0]==0x1000&&s.directions[0]==0&&s.position[0]==0&&s.buttonSlots[0]==0&&s.serial==previous.serial+1);
 ptr(state+0x10,(uintptr_t)game+0x1000);f32(context+0x70,0);f32(actor+0x20,0);game[0x113ec00]=0;
 scenario=9;dcpGamePassR13(9);CHECK(donorCompletedPoseCopyR13(dcpSharedR13,&s)&&s.valid&&s.extraBuilds==1&&s.matrices[1][12]==28&&s.primary[0]==0x1000&&s.position[0]==0);
 uint64_t actorToken=s.actorToken,modelToken=s.modelToken;u32(context+0x410,2);scenario=0;dcpGamePassR13(9);CHECK(donorCompletedPoseCopyR13(dcpSharedR13,&s)&&s.valid&&s.realm==2&&s.actorToken==actorToken&&s.modelToken==modelToken);u32(context+0x410,1);
 scenario=10;float oldX=palette[1][12];dcpGamePassR13(9);CHECK(donorCompletedPoseCopyR13(dcpSharedR13,&s)&&s.valid&&s.extraBuilds==1&&s.matrixBuilds==1&&s.matrices[1][12]==oldX+13);
 previous=s;u32(model+0x70,122);u32(resource+4,122);scenario=0;dcpGamePassR13(9);CHECK(donorCompletedPoseCopyR13(dcpSharedR13,&s)&&s.valid&&s.actorToken!=actorToken&&s.modelToken!=modelToken);
 CHECK(s.generation>previous.generation&&s.actorAddress==previous.actorAddress&&s.objectAddress==previous.objectAddress&&s.modelAddress==previous.modelAddress);
 scenario=11;dcpGamePassR13(9);CHECK(donorCompletedPoseCopyR13(dcpSharedR13,&s)&&!s.valid&&s.reason==109&&s.actorAddress==0&&s.objectAddress==0&&s.modelAddress==0);
 scenario=0;dcpGamePassR13(9);CHECK(donorCompletedPoseCopyR13(dcpSharedR13,&s)&&s.valid&&s.actorAddress==(uint64_t)(uintptr_t)actor);
 DonorCompletedIdentityR13 identity;CHECK(dcpIdentityR13(NULL,dcpReadR13,dcpBaseR13,&identity));palette[1][0]=NAN;CHECK(dcpCaptureR13(NULL,dcpReadR13,dcpCodeR13,dcpBaseR13,dcpImageSizeR13,&identity,&s)==6);palette[1][0]=1;
 u32(model+4,129);CHECK(dcpCaptureR13(NULL,dcpReadR13,dcpCodeR13,dcpBaseR13,dcpImageSizeR13,&identity,&s)==4);u32(model+4,2);
 ptr(state,0);CHECK(!dcpIdentityR13(NULL,dcpReadR13,dcpBaseR13,&identity));ptr(state,(uintptr_t)actor);
 // Object decoy can even match itself; a mismatched MODEL generation must
 // still fail. These independent addresses reproduce the measured R13 bug.
 u32(object+0x70,118);u32(model+0x70,123);CHECK(!dcpIdentityR13(NULL,dcpReadR13,dcpBaseR13,&identity));scenario=0;dcpGamePassR13(9);CHECK(!dcpSharedR13->snapshot.valid&&dcpSharedR13->snapshot.reason==101);
 u32(model+0x70,122);ptr(model+0x68,0);CHECK(!dcpIdentityR13(NULL,dcpReadR13,dcpBaseR13,&identity));ptr(model+0x68,1);CHECK(!dcpIdentityR13(NULL,dcpReadR13,dcpBaseR13,&identity));ptr(model+0x68,(uintptr_t)resource);
 scenario=0;dcpGamePassR13(9);CHECK(donorCompletedPoseCopyR13(dcpSharedR13,&s)&&s.valid);actorToken=s.actorToken;modelToken=s.modelToken;u32(object+0x70,2549292112u);dcpGamePassR13(9);CHECK(donorCompletedPoseCopyR13(dcpSharedR13,&s)&&s.valid&&s.actorToken==actorToken&&s.modelToken==modelToken);
 scenario=6;dcpGamePassR13(9);CHECK(!dcpSharedR13->snapshot.valid&&dcpSharedR13->snapshot.reason==105);unsigned called=originals[1];dcpGamePassR13(9);CHECK(originals[1]==called+1);
 dcpActiveR13=1;scenario=0;dcpGamePassR13(9);dcpSharedR13->sequence|=1;CHECK(!donorCompletedPoseCopyR13(dcpSharedR13,&s));dcpSharedR13->sequence++;
 HANDLE h=CreateFileMappingW(INVALID_HANDLE_VALUE,NULL,PAGE_READWRITE,0,sizeof(*dcpSharedR13),NULL);CHECK(h!=NULL);DonorCompletedPoseSharedR13 *w=h?MapViewOfFile(h,FILE_MAP_WRITE,0,0,sizeof(*w)):NULL;const DonorCompletedPoseSharedR13 *r=h?MapViewOfFile(h,FILE_MAP_READ,0,0,sizeof(*r)):NULL;CHECK(w&&r);if(w&&r){memcpy(w,dcpSharedR13,sizeof(*w));CHECK(donorCompletedPoseCopyR13(r,&s));}if(w)UnmapViewOfFile(w);if(r)UnmapViewOfFile(r);if(h)CloseHandle(h);
 donorCompletedPoseStop();CHECK(dcpSharedR13->revoked&&!dcpActiveR13);
 printf("{\"checks\":%u,\"failures\":%u,\"snapshotBytes\":%zu,\"sharedBytes\":%zu,\"originals\":[%u,%u,%u,%u,%u,%u]}\n",checks,failures,sizeof(s),sizeof(*dcpSharedR13),originals[0],originals[1],originals[2],originals[3],originals[4],originals[5]);free(dcpSharedR13);free(game);return failures?1:0;
}
