// SPDX-License-Identifier: GPL-3.0-or-later
#pragma once
#include "ordinary-presentation-sheets.h"
#include "ordinary-presentation-wire.h"

static inline bool ordinaryPresentationPolicy(void){
 const Sheet_ordinaryPresentation *p=&sheet_ordinaryPresentation_linked_ordinary;
 return p->packetFreshMs==150&&p->groundMode==2&&p->airMode==3&&p->bones==66&&p->matrixFloats==13&&
  p->receiptVersion==1&&p->receiptBytes==3656&&p->sharedBytes==3664&&p->fullCurrentContext&&
  p->preserveGroundTravel&&p->preserveNativeExit&&p->preserveHeldWeapon&&p->preserveLastYield&&
  p->originalTimestamps&&p->postCallValidation&&p->actualForwardedMatrices&&!p->gameWrites;
}
// The caller has already performed original coherent reads, native-exit latch,
// resource/C0 checks. Reuse complete predicates, never callback membership.
// This is presentation permission only. The ground driver uses strict kind2.
static inline bool ordinaryPresentationContext(unsigned mode,const Sr1RetargetContext *c){
 if(!ordinaryPresentationPolicy()||(mode!=2&&mode!=3))return false;
 bool ground=sr1RetargetContextAllowed(c);
#ifdef SR1_NATIVE_JUMP_POSE
 return ground||sr1RetargetJumpContextAllowed(c);
#else
 return ground;
#endif
}

#ifdef SR1_ORDINARY_PRESENTATION_R13
static PVOID ordinaryPresentationView;
static HANDLE ordinaryPresentationMapping;
static uint64_t ordinaryPresentationCreation,ordinaryPresentationQpcFrequency;
static volatile LONG ordinaryPresentationBusy;
static volatile LONG64 ordinaryPresentationSerial;
static void ordinaryPresentationInitialize(void){
 if(ordinaryPresentationView||!ordinaryPresentationPolicy())return;
 FILETIME creation,exit,kernel,user;LARGE_INTEGER frequency;
 if(!GetProcessTimes(GetCurrentProcess(),&creation,&exit,&kernel,&user)||!QueryPerformanceFrequency(&frequency)||frequency.QuadPart<=0)return;
 wchar_t name[96];ordinaryPresentationName(name,GetCurrentProcessId());
 HANDLE mapping=CreateFileMappingW(INVALID_HANDLE_VALUE,NULL,PAGE_READWRITE,0,sizeof(OrdinaryPresentationShared),name);
 if(!mapping)return;if(GetLastError()==ERROR_ALREADY_EXISTS){CloseHandle(mapping);return;}
 PVOID view=MapViewOfFile(mapping,FILE_MAP_READ|FILE_MAP_WRITE,0,0,sizeof(OrdinaryPresentationShared));
 if(!view){CloseHandle(mapping);return;}
 ordinaryPresentationCreation=((uint64_t)creation.dwHighDateTime<<32)|creation.dwLowDateTime;
 ordinaryPresentationQpcFrequency=(uint64_t)frequency.QuadPart;
 ordinaryPresentationMapping=mapping;InterlockedExchangePointer(&ordinaryPresentationView,view);
}
static void ordinaryPresentationPublish(OrdinaryPresentationReceipt *s){
 OrdinaryPresentationShared *view=InterlockedCompareExchangePointer(&ordinaryPresentationView,NULL,NULL);
 if(!view||InterlockedCompareExchange(&ordinaryPresentationBusy,1,0))return;
 s->magic=ORDINARY_PRESENTATION_MAGIC;s->version=1;s->bytes=sizeof(*s);s->hostPid=GetCurrentProcessId();
 s->hostCreation=ordinaryPresentationCreation;s->qpcFrequency=ordinaryPresentationQpcFrequency;
 s->serial=(uint64_t)InterlockedIncrement64(&ordinaryPresentationSerial);memcpy(s->policy,skeletonPolicyHash,32);
 if(!s->valid)memset(s->forwarded,0,sizeof(s->forwarded));
 ordinaryPresentationStore(view,s);InterlockedExchange(&ordinaryPresentationBusy,0);
}
static void ordinaryPresentationClear(void){
 OrdinaryPresentationShared *view=InterlockedCompareExchangePointer(&ordinaryPresentationView,NULL,NULL);
 if(view&&!InterlockedCompareExchange(&ordinaryPresentationBusy,1,0)){OrdinaryPresentationReceipt empty={0};ordinaryPresentationStore(view,&empty);InterlockedExchange(&ordinaryPresentationBusy,0);}
}
#endif
