// SPDX-License-Identifier: GPL-3.0-or-later
// Read-only local RAM mappings. Hex payloads are stdout IPC, never asset files.
#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <stdint.h>
#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <wchar.h>
#include "capture-cadence.h"
#include "donor-completed-pose-wire.h"
#include "ordinary-presentation-wire.h"
#include "completed-pose-transport-sheets.h"

static bool number(const wchar_t *s,uint64_t *value){
 if(!s||!*s||*s<L'0'||*s>L'9')return false;wchar_t *end=NULL;*value=_wcstoui64(s,&end,10);return *value&&end&&!*end;
}
static HANDLE process(DWORD pid,uint64_t birth,const wchar_t *name){
 HANDLE p=OpenProcess(PROCESS_QUERY_LIMITED_INFORMATION|SYNCHRONIZE,FALSE,pid);if(!p)return NULL;
 FILETIME c,e,k,u;wchar_t path[32768];DWORD n=32768;
 bool ok=GetProcessTimes(p,&c,&e,&k,&u)&&(((uint64_t)c.dwHighDateTime<<32)|c.dwLowDateTime)==birth&&QueryFullProcessImageNameW(p,0,path,&n);
 const wchar_t *tail=ok?wcsrchr(path,L'\\'):NULL;
 if(!ok||!tail||_wcsicmp(tail+1,name)){CloseHandle(p);return NULL;}return p;
}
static void *mapping(const wchar_t *name,HANDLE *handle,SIZE_T bytes){
 if(*handle)return NULL;*handle=OpenFileMappingW(FILE_MAP_READ,FALSE,name);if(!*handle)return NULL;
 void *view=MapViewOfFile(*handle,FILE_MAP_READ,0,0,bytes);if(!view){CloseHandle(*handle);*handle=NULL;}return view;
}
static void hex(const void *data,size_t bytes){
 static const char digits[]="0123456789abcdef";
 char encoded[2*(sizeof(DonorCompletedPoseSnapshotR13)+sizeof(OrdinaryPresentationReceipt))];
 if(bytes>sizeof(encoded)/2)return;
 const unsigned char *p=data;for(size_t i=0;i<bytes;i++){encoded[2*i]=digits[p[i]>>4];encoded[2*i+1]=digits[p[i]&15];}
 (void)fwrite(encoded,1,bytes*2,stdout);
}
static void layout(void){
 printf("{\"sourceBytes\":%zu,\"presentationBytes\":%zu,\"source\":{",sizeof(DonorCompletedPoseSnapshotR13),sizeof(OrdinaryPresentationReceipt));
 bool first=true;
#define FIELD(T,n) do{if(!first)putchar(',');first=false;printf("\"" #n "\":%zu",offsetof(T,n));}while(0)
#define S(n) FIELD(DonorCompletedPoseSnapshotR13,n)
 S(magic);S(version);S(bytes);S(valid);S(reason);S(donorPid);S(realm);S(gameMode);S(gameFlags);S(passRva);S(threadId);S(prepareCalls);S(matrixBuilds);S(alternateBuilds);S(baseCount);S(extraCount);S(matrixCount);S(extraBuilds);
 S(donorCreation);S(sessionEpoch);S(generation);S(serial);S(tickMs);S(qpc);S(qpcFrequency);S(actorToken);S(modelToken);S(sourceBuild);S(primary);S(secondary);S(animationRaw);S(position);S(previousPosition);S(actorRotation);S(directions);S(buttonSlots);S(stickAxes);
 S(motionValid);S(motionComplete);S(motionStable);S(motionVisited);S(motionIndex);S(motionFlags);S(timeValid);S(timeSelectedRva);S(motionVector);S(timeFactor);S(animationClock);S(actorFactor);S(frameFactor);S(physicsMode);S(actionKind);S(scalar);S(selectedReaver);S(reaver);S(rootMatrix);S(matrices);S(parents);S(bindLocalPositions);S(actorAddress);S(objectAddress);S(modelAddress);
#undef S
 printf("},\"presentation\":{");first=true;
#define P(n) FIELD(OrdinaryPresentationReceipt,n)
 P(magic);P(version);P(bytes);P(valid);P(hostPid);P(sourcePid);P(writerPid);P(threadId);P(path);P(requestedMode);P(refusal);P(contextMask);P(hostCreation);P(epoch);P(serial);P(tick);P(hostTick);P(sourceTick);P(packetSequence);P(drawSerial);P(qpcBefore);P(qpcAfter);P(qpcFrequency);P(actor);P(object);P(model);P(callbacks);P(hostMode);P(hostFlags);P(verticalVelocity);P(proof);P(policy);P(forwarded);
#undef P
#undef FIELD
 printf("}}\n");
}
int wmain(int argc,wchar_t **argv){
 if(argc==2&&!wcscmp(argv[1],L"--layout")){layout();return 0;}
 uint64_t donor=0,donorBirth=0,host=0,hostBirth=0;
 if(argc!=5||!number(argv[1],&donor)||donor>UINT32_MAX||!number(argv[2],&donorBirth)||!number(argv[3],&host)||host>UINT32_MAX||!number(argv[4],&hostBirth))return 2;
 HANDLE dp=process((DWORD)donor,donorBirth,L"defiance.exe"),hp=process((DWORD)host,hostBirth,L"SRX.exe");
 if(!dp||!hp){if(dp)CloseHandle(dp);if(hp)CloseHandle(hp);return 3;}
 HANDLE dm=NULL,hm=NULL;const DonorCompletedPoseSharedR13 *dv=NULL;const OrdinaryPresentationShared *hv=NULL;
 wchar_t dn[96],hn[96];donorCompletedPoseNameR13(dn,(DWORD)donor);ordinaryPresentationName(hn,(DWORD)host);
 LARGE_INTEGER frequency,origin,counter;bool ok=QueryPerformanceFrequency(&frequency)&&QueryPerformanceCounter(&origin);uint64_t sequence=0;
 const Sheet_completedPoseTransport *policy=&sheet_completedPoseTransport_native_completed;
 if(!ok||policy->captureHz!=120||policy->maxPoseAgeMs!=150||policy->readAttempts!=3||!policy->requireCurrentGeneration||policy->renewCaptureTime)return 4;
 HANDLE timer=CreateWaitableTimerExW(NULL,NULL,2,TIMER_ALL_ACCESS);if(!timer)timer=CreateWaitableTimerW(NULL,FALSE,NULL);
 if(!timer)return 4;
 printf("{\"type\":\"session\",\"pid\":%lu,\"processCreation\":\"%llu\",\"mode\":\"read-only\",\"sha256\":\"fc6a406ff7ac9b5eb7788dc7a65d335e1c1aad9236618112671975b71d2daddc\",\"captureHz\":120,\"completedNativeFrames\":true}\n",(DWORD)donor,(unsigned long long)donorBirth);fflush(stdout);
 while(WaitForSingleObject(dp,0)==WAIT_TIMEOUT&&WaitForSingleObject(hp,0)==WAIT_TIMEOUT){
  if(!dv)dv=mapping(dn,&dm,sizeof(*dv));if(!hv)hv=mapping(hn,&hm,sizeof(*hv));
  DonorCompletedPoseSnapshotR13 source={0};OrdinaryPresentationReceipt presentation={0};
  bool copied=dv&&donorCompletedPoseCopyR13(dv,&source);
  bool ack=hv&&ordinaryPresentationCopy(hv,&presentation)&&presentation.magic==ORDINARY_PRESENTATION_MAGIC&&presentation.version==1&&presentation.bytes==sizeof(presentation)&&presentation.hostPid==host&&presentation.hostCreation==hostBirth;
  if(!QueryPerformanceCounter(&counter)){ok=false;break;}
  // Receipt time follows both immutable copies. A freshly committed snapshot
  // cannot appear to come from the future merely because copying crossed a tick.
  uint64_t tick=GetTickCount64();
  bool accepted=copied&&donorCompletedPoseValidR13(&source,(DWORD)donor,donorBirth,tick);
  printf("{\"type\":\"sample\",\"sequence\":%llu,\"tickMs\":%llu,\"readQpc\":\"%llu\",\"valid\":%s,\"sourceHex\":\"",(unsigned long long)sequence++,(unsigned long long)tick,(unsigned long long)counter.QuadPart,accepted?"true":"false");
  if(copied)hex(&source,sizeof(source));printf("\",\"presentationHex\":\"");if(ack)hex(&presentation,sizeof(presentation));printf("\"}\n");
  if(fflush(stdout)||ferror(stdout)){ok=false;break;}
  if(!QueryPerformanceCounter(&counter)){ok=false;break;}
  uint64_t next=captureNextHz((uint64_t)origin.QuadPart,(uint64_t)counter.QuadPart,(uint64_t)frequency.QuadPart,(uint32_t)policy->captureHz);
  if(next>(uint64_t)counter.QuadPart){LARGE_INTEGER due;due.QuadPart=-(LONGLONG)((next-(uint64_t)counter.QuadPart)*10000000ULL/(uint64_t)frequency.QuadPart);if(due.QuadPart==0)due.QuadPart=-1;if(!SetWaitableTimer(timer,&due,0,NULL,NULL,FALSE)||WaitForSingleObject(timer,1000)!=WAIT_OBJECT_0){ok=false;break;}}
 }
 if(dv)UnmapViewOfFile(dv);if(hv)UnmapViewOfFile(hv);if(dm)CloseHandle(dm);if(hm)CloseHandle(hm);CloseHandle(timer);CloseHandle(dp);CloseHandle(hp);return ok?0:5;
}
