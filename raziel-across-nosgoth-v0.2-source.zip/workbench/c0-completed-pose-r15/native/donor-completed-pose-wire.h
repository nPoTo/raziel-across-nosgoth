// SPDX-License-Identifier: GPL-3.0-or-later
#pragma once
#include <windows.h>
#include <stdint.h>
#include <stdbool.h>
#include <stddef.h>
#include <string.h>
#include <math.h>
enum {DONOR_COMPLETED_POSE_MAGIC_R13=0x31435044,DONOR_COMPLETED_POSE_VERSION_R13=2,DONOR_COMPLETED_POSE_MAX_R13=128};
typedef struct {
 uint32_t valid,present,enabled,nameMatches,flags,partMask,skin,configuredHand;
 uint32_t attachedToActor,attachedBone,b4,b5,type,drawState,coilState,reserved;
 float value24,value28,fadeCurrent,fadeTarget;
} DonorCompletedReaverR13;
typedef struct {
 uint32_t magic,version,bytes,valid,reason,donorPid,realm,gameMode,gameFlags,passRva,threadId,prepareCalls,matrixBuilds,alternateBuilds,baseCount,extraCount,matrixCount,extraBuilds;
 uint64_t donorCreation,sessionEpoch,generation,serial,tickMs,qpc,qpcFrequency,actorToken,modelToken;
 unsigned char sourceBuild[32];
 uint32_t primary[3],secondary[3],animationRaw[3][5];
 float position[3],previousPosition[3],actorRotation[8],directions[3];
 int16_t buttonSlots[26],stickAxes[4];
 uint32_t motionValid,motionComplete,motionStable,motionVisited,motionIndex,motionFlags,timeValid,timeSelectedRva;
 float motionVector[3],timeFactor,animationClock,actorFactor,frameFactor;
 uint32_t physicsMode,actionKind;int32_t scalar;uint32_t selectedReaver;
 DonorCompletedReaverR13 reaver;
 float rootMatrix[16],matrices[128][16];
 int32_t parents[128];float bindLocalPositions[128][3];
 // ABI v2: authenticated process addresses are distinct from lifetime tokens.
 uint64_t actorAddress,objectAddress,modelAddress;
} DonorCompletedPoseSnapshotR13;
typedef struct {volatile LONG sequence,revoked;DonorCompletedPoseSnapshotR13 snapshot;} DonorCompletedPoseSharedR13;
_Static_assert(offsetof(DonorCompletedPoseSnapshotR13,donorCreation)==72,"Completed pose header ABI");
_Static_assert(offsetof(DonorCompletedPoseSharedR13,snapshot)==8,"Completed pose shared ABI");
_Static_assert(sizeof(DonorCompletedReaverR13)==80,"Completed Reaver ABI");
_Static_assert(offsetof(DonorCompletedPoseSnapshotR13,actorAddress)==10848,"Completed address ABI");
_Static_assert(sizeof(DonorCompletedPoseSnapshotR13)==10872,"Completed pose wire ABI");
_Static_assert(sizeof(DonorCompletedPoseSharedR13)==10880,"Completed pose mapping ABI");
static inline void donorCompletedPoseNameR13(wchar_t out[96],DWORD pid){_snwprintf(out,96,L"Local\\LOKCompletedPoseR13-%lu",pid);}
static inline bool donorCompletedPoseCopyR13(const DonorCompletedPoseSharedR13 *view,DonorCompletedPoseSnapshotR13 *out){
 if(!view||!out)return false;
 for(unsigned i=0;i<3;i++){LONG seq=view->sequence;if((seq&1)||view->revoked)continue;MemoryBarrier();memcpy(out,&view->snapshot,sizeof(*out));MemoryBarrier();if(seq==view->sequence&&!view->revoked)return true;}
 return false;
}
static inline void donorCompletedPoseStoreR13(DonorCompletedPoseSharedR13 *view,const DonorCompletedPoseSnapshotR13 *s){
 InterlockedIncrement(&view->sequence);MemoryBarrier();memcpy(&view->snapshot,s,sizeof(*s));MemoryBarrier();InterlockedIncrement(&view->sequence);
}
static inline bool donorCompletedPoseValidR13(const DonorCompletedPoseSnapshotR13 *s,DWORD pid,uint64_t birth,uint64_t now){
 if(!s||s->magic!=DONOR_COMPLETED_POSE_MAGIC_R13||s->version!=DONOR_COMPLETED_POSE_VERSION_R13||s->bytes!=sizeof(*s)||s->valid!=1||s->reason||s->donorPid!=pid||s->donorCreation!=birth||!s->sessionEpoch||!s->generation||!s->serial||!s->qpc||!s->qpcFrequency||!s->actorToken||!s->modelToken||!s->actorAddress||!s->objectAddress||!s->modelAddress||s->actorAddress%8||s->objectAddress%8||s->modelAddress%8||s->tickMs<s->sessionEpoch||s->tickMs>now||now-s->tickMs>150||s->realm<1||s->realm>2||!s->baseCount||s->baseCount>128||s->extraCount>128||s->matrixCount!=s->baseCount+s->extraCount||s->matrixCount>128||!s->prepareCalls||(!s->matrixBuilds&&!s->alternateBuilds&&!s->extraBuilds)||(s->passRva!=0x625b0&&s->passRva!=0x64ac0))return false;
 return true;
}
