// SPDX-License-Identifier: GPL-3.0-or-later
// Original skin/draw only; pinned per-thread argument4 scratch, no actor writes.
#include "host-rig-reader.h"
#include "sr1-native-pose-forward.h"
#include "sr1-skeleton-shared.h"
#include "sr1-retarget-gate.h"
#ifdef SR1_ORDINARY_PRESENTATION_R13
#if !defined(SR1_NATIVE_DRAW_RECEIPT) || !defined(SR1_NATIVE_EXIT_GUARD) || !defined(SR1_NATIVE_JUMP_POSE) || !defined(SR1_C0_PHYSICAL_WEAPON)
#error R13 ordinary presentation requires original draw, native-exit, air and C0 guards
#endif
#include "ordinary-presentation.h"
#endif
#ifdef SR1_JUMP_EXIT_BLEND
#include "sr1-jump-exit-blend.h"
static _Thread_local JumpExitBlend sr1JumpExit;
static volatile LONG sr1JumpExitRendered;
static _Thread_local unsigned sr1JumpTraceCount,sr1JumpTracePath=99,sr1JumpTraceCallback;
static _Thread_local bool sr1JumpTraceCapture;
#endif
#ifdef SR1_NATIVE_CROUCH_HOLD
#include "sr1-crouch-hold.h"
#endif
#include "skeleton-borrow-proof.h"
#ifdef SR1_NATIVE_EXIT_GUARD
#include "sr1-native-exit-reader.h"
#ifdef SR1_V38_HANDOFF_R2
#include "v38-landing-recovery.h"
#endif
static _Thread_local Sr1NativeExitLatch sr1ExitLatch;
static _Thread_local uintptr_t sr1ExitActor,sr1ExitObject,sr1ExitModel;
static volatile LONG sr1ExitHeld,sr1ExitReleased,sr1ExitReadRefused;
#endif
static Sr1NativePoseFn sr1SkeletonOriginal;static PVOID sr1SkeletonTarget,sr1SkeletonView;static HANDLE sr1SkeletonMapping;
static volatile LONG sr1SkeletonThread,sr1SkeletonCopies,sr1SkeletonAligned,sr1SkeletonRefused,sr1SkeletonFailed,sr1SkeletonDepthRefused;
static volatile LONG sr1SkeletonCandidates,sr1SkeletonForeign,sr1SkeletonScopeRejected,sr1SkeletonPacketRejected,sr1SkeletonIdentityRejected,sr1SkeletonThreadRejected,sr1SkeletonContextRejected,sr1SkeletonAdmissionRejected,sr1SkeletonRebaseRejected;
static volatile LONG sr1SkeletonMoving;static float sr1SkeletonLastRoot[13];static uintptr_t sr1SkeletonLastActor;static uint64_t sr1SkeletonLastRootTick;
static _Thread_local unsigned sr1SkeletonDepth;static _Thread_local float sr1SkeletonScratch[66][13];static SkeletonAdmission sr1SkeletonAdmission;static bool sr1SkeletonWasEnabled;
static bool sr1SkeletonRead(void *unused,uintptr_t p,void *out,SIZE_T n){(void)unused;return worldRead(p,out,n);}
#ifdef SR1_NATIVE_DRAW_RECEIPT
#include "host-draw-publisher.h"
#endif
#ifdef SR1_REAVER_HAND_RECEIPT
#include "reaver-host-hand-capture.h"
#endif
#ifdef SR1_C0_PHYSICAL_WEAPON
static bool sr1SkeletonNativeWeapon(uintptr_t actor){
 if(!sr1C0NativeActive(actor))return false;
#ifdef SR1_NATIVE_EXIT_GUARD
 sr1ExitLatch.nativeOwned=true;
#endif
#ifdef SR1_JUMP_EXIT_BLEND
 sr1JumpExit.ready=false;
#endif
 return true;
}
#endif
static bool sr1SkeletonContextRead(uintptr_t base,uintptr_t actor,unsigned kind,bool presentation){
#ifdef SR1_C0_PHYSICAL_WEAPON
 if(sr1SkeletonNativeWeapon(actor))return false;
#endif
 Sr1RetargetContext c={0};uintptr_t owner=0,again=0,cb[3];uint16_t modeAfter=0;uint32_t flagsAfter=0;int32_t velocityAfter=0;DWORD front=0;
 GetWindowThreadProcessId(GetForegroundWindow(),&front);c.foreground=front==GetCurrentProcessId();
 if(!worldRead(base+0x2a88588,&owner,8)||owner!=actor||!worldRead(base+0x2a89536,&c.mode,2)||!worldRead(base+0x2a8950c,&c.flags,4)||!worldRead(actor+0x2d4,&c.verticalVelocity,4))return false;
 for(unsigned i=0;i<3;i++){if(!worldRead(base+0x2a88598+i*0x228,cb+i,8)||cb[i]<base||cb[i]-base>UINT32_MAX)return false;c.callbacks[i]=(uint32_t)(cb[i]-base);}
 if(!worldRead(base+0x2a88588,&again,8)||again!=owner||!worldRead(base+0x2a89536,&modeAfter,2)||modeAfter!=c.mode||!worldRead(base+0x2a8950c,&flagsAfter,4)||flagsAfter!=c.flags||!worldRead(actor+0x2d4,&velocityAfter,4)||velocityAfter!=c.verticalVelocity)return false;
 for(unsigned i=0;i<3;i++){uintptr_t after=0;if(!worldRead(base+0x2a88598+i*0x228,&after,8)||after!=cb[i])return false;}
#ifdef SR1_NATIVE_CROUCH_HOLD
 if(!sr1CrouchHeld(NULL,sr1SkeletonRead,base,&c.crouchHeld))return false;
#endif
 c.identity=true;c.verticalVelocityKnown=true;
#ifdef SR1_NATIVE_EXIT_GUARD
 uintptr_t object=0,objectAfter=0,list=0,model=0,listAfter=0,modelAfter=0;Sr1NativeExitSample exitPose={0};
 if(!worldRead(actor+0x30,&object,8)||!object||!worldRead(object+0x10,&list,8)||!list||!worldRead(list,&model,8)||!model)return false;
 if(sr1ExitActor!=actor||sr1ExitObject!=object||sr1ExitModel!=model){sr1ExitActor=actor;sr1ExitObject=object;sr1ExitModel=model;sr1ExitLatch.nativeOwned=true;}
 bool exitKnown=sr1NativeExitRead(NULL,sr1SkeletonRead,actor,&exitPose);
#if defined(SR1_GENERAL_ALL_IN_RUNTIME) && defined(SR1_AIR_COMBAT_POSE)
 // Same six-clip rule as the external reader, including ordinary takeoff.
 // The landing-only override formerly rejected EVERY compression draw.
 c.ordinaryAirTransition=exitKnown&&sr1OrdinaryAirTransitions(&c,exitPose.animation);
#endif
#ifdef SR1_V38_HANDOFF_R2
#if defined(SR1_GENERAL_ALL_IN_RUNTIME) && defined(SR1_AIR_COMBAT_POSE)
 if(c.callbacks[0]==0xee600&&c.callbacks[1]==0xee600&&c.callbacks[2]==0xee600)
#endif
 c.ordinaryAirTransition=exitKnown&&v38LandingRecovery(&c,&exitPose);
#endif
#ifdef SR1_COMPLETED_GROUND_READ
 c.completedGround=SR1_COMPLETED_GROUND_READ(actor,&c);
#endif
 bool actionAllowed=sr1RetargetContextAllowed(&c);
#ifdef SR1_NATIVE_JUMP_POSE
 actionAllowed=actionAllowed||sr1RetargetJumpContextAllowed(&c);
#endif
 // Recheck ownership/action after the scalar exit read, not merely before it.
 if(!worldRead(base+0x2a88588,&again,8)||again!=owner||!worldRead(actor+0x30,&objectAfter,8)||objectAfter!=object)return false;
 if(!worldRead(object+0x10,&listAfter,8)||listAfter!=list||!worldRead(listAfter,&modelAfter,8)||modelAfter!=model)return false;
 if(!worldRead(base+0x2a89536,&modeAfter,2)||modeAfter!=c.mode||!worldRead(base+0x2a8950c,&flagsAfter,4)||flagsAfter!=c.flags||!worldRead(actor+0x2d4,&velocityAfter,4)||velocityAfter!=c.verticalVelocity)return false;
 for(unsigned i=0;i<3;i++){uintptr_t after=0;if(!worldRead(base+0x2a88598+i*0x228,&after,8)||after!=cb[i])return false;}
 bool wasOwned=sr1ExitLatch.nativeOwned;
 if(!exitKnown)InterlockedIncrement(&sr1ExitReadRefused);
 if(!sr1NativeExitAdmitCurrent(&sr1ExitLatch,true,actionAllowed,exitKnown,&exitPose,&c)){if(actionAllowed&&sr1ExitLatch.nativeOwned)InterlockedIncrement(&sr1ExitHeld);return false;}
 if(wasOwned)InterlockedIncrement(&sr1ExitReleased);
#endif
#ifdef SR1_ORDINARY_PRESENTATION_R13
 if(presentation)return ordinaryPresentationContext(kind,&c);
#else
 (void)presentation;
#endif
#ifdef SR1_NATIVE_JUMP_POSE
 if(kind==3)return sr1RetargetJumpContextAllowed(&c);
#else
 (void)kind;
#endif
 return kind==2&&sr1RetargetContextAllowed(&c);
}
static bool sr1SkeletonContextKind(uintptr_t base,uintptr_t actor,unsigned kind){return sr1SkeletonContextRead(base,actor,kind,false);}
static bool sr1SkeletonPresentationContext(uintptr_t base,uintptr_t actor,unsigned kind){
#ifdef SR1_ORDINARY_PRESENTATION_R13
 return sr1SkeletonContextRead(base,actor,kind,true);
#else
 return sr1SkeletonContextKind(base,actor,kind);
#endif
}
static bool sr1SkeletonContext(uintptr_t base,uintptr_t actor){return sr1SkeletonContextKind(base,actor,2);}
#ifdef SR1_NATIVE_JUMP_POSE
static volatile LONG sr1SkeletonJumpAligned;
#endif
static bool sr1SkeletonPlayerArguments(uintptr_t base,uintptr_t a,uintptr_t b,uintptr_t d){
 // Quick native record/model filter before the expensive coherent rig read.
 uintptr_t actor=0,object=0,list=0,model=0,matrices=0;int16_t index=-1;
 return base&&worldRead(base+0x2a89310,&actor,8)&&actor&&worldRead(actor+0x1c6,&index,2)&&!index&&worldRead(actor+0x30,&object,8)&&object&&worldRead(object+0x10,&list,8)&&list&&worldRead(list,&model,8)&&worldRead(actor+0x70,&matrices,8)&&sr1NativePoseArgumentsMatch(a,b,d,object,model,matrices,0x70);
}
static bool sr1SkeletonScope(uintptr_t base,uintptr_t a,uintptr_t b,uintptr_t d,HostRig *r){
 if(!hostRigRead(NULL,sr1SkeletonRead,base,r)||r->count!=66||r->modelIndex||!sr1NativePoseArgumentsMatch(a,b,d,r->object,r->model,r->render,0x70))return false;
 unsigned char mask[66];int32_t extra=-1;unsigned weighted=0;
 if(a>UINTPTR_MAX-0x71c||!worldRead(a+0x69c,mask,sizeof(mask))||!worldRead(a+0xc,&extra,4)||extra)return false;
 for(unsigned i=0;i<66;i++)weighted+=mask[i]!=0;return weighted==57;
}
static uintptr_t sr1SkeletonCall(uintptr_t a,uintptr_t b,uintptr_t c,uintptr_t d,uintptr_t e,uintptr_t f,uintptr_t g,uintptr_t h){
 const uintptr_t args[8]={a,b,c,d,e,f,g,h};unsigned depth=++sr1SkeletonDepth;bool borrowed=false,moving=false;SkeletonSnapshot s={0};HostRig r;float before[66][13];uint64_t now=GetTickCount64();
 unsigned refusal=1;bool forwardedUnchanged=false;
 uintptr_t base=(uintptr_t)InterlockedCompareExchangePointer(&verifiedSr1Module,NULL,NULL);DWORD thread=GetCurrentThreadId();
 bool enabled=!InterlockedCompareExchange(&probeBoundedComplete,0,0)&&!InterlockedCompareExchange(&sr1SkeletonFailed,0,0)&&GetFileAttributesW(PROBE_PATH(L"\\sr1-skeleton.enable"))!=INVALID_FILE_ATTRIBUTES;
#ifdef SR1_NATIVE_DRAW_RECEIPT
 HostRig captured={0};Sr1RetargetContext capturedContext={0};
 bool capture=depth==1&&enabled&&sr1SkeletonPlayerArguments(base,a,b,d)&&sr1SkeletonScope(base,a,b,d,&captured)&&hostDrawContext(base,captured.actor,&capturedContext);
#endif
 if(depth==1&&(DWORD)InterlockedCompareExchange(&sr1SkeletonThread,0,0)==thread){if(!enabled&&sr1SkeletonWasEnabled){skeletonMarkDrawYield(&sr1SkeletonAdmission,true,thread,now);
#ifdef SR1_NATIVE_EXIT_GUARD
 sr1ExitLatch.nativeOwned=true;sr1ExitActor=sr1ExitObject=sr1ExitModel=0;
#endif
 }sr1SkeletonWasEnabled=enabled;}
 if(depth==1&&enabled){
  const SkeletonShared *view=(const SkeletonShared *)InterlockedCompareExchangePointer(&sr1SkeletonView,NULL,NULL);
  // Establish player ownership BEFORE a rejection can affect reacquisition.
  // Scene objects, enemy/shadow records and other models forward untouched.
  if(!sr1SkeletonPlayerArguments(base,a,b,d))InterlockedIncrement(&sr1SkeletonForeign);
  else if(!sr1SkeletonScope(base,a,b,d,&r)){refusal=2;InterlockedIncrement(&sr1SkeletonScopeRejected);skeletonMarkDrawYield(&sr1SkeletonAdmission,true,thread,now);}
#ifdef SR1_C0_PHYSICAL_WEAPON
  else if(sr1SkeletonNativeWeapon(r.actor)){refusal=10;InterlockedIncrement(&sr1SkeletonContextRejected);skeletonMarkDrawYield(&sr1SkeletonAdmission,true,thread,now);}
#endif
  else if(!view||!skeletonCopy(view,&s)||!skeletonPacketValid(&s,GetCurrentProcessId(),now)){refusal=3;InterlockedIncrement(&sr1SkeletonPacketRejected);skeletonMarkDrawYield(&sr1SkeletonAdmission,true,thread,now);}
  else if(s.actor!=r.actor||s.object!=r.object||s.model!=r.model){refusal=4;InterlockedIncrement(&sr1SkeletonIdentityRejected);skeletonMarkDrawYield(&sr1SkeletonAdmission,true,thread,now);}
  else {
   InterlockedIncrement(&sr1SkeletonCandidates);
   LONG owner=InterlockedCompareExchange(&sr1SkeletonThread,(LONG)thread,0);
   if(!owner||(DWORD)owner==thread){float current[13];memcpy(current,r.renderBytes,sizeof(current));moving=sr1SkeletonLastActor==r.actor&&now>=sr1SkeletonLastRootTick&&now-sr1SkeletonLastRootTick<=150&&skeletonRootMoved(sr1SkeletonLastRoot,current);memcpy(sr1SkeletonLastRoot,current,sizeof(current));sr1SkeletonLastActor=r.actor;sr1SkeletonLastRootTick=now;}
   bool context=s.mode>=2?sr1SkeletonPresentationContext(base,r.actor,s.mode):sr1SkeletonContextKind(base,r.actor,s.mode==1?2:s.mode);
   if(owner&&(DWORD)owner!=thread){refusal=5;InterlockedIncrement(&sr1SkeletonThreadRejected);}
   else if(!s.mode){refusal=6;skeletonMarkDrawYield(&sr1SkeletonAdmission,true,thread,now);InterlockedIncrement(&sr1SkeletonAdmissionRejected);}
   else if(!skeletonAdmit(&sr1SkeletonAdmission,&s,thread,now,context)){if(s.mode>=2&&!context){refusal=7;InterlockedIncrement(&sr1SkeletonContextRejected);}else {refusal=8;InterlockedIncrement(&sr1SkeletonAdmissionRejected);}}
   else {
    memcpy(before,r.renderBytes,sizeof(before));
    if(s.mode==1){memcpy(sr1SkeletonScratch,before,sizeof(before));borrowed=true;refusal=0;}
    else {borrowed=skeletonRebase(sr1SkeletonScratch,before,s.bones);refusal=borrowed?0:9;if(!borrowed)InterlockedIncrement(&sr1SkeletonRebaseRejected);}
   }
  }
 }
 if(depth!=1)InterlockedIncrement(&sr1SkeletonDepthRefused);
 if(borrowed&&s.mode>=2&&!sr1SkeletonPresentationContext(base,r.actor,s.mode)){borrowed=false;refusal=7;skeletonMarkDrawYield(&sr1SkeletonAdmission,true,thread,now);InterlockedIncrement(&sr1SkeletonContextRejected);}
#ifdef SR1_JUMP_EXIT_BLEND
 bool exitBlend=false;
 if(!enabled)sr1JumpExit.ready=false;
 if(!borrowed&&capture&&(DWORD)InterlockedCompareExchange(&sr1SkeletonThread,0,0)==thread
#ifdef SR1_C0_PHYSICAL_WEAPON
    &&!sr1SkeletonNativeWeapon(captured.actor)
#endif
 ){
  Sr1RetargetContext currentContext={0};
  bool safe=skeletonPacketValid(&s,GetCurrentProcessId(),now)&&s.actor==captured.actor&&s.object==captured.object&&s.model==captured.model&&hostDrawContext(base,captured.actor,&currentContext)&&hostDrawContextSame(&capturedContext,&currentContext)&&sr1SkeletonPlayerArguments(base,a,b,d);
  if(safe){r=captured;memcpy(before,captured.renderBytes,sizeof(before));exitBlend=jumpExitApply(&sr1JumpExit,&s,&currentContext,r.parents,before,now,sr1SkeletonScratch);borrowed=exitBlend;}
  else sr1JumpExit.ready=false;
 }
 // Scalar path transitions expose intermittent fallback hidden by 1Hz totals.
 // Player argument scope only; no matrices/pointers/assets are logged.
 if(depth==1&&enabled&&sr1SkeletonPlayerArguments(base,a,b,d)){
  unsigned path=borrowed?(exitBlend?4:s.mode):0,callback=capture?capturedContext.callbacks[0]:0;
  if(sr1JumpTraceCount<(unsigned)sheet_nativeJumpExitBlend_jump_fall.maxTraceEvents&&(path!=sr1JumpTracePath||callback!=sr1JumpTraceCallback||capture!=sr1JumpTraceCapture)){
   logLine("SR1_POSE_PATH tick=%llu path=%u callback=%x capture=%u sequence=%llu",(unsigned long long)now,path,callback,(unsigned)capture,(unsigned long long)s.sequence);
   sr1JumpTraceCount++;sr1JumpTracePath=path;sr1JumpTraceCallback=callback;sr1JumpTraceCapture=capture;
  }
 }
#endif
#ifdef SR1_C0_PHYSICAL_WEAPON
 if(borrowed&&sr1SkeletonNativeWeapon(r.actor)){borrowed=false;refusal=10;skeletonMarkDrawYield(&sr1SkeletonAdmission,true,thread,now);InterlockedIncrement(&sr1SkeletonContextRejected);}
#endif
 uintptr_t forward[8];memcpy(forward,args,sizeof(forward));float shadow[66][13];
 if(borrowed){memcpy(shadow,sr1SkeletonScratch,sizeof(shadow));forward[3]=(uintptr_t)sr1SkeletonScratch;}
#ifdef SR1_ORDINARY_PRESENTATION_R13
 if(capture&&!borrowed)memcpy(shadow,captured.renderBytes,sizeof(shadow));
 uint64_t drawSerialBefore=(uint64_t)InterlockedCompareExchange64(&hostDrawPublished,0,0);
 LARGE_INTEGER presentationQpcBefore={0},presentationQpcAfter={0};
 QueryPerformanceCounter(&presentationQpcBefore);
#endif
#ifdef SR1_REAVER_HAND_RECEIPT
 // Preserve the actual forwarded input even for a native handoff. The existing
 // hostDrawReceipt still receives ORIGINAL native matrices below.
 if(capture&&!borrowed)memcpy(shadow,captured.renderBytes,sizeof(shadow));
 uint64_t reaverFrame=(uint64_t)InterlockedCompareExchange64(&swapCalls,0,0)+1;
#endif
 uintptr_t result=sr1NativePoseForward(sr1SkeletonOriginal,forward);
#ifdef SR1_ORDINARY_PRESENTATION_R13
 QueryPerformanceCounter(&presentationQpcAfter);
#endif
#ifdef SR1_NATIVE_DRAW_RECEIPT
 // Publish original native input, never the adapted TLS scratch passed above.
 if(capture)hostDrawPublish(&captured,&capturedContext,base,d,now);
#endif
 if(borrowed){
  float after[66][13];uintptr_t actorAfter=0,renderAfter=0,objectAfter=0,listAfter=0,modelAfter=0;int16_t indexAfter=-1;
  bool unchanged=worldRead(base+0x2a89310,&actorAfter,8)&&actorAfter==r.actor&&worldRead(actorAfter+0x30,&objectAfter,8)&&objectAfter==r.object&&worldRead(objectAfter+0x10,&listAfter,8)&&listAfter&&worldRead(listAfter,&modelAfter,8)&&modelAfter==r.model&&worldRead(actorAfter+0x1c6,&indexAfter,2)&&!indexAfter&&worldRead(actorAfter+0x70,&renderAfter,8)&&renderAfter==d&&worldRead(d,after,sizeof(after))&&!memcmp(before,after,sizeof(after))&&!memcmp(shadow,sr1SkeletonScratch,sizeof(shadow));
  forwardedUnchanged=unchanged;
  if(!unchanged){refusal=11;sr1SkeletonAdmission.failed=true;InterlockedExchange(&sr1SkeletonFailed,1);}
  else if(s.mode==1){sr1SkeletonAdmission.copies++;InterlockedIncrement(&sr1SkeletonCopies);}else {InterlockedIncrement(&sr1SkeletonAligned);if(moving)InterlockedIncrement(&sr1SkeletonMoving);
#ifdef SR1_NATIVE_JUMP_POSE
   if(s.mode==3)InterlockedIncrement(&sr1SkeletonJumpAligned);
#endif
  }
#ifdef SR1_JUMP_EXIT_BLEND
  if(!unchanged)sr1JumpExit.ready=false;
  else if(exitBlend)InterlockedIncrement(&sr1JumpExitRendered);
  else if(s.mode==3)jumpExitCapture(&sr1JumpExit,&s,r.parents,shadow,now);
  else sr1JumpExit.ready=false;
#endif
 } else InterlockedIncrement(&sr1SkeletonRefused);
#ifdef SR1_ORDINARY_PRESENTATION_R13
 // Consume the ORIGINAL post-call draw proof already produced above. No extra
 // game read or cached/generated pose is promoted into a presentation receipt.
 if(depth==1&&sr1SkeletonPlayerArguments(base,a,b,d)){
  OrdinaryPresentationReceipt receipt={.threadId=thread,.tick=now,.path=borrowed?s.mode:0,
   .requestedMode=s.mode,.refusal=refusal,.sourcePid=s.sourcePid,.writerPid=s.writerPid,
   .epoch=s.epoch,.hostTick=s.hostTick,.sourceTick=s.sourceTick,.packetSequence=s.sequence,
   .qpcBefore=(uint64_t)presentationQpcBefore.QuadPart,.qpcAfter=(uint64_t)presentationQpcAfter.QuadPart,
   .proof=capture?ORDINARY_PRESENTATION_POSTCALL_CHANGED:ORDINARY_PRESENTATION_NO_CAPTURE};
#ifdef SR1_JUMP_EXIT_BLEND
  if(borrowed&&exitBlend)receipt.path=4;
#endif
  HostDrawReceipt originalReceipt={0};
  const HostDrawShared *draw=(const HostDrawShared *)InterlockedCompareExchangePointer(&hostDrawView,NULL,NULL);
  bool proven=enabled&&capture&&hostDrawCopy(draw,&originalReceipt)&&originalReceipt.valid&&
   originalReceipt.serial>drawSerialBefore&&originalReceipt.tick==now&&
   hostDrawResourceSame(&captured,&originalReceipt.rig)&&hostDrawContextSame(&capturedContext,&originalReceipt.context)&&
   (borrowed?forwardedUnchanged:!memcmp(shadow,originalReceipt.rig.renderBytes,sizeof(shadow)));
  if(capture){const Sr1RetargetContext *context=&capturedContext;
   receipt.actor=captured.actor;receipt.object=captured.object;receipt.model=captured.model;
   memcpy(receipt.callbacks,context->callbacks,sizeof(receipt.callbacks));receipt.hostMode=context->mode;
   receipt.hostFlags=context->flags;receipt.verticalVelocity=context->verticalVelocity;
   receipt.contextMask=(context->identity?1u:0u)|(context->foreground?2u:0u)|(context->crouchHeld?4u:0u)|
    (context->verticalVelocityKnown?8u:0u)|(sr1RetargetContextAllowed(context)?16u:0u)|
    (sr1RetargetJumpContextAllowed(context)?32u:0u)|(sr1ExitLatch.nativeOwned?64u:0u)|(refusal==10?128u:0u);
  }
  if(proven){receipt.valid=1;receipt.proof=ORDINARY_PRESENTATION_POSTCALL;receipt.drawSerial=originalReceipt.serial;memcpy(receipt.forwarded,shadow,sizeof(shadow));}
  ordinaryPresentationPublish(&receipt);
 }
#else
 (void)refusal;(void)forwardedUnchanged;
#endif
#ifdef SR1_REAVER_HAND_RECEIPT
 if(capture
#ifdef SR1_C0_PHYSICAL_WEAPON
    &&!sr1C0NativeActive(captured.actor)
#endif
 )reaverHostCapture(&captured,shadow,forward[3],base,reaverFrame,depth);
 else if(depth==1&&sr1SkeletonPlayerArguments(base,a,b,d)){reaverHandClear(&reaverHostHand);reaverHandClear(&reaverHostPalm);reaverHostContext=NULL;
#ifdef SR1_REAVER_GPU_RECEIPT
 memset(&reaverHostPalette,0,sizeof(reaverHostPalette));
#endif
 }
#endif
 --sr1SkeletonDepth;return result;
}
static bool sr1SkeletonInstall(HMODULE module){
 if(sr1SkeletonTarget)return true;const Sheet_nativePoseObserver *p=&sheet_nativePoseObserver_original;unsigned char code[1961],setup[265];char hash[65],expected[65];
 if(!module||p->targetRva!=0x40d10||p->targetBytes!=1961||p->bones!=66||p->matrixBytes!=52||wcslen(p->codeSha256)!=64)return false;
 for(unsigned i=0;i<64;i++){if(!wcschr(L"0123456789abcdef",p->codeSha256[i]))return false;expected[i]=(char)p->codeSha256[i];}expected[64]=0;
 uintptr_t target=(uintptr_t)module+0x40d10;
 if(!worldRead(target,code,sizeof(code))||!hashBytes(code,sizeof(code),hash)||strcmp(hash,expected)||!worldRead((uintptr_t)module+0x9a90,setup,sizeof(setup))||!hashBytes(setup,sizeof(setup),hash)||strcmp(hash,SKELETON_SETUP_SHA256))return false;
 MH_STATUS init=MH_Initialize();if(init!=MH_OK&&init!=MH_ERROR_ALREADY_INITIALIZED)return false;
 MH_STATUS create=MH_CreateHook((void *)target,(void *)&sr1SkeletonCall,(void **)&sr1SkeletonOriginal),enable=create==MH_OK?MH_EnableHook((void *)target):create;
 if(enable!=MH_OK)return false;sr1SkeletonTarget=(void *)target;logLine("CAPABILITY sr1_skeleton_only=1; native8slot draw;66bone argument4 pinned scratch only; mesh/texture bytes0");logLine("CAPABILITY sr1_skeleton_admission=2; foreign draw cannot yield player; native moving counter");
#ifdef SR1_NATIVE_JUMP_POSE
 logLine("CAPABILITY sr1_skeleton_jump=1; exact native Jump only, no ground speed controller in air; fall/glide/landing native");
#endif
#ifdef SR1_NATIVE_EXIT_GUARD
 logLine("CAPABILITY sr1_native_exit=1; native action latch waits for all legacy+HD interpolation lists; no game writes");
#endif
 return true;
}
static void sr1SkeletonTick(void){
#ifdef SR1_ORDINARY_PRESENTATION_R13
 ordinaryPresentationInitialize();
 if(InterlockedCompareExchange(&probeBoundedComplete,0,0)||GetFileAttributesW(PROBE_PATH(L"\\sr1-skeleton.enable"))==INVALID_FILE_ATTRIBUTES)ordinaryPresentationClear();
#endif
#ifdef SR1_JUMP_EXIT_BLEND
 logLine("SR1_JUMP_EXIT blended=%ld; last rendered Jump to current native Fall,120ms,root/actions unchanged",InterlockedCompareExchange(&sr1JumpExitRendered,0,0));
#endif
#ifdef SR1_NATIVE_EXIT_GUARD
 logLine("SR1_NATIVE_EXIT held=%ld released=%ld read_refused=%ld",InterlockedCompareExchange(&sr1ExitHeld,0,0),InterlockedCompareExchange(&sr1ExitReleased,0,0),InterlockedCompareExchange(&sr1ExitReadRefused,0,0));
#endif
#ifdef SR1_NATIVE_DRAW_RECEIPT
 hostDrawInitialize();
 if(InterlockedCompareExchange(&probeBoundedComplete,0,0)||GetFileAttributesW(PROBE_PATH(L"\\sr1-skeleton.enable"))==INVALID_FILE_ATTRIBUTES)hostDrawClear();
 logLine("SR1_DRAW_RECEIPT published=%lld rejected=%lld; original native input only",InterlockedCompareExchange64(&hostDrawPublished,0,0),InterlockedCompareExchange64(&hostDrawRejected,0,0));
#endif
 if(!sr1SkeletonView&&sr1SkeletonTarget){wchar_t name[96];skeletonNames(name,GetCurrentProcessId());HANDLE m=OpenFileMappingW(FILE_MAP_READ,FALSE,name);if(m){PVOID v=MapViewOfFile(m,FILE_MAP_READ,0,0,sizeof(SkeletonShared));if(v){sr1SkeletonMapping=m;InterlockedExchangePointer(&sr1SkeletonView,v);}else CloseHandle(m);}}
 logLine("SR1_SKELETON copies=%ld aligned=%ld refused=%ld nested=%ld failed=%ld; root/model/native input unchanged required",InterlockedCompareExchange(&sr1SkeletonCopies,0,0),InterlockedCompareExchange(&sr1SkeletonAligned,0,0),InterlockedCompareExchange(&sr1SkeletonRefused,0,0),InterlockedCompareExchange(&sr1SkeletonDepthRefused,0,0),InterlockedCompareExchange(&sr1SkeletonFailed,0,0));
 logLine("SR1_SKELETON_GATE candidates=%ld foreign=%ld scope=%ld packet=%ld identity=%ld thread=%ld context=%ld admission=%ld rebase=%ld moving=%ld",InterlockedCompareExchange(&sr1SkeletonCandidates,0,0),InterlockedCompareExchange(&sr1SkeletonForeign,0,0),InterlockedCompareExchange(&sr1SkeletonScopeRejected,0,0),InterlockedCompareExchange(&sr1SkeletonPacketRejected,0,0),InterlockedCompareExchange(&sr1SkeletonIdentityRejected,0,0),InterlockedCompareExchange(&sr1SkeletonThreadRejected,0,0),InterlockedCompareExchange(&sr1SkeletonContextRejected,0,0),InterlockedCompareExchange(&sr1SkeletonAdmissionRejected,0,0),InterlockedCompareExchange(&sr1SkeletonRebaseRejected,0,0),InterlockedCompareExchange(&sr1SkeletonMoving,0,0));
#ifdef SR1_NATIVE_JUMP_POSE
 logLine("SR1_SKELETON_JUMP aligned=%ld; native root/physics, native glide/fall/landing",InterlockedCompareExchange(&sr1SkeletonJumpAligned,0,0));
#endif
}
static void sr1SkeletonStop(void){InterlockedExchange(&sr1SkeletonFailed,1);
#ifdef SR1_ORDINARY_PRESENTATION_R13
 ordinaryPresentationClear();
#endif
 logLine("SR1_SKELETON stopped; original forwarding restored; read mapping and TLS trampoline remain pinned");}
#include "sr1-skeleton-visibility.h"
