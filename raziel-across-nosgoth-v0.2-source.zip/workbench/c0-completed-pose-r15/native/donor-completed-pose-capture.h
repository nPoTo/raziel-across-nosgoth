// SPDX-License-Identifier: GPL-3.0-or-later
#pragma once
#include "donor-completed-pose-wire.h"
#include "donor-completed-pose-policy-r13.h"
#include "donor-state-sections.h"
#include "donor-reaver-reader.h"
#include "donor-motion-reader.h"
typedef struct {
 uintptr_t actor,object,model,state,context,resource;
 uint32_t resourceGeneration,realm;
} DonorCompletedIdentityR13;
static uintptr_t dcpPointerR13(const unsigned char *b){uintptr_t p;memcpy(&p,b,8);return p;}
static uint32_t dcpWordR13(const unsigned char *b){uint32_t v;memcpy(&v,b,4);return v;}
static float dcpFloatR13(const unsigned char *b){float v;memcpy(&v,b,4);return v;}
static bool dcpFieldR13(void *c,DonorActionStateRead r,uintptr_t a,uintptr_t o,void *v,SIZE_T n){return a&&o<=UINTPTR_MAX-a&&n<=UINTPTR_MAX-a-o&&r(c,a+o,v,n);}
static bool dcpIdentityR13(void *c,DonorActionStateRead r,uintptr_t base,DonorCompletedIdentityR13 *out){
 const Sheet_donorCompletedPosePolicy *p=&sheet_donorCompletedPosePolicy_native_pass;
 const Sheet_reaverObservationPolicy *resourcePolicy=&sheet_reaverObservationPolicy_candidate;
 DonorCompletedIdentityR13 i={0};unsigned char object[0x58];uintptr_t name=0,owner=0;char text[7];uint32_t actual=0;
 if(!dcpFieldR13(c,r,base,p->actorRva,&i.actor,8)||!i.actor||i.actor%8||
 !dcpFieldR13(c,r,i.actor,0x88,&i.object,8)||!i.object||i.object%8||
 !dcpFieldR13(c,r,i.actor,0x1c0,&i.model,8)||!i.model||i.model%8||
 !dcpFieldR13(c,r,i.actor,p->actorStateOffset,&i.state,8)||!i.state||i.state%8||
 !dcpFieldR13(c,r,i.state,0,&owner,8)||owner!=i.actor||
 !dcpFieldR13(c,r,base,p->contextRva,&i.context,8)||!i.context||i.context%8||
 !dcpFieldR13(c,r,i.context,p->realmOffset,&i.realm,4)||i.realm<1||i.realm>2||
 !dcpFieldR13(c,r,i.object,0,object,sizeof(object)))return false;
 name=dcpPointerR13(object+0x50);
 if(!dcpFieldR13(c,r,name,0,text,sizeof(text))||memcmp(text,"raziel",7))return false;
 if(wcscmp(p->resourceOwner,L"animation_model")||resourcePolicy->modelResourceOffset!=0x68||resourcePolicy->modelResourceGenerationOffset!=0x70||resourcePolicy->resourceGenerationOffset!=4)return false;
 // These fields belong to the animation model at actor+1C0. Object+68/+70
 // are unrelated fields (the R13 live failure read118 vs2549292112 there).
 if(!dcpFieldR13(c,r,i.model,resourcePolicy->modelResourceOffset,&i.resource,8)||
 !dcpFieldR13(c,r,i.model,resourcePolicy->modelResourceGenerationOffset,&i.resourceGeneration,4)||
 !i.resource||!dcpFieldR13(c,r,i.resource,resourcePolicy->resourceGenerationOffset,&actual,4)||actual!=i.resourceGeneration)return false;
 *out=i;return true;
}
static bool dcpAffineR13(const float m[16]){
 for(unsigned k=0;k<16;k++)if(!isfinite(m[k]))return false;
 return fabsf(m[3])<0.00001f&&fabsf(m[7])<0.00001f&&fabsf(m[11])<0.00001f&&fabsf(m[15]-1)<0.00001f;
}
// Read on the owner thread after the original target matrix builder. This does not
// infer completion from equal reads, nor identify gameplay context as state.
static unsigned dcpCaptureR13(void *c,DonorActionStateRead read,DonorActionStateCode code,uintptr_t base,uint32_t imageSize,const DonorCompletedIdentityR13 *expected,DonorCompletedPoseSnapshotR13 *s){
 const Sheet_donorCompletedPosePolicy *p=&sheet_donorCompletedPosePolicy_native_pass;
 const Sheet_combatPhaseProbe *phase=&sheet_combatPhaseProbe_current;
 const Sheet_donorPoseFrameObservation *basis=&sheet_donorPoseFrameObservation_read_pair;
 if(phase->positionOffset!=0x20||phase->scalarOffset!=0xc4||phase->actionKindOffset!=0x484||phase->animationClockOffset!=0x1d4||phase->actorTimeFactorOffset!=0x1f0||basis->actorRotationOffset!=0x40||basis->stateDirectionOffset!=0x70||basis->stateRecoveryOffset!=0x94||basis->stateAttackOffset!=0xabc)return 14;
 DonorCompletedIdentityR13 a={0},b={0};unsigned char actor[1024],object[0x30],segments[128][40],context[0xac0];
 uintptr_t list=0,segmentList=0,palette=0,root=0;uint16_t modelCount=0;uint32_t counts[2]={0};uintptr_t members[16];
 if(!expected||!s||!dcpIdentityR13(c,read,base,&a)||memcmp(&a,expected,sizeof(a)))return 1;
 if(!dcpFieldR13(c,read,a.actor,0,actor,sizeof(actor))||dcpPointerR13(actor+0x88)!=a.object||dcpPointerR13(actor+0x1c0)!=a.model||dcpPointerR13(actor+0x3f8)!=a.state||
 !dcpFieldR13(c,read,a.object,0,object,sizeof(object))||!dcpFieldR13(c,read,a.model,4,counts,sizeof(counts)))return 2;
 memcpy(&modelCount,object+0x20,2);list=dcpPointerR13(object+0x28);
 if(!modelCount||modelCount>16||!dcpFieldR13(c,read,list,0,members,modelCount*8))return 3;
 bool member=false;for(unsigned k=0;k<modelCount;k++)if(members[k]==a.model)member=true;
 unsigned sectionEnd=0;for(unsigned k=0;k<3;k++){unsigned off=0x1d0+k*0x68,end=actor[off+2]+actor[off+3];if(end>sectionEnd)sectionEnd=end;const unsigned offsets[5]={0,4,8,0x24,0x28};for(unsigned j=0;j<5;j++)s->animationRaw[k][j]=dcpWordR13(actor+off+offsets[j]);}
 if(!member||!counts[0]||counts[0]>128||counts[1]>128||counts[0]+counts[1]>128||counts[0]!=sectionEnd)return 4;
 s->baseCount=counts[0];s->extraCount=counts[1];s->matrixCount=counts[0]+counts[1];
 palette=dcpPointerR13(actor+0x60);root=dcpPointerR13(actor+0x70);
 if(!dcpFieldR13(c,read,palette,0,s->matrices,s->matrixCount*64)||!dcpFieldR13(c,read,root,0,s->rootMatrix,64)||!dcpAffineR13(s->rootMatrix))return 5;
 for(unsigned k=0;k<s->matrixCount;k++)if(!dcpAffineR13(s->matrices[k]))return 6;
 if(!dcpFieldR13(c,read,a.model,0x10,&segmentList,8)||!dcpFieldR13(c,read,segmentList,0,segments,s->baseCount*40))return 7;
 for(unsigned k=0;k<s->baseCount;k++){
  memcpy(&s->parents[k],segments[k]+24,4);memcpy(s->bindLocalPositions[k],segments[k],12);
  if(s->parents[k]<-1||s->parents[k]>=(int32_t)s->baseCount||s->parents[k]==(int32_t)k||fabsf(dcpFloatR13(segments[k]+12)-1)>0.00001f)return 8;
  for(unsigned j=0;j<3;j++)if(!isfinite(s->bindLocalPositions[k][j]))return 8;
 }
 for(unsigned k=0;k<s->baseCount;k++){int32_t at=(int32_t)k;unsigned depth=0;while(at!=-1&&depth<=s->baseCount){at=s->parents[at];depth++;}if(at!=-1)return 8;}
 DonorStateSections sections=donorStateSectionsRead(c,read,code,base,imageSize,a.actor,base+p->actorRva);
 if(!sections.valid||!sections.ownerMatches||!dcpFieldR13(c,read,a.context,0,context,sizeof(context)))return 9;
 for(unsigned k=0;k<3;k++){s->primary[k]=sections.sections[k].firstRva;s->secondary[k]=sections.sections[k].secondValid?sections.sections[k].secondRva:0;}
 memcpy(s->position,actor+phase->positionOffset,12);memcpy(s->previousPosition,actor+0x30,12);memcpy(s->actorRotation,actor+basis->actorRotationOffset,32);
 s->directions[0]=dcpFloatR13(context+basis->stateDirectionOffset);s->directions[1]=dcpFloatR13(context+basis->stateRecoveryOffset);s->directions[2]=dcpFloatR13(context+basis->stateAttackOffset);
 s->realm=dcpWordR13(context+p->realmOffset);s->selectedReaver=dcpWordR13(context+p->selectedOffset);s->scalar=(int32_t)dcpWordR13(context+phase->scalarOffset);s->actionKind=dcpWordR13(context+phase->actionKindOffset);
 s->animationClock=dcpFloatR13(actor+phase->animationClockOffset);s->actorFactor=dcpFloatR13(actor+phase->actorTimeFactorOffset);
 unsigned char mode=0;
 if(s->realm!=a.realm||!dcpFieldR13(c,read,base,p->inputRva,s->buttonSlots,sizeof(s->buttonSlots))||!dcpFieldR13(c,read,base,p->axesRva,s->stickAxes,sizeof(s->stickAxes))||
 !dcpFieldR13(c,read,base,phase->physicsModeRva,&s->physicsMode,4)||!dcpFieldR13(c,read,base,phase->frameFactorRva,&s->frameFactor,4)||
 !dcpFieldR13(c,read,base,0xc5ab60,&mode,1)||!dcpFieldR13(c,read,base,0xc5ab38,&s->gameFlags,4))return 10;
 s->gameMode=mode;
 for(unsigned k=0;k<3;k++)if(!isfinite(s->position[k])||!isfinite(s->previousPosition[k])||!isfinite(s->directions[k]))return 11;
 for(unsigned k=0;k<8;k++)if(!isfinite(s->actorRotation[k]))return 11;
 if(!isfinite(s->animationClock)||!isfinite(s->actorFactor)||!isfinite(s->frameFactor))return 11;
 DonorMotion m=donorMotionRead(read,c,base,a.actor);DonorTimeCandidate t=donorTimeRead(read,c,base,a.actor);
 s->motionValid=m.valid;s->motionComplete=m.complete;s->motionStable=m.stable;s->motionVisited=m.visited;s->motionIndex=m.index;s->motionFlags=m.flags;memcpy(s->motionVector,m.vector,12);
 s->timeValid=t.valid;s->timeFactor=t.factor;s->timeSelectedRva=t.selectedRva;
 ReaverObservation reaver=reaverObserve(c,read,base,imageSize,a.object);
 if(!reaver.valid)return 12;
 const ReaverSnapshot *r=&reaver.snapshot;DonorCompletedReaverR13 *w=&s->reaver;
 w->valid=1;w->present=reaver.present;w->enabled=r->enabled;w->nameMatches=reaver.nameMatches;w->flags=r->flags;w->partMask=r->partMask;w->skin=r->skin;w->configuredHand=r->configuredHand;
 w->attachedToActor=r->attachedParent==a.actor;w->attachedBone=(uint32_t)(int32_t)r->attachedBone;w->b4=r->b4;w->b5=r->b5;w->type=r->type;w->drawState=r->drawState;w->coilState=r->coilState;
 w->value24=r->f24;w->value28=r->f28;w->fadeCurrent=r->fadeCurrent;w->fadeTarget=r->fadeTarget;
 uintptr_t checkPalette=0,checkRoot=0;
 if(!dcpIdentityR13(c,read,base,&b)||memcmp(&a,&b,sizeof(a))||!dcpFieldR13(c,read,a.actor,0x60,&checkPalette,8)||checkPalette!=palette||!dcpFieldR13(c,read,a.actor,0x70,&checkRoot,8)||checkRoot!=root)return 13;
 s->actorAddress=(uint64_t)a.actor;s->objectAddress=(uint64_t)a.object;s->modelAddress=(uint64_t)a.model;
 return 0;
}
