// SPDX-License-Identifier: GPL-3.0-or-later
#pragma once
#include "donor-completed-pose-capture.h"
// Integration dependencies: worldRead/hashBytes/logLine, MinHook, and the
// validated session-lifetime worker lease. No old animation installer needed.
typedef uintptr_t (__fastcall *DcpPass0R13)(void);
typedef uintptr_t (__fastcall *DcpPass1R13)(uintptr_t);
static DcpPass0R13 dcpOriginalAlternateR13;
static DcpPass1R13 dcpOriginalGameR13,dcpOriginalPrepareR13,dcpOriginalMatrixR13,dcpOriginalAltMatrixR13,dcpOriginalExtraMatrixR13;
static uintptr_t dcpBaseR13;static uint32_t dcpImageSizeR13;static bool dcpInstalledR13;
static PVOID dcpTargetsR13[6];static HANDLE dcpMappingR13;static DonorCompletedPoseSharedR13 *dcpSharedR13;
static volatile LONG dcpActiveR13,dcpLockR13,dcpForeignR13;static volatile LONG64 dcpEpochR13;
static uint64_t dcpBirthR13,dcpFrequencyR13,dcpGenerationR13,dcpSerialR13;static unsigned char dcpLeaseR13[48];
static DonorCompletedIdentityR13 dcpIdentityLastR13;static bool dcpIdentityKnownR13;
static DonorCompletedIdentityR13 dcpTokenIdentityR13;static uint64_t dcpNextTokenR13,dcpActorTokenR13,dcpModelTokenR13;
static DWORD dcpOwnerThreadR13;static unsigned dcpPrepareR13,dcpMatricesR13,dcpAlternatesR13,dcpExtrasR13,dcpBadReasonR13;
static DonorCompletedPoseSnapshotR13 dcpPendingR13;static unsigned dcpPendingReasonR13;static bool dcpPendingReadyR13;
static _Thread_local unsigned dcpDepthR13,dcpBuilderDepthR13;
static DonorCompletedIdentityR13 dcpPassIdentityR13;
static const unsigned char dcpBuildR13[32]={0xfc,0x6a,0x40,0x6f,0xf7,0xac,0x9b,0x5e,0xb7,0x78,0x8d,0xc7,0xa6,0x5d,0x33,0x5e,0x1c,0x1a,0xad,0x92,0x36,0x61,0x81,0x12,0x67,0x19,0x75,0xb7,0x1d,0x2d,0xad,0xdc};
static bool dcpReadR13(void *c,uintptr_t a,void *v,SIZE_T n){(void)c;return worldRead(a,v,n);}
static bool dcpCodeR13(void *c,uintptr_t a,uintptr_t base){
 (void)c;MEMORY_BASIC_INFORMATION m={0};return VirtualQuery((void *)a,&m,sizeof(m))==sizeof(m)&&m.State==MEM_COMMIT&&m.Type==MEM_IMAGE&&(uintptr_t)m.AllocationBase==base&&!(m.Protect&(PAGE_GUARD|PAGE_NOACCESS))&&(m.Protect&(PAGE_EXECUTE|PAGE_EXECUTE_READ|PAGE_EXECUTE_READWRITE|PAGE_EXECUTE_WRITECOPY));
}
static bool dcpLeaseLiveR13(uint64_t now){
 uint64_t tick=(uint64_t)InterlockedCompareExchange64(&lifetimeTick,0,0);
 return InterlockedCompareExchange(&dcpActiveR13,0,0)&&tick&&tick<=now&&now-tick<=(uint64_t)sheet_donorCompletedPosePolicy_native_pass.leaseMs;
}
static void dcpHeaderR13(DonorCompletedPoseSnapshotR13 *s){
 memset(s,0,sizeof(*s));s->magic=DONOR_COMPLETED_POSE_MAGIC_R13;s->version=DONOR_COMPLETED_POSE_VERSION_R13;s->bytes=sizeof(*s);s->donorPid=GetCurrentProcessId();s->donorCreation=dcpBirthR13;
 s->sessionEpoch=(uint64_t)InterlockedCompareExchange64(&dcpEpochR13,0,0);s->generation=dcpGenerationR13;s->serial=dcpSerialR13;s->qpcFrequency=dcpFrequencyR13;memcpy(s->sourceBuild,dcpBuildR13,32);
}
// Called only while holding the nonblocking publisher lock. Invalid snapshots
// deliberately have no new capture time and contain no old palette.
static void dcpInvalidateR13(unsigned reason){
 DonorCompletedPoseSnapshotR13 s;dcpIdentityKnownR13=false;++dcpGenerationR13;dcpHeaderR13(&s);s.reason=reason;
 if(dcpSharedR13)donorCompletedPoseStoreR13(dcpSharedR13,&s);
}
static void dcpTokensR13(const DonorCompletedIdentityR13 *i){
 bool resourceChanged=i->object!=dcpTokenIdentityR13.object||i->resource!=dcpTokenIdentityR13.resource||i->resourceGeneration!=dcpTokenIdentityR13.resourceGeneration;
 if(!dcpActorTokenR13||resourceChanged||i->actor!=dcpTokenIdentityR13.actor)dcpActorTokenR13=++dcpNextTokenR13;
 if(!dcpModelTokenR13||resourceChanged||i->model!=dcpTokenIdentityR13.model)dcpModelTokenR13=++dcpNextTokenR13;
 dcpTokenIdentityR13=*i;
}
static bool dcpBeginR13(void){
 if(!dcpLeaseLiveR13(GetTickCount64()))return false;
 if(dcpDepthR13){if(!dcpBadReasonR13)dcpBadReasonR13=103;++dcpDepthR13;return true;}
 if(InterlockedCompareExchange(&dcpLockR13,1,0)){InterlockedExchange(&dcpForeignR13,1);if(dcpSharedR13)InterlockedExchange(&dcpSharedR13->revoked,1);return false;}
 dcpDepthR13=1;dcpBuilderDepthR13=0;dcpOwnerThreadR13=GetCurrentThreadId();dcpPrepareR13=dcpMatricesR13=dcpAlternatesR13=dcpExtrasR13=0;dcpPendingReadyR13=false;dcpPendingReasonR13=0;dcpBadReasonR13=0;InterlockedExchange(&dcpForeignR13,0);
 if(!dcpIdentityR13(NULL,dcpReadR13,dcpBaseR13,&dcpPassIdentityR13)){dcpBadReasonR13=101;dcpInvalidateR13(101);return true;}
 dcpTokensR13(&dcpPassIdentityR13);
 if(!dcpIdentityKnownR13||memcmp(&dcpIdentityLastR13,&dcpPassIdentityR13,sizeof(dcpIdentityLastR13))){
  dcpInvalidateR13(102);dcpIdentityLastR13=dcpPassIdentityR13;dcpIdentityKnownR13=true;
 }
 return true;
}
static void dcpEndR13(uint32_t passRva){
 if(dcpDepthR13>1){--dcpDepthR13;return;}
 unsigned reason=0;DonorCompletedIdentityR13 endIdentity={0};
 if(dcpBadReasonR13)reason=dcpBadReasonR13;
 else if(InterlockedCompareExchange(&dcpForeignR13,0,0)||GetCurrentThreadId()!=dcpOwnerThreadR13)reason=104;
 else if(!dcpLeaseLiveR13(GetTickCount64()))reason=105;
 else if(!dcpPrepareR13)reason=106;
 else if(!dcpIdentityR13(NULL,dcpReadR13,dcpBaseR13,&endIdentity)||memcmp(&endIdentity,&dcpPassIdentityR13,sizeof(endIdentity)))reason=1;
 else if(dcpPendingReadyR13&&(dcpPendingR13.actorAddress!=(uint64_t)endIdentity.actor||dcpPendingR13.objectAddress!=(uint64_t)endIdentity.object||dcpPendingR13.modelAddress!=(uint64_t)endIdentity.model))reason=109;
 else if(!dcpPendingReadyR13&&dcpPendingReasonR13)reason=dcpPendingReasonR13;
 if(!reason&&(!dcpLeaseLiveR13(GetTickCount64())||InterlockedCompareExchange(&dcpForeignR13,0,0)))reason=105;
 if(reason)dcpInvalidateR13(reason);
 else if(dcpPendingReadyR13){
  DonorCompletedPoseSnapshotR13 *s=&dcpPendingR13;
  s->valid=1;s->serial=++dcpSerialR13;s->generation=dcpGenerationR13;s->passRva=passRva;s->threadId=GetCurrentThreadId();
  s->actorToken=dcpActorTokenR13;s->modelToken=dcpModelTokenR13;s->prepareCalls=dcpPrepareR13;s->matrixBuilds=dcpMatricesR13;s->alternateBuilds=dcpAlternatesR13;s->extraBuilds=dcpExtrasR13;
  donorCompletedPoseStoreR13(dcpSharedR13,s);
  // Never clear revocation here: worker shutdown can race this completion.
  // The worker alone rearms under dcpLock after revalidating flag and lease.
 }
 // A native reuse pass with no target builder keeps the previous immutable
 // snapshot and its original serial/time. It never labels old pose with new
 // callbacks, never renews freshness, and cannot survive reader expiry.
 dcpDepthR13=0;dcpOwnerThreadR13=0;InterlockedExchange(&dcpLockR13,0);
}
static uintptr_t __fastcall dcpAlternatePassR13(void){DWORD before=GetLastError();bool scope=dcpBeginR13();SetLastError(before);uintptr_t result=dcpOriginalAlternateR13();DWORD after=GetLastError();if(scope)dcpEndR13(0x625b0);SetLastError(after);return result;}
static uintptr_t __fastcall dcpGamePassR13(uintptr_t context){DWORD before=GetLastError();bool scope=dcpBeginR13();SetLastError(before);uintptr_t result=dcpOriginalGameR13(context);DWORD after=GetLastError();if(scope)dcpEndR13(0x64ac0);SetLastError(after);return result;}
static void dcpCountR13(uintptr_t actor,unsigned kind){
 if(!dcpDepthR13||GetCurrentThreadId()!=dcpOwnerThreadR13){
  uintptr_t current=0;
  if(dcpLeaseLiveR13(GetTickCount64())&&worldRead(dcpBaseR13+(uintptr_t)sheet_donorCompletedPosePolicy_native_pass.actorRva,&current,8)&&current==actor){InterlockedExchange(&dcpForeignR13,1);if(dcpSharedR13)InterlockedExchange(&dcpSharedR13->revoked,1);}
  return;
 }
 if(actor!=dcpPassIdentityR13.actor)return;
 if(kind==0){++dcpPrepareR13;return;}
 if(kind==1)++dcpMatricesR13;else if(kind==2)++dcpAlternatesR13;else ++dcpExtrasR13;
 // An extra-matrix builder nested inside the normal builder is not yet the
 // final target result. Count it, then copy once when its enclosing builder
 // returns. Standalone special extra rebuilds still replace the pending copy.
 if(dcpBuilderDepthR13>1)return;
 dcpPendingReadyR13=false;dcpHeaderR13(&dcpPendingR13);
 dcpPendingReasonR13=dcpCaptureR13(NULL,dcpReadR13,dcpCodeR13,dcpBaseR13,dcpImageSizeR13,&dcpPassIdentityR13,&dcpPendingR13);
 LARGE_INTEGER qpc={0};
 if(!dcpPendingReasonR13&&!QueryPerformanceCounter(&qpc))dcpPendingReasonR13=107;
 if(!dcpPendingReasonR13){dcpPendingR13.tickMs=GetTickCount64();dcpPendingR13.qpc=(uint64_t)qpc.QuadPart;dcpPendingReadyR13=true;}
}
static uintptr_t __fastcall dcpPreparePassR13(uintptr_t a){uintptr_t result=dcpOriginalPrepareR13(a);DWORD error=GetLastError();dcpCountR13(a,0);SetLastError(error);return result;}
static bool dcpBuilderEnterR13(uintptr_t a){bool target=dcpDepthR13&&a==dcpPassIdentityR13.actor;if(target)++dcpBuilderDepthR13;return target;}
static uintptr_t __fastcall dcpMatrixPassR13(uintptr_t a){bool target=dcpBuilderEnterR13(a);uintptr_t result=dcpOriginalMatrixR13(a);DWORD error=GetLastError();dcpCountR13(a,1);if(target)--dcpBuilderDepthR13;SetLastError(error);return result;}
static uintptr_t __fastcall dcpAlternateMatrixPassR13(uintptr_t a){bool target=dcpBuilderEnterR13(a);uintptr_t result=dcpOriginalAltMatrixR13(a);DWORD error=GetLastError();dcpCountR13(a,2);if(target)--dcpBuilderDepthR13;SetLastError(error);return result;}
static uintptr_t __fastcall dcpExtraMatrixPassR13(uintptr_t a){bool target=dcpBuilderEnterR13(a);uintptr_t result=dcpOriginalExtraMatrixR13(a);DWORD error=GetLastError();dcpCountR13(a,3);if(target)--dcpBuilderDepthR13;SetLastError(error);return result;}
static bool dcpFlagR13(void){
 char bytes[64]={0},expected[64]={0};DWORD n=0;LARGE_INTEGER size;HANDLE f=CreateFileW(PROBE_PATH(L"\\donor-completed-pose.enable"),GENERIC_READ,FILE_SHARE_READ|FILE_SHARE_WRITE|FILE_SHARE_DELETE,NULL,OPEN_EXISTING,FILE_ATTRIBUTE_NORMAL,NULL);
 if(f==INVALID_HANDLE_VALUE)return false;
 bool valid=GetFileSizeEx(f,&size)&&size.QuadPart>0&&size.QuadPart<64&&ReadFile(f,bytes,(DWORD)size.QuadPart,&n,NULL)&&n==(DWORD)size.QuadPart;CloseHandle(f);
 if(!valid)return false;while(n&&(bytes[n-1]=='\n'||bytes[n-1]=='\r'))bytes[--n]=0;
 DWORD owner=bridgeU32(lifetimeIdentity+16);if(!owner)return false;int count=snprintf(expected,sizeof(expected),"native-skeleton:%lu",owner);return count>0&&(DWORD)count==n&&!memcmp(bytes,expected,n);
}
static void donorCompletedPoseTick(void){
 if(!dcpInstalledR13||!dcpSharedR13)return;
 uint64_t now=GetTickCount64();bool requested=lifetimeBudgetStatus(now)==1&&dcpFlagR13();
 bool active=InterlockedCompareExchange(&dcpActiveR13,0,0)!=0;
 bool changed=active&&memcmp(dcpLeaseR13,lifetimeIdentity,sizeof(dcpLeaseR13));
 if((!requested||changed)&&active){InterlockedExchange(&dcpActiveR13,0);InterlockedExchange(&dcpSharedR13->revoked,1);active=false;}
 if(!requested)return;
 if(active&&dcpSharedR13->revoked&&!InterlockedCompareExchange(&dcpLockR13,1,0)){
  dcpInvalidateR13(108);InterlockedExchange(&dcpSharedR13->revoked,0);InterlockedExchange(&dcpLockR13,0);
 }
 if(!active&&!InterlockedCompareExchange(&dcpLockR13,1,0)){
  memcpy(dcpLeaseR13,lifetimeIdentity,sizeof(dcpLeaseR13));InterlockedExchange64(&dcpEpochR13,(LONG64)now);dcpInvalidateR13(100);
  InterlockedExchange(&dcpActiveR13,1);InterlockedExchange(&dcpSharedR13->revoked,0);InterlockedExchange(&dcpLockR13,0);
  logLine("DONOR_COMPLETED_POSE enabled=1 epoch=%llu; native pass return publication, RAM only",now);
 }
}
static void donorCompletedPoseInstall(HMODULE module){
 if(!module||dcpInstalledR13)return;
 const Sheet_donorCompletedPosePolicy *p=&sheet_donorCompletedPosePolicy_native_pass;
 if(p->version!=DONOR_COMPLETED_POSE_VERSION_R13||p->maxMatrices!=128||p->readAttempts!=3||p->freshMs!=150||p->leaseMs!=1500||p->enabled||p->gameWrites||p->syntheticCalls)return;
 const Sheet_donorCompletedPoseHook *proof[6]={&sheet_donorCompletedPoseHook_alternate_pass,&sheet_donorCompletedPoseHook_game_pass,&sheet_donorCompletedPoseHook_prepare,&sheet_donorCompletedPoseHook_matrix,&sheet_donorCompletedPoseHook_alternate_matrix,&sheet_donorCompletedPoseHook_extra_matrix};
 PVOID detours[6]={(PVOID)dcpAlternatePassR13,(PVOID)dcpGamePassR13,(PVOID)dcpPreparePassR13,(PVOID)dcpMatrixPassR13,(PVOID)dcpAlternateMatrixPassR13,(PVOID)dcpExtraMatrixPassR13};
 PVOID *originals[6]={(PVOID *)&dcpOriginalAlternateR13,(PVOID *)&dcpOriginalGameR13,(PVOID *)&dcpOriginalPrepareR13,(PVOID *)&dcpOriginalMatrixR13,(PVOID *)&dcpOriginalAltMatrixR13,(PVOID *)&dcpOriginalExtraMatrixR13};
 unsigned char header[4096],body[4450];char actual[65],expected[65];LARGE_INTEGER frequency;uint32_t nt=0,imageSize=0;
 if(!worldRead((uintptr_t)module,header,sizeof(header))||header[0]!='M'||header[1]!='Z')return;memcpy(&nt,header+0x3c,4);
 if(nt>sizeof(header)-0x54||memcmp(header+nt,"PE\0\0",4))return;memcpy(&imageSize,header+nt+0x50,4);
 if(imageSize<0x17c2e18||!bridgeProcessCreation(GetCurrentProcess(),&dcpBirthR13)||!QueryPerformanceFrequency(&frequency)||frequency.QuadPart<=0)return;
 for(unsigned k=0;k<6;k++)if(proof[k]->arguments!=(k?1:0)||proof[k]->bytes<=0||proof[k]->bytes>(int64_t)sizeof(body)||proof[k]->rva<=0||proof[k]->rva+proof[k]->bytes>imageSize||
 !worldRead((uintptr_t)module+(uintptr_t)proof[k]->rva,body,(SIZE_T)proof[k]->bytes)||!hashBytes(body,(ULONG)proof[k]->bytes,actual)||!WideCharToMultiByte(CP_UTF8,0,proof[k]->sha256,-1,expected,65,NULL,NULL)||strcmp(actual,expected)){
  logLine("DONOR_COMPLETED_POSE code proof failed index=%u; installer disabled",k);return;
 }
 MH_STATUS initialized=MH_Initialize();if(initialized!=MH_OK&&initialized!=MH_ERROR_ALREADY_INITIALIZED)return;
 unsigned created=0;bool ready=true;
 for(unsigned k=0;k<6;k++){dcpTargetsR13[k]=(PVOID)((uintptr_t)module+(uintptr_t)proof[k]->rva);if(MH_CreateHook(dcpTargetsR13[k],detours[k],originals[k])!=MH_OK){ready=false;break;}++created;}
 if(!ready){for(unsigned k=0;k<created;k++)MH_RemoveHook(dcpTargetsR13[k]);memset(dcpTargetsR13,0,sizeof(dcpTargetsR13));return;}
 wchar_t name[96];donorCompletedPoseNameR13(name,GetCurrentProcessId());dcpMappingR13=CreateFileMappingW(INVALID_HANDLE_VALUE,NULL,PAGE_READWRITE,0,sizeof(DonorCompletedPoseSharedR13),name);
 if(!dcpMappingR13||GetLastError()==ERROR_ALREADY_EXISTS)ready=false;
 if(ready)dcpSharedR13=MapViewOfFile(dcpMappingR13,FILE_MAP_READ|FILE_MAP_WRITE,0,0,sizeof(*dcpSharedR13));
 if(!dcpSharedR13)ready=false;
 if(ready){dcpBaseR13=(uintptr_t)module;dcpImageSizeR13=imageSize;dcpFrequencyR13=(uint64_t)frequency.QuadPart;dcpInvalidateR13(100);for(unsigned k=0;k<6;k++)if(MH_QueueEnableHook(dcpTargetsR13[k])!=MH_OK)ready=false;}
 if(ready)ready=MH_ApplyQueued()==MH_OK;
 if(!ready){for(unsigned k=0;k<created;k++){MH_DisableHook(dcpTargetsR13[k]);MH_RemoveHook(dcpTargetsR13[k]);}if(dcpSharedR13){UnmapViewOfFile(dcpSharedR13);dcpSharedR13=NULL;}if(dcpMappingR13){CloseHandle(dcpMappingR13);dcpMappingR13=NULL;}memset(dcpTargetsR13,0,sizeof(dcpTargetsR13));return;}
 dcpInstalledR13=true;logLine("DONOR_COMPLETED_POSE installed=1 hooks=6; isolated from collision hook, inactive until owned lease");
}
static void donorCompletedPoseStop(void){
 InterlockedExchange(&dcpActiveR13,0);if(dcpSharedR13)InterlockedExchange(&dcpSharedR13->revoked,1);
 // Keep trampolines and mapping pinned until process exit: no callback UAF.
 // With publication disabled these hooks only forward each original once.
}
