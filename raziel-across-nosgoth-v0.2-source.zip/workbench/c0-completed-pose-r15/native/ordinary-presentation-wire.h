// SPDX-License-Identifier: GPL-3.0-or-later
#pragma once
#include <windows.h>
#include <stdint.h>
#include <stdbool.h>
#include <stddef.h>
#include <string.h>

enum { ORDINARY_PRESENTATION_MAGIC=0x3150524f, ORDINARY_PRESENTATION_VERSION=1,
       ORDINARY_PRESENTATION_RECEIPT_BYTES=3656, ORDINARY_PRESENTATION_SHARED_BYTES=3664 };
enum OrdinaryPresentationRefusal {
 ORDINARY_PRESENTATION_OK=0, ORDINARY_PRESENTATION_DISABLED=1,
 ORDINARY_PRESENTATION_SCOPE=2, ORDINARY_PRESENTATION_PACKET=3,
 ORDINARY_PRESENTATION_IDENTITY=4, ORDINARY_PRESENTATION_THREAD=5,
 ORDINARY_PRESENTATION_NATIVE_PACKET=6, ORDINARY_PRESENTATION_CONTEXT=7,
 ORDINARY_PRESENTATION_REENTRY=8, ORDINARY_PRESENTATION_REBASE=9,
 ORDINARY_PRESENTATION_WEAPON=10, ORDINARY_PRESENTATION_CHANGED=11
};
enum OrdinaryPresentationProof {
 ORDINARY_PRESENTATION_UNPROVED=0, ORDINARY_PRESENTATION_POSTCALL=1,
 ORDINARY_PRESENTATION_NO_CAPTURE=2, ORDINARY_PRESENTATION_POSTCALL_CHANGED=3
};
enum OrdinaryPresentationContext {
 ORDINARY_PRESENTATION_CONTEXT_IDENTITY=1, ORDINARY_PRESENTATION_FOREGROUND=2,
 ORDINARY_PRESENTATION_CROUCH=4, ORDINARY_PRESENTATION_VELOCITY_KNOWN=8,
 ORDINARY_PRESENTATION_GROUND_ALLOWED=16, ORDINARY_PRESENTATION_AIR_ALLOWED=32,
 ORDINARY_PRESENTATION_NATIVE_OWNED=64, ORDINARY_PRESENTATION_HELD=128
};
// Path:0 original native,1 original copy/warmup,2 linked ground,3 linked air,
// 4 native jump-exit blend. Path is the actual final argument4 choice.
// Floats stay in this adapter-owned RAM mapping. They must never be asset files.
#pragma pack(push,8)
typedef struct {
 uint32_t magic,version,bytes,valid;
 uint32_t hostPid,sourcePid,writerPid,threadId;
 uint32_t path,requestedMode,refusal,contextMask;
 uint64_t hostCreation,epoch,serial,tick,hostTick,sourceTick,packetSequence,drawSerial;
 uint64_t qpcBefore,qpcAfter,qpcFrequency,actor,object,model;
 uint32_t callbacks[3],hostMode,hostFlags;
 int32_t verticalVelocity;
 uint32_t proof,reserved;
 unsigned char policy[32];
 float forwarded[66][13];
} OrdinaryPresentationReceipt;
typedef struct {volatile LONG sequence;uint32_t reserved;OrdinaryPresentationReceipt receipt;} OrdinaryPresentationShared;
#pragma pack(pop)
_Static_assert(sizeof(OrdinaryPresentationReceipt)==3656,"ORP1 receipt size");
_Static_assert(sizeof(OrdinaryPresentationShared)==3664,"ORP1 shared size");
_Static_assert(offsetof(OrdinaryPresentationShared,receipt)==8,"ORP1 seqlock prefix");
_Static_assert(offsetof(OrdinaryPresentationReceipt,hostCreation)==48,"ORP1 identities");
_Static_assert(offsetof(OrdinaryPresentationReceipt,qpcBefore)==112,"ORP1 QPC");
_Static_assert(offsetof(OrdinaryPresentationReceipt,callbacks)==160,"ORP1 context");
_Static_assert(offsetof(OrdinaryPresentationReceipt,proof)==184,"ORP1 proof");
_Static_assert(offsetof(OrdinaryPresentationReceipt,policy)==192,"ORP1 policy");
_Static_assert(offsetof(OrdinaryPresentationReceipt,forwarded)==224,"ORP1 matrices");
static inline void ordinaryPresentationName(wchar_t name[96],DWORD pid){_snwprintf(name,96,L"Local\\LOKOrdinaryPresentation-%lu",pid);}
static inline bool ordinaryPresentationCopy(const OrdinaryPresentationShared *shared,OrdinaryPresentationReceipt *out){
 if(!shared||!out)return false;for(unsigned i=0;i<3;i++){LONG n=shared->sequence;if(n&1)continue;MemoryBarrier();memcpy(out,&shared->receipt,sizeof(*out));MemoryBarrier();if(n==shared->sequence)return true;}return false;
}
static inline void ordinaryPresentationStore(OrdinaryPresentationShared *shared,const OrdinaryPresentationReceipt *s){
 InterlockedIncrement(&shared->sequence);MemoryBarrier();memcpy(&shared->receipt,s,sizeof(*s));MemoryBarrier();InterlockedIncrement(&shared->sequence);
}
