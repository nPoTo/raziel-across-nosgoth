// SPDX-License-Identifier: GPL-3.0-or-later
#pragma once
#include "exploration-sheets.h"

typedef enum {
    C0_PICKUP_UNKNOWN,
    C0_PICKUP_PREFLIGHT_REFUSED,
    C0_PICKUP_ATTACHMENT_REFUSED,
    C0_PICKUP_BOTH_CLEAR
} C0PickupOutcome;

typedef struct {
    uint64_t epoch, attempt;
    uintptr_t actor, character, target;
    uint32_t thread;
} C0PickupScope;

typedef struct {
    uintptr_t target, payload, actor;
    uint32_t callerRva, message;
    uint16_t kind, response;
} C0PickupMessage;

typedef struct {
    C0PickupOutcome outcome;
    uint64_t epoch, attempt;
    uint16_t preflightResponse, attachmentResponse;
} C0PickupReceipt;

typedef enum {
    C0_RECEIPT_CLOSED,
    C0_RECEIPT_EXPECT_PREFLIGHT,
    C0_RECEIPT_IN_PREFLIGHT,
    C0_RECEIPT_EXPECT_ATTACHMENT,
    C0_RECEIPT_IN_ATTACHMENT,
    C0_RECEIPT_TERMINAL,
    C0_RECEIPT_INVALID
} C0PickupStage;

typedef struct {
    C0PickupScope scope;
    C0PickupReceipt receipt;
    uintptr_t payload;
    C0PickupStage stage;
} C0PickupTransaction;

static inline bool c0PickupSameScope(const C0PickupScope *a, const C0PickupScope *b) {
    return a && b && a->epoch == b->epoch && a->attempt == b->attempt && a->actor == b->actor &&
           a->character == b->character && a->target == b->target && a->thread == b->thread;
}

static inline bool c0PickupBegin(C0PickupTransaction *tx, const C0PickupScope *scope,
                                 uint32_t callerRva, int32_t section) {
    const Sheet_c0PickupReceipt *p = &sheet_c0PickupReceipt_c006;
    if (!tx) return false;
    if (tx->stage != C0_RECEIPT_CLOSED) {
        tx->stage = C0_RECEIPT_INVALID;
        return false;
    }
    if (callerRva != p->idleReturnRva || section != p->section ||
        !scope || !scope->epoch || !scope->attempt || !scope->actor || !scope->character ||
        !scope->target || scope->target == scope->actor || !scope->thread) return false;
    *tx = (C0PickupTransaction){.scope=*scope, .stage=C0_RECEIPT_EXPECT_PREFLIGHT};
    return true;
}

static inline bool c0PickupMatches(const C0PickupTransaction *tx, const C0PickupScope *scope,
                                   const C0PickupMessage *m, uint32_t expectedMessage) {
    return c0PickupSameScope(&tx->scope,scope) && m->message == expectedMessage &&
           m->target == tx->scope.target && m->actor == tx->scope.actor && m->payload &&
           m->kind == sheet_c0PickupReceipt_c006.payloadKind;
}

static inline bool c0PickupBefore(C0PickupTransaction *tx, const C0PickupScope *scope, const C0PickupMessage *m) {
    const Sheet_c0PickupReceipt *p = &sheet_c0PickupReceipt_c006;
    if (!tx || tx->stage == C0_RECEIPT_CLOSED) return false;
    if (!m) {
        tx->stage = C0_RECEIPT_INVALID;
        return false;
    }
    const bool preflight = m->callerRva == p->preflightReturnRva;
    if (!preflight && m->callerRva != p->attachReturnRva) return false;
    if (tx->stage != (preflight ? C0_RECEIPT_EXPECT_PREFLIGHT : C0_RECEIPT_EXPECT_ATTACHMENT) ||
        !c0PickupMatches(tx,scope,m,(uint32_t)(preflight ? p->preflightMessage : p->attachMessage)) ||
        m->response != (preflight ? p->preflightInitial : p->attachInitial)) {
        tx->stage = C0_RECEIPT_INVALID;
        return false;
    }
    tx->payload = m->payload;
    tx->stage = preflight ? C0_RECEIPT_IN_PREFLIGHT : C0_RECEIPT_IN_ATTACHMENT;
    return true;
}

static inline bool c0PickupAfter(C0PickupTransaction *tx, const C0PickupScope *scope, const C0PickupMessage *m) {
    const Sheet_c0PickupReceipt *p = &sheet_c0PickupReceipt_c006;
    if (!tx || tx->stage == C0_RECEIPT_CLOSED) return false;
    if (!m) {
        tx->stage = C0_RECEIPT_INVALID;
        return false;
    }
    const bool preflight = m->callerRva == p->preflightReturnRva;
    if (!preflight && m->callerRva != p->attachReturnRva) return false;
    if (tx->stage != (preflight ? C0_RECEIPT_IN_PREFLIGHT : C0_RECEIPT_IN_ATTACHMENT) ||
        !c0PickupMatches(tx,scope,m,(uint32_t)(preflight ? p->preflightMessage : p->attachMessage)) || m->payload != tx->payload) {
        tx->stage = C0_RECEIPT_INVALID;
        return false;
    }
    tx->payload = 0;
    if (preflight) {
        tx->receipt.preflightResponse = m->response;
        if (!m->response) {
            tx->stage = C0_RECEIPT_EXPECT_ATTACHMENT;
            return true;
        }
        tx->receipt.outcome = C0_PICKUP_PREFLIGHT_REFUSED;
    } else {
        tx->receipt.attachmentResponse = m->response;
        tx->receipt.outcome = m->response ? C0_PICKUP_ATTACHMENT_REFUSED : C0_PICKUP_BOTH_CLEAR;
    }
    tx->stage = C0_RECEIPT_TERMINAL;
    return true;
}

static inline C0PickupReceipt c0PickupFinish(C0PickupTransaction *tx, const C0PickupScope *scope, int32_t outerResult) {
    C0PickupReceipt result = {0};
    if (!tx) return result;
    if (tx->stage == C0_RECEIPT_TERMINAL && c0PickupSameScope(&tx->scope,scope) &&
        outerResult == sheet_c0PickupReceipt_c006.continuedOuterResult) {
        result = tx->receipt;
        result.epoch = tx->scope.epoch;
        result.attempt = tx->scope.attempt;
    }
    *tx = (C0PickupTransaction){0};
    return result;
}
