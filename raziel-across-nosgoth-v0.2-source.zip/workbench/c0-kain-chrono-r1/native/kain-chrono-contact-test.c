// SPDX-License-Identifier: GPL-3.0-or-later
#include <assert.h>
#include <stdio.h>
#include "kain-chrono-contact.h"

int main(void) {
    const uintptr_t base=0x10000000, common=base+0x990c0, message=base+0x95960;
    assert(kainChronoplastIdentity("kain____",-23395,1459,0x10002,base,common,message));
    assert(!kainChronoplastIdentity("kain____",-23395,4674,0x10002,base,common,message));
    assert(!kainChronoplastIdentity("kain____",-23378,1459,0x10002,base,common,message));
    assert(!kainChronoplastIdentity("walboss_",-23395,1459,0x10002,base,common,message));
    assert(!kainChronoplastIdentity("kain____",-23395,1459,0x10002,base,common,message+1));
    assert(kainChronoplastMelee(1,0,6) && kainChronoplastMelee(1,0,13));
    assert(!kainChronoplastMelee(1,0,1) && !kainChronoplastMelee(1,0,8));
    assert(!kainChronoplastMelee(1,1,13) && !kainChronoplastMelee(2,0,13));
    puts("Chronoplast Kain native contact: PASS");
}
