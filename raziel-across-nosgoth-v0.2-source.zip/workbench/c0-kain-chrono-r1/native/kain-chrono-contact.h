// SPDX-License-Identifier: GPL-3.0-or-later
#pragma once
#include <stdbool.h>
#include <stdint.h>
#include <string.h>
#include "kain-chrono-policy.h"

static inline bool kainChronoplastIdentity(const char name[9], int32_t stream, uint32_t intro,
    uint32_t type, uintptr_t base, uintptr_t collision, uintptr_t message) {
    return base && stream==CHRONO_KAIN_STREAM && intro==CHRONO_KAIN_INTRO && type==CHRONO_KAIN_TYPE &&
        collision==base+CHRONO_KAIN_COLLISION && message==base+CHRONO_KAIN_MESSAGE &&
        !memcmp(name,CHRONO_KAIN_NAME,9);
}

static inline bool kainChronoplastMelee(uint32_t realm, uint32_t airStrike, uint32_t state) {
    return realm==CHRONO_KAIN_REALM && !airStrike &&
        (state==CHRONO_KAIN_STATE_A || state==CHRONO_KAIN_STATE_B);
}
