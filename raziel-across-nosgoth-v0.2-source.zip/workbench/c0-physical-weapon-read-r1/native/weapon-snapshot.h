// SPDX-License-Identifier: GPL-3.0-or-later
#pragma once
#include <stddef.h>
#include <string.h>
#include "exploration-sheets.h"

_Static_assert(sizeof(uintptr_t) == 8, "The supported SR1 image is x64");

typedef bool (*WeaponRead)(void *, uintptr_t, void *, size_t);
typedef struct {
    void *context;
    WeaponRead read;
    uintptr_t base;
    uint32_t imageBytes;
} WeaponSource;

typedef struct {
    uintptr_t actor, object, name, head, reaver, effective, candidate, query, throwRef;
    uintptr_t callback[3];
    uint32_t realm, flags, type, pickupGate;
    int32_t segment;
} WeaponSnapshot;

static bool weaponReadAt(const WeaponSource *source, uintptr_t base, uint64_t offset,
                         void *value, size_t bytes) {
    return base >= 0x10000 && base <= 0x7fffffffffff &&
           offset <= 0x7fffffffffff - base && bytes <= 0x7fffffffffff - base - offset &&
           source->read(source->context, base + (uintptr_t)offset, value, bytes);
}

static bool weaponImageRead(const WeaponSource *source, uint64_t rva, void *value, size_t bytes) {
    return rva < source->imageBytes && bytes <= source->imageBytes - rva &&
           weaponReadAt(source, source->base, rva, value, bytes);
}

static bool weaponPointer(uintptr_t value) {
    return value >= 0x10000 && value <= 0x7fffffffffff && value % 8 == 0;
}

static bool weaponCode(const WeaponSource *source, uintptr_t address) {
    const Sheet_c0WeaponObservation *p = &sheet_c0WeaponObservation_observation;
    return address >= source->base && address - source->base >= (uint64_t)p->textBeginRva &&
           address - source->base < (uint64_t)p->textEndRva;
}

static int weaponHex(wchar_t c) {
    if (c >= L'0' && c <= L'9') return c - L'0';
    if (c >= L'a' && c <= L'f') return c - L'a' + 10;
    return -1;
}

static bool weaponImageMatches(const WeaponSource *source) {
    if (!weaponPointer(source->base) || source->imageBytes != sheet_c0WeaponObservation_observation.imageBytes)
        return false;
    for (size_t i = 0; i < sheet_c0WeaponAnchor_count; ++i) {
        const Sheet_c0WeaponAnchor *anchor = sheet_c0WeaponAnchor_rows[i];
        unsigned char bytes[48];
        size_t length = wcslen(anchor->hex);
        if (!length || length % 2 || length / 2 > sizeof(bytes) ||
            !weaponImageRead(source, anchor->rva, bytes, length / 2)) return false;
        for (size_t j = 0; j < length / 2; ++j) {
            int high = weaponHex(anchor->hex[2 * j]);
            int low = weaponHex(anchor->hex[2 * j + 1]);
            if (high < 0 || low < 0 || bytes[j] != (high << 4 | low)) return false;
        }
    }
    return true;
}

static bool weaponSnapshot(const WeaponSource *source, WeaponSnapshot *sample) {
    const Sheet_c0WeaponObservation *p = &sheet_c0WeaponObservation_observation;
    uintptr_t owner, parent, targets;
    char label[sizeof("raziel__")];
    memset(sample, 0, sizeof(*sample));
#define IMAGE(field, rva) weaponImageRead(source, (rva), &(field), sizeof(field))
#define FIELD(base, offset, field) weaponReadAt(source, (base), (offset), &(field), sizeof(field))
    if (!IMAGE(sample->actor, p->actorRva) || !weaponPointer(sample->actor) ||
        !IMAGE(owner, p->stateActorRva) || owner != sample->actor ||
        !FIELD(sample->actor, p->actorObjectOffset, sample->object) || !weaponPointer(sample->object) ||
        !FIELD(sample->object, p->objectNameOffset, sample->name) ||
        !FIELD(sample->name, 0, label) || memcmp(label, "raziel__", sizeof(label)) ||
        !IMAGE(sample->realm, p->realmRva) ||
        (sample->realm != p->materialRealm && sample->realm != p->spectralRealm) ||
        !IMAGE(sample->flags, p->interactionFlagsRva) || !IMAGE(sample->type, p->interactionTypeRva) ||
        !IMAGE(sample->pickupGate, p->pickupGateRva) || !IMAGE(sample->throwRef, p->throwRefRva) ||
        !IMAGE(sample->reaver, p->reaverRva) ||
        (sample->reaver && !weaponPointer(sample->reaver)) ||
        !FIELD(sample->actor, p->childOffset, sample->head) ||
        (sample->head && (!weaponPointer(sample->head) || sample->head == sample->actor))) return false;
    for (unsigned i = 0; i < 3; ++i) {
        if (!IMAGE(sample->callback[i], p->callbackRva + i * p->sectionStride) ||
            !weaponCode(source, sample->callback[i])) return false;
    }
    sample->effective = sample->head;
    if (sample->reaver && sample->head == sample->reaver &&
        (!FIELD(sample->head, p->parentOffset, parent) || parent != sample->actor ||
         !FIELD(sample->head, p->siblingOffset, sample->effective))) return false;
    if (sample->effective &&
        (!weaponPointer(sample->effective) || sample->effective == sample->actor ||
         sample->effective == sample->reaver ||
         !FIELD(sample->effective, p->parentOffset, parent) || parent != sample->actor ||
         !FIELD(sample->effective, p->segmentOffset, sample->segment) ||
         !FIELD(sample->effective, p->queryOffset, sample->query) ||
         (sample->query && !weaponCode(source, sample->query)))) return false;
    if ((sample->flags & (uint32_t)p->pickupMask) &&
        (!IMAGE(targets, p->targetsRva) || !weaponPointer(targets) ||
         !FIELD(targets, p->pickupTargetOffset, sample->candidate) ||
         (sample->candidate && !weaponPointer(sample->candidate)))) return false;
#undef FIELD
#undef IMAGE
    return true;
}

static bool weaponPair(const WeaponSource *source, WeaponSnapshot *out) {
    WeaponSnapshot first, second;
    memset(out, 0, sizeof(*out));
    if (!weaponSnapshot(source, &first) || !weaponSnapshot(source, &second) ||
        memcmp(&first, &second, sizeof(first))) return false;
    memcpy(out, &first, sizeof(first));
    return true;
}

static bool weaponSameActor(const WeaponSnapshot *a, const WeaponSnapshot *b) {
    return a->actor == b->actor && a->object == b->object && a->name == b->name && a->realm == b->realm;
}
