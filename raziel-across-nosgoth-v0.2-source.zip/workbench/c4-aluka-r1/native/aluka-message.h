// SPDX-License-Identifier: GPL-3.0-or-later
#pragma once
#include "aluka-message-policy.h"

static bool c2AcceptAlukaMessage(uintptr_t base, uintptr_t callback, const char name[9]) {
    if (callback != base + C2_ALUKA_MESSAGE_RVA || memcmp(name, C2_ALUKA_NAME, 9))
        return false;
    static const unsigned char expected[] = C2_ALUKA_MESSAGE_BYTES;
    unsigned char actual[sizeof(expected)];
    return worldRead(callback, actual, sizeof(actual)) && !memcmp(actual, expected, sizeof(actual));
}
