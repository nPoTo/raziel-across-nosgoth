// SPDX-License-Identifier: GPL-3.0-or-later
#include <assert.h>
#include <stdbool.h>
#include <stdint.h>
#include <stdio.h>
#include <string.h>
#include "aluka-message-policy.h"

static const uintptr_t base = 0x180000000ull;
static const unsigned char stock[] = C2_ALUKA_MESSAGE_BYTES;
static bool changed, readable = true;
static unsigned reads;
static bool worldRead(uintptr_t address, void *out, size_t size) {
    ++reads;
    if (!readable || address != base + C2_ALUKA_MESSAGE_RVA || size != sizeof(stock)) return false;
    memcpy(out, stock, size);
    if (changed) ((unsigned char *)out)[size - 1] ^= 1;
    return true;
}

#include "aluka-message.h"

int main(void) {
    const uintptr_t aluka = base + C2_ALUKA_MESSAGE_RVA;
    assert(!c2AcceptAlukaMessage(base, aluka, "alukabss") && !reads);
    assert(!c2AcceptAlukaMessage(base, aluka + 1, "aluka___") && !reads);
    assert(c2AcceptAlukaMessage(base, aluka, "aluka___") && reads == 1);
    changed = true;
    assert(!c2AcceptAlukaMessage(base, aluka, "aluka___"));
    readable = false;
    assert(!c2AcceptAlukaMessage(base, aluka, "aluka___"));
    puts("Aluka message admission: PASS");
}
