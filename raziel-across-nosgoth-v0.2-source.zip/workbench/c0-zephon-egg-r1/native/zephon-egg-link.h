// SPDX-License-Identifier: GPL-3.0-or-later
#pragma once
#include "zephon-egg-policy.h"

typedef enum { C0_EGG_NONE, C0_EGG_PICKUP, C0_EGG_FOLLOWUP } C0EggStage;

static C0EggStage c0ZephonEggStage(const WeaponSource *image, uintptr_t target, uintptr_t object,
                                   uintptr_t process, uintptr_t message) {
    if (message != image->base + ZEPHON_EGG_MESSAGE) return C0_EGG_NONE;

    const bool initial = process == image->base + ZEPHON_EGG_INITIAL;
    if (!initial && process != image->base + ZEPHON_EGG_HELD_A &&
        process != image->base + ZEPHON_EGG_HELD_B && process != image->base + ZEPHON_EGG_RELEASE &&
        process != image->base + ZEPHON_EGG_EXPIRY) return C0_EGG_NONE;

    const Sheet_c0WeaponObservation *obs = &sheet_c0WeaponObservation_observation;
    int32_t stream;
    uintptr_t name;
    char label[sizeof(ZEPHON_EGG_NAME)];
    if (!weaponReadAt(image, target, ZEPHON_EGG_STREAM_OFFSET, &stream, sizeof(stream)) ||
        stream != ZEPHON_EGG_STREAM ||
        !weaponReadAt(image, object, obs->objectNameOffset, &name, sizeof(name)) ||
        !weaponReadAt(image, name, 0, label, sizeof(label)) ||
        memcmp(label, ZEPHON_EGG_NAME, sizeof(label))) return C0_EGG_NONE;

    return initial ? C0_EGG_PICKUP : C0_EGG_FOLLOWUP;
}
