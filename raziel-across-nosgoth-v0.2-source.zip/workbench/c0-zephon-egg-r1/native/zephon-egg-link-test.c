// SPDX-License-Identifier: GPL-3.0-or-later
#include <assert.h>
#include <stdio.h>
#include <windows.h>

#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wunused-function"
#include "c0-physical-weapon-policy.h"
#include "../../c0-physical-weapon-read-r1/native/weapon-snapshot.h"
#include "../../c0-native-pickup-receipt-r1/native/pickup-receipt.h"
#include "zephon-pickup-link-state.generated.h"
#pragma clang diagnostic pop

enum { BASE = 0x10000, ACTOR = BASE, EGG = BASE + 0x400, OBJECT = BASE + 0x800,
       NAME = BASE + 0xa00, DESCRIPTOR = BASE + 0xb00, STATE = BASE + 0xc00 };
static unsigned char bytes[0xe00];

static bool readFixture(void *context, uintptr_t address, void *out, size_t size) {
    (void)context;
    if (address < BASE || address - BASE >= sizeof(bytes) || size > sizeof(bytes) - (address - BASE))
        return false;
    memcpy(out, bytes + address - BASE, size);
    return true;
}

#define SET(type, at, value) do { \
    const type data = (type)(value); \
    memcpy(bytes + (at) - BASE, &data, sizeof(data)); \
} while (0)

int main(void) {
    const Sheet_c0PickupLinkProof *p = &sheet_c0PickupLinkProof_physical;
    const Sheet_c0WeaponDescriptor *w = &sheet_c0WeaponDescriptor_supported;
    const Sheet_c0WeaponObservation *h = &sheet_c0WeaponObservation_observation;
    const WeaponSource image = {.read = readFixture, .base = BASE};
    const C0PickupScope scope = {.actor = ACTOR, .target = EGG};
    C0LinkState initial, current;

    SET(uint32_t, ACTOR + p->instanceIdOffset, 1);
    SET(uint32_t, EGG + p->instanceIdOffset, 2);
    SET(uintptr_t, EGG + h->actorObjectOffset, OBJECT);
    SET(uintptr_t, OBJECT + h->objectNameOffset, NAME);
    SET(uintptr_t, EGG + w->dataOffset, DESCRIPTOR);
    SET(uint16_t, DESCRIPTOR + w->familyOffset, p->family);
    SET(uint16_t, DESCRIPTOR + w->markerOffset, p->marker);
    SET(uintptr_t, EGG + p->stateOffset, STATE);
    SET(uintptr_t, EGG + p->queryOffset, BASE + p->queryRva);
    SET(uintptr_t, EGG + p->processOffset, BASE + ZEPHON_EGG_INITIAL);
    SET(uintptr_t, EGG + p->messageOffset, BASE + ZEPHON_EGG_MESSAGE);
    SET(int32_t, EGG + ZEPHON_EGG_STREAM_OFFSET, ZEPHON_EGG_STREAM);
    memcpy(bytes + NAME - BASE, "walbose_", sizeof("walbose_"));
    assert(c0LinkReadPair(&image, &scope, &initial));
    assert(initial.identity.eggStage == C0_EGG_PICKUP && c0LinkFresh(&initial));

    const uintptr_t followups[] = {ZEPHON_EGG_HELD_A, ZEPHON_EGG_HELD_B, ZEPHON_EGG_RELEASE, ZEPHON_EGG_EXPIRY};
    for (size_t i = 0; i < sizeof(followups) / sizeof(followups[0]); ++i) {
        SET(uintptr_t, EGG + p->processOffset, BASE + followups[i]);
        assert(c0LinkReadPair(&image, &scope, &current));
        assert(current.identity.eggStage == C0_EGG_FOLLOWUP && !c0LinkFresh(&current));
        assert(c0LinkSameIdentity(&initial.identity, &current.identity));
        current.identity.targetId++;
        assert(!c0LinkSameIdentity(&initial.identity, &current.identity));
    }

    SET(uintptr_t, EGG + p->processOffset, BASE + ZEPHON_EGG_INITIAL);
    SET(int32_t, EGG + ZEPHON_EGG_STREAM_OFFSET, ZEPHON_EGG_STREAM + 1);
    assert(!c0LinkReadPair(&image, &scope, &current));
    SET(int32_t, EGG + ZEPHON_EGG_STREAM_OFFSET, ZEPHON_EGG_STREAM);
    SET(uint16_t, DESCRIPTOR + w->markerOffset, 0);
    assert(!c0LinkReadPair(&image, &scope, &current));
    SET(uint16_t, DESCRIPTOR + w->markerOffset, p->marker);
    memcpy(bytes + NAME - BASE, "walbose_x", sizeof("walbose_x"));
    assert(!c0LinkReadPair(&image, &scope, &current));
    memcpy(bytes + NAME - BASE, "walbose", sizeof("walbose"));
    assert(!c0LinkReadPair(&image, &scope, &current));
    memcpy(bytes + NAME - BASE, "walbose_", sizeof("walbose_"));
    SET(uintptr_t, EGG + p->processOffset, BASE + ZEPHON_EGG_INITIAL + 1);
    assert(!c0LinkReadPair(&image, &scope, &current));

    SET(uintptr_t, EGG + p->processOffset, BASE + p->processRva);
    SET(uintptr_t, EGG + p->messageOffset, BASE + p->messageRva);
    assert(c0LinkReadPair(&image, &scope, &current));
    assert(current.identity.eggStage == C0_EGG_NONE && c0LinkFresh(&current));
    assert(!c0LinkSameIdentity(&initial.identity, &current.identity));
    puts("Zephon egg native link: PASS");
}
