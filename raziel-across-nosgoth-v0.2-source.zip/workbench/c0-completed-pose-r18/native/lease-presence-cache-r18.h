// SPDX-License-Identifier: GPL-3.0-or-later
#pragma once
#include <stdbool.h>
#include <stdint.h>
enum {SR1_LEASE_PRESENCE_PATHS=6,SR1_LEASE_PRESENCE_MAX_US=8000};
typedef struct {
 bool valid,requested,missing;
 uint64_t frame,counter,lastCounter,frequency;
} Sr1LeasePresenceCache;
// Cache only raw pathname observations. All gameplay/lease verdicts stay live.
static inline bool sr1LeasePresenceReusable(const Sr1LeasePresenceCache *s,uint64_t frame,uint64_t counter,uint64_t frequency,bool clockValid,uint64_t maxMicros){
 if(!s||!s->valid||!clockValid||!frequency||!maxMicros||s->frame!=frame||s->frequency!=frequency||counter<s->counter||counter<s->lastCounter)return false;
 uint64_t age=counter-s->counter;
 if(age>UINT64_MAX/1000000u||frequency>UINT64_MAX/maxMicros)return false;
 return age*1000000u<frequency*maxMicros;
}
