// SPDX-License-Identifier: GPL-3.0-or-later
#pragma once
#include "sr1-weapon-session.h"
#include "guidance-plan.h"
static SRWLOCK sr1SkeletonVisibilityLock=SRWLOCK_INIT;
static Sr1WeaponSession sr1SkeletonVisibilitySession;
static bool sr1SkeletonVisibilityScope(uintptr_t actor){
 const Sheet_nativeHandoffVisibilityPolicy *p=&sheet_nativeHandoffVisibilityPolicy_bounded_session;
 if(p->plan!=13||(p->seconds!=100&&p->seconds!=120&&p->seconds!=170)||!p->includePreparation||!p->includeNativeActions||!p->includeFinalNative||!p->requireGuidanceAndHeartbeat||!p->requireOriginalModel||!p->poseAdmissionIndependent||!p->sourceFreshnessIndependent||!p->restoreOnSessionEnd||p->enabled)return false;
 bool requested=false;
 uint32_t writer=0;uint64_t session=0,begin=0;
 bool healthy=sr1SkeletonGuidanceLease(&writer,&session,&begin,&requested);
 uintptr_t base=(uintptr_t)InterlockedCompareExchangePointer(&verifiedSr1Module,NULL,NULL),owner=0,object=0,list=0,model=0,again=0;int16_t index=-1,indexAfter=-1;int32_t count=0;bool original=false;
 // The native actor/model identity is stable across native animation states;
 // no changing transform matrix or source packet is needed to own visibility.
 if(base&&actor&&worldActorRead(base,&owner)&&owner==actor&&worldRead(actor+0x1c6,&index,2)&&!index&&
    worldRead(actor+0x30,&object,8)&&object&&worldRead(object+0x10,&list,8)&&list&&worldRead(list,&model,8)&&model&&worldRead(model+0x30,&count,4)&&count==66&&
    worldRead(actor+0x30,&again,8)&&again==object&&worldRead(object+0x10,&again,8)&&again==list&&worldRead(list,&again,8)&&again==model&&
    worldRead(actor+0x1c6,&indexAfter,2)&&indexAfter==index&&worldRead(base+0x2a89310,&again,8)&&again==actor)original=true;
 Sr1WeaponSessionObservation o={.requested=requested,.healthy=healthy,.complete=InterlockedCompareExchange(&probeBoundedComplete,0,0)!=0,.originalModel=original,.writer=writer,.session=session,.begin=begin,.actor=actor,.object=object,.model=model};
 AcquireSRWLockExclusive(&sr1SkeletonVisibilityLock);
 // Concurrent native/GL consumers must serialize their clock receipt with the
 // ownership update, rather than mistake scheduling order for a clock rewind.
 o.now=GetTickCount64();
 // The HUD's existing wall budget includes first-visible-ack startup margin.
 // Active completed/total heartbeat and owned flags still end visibility at
 // the actual timeline boundary; this never extends heartbeat freshness.
 bool allowed=sr1WeaponSessionStep(&sr1SkeletonVisibilitySession,&o,tutorialWallBudgetMs((unsigned)p->seconds));
 ReleaseSRWLockExclusive(&sr1SkeletonVisibilityLock);return allowed;
}
static bool sr1SkeletonCurrentVisibility(void){uintptr_t player=0,base=(uintptr_t)InterlockedCompareExchangePointer(&verifiedSr1Module,NULL,NULL);return base&&worldActorRead(base,&player)&&sr1SkeletonVisibilityScope(player);}
