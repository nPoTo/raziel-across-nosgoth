// SPDX-License-Identifier: GPL-3.0-or-later
#pragma once
#include "sr1-weapon-guidance.h"
#include "lease-presence-cache-r18.h"
#include "r18-policy.h"
static SRWLOCK sr1SkeletonGuidanceLock=SRWLOCK_INIT;
static Sr1WeaponGuidance sr1SkeletonGuidance;
static uint64_t sr1SkeletonGuidancePoll;
static Sr1LeasePresenceCache sr1SkeletonPresence;
static bool sr1SkeletonLeaseFile(const wchar_t *path,void *out,DWORD bytes,bool *missing,bool *invalid){
 HANDLE f=CreateFileW(path,GENERIC_READ,FILE_SHARE_READ|FILE_SHARE_WRITE|FILE_SHARE_DELETE,NULL,OPEN_EXISTING,FILE_ATTRIBUTE_NORMAL,NULL);
 if(f==INVALID_HANDLE_VALUE){DWORD error=GetLastError();*missing|=error==ERROR_FILE_NOT_FOUND||error==ERROR_PATH_NOT_FOUND;return false;}
 LARGE_INTEGER size;DWORD count=0;bool ok=GetFileSizeEx(f,&size)!=0;
 if(ok&&size.QuadPart!=bytes){*invalid=true;ok=false;}
 if(ok)ok=ReadFile(f,out,bytes,&count,NULL)&&count==bytes;
 CloseHandle(f);return ok;
}
// Called only under sr1SkeletonGuidanceLock. Sampling precedes filesystem I/O:
// a slow query cannot reset the eight-millisecond reuse window after it returns.
static void sr1SkeletonPresenceRead(const wchar_t *statusPath,const wchar_t *descriptorPath,bool *requested,bool *missing){
 const Sheet_visibilityPresenceSnapshot *p=&sheet_visibilityPresenceSnapshot_bounded_request_paths;
 bool configured=p->presencePathCount==SR1_LEASE_PRESENCE_PATHS&&p->maxReuseMicros==SR1_LEASE_PRESENCE_MAX_US&&
  p->invalidateOnSwap&&p->clockFailureRefresh&&p->timestampBeforeRead&&!p->cacheVisibilityResult&&!p->cacheGlState&&!p->requirePoseSourceFreshness;
 LARGE_INTEGER frequency={0},counter={0};
 bool clockValid=configured&&QueryPerformanceFrequency(&frequency)&&frequency.QuadPart>0&&
  (uint64_t)frequency.QuadPart<=UINT64_MAX/SR1_LEASE_PRESENCE_MAX_US&&QueryPerformanceCounter(&counter)&&counter.QuadPart>=0;
 if(clockValid&&sr1SkeletonPresence.valid&&(uint64_t)counter.QuadPart<sr1SkeletonPresence.lastCounter)clockValid=false;
 uint64_t frame=(uint64_t)InterlockedCompareExchange64(&swapCalls,0,0);
 if(sr1LeasePresenceReusable(&sr1SkeletonPresence,frame,(uint64_t)counter.QuadPart,(uint64_t)frequency.QuadPart,clockValid,SR1_LEASE_PRESENCE_MAX_US)){
  sr1SkeletonPresence.lastCounter=(uint64_t)counter.QuadPart;
  *requested=sr1SkeletonPresence.requested;*missing=sr1SkeletonPresence.missing;return;
 }
 Sr1LeasePresenceCache fresh={.valid=clockValid,.frame=frame,.counter=(uint64_t)counter.QuadPart,.lastCounter=(uint64_t)counter.QuadPart,.frequency=(uint64_t)frequency.QuadPart,.requested=true};
 const wchar_t *names[]={L"\\sr1-skeleton.enable",L"\\hide-reaver-sr1.enable",L"\\hide-reaver-light-sr1.enable",L"\\hide-reaver-ribbon-sr1.enable"};
 for(unsigned i=0;i<4;i++)if(GetFileAttributesW(PROBE_PATH(names[i]))==INVALID_FILE_ATTRIBUTES)fresh.requested=false;
 const wchar_t *paths[]={statusPath,descriptorPath};
 for(unsigned i=0;i<2;i++)if(GetFileAttributesW(paths[i])==INVALID_FILE_ATTRIBUTES){DWORD e=GetLastError();fresh.missing|=e==ERROR_FILE_NOT_FOUND||e==ERROR_PATH_NOT_FOUND;}
 sr1SkeletonPresence=fresh;*requested=fresh.requested;*missing=fresh.missing;
}
// Existing immutable descriptor/HUD/heartbeat authority; only six pathname
// observations have bounded reuse. Never reuse or renew an allowed verdict.
static bool sr1SkeletonGuidanceLease(uint32_t *writer,uint64_t *session,uint64_t *begin,bool *requested){
 if(requested)*requested=false;
 if(!writer||!session||!begin||!requested||(guidanceSeconds(13)!=100&&guidanceSeconds(13)!=120&&guidanceSeconds(13)!=170))return false;
 AcquireSRWLockExclusive(&sr1SkeletonGuidanceLock);
 uint64_t now=GetTickCount64();bool active=guidanceRefresh();
 Sr1WeaponGuidanceObservation o={.pid=GetCurrentProcessId(),.now=now,.hudActive=active,.hudPlan=guidancePlan,.hudWriter=guidanceWriter,.hudSession=guidanceSession,.hudBegin=guidanceBegin};
 wchar_t statusPath[512],descriptorPath[512];recordingStatusPath(statusPath,o.pid);_snwprintf(descriptorPath,512,PROBE_PATH(L"\\guidance-%lu.bin"),o.pid);
 sr1SkeletonPresenceRead(statusPath,descriptorPath,requested,&o.missing);
 if(!sr1SkeletonGuidancePoll||now<sr1SkeletonGuidancePoll||now-sr1SkeletonGuidancePoll>=100){
  sr1SkeletonGuidancePoll=now;
  o.descriptorRead=sr1SkeletonLeaseFile(descriptorPath,&o.descriptor,sizeof(o.descriptor),&o.missing,&o.invalidShape);
  o.statusRead=sr1SkeletonLeaseFile(statusPath,&o.status,sizeof(o.status),&o.missing,&o.invalidShape);
 }
 bool allowed=sr1WeaponGuidanceStep(&sr1SkeletonGuidance,&o);
 if(allowed){*writer=sr1SkeletonGuidance.writer;*session=sr1SkeletonGuidance.session;*begin=sr1SkeletonGuidance.begin;}
 ReleaseSRWLockExclusive(&sr1SkeletonGuidanceLock);return allowed;
}
