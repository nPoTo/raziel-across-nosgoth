// SPDX-License-Identifier: GPL-3.0-or-later
#pragma once
#include "r27-policy.h"

typedef void (*C0NativeTeardownR27)(uintptr_t list, uint32_t mask);
static C0NativeTeardownR27 sr1C0TeardownOriginal;
static PVOID sr1C0TeardownTarget;
static volatile LONG sr1C0TeardownAttempted, sr1C0TeardownEnabled;
static _Thread_local unsigned sr1C0TeardownDepth;

static bool sr1C0TeardownCurrentTicket(C0UnlinkTicketR26 *out) {
    if (!InterlockedCompareExchange(&sr1C0TeardownEnabled, 0, 0) ||
        !TryAcquireSRWLockShared(&sr1C0UnlinkLock)) return false;
    const bool valid = !sr1C0UnlinkReceipt.tick && sr1C0UnlinkLease(&sr1C0UnlinkTicket);
    if (valid) *out = sr1C0UnlinkTicket;
    ReleaseSRWLockShared(&sr1C0UnlinkLock);
    return valid;
}

static bool sr1C0TeardownMarked(const WeaponSource *source, const C0UnlinkTicketR26 *ticket) {
    const Sheet_c0NativeRetireR27 *p = &sheet_c0NativeRetireR27_observed;
    const Sheet_c0PickupLinkProof *link = &sheet_c0PickupLinkProof_physical;
    uint32_t generation, flags;
    return weaponReadAt(source, ticket->weapon, link->instanceIdOffset, &generation, sizeof(generation)) &&
        generation == ticket->identity.targetId &&
        weaponReadAt(source, ticket->weapon, p->instanceFlagsOffset, &flags, sizeof(flags)) &&
        (flags & (uint32_t)p->pendingRemovalMask) && !(flags & (uint32_t)p->protectedMask);
}

static bool sr1C0TeardownList(const WeaponSource *source, uintptr_t list,
                             const C0UnlinkTicketR26 *ticket, bool before) {
    const Sheet_c0NativeRetireR27 *p = &sheet_c0NativeRetireR27_observed;
    const Sheet_c0PickupLinkProof *link = &sheet_c0PickupLinkProof_physical;
    uintptr_t liveList, head;
    uint32_t count;
    if (!weaponPointer(list) ||
        !weaponImageRead(source, link->instanceListRva, &liveList, sizeof(liveList)) || liveList != list ||
        !weaponReadAt(source, list, p->listCountOffset, &count, sizeof(count)) || !count ||
        count > (uint32_t)p->listLimit ||
        !weaponReadAt(source, list, p->listHeadOffset, &head, sizeof(head))) return false;

    bool actorFound = false, weaponFound = false;
    uintptr_t node = head, previous = 0;
    for (uint32_t index = 0; index < count; ++index) {
        uintptr_t backlink, next;
        if (!weaponPointer(node) ||
            !weaponReadAt(source, node, p->listPrevOffset, &backlink, sizeof(backlink)) || backlink != previous ||
            !weaponReadAt(source, node, p->listNextOffset, &next, sizeof(next))) return false;
        if (node == ticket->actor || node == ticket->weapon) {
            const bool actor = node == ticket->actor;
            const uint32_t expected = actor ? ticket->identity.actorId : ticket->identity.targetId;
            uint32_t generation;
            if ((!actor && !before) ||
                !weaponReadAt(source, node, link->instanceIdOffset, &generation, sizeof(generation)) ||
                generation != expected) return false;
            if (actor) actorFound = true;
            else weaponFound = true;
        }
        previous = node;
        node = next;
    }

    uintptr_t finalHead, finalList;
    uint32_t finalCount;
    return !node && actorFound && weaponFound == before &&
        weaponReadAt(source, list, p->listHeadOffset, &finalHead, sizeof(finalHead)) && finalHead == head &&
        weaponReadAt(source, list, p->listCountOffset, &finalCount, sizeof(finalCount)) && finalCount == count &&
        weaponImageRead(source, link->instanceListRva, &finalList, sizeof(finalList)) && finalList == list;
}

static bool sr1C0TeardownReset(const WeaponSource *source, uintptr_t weapon) {
    const Sheet_c0WeaponObservation *p = &sheet_c0WeaponObservation_observation;
    const Sheet_c0PickupLinkProof *link = &sheet_c0PickupLinkProof_physical;
    uint32_t generation;
    uintptr_t parent, sibling;
    return weaponReadAt(source, weapon, link->instanceIdOffset, &generation, sizeof(generation)) && !generation &&
        weaponReadAt(source, weapon, p->parentOffset, &parent, sizeof(parent)) && !parent &&
        weaponReadAt(source, weapon, p->siblingOffset, &sibling, sizeof(sibling)) && !sibling;
}

static void sr1C0ObserveTeardown(uintptr_t list, uint32_t mask) {
    const DWORD entryError = GetLastError();
    const bool outer = sr1C0TeardownDepth++ == 0;
    const Sheet_c0WeaponObservation *p = &sheet_c0WeaponObservation_observation;
    const WeaponSource source = {NULL, sr1C0UnlinkRead, sr1C0UnlinkBase, (uint32_t)p->imageBytes};
    C0UnlinkTicketR26 ticket;
    const bool observing = outer && sr1C0TeardownCurrentTicket(&ticket) && sr1C0TeardownMarked(&source, &ticket);
    C0RawContact contact;
    WeaponSnapshot before;
    unsigned stage = 0;
    if (observing) {
        const C0PickupScope scope = {.actor=ticket.actor,.target=ticket.weapon};
        const C0LinkTicket linkTicket = {.scope=scope,.identity=ticket.identity};
        C0LinkState link;
        stage = 24;
        if (sr1C0ReadContact(ticket.actor, ticket.epoch, GetTickCount64(), &contact) &&
            contact.sequence >= ticket.acquisitionStep) {
            stage = 25;
            if (weaponPair(&source, &before) && before.actor == ticket.actor && before.realm == p->materialRealm &&
                c0LinkReciprocal(&linkTicket, &before) && c0LinkReadPair(&source, &scope, &link) &&
                link.parent == ticket.actor && c0LinkSameIdentity(&ticket.identity, &link.identity)) {
                stage = 26;
                if (sr1C0TeardownList(&source, list, &ticket, true) && sr1C0TeardownMarked(&source, &ticket))
                    stage = 27;
            }
        }
    }

    SetLastError(entryError);
    sr1C0TeardownOriginal(list, mask);
    const DWORD originalError = GetLastError();

    if (observing) {
        C0UnlinkReceiptR26 receipt = {0};
        if (stage == 27) {
            const uint64_t eventTick = GetTickCount64();
            WeaponSnapshot after;
            C0RawContact latest;
            if (InterlockedCompareExchange(&sr1C0TeardownEnabled, 0, 0) && sr1C0UnlinkLease(&ticket) &&
                sr1C0TeardownReset(&source, ticket.weapon) &&
                weaponPair(&source, &after) && weaponSameActor(&before, &after) && after.realm == before.realm &&
                !after.effective && sr1C0TeardownList(&source, list, &ticket, false) &&
                sr1C0TeardownReset(&source, ticket.weapon) &&
                sr1C0ReadContact(ticket.actor, ticket.epoch, eventTick, &latest) &&
                latest.sequence >= contact.sequence) receipt = (C0UnlinkReceiptR26){eventTick, latest.sequence};
        }
        sr1C0UnlinkRecord(&ticket, stage, receipt);
    }
    --sr1C0TeardownDepth;
    SetLastError(originalError);
}

static void sr1C0TeardownInstall(HMODULE module) {
    if (InterlockedCompareExchange(&sr1C0TeardownAttempted, 1, 0)) return;
    const Sheet_c0NativeRetireR27 *p = &sheet_c0NativeRetireR27_observed;
    unsigned char bytes[962];
    char digest[65];
    MEMORY_BASIC_INFORMATION memory;
    const uintptr_t target = (uintptr_t)module + (uintptr_t)p->targetRva;
    const bool verified = module && InterlockedCompareExchangePointer(&verifiedSr1Module, NULL, NULL) == module &&
        (uintptr_t)module == sr1C0UnlinkBase && InterlockedCompareExchange(&sr1C0UnlinkEnabled, 0, 0) &&
        p->targetRva == 0x768c0 && p->targetBytes == sizeof(bytes) &&
        !wcscmp(p->moduleSha256, sheet_c0WeaponObservation_observation.moduleSha256);
    const bool executable = verified && VirtualQuery((const void *)target, &memory, sizeof(memory)) == sizeof(memory) &&
        memory.AllocationBase == module && memory.State == MEM_COMMIT &&
        (memory.Protect == PAGE_EXECUTE_READ || memory.Protect == PAGE_EXECUTE_READWRITE ||
         memory.Protect == PAGE_EXECUTE_WRITECOPY) && target >= (uintptr_t)memory.BaseAddress &&
        sizeof(bytes) <= memory.RegionSize && target - (uintptr_t)memory.BaseAddress <= memory.RegionSize - sizeof(bytes);
    bool match = executable && worldRead(target, bytes, sizeof(bytes)) &&
        hashBytes(bytes, sizeof(bytes), digest) && strlen(digest) == 64;
    for (unsigned i = 0; match && i < 64; ++i) match = p->codeSha256[i] == (wchar_t)digest[i];
    MH_STATUS create = MH_UNKNOWN, enable = MH_UNKNOWN;
    if (match && !p->codeSha256[64]) {
        create = MH_CreateHook((PVOID)target, (PVOID)&sr1C0ObserveTeardown, (PVOID *)&sr1C0TeardownOriginal);
        if (create == MH_OK) {
            sr1C0TeardownTarget = (PVOID)target;
            enable = MH_EnableHook(sr1C0TeardownTarget);
            if (enable == MH_OK) InterlockedExchange(&sr1C0TeardownEnabled, 1);
        }
    }
    logLine("C0_NATIVE_TEARDOWN_INSTALL active=%u module=%u executable=%u body=%u create=%d enable=%d",
        enable == MH_OK, verified, executable, match, create, enable);
}

static void sr1C0TeardownStop(void) {
    if (InterlockedExchange(&sr1C0TeardownEnabled, 0) && sr1C0TeardownTarget) {
        const MH_STATUS status = MH_DisableHook(sr1C0TeardownTarget);
        logLine("C0_NATIVE_TEARDOWN_STOP disable=%d", status);
    }
}
