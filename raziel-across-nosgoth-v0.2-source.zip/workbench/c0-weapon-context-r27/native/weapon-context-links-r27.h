// SPDX-License-Identifier: GPL-3.0-or-later
#pragma once
#include "r27-policy.h"

typedef struct {
    uintptr_t object, state, parent, sibling;
    uint32_t generation, flags;
} C0ContextLinkR27;

static bool sr1C0ReadContextLink(const WeaponSource *source, uintptr_t item,
                                const C0LinkIdentity *identity, C0ContextLinkR27 *link) {
    const Sheet_c0PickupLinkProof *p = &sheet_c0PickupLinkProof_physical;
    const Sheet_c0WeaponObservation *o = &sheet_c0WeaponObservation_observation;
    *link = (C0ContextLinkR27){0};
    return weaponReadAt(source, item, p->instanceIdOffset, &link->generation, sizeof(link->generation)) &&
        weaponReadAt(source, item, o->actorObjectOffset, &link->object, sizeof(link->object)) &&
        weaponReadAt(source, item, p->stateOffset, &link->state, sizeof(link->state)) &&
        weaponReadAt(source, item, o->parentOffset, &link->parent, sizeof(link->parent)) &&
        weaponReadAt(source, item, o->siblingOffset, &link->sibling, sizeof(link->sibling)) &&
        (link->state != identity->state ||
         weaponReadAt(source, link->state, p->pendingFlagsOffset, &link->flags, sizeof(link->flags)));
}

static bool sr1C0SameContextLink(const C0ContextLinkR27 *a, const C0ContextLinkR27 *b) {
    return a->generation == b->generation && a->object == b->object && a->state == b->state &&
        a->parent == b->parent && a->sibling == b->sibling && a->flags == b->flags;
}

static bool sr1C0ProveContextUnlink(const WeaponSource *source, const WeaponSnapshot *snapshot,
                                  const C0RawContact *contact, const C0WeaponInput *input, uint64_t now) {
    const uint64_t witness = sr1C0State.attackWitnessStep;
    if (sr1C0State.phase != C0_WEAPON_HELD || !sr1C0State.acquisitionStep ||
        witness < sr1C0State.acquisitionStep || contact->sequence <= witness ||
        contact->sequence - witness != (uint64_t)sheet_c0ContextLinkR27_adjacent.contactDelta ||
        input->held || !c0WeaponSafeThrowReference(input, sr1C0State.weapon) ||
        !sr1C0ContactSections(contact, input->callbacks[0])) return false;

    const uintptr_t item = sr1C0State.weapon;
    const C0LinkIdentity *identity = &sr1C0Identity;
    C0ContextLinkR27 first, last;
    C0RawContact latest;
    const bool read = sr1C0ReadContextLink(source, item, identity, &first);
    const bool generation = read && identity->targetId && first.generation == identity->targetId;
    const bool object = read && identity->object && first.object == identity->object;
    const bool state = read && identity->state && first.state == identity->state;
    const bool clear = read && !first.parent && !first.sibling;
    const bool pending = state && (first.flags & (uint32_t)sheet_c0PickupLinkProof_physical.pendingFlag);
    const bool bracket = generation && object && state && clear && !pending &&
        sr1C0SameWeaponSnapshot(source, snapshot) &&
        sr1C0ReadContextLink(source, item, identity, &last) && sr1C0SameContextLink(&first, &last) &&
        sr1C0ActorGeneration(source, input->actor, identity->actorId) &&
        sr1C0ReadContact(input->actor, input->epoch, now, &latest) && latest.sequence == contact->sequence &&
        latest.tick == contact->tick && latest.phase == contact->phase &&
        sr1C0ContactSections(&latest, input->callbacks[0]) &&
        sr1C0NativeActive(input->actor) && input->epoch == (uint64_t)InterlockedCompareExchange64(&sr1C0Epoch, 0, 0);
    logLine("C0_CONTEXT_UNLINK tick=%llu step=%llu witness=%llu proved=%u read=%u generation=%u object=%u state=%u clear=%u pending=%u",
        (unsigned long long)now, (unsigned long long)contact->sequence, (unsigned long long)witness,
        bracket, read, generation, object, state, clear, pending);
    return bracket;
}
