// SPDX-License-Identifier: GPL-3.0-or-later
#pragma once
#include <windows.h>
#include <stdint.h>
#include <stdbool.h>
#include <string.h>
#include "ordinary-input-proof-r17.h"
#define DUAL_INPUT_MAGIC 0x31494b44u
#ifdef SR1_PAUSE_R13
#include "pause-r13-shared.h"
#endif
typedef struct {uint32_t magic,version,host,donor,writer,device;uint64_t hostCreation,donorCreation,epoch;} DualInputSession;
typedef struct {uint64_t sequence,tick;uint32_t held,keys;int16_t x,y,rx,ry;uint8_t lt,rt,valid,menu;uint32_t nativeAxesTicket;} DualInputWire;
typedef struct {volatile LONG guard,revoked;DualInputSession session;DualInputWire sample;volatile LONG64 donorReady;volatile LONG64 hostFrames,donorFrames;
 volatile LONG64 hostActionEdges,hostLiftEdges,donorActionEdges,donorLiftEdges;
 volatile LONG64 eventSubmissions,eventAcknowledgments,eventRefusals;
 volatile LONG hostRawKeys,hostHeld,hostDelivered,donorHeld,donorMouse;
 volatile LONG hostPhysicalX,hostPhysicalY,hostRelayX,hostRelayY,donorRelayX,donorRelayY;
 volatile LONG hostAxisBlocked,donorAxisBlocked,hostPeerFresh,hostScopeValid,hostAxesResumes,donorAxesResumes;
#ifdef SR1_PAUSE_R13
 volatile LONG hostPauseGuard,donorPauseGuard;
 PauseSnapshotR13 hostPause,donorPause;
 volatile LONG pauseCloseRequested,pauseCloseAcknowledged;
#endif
 // Append only: all existing shared-prefix offsets and the40-byte wire stay fixed.
 OrdinaryInputProofR17 ordinaryProofR17;
} DualInputShared;
#ifdef SR1_PAUSE_R13
static inline void dualPauseStoreR13(DualInputShared *m,bool host,const PauseSnapshotR13 *s){
 volatile LONG *guard=host?&m->hostPauseGuard:&m->donorPauseGuard;PauseSnapshotR13 *at=host?&m->hostPause:&m->donorPause;
 InterlockedIncrement(guard);MemoryBarrier();memcpy(at,s,sizeof(*s));MemoryBarrier();InterlockedIncrement(guard);
}
static inline bool dualPauseCopyR13(const DualInputShared *m,bool host,PauseSnapshotR13 *s){
 if(!m||!s)return false;const volatile LONG *guard=host?&m->hostPauseGuard:&m->donorPauseGuard;const PauseSnapshotR13 *at=host?&m->hostPause:&m->donorPause;
 // Independent lane remains readable for owned pause cleanup after host exit.
 // Normal admission still validates session, process liveness and revoked.
 for(unsigned i=0;i<3;i++){LONG g=*guard;if(g&1)continue;MemoryBarrier();memcpy(s,at,sizeof(*s));MemoryBarrier();if(g==*guard)return true;}return false;
}
#endif
static inline void dualInputName(wchar_t name[96],uint32_t host){_snwprintf(name,96,L"Local\\LOKDualInput-v1-%lu",host);}
static inline void dualInputStore(DualInputShared *m,const DualInputWire *s){InterlockedIncrement(&m->guard);MemoryBarrier();m->sample=*s;MemoryBarrier();InterlockedIncrement(&m->guard);}
static inline bool dualInputCopy(const DualInputShared *m,DualInputWire *s){
 if(!m||m->revoked)return false;for(unsigned i=0;i<3;i++){LONG g=m->guard;if(g&1)continue;MemoryBarrier();*s=m->sample;MemoryBarrier();if(g==m->guard&&!m->revoked)return true;}return false;
}
static inline void dualInputOrdinaryStoreR17(DualInputShared *m,const DualInputWire *s,const OrdinaryInputProofR17 *proof){
 InterlockedIncrement(&m->guard);MemoryBarrier();m->sample=*s;m->ordinaryProofR17=*proof;MemoryBarrier();InterlockedIncrement(&m->guard);
}
static inline bool dualInputOrdinaryCopyR17(const DualInputShared *m,DualInputWire *s,OrdinaryInputProofR17 *proof){
 if(!m||!s||!proof||m->revoked)return false;
 for(unsigned i=0;i<3;i++){LONG g=m->guard;if(g&1)continue;MemoryBarrier();*s=m->sample;*proof=m->ordinaryProofR17;
  MemoryBarrier();if(g==m->guard&&!m->revoked)return true;}return false;
}
