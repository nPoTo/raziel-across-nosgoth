// SPDX-License-Identifier: GPL-3.0-or-later
#pragma once
#include "dual-input-state.h"
#include "ordinary-input-proof-r17.h"
#if ORDINARY_INPUT_FRESH_MS_R17 != 150 || ORDINARY_INPUT_MAX_GAP_MS_R17 != 350 || ORDINARY_INPUT_PROOF_VERSION_R17 != 1
#error Checked ordinary input axis policy required
#endif
typedef struct {
 uint64_t now,session,hostActor,donorActor,pauseTicket;
 bool owner,pauseRunning,pauseAgeOnly;
} OrdinaryInputContextR17;
typedef struct {
 uint64_t session,actor,object,donorActor,pauseTicket,sequence,tick,observed;
 bool admitted,pending;
} OrdinaryInputAxesR17;
// Pause and shared-input observation can finish after frame entry. Advance only
// the comparison clock; input/proof/receipt timestamps remain untouched.
static inline uint64_t ordinaryInputDeliveryTickR17(uint64_t frameEntry,uint64_t observed){
 return observed>frameEntry?observed:frameEntry;
}
typedef uint64_t (*OrdinaryInputClockR17)(void);
static inline uint64_t ordinaryInputObserveDeliveryR17(uint64_t frameEntry,OrdinaryInputClockR17 clock){
 return ordinaryInputDeliveryTickR17(frameEntry,clock?clock():frameEntry);
}
static inline bool ordinaryInputAxesR17(OrdinaryInputAxesR17 *g,const DualInputConsumer *before,
 DualInputConsumer *consumer,const DualInputSample *sample,DualInputResult *result,
 const OrdinaryInputProofR17 *proof,const OrdinaryInputContextR17 *context){
 if(!g||!before||!consumer||!sample||!result||!proof||!context)return false;
 const uint64_t now=context->now;
 const bool proven=context->owner&&context->session&&context->hostActor&&context->donorActor&&context->pauseTicket&&
  (context->pauseRunning||context->pauseAgeOnly)&&proof->magic==ORDINARY_INPUT_PROOF_MAGIC_R17&&
  proof->version==ORDINARY_INPUT_PROOF_VERSION_R17&&proof->ordinary==1&&!proof->reserved&&proof->object&&
  proof->session==context->session&&sample->session==context->session&&proof->actor==context->hostActor&&
  proof->sequence==sample->sequence&&proof->tick==sample->tick&&sample->sequence&&sample->tick&&sample->tick<=now&&
  (!g->observed||now>=g->observed);
 const bool same=g->admitted&&g->session==sample->session&&g->actor==proof->actor&&g->object==proof->object&&
  g->donorActor==context->donorActor&&g->pauseTicket==context->pauseTicket;
 if(!proven||(g->admitted&&!same)){*g=(OrdinaryInputAxesR17){0};return false;}
 const uint64_t age=now-sample->tick;
 if(!result->active){
  const bool original=same&&sample->sequence==g->sequence&&sample->tick==g->tick&&
   before->session==g->session&&before->sequence==g->sequence&&before->tick==g->tick;
  if(original&&(before->active||g->pending)&&age>ORDINARY_INPUT_FRESH_MS_R17&&age<=ORDINARY_INPUT_MAX_GAP_MS_R17){
   g->pending=true;g->observed=now;return false;
  }
  *g=(OrdinaryInputAxesR17){0};return false;
 }
 bool resumed=false;
 if(g->pending){
  const bool fresh=context->pauseRunning&&sample->valid&&consumer->active&&before->session==sample->session&&
   same&&sample->sequence>g->sequence&&sample->tick>g->tick&&age<=ORDINARY_INPUT_FRESH_MS_R17&&
   now>=g->tick&&now-g->tick<=ORDINARY_INPUT_MAX_GAP_MS_R17;
  if(!fresh){*g=(OrdinaryInputAxesR17){0};return false;}
  consumer->axisBlocked=false;result->x=sample->x;result->y=sample->y;resumed=true;
 }
 if(!context->pauseRunning||consumer->axisBlocked||age>ORDINARY_INPUT_FRESH_MS_R17){
  *g=(OrdinaryInputAxesR17){0};return false;
 }
 *g=(OrdinaryInputAxesR17){.session=sample->session,.actor=proof->actor,.object=proof->object,
  .donorActor=context->donorActor,.pauseTicket=context->pauseTicket,.sequence=sample->sequence,
  .tick=sample->tick,.observed=now,.admitted=true};
 return resumed;
}
