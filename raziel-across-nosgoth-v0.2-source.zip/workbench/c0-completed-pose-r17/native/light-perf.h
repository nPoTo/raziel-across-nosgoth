// SPDX-License-Identifier: GPL-3.0-or-later
#pragma once
// Fixed diagnostic counters only. No runtime decision consumes these values.
enum {
 LIGHT_PERF_ENTRY_GUARD, LIGHT_PERF_PROGRAM_METADATA, LIGHT_PERF_ACTOR_SCOPE,
 LIGHT_PERF_JOINTS_UNIFORMS, LIGHT_PERF_REAVER_MATCH,
 LIGHT_PERF_ZERO_VERIFY, LIGHT_PERF_ORIGINAL_DRAW, LIGHT_PERF_RESTORE_VERIFY,
 LIGHT_PERF_CALL_TOTAL, LIGHT_PERF_CALL_OWN, LIGHT_PERF_STAGES
};
typedef struct {LONGLONG tick;bool valid;} LightPerfStamp;
typedef struct {uint64_t ticks;bool valid;} LightPerfDuration;
typedef struct {volatile LONG64 count,total,maximum,clockFaults,maxContention;} LightPerfCounter;
typedef struct {uint64_t originalTicks;bool originalClockValid;} LightPerfCall;
static LightPerfCounter lightPerfCounters[LIGHT_PERF_STAGES];
static LightPerfStamp lightPerfStart(void){
 LARGE_INTEGER value={0};bool valid=QueryPerformanceCounter(&value)!=0&&value.QuadPart>=0;
 return (LightPerfStamp){value.QuadPart,valid};
}
static void lightPerfRecord(unsigned stage,uint64_t ticks){
 if(stage>=LIGHT_PERF_STAGES||ticks>INT64_MAX)return;
 LightPerfCounter *c=&lightPerfCounters[stage];
 InterlockedIncrement64(&c->count);InterlockedAdd64(&c->total,(LONG64)ticks);
 LONG64 old=InterlockedCompareExchange64(&c->maximum,0,0);
 for(unsigned attempt=0;attempt<8&&old<(LONG64)ticks;++attempt){
  LONG64 seen=InterlockedCompareExchange64(&c->maximum,(LONG64)ticks,old);
  if(seen==old)return;old=seen;
 }
 if(old<(LONG64)ticks)InterlockedIncrement64(&c->maxContention);
}
static LightPerfDuration lightPerfBetween(unsigned stage,LightPerfStamp begin,LightPerfStamp end){
 if(stage>=LIGHT_PERF_STAGES)return (LightPerfDuration){0,false};
 if(!begin.valid||!end.valid||end.tick<begin.tick){
  InterlockedIncrement64(&lightPerfCounters[stage].clockFaults);return (LightPerfDuration){0,false};
 }
 uint64_t ticks=(uint64_t)(end.tick-begin.tick);lightPerfRecord(stage,ticks);
 return (LightPerfDuration){ticks,true};
}
static LightPerfDuration lightPerfFinish(unsigned stage,LightPerfStamp begin){
 return lightPerfBetween(stage,begin,lightPerfStart());
}
static void lightPerfLog(void){
 static const char *const names[]={"entry_guard","program_metadata","actor_scope","joints_uniforms","reaver_match","zero_verify","original_draw","restore_verify","call_total","call_own"};
 LARGE_INTEGER frequency={0};bool clock=QueryPerformanceFrequency(&frequency)!=0&&frequency.QuadPart>0;
 for(unsigned i=0;i<LIGHT_PERF_STAGES;++i){
  LightPerfCounter *c=&lightPerfCounters[i];
  LONG64 count=InterlockedCompareExchange64(&c->count,0,0),total=InterlockedCompareExchange64(&c->total,0,0),maximum=InterlockedCompareExchange64(&c->maximum,0,0);
  LONG64 faults=InterlockedCompareExchange64(&c->clockFaults,0,0),contention=InterlockedCompareExchange64(&c->maxContention,0,0);
  if(count||faults)logLine("LIGHT_PERF stage=%s count=%lld total_qpc=%lld max_qpc=%lld clock_faults=%lld max_contention=%lld frequency=%lld cumulative=1 fields_independently_atomic=1",names[i],count,total,maximum,faults,contention,clock?frequency.QuadPart:0);
 }
}
