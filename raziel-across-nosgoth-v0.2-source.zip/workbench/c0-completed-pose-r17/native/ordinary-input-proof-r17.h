// SPDX-License-Identifier: GPL-3.0-or-later
#pragma once
#include <stdint.h>
#include "ordinary-input-policy-r17.h"
#define ORDINARY_INPUT_PROOF_MAGIC_R17 0x3141494fu
typedef struct {
 uint32_t magic,version;
 uint64_t session,sequence,tick,actor,object;
 uint32_t ordinary,reserved;
} OrdinaryInputProofR17;
