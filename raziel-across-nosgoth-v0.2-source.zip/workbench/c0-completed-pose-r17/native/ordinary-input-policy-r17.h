// SPDX-License-Identifier: GPL-3.0-or-later
// Checked ordinary-input-axes.json; canonical SHA256:
// ff979f490ae022309f4ae3e44fb4700809bc50e694b223d892d09541328654dd
#pragma once
#define ORDINARY_INPUT_PROOF_VERSION_R17 1u
#define ORDINARY_INPUT_FRESH_MS_R17 150u
#define ORDINARY_INPUT_MAX_GAP_MS_R17 350u
