// SPDX-License-Identifier: GPL-3.0-or-later
#include "host-contact-reader.h"
#include <assert.h>
#include <stdio.h>

static HostContactSnapshot snapshot(uint32_t phase, uint32_t control, uint64_t callback, int32_t velocity) {
    return (HostContactSnapshot){.magic = HOST_CONTACT_MAGIC, .version = HOST_CONTACT_VERSION,
        .pid = 7960, .phase = phase, .creation = 134388910824940729ull, .epoch = 4648984,
        .tick = 4776718, .sequence = 3609, .actor = 0x7ff9f02baa50ull,
        .control = control, .coherent = 1, .callbacks = {callback, callback, callback},
        .verticalVelocity = velocity};
}

static HostContactReader readerFor(const HostContactSnapshot *host, HostContactShared *mapping) {
    return (HostContactReader){.process = GetCurrentProcess(), .view = mapping,
        .lease = {.pid = host->pid, .creation = host->creation, .epoch = host->epoch, .actor = host->actor}};
}

static uint64_t fixtureClock(void *value) { return *(const uint64_t *)value; }

static void expectDormant(HostContactReader *reader, const HostContactSnapshot *original, uint64_t now) {
    HostContactSnapshot received = *original;
    const HostContactSnapshot empty = {0};
    bool fresh = true;
    assert(hostContactReaderReadObservedR20(reader, now, fixtureClock, &now, &received, &fresh));
    assert(reader->ordinaryGapR8 && !fresh && !memcmp(&received, &empty, sizeof(empty)));
    assert(!reader->lease.revoked && !memcmp(&reader->lease.last, original, sizeof(*original)));
}

static void verifyR7Landing(void) {
    HostContactShared mapping = {0};
    const HostContactSnapshot land = snapshot(1, 281, 0xee600, 0);
    HostContactReader reader = readerFor(&land, &mapping);
    HostContactSnapshot received = {0};
    bool fresh = false;

    hostContactStore(&mapping, &land);
    assert(hostContactReaderRead(&reader, 4776718, &received, &fresh) && fresh && !reader.ordinaryGapR8);
    assert(hostContactReaderRead(&reader, 4776868, &received, &fresh) && !fresh && !reader.ordinaryGapR8);
    expectDormant(&reader, &land, 4776875);
    expectDormant(&reader, &land, 4776906);

    HostContactSnapshot idle = snapshot(1, 172297, 0xf2180, 0);
    idle.tick = 4777000;
    idle.sequence++;
    hostContactStore(&mapping, &idle);
    assert(hostContactReaderRead(&reader, 4777000, &received, &fresh) && fresh && !reader.ordinaryGapR8);
    assert(!reader.lease.revoked && !memcmp(&received, &idle, sizeof(idle)));
    assert(!memcmp(&reader.lease.last, &idle, sizeof(idle)));
}

static void verifyOrdinaryClassification(void) {
    const HostContactSnapshot samples[] = {
        snapshot(1, 172297, 0xf2180, 0), snapshot(1, 2269465, 0xf3280, 0),
        snapshot(1, 131337, 0xf5340, 0), snapshot(1, 1305, 0xef480, -150),
        snapshot(2, 1305, 0xef480, -134), snapshot(2, 0x511, 0xf2ae0, 138),
        snapshot(3, 0x111, 0xedb40, 0), snapshot(1, 281, 0xee600, 0)
    };
    for (size_t i = 0; i < sizeof(samples) / sizeof(samples[0]); ++i) {
        const HostContactSnapshot *host = &samples[i];
        HostContactReader reader = readerFor(host, NULL);
        bool fresh = false;
        assert(hostContactAccept(&reader.lease, host, host->tick, true, &fresh) && fresh);
        assert(!ordinaryContactDormantR8(&reader.lease, host, host->tick + 150, true));
        assert(ordinaryContactDormantR8(&reader.lease, host, host->tick + 151, true));
        assert(ordinaryContactDormantR8(&reader.lease, host, host->tick + 350, true));
        assert(!ordinaryContactDormantR8(&reader.lease, host, host->tick + 351, true));
    }
}

static void verifyRefusals(void) {
    const HostContactSnapshot land = snapshot(1, 281, 0xee600, 0);
    HostContactShared mapping = {0};
    HostContactReader reader = readerFor(&land, &mapping);
    HostContactSnapshot result = {0};
    bool fresh = false;
    assert(!ordinaryContactDormantR8(&reader.lease, &land, land.tick + 157, true));
    hostContactStore(&mapping, &land);
    assert(hostContactReaderRead(&reader, land.tick, &result, &fresh) && fresh);
    assert(!ordinaryContactDormantR8(&reader.lease, &land, land.tick + 157, false));

    HostContactSnapshot changed[] = {land, land, land, land, land, land, land, land, land};
    changed[0].actor++;
    changed[1].creation++;
    changed[2].epoch++;
    changed[3].pid++;
    changed[4].sequence++;
    changed[5].tick++;
    changed[6].control ^= 16;
    changed[7].coherent = 0;
    changed[8].callbacks[2] = 0xf2180;
    for (size_t i = 0; i < sizeof(changed) / sizeof(changed[0]); ++i)
        assert(!ordinaryContactDormantR8(&reader.lease, &changed[i], land.tick + 157, true));

    const HostContactSnapshot excluded[] = {
        snapshot(1, 281, 0xefb50, 0), snapshot(1, 281, 0xf6a30, 0),
        snapshot(4, 0x8001, 0xecf70, 0), snapshot(1, 281, 0, 0)
    };
    for (size_t i = 0; i < sizeof(excluded) / sizeof(excluded[0]); ++i) {
        const HostContactSnapshot *host = &excluded[i];
        HostContactReader other = readerFor(host, NULL);
        assert(hostContactAccept(&other.lease, host, host->tick, true, &fresh));
        assert(!ordinaryContactDormantR8(&other.lease, host, host->tick + 157, true));
    }

    expectDormant(&reader, &land, land.tick + 350);
    assert(!hostContactReaderRead(&reader, land.tick + 351, &result, &fresh));
    assert(reader.lease.revoked && !reader.ordinaryGapR8 && !fresh && !result.actor);
    HostContactSnapshot recovered = land;
    recovered.tick += 352;
    recovered.sequence++;
    hostContactStore(&mapping, &recovered);
    assert(!hostContactReaderRead(&reader, recovered.tick, &result, &fresh));
}

int main(void) {
    verifyR7Landing();
    verifyOrdinaryClassification();
    verifyRefusals();
    puts("PASS R8 contact dormancy preserves exact old receipt, resumes fresh R7 landing, rejects foreign/expired/native packets");
}
