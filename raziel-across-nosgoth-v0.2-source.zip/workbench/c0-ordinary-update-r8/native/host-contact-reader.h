// SPDX-License-Identifier: GPL-3.0-or-later
#pragma once
#include "host-contact-shared.h"
#include "bridge-process-identity.h"
#ifdef SR1_CONTACT_OBSERVATION_R20
#include "contact-observation-r20.h"
#endif
#ifdef SR1_NATIVE_BOUNDARY_GAP_R19
#include "native-boundary-gap-r19.h"
#endif
#ifdef SR1_NATIVE_OBJECT_GAP_R18
#include "native-object-gap-r18.h"
#endif

#ifdef SR1_V38_REPAIR_R2
#include "v38-bars-suspension.h"
#endif
#ifdef SR1_ORDINARY_UPDATE_WAIT_R8
#include "ordinary-contact-dormancy-r8.h"
#endif

// Attach on the worker, never in a draw/collision hook. The owner must first
// validate the installed executable/module and obtain these exact host tokens.
// This reader cannot discover or adopt a replacement host session by itself.
typedef struct {
 HANDLE process,mapping;
 const HostContactShared *view;
 HostContactLease lease;
#ifdef SR1_CONTACT_OBSERVATION_R20
 ContactReadFailureR20 firstFailureR20;
 uint64_t observedClockR20;bool observedClockSeenR20;
#endif
#ifdef SR1_NATIVE_BOUNDARY_GAP_R19
 NativeBoundaryGapR19 boundaryGap;
#endif
 bool attempted;
#ifdef SR1_V38_REPAIR_R2
 bool suspended;
#endif
#ifdef SR1_ORDINARY_UPDATE_WAIT_R8
 bool ordinaryGapR8;
#endif
} HostContactReader;
static inline void hostContactReaderClose(HostContactReader *r){
 if(!r)return;
 r->lease.revoked=true;
 if(r->view){UnmapViewOfFile(r->view);r->view=NULL;}
 if(r->mapping){CloseHandle(r->mapping);r->mapping=NULL;}
 if(r->process){CloseHandle(r->process);r->process=NULL;}
}
static inline bool hostContactReaderOpen(HostContactReader *r,HostContactLease expected){
 if(!r||r->attempted)return false;
 r->attempted=true;r->lease=expected;
 if(!expected.pid||!expected.creation||!expected.epoch||!expected.actor||expected.seen||expected.revoked)goto fail;
 r->process=OpenProcess(PROCESS_QUERY_LIMITED_INFORMATION|SYNCHRONIZE,FALSE,expected.pid);
 uint64_t creation=0;
 if(!r->process||WaitForSingleObject(r->process,0)!=WAIT_TIMEOUT||!bridgeProcessCreation(r->process,&creation)||creation!=expected.creation)goto fail;
 wchar_t name[96];hostContactMappingName(name,expected.pid);
 r->mapping=OpenFileMappingW(FILE_MAP_READ,FALSE,name);
 if(!r->mapping)goto fail;
 r->view=MapViewOfFile(r->mapping,FILE_MAP_READ,0,0,sizeof(*r->view));
 if(!r->view)goto fail;
 return true;
fail:
 hostContactReaderClose(r);return false;
}
// Single worker owns read/close. Return no old snapshot on a failed/torn read.
// Revocation stays latched until the owner explicitly creates a NEW reader.
#ifdef SR1_CONTACT_OBSERVATION_R20
static inline bool hostContactReaderReadCoreR20(HostContactReader *r,uint64_t now,HostContactObservationClockR20 observe,void *clockContext,HostContactSnapshot *out,bool *fresh){
#else
static inline bool hostContactReaderRead(HostContactReader *r,uint64_t now,HostContactSnapshot *out,bool *fresh){
#endif
 if(out)memset(out,0,sizeof(*out));if(fresh)*fresh=false;
#ifdef SR1_ORDINARY_UPDATE_WAIT_R8
 if(r)r->ordinaryGapR8=false;
#endif
 if(!r||!out||!fresh||r->lease.revoked){
#ifdef SR1_CONTACT_OBSERVATION_R20
  if(r)contactReadFailureR20(&r->firstFailureR20,r->lease.revoked?CONTACT_READ_R20_ALREADY_REVOKED:CONTACT_READ_R20_ARGUMENT,now,now,NULL,false,false);
#endif
  return false;
 }
 HostContactSnapshot next={0};
 bool copied=hostContactCopy(r->view,&next);
#ifdef SR1_CONTACT_OBSERVATION_R20
 uint64_t before=now,observed=observe?observe(clockContext):now;
 bool alive=r->process&&WaitForSingleObject(r->process,0)==WAIT_TIMEOUT;
 if(observe&&(observed<before||(r->observedClockSeenR20&&observed<r->observedClockR20))){
  contactReadFailureR20(&r->firstFailureR20,CONTACT_READ_R20_CLOCK_REGRESSED,before,observed,&next,copied,alive);r->lease.revoked=true;return false;
 }
 if(observe){r->observedClockSeenR20=true;r->observedClockR20=observed;}now=observed;
#else
 bool alive=r->process&&WaitForSingleObject(r->process,0)==WAIT_TIMEOUT;
#endif
#ifdef SR1_V38_REPAIR_R2
 r->suspended=false;
 if(copied&&v38BarsLeasePending(&r->lease,&next,now,alive)){r->suspended=true;return true;}
#endif
#ifdef SR1_NATIVE_OBJECT_GAP_R18
 if(copied&&nativeObjectGapLeasePendingR18(&r->lease,&next,now,alive)){r->suspended=true;return true;}
#endif
#ifdef SR1_NATIVE_BOUNDARY_GAP_R19
 if(copied&&r->boundaryGap.seen&&!nativeBoundaryRecoveryOrderR19(&r->boundaryGap,&next)){
#ifdef SR1_CONTACT_OBSERVATION_R20
  contactReadFailureR20(&r->firstFailureR20,CONTACT_READ_R20_BOUNDARY_ORDER,before,now,&next,copied,alive);
#endif
  r->lease.revoked=true;return false;
 }
 if(copied&&nativeWaterExitPendingR19(&r->lease,&r->boundaryGap,&next,now,alive)){r->suspended=true;return true;}
 r->boundaryGap.seen=false;
#endif
#ifdef SR1_ORDINARY_UPDATE_WAIT_R8
 if(copied&&ordinaryContactDormantR8(&r->lease,&next,now,alive)){r->ordinaryGapR8=true;return true;}
#endif
 if(!copied||!hostContactAccept(&r->lease,&next,now,alive,fresh)){
#ifdef SR1_CONTACT_OBSERVATION_R20
  contactReadFailureR20(&r->firstFailureR20,!copied?(!r->view?CONTACT_READ_R20_MAPPING_MISSING:r->view->revoked?CONTACT_READ_R20_SHARED_REVOKED:CONTACT_READ_R20_COPY):!alive?CONTACT_READ_R20_PEER_DEAD:CONTACT_READ_R20_VALIDATION,before,now,&next,copied,alive);
#endif
  r->lease.revoked=true;return false;
 }
 *out=next;return true;
}
#ifdef SR1_CONTACT_OBSERVATION_R20
// Explicit legacy observation for deterministic historical fixtures. Production
// owner code must call the observed entry with its actual after-copy clock.
static inline bool hostContactReaderRead(HostContactReader *r,uint64_t now,HostContactSnapshot *out,bool *fresh){
 return hostContactReaderReadCoreR20(r,now,NULL,NULL,out,fresh);
}
static inline bool hostContactReaderReadObservedR20(HostContactReader *r,uint64_t before,HostContactObservationClockR20 observe,void *clockContext,HostContactSnapshot *out,bool *fresh){
 if(!observe||!contactObservationPolicyR20()){
  if(out)memset(out,0,sizeof(*out));if(fresh)*fresh=false;
  if(r){contactReadFailureR20(&r->firstFailureR20,CONTACT_READ_R20_CLOCK_MISSING,before,before,NULL,false,false);r->lease.revoked=true;}
  return false;
 }
 return hostContactReaderReadCoreR20(r,before,observe,clockContext,out,fresh);
}
#endif
