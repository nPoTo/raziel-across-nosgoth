// SPDX-License-Identifier: GPL-3.0-or-later
#pragma once
#include "host-contact-shared.h"
#include "exploration-sheets.h"
#include "ordinary-contact-policy-r8.h"

#if ORDINARY_CONTACT_DORMANCY_R8_FRESH_MS != 150 || ORDINARY_CONTACT_DORMANCY_R8_MAX_MS != 350
#error Ordinary contact dormancy requires the checked R8 freshness policy
#endif

static inline bool ordinaryContactGroundCallbackR8(uint64_t callback) {
    for (size_t i = 0; i < sheet_retargetGroundStates_count; ++i) {
        if (callback == (uint64_t)sheet_retargetGroundStates_rows[i]->rva) return true;
    }
    return false;
}

static inline bool ordinaryContactContextR8(const HostContactSnapshot *contact) {
    const Sheet_airCombatPosePolicy *air = &sheet_airCombatPosePolicy_air_candidate;
    const uint64_t callback = contact->callbacks[0];
    if (contact->callbacks[1] != callback || contact->callbacks[2] != callback ||
        contact->verticalVelocity < -air->maxAbsVerticalVelocity ||
        contact->verticalVelocity > air->maxAbsVerticalVelocity) return false;

    const bool falling = callback == (uint64_t)air->hostFallRva;
    switch (contact->phase) {
    case 1:
        return falling || callback == (uint64_t)air->hostLandingRva || ordinaryContactGroundCallbackR8(callback);
    case 2:
        return falling || callback == (uint64_t)air->hostJumpRva;
    case 3:
        return callback == (uint64_t)air->hostCompressionRva &&
            hostContactCompression(contact->control, contact->callbacks);
    default:
        return false;
    }
}

// An expired receipt is only proof of a previously admitted owner. Leave the
// original receipt, its timestamp, and the reader's acceptance state intact.
static inline bool ordinaryContactDormantR8(const HostContactLease *lease, const HostContactSnapshot *next,
    uint64_t now, bool peerAlive) {
    if (!lease || !next || !peerAlive || lease->revoked || !lease->seen || !lease->pid ||
        !lease->creation || !lease->epoch || !lease->actor) return false;
    if (next->magic != HOST_CONTACT_MAGIC || next->version != HOST_CONTACT_VERSION ||
        next->pid != lease->pid || next->creation != lease->creation || next->epoch != lease->epoch ||
        next->actor != lease->actor || !next->sequence || next->coherent != 1 || next->reserved ||
        next->tick < next->epoch || next->tick > now || (next->control & 0x4000000u)) return false;

    const uint64_t age = now - next->tick;
    return age > ORDINARY_CONTACT_DORMANCY_R8_FRESH_MS && age <= ORDINARY_CONTACT_DORMANCY_R8_MAX_MS &&
        forceDuration(now - next->epoch, HOST_CONTACT_MAX_MS + 1u) &&
        !memcmp(next, &lease->last, sizeof(*next)) && ordinaryContactContextR8(next);
}
