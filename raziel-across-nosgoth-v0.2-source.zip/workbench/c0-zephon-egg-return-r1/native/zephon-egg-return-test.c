// SPDX-License-Identifier: GPL-3.0-or-later
#include <assert.h>
#include <stdio.h>
#include "c0-physical-weapon-policy.h"
#include "zephon-weapon-ownership.generated.h"

static void sections(C0WeaponInput *in, uint32_t rva) {
    for (size_t i = 0; i < 3; ++i) in->callbacks[i] = rva;
}

int main(void) {
    const Sheet_c0WeaponOwnership *p = &sheet_c0WeaponOwnership_family0;
    C0WeaponState pickup = {.epoch=1,.actor=2,.weapon=3,.step=584,.boundaryStep=583,.phase=C0_WEAPON_PICKUP};
    C0WeaponInput in = {.epoch=1,.actor=2,.step=587,.coherent=true,.inputNeutral=true};
    sections(&in, ZEPHON_EGG_INTERRUPTION);
    C0WeaponState state = pickup;
    assert(c0WeaponAdvance(&state, &in).phase == C0_WEAPON_UNRESOLVED);

    state = pickup;
    in.eggPickupExit = c0EggPickupExit(false,true,true,true,false);
    assert(c0WeaponAdvance(&state, &in).phase == C0_WEAPON_PICKUP);
    in.step++;
    in.eggPickupExit = c0EggPickupExit(false,true,false,false,false);
    assert(c0WeaponAdvance(&state, &in).phase == C0_WEAPON_PICKUP);
    in.step++;
    in.eggPickupExit = c0EggPickupExit(false,true,false,true,false);
    sections(&in, (uint32_t)p->idleCallbackRva);
    assert(c0WeaponAdvance(&state, &in).phase == C0_WEAPON_DETACHED && state.acquisitionStep == 0);
    in.step++;
    in.eggPickupExit = C0_EGG_EXIT_NONE;
    in.returnComplete = true;
    in.returnForDetachStep = state.boundaryStep;
    assert(c0WeaponAdvance(&state, &in).handedBack && state.phase == C0_WEAPON_IDLE);

    state = pickup;
    in.step = 587;
    in.held = state.weapon;
    in.heldQueryRva = (uint32_t)p->heldQueryRva;
    in.heldSegment = (int32_t)p->heldSegment;
    in.eggPickupExit = c0EggPickupExit(true,false,false,false,false);
    assert(c0WeaponAdvance(&state, &in).phase == C0_WEAPON_HELD && state.acquisitionStep == in.step);
    in.step++;
    in.held = 0;
    in.originalUnlinkReceipt = true;
    in.eggPickupExit = C0_EGG_EXIT_NONE;
    assert(c0WeaponAdvance(&state, &in).phase == C0_WEAPON_DETACHED);

    assert(c0EggPickupExit(true,false,true,false,false) == C0_EGG_EXIT_WAIT);
    assert(c0EggPickupExit(true,false,false,true,true) == C0_EGG_EXIT_NONE);
    assert(c0EggPickupExit(false,false,false,true,false) == C0_EGG_EXIT_WAIT);
    puts("Zephon egg interrupted pickup: PASS");
}
