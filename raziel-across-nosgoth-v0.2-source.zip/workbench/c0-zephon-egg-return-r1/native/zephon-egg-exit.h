// SPDX-License-Identifier: GPL-3.0-or-later
#pragma once

typedef enum {
    C0_EGG_EXIT_NONE,
    C0_EGG_EXIT_WAIT,
    C0_EGG_EXIT_HELD,
    C0_EGG_EXIT_DETACHED
} C0EggPickupExit;

static inline C0EggPickupExit c0EggPickupExit(bool ownAttachment, bool physicallyEmpty,
    bool nativePending, bool ordinaryExit, bool foreignRelation) {
    if (foreignRelation) return C0_EGG_EXIT_NONE;
    if (nativePending) return C0_EGG_EXIT_WAIT;
    if (ownAttachment) return C0_EGG_EXIT_HELD;
    if (physicallyEmpty && ordinaryExit) return C0_EGG_EXIT_DETACHED;
    return C0_EGG_EXIT_WAIT;
}
