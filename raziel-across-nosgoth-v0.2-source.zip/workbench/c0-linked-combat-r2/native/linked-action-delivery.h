// SPDX-License-Identifier: GPL-3.0-or-later
#pragma once
#include "native-action-route-r12.h"
#include "exploration-sheets.h"

static inline uint16_t linkedActionHostButtons(uint16_t delivered, uint16_t donorButtons,
                                              NativeActionDecisionR12 route, unsigned pressOwner,
                                              bool currentOrdinaryLink) {
    const Sheet_nativeActionRouteR12 *p = &sheet_nativeActionRouteR12_contextual_action;
    if (currentOrdinaryLink && p->onePressOneOwner && p->actionMask == 0x4000 && pressOwner == 1 &&
        route.applicable && route.donorAction && !route.hostAction && !route.nativeOwned && !route.requestingNative &&
        (donorButtons & (uint16_t)p->actionMask))
        return (uint16_t)(delivered & ~(uint16_t)p->actionMask);
    return delivered;
}
