#include "general-test-budget.h"
// SPDX-License-Identifier: GPL-3.0-or-later
#include "air-clock-shared.h"
#include "sr1-input-channels.h"
#include "lift-source-follow.h"
static HANDLE srLiftMap;static const AirClockShared *srLiftView;static LiftSourceFollow srLiftPads[SR_INPUT_CHANNELS];static unsigned srLiftPulses;
#ifdef SR1_LIFT_VERTICAL_LAUNCH
#include "lift-vertical-launch.h"
#include "lift-launch-proof.h"
static LiftVerticalLaunch srLiftVertical;static volatile LONG srLiftVerticalLock;
static void srLiftLaunchInstall(void);
static void srLiftLaunchArm(uintptr_t actor,uint64_t now,uint64_t epoch){
 if(!InterlockedCompareExchange(&srLiftVerticalLock,1,0)){srLiftVertical=(LiftVerticalLaunch){actor,now,epoch};InterlockedExchange(&srLiftVerticalLock,0);}
}
#endif
static void srLiftTick(void){
#ifdef SR1_LIFT_VERTICAL_LAUNCH
 srLiftLaunchInstall();
#endif
 if(srLiftView||!hostContactSource.view)return;
 wchar_t n[96];_snwprintf(n,96,L"Local\\LOKLift-v1-%lu",GetCurrentProcessId());HANDLE m=OpenFileMappingW(FILE_MAP_READ,FALSE,n);if(!m)return;
 const AirClockShared *v=MapViewOfFile(m,FILE_MAP_READ,0,0,sizeof(*v));if(!v){CloseHandle(m);return;}srLiftMap=m;MemoryBarrier();InterlockedExchangePointer((PVOID volatile *)&srLiftView,(PVOID)v);
}
static WORD srLiftApply(DWORD index,uint64_t now,uintptr_t actor,bool scope,const Sr1RetargetContext *c,WORD raw,WORD delivered){
 if(index>=SR_INPUT_CHANNELS)return delivered;
 AirClockPacket p={0};SkeletonSnapshot pose={0};const Sheet_liftSourceFollow *v=&sheet_liftSourceFollow_source_launch;
 bool fresh=!v->enabled&&v->freshMs==100&&v->pulseMs==64&&v->maxPressMs==3000&&v->sourceJumpRva==0x10f1d0&&v->sourceSecondaryRva==0x10f220&&!v->hostCoordinateWrites&&!v->hostVelocityWrites&&v->releaseToArm&&
 airClockCopy(srLiftView,&p)&&p.magic==0x314c4341&&p.version==1&&p.hostPid==GetCurrentProcessId()&&p.hostCreation==hostContactSource.creation&&p.epoch==hostContactSource.epoch&&p.actor==actor&&p.tick>=p.epoch&&p.tick<=now&&now-p.tick<=100&&forceDuration(now-p.epoch,GENERAL_OR_SHORT_MS(50000))&&
 skeletonCopy(sr1SkeletonView,&pose)&&skeletonPacketValid(&pose,GetCurrentProcessId(),now)&&pose.actor==actor&&pose.sourcePid==p.donorPid&&(pose.mode==2||pose.mode==3);
 bool ground=sr1RetargetContextAllowed(c),compression=c->ordinaryAirTransition;
 for(unsigned i=0;i<3;i++)compression=compression&&c->callbacks[i]==0xedb40;
 bool fired=srLiftPads[index].fired;
 WORD result=liftSourceButtons(&srLiftPads[index],now,actor,scope&&fresh,ground,compression,p.active==1,raw,delivered);
 if(!fired&&srLiftPads[index].fired&&!(raw&XINPUT_GAMEPAD_A)){
#ifdef SR1_LIFT_VERTICAL_LAUNCH
 srLiftLaunchArm(actor,now,p.epoch);
#endif
 ++srLiftPulses;logLine("SR1_LIFT pulse=%u tick=%llu source_tick=%llu sequence=%llu",srLiftPulses,now,p.tick,p.sequence);}
 return result;
}
#ifdef SR1_LIFT_VERTICAL_LAUNCH
typedef void (__fastcall *SrLiftLaunchFn)(uintptr_t,int32_t,int32_t,int32_t,int32_t);
static SrLiftLaunchFn srLiftLaunchOriginal;static PVOID srLiftLaunchTarget;static uintptr_t srLiftLaunchBase;static bool srLiftLaunchAttempted;
static void __fastcall srLiftLaunch(uintptr_t actor,int32_t gravity,int32_t x,int32_t y,int32_t z){
 uintptr_t caller=(uintptr_t)__builtin_return_address(0)-srLiftLaunchBase;uint64_t now=GetTickCount64();bool change=false;
 if(!InterlockedCompareExchange(&srLiftVerticalLock,1,0)){
  AirClockPacket p={0};SkeletonSnapshot pose={0};DWORD foreground=0;GetWindowThreadProcessId(GetForegroundWindow(),&foreground);
  bool live=foreground==GetCurrentProcessId()&&airClockCopy(srLiftView,&p)&&p.magic==0x314c4341&&p.version==1&&p.hostPid==GetCurrentProcessId()&&p.hostCreation==hostContactSource.creation&&p.epoch==hostContactSource.epoch&&p.actor==actor&&p.tick>=p.epoch&&p.tick<=now&&now-p.tick<=100&&forceDuration(now-p.epoch,GENERAL_OR_SHORT_MS(50000))&&
   skeletonCopy(sr1SkeletonView,&pose)&&skeletonPacketValid(&pose,GetCurrentProcessId(),now)&&pose.actor==actor&&pose.sourcePid==p.donorPid&&(pose.mode==2||pose.mode==3);
#ifdef SR1_C0_PHYSICAL_WEAPON
  live=live&&!sr1C0NativeActive(actor);
#endif
  change=liftVerticalConsume(&srLiftVertical,now,actor,p.epoch,live,caller,gravity,x,y,z);
  InterlockedExchange(&srLiftVerticalLock,0);
 }
 srLiftLaunchOriginal(actor,gravity,x,change?0:y,z);
 if(change)logLine("SR1_LIFT_VERTICAL tick=%llu caller=%llx horizontal_before=%d horizontal_after=0 vertical=%d",now,(unsigned long long)caller,y,z);
}
static void srLiftLaunchInstall(void){
 if(srLiftLaunchAttempted||!hostContactSource.view)return;
 uintptr_t base=(uintptr_t)InterlockedCompareExchangePointer(&verifiedSr1Module,NULL,NULL);if(!base)return;srLiftLaunchAttempted=true;
 const Sheet_liftSourceFollow *p=&sheet_liftSourceFollow_source_launch;
 if(!p->verticalLaunchOnly||p->launchRva!=0xe4230||p->launchReturnRva!=0xede81||p->launchTokenMs!=350)return;
 unsigned char code[56];char sha[65];
 if(!worldRead(base+0xe4230,code,56)||!hashBytes(code,56,sha)||strcmp(sha,LIFT_LAUNCH_SHA)||!worldRead(base+0xede63,code,30)||!hashBytes(code,30,sha)||strcmp(sha,LIFT_COMPRESSION_SHA)){logLine("SR1_LIFT_VERTICAL code gate refused");return;}
 srLiftLaunchBase=base;MH_STATUS init=MH_Initialize();if(init!=MH_OK&&init!=MH_ERROR_ALREADY_INITIALIZED)return;
 PVOID target=(PVOID)(base+0xe4230);MH_STATUS created=MH_CreateHook(target,(PVOID)srLiftLaunch,(PVOID *)&srLiftLaunchOriginal);MH_STATUS enabled=created==MH_OK?MH_EnableHook(target):created;
 if(enabled==MH_OK)srLiftLaunchTarget=target;
 logLine("SR1_LIFT_VERTICAL installed=%u status=%d",srLiftLaunchTarget!=NULL,enabled);
}
static void srLiftLaunchStop(void){if(srLiftLaunchTarget)MH_DisableHook(srLiftLaunchTarget);}
#endif
