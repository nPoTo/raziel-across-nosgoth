// SPDX-License-Identifier: GPL-3.0-or-later
// Observation only: original collision calculation remains the sole writer.
#include "host-ground-forward.h"
#include "general-test-budget.h"
#include "exploration-sheets.h"
#include "report-path.h"
#ifdef HOST_CONTACT_FRAME_OBSERVER
#include "host-contact-frame.h"
#ifdef HOST_CONTACT_TRANSPORT
#include "host-contact-source.h"
static HostContactSource hostContactSource;
#endif
typedef void (*HostCollisionFn)(uintptr_t,uint64_t);
static HostCollisionFn hostCollisionOriginal;
static PVOID hostCollisionTarget;
static _Thread_local HostContactFrame *hostContactActive;
static volatile LONG64 hostContactSequence;
typedef struct {HostContactResult result;uintptr_t actor;uint32_t control;uintptr_t callbacks[3];unsigned queries;bool coherent;int32_t completedVelocity;bool completedVelocityKnown;} HostContactRecord;
static HostContactRecord hostContactQueue[128];
static unsigned hostContactHead,hostContactTail;
static volatile LONG hostContactLock,hostContactDropped;
#endif
typedef struct {uint64_t tick,sequence;uintptr_t actor;DWORD thread;unsigned depth;uint32_t before,after,result;int16_t z;int32_t vz;bool valid;} HostGroundRecord;
static HostGroundFn hostGroundOriginal;
static PVOID hostGroundTarget;
static volatile LONG hostGroundEnabled,hostGroundQueueLock,hostGroundDropped;
static volatile LONG64 hostGroundSequence;
static _Thread_local unsigned hostGroundDepth;
static uint64_t hostGroundBegin;
static bool hostGroundStarted;
#if defined(HOST_CONTACT_TRANSPORT) && defined(SR1_GENERAL_ALL_IN_RUNTIME)
#include "sr1-completed-ground-contact.h"
static bool sr1CompletedGroundNative(uintptr_t actor,const Sr1RetargetContext *c){
 // Enabled is the acquire barrier for the immutable, process-pinned source.
 // Shutdown revokes the mapping without unmapping callbacks' storage.
 if(!InterlockedCompareExchange(&hostGroundEnabled,0,0)||InterlockedCompareExchange(&probeBoundedComplete,0,0))return false;
 return sr1CompletedGroundRead(hostContactSource.view,c,GetCurrentProcessId(),hostContactSource.creation,hostContactSource.epoch,actor,GetTickCount64());
}
#define SR1_COMPLETED_GROUND_READ(actor,context) sr1CompletedGroundNative((actor),(context))
#endif
static HostGroundRecord hostGroundQueue[128];
static unsigned hostGroundHead,hostGroundTail;
static bool hostGroundPlayer(uintptr_t base,uintptr_t actor){
 uintptr_t current=0,object=0,name=0;char label[9];
 const Sheet_rigRead *p=&sheet_rigRead_current;
 return base&&actor&&actor%8==0&&worldRead(base+p->actorGlobalRva,&current,8)&&current==actor&&
  worldRead(actor+p->actorObjectOffset,&object,8)&&object&&worldRead(object+p->objectNameOffset,&name,8)&&name&&
  worldRead(name,label,sizeof(label))&&!memcmp(label,"raziel__",9);
}
static uint32_t hostGroundObserve(uintptr_t actor,int16_t *payload,uint16_t flags){
 uintptr_t caller=(uintptr_t)__builtin_return_address(0);
 uintptr_t base=(uintptr_t)InterlockedCompareExchangePointer(&verifiedSr1Module,NULL,NULL);
 const Sheet_hostGroundObserver *p=&sheet_hostGroundObserver_completed_query;
 unsigned depth=++hostGroundDepth;uint64_t now=GetTickCount64();HostGroundRecord r={.tick=now,.actor=actor,.thread=GetCurrentThreadId(),.depth=depth};
 bool capture=depth==1&&InterlockedCompareExchange(&hostGroundEnabled,0,0)&&!InterlockedCompareExchange(&probeBoundedComplete,0,0)&&
  now>=hostGroundBegin&&forceDuration(now-hostGroundBegin,(uint64_t)p->durationMs+1u)&&base&&caller==base+(uintptr_t)p->callerReturnRva&&flags==p->queryFlags&&
  (forceHelperContinuous()||InterlockedCompareExchange64(&hostGroundSequence,0,0)<p->maxSamples)&&hostGroundPlayer(base,actor)&&worldRead(base+p->controlRva,&r.before,4);
 // No mutex held, no payload inspection, no writes or extra collision queries.
 uint32_t result=hostGroundForward(hostGroundOriginal,actor,payload,flags);
#ifdef HOST_CONTACT_FRAME_OBSERVER
 if(hostContactActive&&caller==base+(uintptr_t)p->callerReturnRva){
  uint32_t after=0;bool valid=capture&&hostGroundPlayer(base,actor)&&worldRead(base+p->controlRva,&after,4);
  hostContactQuery(hostContactActive,actor,depth,valid,valid,r.before,after,result);
 }
#endif
 if(capture){
  r.tick=GetTickCount64();r.result=result;r.sequence=(uint64_t)InterlockedIncrement64(&hostGroundSequence);
  r.valid=hostGroundPlayer(base,actor)&&worldRead(base+p->controlRva,&r.after,4)&&worldRead(actor+0xa0,&r.z,2)&&worldRead(actor+0x2d4,&r.vz,4);
  if(!InterlockedCompareExchange(&hostGroundQueueLock,1,0)){
   unsigned next=(hostGroundHead+1)%ARRAYSIZE(hostGroundQueue);
   if(next!=hostGroundTail){hostGroundQueue[hostGroundHead]=r;hostGroundHead=next;}else InterlockedIncrement(&hostGroundDropped);
   InterlockedExchange(&hostGroundQueueLock,0);
  }else InterlockedIncrement(&hostGroundDropped);
 }
 --hostGroundDepth;return result;
}
#ifdef HOST_CONTACT_FRAME_OBSERVER
static void hostCollisionObserve(uintptr_t actor,uint64_t opaque){
 uintptr_t base=(uintptr_t)InterlockedCompareExchangePointer(&verifiedSr1Module,NULL,NULL);
 const Sheet_hostContactFrameObserver *p=&sheet_hostContactFrameObserver_completed_collision;
 HostContactFrame frame,*previous=hostContactActive;
 bool capture=!previous&&InterlockedCompareExchange(&hostGroundEnabled,0,0)&&
  !InterlockedCompareExchange(&probeBoundedComplete,0,0)&&forceDuration(GetTickCount64()-hostGroundBegin,(uint64_t)p->durationMs+1u)&&
  (forceHelperContinuous()||InterlockedCompareExchange64(&hostContactSequence,0,0)<p->maxFrames)&&hostGroundPlayer(base,actor);
 if(previous)previous->poisoned=true;
 if(capture){hostContactBegin(&frame,actor,(uint64_t)InterlockedIncrement64(&hostContactSequence));hostContactActive=&frame;}
 // Preserve the original collision call, arguments and all native writes.
 hostCollisionOriginal(actor,opaque);
 if(capture){
  HostContactRecord r={.actor=actor,.queries=frame.queries};uintptr_t second[3]={0};uint32_t control2=0;
  bool ok=hostGroundPlayer(base,actor)&&worldRead(base+p->controlRva,&r.control,4);
  for(unsigned i=0;i<3;i++)ok=worldRead(base+p->callbackRva+i*p->callbackStride,&r.callbacks[i],8)&&ok;
  for(unsigned i=0;i<3;i++)ok=worldRead(base+p->callbackRva+i*p->callbackStride,&second[i],8)&&ok;
  ok=worldRead(base+p->controlRva,&control2,4)&&ok&&control2==r.control&&!memcmp(second,r.callbacks,sizeof(second))&&hostGroundPlayer(base,actor);
  for(unsigned i=0;i<3;i++)r.callbacks[i]=r.callbacks[i]>=base?r.callbacks[i]-base:0;
  r.coherent=ok;r.result=hostContactFinish(&frame,actor,GetTickCount64(),ok,r.control,r.callbacks);
#ifdef HOST_CONTACT_TRANSPORT
  HostContactSnapshot snapshot={.tick=r.result.tick,.sequence=r.result.sequence,.actor=actor,.control=r.control,.coherent=ok,.phase=r.result.contact};
  for(unsigned i=0;i<3;i++)snapshot.callbacks[i]=r.callbacks[i];
  int32_t vzAgain=0;
  r.completedVelocityKnown=worldRead(actor+0x2d4,&snapshot.verticalVelocity,4)&&worldRead(actor+0x2d4,&vzAgain,4)&&vzAgain==snapshot.verticalVelocity;
  r.completedVelocity=snapshot.verticalVelocity;if(!r.completedVelocityKnown)snapshot.coherent=0;
  if(ok&&!r.result.contact&&hostContactCompression(r.control,snapshot.callbacks)&&!frame.poisoned&&!frame.queries)snapshot.phase=3;
#ifdef GENERAL_FREE_TEST
#ifdef SR1_C0_PHYSICAL_WEAPON
  sr1C0ObserveCompletedContact(actor,snapshot.tick,snapshot.sequence,snapshot.phase,
                              snapshot.coherent&&!frame.poisoned,snapshot.callbacks);
  if(snapshot.coherent&&!frame.poisoned&&sr1C0NativeActive(actor)&&hostContactC0WeaponCallbacks(snapshot.callbacks)&&
     (!(snapshot.control&0x4000000u)||hostContactNativeHangControl(snapshot.control,snapshot.callbacks))){
   snapshot.phase=(uint32_t)sheet_c0RuntimeOwnership_linked.nativePhase;
   snapshot.reserved=(uint32_t)sheet_c0RuntimeOwnership_linked.contactTag;
  }else
#endif
  // Known native mechanics suspend projection, even if their collision call
  // happens to return a ground query. Unknown/torn frames remain refusals.
  if(ok&&!frame.poisoned&&hostContactNativePause(snapshot.callbacks))snapshot.phase=4;
#endif
  hostContactSourcePublish(&hostContactSource,snapshot);
#endif
  if(!InterlockedCompareExchange(&hostContactLock,1,0)){
   unsigned next=(hostContactHead+1)%ARRAYSIZE(hostContactQueue);
   if(next!=hostContactTail){hostContactQueue[hostContactHead]=r;hostContactHead=next;}else InterlockedIncrement(&hostContactDropped);
   InterlockedExchange(&hostContactLock,0);
  }else InterlockedIncrement(&hostContactDropped);
 }
 hostContactActive=previous;
}
#endif
static void hostGroundFlush(void){
 HostGroundRecord local[128];unsigned n=0;if(InterlockedCompareExchange(&hostGroundQueueLock,1,0))return;
 while(hostGroundTail!=hostGroundHead){local[n++]=hostGroundQueue[hostGroundTail];hostGroundTail=(hostGroundTail+1)%ARRAYSIZE(hostGroundQueue);}InterlockedExchange(&hostGroundQueueLock,0);
 for(unsigned i=0;i<n;i++){const HostGroundRecord *r=local+i;logLine("HOST_GROUND tick=%llu sequence=%llu actor=%p thread=%lu depth=%u before=%u after=%u result=%u z=%d vz=%d valid=%u; completed original query; no writes",r->tick,r->sequence,(void *)r->actor,r->thread,r->depth,r->before,r->after,r->result,r->z,r->vz,r->valid);}
#ifdef HOST_CONTACT_FRAME_OBSERVER
 HostContactRecord frames[128];unsigned count=0;if(InterlockedCompareExchange(&hostContactLock,1,0))return;
 while(hostContactTail!=hostContactHead){frames[count++]=hostContactQueue[hostContactTail];hostContactTail=(hostContactTail+1)%ARRAYSIZE(hostContactQueue);}InterlockedExchange(&hostContactLock,0);
 for(unsigned i=0;i<count;i++){const HostContactRecord *r=&frames[i];logLine("HOST_CONTACT_FRAME tick=%llu sequence=%llu actor=%p contact=%u jump=%u control=%u cb0=%llu cb1=%llu cb2=%llu queries=%u coherent=%u dropped=%ld completedVz=%d completedVzKnown=%u",r->result.tick,r->result.sequence,(void *)r->actor,r->result.contact,r->result.queryDisabledJump,r->control,(uint64_t)r->callbacks[0],(uint64_t)r->callbacks[1],(uint64_t)r->callbacks[2],r->queries,r->coherent,InterlockedCompareExchange(&hostContactDropped,0,0),r->completedVelocity,r->completedVelocityKnown);}
#endif
}
static bool hostGroundInstall(HMODULE module){
 if(hostGroundTarget)return true;
 const Sheet_hostGroundObserver *p=&sheet_hostGroundObserver_completed_query;
 if(!module||p->enabled||p->gameWrites||p->targetRva!=0xb9940||p->targetBytes!=1847||p->callerReturnRva!=0xe8b32||p->controlRva!=0x2a88568||p->queryFlags!=7||p->durationMs!=GENERAL_OR_SHORT_MS(60000)||p->maxSamples!=GENERAL_OR_SHORT_SAMPLES(7200))return false;
 unsigned char code[1847],caller[1230];char sha[65],expected[65];uintptr_t base=(uintptr_t)module;
 if(wcslen(p->codeSha256)!=64)return false;
 for(unsigned i=0;i<64;i++){if(!wcschr(L"0123456789abcdef",p->codeSha256[i]))return false;expected[i]=(char)p->codeSha256[i];}expected[64]=0;
 if(!worldRead(base+p->targetRva,code,sizeof(code))||!hashBytes(code,sizeof(code),sha)||strcmp(sha,expected)||
    !worldRead(base+0xe8a40,caller,sizeof(caller))||!hashBytes(caller,sizeof(caller),sha)||strcmp(sha,"c35e28612a2ae12d06166e02bd8fa4d7763dc8be4c6dbaf01665f97ee8532f75"))return false;
 MH_STATUS init=MH_Initialize();if(init!=MH_OK&&init!=MH_ERROR_ALREADY_INITIALIZED)return false;
 PVOID target=(void *)(base+p->targetRva);MH_STATUS create=MH_CreateHook(target,(void *)&hostGroundObserve,(void **)&hostGroundOriginal);
 if(create!=MH_OK||MH_EnableHook(target)!=MH_OK)return false;
 hostGroundTarget=target;
#ifdef HOST_CONTACT_FRAME_OBSERVER
 // Full caller hash was checked above, before either hook changed its entry.
 const Sheet_hostContactFrameObserver *fp=&sheet_hostContactFrameObserver_completed_collision;
 if(fp->enabled||fp->gameWrites||fp->targetRva!=0xe8a40||fp->targetBytes!=1230||fp->controlRva!=0x2a88568||fp->callbackRva!=0x2a88598||fp->callbackStride!=0x228||fp->callbackCount!=3||fp->durationMs!=GENERAL_OR_SHORT_MS(60000)||fp->maxFrames!=GENERAL_OR_SHORT_SAMPLES(7200)||wcscmp(fp->codeSha256,L"c35e28612a2ae12d06166e02bd8fa4d7763dc8be4c6dbaf01665f97ee8532f75")){MH_DisableHook(target);hostGroundTarget=NULL;return false;}
 PVOID collision=(void *)(base+fp->targetRva);
 if(MH_CreateHook(collision,(void *)&hostCollisionObserve,(void **)&hostCollisionOriginal)!=MH_OK||MH_EnableHook(collision)!=MH_OK){MH_DisableHook(target);hostGroundTarget=NULL;return false;}
 hostCollisionTarget=collision;logLine("CAPABILITY host_contact_frame_observer=1; completed collision scope, no physics writes");
#endif
 logLine("CAPABILITY host_ground_observer=1; original query forwarding only, dormant until explicit flag");return true;
}
static void hostGroundTick(void){
 const Sheet_hostGroundObserver *p=&sheet_hostGroundObserver_completed_query;
 bool requested=GetFileAttributesW(PROBE_PATH(L"\\host-ground-observe.enable"))!=INVALID_FILE_ATTRIBUTES;
 if(requested&&hostGroundTarget&&!hostGroundStarted&&!InterlockedCompareExchange(&probeBoundedComplete,0,0)){
  hostGroundStarted=true;hostGroundBegin=GetTickCount64();
#ifdef HOST_CONTACT_TRANSPORT
  if(!hostContactSourceOpen(&hostContactSource,hostGroundBegin)){logLine("HOST_CONTACT_RAM refused: mapping/identity unavailable; not armed");return;}
  logLine("CAPABILITY host_contact_ram=1; epoch=%llu creation=%llu; scalar receipts only",hostGroundBegin,hostContactSource.creation);
#endif
  InterlockedExchange(&hostGroundEnabled,1);logLine("HOST_GROUND active=1; read-only completed-query capture");
 }
 if(InterlockedCompareExchange(&hostGroundEnabled,0,0)&&(!requested||!forceDuration(GetTickCount64()-hostGroundBegin,(uint64_t)p->durationMs+1u)||(!forceHelperContinuous()&&InterlockedCompareExchange64(&hostGroundSequence,0,0)>=p->maxSamples))){
  InterlockedExchange(&hostGroundEnabled,0);logLine("HOST_GROUND active=0 samples=%lld dropped=%ld",InterlockedCompareExchange64(&hostGroundSequence,0,0),InterlockedCompareExchange(&hostGroundDropped,0,0));
#ifdef HOST_CONTACT_TRANSPORT
  hostContactSourceStop(&hostContactSource);
#endif
 }
 hostGroundFlush();
}
static void hostGroundStop(void){InterlockedExchange(&hostGroundEnabled,0);
#ifdef HOST_CONTACT_TRANSPORT
 hostContactSourceStop(&hostContactSource);
#endif
 hostGroundFlush();}
