// SPDX-License-Identifier: GPL-3.0-or-later
#pragma once
#include "sr1-free-attack-owner.h"
#include "defiance-host-controls.h"
#include "sr1-combat-input-identity.h"
#include "sr1-input-preparation-lease.h"
static SrFreeAttackOwner srFreePads[SR_INPUT_CHANNELS][2];static uintptr_t srFreeObjects[SR_INPUT_CHANNELS];
static SrFreeAttackOwner srLayoutPads[SR_INPUT_CHANNELS][16];
static RepeatJumpPacket srFreePackets[SR_INPUT_CHANNELS];
static volatile LONG srFreeLock;static bool srFreeLease;static uint64_t srFreeStart,srFreeHeartbeat;static DWORD srFreeWriter;
static unsigned srFreeCalls,srFreeEligible,srFreeConsumed;
static WORD srFreePreviousHardware[SR_INPUT_CHANNELS];
#ifdef SR1_LIFT_FOLLOW
static WORD srLiftApply(DWORD,uint64_t,uintptr_t,bool,const Sr1RetargetContext *,WORD,WORD);
#endif
static WORD srFreeApplyBoundary(DWORD index,uint64_t now,bool boundary,DWORD foreground,const XINPUT_STATE *raw,XINPUT_STATE *output){
 WORD delivered=output->Gamepad.wButtons;
 // Unrelated XInput consumers neither acquire nor revoke this game's press.
 if(!boundary)return delivered;
 if(index>=SR_INPUT_CHANNELS||InterlockedCompareExchange(&srFreeLock,1,0))return delivered;
 const Sheet_freeAttackInputPolicy *p=&sheet_freeAttackInputPolicy_ground_diagnostic;
 uintptr_t base=(uintptr_t)InterlockedCompareExchangePointer(&verifiedSr1Module,NULL,NULL),actor=0,object=0;
 Sr1RetargetContext context={0};int32_t time=0;
 bool owner=p->buttonMask==(XINPUT_GAMEPAD_X|XINPUT_GAMEPAD_LEFT_SHOULDER)&&p->freshMs==150&&(p->seconds==50||p->seconds==170)&&p->prepareSeconds==20&&!p->enabled&&!p->hostDamageWrites&&p->emptyFloorOnly&&
  srFreeLease&&srFreeWriter&&now>=srFreeStart&&forceDuration(now-srFreeStart,(uint64_t)p->seconds*1000)&&now>=srFreeHeartbeat&&now-srFreeHeartbeat<1500&&
  foreground==GetCurrentProcessId()&&boundary&&base&&
  srCombatInputIdentity(NULL,srRepeatRead,base,&actor,&object);
#ifdef SR1_C0_PHYSICAL_WEAPON
 owner=owner&&!sr1C0NativeActive(actor);
#endif
 // raw is this exact successful original XInput poll. Polling again can cross
 // a button edge and must not revoke ownership of the first poll's X press.
 bool current=owner&&worldRead(base+0x2a89628,&time,4)&&time>0&&time<=8192&&sr1RetargetReadContext(NULL,srRepeatRead,base,actor,true,&context);
 bool menu=!current||context.mode||(context.flags&0x10000000u)||(context.callbacks[0]==0xf0240||context.callbacks[0]==0xf0ac0);
 WORD permitted=XINPUT_GAMEPAD_X|XINPUT_GAMEPAD_LEFT_SHOULDER;
#ifdef FORCE_ON_RUNTIME
 permitted|=(WORD)sheet_forceOnPolicy_continuous.benignButtons; // L3/R3 have no gameplay binding; never turn X/Y into native actions.
#endif
 bool action=sr1RetargetContextAllowed(&context);
#ifdef SR1_AIR_COMBAT_POSE
 permitted|=XINPUT_GAMEPAD_A; // A still goes to SR1, including native glide.
#ifdef SR1_LIFT_FOLLOW
 permitted|=XINPUT_GAMEPAD_Y;
#endif
 action=action||sr1RetargetJumpContextAllowed(&context);
#endif
 bool eligible=current&&!menu&&!(raw->Gamepad.wButtons&~permitted)&&raw->Gamepad.bLeftTrigger<30&&raw->Gamepad.bRightTrigger<30&&action;
 if(srFreeObjects[index]!=object){memset(&srFreePads[index],0,sizeof(srFreePads[index]));memset(&srLayoutPads[index],0,sizeof(srLayoutPads[index]));srFreeObjects[index]=object;srFreePreviousHardware[index]=raw->Gamepad.wButtons;}
 ++srFreeCalls;if(eligible)++srFreeEligible;
 WORD filtered=srFreeAttackStep(&srFreePads[index][0],now,actor,owner,eligible,raw->Gamepad.wButtons,delivered,XINPUT_GAMEPAD_X);
 if(owner&&(raw->Gamepad.wButtons&XINPUT_GAMEPAD_X)&&!(srFreePreviousHardware[index]&XINPUT_GAMEPAD_X)&&(filtered&XINPUT_GAMEPAD_X))
  logLine("SR1_FREE_BYPASS tick=%llu current=%u eligible=%u action=%u menu=%u callbacks=%x,%x,%x mode=%u flags=%x vz=%d crouch=%u buttons=%x lt=%u rt=%u; newly passed native X only, no extra writes",(unsigned long long)now,current,eligible,action,menu,context.callbacks[0],context.callbacks[1],context.callbacks[2],context.mode,context.flags,context.verticalVelocity,context.crouchHeld,raw->Gamepad.wButtons,raw->Gamepad.bLeftTrigger,raw->Gamepad.bRightTrigger);
 srFreePreviousHardware[index]=raw->Gamepad.wButtons;
 DefianceHostRoute routes[16];unsigned routeCount=(unsigned)sheet_defianceHostButtons_count;
 if(routeCount<=16){for(unsigned j=0;j<routeCount;j++){routes[j].source=(uint16_t)sheet_defianceHostButtons_rows[j]->sourceMask;routes[j].target=(uint16_t)sheet_defianceHostButtons_rows[j]->hostMask;}
  filtered=defianceHostControls(srLayoutPads[index],routes,routeCount,now,actor,owner,current&&!menu,menu,raw->Gamepad.wButtons,filtered);}
 if(filtered!=delivered)++srFreeConsumed;
#ifdef SR1_LIFT_FOLLOW
 filtered=srLiftApply(index,now,actor,owner&&current&&!menu&&action&&!(raw->Gamepad.wButtons&~permitted)&&raw->Gamepad.bLeftTrigger<30&&raw->Gamepad.bRightTrigger<30,&context,raw->Gamepad.wButtons,filtered);
#endif
 // Every input poll whose result differs must be visible to the game's cache.
 output->dwPacketNumber=repeatJumpPacket(&srFreePackets[index],output->dwPacketNumber,delivered,filtered);
 InterlockedExchange(&srFreeLock,0);return filtered;
}
static WORD srFreeApply(DWORD index,uint64_t now,uintptr_t caller,DWORD foreground,const XINPUT_STATE *raw,XINPUT_STATE *output){
 return index<4?srFreeApplyBoundary(index,now,srInputPollSite(caller,srInputMainBase),foreground,raw,output):output->Gamepad.wButtons;
}
static void srFreeTick(void){
 bool requested=GetFileAttributesW(PROBE_PATH(L"\\free-attack-sr1.enable"))!=INVALID_FILE_ATTRIBUTES;
 // Arm on neutral preparation polls, before the first visible action cue.
 // Acquiring only at completed200 leaves a one-second native LB/map race.
 const Sheet_freeAttackInputPolicy *p=&sheet_freeAttackInputPolicy_ground_diagnostic;
 RecordingStatus status={0};uint64_t now=GetTickCount64();bool valid=requested&&recordingReadStatus(GetCurrentProcessId(),&status)&&recordingStatusValid(&status,GetCurrentProcessId(),now);
 bool lease=srInputPreparationLease(requested,valid,status.total,status.completed,p->leaseDuringPreparation);
 if(InterlockedCompareExchange(&srFreeLock,1,0))return;
 if(!lease||!srFreeLease||srFreeWriter!=status.writerPid){memset(srFreePads,0,sizeof(srFreePads));memset(srLayoutPads,0,sizeof(srLayoutPads));memset(srFreeObjects,0,sizeof(srFreeObjects));srFreeStart=now;}
 srFreeLease=lease;srFreeWriter=lease?status.writerPid:0;srFreeHeartbeat=lease?status.tick:0;
 unsigned calls=srFreeCalls,eligible=srFreeEligible,consumed=srFreeConsumed;InterlockedExchange(&srFreeLock,0);
 if(requested)logLine("SR1_FREE_ATTACK lease=%u calls=%u eligible=%u consumed=%u; empty-floor diagnostic only",lease,calls,eligible,consumed);
}
static void srFreeStop(void){if(InterlockedCompareExchange(&srFreeLock,1,0))return;srFreeLease=false;srFreeWriter=0;memset(srFreePads,0,sizeof(srFreePads));memset(srLayoutPads,0,sizeof(srLayoutPads));InterlockedExchange(&srFreeLock,0);}

