// SPDX-License-Identifier: GPL-3.0-or-later
#pragma once
#include <stdint.h>
#include <stdbool.h>
#include <string.h>
#include <stdio.h>
#include <windows.h>
#include "host-contact-compression.h"
#include "host-contact-native-pause.h"
#ifdef SR1_V38_HANDOFF_R2
#include "exploration-sheets.h"
#endif
#ifdef SR1_C0_PHYSICAL_WEAPON
#include "c0-physical-weapon-policy.h"
#endif

#ifdef GENERAL_FREE_TEST
#ifdef SR1_C0_PHYSICAL_WEAPON
#define HOST_CONTACT_VERSION 3u
#else
#define HOST_CONTACT_VERSION 2u
#endif
#define HOST_CONTACT_MAX_MS 200000u
#define HOST_CONTACT_MAX_PHASE 4u
#else
#define HOST_CONTACT_VERSION 1u
#define HOST_CONTACT_MAX_MS 60000u
#define HOST_CONTACT_MAX_PHASE 3u
#endif

#define HOST_CONTACT_MAGIC 0x31435748u
// phase: 0 unknown, 1 completed ground, 2 completed air, 3 proved compression.
// Compression does not assert a contact. No process pointers may be dereferenced by the peer.
typedef struct {
 uint32_t magic,version,pid,phase;
 uint64_t creation,epoch,tick,sequence,actor;
 uint32_t control,coherent;
 uint64_t callbacks[3];
 int32_t verticalVelocity;
 uint32_t reserved;
} HostContactSnapshot;
typedef struct {volatile LONG guard,revoked;HostContactSnapshot value;} HostContactShared;
_Static_assert(sizeof(HostContactSnapshot)==96,"Host contact wire layout changed");
_Static_assert(sizeof(HostContactShared)==104,"Host contact mapping layout changed");
#ifdef SR1_C0_PHYSICAL_WEAPON
static inline bool hostContactC0WeaponCallbacks(const uint64_t callbacks[3]){
 const Sheet_nativeInteractionR12 *image=&sheet_nativeInteractionR12_current;
 for(unsigned i=0;i<3;i++)
  if(callbacks[i]<(uint64_t)image->textStartRva||callbacks[i]>=(uint64_t)image->textEndRva)return false;
 return true;
}
static inline bool hostContactC0Weapon(const HostContactSnapshot *s){
 const Sheet_c0RuntimeOwnership *p=&sheet_c0RuntimeOwnership_linked;
 return p->contactVersion==HOST_CONTACT_VERSION&&p->contactTag==1&&p->nativePhase==4&&p->contactFreshMs==250&&
  s&&s->magic==HOST_CONTACT_MAGIC&&s->version==HOST_CONTACT_VERSION&&s->phase==(uint32_t)p->nativePhase&&
  s->coherent==1&&s->reserved==(uint32_t)p->contactTag&&hostContactC0WeaponCallbacks(s->callbacks);
}
#endif
static inline bool hostContactNativeSnapshot(const HostContactSnapshot *s){
 if(!s||s->phase!=4)return false;
#ifdef SR1_C0_PHYSICAL_WEAPON
 if(s->reserved)return hostContactC0Weapon(s);
#endif
 return !s->reserved&&hostContactNativePause(s->callbacks);
}
static inline void hostContactMappingName(wchar_t name[96],DWORD pid){_snwprintf(name,96,L"Local\\LOKHostContact-v1-%lu",pid);}
// Caller serializes writers; readers never acquire a lock in the game thread.
static inline void hostContactStore(HostContactShared *m,const HostContactSnapshot *s){
 InterlockedIncrement(&m->guard);MemoryBarrier();memcpy(&m->value,s,sizeof(*s));MemoryBarrier();InterlockedIncrement(&m->guard);
}
static inline bool hostContactCopy(const HostContactShared *m,HostContactSnapshot *s){
 if(!m||!s||m->revoked)return false;
 for(unsigned i=0;i<3;i++){LONG g=m->guard;if(g&1)continue;MemoryBarrier();memcpy(s,&m->value,sizeof(*s));MemoryBarrier();if(g==m->guard&&!m->revoked)return true;}
 return false;
}
typedef struct {uint32_t pid;uint64_t creation,epoch,actor;HostContactSnapshot last;bool seen,revoked;} HostContactLease;
static inline bool hostContactAccept(HostContactLease *l,const HostContactSnapshot *s,uint64_t now,bool processAlive,bool *fresh){
 if(fresh)*fresh=false;
 if(!l||!s||!fresh||l->revoked)return false;
 // A suspended native action does not project a floor or air contact. Only
 // that already admitted suspension tolerates the measured 187ms bars gap.
 unsigned ageLimit=HOST_CONTACT_MAX_PHASE==4&&l->seen&&l->last.phase==4&&s->phase==4?250u:150u;
#ifdef SR1_V38_HANDOFF_R2
 const Sheet_v38NativeWait *p=&sheet_v38NativeWait_native_suspend;
 if(!p->enabled&&p->barsFreshMs==500&&p->barsCallback==0xecf70&&p->barsControl==32769&&HOST_CONTACT_MAX_PHASE==4&&l->seen&&l->last.phase==4&&s->phase==4&&s->control==(unsigned)p->barsControl&&l->last.control==s->control){
  bool sameBars=true;for(unsigned i=0;i<3;i++)sameBars=sameBars&&s->callbacks[i]==(uint64_t)p->barsCallback&&l->last.callbacks[i]==s->callbacks[i];
  if(sameBars)ageLimit=(unsigned)p->barsFreshMs;
 }
#endif
 bool ok=processAlive&&l->pid&&l->creation&&l->epoch&&l->actor&&s->magic==HOST_CONTACT_MAGIC&&s->version==HOST_CONTACT_VERSION&&
  s->pid==l->pid&&s->creation==l->creation&&s->epoch==l->epoch&&s->actor==l->actor&&s->sequence&&
  s->epoch<=s->tick&&s->tick<=now&&now-s->tick<=ageLimit&&forceDuration(s->tick-s->epoch,HOST_CONTACT_MAX_MS+1u)&&s->coherent==1&&s->phase>=1&&s->phase<=HOST_CONTACT_MAX_PHASE&&
  (!s->reserved||s->phase==4)&&
  (!(s->control&0x4000000)||(HOST_CONTACT_MAX_PHASE==4&&s->phase==4&&hostContactNativeHangControl(s->control,s->callbacks)));
 if(ok&&s->phase==1)ok=(s->control&8)!=0;
 if(ok&&s->phase==2&&!(s->control&8))ok=s->control==0x511&&s->callbacks[0]==0xf2ae0&&s->callbacks[1]==0xf2ae0&&s->callbacks[2]==0xf2ae0;
 if(ok&&s->phase==3)ok=hostContactCompression(s->control,s->callbacks);
 if(ok&&s->phase==4)ok=hostContactNativeSnapshot(s);
 if(ok&&l->seen){
  ok=s->sequence>=l->last.sequence&&s->tick>=l->last.tick;
  if(ok&&s->sequence==l->last.sequence){ok=!memcmp(s,&l->last,sizeof(*s));if(ok)return true;}
 }
 if(!ok){l->revoked=true;return false;}
 l->last=*s;l->seen=true;*fresh=true;return true;
}
