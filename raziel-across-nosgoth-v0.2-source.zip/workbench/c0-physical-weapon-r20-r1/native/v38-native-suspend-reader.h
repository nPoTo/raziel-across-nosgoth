// SPDX-License-Identifier: GPL-3.0-or-later
#pragma once
#include "host-contact-shared.h"
#ifdef SR1_NATIVE_OBJECT_GAP_R18
#include "native-object-gap-r18.h"
#endif

// An independent scalar receipt may keep a native wait alive. It never admits
// a drawable rig or copies matrices. The external session pins epoch as well.
static inline bool v38NativeSuspendRead(const HostContactShared *view,const HostRig *identity,const Sr1RetargetContext *context,DWORD pid,uint64_t creation,uint64_t now,HostContactSnapshot *out){
 const Sheet_v38NativeWait *p=&sheet_v38NativeWait_native_suspend;
 if(!p->readOnly||p->enabled||p->contactFreshMs!=250||p->nativePhase!=4||p->publishCachedBones||p->publishTravel||!context->identity||!context->foreground||context->mode||(context->flags&0x10000000u))return false;
 if(!hostContactCopy(view,out))return false;
 bool bars=p->barsFreshMs==500&&p->barsCallback==0xecf70&&p->barsControl==32769&&out->control==(unsigned)p->barsControl;
 for(unsigned i=0;i<3;i++)bars=bars&&out->callbacks[i]==(uint64_t)p->barsCallback;
 const unsigned ageLimit=bars?(unsigned)p->barsFreshMs:(unsigned)p->contactFreshMs;
 if(out->magic!=HOST_CONTACT_MAGIC||out->version!=HOST_CONTACT_VERSION||out->pid!=pid||out->creation!=creation||out->actor!=identity->actor||!out->epoch||!out->sequence||out->epoch>out->tick||out->tick>now||now-out->tick>ageLimit||!forceDuration(out->tick-out->epoch,HOST_CONTACT_MAX_MS+1u)||out->phase!=(unsigned)p->nativePhase||out->coherent!=1||!hostContactNativeSnapshot(out))return false;
 if((out->control&0x4000000u)&&!hostContactNativeHangControl(out->control,out->callbacks))return false;
 for(unsigned i=0;i<3;i++)if(out->callbacks[i]!=context->callbacks[i])return false;
 return true;
}
#ifdef SR1_V38_REPAIR_R2
#include "v38-bars-suspension.h"
static inline bool v38NativeSuspendPendingRead(const HostContactShared *view,const HostRig *identity,const Sr1RetargetContext *c,DWORD pid,uint64_t creation,uint64_t now,HostContactSnapshot *out){
 if(v38NativeSuspendRead(view,identity,c,pid,creation,now,out))return true;
#ifdef SR1_NATIVE_OBJECT_GAP_R18
 if(c->identity&&c->foreground&&!c->mode&&!(c->flags&0x10000000u)&&hostContactCopy(view,out)&&nativeObjectGapSnapshotR18(out)&&out->pid==pid&&out->creation==creation&&out->actor==identity->actor&&out->epoch&&out->sequence&&out->epoch<=out->tick&&out->tick<=now&&now-out->tick>250&&now-out->tick<=1500&&forceDuration(now-out->epoch,HOST_CONTACT_MAX_MS+1u)){
  bool same=true;for(unsigned i=0;i<3;i++)same=same&&c->callbacks[i]==out->callbacks[i];if(same)return true;
 }
#endif

 // Fresh double-read context comes from the current host observation. The old
 // collision tick is retained as provenance; this admits no drawable pose.
 if(!c->identity||!c->foreground||c->mode||(c->flags&0x10000000u)||!hostContactCopy(view,out)||!v38BarsSnapshot(out))return false;
 if(out->pid!=pid||out->creation!=creation||out->actor!=identity->actor||!out->epoch||!out->sequence||out->epoch>out->tick||out->tick>now||now-out->tick<=500||!forceDuration(now-out->epoch,HOST_CONTACT_MAX_MS+1u))return false;
 for(unsigned i=0;i<3;i++)if(c->callbacks[i]!=out->callbacks[i])return false;
 return true;
}
static inline bool v38CompletedContactRead(const HostContactShared *view,const HostRig *r,const Sr1RetargetContext *c,DWORD pid,uint64_t creation,uint64_t now,HostContactSnapshot *out){
 if(!c->identity||!c->foreground||c->mode||(c->flags&0x10000000u)||!hostContactCopy(view,out))return false;
 HostContactLease once={.pid=pid,.creation=creation,.epoch=out->epoch,.actor=r->actor};bool fresh=false;
 if(out->phase<1||out->phase>3||!hostContactAccept(&once,out,now,true,&fresh)||!fresh)return false;
 for(unsigned i=0;i<3;i++)if(c->callbacks[i]!=out->callbacks[i])return false;
 return true;
}
#endif
