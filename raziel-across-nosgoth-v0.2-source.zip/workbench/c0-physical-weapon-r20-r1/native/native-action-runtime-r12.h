// SPDX-License-Identifier: GPL-3.0-or-later
#pragma once
#include "native-action-route-r12.h"
#include "native-interaction-context-r12.h"
#include "native-action-callbacks-r12.h"
#ifdef SR1_C0_PHYSICAL_WEAPON
#include "c0-runtime-action.h"
#endif
// Completed host-input thread only. No native calls or world writes.
static NativeActionRouteR12 srNativeRouteR12;
static uint64_t srNativeRouteLastLogR12;
static NativeActionDecisionR12 srNativeActionPrepareR12(uint64_t now,uintptr_t actor,bool owner,const Sr1RetargetContext *c,uint16_t buttons
#ifdef SR1_C0_PHYSICAL_WEAPON
 ,uint64_t c0Epoch,bool c0Scope
#endif
){
 const Sheet_nativeActionRouteR12 *policy=&sheet_nativeActionRouteR12_contextual_action;
 NativeActionDecisionR12 none={0};
 if(policy->actionMask!=0x4000||!policy->onePressOneOwner||!policy->currentAxesOnReturn||!policy->heldActionNeedsRelease||!policy->noFixedActionTimer||!policy->donorNeutralDuringNative)return none;
 const uintptr_t base=(uintptr_t)InterlockedCompareExchangePointer(&verifiedSr1Module,NULL,NULL);
 uint64_t cb[3]={0};if(c)for(unsigned i=0;i<3;i++)cb[i]=c->callbacks[i];
 const bool known=owner&&base&&c&&c->identity;
 const bool busy=known&&(c->crouchHeld||hostContactNativePause(cb));
 const bool ordinary=known&&(sr1RetargetContextAllowed(c)||sr1RetargetJumpContextAllowed(c));
 HostContactSnapshot contact={0};
 const bool completed=known&&hostContactCopy(hostContactSource.view,&contact)&&contact.actor==actor&&contact.pid==GetCurrentProcessId()&&contact.creation==hostContactSource.creation&&contact.epoch==hostContactSource.epoch&&contact.sequence&&contact.coherent==1&&contact.phase>=1&&contact.phase<=4&&contact.tick<=now&&now-contact.tick<=150;
 Sr1NativeExitSample exit={0};bool exitComplete=false;
 if(known&&srNativeRouteR12.nativeOwned&&!busy&&ordinary)exitComplete=sr1NativeExitRead(NULL,srRepeatRead,actor,&exit)&&!sr1NativeExitBlending(&exit);
 NativeInteractionContextR12 availability={0};
 const bool down=(buttons&(uint16_t)policy->actionMask)!=0,newPress=down&&!srNativeRouteR12.down;
 const bool query=known&&newPress&&!busy&&ordinary
#ifdef SR1_C0_PHYSICAL_WEAPON
  &&!sr1C0NativeActive(actor)
#endif
 ;
 const bool queried=query&&nativeInteractionContextR12Read(NULL,srRepeatRead,base,actor,&availability);
 bool available=queried&&availability.available,nativeBusy=busy;
#ifdef SR1_C0_PHYSICAL_WEAPON
 // Keep the original contextual branch ahead of the slot-5 fallback.
 const Sheet_nativeInteractionR12 *contextPolicy=&sheet_nativeInteractionR12_current;
 const bool c0Edge=queried&&srNativeRouteR12.armed&&!srNativeRouteR12.nativeOwned&&availability.converted&&!availability.kind&&
  !(availability.flags&(uint32_t)contextPolicy->commonMask)&&
  (availability.flags&(uint32_t)contextPolicy->pickupMask);
 const bool c0Press=sr1C0ActionStep(c0Epoch,now,base,actor,c0Scope&&known,c0Edge,available,down);
 available=available||c0Press;
 nativeBusy=busy||(!c0Press&&sr1C0NativeActive(actor));
#endif
 // New unknown reads cannot assign a fresh press. An already assigned press
 // retains its destination until release, independent of changing targets.
 const bool decisionKnown=known&&(!query||queried);
 NativeActionObservationR12 o={.ownerAlive=owner,.contextKnown=decisionKnown,.available=available,.nativeBusy=nativeBusy,.ordinary=ordinary,.exitComplete=exitComplete&&completed&&contact.phase!=4,.actor=actor,.tick=now,.hostStep=completed?contact.sequence:0,.actionDown=down};
 NativeActionDecisionR12 r=nativeActionRouteR12Step(&srNativeRouteR12,o);
 if(newPress||r.entered||r.returned||(r.nativeOwned&&now-srNativeRouteLastLogR12>=1000)){
  logLine("NATIVE_ACTION_R12 tick=%llu available=%u query=%u converted=%u flags=%x kind=%u target=%u busy=%u native=%u requesting=%u entered=%u returned=%u press=%u step=%llu; scalar ownership only",(unsigned long long)now,availability.available,queried,availability.converted,availability.flags,availability.kind,availability.targetPresent,busy,r.nativeOwned,r.requestingNative,r.entered,r.returned,srNativeRouteR12.pressOwner,(unsigned long long)o.hostStep);srNativeRouteLastLogR12=now;
 }
 return r;
}
