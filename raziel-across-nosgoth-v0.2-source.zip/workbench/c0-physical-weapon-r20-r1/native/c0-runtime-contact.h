// SPDX-License-Identifier: GPL-3.0-or-later
#pragma once
#include "c0-physical-weapon-policy.h"

typedef struct {
    uintptr_t actor;
    uint64_t tick, sequence, callbacks[3];
    uint32_t phase;
} C0RawContact;

static SRWLOCK sr1C0ContactLock = SRWLOCK_INIT;
static C0RawContact sr1C0Contact;
static PVOID volatile sr1C0Owner;
static volatile LONG64 sr1C0Epoch;

static void sr1C0Session(uint64_t epoch) {
    InterlockedExchange64(&sr1C0Epoch, 0);
    InterlockedExchangePointer(&sr1C0Owner, NULL);
    if (epoch) InterlockedExchange64(&sr1C0Epoch, (LONG64)epoch);
}

static bool sr1C0NativeActive(uintptr_t actor) {
    return actor && InterlockedCompareExchange64(&sr1C0Epoch, 0, 0) &&
           InterlockedCompareExchangePointer(&sr1C0Owner, NULL, NULL) == (PVOID)actor;
}

static void sr1C0ObserveCompletedContact(uintptr_t actor, uint64_t tick, uint64_t sequence,
                                        uint32_t phase, bool coherent, const uint64_t callbacks[3]) {
    if (!TryAcquireSRWLockExclusive(&sr1C0ContactLock)) return;
    sr1C0Contact = (C0RawContact){0};
    if (coherent && actor && tick && sequence && phase <= 3) {
        sr1C0Contact = (C0RawContact){.actor=actor,.tick=tick,.sequence=sequence,.phase=phase};
        memcpy(sr1C0Contact.callbacks, callbacks, sizeof(sr1C0Contact.callbacks));
    }
    ReleaseSRWLockExclusive(&sr1C0ContactLock);
}

static bool sr1C0ReadContact(uintptr_t actor, uint64_t epoch, uint64_t now, C0RawContact *out) {
    if (!TryAcquireSRWLockShared(&sr1C0ContactLock)) return false;
    *out = sr1C0Contact;
    ReleaseSRWLockShared(&sr1C0ContactLock);
    return actor && out->actor == actor && out->sequence && out->tick >= epoch && out->tick <= now &&
           now - out->tick <= (uint64_t)sheet_c0RuntimeOwnership_linked.inputContactFreshMs;
}
