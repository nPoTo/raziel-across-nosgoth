// SPDX-License-Identifier: GPL-3.0-or-later
#pragma once
#include "host-draw-receipt.h"
#include "host-contact-shared.h"

static inline bool c0OwnershipContext(const Sr1RetargetContext *context) {
    if (!context->identity || !context->foreground || context->mode || (context->flags & 0x10000000u)) return false;
    const uint64_t callbacks[3] = {context->callbacks[0], context->callbacks[1], context->callbacks[2]};
    return hostContactC0WeaponCallbacks(callbacks);
}

// Validate only the draw's owned resource identity. This never grants a
// drawable pose and the original draw and return checks stay separate.
static inline bool c0OwnershipSuspendRead(const HostContactShared *view, const HostDrawReceipt *draw,
                                         const HostRig *live, const Sr1RetargetContext *context,
                                         DWORD pid, uint64_t creation, uint64_t now,
                                         HostContactSnapshot *out, bool *callbacksDiffer) {
    const Sheet_c0RuntimeOwnership *p = &sheet_c0RuntimeOwnership_linked;
    *callbacksDiffer = false;
    if (!pid || !creation || !live->actor || !live->object || !live->model || !hostDrawPolicy() ||
        draw->magic != 0x31524448u || draw->version != 1 || draw->pid != pid || draw->creation != creation ||
        draw->valid != 1 || !draw->serial || !draw->tick || draw->tick > now ||
        now - draw->tick > (uint64_t)p->inputContactFreshMs || memcmp(draw->policy, skeletonPolicyHash, 32) ||
        !hostDrawResourceSame(&draw->rig, live) || !c0OwnershipContext(context)) return false;
    HostContactSnapshot s;
    if (!hostContactCopy(view, &s) || !hostContactC0Weapon(&s) || s.pid != pid || s.creation != creation ||
        s.actor != live->actor || !s.epoch || !s.sequence || s.epoch > s.tick || s.tick > now ||
        now - s.tick > (uint64_t)p->contactFreshMs || !forceDuration(s.tick - s.epoch, HOST_CONTACT_MAX_MS + 1u) ||
        ((s.control & 0x4000000u) && !hostContactNativeHangControl(s.control, s.callbacks))) return false;
    *out = s;
    for (unsigned i = 0; i < 3; ++i) *callbacksDiffer = *callbacksDiffer || s.callbacks[i] != context->callbacks[i];
    return true;
}
