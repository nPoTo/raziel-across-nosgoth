// SPDX-License-Identifier: GPL-3.0-or-later
// Bounded read-only host stream. Skeletal payload exists only in an anonymous
// pipe; the caller must not log it or persist extracted resources.
#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <tlhelp32.h>
#include <bcrypt.h>
#include <stdio.h>
#include <stdlib.h>
#include <wchar.h>
#include "host-rig-reader.h"
#include "reader-hash.h"
#include "sr1-retarget-gate.h"
#if defined(SR1_V38_HANDOFF_R2) && defined(SR1_GENERAL_ALL_IN_RUNTIME)
#include "sr1-completed-ground-contact.h"
static const HostContactShared *completedGroundStreamView;
static Sr1CompletedGroundReader completedGroundStreamReader;
static bool sr1CompletedGroundStream(uintptr_t actor,const Sr1RetargetContext *c){
 // Process path/hash/creation are verified before this provider is called.
 // Adopt a source epoch only from a fully authenticated current collision,
 // then keep it pinned even if a later source attempts to replace it.
 return sr1CompletedGroundPinnedRead(&completedGroundStreamReader,completedGroundStreamView,c,actor,GetTickCount64());
}
#define SR1_COMPLETED_GROUND_READ(actor,context) sr1CompletedGroundStream((actor),(context))
#endif
#include "sr1-actor-position-read.h"
#ifdef SR1_NATIVE_EXIT_GUARD
#include "sr1-native-exit-reader.h"
#endif
#ifdef SR1_HANDOFF_CONTINUITY
#include "host-rig-continuity.h"
#include "sr1-retarget-context-reader.h"
#ifdef SR1_RIG_RETRY
#include "host-rig-acquire.h"
static uint64_t rigClockUs(void *unused){(void)unused;LARGE_INTEGER t,f;if(!QueryPerformanceCounter(&t)||!QueryPerformanceFrequency(&f)||f.QuadPart<=0)return UINT64_MAX;return (uint64_t)(t.QuadPart/f.QuadPart)*1000000+(uint64_t)(t.QuadPart%f.QuadPart)*1000000/(uint64_t)f.QuadPart;}
#endif
#endif
#ifdef SR1_NATIVE_DRAW_RECEIPT
#include "host-draw-receipt.h"
#ifdef SR1_V38_HANDOFF_R2
#include "v38-native-suspend-reader.h"
#endif
#endif
#ifdef SR1_SKELETON_CADENCE60
#include "capture-cadence.h"
#endif
static bool readAt(void *c,uintptr_t p,void *out,SIZE_T n){SIZE_T got=0;return p&&ReadProcessMemory((HANDLE)c,(LPCVOID)p,out,n,&got)&&got==n;}
#if !defined(SR1_RIG_RETRY) || defined(SR1_NATIVE_DRAW_RECEIPT)
static bool contextRead(HANDLE p,uintptr_t base,uintptr_t actor,Sr1RetargetContext *s){
#ifdef SR1_HANDOFF_CONTINUITY
 DWORD front=0;GetWindowThreadProcessId(GetForegroundWindow(),&front);return sr1RetargetReadContext(p,readAt,base,actor,front==GetProcessId(p),s);
#else
 uintptr_t owner=0,again=0,cb[3];uint16_t mode=0,mode2=0;uint32_t flags=0,flags2=0;int32_t velocity=0,velocityAfter=0;DWORD front=0;memset(s,0,sizeof(*s));GetWindowThreadProcessId(GetForegroundWindow(),&front);s->foreground=front==GetProcessId(p);
 const Sheet_retargetNativeAirGuard *air=&sheet_retargetNativeAirGuard_sr1;
 if(air->verticalVelocityOffset!=0x2d4||air->verticalVelocityBytes!=4||!air->zeroVerticalVelocityRequired||air->hostWrites||!readAt(p,base+0x2a88588,&owner,8)||owner!=actor||!readAt(p,base+0x2a89536,&mode,2)||!readAt(p,base+0x2a8950c,&flags,4)||!readAt(p,actor+air->verticalVelocityOffset,&velocity,4))return false;
 for(unsigned i=0;i<3;i++){if(!readAt(p,base+0x2a88598+i*0x228,cb+i,8)||cb[i]<base||cb[i]-base>UINT32_MAX)return false;s->callbacks[i]=(uint32_t)(cb[i]-base);}
 if(!readAt(p,base+0x2a88588,&again,8)||again!=owner||!readAt(p,base+0x2a89536,&mode2,2)||mode2!=mode||!readAt(p,base+0x2a8950c,&flags2,4)||flags2!=flags||!readAt(p,actor+air->verticalVelocityOffset,&velocityAfter,4)||velocityAfter!=velocity)return false;
 s->identity=true;s->mode=mode;s->flags=flags;s->verticalVelocityKnown=true;s->verticalVelocity=velocity;return true;
#endif
}
#endif
int wmain(int argc,wchar_t **argv){
 bool fast=false;unsigned long requested=0;uint64_t fastWall=120000;uint32_t captureHz=0;
#ifdef SR1_SKELETON_CADENCE60
 captureHz=argc==4&&!wcscmp(argv[2],L"--skeleton-60")?60:
  argc==4&&!wcscmp(argv[2],L"--skeleton-120")?120:0;
 bool cadenceFailed=false;fast=captureHz!=0;
 if(fast){const Sheet_skeletonCadencePolicy *cp=&sheet_skeletonCadencePolicy_capture;
  if(!captureSelectHz(captureHz,(uint32_t)cp->targetHz)||!((cp->maxSamples==7200&&cp->maxWallMs==120000)||(cp->maxSamples==8400&&cp->maxWallMs==140000)||(cp->maxSamples==12000&&cp->maxWallMs==200000))||!cp->helperOnly||cp->gameWrites)return 1;
  wchar_t *last=NULL;requested=wcstoul(argv[3],&last,10);if(!requested||*last||requested>(unsigned long)cp->maxSamples)return 1;fastWall=(uint64_t)cp->maxWallMs;
 }
#endif
 if((argc!=2&&!fast)||GetFileType(GetStdHandle(STD_OUTPUT_HANDLE))!=FILE_TYPE_PIPE)return 1;
 wchar_t *end=NULL;unsigned long pid=wcstoul(argv[1],&end,10);if(!pid||*end||pid>UINT32_MAX)return 1;
 HANDLE p=OpenProcess(PROCESS_VM_READ|PROCESS_QUERY_LIMITED_INFORMATION,FALSE,(DWORD)pid);if(!p)return 2;
#ifdef SR1_V38_HANDOFF_R2
 HANDLE contactMapping=NULL;const HostContactShared *contactView=NULL;
#endif
 wchar_t file[32768];DWORD n=ARRAYSIZE(file);char digest[65];int result=3;
 if(!QueryFullProcessImageNameW(p,0,file,&n)||!wcsrchr(file,L'\\')||_wcsicmp(wcsrchr(file,L'\\')+1,L"SRX.exe")||!hashFile(file,digest)||strcmp(digest,"0fb3aef0530ebf0510191f934dc371b69b43574331d3623eda694b72f060db93"))goto done;
 HANDLE snap=CreateToolhelp32Snapshot(TH32CS_SNAPMODULE|TH32CS_SNAPMODULE32,(DWORD)pid);if(snap==INVALID_HANDLE_VALUE)goto done;
 MODULEENTRY32W me={.dwSize=sizeof(me)};uintptr_t base=0;
 if(Module32FirstW(snap,&me))do{if(!_wcsicmp(me.szModule,L"sr1.dll")&&hashFile(me.szExePath,digest)&&!strcmp(digest,"c006dea45509cdc3fbfab3a4230b47869c306ecdd7df8b4fd2499fd3654a2205")){base=(uintptr_t)me.modBaseAddr;break;}}while(Module32NextW(snap,&me));CloseHandle(snap);if(!base)goto done;
 FILETIME creation,exit,kernel,user;if(!GetProcessTimes(p,&creation,&exit,&kernel,&user))goto done;
#if defined(SR1_V38_HANDOFF_R2) && defined(SR1_GENERAL_ALL_IN_RUNTIME)
 completedGroundStreamReader.pid=(uint32_t)pid;completedGroundStreamReader.creation=((uint64_t)creation.dwHighDateTime<<32)|creation.dwLowDateTime;
#endif
 const Sheet_retargetPreviewPolicy *policy=&sheet_retargetPreviewPolicy_bounded;
 if(policy->maxSamples>4200||policy->intervalMs<33||policy->hostPhysicsWrites||policy->saveWrites||!policy->swimmingNative||!policy->flightNative||!policy->glideNative)goto done;
 HANDLE cadenceTimer=NULL;uint64_t started=GetTickCount64();
#ifdef SR1_SKELETON_CADENCE60
 LARGE_INTEGER cadenceFrequency={0},cadenceOrigin={0};
 if(fast){if(!QueryPerformanceFrequency(&cadenceFrequency)||!QueryPerformanceCounter(&cadenceOrigin)||!captureNextHz((uint64_t)cadenceOrigin.QuadPart,(uint64_t)cadenceOrigin.QuadPart,(uint64_t)cadenceFrequency.QuadPart,captureHz))goto done;cadenceTimer=CreateWaitableTimerExW(NULL,NULL,2,TIMER_ALL_ACCESS);if(!cadenceTimer)cadenceTimer=CreateWaitableTimerW(NULL,FALSE,NULL);}
#endif
 printf("{\"type\":\"session\",\"pid\":%lu,\"creation\":\"%llu\",\"moduleSha256\":\"%s\",\"captureHz\":%u}\n",pid,((unsigned long long)creation.dwHighDateTime<<32)|creation.dwLowDateTime,digest,captureHz);fflush(stdout);
 uintptr_t actor=0,model=0;unsigned epoch=0;
#ifdef SR1_NATIVE_EXIT_GUARD
 Sr1NativeExitLatch exitLatch={.nativeOwned=true};
#endif
#ifdef SR1_HANDOFF_CONTINUITY
 #ifndef SR1_NATIVE_DRAW_RECEIPT
 HostRigContinuity continuity={0};
#else
 HANDLE drawMapping=NULL;const HostDrawShared *drawView=NULL;
#endif
#endif
 for(unsigned long j=0;(forceHelperContinuous()||j<(fast?requested:(unsigned long)policy->maxSamples));j++){
  if(fast&&!forceDuration(GetTickCount64()-started,fastWall))break;
  DWORD status=0;if(!GetExitCodeProcess(p,&status)||status!=STILL_ACTIVE){result=4;goto done;}
#ifdef SR1_V38_HANDOFF_R2
  // Open before context/draw/input admission; diagnostics used to open only
  // after those decisions, too late for the completed-ground proof.
  if(!contactView){wchar_t name[96];hostContactMappingName(name,(DWORD)pid);contactMapping=OpenFileMappingW(FILE_MAP_READ,FALSE,name);if(contactMapping){contactView=MapViewOfFile(contactMapping,FILE_MAP_READ,0,0,sizeof(HostContactShared));if(!contactView){CloseHandle(contactMapping);contactMapping=NULL;}}}
#ifdef SR1_GENERAL_ALL_IN_RUNTIME
  completedGroundStreamView=contactView;
#endif
#endif
  HostRig r;Sr1RetargetContext c={0};bool valid,context;uint64_t observedTick=0,rigTick=0;unsigned reason=0;
#ifdef SR1_HANDOFF_CONTINUITY
#ifdef SR1_NATIVE_DRAW_RECEIPT
  bool held=false;HostDrawReceipt receipt={0};HostRig current={0},after={0};
  if(!drawView){wchar_t name[96];hostDrawName(name,(DWORD)pid);drawMapping=OpenFileMappingW(FILE_MAP_READ,FALSE,name);if(drawMapping){drawView=MapViewOfFile(drawMapping,FILE_MAP_READ,0,0,sizeof(HostDrawShared));if(!drawView){CloseHandle(drawMapping);drawMapping=NULL;}}}
  bool copied=hostDrawCopy(drawView,&receipt);
  context=rigIdentitySnapshot(p,readAt,base,&current)&&contextRead(p,base,current.actor,&c)&&rigIdentitySnapshot(p,readAt,base,&after)&&hostDrawResourceSame(&current,&after);
  observedTick=GetTickCount64();uint64_t processCreation=((uint64_t)creation.dwHighDateTime<<32)|creation.dwLowDateTime;
  valid=copied&&context&&hostDrawAccept(&receipt,(DWORD)pid,processCreation,observedTick,&current,&c);
  reason=valid?0:!copied?16:!context?17:18;rigTick=valid?receipt.tick:observedTick;if(valid)r=receipt.rig;
#elif defined(SR1_RIG_RETRY)
  RigAcquisition acquisition={0};DWORD front=0;GetWindowThreadProcessId(GetForegroundWindow(),&front);
  rigAcquire(p,readAt,base,front==GetProcessId(p),sr1RetargetReadContext,rigClockUs,&acquisition);
  bool held=false;reason=acquisition.reason;c=acquisition.context;context=c.identity;
  observedTick=GetTickCount64();
  valid=hostRigContinuitySelect(&continuity,&acquisition.receipt,acquisition.coherent,acquisition.matrixRace,reason,acquisition.same,&c,observedTick,&r,&rigTick,&held);
#else
  HostRig observed={0},raceIdentity={0},current={0},after={0};bool matrixRace=false,held=false;
  bool coherent=hostRigReadClassified(p,readAt,base,&observed,&raceIdentity,&matrixRace);reason=rigReadFailure;
  // Context is a current independent observation even if matrices raced. Never
  // manufacture zero callbacks/focus from a rejected full matrix snapshot.
  bool identity=rigIdentitySnapshot(p,readAt,base,&current);
  context=identity&&contextRead(p,base,current.actor,&c);
  context=context&&rigIdentitySnapshot(p,readAt,base,&after)&&rigSameIdentity(&current,&after);
  const HostRig *receipt=coherent?&observed:matrixRace?&raceIdentity:NULL;
  bool same=context&&receipt&&rigSameIdentity(receipt,&current);observedTick=GetTickCount64();
  valid=hostRigContinuitySelect(&continuity,receipt,coherent,matrixRace,reason,same,&c,observedTick,&r,&rigTick,&held);
#endif
#else
  valid=hostRigRead(p,readAt,base,&r);reason=rigReadFailure;context=valid&&contextRead(p,base,r.actor,&c);observedTick=rigTick=GetTickCount64();
#endif
#ifdef SR1_C0_PHYSICAL_WEAPON
  HostContactSnapshot c0Suspension={0};
  const bool c0Suspended=context&&copied&&hostDrawResourceSame(&receipt.rig,&current)&&
   v38NativeSuspendRead(contactView,&current,&c,(DWORD)pid,processCreation,observedTick,&c0Suspension)&&
   hostContactC0Weapon(&c0Suspension);
#endif
  bool allowed=context&&valid&&sr1RetargetContextAllowed(&c);
#ifdef SR1_C0_PHYSICAL_WEAPON
  allowed=allowed&&!c0Suspended;
#endif
  if(valid&&(r.actor!=actor||r.model!=model)){actor=r.actor;model=r.model;epoch++;
#ifdef SR1_NATIVE_EXIT_GUARD
   exitLatch.nativeOwned=true;
#endif
  }
#ifdef SR1_NATIVE_EXIT_GUARD
  Sr1NativeExitSample exitPose={0};Sr1RetargetContext exitContext={0};HostRig exitIdentity={0};
  bool exitKnown=valid&&context&&sr1NativeExitRead(p,readAt,r.actor,&exitPose)&&contextRead(p,base,r.actor,&exitContext)&&hostDrawContextSame(&c,&exitContext)&&rigIdentitySnapshot(p,readAt,base,&exitIdentity)&&hostDrawResourceSame(&r,&exitIdentity);
  bool exitAction=context&&(sr1RetargetContextAllowed(&c)||sr1RetargetJumpContextAllowed(&c));
#ifdef SR1_C0_PHYSICAL_WEAPON
  if(c0Suspended){exitLatch.nativeOwned=true;exitAction=false;}
#endif
  bool exitAdmitted=sr1NativeExitAdmitCurrent(&exitLatch,context,exitAction,exitKnown,&exitPose,&c);
  allowed=allowed&&exitAdmitted;
#endif
  printf("{\"type\":\"sample\",\"sequence\":%lu,\"tick\":%llu,\"valid\":%s,\"allowed\":%s,\"reason\":%u,\"epoch\":%u,\"callbacks\":[%u,%u,%u],\"foreground\":%s,\"contextValid\":%s,\"mode\":%u,\"flags\":%u,\"verticalVelocity\":%d,\"completedGroundAdmission\":%s",j,(unsigned long long)(valid?rigTick:observedTick),valid?"true":"false",allowed?"true":"false",reason,epoch,c.callbacks[0],c.callbacks[1],c.callbacks[2],c.foreground?"true":"false",context?"true":"false",c.mode,c.flags,c.verticalVelocity,c.completedGround?"true":"false");
  int16_t actorPosition[3]={0};bool positionKnown=valid&&srActorPositionRead(p,readAt,base,r.actor,r.object,actorPosition);
  printf(",\"actorPositionValid\":%s",positionKnown?"true":"false");
  if(positionKnown)printf(",\"actorPosition\":[%d,%d,%d]",actorPosition[0],actorPosition[1],actorPosition[2]);
#ifdef SR1_HANDOFF_CONTINUITY
  printf(",\"observedTick\":%llu,\"held\":%s,\"rigAgeMs\":%llu",(unsigned long long)observedTick,held?"true":"false",(unsigned long long)(valid?observedTick-rigTick:0));
#if defined(SR1_RIG_RETRY) && !defined(SR1_NATIVE_DRAW_RECEIPT)
  printf(",\"acquisitionAttempts\":%u,\"acquisitionRetries\":%u,\"acquisitionUs\":%llu",acquisition.attempts,acquisition.retries,(unsigned long long)acquisition.elapsedUs);
#endif
#endif
#ifdef SR1_NATIVE_JUMP_POSE
  printf(",\"crouchHeld\":%s",c.crouchHeld?"true":"false");
  bool jumpAllowed=context&&sr1RetargetJumpContextAllowed(&c);
#ifdef SR1_NATIVE_EXIT_GUARD
  jumpAllowed=jumpAllowed&&exitAdmitted;
#endif
#ifdef SR1_C0_PHYSICAL_WEAPON
  jumpAllowed=jumpAllowed&&!c0Suspended;
#endif
  printf(",\"jumpAllowed\":%s",jumpAllowed?"true":"false");
#endif
#ifdef SR1_NATIVE_EXIT_GUARD
  printf(",\"nativeExitKnown\":%s,\"nativeExitPending\":%s,\"nativeExitBlending\":%s,\"nativeExitAnimations\":[%u,%u,%u,%u,%u,%u]",exitKnown?"true":"false",exitLatch.nativeOwned?"true":"false",exitKnown&&sr1NativeExitBlending(&exitPose)?"true":"false",exitPose.animation[0],exitPose.animation[1],exitPose.animation[2],exitPose.animation[3],exitPose.animation[4],exitPose.animation[5]);
#endif
#ifdef SR1_NATIVE_DRAW_RECEIPT
  unsigned drawRejectReason=valid?0:!copied?1:!receipt.valid?2:!context?3:!hostDrawResourceSame(&receipt.rig,&current)?4:!hostDrawCurrentContextCompatible(&receipt.context,&c)?5:6;
  printf(",\"nativeDrawReceipt\":true,\"drawSerial\":%llu,\"drawRejectReason\":%u",(unsigned long long)(valid?receipt.serial:0),drawRejectReason);
#ifdef SR1_V38_HANDOFF_R2
  HostContactSnapshot suspension={0};bool suspended=context&&copied&&hostDrawResourceSame(&receipt.rig,&current)&&
#ifdef SR1_V38_REPAIR_R2
   v38NativeSuspendPendingRead(contactView,&current,&c,(DWORD)pid,processCreation,observedTick,&suspension);
#ifdef SR1_C0_PHYSICAL_WEAPON
  if(c0Suspended){suspension=c0Suspension;suspended=true;}
  else if(suspended&&hostContactC0Weapon(&suspension))suspended=false; // use the same C0 receipt for all gates
#endif
  HostContactSnapshot completed={0};bool contactFresh=context&&copied&&hostDrawResourceSame(&receipt.rig,&current)&&
#ifdef SR1_C0_PHYSICAL_WEAPON
   !c0Suspended&&
#endif
   v38CompletedContactRead(contactView,&current,&c,(DWORD)pid,processCreation,observedTick,&completed);
#ifdef SR1_V38_REPAIR_R3
  printf(",\"waitIdentity\":{\"valid\":%s,\"actor\":\"0x%llx\",\"object\":\"0x%llx\",\"model\":\"0x%llx\"}",context&&c.identity&&copied&&hostDrawResourceSame(&receipt.rig,&current)?"true":"false",current.actor,current.object,current.model);
#endif
  printf(",\"completedContact\":{\"valid\":%s,\"phase\":%u,\"tick\":%llu,\"sequence\":%llu,\"pid\":%lu,\"creation\":\"%llu\",\"epoch\":\"%llu\",\"actor\":\"0x%llx\"}",contactFresh?"true":"false",completed.phase,completed.tick,completed.sequence,(unsigned long)completed.pid,completed.creation,completed.epoch,completed.actor);
#else
   v38NativeSuspendRead(contactView,&current,&c,(DWORD)pid,processCreation,observedTick,&suspension);
#endif
  printf(",\"nativeSuspension\":{\"valid\":%s",suspended?"true":"false");
#ifdef SR1_C0_PHYSICAL_WEAPON
  if(c0Suspended)fputs(",\"c0Weapon\":true",stdout);
#endif
#ifdef SR1_NATIVE_OBJECT_GAP_R18
  if(suspended)printf(",\"pending\":%s",nativeObjectGapSnapshotR18(&suspension)&&observedTick-suspension.tick>250?"true":"false");
#endif
  if(suspended)printf(",\"pid\":%lu,\"creation\":\"%llu\",\"epoch\":\"%llu\",\"tick\":%llu,\"sequence\":%llu,\"phase\":%u,\"control\":%u,\"actor\":\"0x%llx\",\"object\":\"0x%llx\",\"model\":\"0x%llx\"",pid,(unsigned long long)suspension.creation,(unsigned long long)suspension.epoch,(unsigned long long)suspension.tick,(unsigned long long)suspension.sequence,suspension.phase,suspension.control,(unsigned long long)current.actor,(unsigned long long)current.object,(unsigned long long)current.model);
  putchar('}');
#endif
#endif
  if(valid){printf(",\"actor\":\"0x%llx\",\"object\":\"0x%llx\",\"model\":\"0x%llx\",\"parents\":[",(unsigned long long)r.actor,(unsigned long long)r.object,(unsigned long long)r.model);for(int i=0;i<r.count;i++)printf("%s%d",i?",":"",r.parents[i]);printf("],\"render\":[");for(int i=0;i<r.count;i++){printf("%s[",i?",":"");for(int k=0;k<13;k++){float v;memcpy(&v,r.renderBytes[i]+k*4,4);printf("%s%.9g",k?",":"",v);}putchar(']');}putchar(']');}puts("}");fflush(stdout);
#ifdef SR1_SKELETON_CADENCE60
  if(fast){LARGE_INTEGER now,wait;int64_t relative=0;
   if(!QueryPerformanceCounter(&now)){cadenceFailed=true;break;}
   uint64_t due=captureNextHz((uint64_t)cadenceOrigin.QuadPart,(uint64_t)now.QuadPart,(uint64_t)cadenceFrequency.QuadPart,captureHz);
   if(!due||due<=(uint64_t)now.QuadPart||!captureWait100ns(due-(uint64_t)now.QuadPart,(uint64_t)cadenceFrequency.QuadPart,&relative)){cadenceFailed=true;break;}
   wait.QuadPart=relative;if(cadenceTimer&&SetWaitableTimer(cadenceTimer,&wait,0,NULL,NULL,FALSE))WaitForSingleObject(cadenceTimer,50);
   else {uint64_t units=(uint64_t)(-relative);Sleep((DWORD)(units/10000+(units%10000!=0)));}
  }
  else
#endif
  Sleep((DWORD)policy->intervalMs);
 }
#ifdef SR1_NATIVE_DRAW_RECEIPT
 if(drawView)UnmapViewOfFile(drawView);if(drawMapping)CloseHandle(drawMapping);
#endif
 if(cadenceTimer)CloseHandle(cadenceTimer);
#ifdef SR1_SKELETON_CADENCE60
 result=cadenceFailed?8:0;
#else
 result=0;
#endif
done:
#ifdef SR1_V38_HANDOFF_R2
 if(contactView)UnmapViewOfFile(contactView);if(contactMapping)CloseHandle(contactMapping);
#endif
 CloseHandle(p);return result;
}
