#include "general-test-budget.h"
// SPDX-License-Identifier: GPL-3.0-or-later
#pragma once
#include "sr1-repeat-jump-buffer.h"
#include "sr1-retarget-context-reader.h"
#include "repeat-jump-draw-scope.h"
static RepeatJumpBuffer srRepeatPads[SR_INPUT_CHANNELS];static uintptr_t srRepeatObjects[SR_INPUT_CHANNELS];
static RepeatJumpPacket srRepeatPackets[SR_INPUT_CHANNELS];
static volatile LONG srRepeatLock;static uint64_t srRepeatBegin,srRepeatHeartbeat;
static DWORD srRepeatWriter;static bool srRepeatRequested;
static unsigned srRepeatCalls,srRepeatScopeAccepted,srRepeatArmed,srRepeatChanged;
static bool srRepeatRead(void *unused,uintptr_t at,void *out,size_t size){(void)unused;return worldRead(at,out,size);}
static bool srRepeatNativeIdentity(uintptr_t base,uint64_t now,uintptr_t *actor,uintptr_t *object){
#ifdef SR1_NATIVE_SKELETON_ADAPTER
 HostRig current;HostDrawReceipt receipt;
 const HostDrawShared *view=InterlockedCompareExchangePointer(&hostDrawView,NULL,NULL);
 if(!hostRigRead(NULL,srRepeatRead,base,&current)||!hostDrawCopy(view,&receipt)||!repeatJumpDrawScope(&receipt,GetCurrentProcessId(),hostDrawCreation,now,&current))return false;
 *actor=current.actor;*object=current.object;return true;
#else
 (void)base;(void)now;(void)actor;(void)object;return false;
#endif
}
static WORD srRepeatApplyBoundary(DWORD index,ULONGLONG now,bool boundary,DWORD foreground,const XINPUT_STATE *raw,XINPUT_STATE *output){
 WORD delivered=raw->Gamepad.wButtons;if(index>=SR_INPUT_CHANNELS||InterlockedCompareExchange(&srRepeatLock,1,0))return delivered;
 const Sheet_repeatJumpBufferPolicy *p=&sheet_repeatJumpBufferPolicy_bounded;
 ++srRepeatCalls;
 uintptr_t base=(uintptr_t)InterlockedCompareExchangePointer(&verifiedSr1Module,NULL,NULL),actor=0,object=0;int32_t time=0;Sr1RetargetContext c;XINPUT_STATE unique={0};
 bool scope=p->intentMs==350&&p->releaseMs==32&&p->pulseMs==64&&p->maxGapMs==100&&p->seconds==120&&p->landingRva==0xee600&&!p->enabled&&!p->hostPhysicsWrites&&
  srRepeatRequested&&srRepeatWriter&&now>=srRepeatBegin&&forceDuration(now-srRepeatBegin,GENERAL_OR_SHORT_MS(120000))&&now>=srRepeatHeartbeat&&now-srRepeatHeartbeat<1500&&base&&
  foreground==GetCurrentProcessId()&&boundary&&
  srRepeatNativeIdentity(base,now,&actor,&object)&&worldRead(base+0x2a89628,&time,4)&&time>0&&time<=8192&&
  srPhysicalInput(&unique)&&unique.dwPacketNumber==raw->dwPacketNumber&&unique.Gamepad.wButtons==raw->Gamepad.wButtons&&
  !(raw->Gamepad.wButtons&~XINPUT_GAMEPAD_A)&&raw->Gamepad.bLeftTrigger<30&&raw->Gamepad.bRightTrigger<30&&
  sr1RetargetReadContext(NULL,srRepeatRead,base,actor,true,&c)&&!c.mode&&!c.crouchHeld&&!(c.flags&0x10000000u)&&c.verticalVelocityKnown&&c.verticalVelocity==0;
#ifdef SR1_C0_PHYSICAL_WEAPON
 scope=scope&&!sr1C0NativeActive(actor);
#endif
 RepeatJumpPhase phase=REPEAT_JUMP_OTHER;
 if(scope){bool landing=true;for(unsigned i=0;i<3;i++)if(c.callbacks[i]!=0xee600)landing=false;
  if(landing)phase=REPEAT_JUMP_LANDING;else if(sr1RetargetContextAllowed(&c))phase=REPEAT_JUMP_GROUND;
 }
 if(srRepeatObjects[index]!=object){memset(&srRepeatPads[index],0,sizeof(srRepeatPads[index]));srRepeatObjects[index]=object;}
 if(scope)++srRepeatScopeAccepted;bool wasPending=srRepeatPads[index].pending;
 delivered=repeatJumpStep(&srRepeatPads[index],now,actor,scope,phase,delivered,(uint32_t)p->intentMs,(uint32_t)p->releaseMs,(uint32_t)p->pulseMs);
 if(!wasPending&&srRepeatPads[index].pending)++srRepeatArmed;
 if(delivered!=raw->Gamepad.wButtons)++srRepeatChanged;
 output->dwPacketNumber=repeatJumpPacket(&srRepeatPackets[index],raw->dwPacketNumber,raw->Gamepad.wButtons,delivered);
 InterlockedExchange(&srRepeatLock,0);return delivered;
}
static WORD srRepeatApply(DWORD index,ULONGLONG now,uintptr_t caller,DWORD foreground,const XINPUT_STATE *raw,XINPUT_STATE *output){
 return index<4?srRepeatApplyBoundary(index,now,srInputPollSite(caller,srInputMainBase),foreground,raw,output):raw->Gamepad.wButtons;
}
#include "sr1-repeat-jump-advance.h"
static void srRepeatTick(void){
 bool requested=GetFileAttributesW(PROBE_PATH(L"\\repeat-jump-sr1.enable"))!=INVALID_FILE_ATTRIBUTES;
 RecordingStatus s={0};uint64_t now=GetTickCount64();bool lease=requested&&recordingReadStatus(GetCurrentProcessId(),&s)&&recordingStatusValid(&s,GetCurrentProcessId(),now)&&(s.total==500||s.total==1200)&&s.completed>=200&&s.completed<s.total;
 if(InterlockedCompareExchange(&srRepeatLock,1,0))return;
 if(!lease||!srRepeatRequested||srRepeatWriter!=s.writerPid){memset(srRepeatPads,0,sizeof(srRepeatPads));memset(srRepeatObjects,0,sizeof(srRepeatObjects));srRepeatBegin=now;}
 srRepeatRequested=lease;srRepeatWriter=lease?s.writerPid:0;srRepeatHeartbeat=lease?s.tick:0;
 unsigned calls=srRepeatCalls,accepted=srRepeatScopeAccepted,armed=srRepeatArmed,changed=srRepeatChanged;
 InterlockedExchange(&srRepeatLock,0);
 if(requested)logLine("SR1_REPEAT_JUMP lease=%u calls=%u scope=%u armed=%u changed=%u",lease,calls,accepted,armed,changed);
 srFastTick();
}
static void srRepeatStop(void){srFastStop();if(InterlockedCompareExchange(&srRepeatLock,1,0))return;srRepeatRequested=false;srRepeatWriter=0;memset(srRepeatPads,0,sizeof(srRepeatPads));InterlockedExchange(&srRepeatLock,0);}
