// SPDX-License-Identifier: GPL-3.0-or-later
#pragma once
#include "strike-pose-wire.h"
#include "c2-pose-policy.h"
#include "c2-host-policy.h"
#include "sphere-center.h"

typedef struct {
    ReaverPacketSession session;
    HANDLE mapping;
    const C2StrikeMapping *view;
    uint64_t retryAt, previousMarker;
    unsigned frames;
} C2GeometryReader;
static _Thread_local C2GeometryReader c2Geometry;

static void c2GeometryClose(void) {
    if (c2Geometry.view) UnmapViewOfFile(c2Geometry.view);
    if (c2Geometry.mapping) CloseHandle(c2Geometry.mapping);
    c2Geometry=(C2GeometryReader){0};
}

static bool c2GeometryAttach(const ReaverPacketSession *session, uint64_t now) {
    if (memcmp(&c2Geometry.session,session,sizeof(*session))) {
        c2GeometryClose();
        c2Geometry.session=*session;
    }
    if (c2Geometry.view) return true;
    if (now<c2Geometry.retryAt) return false;
    c2Geometry.retryAt=now+250;
    wchar_t name[96];
    donorCompletedPoseNameR13(name,session->donorPid);
    c2Geometry.mapping=OpenFileMappingW(FILE_MAP_READ,FALSE,name);
    if (!c2Geometry.mapping) return false;
    c2Geometry.view=MapViewOfFile(c2Geometry.mapping,FILE_MAP_READ,0,0,sizeof(*c2Geometry.view));
    if (!c2Geometry.view) {
        CloseHandle(c2Geometry.mapping);
        c2Geometry.mapping=NULL;
    }
    return c2Geometry.view!=NULL;
}

static bool c2HostSphere(uintptr_t base, uintptr_t actor, int16_t centers[2][3], uint16_t *radius) {
    const Sheet_c2HostGeometry *p=&sheet_c2HostGeometry_host_observation;
    const Sheet_c1CollisionGeometry *geometry=&sheet_c1CollisionGeometry_host_sword_sphere;
    uintptr_t blade=0,parent=0,callback=0,models=0,entries=0,palette[2]={0};
    int16_t model=0;
    uint32_t count=0;
    if (!worldRead(base+p->reaverRva,&blade,8) || !blade ||
        !worldRead(blade+p->parentOffset,&parent,8) || parent!=actor ||
        !worldRead(blade+p->collisionCallbackOffset,&callback,8) || callback!=base+p->reaverCollisionRva ||
        !worldRead(blade+p->collisionModelsOffset,&models,8) || !models ||
        !worldRead(blade+p->modelIndexOffset,&model,2) || model<0 || model>31) return false;
    const uintptr_t descriptor=models+(size_t)model*16;
    if (!worldRead(descriptor,&entries,8) || !entries ||
        !worldRead(descriptor+8,&count,4) || !count || count>128 ||
        !worldRead(blade+p->currentPaletteOffset,&palette[0],8) || !palette[0] ||
        !worldRead(blade+p->previousPaletteOffset,&palette[1],8) || !palette[1]) return false;
    unsigned char table[128][16];
    if (!worldRead(entries,table,count*sizeof(*table))) return false;
    for (uint32_t i=0;i<count;++i) {
        const unsigned char *entry=table[i];
        if (!(entry[1]&4) || entry[2]!=1 || entry[3]!=0) continue;
        uintptr_t primitive=0;
        unsigned char sphere[16], matrices[2][32];
        memcpy(&primitive,entry+8,8);
        if (!primitive || !worldRead(primitive,sphere,sizeof(sphere)) ||
            sphere[4]!=geometry->bladePrimitiveId) continue;
        if (!worldRead(palette[0],matrices[0],sizeof(matrices[0])) ||
            !worldRead(palette[1],matrices[1],sizeof(matrices[1]))) return false;
        uintptr_t after=0, afterPalette[2]={0};
        return worldRead(base+p->reaverRva,&after,8) && after==blade &&
            worldRead(blade+p->currentPaletteOffset,&afterPalette[0],8) &&
            worldRead(blade+p->previousPaletteOffset,&afterPalette[1],8) &&
            !memcmp(palette,afterPalette,sizeof(palette)) &&
            sr1CollisionSphereCenter(matrices[0],sphere,centers[0],radius) &&
            sr1CollisionSphereCenter(matrices[1],sphere,centers[1],radius);
    }
    return false;
}

// Read the actual submitted vertices and transform after the GL draw succeeded.
// The far vertex measures visual reach from the palm. It isn't a contact test.
static bool c2VisualReach(const ReaverPresentationLease *lease, const float palm[16], float tip[3]) {
    const unsigned char *vertices=lease->bytes+128;
    const unsigned char *indices=vertices+lease->view.vertices*36;
    float farthest=0,local[3]={0};
    for (uint32_t i=0;i<lease->view.indices;++i) {
        uint16_t index;
        memcpy(&index,indices+2*i,2);
        if (index>=lease->view.vertices) return false;
        float p[3];
        memcpy(p,vertices+36*index,sizeof(p));
        const float squared=p[0]*p[0]+p[1]*p[1]+p[2]*p[2];
        if (!isfinite(squared)) return false;
        if (squared>farthest) {farthest=squared;memcpy(local,p,sizeof(p));}
    }
    if (!(farthest>0)) return false;
    for (unsigned i=0;i<3;++i)
        tip[i]=palm[12+i]+palm[i]*local[0]+palm[4+i]*local[1]+palm[8+i]*local[2];
    return isfinite(tip[0])&&isfinite(tip[1])&&isfinite(tip[2]);
}

static void c2ObserveGeometry(const ReaverPacketSession *session,const ReaverPresentationLease *lease,
    const float palm[16],uintptr_t base,uintptr_t actor,uint64_t frame) {
    const Sheet_c2HostGeometry *p=&sheet_c2HostGeometry_host_observation;
    const uint64_t now=GetTickCount64();
    if (!c2GeometryAttach(session,now)) return;
    DonorCompletedPoseSnapshotR13 pose;
    C2StrikeReceipt strike;
    if (!c2StrikeCopy(c2Geometry.view,&pose,&strike,session->donorPid,session->donorCreation,now) ||
        pose.actorAddress!=session->actor || strike.bladeAddress!=session->weapon) return;
    uint32_t hostRealm=0;
    if (!worldRead(base+p->realmRva,&hostRealm,sizeof(hostRealm)) || hostRealm!=strike.realm) return;
    if (strike.marker!=c2Geometry.previousMarker) {
        c2Geometry.previousMarker=strike.marker;
        c2Geometry.frames=0;
    }
    if (c2Geometry.frames>=1) return;
    float tip[3];
    if (!c2VisualReach(lease,palm,tip)) return;
    int16_t centers[2][3]={{0}};
    uint16_t radius=0;
    const bool native=c2HostSphere(base,actor,centers,&radius);
    int16_t hostRoot[3];
    if (!worldRead(actor+p->rootOffset,hostRoot,sizeof(hostRoot))) return;
    ++c2Geometry.frames;
    logLine("C2_STRIKE_GEOMETRY marker=%llu serial=%u pose=%llu capture=%llu packet=%llu packetTick=%llu hostTick=%llu draw=%llu root=%d,%d,%d palm=%.3f,%.3f,%.3f tip=%.3f,%.3f,%.3f native=%u radius=%u current=%d,%d,%d previous=%d,%d,%d",
        strike.marker,strike.nativeSerial,strike.poseSerial,pose.tickMs,lease->view.sequence,lease->view.tick,now,frame,
        hostRoot[0],hostRoot[1],hostRoot[2],palm[12],palm[13],palm[14],tip[0],tip[1],tip[2],(unsigned)native,
        radius,centers[0][0],centers[0][1],centers[0][2],centers[1][0],centers[1][1],centers[1][2]);
}
