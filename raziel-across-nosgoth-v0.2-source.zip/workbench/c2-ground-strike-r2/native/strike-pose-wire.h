// SPDX-License-Identifier: GPL-3.0-or-later
#pragma once
#include "donor-completed-pose-wire.h"

enum { C2_STRIKE_RECEIPT_VERSION = 1 };

typedef struct {
    uint64_t marker, tick, epoch, generation, poseSerial, actorToken, bladeAddress;
    uint32_t nativeSerial, realm, version, active;
} C2StrikeReceipt;

typedef struct {
    DonorCompletedPoseSharedR13 pose;
    volatile LONG64 marker;
    C2StrikeReceipt strike;
} C2StrikeMapping;

_Static_assert(offsetof(C2StrikeMapping, marker) == 10880, "Keep the R33 mapping prefix");
_Static_assert(sizeof(C2StrikeReceipt) == 72, "C2 receipt ABI");

static inline void c2StrikePublish(C2StrikeMapping *view, const DonorCompletedPoseSnapshotR13 *pose,
    const C2StrikeReceipt *strike) {
    InterlockedIncrement(&view->pose.sequence);
    MemoryBarrier();
    view->pose.snapshot = *pose;
    view->strike = *strike;
    MemoryBarrier();
    InterlockedIncrement(&view->pose.sequence);
}

// A new marker independently revokes a receipt, even during a pose reuse pass.
static inline bool c2StrikeCopy(const C2StrikeMapping *view, DonorCompletedPoseSnapshotR13 *pose,
    C2StrikeReceipt *strike, DWORD pid, uint64_t birth, uint64_t now) {
    if (!view || !pose || !strike) return false;
    for (unsigned i = 0; i < 3; ++i) {
        const LONG sequence = view->pose.sequence;
        const LONG64 marker = view->marker;
        if ((sequence & 1) || view->pose.revoked) continue;
        MemoryBarrier();
        *pose = view->pose.snapshot;
        *strike = view->strike;
        MemoryBarrier();
        if (sequence != view->pose.sequence || marker != view->marker || view->pose.revoked) continue;
        return strike->version == C2_STRIKE_RECEIPT_VERSION && strike->active == 1 &&
            strike->marker && strike->marker == (uint64_t)marker && strike->bladeAddress &&
            strike->tick >= pose->sessionEpoch && strike->tick <= pose->tickMs &&
            strike->epoch == pose->sessionEpoch && strike->generation == pose->generation &&
            strike->poseSerial == pose->serial && strike->actorToken == pose->actorToken &&
            strike->realm == pose->realm && donorCompletedPoseValidR13(pose, pid, birth, now);
    }
    return false;
}
