// SPDX-License-Identifier: GPL-3.0-or-later
#pragma once
#include "strike-pose-wire.h"
#include "c2-pose-policy.h"

typedef void (*C2NativePost)(void *, uint32_t, uintptr_t);
typedef struct {
    uintptr_t actor, context, blade;
    uint64_t marker, tick, epoch;
    uint32_t thread, nativeSerial;
} C2NativeOpen;

static C2StrikeMapping *c2Mapping;
static C2NativePost c2OriginalPost;
static SRWLOCK c2MarkerLock = SRWLOCK_INIT;
static C2NativeOpen c2LatestOpen, c2AtBuilder;

static uint64_t c2Marker(void) {
    return (uint64_t)InterlockedCompareExchange64(&c2Mapping->marker, 0, 0);
}

static void c2Invalidate(const DonorCompletedPoseSnapshotR13 *pose) {
    if (!c2Mapping) return;
    InterlockedIncrement64(&c2Mapping->marker);
    c2StrikePublish(c2Mapping, pose, &(C2StrikeReceipt){0});
}

static bool c2Blade(uintptr_t context, uintptr_t *blade, uint32_t *serial) {
    const Sheet_c2PoseLink *p = &sheet_c2PoseLink_native_pose;
    return context && worldRead(context + (uintptr_t)p->bladeOffset, blade, sizeof(*blade)) &&
        *blade && worldRead(context + (uintptr_t)p->serialOffset, serial, sizeof(*serial));
}

static void c2ObservePost(void *recipient, uint32_t id, uintptr_t payload) {
    const DWORD before = GetLastError();
    const uintptr_t address = (uintptr_t)__builtin_return_address(0);
    const uintptr_t site = address >= dcpBaseR13 ? address - dcpBaseR13 : UINTPTR_MAX;
    const Sheet_c2PoseLink *p = &sheet_c2PoseLink_native_pose;
    const bool opening = id == p->openId && site == (uintptr_t)p->openSite;
    const bool closing = id == p->closeId &&
        (site == (uintptr_t)p->closeSite || site == (uintptr_t)p->exitSite ||
            site == (uintptr_t)p->resetSite);
    C2NativeOpen candidate = {0};
    if ((opening || closing) && dcpLeaseLiveR13(GetTickCount64())) {
        // Revoke the old receipt before forwarding a new event. A nested
        // marker also supersedes this one before it returns.
        candidate.marker = (uint64_t)InterlockedIncrement64(&c2Mapping->marker);
        const Sheet_donorCompletedPosePolicy *pose = &sheet_donorCompletedPosePolicy_native_pass;
        if (opening &&
            worldRead(dcpBaseR13 + (uintptr_t)pose->actorRva, &candidate.actor, sizeof(candidate.actor)) &&
            worldRead(dcpBaseR13 + (uintptr_t)pose->contextRva, &candidate.context, sizeof(candidate.context)) &&
            c2Blade(candidate.context, &candidate.blade, &candidate.nativeSerial) &&
            candidate.blade == (uintptr_t)recipient) {
            // The original animation caller increments the serial after this post.
            ++candidate.nativeSerial;
            candidate.tick = GetTickCount64();
            candidate.epoch = (uint64_t)InterlockedCompareExchange64(&dcpEpochR13, 0, 0);
            candidate.thread = GetCurrentThreadId();
        }
    }
    SetLastError(before);
    c2OriginalPost(recipient, id, payload);
    const DWORD after = GetLastError();
    if (candidate.thread && TryAcquireSRWLockExclusive(&c2MarkerLock)) {
        if (c2Marker() == candidate.marker) c2LatestOpen = candidate;
        ReleaseSRWLockExclusive(&c2MarkerLock);
    }
    SetLastError(after);
}

static bool c2Matches(const C2NativeOpen *open, const DonorCompletedIdentityR13 *identity,
    const DonorCompletedPoseSnapshotR13 *pose) {
    if (!c2Mapping || !open->marker || open->marker != c2Marker() ||
        open->epoch != pose->sessionEpoch || open->thread != GetCurrentThreadId() ||
        open->actor != identity->actor || open->context != identity->context ||
        !pose->reaver.present || !pose->reaver.attachedToActor || !pose->reaver.nameMatches) return false;
    const Sheet_c2PoseLink *p = &sheet_c2PoseLink_native_pose;
    for (unsigned i = 0; i < 3; ++i) {
        if (pose->primary[i] != p->groundPrimary || pose->secondary[i] != p->groundSecondary) return false;
    }
    uintptr_t blade = 0;
    uint32_t serial = 0;
    return c2Blade(identity->context, &blade, &serial) && blade == open->blade &&
        serial == open->nativeSerial && open->marker == c2Marker();
}

static void c2CaptureAtBuilder(const DonorCompletedIdentityR13 *identity,
    const DonorCompletedPoseSnapshotR13 *pose) {
    c2AtBuilder = (C2NativeOpen){0};
    if (!c2Mapping || !TryAcquireSRWLockShared(&c2MarkerLock)) return;
    const C2NativeOpen current = c2LatestOpen;
    ReleaseSRWLockShared(&c2MarkerLock);
    if (c2Matches(&current, identity, pose)) c2AtBuilder = current;
}

static void c2PublishAtEnd(const DonorCompletedIdentityR13 *identity,
    const DonorCompletedPoseSnapshotR13 *pose) {
    C2StrikeReceipt strike = {0};
    if (c2Matches(&c2AtBuilder, identity, pose)) {
        const C2NativeOpen *open = &c2AtBuilder;
        strike = (C2StrikeReceipt){.marker=open->marker,.tick=open->tick,.epoch=pose->sessionEpoch,
            .generation=pose->generation,.poseSerial=pose->serial,.actorToken=pose->actorToken,.bladeAddress=open->blade,
            .nativeSerial=open->nativeSerial,.realm=pose->realm,.version=C2_STRIKE_RECEIPT_VERSION,.active=1};
    }
    c2StrikePublish(c2Mapping, pose, &strike);
}

static void c2InstallPost(void) {
    const Sheet_c2PoseLink *p = &sheet_c2PoseLink_native_pose;
    if (p->damageEnabled) return;
    const unsigned char expected[] = C2_POST_BODY;
    unsigned char actual[sizeof(expected)];
    const uintptr_t at = dcpBaseR13 + (uintptr_t)p->postRva;
    if (!dcpCodeR13(NULL, at, dcpBaseR13) || !worldRead(at, actual, sizeof(actual)) ||
        memcmp(expected, actual, sizeof(actual))) {
        logLine("C2_STRIKE readonly post proof refused");
        return;
    }
    void *target = (void *)at;
    if (MH_CreateHook(target, (void *)&c2ObservePost, (void **)&c2OriginalPost) != MH_OK) {
        logLine("C2_STRIKE readonly post create refused");
        return;
    }
    if (MH_EnableHook(target) != MH_OK) {
        MH_RemoveHook(target);
        logLine("C2_STRIKE readonly post enable refused");
        return;
    }
    logLine("C2_STRIKE readonly post installed");
}
