// SPDX-License-Identifier: GPL-3.0-or-later
#pragma once
#include <stdbool.h>
#include <stdint.h>
#include <string.h>
#include "zephon-abdomen-policy.h"

static inline bool zephonAbdomenIdentity(const char name[9], int32_t stream, uint32_t intro,
    uint32_t type, uintptr_t base, uintptr_t collision, uintptr_t message) {
    return base && stream == ZEPHON_BODY_STREAM && intro == ZEPHON_BODY_INTRO && type == ZEPHON_BODY_TYPE &&
        collision == base + ZEPHON_BODY_COLLISION && message == base + ZEPHON_BODY_MESSAGE &&
        !memcmp(name,ZEPHON_BODY_NAME,9);
}

static inline bool zephonAbdomenWindow(uint32_t realm, uint32_t airStrike, uint32_t state,
    uint32_t flags, int16_t counter, uint32_t exhaustedLimbs) {
    return realm == ZEPHON_BODY_REALM && !airStrike && state == ZEPHON_BODY_LIVE_STATE &&
        !(flags & ZEPHON_BODY_BUSY_FLAGS) && counter > 0 && exhaustedLimbs == ZEPHON_BODY_LIMB_MASK;
}

static inline bool zephonAbdomenSegment(unsigned segment) {
    return segment==ZEPHON_BODY_SEGMENT_A || segment==ZEPHON_BODY_SEGMENT_B;
}
