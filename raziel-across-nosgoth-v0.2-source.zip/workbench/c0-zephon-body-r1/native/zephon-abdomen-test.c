// SPDX-License-Identifier: GPL-3.0-or-later
#include <assert.h>
#include <stdio.h>
#include "zephon-abdomen.h"

int main(void) {
    const uintptr_t base=0x10000000;
    const uintptr_t collision=base+ZEPHON_BODY_COLLISION,message=base+ZEPHON_BODY_MESSAGE;
    assert(zephonAbdomenIdentity("walboss_",-4744,1299,0x10102,base,collision,message));
    assert(!zephonAbdomenIdentity("walbosb_",-4744,1299,0x10102,base,collision,message));
    assert(!zephonAbdomenIdentity("walboss_",-4743,1299,0x10102,base,collision,message));
    assert(!zephonAbdomenIdentity("walboss_",-4744,1300,0x10102,base,collision,message));
    assert(!zephonAbdomenIdentity("walboss_",-4744,1299,0x410002,base,collision,message));
    assert(!zephonAbdomenIdentity("walboss_",-4744,1299,0x10102,base,base+0xb2830,message));
    assert(zephonAbdomenWindow(1,0,6,0xa0000000u,3,15));
    assert(!zephonAbdomenWindow(2,0,6,0,3,15));
    assert(!zephonAbdomenWindow(1,1,6,0,3,15));
    assert(!zephonAbdomenWindow(1,0,13,0,3,15));
    assert(!zephonAbdomenWindow(1,0,6,2,3,15));
    assert(!zephonAbdomenWindow(1,0,6,0,0,15));
    assert(!zephonAbdomenWindow(1,0,6,0,3,14));
    assert(zephonAbdomenSegment(1) && zephonAbdomenSegment(11) && !zephonAbdomenSegment(34));
    puts("Zephon abdomen native contact: PASS");
}
