// SPDX-License-Identifier: GPL-3.0-or-later
#pragma once
#include "hud-render.h"
static HudDisplay hudDisplay;
static uint64_t hudPollTick,hudDrawCount;
static bool hudDescriptor(HudSession *s){
 wchar_t file[512];_snwprintf(file,512,PROBE_PATH(L"\\hud-%lu.bin"),GetCurrentProcessId());HANDLE f=CreateFileW(file,GENERIC_READ,FILE_SHARE_READ|FILE_SHARE_WRITE|FILE_SHARE_DELETE,NULL,OPEN_EXISTING,FILE_ATTRIBUTE_NORMAL,NULL);if(f==INVALID_HANDLE_VALUE)return false;DWORD got=0;LARGE_INTEGER size;bool ok=GetFileSizeEx(f,&size)&&size.QuadPart==sizeof(*s)&&ReadFile(f,s,sizeof(*s),&got,NULL)&&got==sizeof(*s);CloseHandle(f);return ok&&hudU32(s->bytes+8)==GetCurrentProcessId()&&hudSessionValid(s,GetTickCount64())&&hudProcesses(s);
}
static void hudRuntimeDraw(HDC dc){
 if(!InterlockedCompareExchangePointer(&verifiedSr1Module,NULL,NULL)||wglGetCurrentDC()!=dc)return;HGLRC context=wglGetCurrentContext();if(!context)return;uint64_t now=GetTickCount64();HudSession session={0};
 if(!hudDescriptor(&session)){if(hudDisplay.gl.context==context){reaverGLDestroy(&hudDisplay.gl);memset(&hudDisplay,0,sizeof(hudDisplay));}return;}
 GLint fbo=0,viewport[4]={0};glGetIntegerv(GL_DRAW_FRAMEBUFFER_BINDING,&fbo);glGetIntegerv(GL_VIEWPORT,viewport);if(fbo||viewport[2]<320||viewport[3]<240)return;
 if(hudDisplay.gl.context&&hudDisplay.gl.context!=context)return;
 wchar_t name[160],mutexName[160];hudNames(&session,name,mutexName);HANDLE map=OpenFileMappingW(FILE_MAP_READ,FALSE,name),lock=NULL;const HudMemory *view=NULL;unsigned char frame[HUD_MAX_FRAME_BYTES],*bank=NULL;size_t frameSize=0,bankSize=0;
 if(map){lock=OpenMutexW(SYNCHRONIZE|MUTEX_MODIFY_STATE,FALSE,mutexName);if(lock)view=MapViewOfFile(map,FILE_MAP_READ,0,0,sizeof(*view));}
 bool same=hudDisplay.loaded&&!memcmp(hudDisplay.session.bytes,session.bytes,64),online=false;
 if(view){DWORD wait=WaitForSingleObject(lock,0);if(wait==WAIT_OBJECT_0){
   online=view->magic==0x314d4448&&view->online==1&&view->frameSize>=96&&view->frameSize<=HUD_MAX_FRAME_BYTES&&view->bankSize>=80&&view->bankSize<=HUD_MAX_TEXTURE_BYTES;
   if(online){frameSize=view->frameSize;memcpy(frame,view->frame,frameSize);if(!same){bankSize=view->bankSize;bank=malloc(bankSize);if(bank)memcpy(bank,view->bank,bankSize);}}
   ReleaseMutex(lock);
  }else if(wait==WAIT_ABANDONED)ReleaseMutex(lock);
 }
 if(view)UnmapViewOfFile(view);if(lock)CloseHandle(lock);if(map)CloseHandle(map);
 if(!online){free(bank);return;}if(!same){if(!bank||!hudLoadBank(&hudDisplay,&session,bank,bankSize)){free(bank);return;}logLine("REAVER_HUD bank=%u bytes=%llu",hudDisplay.count,(unsigned long long)bankSize);}free(bank);
 if(hudDisplayFrame(&hudDisplay,frame,frameSize,GetTickCount64(),viewport)){hudDrawCount++;if(!hudPollTick||now-hudPollTick>=1000){logLine("REAVER_HUD frames=%llu sequence=%llu quads=%u",(unsigned long long)hudDrawCount,(unsigned long long)hudDisplay.sequence,hudU32(frame+12));hudPollTick=now;}}
}
