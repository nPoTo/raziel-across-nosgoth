// SPDX-License-Identifier: GPL-3.0-or-later
// External current-widget metadata only. No game input, writes or asset payloads.
#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <tlhelp32.h>
#include <bcrypt.h>
#include <stdint.h>
#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <wchar.h>
#include <math.h>
#include "reader-hash.h"
#include "exploration-sheets.h"
static bool readAt(HANDLE p,uintptr_t a,void *out,SIZE_T n){SIZE_T got=0;return a&&ReadProcessMemory(p,(void*)a,out,n,&got)&&got==n;}
static unsigned failureStage;
static void jsonName(const char *p){putchar('"');for(;*p;p++){if(*p=='"'||*p=='\\')putchar('\\');putchar((unsigned char)*p);}putchar('"');}
typedef struct{uintptr_t actor,object,name,model;char label[32];uint32_t magic,bones,vertices;uint16_t modelCount;unsigned char active;bool valid;} HudModelMeta;
static void modelMeta(HANDLE p,uintptr_t actor,HudModelMeta *m){
 memset(m,0,sizeof(*m));m->actor=actor;if(!actor)return;
 if(!readAt(p,actor+0x88,&m->object,8)||!m->object||!readAt(p,m->object+0x50,&m->name,8)||!m->name)return;
 bool ended=false;for(unsigned i=0;i<31;i++){if(!readAt(p,m->name+i,m->label+i,1))return;if(!m->label[i]){ended=true;break;}if((unsigned char)m->label[i]<32||(unsigned char)m->label[i]>126){memset(m->label,0,sizeof(m->label));return;}}
 if(!ended||!readAt(p,m->object+0x20,&m->modelCount,2)||!m->modelCount||m->modelCount>16||!readAt(p,actor+0xa0,&m->active,1)||m->active>=m->modelCount||!readAt(p,actor+0x1c0,&m->model,8)||!m->model||!readAt(p,m->model,&m->magic,4)||!readAt(p,m->model+4,&m->bones,4)||!readAt(p,m->model+0x28,&m->vertices,4))return;
 m->valid=m->magic==0x04c2042f&&m->bones>0&&m->bones<=256&&m->vertices<=65535;
}
typedef struct{uintptr_t player,data,state,owner,meterVtable,barVtable,meterDefs,barDefs,model;uint32_t selected,realm,unlocks,ids[19],barIds[2],originalIds[19],barOriginalIds[2],gameFlags;float charge,blend,meterLayout[3],orbLayout[20],barLayout[6],barClocks[2],fade;unsigned char visible,barClips[2],gameMode;HudModelMeta models[3];} HudSnapshot;
static bool snap(HANDLE p,uintptr_t base,HudSnapshot *s){
 const Sheet_nativeHudRead *r=&sheet_nativeHudRead_bounded;memset(s,0,sizeof(*s));
 failureStage=1;
 if(!readAt(p,base+r->meterRva,&s->meterVtable,8)||s->meterVtable!=base+r->meterVtableRva||!readAt(p,base+r->barRva,&s->barVtable,8)||s->barVtable!=base+r->barVtableRva)return false;
 failureStage=2;
 // c67120 is the separate native Raziel context, not Instance+3f8.
 // The latter carries its actual owner in its first pointer (existing live
 // donor-air-clock proof). Both roots are included in the double snapshot.
 if(!readAt(p,base+r->playerRva,&s->player,8)||!s->player||!readAt(p,s->player+r->dataOffset,&s->data,8)||!s->data||!readAt(p,s->data,&s->owner,8)||s->owner!=s->player||!readAt(p,base+r->stateRva,&s->state,8)||!s->state)return false;
 failureStage=3;
 if(!readAt(p,s->data+r->chargeOffset,&s->charge,4)||!isfinite(s->charge)||s->charge<0||s->charge>100000||!readAt(p,s->state+r->selectedOffset,&s->selected,4)||!readAt(p,s->state+r->realmOffset,&s->realm,4)||!readAt(p,base+r->blendRva,&s->blend,4)||!isfinite(s->blend)||s->blend<0||s->blend>1||!readAt(p,base+r->unlocksRva,&s->unlocks,4))return false;
 failureStage=4;
 if(!readAt(p,base+r->meterRva+r->defsOffset,&s->meterDefs,8)||!s->meterDefs||!readAt(p,base+r->barRva+r->defsOffset,&s->barDefs,8)||!s->barDefs||!readAt(p,base+r->meterRva+r->meterTexturesOffset,s->ids,sizeof(s->ids))||!readAt(p,base+r->barRva+r->barTexturesOffset,s->barIds,sizeof(s->barIds))||!readAt(p,base+r->meterRva+r->modelOffset,&s->model,8)||!readAt(p,base+r->meterRva+0x10,&s->visible,1))return false;
 failureStage=5;
 for(unsigned i=0;i<19;i++)if(s->ids[i]>65535)return false;for(unsigned i=0;i<2;i++)if(s->barIds[i]>65535)return false;
 // 1ac770 registers original VRM IDs into a separate runtime-handle table.
 //15b2b0/751f0 resolve these configuration keys; never pass runtime handles
 // to the on-disk tex.map loader as though they were original texture IDs.
 failureStage=7;
 if(!readAt(p,s->meterDefs+0x2c,s->originalIds,sizeof(s->originalIds))||!readAt(p,s->barDefs+0x1c,s->barOriginalIds,sizeof(s->barOriginalIds)))return false;
 for(unsigned i=0;i<21;i++){uint32_t original=i<19?s->originalIds[i]:s->barOriginalIds[i-19],runtime=i<19?s->ids[i]:s->barIds[i-19];uint16_t mapped=0;
  if(original>65535||(!original&&runtime)||(original&&(!readAt(p,base+r->textureLookupRva+original*2,&mapped,2)||mapped!=runtime)))return false;}
 failureStage=8;uintptr_t barActors[2]={0};if(!readAt(p,base+r->barRva+0x18,barActors,sizeof(barActors)))return false;
 modelMeta(p,s->model,&s->models[0]);modelMeta(p,barActors[0],&s->models[1]);modelMeta(p,barActors[1],&s->models[2]);
 failureStage=9;
 if(!readAt(p,base+r->meterRva+0x64,s->meterLayout,sizeof(s->meterLayout))||!readAt(p,base+r->meterRva+0xd4,s->orbLayout,sizeof(s->orbLayout))||!readAt(p,base+r->barRva+0x3c,s->barLayout,sizeof(s->barLayout))||!readAt(p,base+r->barRva+0x28,s->barClocks,sizeof(s->barClocks))||!readAt(p,s->barDefs+0x2c,s->barClips,sizeof(s->barClips))||!readAt(p,base+r->meterRva+0x4c,&s->fade,4)||!readAt(p,base+0xc5ab60,&s->gameMode,1)||!readAt(p,base+0xc5ab38,&s->gameFlags,4))return false;
 const float *arrays[]={s->meterLayout,s->orbLayout,s->barLayout,s->barClocks};const unsigned lengths[]={3,20,6,2};for(unsigned j=0;j<4;j++)for(unsigned k=0;k<lengths[j];k++)if(!isfinite(arrays[j][k])||fabsf(arrays[j][k])>1000000)return false;if(!isfinite(s->fade)||s->fade<0||s->fade>1)return false;
 failureStage=0;return true;
}
int wmain(int argc,wchar_t **argv){
 if(argc!=2&&argc!=3)return 1;wchar_t *end=NULL;unsigned long pid=wcstoul(argv[1],&end,10);if(!pid||*end)return 1;unsigned samples=150;if(argc==3){samples=(unsigned)wcstoul(argv[2],&end,10);if(*end||!samples||samples>12000)return 1;}HANDLE p=OpenProcess(PROCESS_QUERY_LIMITED_INFORMATION|PROCESS_VM_READ,FALSE,(DWORD)pid);if(!p)return 2;
 int result=3;wchar_t file[32768];DWORD n=32768;char sha[65];FILETIME created,exitTime,kernel,user;
 if(!QueryFullProcessImageNameW(p,0,file,&n)||!hashFile(file,sha)||strcmp(sha,"fc6a406ff7ac9b5eb7788dc7a65d335e1c1aad9236618112671975b71d2daddc")||!GetProcessTimes(p,&created,&exitTime,&kernel,&user))goto done;
 uintptr_t base=0;unsigned matches=0;HANDLE modules=CreateToolhelp32Snapshot(TH32CS_SNAPMODULE|TH32CS_SNAPMODULE32,(DWORD)pid);
 if(modules!=INVALID_HANDLE_VALUE){MODULEENTRY32W m={0};m.dwSize=sizeof(m);if(Module32FirstW(modules,&m))do{if(!_wcsicmp(m.szExePath,file)&&m.modBaseSize>0x17eaef0){base=(uintptr_t)m.modBaseAddr;matches++;}}while(Module32NextW(modules,&m));CloseHandle(modules);}if(matches!=1)goto done;
 printf("{\"type\":\"session\",\"pid\":%lu,\"creation\":\"%llu\",\"moduleHash\":\"%s\",\"readOnly\":true}\n",pid,(unsigned long long)(((uint64_t)created.dwHighDateTime<<32)|created.dwLowDateTime),sha);
 unsigned valid=0;
 for(unsigned i=0;i<samples;i++){
  HudSnapshot a,b;bool ok=snap(p,base,&a)&&snap(p,base,&b)&&!memcmp(&a,&b,sizeof(a));if(ok)valid++;else if(!failureStage)failureStage=6;
  printf("{\"type\":\"sample\",\"sequence\":%u,\"tickMs\":%llu,\"valid\":%s,\"failureStage\":%u,\"selectedRaw\":%u,\"realmRaw\":%u,\"unlocksRaw\":%u,\"chargeRaw\":%.9g,\"realmBlend\":%.9g,\"modelPresent\":%s,\"visibleRaw\":%u,\"textureIds\":[",i,(unsigned long long)GetTickCount64(),ok?"true":"false",failureStage,ok?a.selected:0,ok?a.realm:0,ok?a.unlocks:0,ok?a.charge:0,ok?a.blend:0,ok&&a.model?"true":"false",ok?a.visible:0);
  for(unsigned j=0;j<19;j++)printf("%s%u",j?",":"",ok?a.ids[j]:0);printf("],\"barTextureIds\":[%u,%u],\"originalIds\":[",ok?a.barIds[0]:0,ok?a.barIds[1]:0);
  for(unsigned j=0;j<19;j++)printf("%s%u",j?",":"",ok?a.originalIds[j]:0);printf("],\"barOriginalIds\":[%u,%u],\"models\":[",ok?a.barOriginalIds[0]:0,ok?a.barOriginalIds[1]:0);
  for(unsigned j=0;j<3;j++){HudModelMeta *m=&a.models[j];printf("%s{\"valid\":%s,\"name\":",j?",":"",ok&&m->valid?"true":"false");jsonName(ok&&m->valid?m->label:"");printf(",\"modelCount\":%u,\"active\":%u,\"bones\":%u,\"vertices\":%u}",ok&&m->valid?m->modelCount:0,ok&&m->valid?m->active:0,ok&&m->valid?m->bones:0,ok&&m->valid?m->vertices:0);}printf("],\"meterLayout\":[");for(unsigned j=0;j<3;j++)printf("%s%.9g",j?",":"",ok?a.meterLayout[j]:0);printf("],\"orbLayout\":[");for(unsigned j=0;j<20;j++)printf("%s%.9g",j?",":"",ok?a.orbLayout[j]:0);printf("],\"barLayout\":[");for(unsigned j=0;j<6;j++)printf("%s%.9g",j?",":"",ok?a.barLayout[j]:0);printf("],\"barClips\":[%u,%u],\"barClocks\":[%.9g,%.9g],\"fade\":%.9g,\"gameMode\":%u,\"gameFlags\":%u}\n",ok?a.barClips[0]:0,ok?a.barClips[1]:0,ok?a.barClocks[0]:0,ok?a.barClocks[1]:0,ok?a.fade:0,ok?a.gameMode:0,ok?a.gameFlags:0);fflush(stdout);if(i+1<samples)Sleep(argc==3?16:33);
 }
 result=valid?0:5;
done:CloseHandle(p);return result;
}
