// SPDX-License-Identifier: GPL-3.0-or-later
// Anonymous stdin -> distinct HUD pagefile map. No game writes or asset files.
#include <errno.h>
#include <wchar.h>
#include "hud-memory.h"
static bool input(HANDLE p,void *out,DWORD n,const HudSession *s){DWORD done=0;while(done<n){if(!hudSessionValid(s,GetTickCount64())||!hudProcesses(s))return false;DWORD available=0,got=0;if(!PeekNamedPipe(p,NULL,0,NULL,&available,NULL))return false;if(!available){Sleep(2);continue;}DWORD want=n-done;if(want>available)want=available;if(!ReadFile(p,(unsigned char*)out+done,want,&got,NULL)||!got)return false;done+=got;}return true;}
int wmain(int argc,wchar_t **argv){
 if(argc!=7||GetFileType(GetStdHandle(STD_INPUT_HANDLE))!=FILE_TYPE_PIPE)return 1;
 uint64_t a[6];for(unsigned i=0;i<6;i++){wchar_t *end=NULL;errno=0;for(const wchar_t *x=argv[i+1];*x;x++)if(*x<L'0'||*x>L'9')return 1;a[i]=wcstoull(argv[i+1],&end,10);if(errno||*end||!a[i])return 1;}if(a[0]>UINT32_MAX||a[2]>UINT32_MAX||a[5]>HUD_MAX_LIFETIME_MS)return 1;
 HudSession s={0};uint32_t head[]={0x31534448,1,(uint32_t)a[0],GetCurrentProcessId(),(uint32_t)a[2],0};memcpy(s.bytes,head,24);FILETIME c,e,k,u;if(!GetProcessTimes(GetCurrentProcess(),&c,&e,&k,&u))return 2;
 uint64_t rest[]={a[1],((uint64_t)c.dwHighDateTime<<32)|c.dwLowDateTime,a[3],a[4],GetTickCount64()+a[5]};memcpy(s.bytes+24,rest,40);if(!hudSessionValid(&s,GetTickCount64())||!hudProcesses(&s))return 2;
 wchar_t name[160],lockName[160];hudNames(&s,name,lockName);HANDLE lock=CreateMutexW(NULL,FALSE,lockName);if(!lock)return 3;if(GetLastError()==ERROR_ALREADY_EXISTS){CloseHandle(lock);return 3;}
 HANDLE map=CreateFileMappingW(INVALID_HANDLE_VALUE,NULL,PAGE_READWRITE,0,sizeof(HudMemory),name);if(!map||GetLastError()==ERROR_ALREADY_EXISTS){if(map)CloseHandle(map);CloseHandle(lock);return 3;}
 HudMemory *view=MapViewOfFile(map,FILE_MAP_WRITE,0,0,sizeof(*view));unsigned char *packet=malloc(HUD_MAX_TEXTURE_BYTES);int result=4;
 if(view&&packet){memset(view,0,16);view->magic=0x314d4448;printf("{\"session\":\"");for(unsigned i=0;i<64;i++)printf("%02x",s.bytes[i]);printf("\",\"tick\":%llu}\n",(unsigned long long)GetTickCount64());fflush(stdout);result=0;uint64_t seq=0;
  for(;;){uint32_t n=0;if(!input(GetStdHandle(STD_INPUT_HANDLE),&n,4,&s))break;if(n<80||n>HUD_MAX_TEXTURE_BYTES||!input(GetStdHandle(STD_INPUT_HANDLE),packet,n,&s)){result=5;break;}bool bank=hudU32(packet)==0x31544448;
   if(bank?(view->bankSize||!hudBankValid(packet,n,&s)):(!view->bankSize||!hudFrameValid(packet,n,&s,GetTickCount64(),seq,false))){result=6;break;}
   DWORD wait=WaitForSingleObject(lock,bank?100:0);if(wait==WAIT_TIMEOUT&&!bank)continue;if(wait!=WAIT_OBJECT_0){if(wait==WAIT_ABANDONED)ReleaseMutex(lock);result=7;break;}
   if(bank){memcpy(view->bank,packet,n);view->bankSize=n;}else{memcpy(view->frame,packet,n);view->frameSize=n;seq=hudU64(packet+80);view->online=1;}ReleaseMutex(lock);
  }
  DWORD wait=WaitForSingleObject(lock,0);if(wait==WAIT_OBJECT_0||wait==WAIT_ABANDONED){view->online=0;view->frameSize=0;ReleaseMutex(lock);}
 }if(view)UnmapViewOfFile(view);if(map)CloseHandle(map);if(lock)CloseHandle(lock);free(packet);return result;
}
