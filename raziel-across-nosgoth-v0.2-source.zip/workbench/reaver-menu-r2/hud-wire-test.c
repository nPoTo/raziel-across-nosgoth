// SPDX-License-Identifier: GPL-3.0-or-later
#include <stdio.h>
#include <stdlib.h>
#include <io.h>
#include <fcntl.h>
#include "hud-wire.h"
int main(void){_setmode(_fileno(stdin),_O_BINARY);unsigned char *b=malloc(HUD_MAX_TEXTURE_BYTES);if(!b)return 2;uint32_t kind,n;HudSession s={0};uint64_t now;
 while(fread(&kind,4,1,stdin)==1){if(fread(&n,4,1,stdin)!=1||fread(&now,8,1,stdin)!=1||fread(s.bytes,64,1,stdin)!=1||n>HUD_MAX_TEXTURE_BYTES||fread(b,1,n,stdin)!=n){free(b);return 3;}bool ok=kind==1?hudFrameValid(b,n,&s,now,0,false):hudBankValid(b,n,&s);printf("%u\n",ok?1:0);}free(b);return 0;}
