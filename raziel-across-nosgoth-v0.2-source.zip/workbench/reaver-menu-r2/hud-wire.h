// SPDX-License-Identifier: GPL-3.0-or-later
#pragma once
#include <stdint.h>
#include <stdbool.h>
#include <stddef.h>
#include <string.h>
#include <math.h>
#include "hud-policy.h"
typedef struct{unsigned char bytes[64];} HudSession;
static uint32_t hudU32(const unsigned char *p){uint32_t x;memcpy(&x,p,4);return x;}
static uint64_t hudU64(const unsigned char *p){uint64_t x;memcpy(&x,p,8);return x;}
static float hudF32(const unsigned char *p){float x;memcpy(&x,p,4);return x;}
static bool hudSessionValid(const HudSession *s,uint64_t now){
 return s&&hudU32(s->bytes)==0x31534448&&hudU32(s->bytes+4)==1&&hudU32(s->bytes+8)&&hudU32(s->bytes+12)&&hudU32(s->bytes+16)&&!hudU32(s->bytes+20)&&hudU64(s->bytes+24)&&hudU64(s->bytes+32)&&hudU64(s->bytes+40)&&hudU64(s->bytes+48)&&now<hudU64(s->bytes+56)&&hudU64(s->bytes+56)-now<=(uint64_t)HUD_MAX_LIFETIME_MS;
}
static bool hudFrameValid(const unsigned char *b,size_t n,const HudSession *s,uint64_t now,uint64_t previous,bool allowRepeat){
 if(!hudSessionValid(s,now)||!b||n<96||n>HUD_MAX_FRAME_BYTES||hudU32(b)!=0x31464448||hudU32(b+4)!=1||hudU32(b+8)!=n||memcmp(b+16,s->bytes,64))return false;
 uint32_t count=hudU32(b+12);uint64_t seq=hudU64(b+80),tick=hudU64(b+88);
 if(count>HUD_MAX_QUADS||n!=96+(size_t)count*80||!seq||seq<previous||(!allowRepeat&&seq==previous)||!tick||tick>now||now-tick>HUD_MAX_AGE_MS)return false;
 for(unsigned i=0;i<count;i++){const unsigned char *q=b+96+i*80;if(!hudU32(q)||hudU32(q)>65535||hudU32(q+4)!=1||hudU64(q+8))return false;
  for(unsigned k=0;k<16;k++){float f=hudF32(q+16+k*4);if(!isfinite(f)||(k<8?fabsf(f)>2048:(f<0||f>1)))return false;}
 }
 return true;
}
static bool hudBankValid(const unsigned char *b,size_t n,const HudSession *s){
 if(!b||!s||n<80||n>HUD_MAX_TEXTURE_BYTES||hudU32(b)!=0x31544448||hudU32(b+4)!=1||hudU32(b+8)!=n||memcmp(b+16,s->bytes,64))return false;
 uint32_t count=hudU32(b+12);if(!count||count>HUD_MAX_TEXTURES||n<80+(size_t)count*32)return false;size_t cursor=80+count*32;
 for(unsigned i=0;i<count;i++){const unsigned char *d=b+80+i*32;uint32_t id=hudU32(d),w=hudU32(d+4),h=hudU32(d+8),o=hudU32(d+12),z=hudU32(d+16);
  if(!id||id>65535||!w||!h||w>2048||h>2048||z!=(uint64_t)w*h*4||o!=cursor||z>n-cursor||hudU32(d+20)||hudU64(d+24))return false;
  for(unsigned j=0;j<i;j++)if(hudU32(b+80+j*32)==id)return false;cursor+=z;
 }return cursor==n;
}
