// SPDX-License-Identifier: GPL-3.0-or-later
#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <stdint.h>
#include <stdbool.h>
#include <stdio.h>
#include <wchar.h>
#include "exploration-sheets.h"
#include "guidance-plan.h"
#define REQUIRE(x) do{if(!(x)){fprintf(stderr,"FAIL %d\n",__LINE__);return 1;}}while(0)
int main(void){REQUIRE(guidanceSeconds(15)==50);for(unsigned i=0;i<50;i++){const TutorialStage *s=guidanceStageAt(15,i);REQUIRE(s&&s->title&&wcslen(s->title)&&s->begin==(i<20?0:20)&&s->end==(i<20?20:50));}REQUIRE(!guidanceStageAt(15,50));GuidanceDescriptor d={0x31445548,1,10,20,15,50,500,0,123,{0}};const char *h=EXPLORATION_SHEET_SHA256;for(unsigned i=0;i<32;i++)d.sheetHash[i]=(unsigned char)(guidanceHex(h[i*2])*16+guidanceHex(h[i*2+1]));REQUIRE(guidanceDescriptorValid(&d,10,20,500));d.seconds=170;REQUIRE(!guidanceDescriptorValid(&d,10,20,500));puts("PASS actual plan15: all 50 seconds, transition20, terminal50, exact descriptor/hash, foreign length refusal.");return 0;}
