// SPDX-License-Identifier: GPL-3.0-or-later
#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <stdint.h>
#include <string.h>
#include <assert.h>
typedef struct{uintptr_t at;size_t size;unsigned char bytes[128];} Cell;
static Cell cells[64];static unsigned count;
static void cell(uintptr_t at,const void *p,size_t n){assert(count<64&&n<=128);cells[count].at=at;cells[count].size=n;memcpy(cells[count++].bytes,p,n);}
static BOOL WINAPI fixtureRead(HANDLE p,LPCVOID at,LPVOID out,SIZE_T n,SIZE_T *got){(void)p;for(unsigned i=0;i<count;i++)if(cells[i].at==(uintptr_t)at&&cells[i].size==n){memcpy(out,cells[i].bytes,n);*got=n;return TRUE;}return FALSE;}
#define ReadProcessMemory fixtureRead
#define wmain unusedHudMain
#include "native-hud-observer.c"
#undef wmain
#undef ReadProcessMemory
int main(void){
 const Sheet_nativeHudRead *r=&sheet_nativeHudRead_bounded;uintptr_t base=0x10000000,player=0x200000,data=0x300000,context=0x400000,meter=base+r->meterVtableRva,bar=base+r->barVtableRva,defs=0x500000,model=0;uint32_t selected=9,realm=2,unlocks=0;float charge=40,blend=1;unsigned char visible=1;uint32_t ids[19]={1,2,3},barIds[2]={4,5},original[19]={101,102,103},barOriginal[2]={104,105};
 cell(base+r->meterRva,&meter,8);cell(base+r->barRva,&bar,8);cell(base+r->playerRva,&player,8);cell(player+r->dataOffset,&data,8);unsigned owner=count;cell(data,&player,8);cell(base+r->stateRva,&context,8);
 cell(data+r->chargeOffset,&charge,4);cell(context+r->selectedOffset,&selected,4);cell(context+r->realmOffset,&realm,4);cell(base+r->blendRva,&blend,4);cell(base+r->unlocksRva,&unlocks,4);
 cell(base+r->meterRva+r->defsOffset,&defs,8);cell(base+r->barRva+r->defsOffset,&defs,8);cell(base+r->meterRva+r->meterTexturesOffset,ids,sizeof(ids));cell(base+r->barRva+r->barTexturesOffset,barIds,sizeof(barIds));cell(base+r->meterRva+r->modelOffset,&model,8);cell(base+r->meterRva+0x10,&visible,1);
 cell(defs+0x2c,original,sizeof(original));cell(defs+0x1c,barOriginal,sizeof(barOriginal));
 for(unsigned i=0;i<5;i++){uint16_t handle=(uint16_t)(i+1);cell(base+r->textureLookupRva+(101+i)*2,&handle,2);}
 uintptr_t emptyActors[2]={0};cell(base+r->barRva+0x18,emptyActors,sizeof(emptyActors));
 float meterLayout[3]={400,270,64},orbLayout[20]={0},barLayout[6]={0,0,192,48,0,1},clocks[2]={0},fade=1;unsigned char clips[2]={7,8},mode=0;uint32_t flags=0;
 cell(base+r->meterRva+0x64,meterLayout,sizeof(meterLayout));cell(base+r->meterRva+0xd4,orbLayout,sizeof(orbLayout));cell(base+r->barRva+0x3c,barLayout,sizeof(barLayout));cell(base+r->barRva+0x28,clocks,sizeof(clocks));cell(defs+0x2c,clips,sizeof(clips));cell(base+r->meterRva+0x4c,&fade,4);cell(base+0xc5ab60,&mode,1);cell(base+0xc5ab38,&flags,4);
 HudSnapshot a,b;assert(context!=data);assert(snap(NULL,base,&a)&&snap(NULL,base,&b)&&!memcmp(&a,&b,sizeof(a)));assert(a.charge==40&&a.selected==9&&a.realm==2);
 uintptr_t other=player+8;memcpy(cells[owner].bytes,&other,8);assert(!snap(NULL,base,&a)&&failureStage==2);memcpy(cells[owner].bytes,&player,8);
 memcpy(cells[0].bytes,&other,8);assert(!snap(NULL,base,&a)&&failureStage==1);memcpy(cells[0].bytes,&meter,8);
 assert(snap(NULL,base,&a));cells[13].bytes[0]^=1;assert(!snap(NULL,base,&b)&&failureStage==7);cells[13].bytes[0]^=1;
 cells[6].bytes[0]^=1;assert(snap(NULL,base,&b)&&memcmp(&a,&b,sizeof(a)));puts("PASS actual reader: distinct native contexts, player owner, vtable, original-ID/runtime-handle match and torn metadata");return 0;
}
