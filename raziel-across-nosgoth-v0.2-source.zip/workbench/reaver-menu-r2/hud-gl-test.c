// SPDX-License-Identifier: GPL-3.0-or-later
#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <stdint.h>
#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <io.h>
#include <fcntl.h>
#include "exploration-sheets.h"
#include "hud-render.h"
#define REQUIRE(x) do{if(!(x)){fprintf(stderr,"FAIL line %d: %s\n",__LINE__,#x);return 1;}}while(0)
static bool same(const ReaverGLState *expected){ReaverGLState actual={0};reaverGLSave(&actual);return !memcmp(expected,&actual,sizeof(actual));}
int main(int argc,char **argv){
 (void)argv;
 WNDCLASSW wc={0};wc.lpfnWndProc=DefWindowProcW;wc.hInstance=GetModuleHandleW(NULL);wc.lpszClassName=L"RazielHudIsolatedGLTest";REQUIRE(RegisterClassW(&wc));HWND window=CreateWindowW(wc.lpszClassName,L"Hidden HUD renderer test",WS_POPUP,0,0,320,320,NULL,NULL,wc.hInstance,NULL);REQUIRE(window);
 HDC dc=GetDC(window);PIXELFORMATDESCRIPTOR pf={0};pf.nSize=sizeof(pf);pf.nVersion=1;pf.dwFlags=PFD_DRAW_TO_WINDOW|PFD_SUPPORT_OPENGL|PFD_DOUBLEBUFFER;pf.iPixelType=PFD_TYPE_RGBA;pf.cColorBits=32;pf.cDepthBits=24;pf.cAlphaBits=8;int format=ChoosePixelFormat(dc,&pf);REQUIRE(format&&SetPixelFormat(dc,format,&pf));HGLRC context=wglCreateContext(dc);REQUIRE(context&&wglMakeCurrent(dc,context));REQUIRE(reaverGLLoad());
 glViewport(0,0,320,320);glClearColor(0,0,1,1);glClearDepth(0);glClear(GL_COLOR_BUFFER_BIT|GL_DEPTH_BUFFER_BIT);
 glEnable(GL_CULL_FACE);glEnable(GL_STENCIL_TEST);glEnable(GL_SCISSOR_TEST);glScissor(0,0,1,1);glEnable(GL_RASTERIZER_DISCARD);glEnable(GL_COLOR_LOGIC_OP);glEnable(GL_CLIP_DISTANCE0);glEnable(GL_SAMPLE_COVERAGE);glEnable(GL_SAMPLE_ALPHA_TO_COVERAGE);glEnable(GL_SAMPLE_ALPHA_TO_ONE);glEnable(GL_SAMPLE_MASK);glPolygonMode(GL_FRONT_AND_BACK,GL_LINE);glEnable(GL_DEPTH_TEST);glDepthFunc(GL_LESS);glDepthMask(GL_TRUE);
 ghActiveTexture(GL_TEXTURE3);glPixelStorei(GL_UNPACK_ALIGNMENT,8);glPixelStorei(GL_UNPACK_ROW_LENGTH,17);glPixelStorei(GL_UNPACK_SKIP_ROWS,2);glPixelStorei(GL_UNPACK_SKIP_PIXELS,3);rgBlendFuncSeparatei(0,GL_DST_COLOR,GL_ZERO,GL_ZERO,GL_ONE);rgBlendEquationSeparatei(0,GL_FUNC_REVERSE_SUBTRACT,GL_FUNC_SUBTRACT);
 ReaverGLState saved={0};reaverGLSave(&saved);HudSession s={0};uint32_t header[]={0x31534448,1,10,20,30,0};memcpy(s.bytes,header,24);uint64_t rest[]={1,2,3,4,90000};memcpy(s.bytes+24,rest,40);
 unsigned char bank[116]={0};uint32_t bh[]={0x31544448,1,sizeof(bank),1};memcpy(bank,bh,16);memcpy(bank+16,s.bytes,64);uint32_t td[]={1438,1,1,112,4,0,0,0};memcpy(bank+80,td,32);bank[112]=255;bank[115]=128;
 HudDisplay display={0};REQUIRE(hudLoadBank(&display,&s,bank,sizeof(bank)));REQUIRE(same(&saved));
 unsigned char frame[176]={0};uint32_t fh[]={0x31464448,1,sizeof(frame),1};memcpy(frame,fh,16);memcpy(frame+16,s.bytes,64);uint64_t receipt[]={1,10000};memcpy(frame+80,receipt,16);uint32_t qh[]={1438,1,0,0};memcpy(frame+96,qh,16);float q[]={0,0,256,0,256,768,0,768,0,0,1,1,1,1,1,1};memcpy(frame+112,q,sizeof(q));
 GLint viewport[]={0,0,320,320};REQUIRE(hudDisplayFrame(&display,frame,sizeof(frame),10000,viewport));REQUIRE(same(&saved));unsigned char pixel[4];glReadPixels(38,96,1,1,GL_RGBA,GL_UNSIGNED_BYTE,pixel);REQUIRE(pixel[0]>=127&&pixel[0]<=129&&pixel[1]==0&&pixel[2]>=126&&pixel[2]<=128);
 unsigned char outside[4];glReadPixels(250,250,1,1,GL_RGBA,GL_UNSIGNED_BYTE,outside);REQUIRE(outside[0]==0&&outside[1]==0&&outside[2]==255);float depth=-1;glReadPixels(38,96,1,1,GL_DEPTH_COMPONENT,GL_FLOAT,&depth);REQUIRE(depth==0);
 REQUIRE(!hudDisplayFrame(&display,frame,sizeof(frame),10151,viewport));REQUIRE(!hudDisplayFrame(&display,frame,sizeof(frame),9999,viewport));frame[96]^=1;REQUIRE(!hudDisplayFrame(&display,frame,sizeof(frame),10000,viewport));frame[96]^=1;REQUIRE(same(&saved));
 bank[112]=0;bank[113]=255;REQUIRE(hudLoadBank(&display,&s,bank,sizeof(bank)));REQUIRE(same(&saved));REQUIRE(hudDisplayFrame(&display,frame,sizeof(frame),10000,viewport));REQUIRE(same(&saved));
 if(argc>1){_setmode(_fileno(stdin),_O_BINARY);uint32_t n=0;REQUIRE(fread(&n,4,1,stdin)==1&&n<=HUD_MAX_TEXTURE_BYTES);unsigned char *original=malloc(n);REQUIRE(original&&fread(original,1,n,stdin)==n);REQUIRE(hudLoadBank(&display,&s,original,n));free(original);REQUIRE(same(&saved));unsigned frames=0;unsigned char prepared[HUD_MAX_FRAME_BYTES];while(fread(&n,4,1,stdin)==1){REQUIRE(n<=HUD_MAX_FRAME_BYTES&&fread(prepared,1,n,stdin)==n);REQUIRE(hudDisplayFrame(&display,prepared,n,10000,viewport));REQUIRE(same(&saved));frames++;}REQUIRE(frames>=10);printf("PASS original HUD RAM artwork: %u textures uploaded, %u composed frames; no resource files.\n",display.count,frames);}
 REQUIRE(reaverGLDestroy(&display.gl));REQUIRE(same(&saved));REQUIRE(glGetError()==GL_NO_ERROR);
 wglMakeCurrent(NULL,NULL);wglDeleteContext(context);ReleaseDC(window,dc);DestroyWindow(window);puts("PASS real hidden GL HUD: source-alpha pixels, transparent outside, depth ignored/not written, texture replacement, stale/missing-ID refusal and exact GL state restoration. Synthetic artwork only.");return 0;
}
