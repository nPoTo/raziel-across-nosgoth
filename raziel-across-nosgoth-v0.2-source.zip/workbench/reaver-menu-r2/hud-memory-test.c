// SPDX-License-Identifier: GPL-3.0-or-later
// Read-only synthetic transport consumer. Does not open games or draw.
#include <wchar.h>
#include "hud-memory.h"
int wmain(int argc,wchar_t **argv){if(argc!=2||wcslen(argv[1])!=128)return 1;HudSession s;for(unsigned i=0;i<64;i++){unsigned x=0;if(swscanf(argv[1]+i*2,L"%2x",&x)!=1)return 1;s.bytes[i]=(unsigned char)x;}bool valid=false;
 if(hudSessionValid(&s,GetTickCount64())&&hudProcesses(&s)){wchar_t name[160],mutex[160];hudNames(&s,name,mutex);HANDLE map=OpenFileMappingW(FILE_MAP_READ,FALSE,name),lock=OpenMutexW(SYNCHRONIZE|MUTEX_MODIFY_STATE,FALSE,mutex);const HudMemory *v=map?MapViewOfFile(map,FILE_MAP_READ,0,0,sizeof(*v)):NULL;
  if(v&&lock){DWORD wait=WaitForSingleObject(lock,0);if(wait==WAIT_OBJECT_0){valid=v->magic==0x314d4448&&v->online==1&&v->frameSize<=HUD_MAX_FRAME_BYTES&&v->bankSize<=HUD_MAX_TEXTURE_BYTES&&hudFrameValid(v->frame,v->frameSize,&s,GetTickCount64(),0,false)&&hudBankValid(v->bank,v->bankSize,&s);ReleaseMutex(lock);}else if(wait==WAIT_ABANDONED)ReleaseMutex(lock);}
  if(v)UnmapViewOfFile(v);if(lock)CloseHandle(lock);if(map)CloseHandle(map);
 }printf("%u\n",valid?1:0);return 0;}
