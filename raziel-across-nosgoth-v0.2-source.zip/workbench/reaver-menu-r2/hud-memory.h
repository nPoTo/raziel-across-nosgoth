// SPDX-License-Identifier: GPL-3.0-or-later
#pragma once
#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <stdio.h>
#include <stdlib.h>
#include "hud-wire.h"
typedef struct{uint32_t magic,online,frameSize,bankSize;unsigned char frame[HUD_MAX_FRAME_BYTES],bank[HUD_MAX_TEXTURE_BYTES];} HudMemory;
static void hudNames(const HudSession *s,wchar_t map[160],wchar_t mutex[160]){
 _snwprintf(map,160,L"Local\\RazielHud-%lu-%lu-%llu",(unsigned long)hudU32(s->bytes+8),(unsigned long)hudU32(s->bytes+12),(unsigned long long)hudU64(s->bytes+48));_snwprintf(mutex,160,L"%ls-lock",map);
}
static bool hudProcess(uint32_t pid,uint64_t born){
 HANDLE h=OpenProcess(PROCESS_QUERY_LIMITED_INFORMATION|SYNCHRONIZE,FALSE,pid);if(!h)return false;FILETIME c,e,k,u;bool ok=GetProcessTimes(h,&c,&e,&k,&u)&&(((uint64_t)c.dwHighDateTime<<32)|c.dwLowDateTime)==born&&WaitForSingleObject(h,0)==WAIT_TIMEOUT;CloseHandle(h);return ok;
}
static bool hudProcesses(const HudSession *s){return hudProcess(hudU32(s->bytes+8),hudU64(s->bytes+24))&&hudProcess(hudU32(s->bytes+12),hudU64(s->bytes+32))&&hudProcess(hudU32(s->bytes+16),hudU64(s->bytes+40));}
