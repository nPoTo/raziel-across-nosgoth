// SPDX-License-Identifier: GPL-3.0-or-later
// Bounded external scalar observer: PROCESS_VM_READ only. No hooks or input.
#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <tlhelp32.h>
#include <bcrypt.h>
#include <stdbool.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <wchar.h>
#include "reader-hash.h"
#include "exploration-sheets.h"
static bool readAt(HANDLE p,uintptr_t a,void *out,SIZE_T n){SIZE_T got=0;return a&&ReadProcessMemory(p,(void*)a,out,n,&got)&&got==n;}
static bool codeProof(HANDLE p,uintptr_t base,const Sheet_nativeMenuProof *proof){
 unsigned char bytes[4096],digest[32];char text[65],expected[65];BCRYPT_ALG_HANDLE alg=NULL;BCRYPT_HASH_HANDLE h=NULL;bool ok=false;
 if(proof->size<1||proof->size>4096||!readAt(p,base+(uintptr_t)proof->rva,bytes,(SIZE_T)proof->size)||!WideCharToMultiByte(CP_UTF8,0,proof->sha256,-1,expected,65,NULL,NULL))return false;
 if(BCryptOpenAlgorithmProvider(&alg,BCRYPT_SHA256_ALGORITHM,NULL,0)<0||BCryptCreateHash(alg,&h,NULL,0,NULL,0,0)<0||BCryptHashData(h,bytes,(ULONG)proof->size,0)<0||BCryptFinishHash(h,digest,32,0)<0)goto done;
 for(unsigned i=0;i<32;i++)sprintf(text+i*2,"%02x",digest[i]);text[64]=0;ok=!strcmp(text,expected);
done:if(h)BCryptDestroyHash(h);if(alg)BCryptCloseAlgorithmProvider(alg,0);return ok;
}
typedef struct{uintptr_t player,statePlayer,process,glyph,object,name,privateData;uint32_t plane,globalFlags,streamFlags,actorFlags;uint16_t mode,glyphQuery;char label[9];bool glyphReadable;} Snapshot;
static bool snapshot(HANDLE p,uintptr_t base,uintptr_t imageSize,Snapshot *s){
 memset(s,0,sizeof(*s));
#define FIELD(key,target) if(!readAt(p,base+(uintptr_t)sheet_nativeMenuRead_##key.rva,&s->target,sizeof(s->target)))return false
 FIELD(player,player);FIELD(statePlayer,statePlayer);FIELD(process,process);FIELD(glyph,glyph);FIELD(plane,plane);FIELD(globalFlags,globalFlags);FIELD(streamFlags,streamFlags);FIELD(mode,mode);
#undef FIELD
 if(!s->player||s->statePlayer!=s->player||s->process<base||s->process>=base+imageSize||!readAt(p,s->player+0x30,&s->object,8)||!s->object||!readAt(p,s->object+0x30,&s->name,8)||!readAt(p,s->name,s->label,9)||memcmp(s->label,"raziel__",9)||!readAt(p,s->player+0x28,&s->actorFlags,4))return false;
 // Native query073720 reads precisely this signed-short slot. No writes or
 // interpretation of a generic mode12 as Glyph-menu ownership.
 if(s->glyph&&readAt(p,s->glyph+0x2c0,&s->privateData,8)&&s->privateData&&readAt(p,s->privateData+0x112,&s->glyphQuery,2))s->glyphReadable=true;
 return true;
}
int wmain(int argc,wchar_t **argv){
 if(argc!=2)return 1;wchar_t *end=NULL;unsigned long pid=wcstoul(argv[1],&end,10);if(!pid||*end)return 1;
 HANDLE p=OpenProcess(PROCESS_QUERY_LIMITED_INFORMATION|PROCESS_VM_READ,FALSE,(DWORD)pid);if(!p)return 2;
 int result=3;wchar_t file[32768],dll[32768];DWORD n=32768;char sha[65];FILETIME created,exited,kernel,user;
 if(!QueryFullProcessImageNameW(p,0,file,&n)||n+12>=32768||!wcsrchr(file,L'\\')||_wcsicmp(wcsrchr(file,L'\\')+1,L"SRX.exe")||!hashFile(file,sha)||strcmp(sha,"0fb3aef0530ebf0510191f934dc371b69b43574331d3623eda694b72f060db93"))goto done;
 wcscpy(dll,file);wcscpy(wcsrchr(dll,L'\\')+1,L"1\\sr1.dll");if(!hashFile(dll,sha)||strcmp(sha,"c006dea45509cdc3fbfab3a4230b47869c306ecdd7df8b4fd2499fd3654a2205")||!GetProcessTimes(p,&created,&exited,&kernel,&user))goto done;
 HANDLE modules=CreateToolhelp32Snapshot(TH32CS_SNAPMODULE|TH32CS_SNAPMODULE32,(DWORD)pid);uintptr_t base=0,imageSize=0;unsigned matches=0;
 if(modules!=INVALID_HANDLE_VALUE){MODULEENTRY32W m={0};m.dwSize=sizeof(m);if(Module32FirstW(modules,&m))do{if(!_wcsicmp(m.szExePath,dll)&&m.modBaseSize>0x2a89538){matches++;base=(uintptr_t)m.modBaseAddr;imageSize=m.modBaseSize;}}while(Module32NextW(modules,&m));CloseHandle(modules);}
 if(matches!=1)goto done;
 for(unsigned i=0;i<sheet_nativeMenuProof_count;i++)if(!codeProof(p,base,sheet_nativeMenuProof_rows[i])){result=4;goto done;}
 uint64_t creation=((uint64_t)created.dwHighDateTime<<32)|created.dwLowDateTime;
 printf("{\"type\":\"session\",\"pid\":%lu,\"creation\":\"%llu\",\"moduleHash\":\"%s\",\"readOnly\":true}\n",pid,(unsigned long long)creation,sha);
 unsigned coherent=0;uintptr_t previous=0;unsigned generation=0;
 for(unsigned i=0;i<150;i++){
  Snapshot a,b;bool ok=snapshot(p,base,imageSize,&a)&&snapshot(p,base,imageSize,&b)&&!memcmp(&a,&b,sizeof(a));
  if(ok){coherent++;if(previous!=a.player){generation++;previous=a.player;}}else previous=0;
  printf("{\"type\":\"sample\",\"sequence\":%u,\"tickMs\":%llu,\"valid\":%s,\"generation\":%u,\"planeRaw\":%u,\"modeRaw\":%u,\"globalFlagsRaw\":%u,\"streamFlagsRaw\":%u,\"actorFlagsRaw\":%u,\"processRva\":\"0x%llx\",\"glyphReadable\":%s,\"glyphQueryRaw\":%u}\n",i,(unsigned long long)GetTickCount64(),ok?"true":"false",ok?generation:0,ok?a.plane:0,ok?a.mode:0,ok?a.globalFlags:0,ok?a.streamFlags:0,ok?a.actorFlags:0,(unsigned long long)(ok?a.process-base:0),ok&&a.glyphReadable?"true":"false",ok?a.glyphQuery:0);fflush(stdout);if(i<149)Sleep(33);
 }
 result=coherent?0:5;
done:CloseHandle(p);return result;
}
