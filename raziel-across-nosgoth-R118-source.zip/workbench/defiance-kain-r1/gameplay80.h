// SPDX-License-Identifier: GPL-3.0-or-later
#pragma once
#include "native-ai-core.h"
#include "native-output92.h"
#include "reaction-presentation86.h"
#include "ghost-presentation85.h"
#include "render-identity91.h"
#include "boss-contact92.h"
#include "encounter93.h"
#include "combat95.h"
#include "sluagh-resource80-policy.h"
#include "kain102-policy.h"
static const Sheet_kain102 *const kainPolicy102=&sheet_kain102_beam_sequence_guard_step;
static const Sheet_kain103 *const kainPolicy103=&sheet_kain103_native_charge_air_recovery;
static const Sheet_kain104 *const kainPolicy104=&sheet_kain104_native_physics_fall_boundary;
static const Sheet_kain105 *const kainPolicy105=&sheet_kain105_lost_support_and_navigation_receipts;
static const Sheet_kain106 *const kainPolicy106=&sheet_kain106_native_fly_boundary_lease;
static bool kainNavigation102(const float *,const float *);
static bool kainProjectNavigation105(const float *,float *);
static bool sluaghMove80(float,float);
static void sluaghQueueMove80(float,float);
// Local single-enemy prototype. Original resources never leave RAM.
typedef struct {uint32_t first,count,keys,timePerKey;} SluaghClip80;
typedef struct {uint32_t vertices,indices,texture;uint16_t index[8192],source[2048];} SluaghBatch80;
typedef struct {
 unsigned char *allocation;float *position,*uv,*bind,*root,*pose;unsigned char *joints,*weights,*materials,*texture,*attributes;
 uint16_t *indices,*palette;SluaghClip80 *clips;uint32_t vertices,indexCount,textures,bones,clipCount,frames,paletteCount,bindCount;
 SluaghBatch80 batches[64];unsigned batchCount;uintptr_t module;
 uint32_t voiceRate100[4],voiceBytes100[4];unsigned char *voicePcm100[4];
} SluaghResources80;
static SluaghResources80 sluaghResources80;
static volatile LONG sluaghReady80,sluaghCommand80;
static volatile LONG64 sluaghLastVisual80;
static SRWLOCK sluaghRenderLock80=SRWLOCK_INIT;
static struct {
 uintptr_t actor,object,tracker,player;uint32_t generation,playerGeneration,world;int16_t hp,maxHp;
 bool pinned,loading,initializing,initialized,hitActive,hitSent,render;int16_t spawn[3];
 uint64_t requested,lastTick,decision,lastLog;unsigned clip;float sample,position[3],yaw,precise[3];bool preciseValid;
 SluaghNativeAI ai;float matrices[79*16];unsigned presentationState;bool ghost;int32_t playerHealth;float nativeScale[3];unsigned moveAccepted,moveBlocked,moveRestored;float pendingMove[2];uint64_t pendingMoveTick;
 bool sucking85;uint64_t suckingSince85,mouthTick85;float mouth85[3];
 bool airborne86,hurt86,endAck86,deathDone86,endDelivered87,airHit94,airPursuit95;float highestZ86,groundZ86,opacity86,blendPose86[1264];uint64_t blendTick86;unsigned reaction86;
 unsigned strikeSeen96,yellowCharge100;
 float previousPose98[1264],previousPosition98[3],previousYaw98,publishedYaw98;uint64_t poseTick98,poseStep98,maximumGap98,clampedFrames98;bool previousValid98;
} sluagh80;
static void sluaghBlend86(uint64_t now){
 if(sluagh80.render){memcpy(sluagh80.blendPose86,sluagh80.matrices,sizeof sluagh80.blendPose86);sluagh80.blendTick86=now;}
}
static bool sluaghPresent86(unsigned key,unsigned logical,bool loop,uint64_t now){
 if(sluagh80.reaction86==key&&!sluagh80.hurt86)return true;
 sluaghBlend86(now);if(!snPresent86(&sluagh80.ai,logical,loop))return false;
 sluagh80.clip=sluagh80.ai.clip;sluagh80.sample=0;sluagh80.reaction86=key;sluagh80.hurt86=false;sluagh80.endAck86=false;sluagh80.endDelivered87=false;
 record("kain92 presentation key=%u logical=%u clip=%u loop=%u",key,logical,sluagh80.clip,loop);return true;
}
static void (*sluaghOriginalInit80)(uintptr_t);
static uintptr_t (*sluaghOriginalLookup80)(uintptr_t,uint32_t);
static void (*sluaghOriginalAdditional80)(uintptr_t,uintptr_t);
static void (*sluaghOriginalLanding87)(uintptr_t);
static uintptr_t sluaghPairs80[32][2];
static _Thread_local struct {HGLRC context;uint64_t frame;uintptr_t actor;uint32_t generation;unsigned joints;float values[96*12];bool valid;} sluaghProxyPalette80;
static _Thread_local float sluaghCamera80[16];
static _Thread_local uint64_t sluaghCameraFrame80;
static _Thread_local ReaverGL sluaghGL80;
#include "boss-hud92.h"
static KainEncounter93 kainEncounter93;static bool kainKeep93,kainRestore93;
static uint64_t kainDeath92,kainGrabTick92;static float kainGrabOffset92[2];static unsigned kainGrabSeen92,kainDamageSeen92,kainFxSeen92;
static _Thread_local uint64_t sluaghSuckStart85;
static _Thread_local float sluaghSuckDistance85;
static bool sluaghOwned80(uintptr_t actor){return actor&&actor==sluagh80.actor&&generation(actor)==sluagh80.generation;}
#include "boss-effects95.h"
static bool kainBeamBusy102(void);
static void kainVoice100(unsigned,uint64_t);
static bool kainGuard102(void){
 uint32_t state=0;
 return sluagh80.render&&sluagh80.hp>0&&!sluagh80.hurt86&&!sluagh80.airborne86&&!sluagh80.airPursuit95&&
  !kainBeamBusy102()&&sluagh80.clip==(unsigned)kainPolicy102->guardRuntimeClip&&sluagh80.ai.logical==(unsigned)kainPolicy102->guardLogical&&
  (sluagh80.ai.mode==12||sluagh80.ai.mode==37)&&readAt(sluagh80.actor+0x2f0,&state,4)&&state!=8&&state!=9&&state!=11&&state!=15;
}
#include "boss-contract114.h"
static int32_t kainIncoming99(uintptr_t target,int32_t amount){
 if(amount<=0||!sluaghOwned80(target)||!sluagh80.player||sluagh80.maxHp!=30000||!InterlockedCompareExchange(&portableActive60,0,0))return amount;
 if(kainGuard102()){kainVoice100(3,GetTickCount64());record("kain102 guard-contact blocked=%d clip=%u logical=%u",amount,sluagh80.clip,sluagh80.ai.logical);return 0;}
 uint32_t powers=0;readAt(base+acquisition->abilitiesRva,&powers,4);const bool sword=(powers&(uint32_t)combatPolicy->reaverAbility)!=0;
 const unsigned form=localCurrentForm(1),bp=sword?(form==(unsigned)kainPolicy114->spiritForm?(unsigned)kainPolicy114->spiritBp:kainBasis114((unsigned)kainPolicy114->swordMinBp,(unsigned)kainPolicy114->swordMaxBp)):kainBasis114((unsigned)kainPolicy114->fistMinBp,(unsigned)kainPolicy114->fistMaxBp);
 const int damage=kainPercent114(bp);record("kain114 incoming sword=%u form=%u basis-points=%u native=%d maximum=%d",sword,form,bp,damage,sluagh80.maxHp);return damage;
}
static bool kainNoRegen93(uintptr_t actor){return sluagh80.player&&!sluagh80.loading&&sluaghOwned80(actor);}
static void sluaghPlayerHead85(uintptr_t actor,const float pose[66][13]){
 if(!sluagh80.actor||actor!=sluagh80.player||generation(actor)!=sluagh80.playerGeneration)return;
 float head[16],mouth[3];int16_t root[3];
 if(!decodeHostRenderRoot((const unsigned char*)pose[18],head)||!readAt(actor+0x9c,root,6))return;
 float distance=0;for(unsigned k=0;k<3;k++){mouth[k]=head[12+k]-30.f*head[4+k]-12.f*head[8+k];if(!isfinite(mouth[k]))return;float d=mouth[k]-root[k];distance+=d*d;}
 if(distance>1000.f*1000.f)return;
 AcquireSRWLockExclusive(&sluaghRenderLock80);memcpy(sluagh80.mouth85,mouth,12);sluagh80.mouthTick85=GetTickCount64();ReleaseSRWLockExclusive(&sluaghRenderLock80);
}
static bool sluaghResourceRead80(HANDLE pipe,void *data,DWORD size){
 while(size){DWORD count=0;if(!ReadFile(pipe,data,size,&count,NULL)||!count)return false;data=(char*)data+count;size-=count;}return true;
}
static DWORD WINAPI kainVoiceWorker100(void *unused);
static bool sluaghParseInner92(unsigned char *bytes,uint32_t length,SluaghResources80 *r){
 if(length<48||length>32*1024*1024)return false;char digest[65];if(!boundedSha256(bytes,length,32*1024*1024,digest)||strcmp(digest,SLUAGH_RAM_SHA))return false;
 uint32_t h[12];memcpy(h,bytes,48);
 if(h[0]!=0x324e414b||h[1]!=1||!h[2]||h[2]>65535||!h[3]||h[3]>196605||h[3]%3||h[4]!=18||h[5]!=79||h[6]!=48||!h[7]||h[7]>10000||h[8]!=12448||h[9]!=71||!h[10]||h[10]>128||h[11]!=128)return false;
 *r=(SluaghResources80){.allocation=bytes,.vertices=h[2],.indexCount=h[3],.textures=h[4],.bones=h[5],.clipCount=h[6],.frames=h[7],.paletteCount=h[10],.bindCount=h[11]};
 size_t at=48;
#define S80_TAKE(field,type,count) do{size_t size=(size_t)(count)*sizeof(type);if(size>length-at)return false;r->field=(type*)(bytes+at);at+=size;}while(0)
 S80_TAKE(position,float,r->vertices*3);S80_TAKE(uv,float,r->vertices*2);S80_TAKE(joints,unsigned char,r->vertices*4);S80_TAKE(weights,unsigned char,r->vertices*4);S80_TAKE(materials,unsigned char,r->vertices);
 S80_TAKE(indices,uint16_t,r->indexCount);S80_TAKE(palette,uint16_t,r->paletteCount);S80_TAKE(bind,float,r->bindCount*3);S80_TAKE(texture,unsigned char,18*256*256*4);
 S80_TAKE(clips,SluaghClip80,48);S80_TAKE(root,float,r->frames*3);S80_TAKE(pose,float,r->frames*79*16);
 uint32_t rel[71];if(sizeof rel>length-at)return false;memcpy(rel,bytes+at,sizeof rel);at+=sizeof rel;S80_TAKE(attributes,unsigned char,12448);
#undef S80_TAKE
 if(length-at<72)return false;uint32_t voice[18];memcpy(voice,bytes+at,72);at+=72;
 if(voice[0]!=0x3031564b||voice[1]!=4)return false;uint32_t voiceCursor=0;
 for(unsigned i=0;i<4;i++){const unsigned p=2+i*4,rate=voice[p],size=voice[p+1],offset=voice[p+2];if(rate<8000||rate>48000||!size||size%2||size>rate*2*10||offset!=voiceCursor||voice[p+3]!=i||offset>length-at||size>length-at-offset)return false;r->voiceRate100[i]=rate;r->voiceBytes100[i]=size;r->voicePcm100[i]=bytes+at+offset;voiceCursor+=size;}
 if(at+voiceCursor!=length)return false;
 for(unsigned i=0;i<r->vertices;i++){
  unsigned sum=0;for(unsigned k=0;k<4;k++){unsigned weight=r->weights[i*4+k];sum+=weight;if(weight&&r->joints[i*4+k]>=r->paletteCount)return false;}
  if(sum!=255||r->materials[i]>=18)return false;
 }
 for(unsigned i=0;i<r->paletteCount;i++)if(r->palette[i]>=79)return false;
 for(unsigned i=0;i<48;i++){if(!r->clips[i].count||r->clips[i].first>=r->frames||r->clips[i].count>r->frames-r->clips[i].first||(r->clips[i].timePerKey!=100&&!((i>=8&&i<=11)&&r->clips[i].timePerKey==75))||r->clips[i].count!=(r->clips[i].keys-1)*2+1)return false;}
 const float *arrays[]={r->position,r->uv,r->bind,r->root,r->pose};const size_t counts[]={r->vertices*3,r->vertices*2,r->bindCount*3,r->frames*3,r->frames*79*16};
 for(unsigned a=0;a<5;a++)for(size_t i=0;i<counts[a];i++)if(!isfinite(arrays[a][i])||fabsf(arrays[a][i])>1000000)return false;
 for(unsigned i=0;i<r->frames*79;i++){const float *m=r->pose+i*16;if(fabsf(m[3])>.0001f||fabsf(m[7])>.0001f||fabsf(m[11])>.0001f||fabsf(m[15]-1)>.0001f)return false;}
 for(unsigned i=0;i<71;i++){uint32_t value=0,high=0;if(rel[i]>12440||rel[i]%8)return false;for(unsigned j=0;j<i;j++)if(rel[j]==rel[i])return false;memcpy(&value,r->attributes+rel[i],4);memcpy(&high,r->attributes+rel[i]+4,4);if(high||(value>>22)!=61||(value&0x3fffff)>=12448)return false;snPointer(r->attributes,rel[i],r->attributes+(value&0x3fffff));}
 // Split indexed triangles into bounded private GL batches.
 for(unsigned material=0;material<18;material++){
  SluaghBatch80 *batch=NULL;int *mapping=HeapAlloc(GetProcessHeap(),0,r->vertices*sizeof(int));if(!mapping)return false;
  for(unsigned i=0;i<r->vertices;i++)mapping[i]=-1;
  for(unsigned triangle=0;triangle<r->indexCount;triangle+=3){
   const uint16_t *v=r->indices+triangle;if(v[0]>=r->vertices||v[1]>=r->vertices||v[2]>=r->vertices){HeapFree(GetProcessHeap(),0,mapping);return false;}
   if(r->materials[v[0]]!=r->materials[v[1]]||r->materials[v[0]]!=r->materials[v[2]]){HeapFree(GetProcessHeap(),0,mapping);return false;}
   if(r->materials[v[0]]!=material)continue;unsigned added=0;for(unsigned k=0;k<3;k++)if(mapping[v[k]]<0)added++;
   if(!batch||batch->vertices+added>2048||batch->indices+3>8192){
    if(r->batchCount>=64){HeapFree(GetProcessHeap(),0,mapping);return false;}batch=&r->batches[r->batchCount++];batch->texture=material;
    for(unsigned i=0;i<r->vertices;i++)mapping[i]=-1;
   }
   for(unsigned k=0;k<3;k++){if(mapping[v[k]]<0){mapping[v[k]]=(int)batch->vertices;batch->source[batch->vertices++]=v[k];}batch->index[batch->indices++]=(uint16_t)mapping[v[k]];}
  }HeapFree(GetProcessHeap(),0,mapping);
 }
 sluaghResources80=*r;return true;
}
static bool sluaghParse80(unsigned char *bytes,uint32_t length){
 SluaghResources80 *staged=HeapAlloc(GetProcessHeap(),HEAP_ZERO_MEMORY,sizeof(*staged));if(!staged)return false;
 const bool ok=sluaghParseInner92(bytes,length,staged);HeapFree(GetProcessHeap(),0,staged);return ok;
}
static void sluaghNavigation80(void *instance,void *destination,int stream,unsigned char flying){
 (void)stream;
 if(instance!=sluagh80.ai.actor)return;
 SluaghNativeAI *n=&sluagh80.ai;uint32_t flags=snU32(n->state,0x3e8)&~0x1000000u;
 float from[3];int16_t to[3];const float *goal=destination;
 float grounded105[3];if(!flying&&kainProjectNavigation105(goal,grounded105)){goal=grounded105;static uint64_t last105;const uint64_t now105=GetTickCount64();if(now105-last105>=1000){last105=now105;record("kain105 navigation-ground-goal requested-z=%.1f ground-z=%.1f",((const float*)destination)[2],goal[2]);}}
 for(unsigned k=0;k<3;k++){from[k]=snFloat(n->actor,0x20+k*4);if(!isfinite(goal[k])||goal[k]<INT16_MIN||goal[k]>INT16_MAX){snSetU32(n->state,0x3e8,flags);return;}to[k]=(int16_t)lroundf(goal[k]);}
 // Both world coordinates use native Z-up units; raise the visibility segment.
 from[2]+=128;to[2]=(int16_t)(to[2]+128);
 if(localNativeLineClear(sluagh80.actor,sluagh80.world,from,to)||kainNavigation102((const float*)(n->actor+0x20),goal)){memcpy(n->state+0x80,goal,12);flags|=0x1000000u;}
 else {static uint64_t last105;const uint64_t now105=GetTickCount64();if(now105-last105>=1000){last105=now105;record("kain105 navigation-refused from=%.1f/%.1f/%.1f goal=%.1f/%.1f/%.1f mode=%u",snFloat(n->actor,0x20),snFloat(n->actor,0x24),snFloat(n->actor,0x28),goal[0],goal[1],goal[2],n->mode);}}
 snSetU32(n->state,0x3e8,flags);
}
static DWORD WINAPI sluaghResourceWorker80(void *unused){
 (void)unused;wchar_t name[128];swprintf(name,128,L"\\\\.\\pipe\\SR1KainResource92-%lu",GetCurrentProcessId());
 HANDLE pipe=CreateNamedPipeW(name,PIPE_ACCESS_INBOUND|FILE_FLAG_FIRST_PIPE_INSTANCE,PIPE_TYPE_BYTE|PIPE_READMODE_BYTE|PIPE_WAIT|PIPE_REJECT_REMOTE_CLIENTS,1,4096,65536,0,NULL);
 if(pipe==INVALID_HANDLE_VALUE)return 0;
 bool connected=ConnectNamedPipe(pipe,NULL)||GetLastError()==ERROR_PIPE_CONNECTED;uint32_t count=0;unsigned char *data=NULL;
 if(connected&&sluaghResourceRead80(pipe,&count,4)&&count>48&&count<32*1024*1024){data=HeapAlloc(GetProcessHeap(),0,count);if(data&&(!sluaghResourceRead80(pipe,data,count)||!sluaghParse80(data,count))){HeapFree(GetProcessHeap(),0,data);data=NULL;}}
 DisconnectNamedPipe(pipe);CloseHandle(pipe);if(!data)return 0;
 wchar_t configPath[1400],exeBuffer[1025]={0};char digest[65];
 swprintf(configPath,ARRAYSIZE(configPath),L"%ls/defiance-exe.txt",portableReports60);
 HANDLE pathFile=CreateFileW(configPath,GENERIC_READ,FILE_SHARE_READ,NULL,OPEN_EXISTING,FILE_ATTRIBUTE_NORMAL,NULL);
 if(pathFile==INVALID_HANDLE_VALUE)return 0;
 const DWORD pathBytes=GetFileSize(pathFile,NULL);DWORD pathRead=0;
 const bool pathValid=pathBytes>=4&&pathBytes<=2048&&!(pathBytes&1)&&ReadFile(pathFile,exeBuffer,pathBytes,&pathRead,NULL)&&pathRead==pathBytes;
 CloseHandle(pathFile);if(!pathValid)return 0;
 const wchar_t *exe=exeBuffer[0]==0xfeff?exeBuffer+1:exeBuffer;
 if(!*exe||wcslen(exe)!=(size_t)(pathBytes/2-(exe!=exeBuffer)))return 0;
 if(!hashFile(exe,digest)||strcmp(digest,"fc6a406ff7ac9b5eb7788dc7a65d335e1c1aad9236618112671975b71d2daddc"))return 0;
 HMODULE module=LoadLibraryExW(exe,NULL,0);if(!module)return 0;sluaghResources80.module=(uintptr_t)module;if(!snOutputs92((uintptr_t)module))return 0;
 if(MH_CreateHook((char*)module+0xac970,sluaghNavigation80,NULL)!=MH_OK||MH_EnableHook((char*)module+0xac970)!=MH_OK)return 0;
 HANDLE voiceThread100=CreateThread(NULL,0,kainVoiceWorker100,NULL,0,NULL);if(voiceThread100)CloseHandle(voiceThread100);else return 0;
 record("kain92 RAM-ready vertices=%u clips=%u frames=%u batches=%u standalone-native-AI=1",sluaghResources80.vertices,sluaghResources80.clipCount,sluaghResources80.frames,sluaghResources80.batchCount);
 InterlockedExchange(&sluaghReady80,1);return 0;
}
static void kainClearMotion97(void);
static bool sluaghMember80(void){
 uintptr_t list=0,node=0;if(!sluagh80.actor||!readAt(base+contactPolicy->listRva,&list,8)||!list||!readAt(list+8,&node,8))return false;
 for(unsigned i=0;node&&i<512;i++){if(node==sluagh80.actor){uintptr_t object=0;return sluaghOwned80(node)&&readAt(node+0x30,&object,8)&&object==sluagh80.object;}if(!readAt(node+0x10,&node,8))return false;}return false;
}
#include "boss-air95.h"
#include "boss-voice100.h"
#include "boss-player96.h"
#include "boss-force94.h"
static void kainClearBeam100(void);
static bool kainSaveCurrent93(void){
 if(!sluaghMember80())return kainEncounter93.saved;uintptr_t data=0;int16_t hp=0,position[3];
 if(!readAt(sluagh80.actor+0x2c0,&data,8)||!data||!readAt(data+contactPolicy->healthOffset,&hp,2)||!readAt(sluagh80.actor+0x9c,position,6))return kainEncounter93.saved;
 if(sluagh80.airborne86)position[2]=(int16_t)lroundf(sluagh80.groundZ86);if(sluagh80.airPursuit95)position[2]=(int16_t)lroundf(kainAir95.floor);uint64_t phase=0;memcpy(&phase,sluagh80.ai.state+0x818,8);
 kainRemember93(&kainEncounter93,sluagh80.player,sluagh80.playerGeneration,GetCurrentProcessId(),sluagh80.world,hp,sluagh80.maxHp,position,sluagh80.yaw,phase,snFloat(sluagh80.ai.state,0x444),sluagh80.ai.cooldowns);kainEncounter93.bladeCharge96=sluagh80.ai.bladeCharge96;kainEncounter93.lastTelekinesis98=sluagh80.ai.lastTelekinesis98;kainEncounter93.yellowCharge100=sluagh80.yellowCharge100;return kainEncounter93.saved;
}
#include "story108.h"
#include "training109.h"
static void sluaghCleanup80(void){
 if(!kainKeep93&&!kainStory108.committed)kainStatusRestore114();
 memset(&kainPush114,0,sizeof kainPush114);
 kainStoryFailure108();
 kainClearBeam100();kainVoiceCancel100();
 kainClearPlayer96();
 kainClearForce94();
 kainClearMotion97();
 kainAirClear95();
 if(!kainKeep93){kainEncounter93.saved=false;kainRestore93=false;}
 AcquireSRWLockExclusive(&sluaghRenderLock80);sluagh80.render=false;ReleaseSRWLockExclusive(&sluaghRenderLock80);
 if(sluaghMember80()){uintptr_t list=0;if(readAt(base+contactPolicy->listRva,&list,8))((void(*)(uintptr_t,uintptr_t,int))(base+0x7a840))(list,sluagh80.actor,0);}
 if(sluagh80.pinned){uintptr_t object=0;int16_t users=0;if(readAt(sluagh80.tracker+0x10,&object,8)&&object==sluagh80.object&&readAt(sluagh80.tracker+0x1a,&users,2)&&users>0){users--;memcpy((void*)(sluagh80.tracker+0x1a),&users,2);}}
 memset(&sluagh80,0,sizeof sluagh80);record("kain92 cleanup owned-only=1");
}
static void kainScenePause118(void){
 if(!InterlockedCompareExchange(&portableActive60,0,0)||!kainStory108.player||kainStory108.committed||!kainCinematic118())return;
 if(sluagh80.player){
  const bool saved=kainSaveCurrent93();
  if(!saved)kainStory108.pending=false;
  kainKeep93=true;sluaghCleanup80();kainKeep93=false;
 }
 InterlockedExchange(&sluaghCommand80,0);
 kainStoryRestore108();
 if(!kainStory108.cinemaPaused118)record("kain118 cinematic-paused original-restored=1 boss-hp=%d outputs-cleared=1",kainEncounter93.hp);
 kainStory108.cinemaPaused118=true;
}
static bool kainTransientRonin118(uintptr_t actor,uintptr_t object){
 // Birth76500: dynamic name, no authored intro, flag2. Both authored room
 // placement tables contain zero Ronins. Never match an authored enemy.
 uintptr_t actual=0,intro=1,commands=1,parent=1;uint32_t world=0,id=0,flags=0;char name[16]={0};
 return actor&&actor!=sluagh80.actor&&object&&generation(actor)&&
  readAt(actor+0x30,&actual,8)&&actual==object&&readAt(actor+0x60,&world,4)&&(world==31442||world==31451)&&
  readAt(actor+0x64,&id,4)&&id!=4674&&readAt(actor+0x24,&flags,4)&&(flags&2)&&
  readAt(actor+0x38,&intro,8)&&!intro&&readAt(actor+0x48,&commands,8)&&!commands&&
  readAt(actor+0x50,&parent,8)&&!parent&&readAt(actor+0x2b0,name,sizeof name)&&!strcmp(name,"ronin");
}
static bool sluaghTracker80(uintptr_t *,uintptr_t *);
static void kainTransientSweep118(void){
 if(!kainStory108.player||kainStory108.committed||(!kainStory108.owned&&!kainStory108.pending)||kainCinematic118())return;
 uintptr_t tracker=0,object=0,list=0,node=0;
 if(!sluaghTracker80(&tracker,&object)||!readAt(base+contactPolicy->listRva,&list,8)||!list||!readAt(list+8,&node,8))return;
 unsigned removed=0;
 for(unsigned i=0;node&&i<512;i++){
  uintptr_t next=0;if(!readAt(node+0x10,&next,8))break;
  if(kainTransientRonin118(node,object)){
   const uint32_t gen=generation(node);uint32_t id=0;readAt(node+0x64,&id,4);
   if(kainStoryMember108(node,gen)&&kainTransientRonin118(node,object)){
    ((void(*)(uintptr_t,uintptr_t,int))(base+0x7a840))(list,node,0);removed++;
    record("kain118 transient-ronin-removed generation=%u intro=%u authored=0",gen,id);
   }
  }node=next;
 }if(removed)record("kain118 transient-sweep removed=%u current-proxy-retained=1",removed);
}
static void sluaghInit80(uintptr_t actor){
 uintptr_t object=0,parent=0;
 if(sluagh80.initializing&&!sluagh80.initialized&&readAt(actor+0x30,&object,8)&&object==sluagh80.object&&readAt(actor+0x50,&parent,8)&&parent==sluagh80.player){
  const uintptr_t zero=0;for(unsigned i=0;i<3;i++)memcpy((void*)(actor+(i==0?0x38:i==1?0x48:0x50)),&zero,8);
  for(unsigned i=0;i<3;i++){
   const float position=sluagh80.spawn[i],rotation=0,scale=4096;memcpy((void*)(actor+0xa4+i*4),&position,4);memcpy((void*)(actor+0xb8+i*4),&position,4);
   memcpy((void*)(actor+0xd8+i*4),&rotation,4);memcpy((void*)(actor+0xf0+i*4),&rotation,4);memcpy((void*)(actor+0x108+i*4),&scale,4);
  }
  memcpy((void*)(actor+0x9c),sluagh80.spawn,6);memcpy((void*)(actor+0xb2),sluagh80.spawn,6);memcpy((void*)(actor+0xc8),sluagh80.spawn,6);
  const int16_t rotation[4]={0},scale[3]={4096,4096,4096};memcpy((void*)(actor+0xce),rotation,8);memcpy((void*)(actor+0xe8),rotation,8);memcpy((void*)(actor+0x100),scale,6);
  uint32_t flags=0;readAt(actor+0x28,&flags,4);flags=hyldenMaterialFlags90(flags);memcpy((void*)(actor+0x28),&flags,4);sluagh80.initialized=true;
 }sluaghOriginalInit80(actor);
}
static void sluaghQueue80(uintptr_t actor){
 // Original generic message processing retains hit/stun/death authority.
 ((void(*)(uintptr_t))(base+0xa04f0))(actor);
}
static void sluaghLandingUpdate87(uintptr_t actor){
 uint32_t state=0,flags=0;uintptr_t data=0;int16_t hp=0;
 // Native animation processing replaces the one-frame completion flags before
 // this callback. Deliver the finished Defiance keylist at the real consumer.
 if(sluaghOwned80(actor)&&sluagh80.endAck86&&sluagh80.reaction86==41&&
  readAt(actor+0x2f0,&state,4)&&readAt(actor+0x2c0,&data,8)&&data&&readAt(data+contactPolicy->healthOffset,&hp,2)&&
  snRecoveryEnd86(state,hp,sluagh80.airborne86,true,true)&&readAt(actor+0x28,&flags,4)){
  flags|=0x10u;memcpy((void*)(actor+0x28),&flags,4);
  if(!sluagh80.endDelivered87){sluagh80.endDelivered87=true;record("kain92 landing-end delivered-at-native-update=1");}
 }
 sluaghOriginalLanding87(actor);
}
static uintptr_t sluaghStatePair80(uintptr_t actor,uint32_t state){
 const uintptr_t pair=sluaghOriginalLookup80(actor,state);
 if(!sluaghOwned80(actor)||state>=32)return pair;
 // Native SR1 pursuit/idle/wander/attack/combat choices are suppressed only
 // for our proxy. Reaction, flight, stun, death and soul callbacks stay native.
 if(state==1||state==2||state==5||state==6||state==7||state==12||state==13||state==25||state==26){
  sluaghPairs80[state][0]=(uintptr_t)sluaghQueue80;sluaghPairs80[state][1]=(uintptr_t)sluaghQueue80;return (uintptr_t)sluaghPairs80[state];
 }return pair;
}
static bool sluaghTracker80(uintptr_t *tracker,uintptr_t *object){
 uintptr_t array=0;if(!readAt(base+44602192,&array,8)||!array)return false;
 for(unsigned i=0;i<48;i++){char name[17]={0};int16_t status=0;uintptr_t at=array+i*56;if(!readAt(at,name,16)||!readAt(at+24,&status,2))return false;if(status==2&&!strcmp(name,"ronin")&&readAt(at+16,object,8)&&*object){*tracker=at;return true;}}return false;
}
static bool sluaghAnimationReady80(uintptr_t object){
 uint32_t flags=0;int16_t count=0;uintptr_t animations=0;
 if(!readAt(object+0x48,&flags,4)||(flags&0x10000000u)||!readAt(object+10,&count,2)||count<1||count>4096||!readAt(object+24,&animations,8)||!animations)return false;
 for(int i=0;i<count;i++){uintptr_t key=0;uint32_t magic=0;if(!readAt(animations+i*8,&key,8)||!key||!readAt(key,&magic,4)||magic==0x0face0ffu)return false;}return true;
}
static void sluaghSample80(unsigned clip,float time,float matrices[1264],float root[3]){
 const SluaghResources80 *r=&sluaghResources80;const SluaghClip80 c=r->clips[clip];float sample=fmaxf(0,fminf(time/(c.timePerKey*.5f),(float)c.count-1));unsigned a=(unsigned)sample,b=a+1<c.count?a+1:a;float weight=sample-a;
 for(unsigned k=0;k<1264;k++){float x=r->pose[(c.first+a)*1264+k],y=r->pose[(c.first+b)*1264+k];matrices[k]=x+(y-x)*weight;}
 for(unsigned k=0;k<3;k++){float x=r->root[(c.first+a)*3+k],y=r->root[(c.first+b)*3+k];root[k]=x+(y-x)*weight;}
}
static void sluaghRootMotion80(unsigned clip,float from,float interval,float output[3]){
 memset(output,0,12);const SluaghClip80 c=sluaghResources80.clips[clip];float cursor=from,remaining=fminf(interval,fmaxf(0,(c.keys-1)*c.timePerKey-from));
 while(remaining>0){const float nextKey=(floorf(cursor/c.timePerKey)+1)*c.timePerKey,step=fminf(remaining,nextKey-cursor);float root[3],scratch[1264];sluaghSample80(clip,cursor,scratch,root);for(unsigned k=0;k<3;k++)output[k]+=root[k]*step/c.timePerKey;cursor+=step;remaining-=step;}
}
static float kainSoleOffset95(const float pose[1264]){
 const SluaghResources80 *r=&sluaghResources80;float minimum=INFINITY;
 for(unsigned v=0;v<r->vertices;v++){if(r->materials[v]>=16)continue;float z=0;
  for(unsigned j=0;j<4;j++){unsigned weight=r->weights[v*4+j];if(!weight)continue;unsigned bone=r->palette[r->joints[v*4+j]];const float *m=pose+bone*16;
   float x=r->position[v*3]+r->bind[bone*3],y=r->position[v*3+1]+r->bind[bone*3+1],height=r->position[v*3+2]+r->bind[bone*3+2];z+=(m[2]*x+m[6]*y+m[10]*height+m[14])*weight/255.f;
  }minimum=fminf(minimum,z);
 }return kainSoleCorrection95(minimum);
}
#include "boss-motion97.h"
static bool kainNavigation102(const float *current,const float *goal){
 const float dx=goal[0]-current[0],dy=goal[1]-current[1],length=hypotf(dx,dy);if(!isfinite(length)||length<1||length>8000||!isfinite(goal[2])||fabsf(goal[2]-current[2])>768||fabsf(current[2])+kainPolicy102->navVisibilityHeight>31500||fabsf(goal[2])+kainPolicy102->navVisibilityHeight>31500)return false;
 const float from[3]={current[0],current[1],current[2]+kainPolicy102->navVisibilityHeight};int16_t to[3]={(int16_t)lroundf(goal[0]),(int16_t)lroundf(goal[1]),(int16_t)lroundf(goal[2]+kainPolicy102->navVisibilityHeight)};
 if(!localNativeLineClear(sluagh80.actor,sluagh80.world,from,to))return false;
 const float step=fminf(60,length);int16_t root[3],next[3];for(unsigned k=0;k<3;k++)root[k]=(int16_t)lroundf(current[k]);
 const bool safe=kainStepPlan97(root,dx*step/length,dy*step/length,next);kainMotion97.floorValid=false;
 if(safe)record("kain102 navigation-step accepted=1 visibility=%lld",(long long)kainPolicy102->navVisibilityHeight);return safe;
}
#include "boss-beam100.h"
#include "boss-fall101.h"
#include "native-physics104.h"
#include "native-fly106.h"
static bool sluaghMove80(float dx,float dy){
 int16_t current[3],next[3];if(!readAt(sluagh80.actor+0x9c,current,6))return false;
 const unsigned segments=(unsigned)ceilf(hypotf(dx,dy)/60.f);if(segments>32)return false;if(!segments)return true;
 for(unsigned i=0;i<segments;i++){if(!kainStepPlan97(current,dx/segments,dy/segments,next)){
   bool around=false;if(!kainMotion97.dash)for(unsigned side=0;side<2&&!around;side++){const float angle=(side?-.78539816339f:.78539816339f),c=cosf(angle),s=sinf(angle);around=kainStepPlan97(current,(c*dx-s*dy)/segments,(s*dx+c*dy)/segments,next);}
   if(!around){sluagh80.moveBlocked++;return false;}record("kain100 edge-slide supported=1 walls-retained=1");
  }
  if(abs(next[2]-current[2])>4)record("kain97 terrain-step dz=%d dash=%u",next[2]-current[2],kainMotion97.dash);
  ((void(*)(uintptr_t,const int16_t*,int))(base+0x117810))(sluagh80.actor,next,0);memcpy(current,next,6);sluagh80.moveAccepted++;
 }
 for(unsigned k=0;k<3;k++)sluagh80.precise[k]=current[k];sluagh80.preciseValid=true;return true;
}
static void sluaghQueueMove80(float dx,float dy){
 if(!isfinite(dx)||!isfinite(dy)||fabsf(dx)>200||fabsf(dy)>200)return;
 sluagh80.pendingMove[0]+=dx;sluagh80.pendingMove[1]+=dy;sluagh80.pendingMoveTick=GetTickCount64();
}
static void sluaghAfterCollision80(uintptr_t actor,uintptr_t tracker){
 sluaghOriginalAdditional80(actor,tracker);const DWORD error=GetLastError();
 if(sluaghOwned80(actor)&&!kainCinematic118()){
  const float dx=sluagh80.pendingMove[0],dy=sluagh80.pendingMove[1];const uint64_t issued=sluagh80.pendingMoveTick,now=GetTickCount64();
  sluagh80.pendingMove[0]=sluagh80.pendingMove[1]=0;sluagh80.pendingMoveTick=0;
  uintptr_t state=0;int16_t hp=0;uint32_t world=0,playerWorld=0;
  if(issued&&now>=issued&&now-issued<=100&&InterlockedCompareExchange(&portableActive60,0,0)&&
   readAt(actor+0x60,&world,4)&&world==sluagh80.world&&readAt(sluagh80.player+0x60,&playerWorld,4)&&playerWorld==world&&readAt(actor+0x2c0,&state,8)&&state&&readAt(state+contactPolicy->healthOffset,&hp,2)&&hp>0&&fabsf(dx)<=(kainMotion97.dash?1600:200)&&fabsf(dy)<=(kainMotion97.dash?1600:200)){
   sluaghMove80(dx,dy);
  }
 }
 SetLastError(error);
}
static void sluaghFrame80(void){
 const bool active=InterlockedCompareExchange(&portableActive60,0,0)!=0;bool down=(GetAsyncKeyState(VK_F11)&0x8000)!=0;static bool held;DWORD focus=0;GetWindowThreadProcessId(GetForegroundWindow(),&focus);
 if(down&&!held&&focus==GetCurrentProcessId())InterlockedExchange(&sluaghCommand80,1);held=down;
 uintptr_t actor=0;readAt(base+host->actorRva,&actor,8);Sr1LocalFrame frame=readLocalFrame(true);const uint64_t now=GetTickCount64();
 uint32_t actualWorld=0,actualRealm=0;if(actor)readAt(actor+0x60,&actualWorld,4);readAt(base+44600604,&actualRealm,4);
 kainStoryPoll108(active,actor,actualWorld);
 kainScenePause118();
 if(active&&kainCinematic118())return; // no queued force, player hold or AI tick
 if(kainStory108.cinemaPaused118){
  kainStory108.cinemaPaused118=false;
  record("kain118 cinematic-released saved=%u hp=%d",kainEncounter93.saved,kainEncounter93.hp);
 }
 kainStoryJoin109(&frame,actor,now);
 kainTransientSweep118();
 kainPollForce94(&frame,now);
 kainAirPoll95(&frame,now);
 kainPollPlayer96(&frame,now);
 kainFallFrame101(&frame,now);
 if(!frame.ready&&kainBeamBusy102())kainAbortBeam102(now,false);
 if(!active||!actor||actualRealm==0){if(!kainShortcutWaiting113()){kainEncounter93.saved=false;kainRestore93=false;}if(sluagh80.player)sluaghCleanup80();return;}
 if(kainEncounter93.saved&&!kainSameEncounter93(&kainEncounter93,actor,generation(actor),GetCurrentProcessId())){kainEncounter93.saved=false;kainRestore93=false;}
 if(sluagh80.player&&(actor!=sluagh80.player||generation(actor)!=sluagh80.playerGeneration||(sluagh80.loading&&actualWorld!=sluagh80.world))){sluaghCleanup80();return;}
 if(sluagh80.player&&actualRealm!=1){if(kainPlayer96.fatal113)return;kainStatus114.refill=true;kainKeep93=kainSaveCurrent93();if(kainKeep93)record("kain93 suspended world=%u hp=%d",kainEncounter93.world,kainEncounter93.hp);sluaghCleanup80();kainKeep93=false;return;}
 if(kainPlayer96.fatal113)return;
 const bool resume93=!sluagh80.player&&kainCanResume93(&kainEncounter93,actor,generation(actor),GetCurrentProcessId(),actualWorld,actualRealm,active,frame.ready&&frame.grounded&&kainGameplayReady113(&frame));
 if(resume93){kainRestore93=true;InterlockedCompareExchange(&sluaghCommand80,1,0);}

 if(sluagh80.actor){
  if(!sluaghMember80()){record("kain92 native-actor-removed");kainKeep93=kainEncounter93.saved;sluaghCleanup80();kainKeep93=false;return;}
  uint32_t enemyWorld=0;uintptr_t terrain=0,unit=0;
  if(readAt(sluagh80.actor+0x60,&enemyWorld,4))unit=((uintptr_t(*)(int32_t))(base+contactPolicy->streamRva))((int32_t)enemyWorld);
  if(!unit||!readAt(unit,&terrain,8)||!terrain){record("kain92 native-stream-unloaded");kainSaveCurrent93();kainKeep93=kainEncounter93.saved;sluaghCleanup80();kainKeep93=false;return;}
  sluagh80.world=enemyWorld;
 }
 if(InterlockedExchange(&sluaghCommand80,0)){
  if(sluagh80.player){sluaghCleanup80();return;}
  if(!active||!InterlockedCompareExchange(&sluaghReady80,0,0)||!frame.ready||!frame.grounded||(!kainGameplayReady113(&frame)&&!(kainStorySpawn108()&&frame.nativeControl))||frame.realm!=1){record("kain92 request-refused active=%u resources=%ld ready=%u grounded=%u realm=%u",active,sluaghReady80,frame.ready,frame.grounded,frame.realm);if(kainStorySpawn108())InterlockedCompareExchange(&sluaghCommand80,1,0);return;}
  sluagh80.player=actor;sluagh80.playerGeneration=generation(actor);sluagh80.world=frame.worldGeneration;sluagh80.loading=true;sluagh80.requested=now;
  int16_t p[3];uint16_t yaw=0;readAt(actor+0x9c,p,6);readAt(actor+0xd2,&yaw,2);float angle=yaw*6.28318530718f/4096.f;
  float wanted[3]={0};bool placement=false;
  if(kainRestore93){for(unsigned k=0;k<3;k++)wanted[k]=kainEncounter93.position[k];placement=true;}
  else if(kainStorySpawn108()){for(unsigned k=0;k<3;k++)wanted[k]=kainStory108.center[k];placement=true;}
  for(unsigned attempt=0;attempt<12&&!placement;attempt++){
   const float distance=1000.f-(attempt/4)*250.f,bearing=angle+(attempt%4)*1.57079632679f;
   wanted[0]=p[0]-sinf(bearing)*distance;wanted[1]=p[1]+cosf(bearing)*distance;wanted[2]=p[2]+64.f;
   if(wanted[0]<-32000||wanted[0]>32000||wanted[1]<-32000||wanted[1]>32000||wanted[2]<-31500||wanted[2]>31500)continue;
   const float from[3]={p[0],p[1],p[2]+128.f},top[3]={wanted[0],wanted[1],p[2]+256.f};const int16_t to[3]={(int16_t)wanted[0],(int16_t)wanted[1],(int16_t)(p[2]+128)},bottom[3]={(int16_t)wanted[0],(int16_t)wanted[1],(int16_t)(p[2]-512)};
   placement=localNativeLineClear(actor,sluagh80.world,from,to)&&!localNativeLineClear(actor,sluagh80.world,top,bottom);
  }
  if(!placement){record("kain92 no-safe-placement");sluaghCleanup80();return;}
  for(unsigned i=0;i<3;i++){if(wanted[i]<-32000||wanted[i]>32000){sluaghCleanup80();return;}sluagh80.spawn[i]=(int16_t)lroundf(wanted[i]);}
  record("kain92 spawn-request realm=1 stream=%u xyz=%d,%d,%d",sluagh80.world,sluagh80.spawn[0],sluagh80.spawn[1],sluagh80.spawn[2]);
 }
 // Feeding deliberately suspends borrowed Raziel poses. It must not suspend
 // an existing ghost's native lifetime/presentation while it is being eaten.
 if(!sluagh80.player||!frame.ready||(!frame.renderBlend&&!(frame.nativeControl&&(kainStorySpawn108()||kainStory108.owned||(sluagh80.actor&&sluagh80.hp<=0)))&&!kainPlayerBusy97(sluagh80.player,now)))return;
 if(sluagh80.loading){
  if(now-sluagh80.requested>30000){record("kain92 model-timeout");sluaghCleanup80();return;}
  uintptr_t tracker=0,object=0;if(!sluaghTracker80(&tracker,&object)){if(!sluagh80.initializing){((uintptr_t(*)(const char*))(base+0x115b40))("ronin");sluagh80.initializing=true;}return;}
  if(!sluagh80.pinned){int16_t users=0;if(!readAt(tracker+0x1a,&users,2)||users<0||users>32765){sluaghCleanup80();return;}users++;memcpy((void*)(tracker+0x1a),&users,2);sluagh80.pinned=true;sluagh80.tracker=tracker;sluagh80.object=object;}
  uint32_t flags=0;readAt(object+0x48,&flags,4);if(flags&0x10000000u){((void(*)(uintptr_t))(base+0xb7a10))(tracker);return;}
  if(!sluaghAnimationReady80(object))return;
  if(!kainCapacityReady110(now))return;
  sluagh80.initializing=true;sluagh80.initialized=false;uintptr_t born=((uintptr_t(*)(uintptr_t,uintptr_t,int))(base+0x76500))(actor,object,0);sluagh80.initializing=false;
  sluagh80.actor=born;sluagh80.generation=generation(born);sluagh80.loading=false;
  if(!born||!sluagh80.initialized||!sluaghMember80()){record("kain92 birth-refused");sluaghCleanup80();return;}
  uintptr_t state=0;readAt(born+0x2c0,&state,8);if(!state||!readAt(state+600,&sluagh80.hp,2)){sluaghCleanup80();return;}const int16_t bossHealth92=kainRestore93?kainEncounter93.hp:30000;memcpy((void*)(state+600),&bossHealth92,2);sluagh80.hp=bossHealth92;sluagh80.maxHp=kainRestore93?kainEncounter93.maximum:30000;kainDeath92=kainGrabTick92=0;kainGrabSeen92=kainDamageSeen92=kainFxSeen92=0;
  if(!snInit(&sluagh80.ai,sluaghResources80.module,sluaghResources80.attributes)){sluaghCleanup80();return;}if(kainRestore93){sluagh80.ai.bladeCharge96=kainEncounter93.bladeCharge96;sluagh80.ai.lastTelekinesis98=kainEncounter93.lastTelekinesis98;sluagh80.yellowCharge100=kainEncounter93.yellowCharge100;snWorld(&sluagh80.ai,(float[3]){sluagh80.spawn[0],sluagh80.spawn[1],sluagh80.spawn[2]},(float[3]){0,0,0},bossHealth92*(5000.f/sluagh80.maxHp),5000);snSetFloat(sluagh80.ai.actor,0x48,kainEncounter93.yaw/6.28318530718f);memcpy(sluagh80.ai.state+0x818,&kainEncounter93.phase,8);memcpy(sluagh80.ai.cooldowns,kainEncounter93.cooldowns,sizeof sluagh80.ai.cooldowns);snSetFloat(sluagh80.ai.state,0x444,kainEncounter93.behaviorTimer);snCancel(&sluagh80.ai);sluagh80.yaw=kainEncounter93.yaw;record("kain93 resumed world=%u hp=%d/%d",sluagh80.world,bossHealth92,sluagh80.maxHp);kainRestore93=false;}
  sluagh80.clip=sluagh80.ai.clip;sluagh80.lastTick=now;
  if(!kainStoryBorn108()){sluaghCleanup80();return;}
  kainStatusFill114();record("kain92 spawned generation=%u native-hp=%d standalone=1 effective-max-hp=120000",sluagh80.generation,sluagh80.hp);return;
 }
 if(!sluaghMember80()){record("kain92 native-actor-removed");sluaghCleanup80();return;}
 // Combat eligibility excludes dying/sucked actors. Presentation must follow
 // the same owned generation through its native soul lifetime.
 LocalTarget target={.actor=sluagh80.actor,.generation=sluagh80.generation};
 const bool contactEligible=localReadContactTarget(sluagh80.actor,sluagh80.world,&target);
 if(!contactEligible&&(!readAt(target.actor+0x2c0,&target.state,8)||!target.state||!readAt(target.state+contactPolicy->healthOffset,&target.hp,2)||!readAt(target.actor+contactPolicy->stateOffset,&target.mainState,4)))return;
 int32_t playerHealth=0;if(readAt(base+0x2a88cd0,&playerHealth,4)&&playerHealth!=sluagh80.playerHealth){if(playerHealth<sluagh80.playerHealth||playerHealth-sluagh80.playerHealth>=1000)record("kain92 player-hp before=%d after=%d victim-hp=%d state=%u",sluagh80.playerHealth,playerHealth,target.hp,target.mainState);sluagh80.playerHealth=playerHealth;}
 if(target.hp>sluagh80.hp&&sluagh80.hp>0){const int16_t retained92=sluagh80.hp;uintptr_t data92=0;if(readAt(target.actor+0x2c0,&data92,8)&&data92){memcpy((void*)(data92+contactPolicy->healthOffset),&retained92,2);target.hp=retained92;}}
 if(target.hp!=sluagh80.hp){record("kain92 native-hp generation=%u before=%d after=%d state=%u",sluagh80.generation,sluagh80.hp,target.hp,target.mainState);if(target.hp<sluagh80.hp){sluagh80.airHit94=sluagh80.airborne86;if(target.hp>0&&!snHit95(&sluagh80.ai,target.mainState!=11&&!sluagh80.airborne86&&!sluagh80.airPursuit95,snFloat(sluagh80.ai.target,0x10)<0?-1:1)){record("kain92 native-hit-reaction-refused");sluaghCleanup80();return;}sluagh80.hurt86=true;sluagh80.hitActive=false;}sluagh80.hp=target.hp;}
 if(target.hp<=0&&kainStoryDefeat108())return;
 if(kainPushPoll114(now))return;
 const uint64_t elapsed98=now-sluagh80.lastTick;sluagh80.maximumGap98=elapsed98>sluagh80.maximumGap98?elapsed98:sluagh80.maximumGap98;sluagh80.clampedFrames98+=elapsed98>33;const float delta=fminf(100,(float)elapsed98*3.f);sluagh80.lastTick=now;if(delta<=0)return;
 // The tracker clock is an engine service, separate from the actor callback.
 snSetFloat((void*)sluaghResources80.module,0xc5b1f0,fmaxf(0,snFloat((void*)sluaghResources80.module,0xc5b1f0)-delta));
 const bool canFight=actualWorld==sluagh80.world&&contactEligible&&target.hp>0&&(target.mainState==1||target.mainState==2||target.mainState==5||target.mainState==6||target.mainState==7||target.mainState==12||target.mainState==13||target.mainState==25||target.mainState==26);
 if(canFight&&!sluagh80.airborne86&&!sluagh80.airPursuit95&&!(localFlight.identity.target==target.generation&&localFlight.identity.realm==1&&localVictimWindow(localFlight.launch,now)))kainPlant104();
 int16_t current[3],goal[3];if(!readAt(target.actor+0x9c,current,6)||!readAt(actor+0x9c,goal,6))return;
 float p[3]={current[0],current[1],current[2]},t[3]={goal[0],goal[1],goal[2]},stagedMatrices[1264];SluaghNativeAI *ai=&sluagh80.ai;
 snWorld(ai,p,t,sluagh80.hp*(5000.f/sluagh80.maxHp),5000);
 snClock94(ai,delta);
 snSetU32(ai->target,0x5c,0x10a0u|(ai->mode==48?0x4000u:0));
 if(!sluagh80.airborne86){sluagh80.groundZ86=sluagh80.airPursuit95?kainAir95.floor:p[2];sluagh80.highestZ86=p[2];}
 if(target.hp>0&&(target.mainState==8||target.mainState==11)){
  // Native flight is still authoritative; the original fall selector owns its pose.
  if(target.mainState==11||(localFlight.identity.target==target.generation&&localFlight.identity.realm==1&&localVictimWindow(localFlight.launch,now))){sluagh80.airborne86=true;sluagh80.highestZ86=fmaxf(sluagh80.highestZ86,p[2]);}
 }
 sluagh80.opacity86=1.f;
 kainVoiceHeartbeat100(now);
 const bool spell102=kainBeamFrame100(&frame,now,canFight,stagedMatrices);
 if(spell102){
  sluagh80.hitActive=false;kainMotion97.dash=kainBeam100.retreat!=0;
 }else if(canFight){
  if(sluagh80.reaction86){sluaghBlend86(now);snCancel(ai);sluagh80.presentationState=0;sluagh80.reaction86=0;sluagh80.clip=ai->clip;sluagh80.sample=0;sluagh80.airborne86=false;sluagh80.hurt86=false;sluagh80.decision=now-50;}
  // The original state12 turn service receives a fresh host target every frame,
  // including committed attack preparation. Preserve authored attack/roll heading.
  if(ai->mode!=42&&ai->mode!=48&&ai->mode!=49&&(ai->mode!=37||(!sluagh80.hitActive&&sluagh80.sample<100)))snFace86(ai,delta);
  if(ai->mode!=36&&ai->mode!=41&&ai->mode!=37&&ai->mode!=42&&ai->mode!=48&&ai->mode!=49&&ai->mode!=60&&now-sluagh80.decision>=50){unsigned next=snDecision(ai,p,t,(float)(now-sluagh80.decision>33?33:now-sluagh80.decision)*3,sluagh80.hp*(5000.f/sluagh80.maxHp),5000);sluagh80.decision=now;if(ai->clip>=48){record("kain92 invalid-native-clip=%u",ai->clip);sluaghCleanup80();return;}if(ai->clip!=sluagh80.clip||next==37||next==42){sluaghBlend86(now);sluagh80.clip=ai->clip;sluagh80.sample=0;}if(next!=255)record("kain92 native-choice state=%u clip=%u",next,ai->clip);}
  if(ai->mode==36||ai->mode==41){unsigned serial95=ai->animationSerial,old95=ai->mode;if(!snPursuit95(ai)){record("kain95 pursuit-refused mode=%u pending=%u",old95,ai->state[0x47b]);return;}if(serial95!=ai->animationSerial){sluaghBlend86(now);sluagh80.clip=ai->clip;sluagh80.sample=0;record("kain95 pursuit-transition before=%u after=%u clip=%u",old95,ai->mode,ai->clip);}}
  float previous=sluagh80.sample;const float actionDelta97=ai->mode==37&&kainMelee97(ai)?delta*1.25f:delta;sluagh80.sample+=actionDelta97;
  SluaghClip80 clip=sluaghResources80.clips[sluagh80.clip];float end=(clip.keys-1)*clip.timePerKey;
  if(ai->mode==42){sluagh80.sample=kainDash97(now,snWorldYaw(ai),end);sluagh80.opacity86=.28f;}else kainMotion97.dash=false;
  if(ai->mode==37){unsigned serial=ai->animationSerial;snAttackFrame(ai,sluagh80.sample,(int)(previous/clip.timePerKey),actionDelta97);
   if(ai->clip>=48){record("kain92 unsupported-native-action logical=%u",ai->logical);sluaghCleanup80();return;}
   if(serial!=ai->animationSerial){sluaghBlend86(now);sluagh80.clip=ai->clip;sluagh80.sample=previous=0;clip=sluaghResources80.clips[ai->clip];end=(clip.keys-1)*clip.timePerKey;sluagh80.hitActive=false;sluagh80.decision=now-50;record("kain92 original-action-transition state=%u logical=%u clip=%u",ai->mode,ai->logical,ai->clip);}
   bool hit=ai->mode==37&&(snU32(ai->state,0x3ec)&8u)!=0;if(ai->strikeSerial96!=sluagh80.strikeSeen96){sluagh80.strikeSeen96=ai->strikeSerial96;sluagh80.hitSent=false;}sluagh80.hitActive=hit;}
  if(ai->grabEvents92!=kainGrabSeen92){kainGrabSeen92=ai->grabEvents92;float distance92=hypotf(t[0]-p[0],t[1]-p[1]);
   if(!localDodgeBusy56(&frame,actor,now)&&distance92<400&&fabsf(t[2]-p[2])<300&&localNativeLineClear(target.actor,sluagh80.world,p,goal)&&snGrab92(ai)){kainGrabTick92=now;kainGrabOffset92[0]=t[0]-p[0];kainGrabOffset92[1]=t[1]-p[1];sluaghBlend86(now);sluagh80.clip=ai->clip;sluagh80.sample=previous=0;clip=sluaghResources80.clips[ai->clip];end=(clip.keys-1)*clip.timePerKey;record("kain92 grab-contact accepted=1 state=%u",ai->mode);}else record("kain96 remote-grab distance=%.1f executed=%u",distance92,kainTelekinesis96(&frame,now,true));
  }
  if(ai->mode==48||ai->mode==49||ai->mode==60){unsigned serial92=ai->animationSerial;const bool end92=sluagh80.sample>=end;if(!snPairFrame92(ai,delta,end92)){record("kain92 paired-action-refused");sluaghCleanup80();return;}if(serial92!=ai->animationSerial){sluaghBlend86(now);sluagh80.clip=ai->clip;sluagh80.sample=previous=0;clip=sluaghResources80.clips[ai->clip];end=(clip.keys-1)*clip.timePerKey;}
   if(ai->mode==48){float wanted92[3]={p[0]+kainGrabOffset92[0],p[1]+kainGrabOffset92[1],t[2]};int16_t to92[3];for(unsigned k=0;k<3;k++)to92[k]=(int16_t)lroundf(wanted92[k]);if(localNativeLineClear(actor,sluagh80.world,t,to92)){((void(*)(uintptr_t,const int16_t*,int))(base+0x117810))(actor,to92,0);}}else kainGrabTick92=0;
  }
  if(ai->damageEvents92!=kainDamageSeen92){kainDamageSeen92=ai->damageEvents92;float from92[3]={p[0],p[1],p[2]+300};int16_t to92[3]={goal[0],goal[1],(int16_t)(goal[2]+300)};
   if(!ai->damageIsPower95&&localNativeLineClear(target.actor,sluagh80.world,from92,to92)){const unsigned raw92=snU32(ai->playerEvent92,0x18);const int power92=raw92&&raw92<5000?(int)fminf(16384,fmaxf(1024,raw92*40.96f)):4096;const bool applied96=kainPlayerContact96(target.actor,actor,power92,snU32(ai->playerEvent92,0x24),false,&frame,now);record("kain96 native-action-hit event=%u power=%d applied=%u",ai->damageEvents92,power92,applied96);}
  }
  if(ai->fxEvents92!=kainFxSeen92){kainFxSeen92=ai->fxEvents92;record("kain100 native-effect routed-to-named-output request=%u generic-cast-flash=0",kainFxSeen92);}
  if(ai->projectileRequests94!=kainProjectileSeen94){kainProjectileSeen94=ai->projectileRequests94;record("kain94 original-projectile request=%u executed=%u",kainProjectileSeen94,kainLaunchForce94(&frame,now));}
  if(ai->shockRequests94!=kainShockSeen94){
   kainShockSeen94=ai->shockRequests94;const float radius94=snFloat(ai->shockEvent94,0x28),angle94=snFloat(ai->shockEvent94,0x2c),width94=snFloat(ai->shockEvent94,0x30),distance94=hypotf(t[0]-p[0],t[1]-p[1]);
   const float bearing94=atan2f(-(t[0]-p[0]),t[1]-p[1])/6.28318530718f;float difference94=remainderf(bearing94-angle94,1.f);
   bool admitted94=isfinite(radius94)&&radius94>0&&radius94<=8000&&isfinite(width94)&&width94>0&&distance94<=radius94&&fabsf(difference94)<=width94;
   if(admitted94)admitted94=kainTelekinesis96(&frame,now,false);
   record("kain94 original-shock request=%u radius=%.1f distance=%.1f admitted=%u",kainShockSeen94,radius94,distance94,admitted94);
  }
  if(ai->powerEffects94!=kainPowerSeen94)kainPowerSeen94=ai->powerEffects94;
  if(ai->powerCasts95!=kainPowerCastSeen95){kainPowerCastSeen95=ai->powerCasts95;kainVoice100(0,now);kainBlast95(&frame,now);record("kain95 sword-power original-command=%u",kainPowerCastSeen95);}
  float beforeMatrices[1264],beforeRoot[3],root[3];sluaghSample80(sluagh80.clip,previous,beforeMatrices,beforeRoot);sluaghSample80(sluagh80.clip,sluagh80.sample,stagedMatrices,root);
  float yaw=snWorldYaw(ai),c=cosf(yaw),s=sinf(yaw);sluagh80.yaw=yaw;
  if(ai->mode==36||ai->mode==41||ai->mode==37||ai->mode==42){
   // G2 root channels are per-key displacements. Original 5c640 integrates
   // sampled translation * interval/key duration (5c991..5c9fe), not a
   // difference between two root positions.
   const float scale=.9598479333948396f;float movement[3];sluaghRootMotion80(sluagh80.clip,previous,actionDelta97,movement);float dx=movement[0]*scale,dy=movement[1]*scale;
   if(ai->mode==36||ai->mode==41){const float gx=snFloat(ai->state,0x80)-p[0],gy=snFloat(ai->state,0x84)-p[1],distance=hypotf(gx,gy),step=fminf(hypotf(dx,dy),distance);if(distance>1){dx=gx*step/distance;dy=gy*step/distance;}else dx=dy=0;sluaghQueueMove80(dx,dy);}
   else if(ai->mode!=42)sluaghQueueMove80(c*dx-s*dy,s*dx+c*dy);
   if(ai->mode==37&&!snPowerDescriptor96(ai,snPtr(ai->state,0x200))&&hypotf(t[0]-p[0],t[1]-p[1])>650){const float distance=hypotf(t[0]-p[0],t[1]-p[1]),step=fminf(delta*.7f,distance-650);sluaghQueueMove80((t[0]-p[0])*step/distance,(t[1]-p[1])*step/distance);}
  }
  if((end<=0||sluagh80.sample>=end)&&ai->mode!=48&&ai->mode!=49&&ai->mode!=60){if(ai->mode==37||ai->mode==42){sluaghBlend86(now);unsigned next=snActionEnd(ai);if(next==255){record("kain92 native-end-refused");sluaghCleanup80();return;}sluagh80.clip=ai->clip;sluagh80.hitActive=false;sluagh80.decision=now-50;}sluagh80.sample=0;}
  if(sluagh80.hitActive&&!sluagh80.hitSent&&now-(uint64_t)InterlockedCompareExchange64(&sluaghLastVisual80,0,0)<200){
   LocalSphere body;bool contact=false;const unsigned char *descriptor=snPtr(ai->state,0x200),*commands=snPtr(sluaghResources80.attributes,0xe0);
   if(localContactSphere(actor,false,true,NULL,NULL,&body)&&descriptor&&commands&&descriptor[0x44]<=16&&readAt(target.actor+0x9c,current,6)){
    for(unsigned i=0;i<descriptor[0x44]&&!contact;i++){
     const unsigned char *command=commands+descriptor[0x5f+i]*88;int bone=(int)(int8_t)command[4];if(command[1]!=0||bone<0||bone>=79)continue;
     const float *joint=stagedMatrices+bone*16,scale=.9598479333948396f;
     float point[3]={current[0]+(c*joint[12]-s*joint[13])*scale,current[1]+(s*joint[12]+c*joint[13])*scale,current[2]+joint[14]*scale};
     float tip92[3];for(unsigned k=0;k<3;k++){const float end92=joint[12+k]+joint[8+k]*493.724121f;tip92[k]=current[k]+(k==0?c*end92-s*(joint[13]+joint[9]*493.724121f):k==1?s*(joint[12]+joint[8]*493.724121f)+c*end92:end92)*scale;}
     const float radius=body.native.radius+45.f;
     const float *oldJoint=beforeMatrices+bone*16;float oldPoint[3],oldTip[3];
     for(unsigned k=0;k<3;k++){const float b0=oldJoint[12]+oldJoint[8]*493.724121f,b1=oldJoint[13]+oldJoint[9]*493.724121f;oldPoint[k]=current[k]+(k==0?c*oldJoint[12]-s*oldJoint[13]:k==1?s*oldJoint[12]+c*oldJoint[13]:oldJoint[14])*scale;oldTip[k]=current[k]+(k==0?c*b0-s*b1:k==1?s*b0+c*b1:oldJoint[14]+oldJoint[10]*493.724121f)*scale;}
     for(unsigned sweep=0;sweep<=8&&!contact;sweep++){float a[3],b[3];for(unsigned k=0;k<3;k++){a[k]=oldPoint[k]+(point[k]-oldPoint[k])*sweep/8.f;b[k]=oldTip[k]+(tip92[k]-oldTip[k])*sweep/8.f;}contact=kainSegmentDistance92(a,b,body.native.center)<=radius*radius&&localNativeLineClear(target.actor,sluagh80.world,a,body.native.center);}
    }
   }
   if(contact){
    const unsigned kind96=(unsigned)(uint8_t)descriptor[0x20];
    if(kainPlayerContact96(target.actor,actor,kind96!=5&&snU32(descriptor,0x18)>=20?8192:4096,kind96,false,&frame,now)){sluagh80.hitSent=true;record("kain96 blade-contact serial=%u clip=%u frame=%.2f",ai->strikeSerial96,sluagh80.clip,sluagh80.sample/100);}
   }
  }
 }else {
  kainGrabTick92=0;
  sluagh80.hitActive=false;
  sluagh80.pendingMove[0]=sluagh80.pendingMove[1]=0;sluagh80.pendingMoveTick=0;
  // Explicit host-reaction adapter using original logical descriptors. All31
  // keylists remain available; unrelated attacks are not cycled as reactions.
  unsigned key=16,logical=snAnimSlot86(ai,2);bool loop=true;
  if(target.hp<=0){
   kainEncounter93.saved=false;if(!kainDeath92){kainDeath92=now;record("kain92 defeated hp=0");}sluagh80.opacity86=fmaxf(0,1.f-(now-kainDeath92)/700.f);if(now-kainDeath92>=700){sluaghCleanup80();return;}
   if(hyldenDeadState90(target.mainState)){key=400;logical=snDeathAnimation89(ai);loop=false;}
   else if(sluagh80.airborne86&&(target.mainState==4||target.mainState==11)){key=13;logical=snFallAnimation86(ai,0,2);loop=false;}
   else {key=16;logical=snAnimSlot86(ai,2);loop=true;}
  }else if(target.mainState==15&&sluagh80.airborne86){key=sluagh80.reaction86==41?41:40;logical=snThrowSlot94(ai,key==41?0x0e:0x0d);loop=false;}
  else if(target.mainState==4&&sluagh80.airborne86){key=46;logical=snThrowSlot94(ai,0x0a);loop=true;}
  else if(target.mainState==8||target.mainState==9||target.mainState==11){
   key=sluagh80.airborne86?(sluagh80.airHit94?47:46):15;logical=snDamageAnimation86(ai,sluagh80.airborne86&&!sluagh80.airHit94);loop=sluagh80.airborne86&&!sluagh80.airHit94;
  }
  if(!sluaghPresent86(key,logical,loop,now)){record("kain92 presentation-refused key=%u logical=%u",key,logical);sluaghCleanup80();return;}
  const float end=(sluaghResources80.clips[sluagh80.clip].keys-1)*sluaghResources80.clips[sluagh80.clip].timePerKey;
  sluagh80.sample=snAdvancePresentation86(sluagh80.sample,delta,end,loop);
  sluaghSample80(sluagh80.clip,sluagh80.sample,stagedMatrices,(float[3]){0});
  const bool finished=sluagh80.sample>=end;
  if(key==400&&finished&&!sluagh80.deathDone86){sluagh80.deathDone86=true;record("kain92 death-animation-complete native=%u",target.mainState);}
  if(key==40&&finished&&!sluaghPresent86(41,snThrowSlot94(ai,0x0e),false,now)){sluaghCleanup80();return;}
  if(key==47&&finished){sluagh80.airHit94=false;if(!sluaghPresent86(46,snThrowSlot94(ai,0x0a),true,now)){sluaghCleanup80();return;}}
  // The SR1 proxy can enter its long stun with positive boss HP. It must
  // acknowledge the completed original hit reaction instead of waiting for
  // the Ronin's own stun timer. Air/landing completion retains its native path.
  if(key==15&&finished&&target.hp>0&&!sluagh80.airborne86&&(target.mainState==8||target.mainState==9)){
   ((void(*)(uintptr_t,unsigned))(base+0x9f0d0))(target.actor,13);
   record("kain94 ground-reaction-complete hp=%d native=%u next=13",target.hp,target.mainState);
  }
  uintptr_t landingPair=sluaghOriginalLookup80(target.actor,15),landingUpdate=0;readAt(landingPair+8,&landingUpdate,8);
  if(key==41&&!sluagh80.endAck86&&snRecoveryEnd86(target.mainState,target.hp,sluagh80.airborne86,finished,landingUpdate==base+0xa5b70)){
   sluagh80.endAck86=true;record("kain92 landing-animation-complete native-end-pending=1");
  }
  // Keep the last fighting orientation through flinch/flight/collapse. Only
  // the actual fleeing/intake body follows native SR1 soul steering.
  uint16_t nativeYaw=0;if(key==700&&readAt(target.actor+0xd2,&nativeYaw,2))sluagh80.yaw=nativeYaw*6.28318530718f/4096.f;
 }
 kainGaitClock97(p,delta,canFight&&!sluagh80.airborne86&&!sluagh80.airPursuit95&&!spell102);
 if(!spell102)kainGaitPose97(stagedMatrices);
 if(!kainMotion97.dash&&sluagh80.blendTick86&&now>=sluagh80.blendTick86){const float blend=fminf(1,(now-sluagh80.blendTick86)/100.f);for(unsigned i=0;i<1264;i++)stagedMatrices[i]=sluagh80.blendPose86[i]+blend*(stagedMatrices[i]-sluagh80.blendPose86[i]);if(blend>=1)sluagh80.blendTick86=0;}
 if((!sluagh80.airborne86&&!sluagh80.airPursuit95)||target.mainState==15){float lift95=kainSoleOffset95(stagedMatrices);for(unsigned bone=0;bone<79;bone++)stagedMatrices[bone*16+14]+=lift95;}
 readAt(target.actor+0x9c,current,6);
 int16_t nativeScale[3]={4096,4096,4096};readAt(target.actor+0x100,nativeScale,6);
 AcquireSRWLockExclusive(&sluaghRenderLock80);
 sluagh80.previousValid98=sluagh80.render&&sluagh80.poseTick98&&now>sluagh80.poseTick98;
 if(sluagh80.previousValid98){memcpy(sluagh80.previousPose98,sluagh80.matrices,sizeof sluagh80.matrices);memcpy(sluagh80.previousPosition98,sluagh80.position,12);sluagh80.previousYaw98=sluagh80.publishedYaw98;sluagh80.poseStep98=now-sluagh80.poseTick98;if(sluagh80.poseStep98>50)sluagh80.poseStep98=50;}
 sluagh80.poseTick98=now;sluagh80.publishedYaw98=sluagh80.yaw;memcpy(sluagh80.matrices,stagedMatrices,sizeof stagedMatrices);for(unsigned k=0;k<3;k++){sluagh80.position[k]=current[k];sluagh80.nativeScale[k]=fmaxf(0,fminf(nativeScale[k]/4096.f,2.f));}sluagh80.ghost=target.hp<=0;
 const bool sucking85=false;if(sucking85&&!sluagh80.sucking85)sluagh80.suckingSince85=now;if(!sucking85)sluagh80.suckingSince85=0;sluagh80.sucking85=sucking85;
 sluagh80.render=true;ReleaseSRWLockExclusive(&sluaghRenderLock80);
 kainSaveCurrent93();
 if(now-sluagh80.lastLog>=1000){record("kain98 cadence max-gap=%llu clamped-frames=%llu interpolation-ms=%llu",(unsigned long long)sluagh80.maximumGap98,(unsigned long long)sluagh80.clampedFrames98,(unsigned long long)sluagh80.poseStep98);sluagh80.maximumGap98=sluagh80.clampedFrames98=0;sluagh80.lastLog=now;record("kain92 frame native-state=%u ai-state=%u clip=%u hp=%d xyz=%d,%d,%d calls=%u moves=%u blocked=%u restored=%u scale=%d,%d,%d feed=%u",target.mainState,ai->mode,sluagh80.clip,target.hp,current[0],current[1],current[2],ai->calls,sluagh80.moveAccepted,sluagh80.moveBlocked,sluagh80.moveRestored,nativeScale[0],nativeScale[1],nativeScale[2],frame.nativeControl);
  uint32_t realmFlags90=0;int32_t velocity90=0,gravity90=0;readAt(target.actor+0x28,&realmFlags90,4);readAt(target.actor+0x2d4,&velocity90,4);readAt(target.actor+0x2e0,&gravity90,4);record("kain92 physics spectral=%u vz=%d gravity=%d",(realmFlags90&0x08000000u)!=0,velocity90,gravity90);
  int16_t player105[3]={0};uintptr_t handler105=0;int physics105=-1,vz105=0;readAt(actor+0x9c,player105,6);readAt(base+host->callbackRva,&handler105,8);readAt(base+0xd6b2ac,&physics105,4);readAt(actor+0x2d4,&vz105,4);record("kain105 player-frame xyz=%d,%d,%d handler=%llx physics=%d vz=%d support-age=%llu missing=%u",player105[0],player105[1],player105[2],(unsigned long long)(handler105?handler105-base:0),physics105,vz105,(unsigned long long)(kainSupport105.tick&&now>=kainSupport105.tick?now-kainSupport105.tick:UINT64_MAX),kainSupport105.missing);
 }
}
static bool sluaghDrawScope80(const uintptr_t args[8]){
 if(!InterlockedCompareExchange(&portableActive60,0,0)||!sluaghMember80())return false;uintptr_t models=0,model=0,render=0;int16_t index=0;
 if(!readAt(sluagh80.actor+0x1c6,&index,2)||index<0||index>=32||!readAt(sluagh80.object+0x10,&models,8)||!models||!readAt(models+index*8,&model,8)||!readAt(sluagh80.actor+0x70,&render,8))return false;
 const int slot=hyldenPoseRecord91(args[0],args[1],args[3],sluagh80.object,model,render);if(slot<0)return false;
 static unsigned scopes;if(++scopes==1||scopes%600==0)record("kain92 render-scope generation=%u model=%d record=%d calls=%u",sluagh80.generation,index,slot,scopes);return true;
}
static void sluaghCaptureProxy80(void){
 sluaghProxyPalette80.valid=false;HGLRC context=wglGetCurrentContext();unsigned before=0,after=0;float duplicate[96*12];const Sheet_reaverPalettePolicy *p=&sheet_reaverPalettePolicy_submitted_gpu_palette;
 if(!context||!readAt(base+p->countRva,&before,4)||!before||before>96||!readAt(base+p->paletteRva,sluaghProxyPalette80.values,before*48)||!readAt(base+p->paletteRva,duplicate,before*48)||!readAt(base+p->countRva,&after,4)||before!=after||memcmp(duplicate,sluaghProxyPalette80.values,before*48))return;
 for(unsigned i=0;i<before*12;i++)if(!isfinite(duplicate[i]))return;
 sluaghProxyPalette80.context=context;sluaghProxyPalette80.frame=localBladeFrame();sluaghProxyPalette80.actor=sluagh80.actor;sluaghProxyPalette80.generation=sluagh80.generation;sluaghProxyPalette80.joints=before;sluaghProxyPalette80.valid=true;
 static unsigned captures;if(++captures==1||captures%600==0)record("kain92 palette-captured generation=%u joints=%u calls=%u",sluagh80.generation,before,captures);
}
static bool kainPaletteMatch118(const float *a,const float *b,unsigned joints,uint64_t frame,HGLRC context){
 return sluaghProxyPalette80.valid&&sluaghProxyPalette80.actor==sluagh80.actor&&
  sluaghProxyPalette80.generation==sluagh80.generation&&sluaghProxyPalette80.frame==frame&&
  sluaghProxyPalette80.context==context&&joints>0&&joints<=96&&joints==sluaghProxyPalette80.joints&&
  !memcmp(a,b,joints*48)&&!memcmp(a,sluaghProxyPalette80.values,joints*48);
}
static bool sluaghHideNative80(GLenum mode,GLsizei count,GLenum type){
 if(sluaghDrawing117){
  GLint program117=0;glGetIntegerv(GL_CURRENT_PROGRAM,&program117);
  const HGLRC context117=wglGetCurrentContext();
  if(program117>0&&context117&&localBladeCamera(context117))sluaghCapture80(localBladeFrame(),context117,(GLuint)program117);
  return true;
 }
 // Native groundDraw may submit geometry for a later GL pass. Its TLS scope
 // alone cannot hide those draws; retain current-frame GPU palette identity.
 (void)count;if(mode!=GL_TRIANGLES||type!=GL_UNSIGNED_SHORT||!sluaghMember80()||!sluaghProxyPalette80.valid||sluaghProxyPalette80.frame!=localBladeFrame()||sluaghProxyPalette80.actor!=sluagh80.actor||sluaghProxyPalette80.generation!=sluagh80.generation)return false;
 GLint program=0,fbo=0;HGLRC context=wglGetCurrentContext();glGetIntegerv(GL_CURRENT_PROGRAM,&program);glGetIntegerv(GL_DRAW_FRAMEBUFFER_BINDING,&fbo);if(fbo||program<=0||context!=sluaghProxyPalette80.context||!localBladeCamera(context))return false;
 float a[96*12],b[96*12];unsigned joints=sluaghProxyPalette80.joints;
 if(!reaverGpuPaletteRead(a,joints,context,(GLuint)program)||!reaverGpuPaletteRead(b,joints,context,(GLuint)program)||!kainPaletteMatch118(a,b,joints,localBladeFrame(),context))return false;
 sluaghCapture80(localBladeFrame(),context,(GLuint)program);static unsigned hidden;if(++hidden==1||hidden%300==0)record("kain92 native-proxy-hidden draws=%u joints=%u",hidden,joints);return true;
}
static void sluaghCapture80(uint64_t frame,HGLRC context,GLuint program){
 if(!sluagh80.render)return;ReaverCameraSample a,b;if(!reaverHostCameraSample(&a,frame,context,program)||!reaverHostCameraSample(&b,frame,context,program)||memcmp(a.view,b.view,64)||memcmp(a.projection,b.projection,64))return;
 hostMultiply(a.projection,a.view,sluaghCamera80);sluaghCameraFrame80=frame;
}
static bool sluaghSpectralShader80(ReaverGL *r){
 // Private enemy-only presentation. Geometry/collision/decisions stay native.
 const char *vs="#version 330 core\nlayout(location=0)in vec3 position;layout(location=1)in vec2 texcoord;layout(location=2)in vec4 preparedColor;uniform mat4 mvp;uniform float spectralTime;out vec2 uv;out vec4 tint;void main(){vec3 p=position;gl_Position=mvp*vec4(p,1);uv=texcoord;tint=preparedColor;}";
 // Original diffuse RGB. Scene spectral grading/lighting has not been ported.
 const char *fs="#version 330 core\nuniform sampler2D blade;in vec2 uv;in vec4 tint;out vec4 color;void main(){color=vec4(texture(blade,uv).rgb*tint.rgb,tint.a);}";
 GLuint vertex=guidanceShader(GL_VERTEX_SHADER,vs),fragment=guidanceShader(GL_FRAGMENT_SHADER,fs),program=0;GLint linked=0;
 if(vertex&&fragment){program=ghCreateProgram();ghAttachShader(program,vertex);ghAttachShader(program,fragment);ghLinkProgram(program);ghGetProgramiv(program,GL_LINK_STATUS,&linked);}
 if(vertex)ghDeleteShader(vertex);if(fragment)ghDeleteShader(fragment);
 if(!linked){if(program)ghDeleteProgram(program);return false;}
 ghDeleteProgram(r->program);r->program=program;record("kain92 original-diffuse-shader linked=1 outline=0 material=1");return true;
}
static bool sluaghOpaque80(ReaverGL *r,const ReaverGLVertex *vertices,unsigned vertexCount,const uint16_t *indices,unsigned indexCount,unsigned texture,const float mvp[16],bool ghost){
 if(!r->context||r->context!=wglGetCurrentContext()||!r->program||!vertexCount||vertexCount>2048||!indexCount||indexCount>8192||indexCount%3||!kainMaterial93(texture,sluaghResources80.textures)||!r->textures[texture])return false;
 for(unsigned i=0;i<16;i++)if(!isfinite(mvp[i]))return false;
 for(unsigned i=0;i<vertexCount;i++)for(unsigned k=0;k<9;k++)if(!isfinite(((const float*)(vertices+i))[k]))return false;
 for(unsigned i=0;i<indexCount;i++)if(indices[i]>=vertexCount)return false;
 ReaverGLState saved={0};reaverGLSave(&saved);ghUseProgram(r->program);ghBindVertexArray(r->vao);ghBindBuffer(GL_ARRAY_BUFFER,r->vbo);
 rgBufferData(GL_ARRAY_BUFFER,vertexCount*sizeof(*vertices),vertices,GL_STREAM_DRAW);ghBindBuffer(GL_ELEMENT_ARRAY_BUFFER,r->ebo);rgBufferData(GL_ELEMENT_ARRAY_BUFFER,indexCount*sizeof(*indices),indices,GL_STREAM_DRAW);
 ghActiveTexture(GL_TEXTURE0);glBindTexture(GL_TEXTURE_2D,r->textures[texture]);ghBindSampler(0,0);ghUniform1i(ghGetUniformLocation(r->program,"blade"),0);
 rgUniformMatrix4fv(ghGetUniformLocation(r->program,"mvp"),1,GL_FALSE,mvp);rgUniform1f(ghGetUniformLocation(r->program,"scroll"),0);rgUniform1f(ghGetUniformLocation(r->program,"alphaTest"),.1f);
 rgUniform1f(ghGetUniformLocation(r->program,"spectralTime"),(GetTickCount64()%600000)*.0009f);
 glEnable(GL_DEPTH_TEST);glDepthFunc(GL_LEQUAL);glDepthMask(GL_TRUE);ghDisablei(GL_BLEND,0);ghColorMaski(0,GL_TRUE,GL_TRUE,GL_TRUE,GL_TRUE);glPolygonMode(GL_FRONT_AND_BACK,GL_FILL);
 if(ghost||vertices[0].rgba[3]<.99f){glDepthMask(GL_FALSE);ghEnablei(GL_BLEND,0);rgBlendFuncSeparatei(0,GL_SRC_ALPHA,GL_ONE_MINUS_SRC_ALPHA,GL_ONE,GL_ONE_MINUS_SRC_ALPHA);rgBlendEquationSeparatei(0,GL_FUNC_ADD,GL_FUNC_ADD);}
 glDisable(GL_STENCIL_TEST);glDisable(GL_CULL_FACE);glDisable(GL_SCISSOR_TEST);glDisable(GL_RASTERIZER_DISCARD);glDisable(GL_COLOR_LOGIC_OP);
 for(unsigned i=0;i<8;i++)glDisable(GL_CLIP_DISTANCE0+i);glDisable(GL_SAMPLE_COVERAGE);glDisable(GL_SAMPLE_ALPHA_TO_COVERAGE);glDisable(GL_SAMPLE_ALPHA_TO_ONE);glDisable(GL_SAMPLE_MASK);
 glDrawElements(GL_TRIANGLES,(GLsizei)indexCount,GL_UNSIGNED_SHORT,NULL);reaverGLRestore(&saved);return true;
}
static void sluaghDraw80(uint64_t frame){
 if(sluaghCameraFrame80!=frame||!sluagh80.render)return;SluaghResources80 *r=&sluaghResources80;
 if(!sluaghGL80.context){if(!reaverGLInit(&sluaghGL80))return;if(!sluaghSpectralShader80(&sluaghGL80)){reaverGLDestroy(&sluaghGL80);return;}for(unsigned i=0;i<18;i++)if(!reaverGLTexture(&sluaghGL80,i,256,256,r->texture+i*256*256*4,true,true))return;}
 float pose[1264],position[3],yaw,nativeScale[3],mouth85[3],opacity86;uint64_t mouthTick85,suckSince85;bool sucking85;AcquireSRWLockShared(&sluaghRenderLock80);memcpy(pose,sluagh80.matrices,sizeof pose);memcpy(position,sluagh80.position,sizeof position);memcpy(nativeScale,sluagh80.nativeScale,sizeof nativeScale);memcpy(mouth85,sluagh80.mouth85,12);mouthTick85=sluagh80.mouthTick85;suckSince85=sluagh80.suckingSince85;sucking85=sluagh80.sucking85;opacity86=sluagh80.opacity86;yaw=sluagh80.publishedYaw98;bool render=sluagh80.render,ghost=sluagh80.ghost;
 if(sluagh80.previousValid98&&sluagh80.poseStep98){const uint64_t tick98=GetTickCount64();const float blend98=tick98>=sluagh80.poseTick98?fminf(1,(tick98-sluagh80.poseTick98)/(float)sluagh80.poseStep98):0;
  for(unsigned k=0;k<1264;k++)pose[k]=sluagh80.previousPose98[k]+(pose[k]-sluagh80.previousPose98[k])*blend98;
  for(unsigned bone=0;bone<79;bone++)if(!kainRigidBasis98(pose+bone*16))memcpy(pose+bone*16,sluagh80.matrices+bone*16,64);
  for(unsigned k=0;k<3;k++)position[k]=sluagh80.previousPosition98[k]+(position[k]-sluagh80.previousPosition98[k])*blend98;
  yaw=sluagh80.previousYaw98+remainderf(yaw-sluagh80.previousYaw98,6.28318530718f)*blend98;
 }ReleaseSRWLockShared(&sluaghRenderLock80);if(!render)return;
 const float scale=.9598479333948396f,c=cosf(yaw),s=sinf(yaw);float model[16]={c*scale*nativeScale[0],s*scale*nativeScale[0],0,0,-s*scale*nativeScale[1],c*scale*nativeScale[1],0,0,0,0,scale*nativeScale[2],0,position[0],position[1],position[2],1},mvp[16];hostMultiply(sluaghCamera80,model,mvp);
 const uint64_t now85=GetTickCount64();const bool warp85=ghost&&sucking85&&suckSince85&&now85>=suckSince85&&mouthTick85&&now85>=mouthTick85&&now85-mouthTick85<=250;
 float blend85=0,width85=1;
 if(warp85){float distance85=0;for(unsigned k=0;k<3;k++){float d=mouth85[k]-position[k];distance85+=d*d;}distance85=sqrtf(distance85);
  if(sluaghSuckStart85!=suckSince85){sluaghSuckStart85=suckSince85;sluaghSuckDistance85=fmaxf(1,distance85);record("sluagh85 suction-warp head=18 distance=%.1f",distance85);}
  const float x=ghostClamp85((now85-suckSince85)/350.f);blend85=x*x*(3-2*x);width85=distance85/sluaghSuckDistance85;memcpy(mvp,sluaghCamera80,64);
 }
 for(unsigned batchIndex=0;batchIndex<r->batchCount;batchIndex++){
  const SluaghBatch80 *batch=&r->batches[batchIndex];ReaverGLVertex vertices[2048];
  for(unsigned v=0;v<batch->vertices;v++){unsigned index=batch->source[v];ReaverGLVertex *out=vertices+v;memset(out,0,sizeof(*out));out->rgba[0]=out->rgba[1]=out->rgba[2]=1.f;out->rgba[3]=opacity86;memcpy(out->uv,r->uv+index*2,8);
   for(unsigned joint=0;joint<4;joint++){unsigned weight=r->weights[index*4+joint];if(!weight)continue;unsigned bone=r->palette[r->joints[index*4+joint]];const float *m=pose+bone*16;float local[3];for(unsigned k=0;k<3;k++)local[k]=r->position[index*3+k]+r->bind[bone*3+k];for(unsigned k=0;k<3;k++)out->position[k]+=(m[k]*local[0]+m[4+k]*local[1]+m[8+k]*local[2]+m[12+k])*weight/255.f;
   }
   if(warp85){float local85[3];memcpy(local85,out->position,12);for(unsigned k=0;k<3;k++)out->position[k]=model[k]*local85[0]+model[4+k]*local85[1]+model[8+k]*local85[2]+model[12+k];ghostSuctionPoint85(out->position,local85[2],pose[4*16+14],position,mouth85,blend85,width85);}
  }
  if(sluaghOpaque80(&sluaghGL80,vertices,batch->vertices,batch->index,batch->indices,batch->texture,mvp,ghost))InterlockedExchange64(&sluaghLastVisual80,(LONG64)GetTickCount64());
 }
 kainHud92();
 kainSwordCoil97(sluaghCamera80,model,pose+65*16,sluagh80.ai.bladeCharge96,GetTickCount64());
 kainEffectsDraw95(sluaghCamera80,GetTickCount64());
}
static bool sluaghPrepare80(void){
 if(!kainPreparePlayer96()||!kainPreparePhysics104()||!kainPrepareFly106()||!localArmPrepare107()||!kainStoryPrepare108()||!trainingPrepare109())return false;
 const unsigned char landing[]={0x48,0x89,0x5c,0x24,0x08,0x57,0x48,0x83,0xec,0x20};
 if(!matches(0xa5b70,landing,sizeof landing)||MH_CreateHook((void*)(base+0xa5b70),sluaghLandingUpdate87,(void**)&sluaghOriginalLanding87)!=MH_OK)return false;
 const unsigned char init[]={0x40,0x53,0x48,0x83,0xec,0x20,0x48,0x8b,0x41,0x30},lookup[]={0x48,0x8b,0x41,0x30,0x48,0x8b,0x40,0x68};
 const unsigned char relocate[]={0x48,0x89,0x5c,0x24,0x10,0x57,0x48,0x83,0xec,0x20,0x0f,0xb7,0x02};if(!matches(0x117810,relocate,sizeof relocate))return false;
 const unsigned char additional[]={0x48,0x83,0x79,0x40,0x00,0x0f,0x85,0x15,0x1b,0x00,0x00,0xc3};
 if(!matches(0x990b0,additional,sizeof additional)||MH_CreateHook((void*)(base+0x990b0),sluaghAfterCollision80,(void**)&sluaghOriginalAdditional80)!=MH_OK)return false;
 if(!matches(0xb7d10,init,sizeof init)||!matches(0xa7890,lookup,sizeof lookup)||MH_CreateHook((void*)(base+0xb7d10),sluaghInit80,(void**)&sluaghOriginalInit80)!=MH_OK||MH_CreateHook((void*)(base+0xa7890),sluaghStatePair80,(void**)&sluaghOriginalLookup80)!=MH_OK)return false;
 HANDLE worker=CreateThread(NULL,0,sluaghResourceWorker80,NULL,0,NULL);if(!worker)return false;CloseHandle(worker);return true;
}
