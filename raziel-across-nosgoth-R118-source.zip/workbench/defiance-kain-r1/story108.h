// SPDX-License-Identifier: GPL-3.0-or-later
#pragma once
// Only the first authored Pillars encounter. SR1 retains every cinematic,
// reward and subsequent campaign script. Ordinary Defiance AI is unchanged.
static struct {
 uintptr_t level,table,opening,victory,progress,oldActor,player,callbacks[4];uint32_t oldGeneration,playerGeneration;
 bool openingSeen,pending,owned,suspended,committed,failed,modelRequested109,doorSeen110,cinemaPaused118;int16_t center[3];
 struct {uintptr_t actor;uint32_t generation,flags;} hidden[9];unsigned hiddenCount;
} kainStory108;
static void (*kainOriginalEvents108)(uintptr_t,uintptr_t);
static void (*kainOriginalFade114)(uintptr_t);
static struct{uintptr_t actor;uint32_t generation;}kainCinema114[9];
static bool kainVictoryActive115;
static unsigned kainFadeReads115;
static int (*kainOriginalOpacity115)(uintptr_t);
static int kainOpacity115(uintptr_t actor){
 const int value=kainOriginalOpacity115(actor);
 if(!kainVictoryActive115||!actor||!InterlockedCompareExchange(&portableActive60,0,0))return value;
 for(unsigned i=0;i<9&&kainCinema114[i].actor;i++){
  if(kainCinema114[i].actor==actor&&generation(actor)==kainCinema114[i].generation){
   kainFadeReads115++;return 0;
  }
 }
 return value;
}
static void kainFade114(uintptr_t actor){
 const DWORD error=GetLastError();uint8_t playing=0;
 if(kainStory108.committed&&kainStory108.victory&&InterlockedCompareExchange(&portableActive60,0,0)&&readAt(kainStory108.victory+5,&playing,1)&&playing){
  for(unsigned i=0;i<9;i++)if(kainCinema114[i].actor==actor&&generation(actor)==kainCinema114[i].generation){
   int16_t before=0;readAt(actor+0x190,&before,2);const int16_t visible=0;memcpy((void*)(actor+0x190),&visible,2);
   static uint64_t last;const uint64_t now=GetTickCount64();if(now-last>=500){last=now;record("kain114 cinematic-fade held-visible=1 generation=%u prior=%d original-scene-playing=1",generation(actor),before);}
   SetLastError(error);return;
  }
 }
 SetLastError(error);kainOriginalFade114(actor);
}
static bool kainShortcut113;
static bool kainShortcutWaiting113(void){return kainShortcut113&&(InterlockedCompareExchange(&portableWanted60,0,0)||portableDebugResume65);}
static bool kainDebugBusy113(void){
 uintptr_t actor=0;if(!InterlockedCompareExchange(&portableActive60,0,0)||!readAt(base+host->actorRva,&actor,8)||!actor)return false;
 return (kainStory108.player==actor&&generation(actor)==kainStory108.playerGeneration&&!kainStory108.committed&&(kainStory108.owned||kainStory108.pending))||
  (sluagh80.player==actor&&generation(actor)==sluagh80.playerGeneration&&(sluagh80.actor||sluagh80.loading));
}
static bool kainShortcutBegin113(void){
 if(!kainDebugBusy113())return false;
 if(sluagh80.actor&&!kainSaveCurrent93())return false;
 if(kainStory108.pending&&!sluagh80.actor){kainStory108.pending=false;InterlockedExchange(&sluaghCommand80,0);}
 kainShortcut113=true;kainKeep93=true;return true;
}
static void kainShortcutEnd113(void){kainKeep93=false;record("kain113 shortcut-preserved saved=%u hp=%d original-hidden=%u",kainEncounter93.saved,kainEncounter93.hp,kainStory108.suspended);}
static bool kainCinematic118(void){
 // renderBlend is a pose permission, not permission to fight during a puppet.
 for(unsigned i=0;i<3;i++){uintptr_t callback=0;
  if(readAt(base+host->callbackRva+i*host->sectionStride,&callback,8)&&callback==base+0xf41c0)return true;
 }
 if(kainStory108.player&&!kainStory108.committed&&kainStory108.opening){
  uint8_t playing=0;uint16_t flags=0;uintptr_t actions=0,script=0;
  if(readAt(kainStory108.opening+5,&playing,1)&&playing)return true;
  if(readAt(kainStory108.opening+0x20,&actions,8)&&actions&&readAt(actions,&script,8)&&script&&
   readAt(script+2,&flags,2)&&(flags&(unsigned)kainPolicy109->openingPendingMask))return true;
 }
 return false;
}
static bool kainGameplayReady113(const Sr1LocalFrame *frame){
 if(kainCinematic118())return false;
 if(frame->renderBlend)return true;
 uintptr_t actor=0;uint32_t abilities=0,mirror=0,flags=0;uint16_t mode=0;
 if(!frame->ready||!frame->nativeControl||!readAt(base+host->actorRva,&actor,8)||!actor||localPhysicalCarry(actor)||
  !readAt(base+acquisition->abilitiesRva,&abilities,4)||!readAt(base+acquisition->mirrorRva,&mirror,4)||abilities!=mirror||(abilities&combatPolicy->reaverAbility)||
  !readAt(base+0x2a89536,&mode,2)||mode||!readAt(base+0x2a8950c,&flags,4)||(flags&(0x10000000u|motion->scriptedPadMask)))return false;
 for(unsigned i=0;i<3;i++){
  uintptr_t callback=0;if(!readAt(base+host->callbackRva+i*host->sectionStride,&callback,8))return false;
  bool normal=callback==base+combatPolicy->nativeAttackRva;
  for(unsigned j=0;j<sheet_retargetGroundStates_count;j++)normal|=callback==base+sheet_retargetGroundStates_rows[j]->rva;
  if(!normal)return false;
 }return true;
}
static bool kainStoryMember108(uintptr_t actor,uint32_t gen){
 uintptr_t list=0,node=0;if(!actor||!gen||!readAt(base+contactPolicy->listRva,&list,8)||!list||!readAt(list+8,&node,8))return false;
 for(unsigned i=0;node&&i<512;i++){if(node==actor)return generation(node)==gen;if(!readAt(node+0x10,&node,8))return false;}return false;
}
static bool kainActorDraw117(const uintptr_t args[8],uintptr_t actor,uint32_t gen){
 uintptr_t object=0,models=0,model=0,matrices=0;int16_t index=0;
 if(!actor||generation(actor)!=gen||!readAt(actor+0x30,&object,8)||!object||
  !readAt(actor+0x1c6,&index,2)||index<0||index>=32||!readAt(object+0x10,&models,8)||!models||
  !readAt(models+index*8,&model,8)||!model||!readAt(actor+0x70,&matrices,8)||!matrices)return false;
 return hyldenPoseRecord91(args[0],args[1],args[3],object,model,matrices)>=0;
}
static bool kainStoryDrawHidden117(const uintptr_t args[8]){
 if(!kainStory108.suspended||kainStory108.committed||!InterlockedCompareExchange(&portableActive60,0,0))return false;
 for(unsigned i=0;i<kainStory108.hiddenCount;i++){
  const uintptr_t actor=kainStory108.hidden[i].actor;
  if(kainStoryMember108(actor,kainStory108.hidden[i].generation)&&kainActorDraw117(args,actor,kainStory108.hidden[i].generation))return true;
 }
 return false;
}
// Called at the original room's event boundary, even when the puppet owns
// both characters and normal combat callbacks are suspended.
static void kainVictoryFrame115(uintptr_t table,uintptr_t level){
 if(!kainStory108.committed||table!=kainStory108.table||level!=kainStory108.level)return;
 const uintptr_t event=kainStory108.victory;
 uintptr_t actions=0,script=0,refs=0,ref=0,bound=0;
 uint8_t queued=0;uint16_t flags=0,count=0,kind=0;uint32_t intro=0,stream=0;
 const bool wasActive=kainVictoryActive115;
 kainVictoryActive115=InterlockedCompareExchange(&portableActive60,0,0)&&event&&
  readAt(event+5,&queued,1)&&readAt(event+0x20,&actions,8)&&actions&&readAt(actions,&script,8)&&script&&
  readAt(script+2,&flags,2)&&(queued||(flags&kainPolicy109->openingPendingMask));
 if(!kainVictoryActive115){
  if(wasActive)record("kain115 victory-ended opacity-queries=%u",kainFadeReads115);
  return;
 }
 const uintptr_t root=kainStory108.oldActor;
 if(!kainStoryMember108(root,kainStory108.oldGeneration)){kainVictoryActive115=false;return;}
 const unsigned slot=(unsigned)sheet_kain115_rows[0]->rootSlot;
 const bool authored=readAt(event+2,&count,2)&&count>slot&&readAt(event+0x10,&refs,8)&&refs&&
  readAt(refs+slot*8,&ref,8)&&ref&&readAt(ref,&kind,2)&&kind==1&&readAt(ref+4,&stream,4)&&
  stream==(uint32_t)kainPolicy109->originalAuthoredStream&&readAt(ref+8,&intro,4)&&
  intro==(uint32_t)kainPolicy108->storyIntro&&readAt(ref+16,&bound,8);
 if(authored&&bound!=root){
  ((void(*)(uintptr_t))(base+kainPolicy111->nativeRebindRva))(root);
  readAt(ref+16,&bound,8);
 }
 int16_t raw=0;
 for(unsigned i=0;i<9&&kainCinema114[i].actor;i++){
  const uintptr_t a=kainCinema114[i].actor;
  if(!kainStoryMember108(a,kainCinema114[i].generation))continue;
  int16_t opacity=0;const int16_t visible=(int16_t)kainPolicy112->visibleFade;
  if(readAt(a+kainPolicy112->fadeOffset,&opacity,2)&&opacity!=visible)
   memcpy((void*)(a+kainPolicy112->fadeOffset),&visible,2);
  if(i==0)raw=opacity;
 }
 static uint64_t last;const uint64_t now=GetTickCount64();
 if(!wasActive||now-last>=500){
  uint32_t f=0,f2=0;int16_t xyz[3]={0};uintptr_t matrix=0;
  readAt(root+0x24,&f,4);readAt(root+0x28,&f2,4);readAt(root+0x9c,xyz,6);readAt(root+0x68,&matrix,8);
  record("kain115 victory-frame queued=%u timer=%u reference=%u raw=%d flags=%x/%x xyz=%d/%d/%d matrix=%u opacity-queries=%u",
   queued,flags&1,authored&&bound==root,raw,f,f2,xyz[0],xyz[1],xyz[2],matrix!=0,kainFadeReads115);last=now;
 }
}
static bool kainStoryHidden108(uintptr_t actor){return kainStory108.suspended&&actor==kainStory108.oldActor&&generation(actor)==kainStory108.oldGeneration;}
static void kainStoryNoProcess108(uintptr_t actor,uintptr_t tracker){(void)actor;(void)tracker;}
static uintptr_t kainStoryQuery108(uintptr_t actor,uint32_t query){
 if(kainStoryHidden108(actor)&&(query==1||query==30))return 0;
 return kainStory108.callbacks[3]?((uintptr_t(*)(uintptr_t,uint32_t))kainStory108.callbacks[3])(actor,query):0;
}
static void kainStoryRestore108(void){
 const DWORD error=GetLastError();
 if(kainStoryMember108(kainStory108.oldActor,kainStory108.oldGeneration)){
  const uintptr_t replacements[4]={(uintptr_t)kainStoryNoProcess108,(uintptr_t)kainStoryNoProcess108,(uintptr_t)kainStoryNoProcess108,(uintptr_t)kainStoryQuery108};
  for(unsigned i=0;i<4;i++){uintptr_t expected=replacements[i];atomic_compare_exchange_strong((_Atomic uintptr_t*)(kainStory108.oldActor+0x198+i*8),&expected,kainStory108.callbacks[i]);}
 }
 for(unsigned i=0;i<kainStory108.hiddenCount;i++){
  const uintptr_t a=kainStory108.hidden[i].actor;if(!kainStoryMember108(a,kainStory108.hidden[i].generation))continue;
  uint32_t flags=0;if(readAt(a+0x24,&flags,4)){flags=(flags&~0x840u)|(kainStory108.hidden[i].flags&0x840u);memcpy((void*)(a+0x24),&flags,4);}
 }
 kainStory108.hiddenCount=0;kainStory108.suspended=false;SetLastError(error);
}
static bool kainStorySuspend108(void){
 if(kainStory108.suspended)return true;
 if(!kainStoryMember108(kainStory108.oldActor,kainStory108.oldGeneration))return false;
 for(unsigned i=0;i<4;i++)if(!readAt(kainStory108.oldActor+0x198+i*8,&kainStory108.callbacks[i],8))return false;
 if(!kainStory108.callbacks[0]||!kainStory108.callbacks[3])return false;
 uintptr_t child=kainStory108.oldActor;
 for(unsigned i=0;child&&i<9;i++){
  uint32_t flags=0,gen=generation(child);if(!gen||!readAt(child+0x24,&flags,4)){kainStoryRestore108();return false;}
  kainStory108.hidden[i].actor=child;kainStory108.hidden[i].generation=gen;kainStory108.hidden[i].flags=flags;kainStory108.hiddenCount=i+1;
  flags|=0x840u;memcpy((void*)(child+0x24),&flags,4);
  if(!readAt(child+(i?host->siblingOffset:host->childOffset),&child,8)){kainStoryRestore108();return false;}
 }
 const uintptr_t replacements[4]={(uintptr_t)kainStoryNoProcess108,(uintptr_t)kainStoryNoProcess108,(uintptr_t)kainStoryNoProcess108,(uintptr_t)kainStoryQuery108};
 for(unsigned i=0;i<4;i++){uintptr_t expected=kainStory108.callbacks[i];if(!atomic_compare_exchange_strong((_Atomic uintptr_t*)(kainStory108.oldActor+0x198+i*8),&expected,replacements[i])){kainStoryRestore108();return false;}}
 kainStory108.suspended=true;record("kain108 original-suspended generation=%u children=%u",kainStory108.oldGeneration,kainStory108.hiddenCount-1);return true;
}
static bool kainStoryScript108(uintptr_t event,unsigned index,unsigned words,const wchar_t *sha,uintptr_t *script){
 uintptr_t actions=0,start=0;uint16_t size=0;unsigned char bytes[6000];char digest[65];
 if(!(event&&words<=3000&&readAt(event+0x20,&actions,8)&&actions&&readAt(actions+index*8,script,8)&&*script&&
  readAt(*script,&size,2)&&size==words&&readAt(*script+8,&start,8)&&start&&readAt(start,bytes,size*2)&&
  boundedSha256(bytes,size*2,sizeof bytes,digest)))return false;
 for(unsigned i=0;i<64;i++)if(sha[i]!=(wchar_t)digest[i])return false;return sha[64]==0;
}
static bool kainStoryContext108(uintptr_t table,uintptr_t level,uintptr_t *opening,uintptr_t *victory,uintptr_t *progress){
 uint32_t count=0;uintptr_t actualTable=0;
 if(!level||!readAt(level+(uintptr_t)kainPolicy108->eventLevelTableOffset,&actualTable,8)||actualTable!=table||
  !readAt(table,&count,4)||count!=(unsigned)kainPolicy108->eventCount)return false;
 *opening=*victory=*progress=0;
 for(unsigned i=0;i<count;i++){uintptr_t e=0;int16_t id=0;if(!readAt(table+8+i*8,&e,8)||!e||!readAt(e,&id,2))return false;if(id==kainPolicy108->openingEvent)*opening=e;if(id==kainPolicy108->victoryEvent)*victory=e;if(id==2)*progress=e;}
 uint8_t oa=0,va=0,pa=0;if(!*opening||!*victory||!*progress||!readAt(*opening+4,&oa,1)||oa!=1||!readAt(*victory+4,&va,1)||va!=1||!readAt(*progress+4,&pa,1)||pa!=6)return false;
 uintptr_t script=0;return (kainStoryScript108(*opening,0,(unsigned)kainPolicy108->openingWords,kainPolicy108->openingSha,&script)||
  kainStoryScript108(*opening,0,(unsigned)kainPolicy108->openingWords,kainPolicy109->openingRuntimeSha,&script))&&
  kainStoryScript108(*victory,0,(unsigned)kainPolicy108->victoryWords,kainPolicy108->victorySha,&script)&&
  kainStoryScript108(*progress,2,29,L"c93fccb76be54c765c41cc0f920acf8767e4a58b8eb944b8efbc2ff3b43328cb",&script);
}
static bool kainStoryOld108(void){
 uintptr_t list=0,node=0;if(!readAt(base+contactPolicy->listRva,&list,8)||!list||!readAt(list+8,&node,8))return false;
 for(unsigned i=0;node&&i<512;i++){
  uint32_t intro=0,world=0;uintptr_t message=0;
  if(readAt(node+0x64,&intro,4)&&intro==(unsigned)kainPolicy108->storyIntro&&readAt(node+0x60,&world,4)&&(world==(unsigned)kainPolicy108->storyStream||world==(unsigned)kainPolicy109->originalAuthoredStream)&&
   readAt(node+0x1b8,&message,8)&&message==base+0x95960){kainStory108.oldActor=node;kainStory108.oldGeneration=generation(node);return kainStory108.oldGeneration!=0;}
  if(!readAt(node+0x10,&node,8))return false;
 }return false;
}
static void kainStoryMaintain117(void){
 if((!kainStory108.suspended&&!kainStory108.owned&&!kainStory108.pending)||kainStory108.committed||!InterlockedCompareExchange(&portableActive60,0,0))return;
 if(kainCinematic118()||kainStory108.cinemaPaused118)return;
 if(!kainStory108.suspended||!kainStoryMember108(kainStory108.oldActor,kainStory108.oldGeneration)){
  kainStoryRestore108();
  if(kainStoryOld108()&&kainStorySuspend108())record("kain117 original-rebound generation=%u",kainStory108.oldGeneration);
  return;
 }
 const uintptr_t replacements[4]={(uintptr_t)kainStoryNoProcess108,(uintptr_t)kainStoryNoProcess108,(uintptr_t)kainStoryNoProcess108,(uintptr_t)kainStoryQuery108};
 for(unsigned i=0;i<4;i++){
  uintptr_t expected=kainStory108.callbacks[i];
  atomic_compare_exchange_strong((_Atomic uintptr_t*)(kainStory108.oldActor+0x198+i*8),&expected,replacements[i]);
 }
 for(unsigned i=0;i<kainStory108.hiddenCount;i++){
  const uintptr_t actor=kainStory108.hidden[i].actor;uint32_t flags=0;
  if(kainStoryMember108(actor,kainStory108.hidden[i].generation)&&readAt(actor+0x24,&flags,4)&&(flags&0x840u)!=0x840u){
   flags|=0x840u;memcpy((void*)(actor+0x24),&flags,4);
   record("kain117 original-hide-restored generation=%u",kainStory108.hidden[i].generation);
  }
 }
}
static bool kainStoryCenter108(uintptr_t level){
 uint32_t count=0;uintptr_t markers=0;if(!readAt(level+0x180,&count,4)||!count||count>2048||!readAt(level+0x188,&markers,8)||!markers)return false;
 for(unsigned i=0;i<count;i++){int16_t m[4];if(!readAt(markers+i*8,m,8))return false;if(m[3]==kainPolicy108->centerMarker){memcpy(kainStory108.center,m,6);return true;}}return false;
}
static void kainStoryDoor110(uintptr_t event,uintptr_t script,uintptr_t cursor){
 if(!InterlockedCompareExchange(&portableActive60,0,0)||kainStory108.owned||kainStory108.committed||kainStory108.failed||kainStory108.doorSeen110)return;
 uintptr_t actor=0,level=0,table=0,opening=0,victory=0,progress=0,verified=0,start=0;uint32_t world=0,realm=0;int16_t id=0;
 if(!readAt(event,&id,2)||id!=kainPolicy110->doorEvent||!readAt(base+host->actorRva,&actor,8)||!actor||!generation(actor)||
  !readAt(actor+0x60,&world,4)||(world!=31442u&&world!=31443u)||!readAt(base+44600604,&realm,4)||realm!=1||
  !readAt(base+0x2bb608,&level,8)||!level||((uintptr_t(*)(int32_t))(base+0x115b00))(31442)!=level||
  !readAt(level+(uintptr_t)kainPolicy108->eventLevelTableOffset,&table,8)||!kainStoryContext108(table,level,&opening,&victory,&progress)||progress!=event||
  !kainStoryScript108(event,(unsigned)kainPolicy110->doorAction,(unsigned)kainPolicy110->doorWords,kainPolicy110->doorSha,&verified)||verified!=script||
  !readAt(script+8,&start,8)||start!=cursor)return;
 kainStory108.player=actor;kainStory108.playerGeneration=generation(actor);kainStory108.level=level;kainStory108.table=table;kainStory108.opening=opening;kainStory108.victory=victory;kainStory108.progress=progress;kainStory108.doorSeen110=true;
 kainStatusCapture114(actor);
 if(!kainStory108.modelRequested109){((uintptr_t(*)(const char*))(base+0x115b40))("ronin");kainStory108.modelRequested109=true;}
 record("kain110 door-open-preload intro=%lld original-action-unchanged=1 wait-for-scene-or-skip=1",(long long)kainPolicy110->doorIntro);
}
static bool kainCapacityReady110(uint64_t now){
 uintptr_t list=0,pool=0,first=0;uint32_t freeActors=0;
 const bool valid=readAt(base+contactPolicy->listRva,&list,8)&&list&&readAt(list+16,&pool,8)&&pool&&readAt(pool+4,&freeActors,4)&&
  freeActors<=(unsigned)kainPolicy110->maximumFreeActors&&readAt(pool+(uintptr_t)kainPolicy110->freeListOffset,&first,8)&&(!freeActors||first);
 const bool ready=valid&&freeActors>=(unsigned)kainPolicy110->minimumFreeActors;
 static uint64_t last;static uint32_t previous=UINT_MAX;
 if(freeActors!=previous||now-last>=(uint64_t)kainPolicy110->capacityLogMs){last=now;previous=freeActors;record("kain110 capacity valid=%u free=%u required=%lld ready=%u waiting=%u",valid,freeActors,(long long)kainPolicy110->minimumFreeActors,ready,!ready);}
 // No birth or room-actor removal on shortage. Keep the same request/pin;
 // Off/player-generation/world guards in the frame owner still cancel it.
 if(!ready)sluagh80.requested=now;return ready;
}
static void kainStoryReset108(void){kainVictoryActive115=false;kainFadeReads115=0;kainStatusRestore114();kainStoryRestore108();memset(&kainStory108,0,sizeof kainStory108);memset(kainCinema114,0,sizeof kainCinema114);}
static void kainStoryPoll108(bool active,uintptr_t actor,uint32_t world){
 if(!active&&kainShortcutWaiting113()&&actor==kainStory108.player&&generation(actor)==kainStory108.playerGeneration)return;
 if(active)kainShortcut113=false;
 if(!active||!actor||actor!=kainStory108.player||generation(actor)!=kainStory108.playerGeneration){if(kainStory108.player)kainStoryReset108();return;}
 kainStoryMaintain117();
 if(world!=(unsigned)kainPolicy108->storyStream&&world!=31443u&&!kainStory108.owned&&!kainStory108.pending)kainStoryReset108();
}
static bool kainStorySpawn108(void){return kainStory108.pending&&!kainStory108.failed&&!kainStory108.committed;}
static bool kainStoryBorn108(void){
 if(kainStory108.owned&&!kainStory108.committed){kainStoryMaintain117();return true;}
 if(!kainStorySpawn108())return true;
 if(!kainStorySuspend108()){kainStory108.failed=true;kainStory108.pending=false;return false;}
 kainStory108.pending=false;kainStory108.owned=true;record("kain108 replacement-born generation=%u center=%d/%d/%d",sluagh80.generation,kainStory108.center[0],kainStory108.center[1],kainStory108.center[2]);return true;
}
static void kainStoryFailure108(void){
 if(!kainStory108.owned&&!kainStory108.pending)return;
 if(kainKeep93&&kainEncounter93.saved)return;
 if(!kainStory108.committed){kainStoryRestore108();kainStory108.owned=kainStory108.pending=false;kainStory108.failed=true;record("kain108 replacement-released original-restored=1 story-completed=0");}
}
static bool kainStoryVisible111(uintptr_t actor,uint32_t gen){
 if(!kainStoryMember108(actor,gen))return false;
 // Authored mod-side Unhide instruction, interpreted by the original engine.
 // TLS storage remains valid after EVENT_DoAction's current-script pointer.
 // No scene asset, animation or quest-progress script is replaced.
 static _Thread_local unsigned char event[0x28],script[16],reference[32];
 static _Thread_local uintptr_t references[1];
 static _Thread_local int16_t code[11];
 const int16_t unhide[11]={8,5,1,0,2,11,12,1,3,5,9};memcpy(code,unhide,sizeof code);
 memset(event,0,sizeof event);memset(script,0,sizeof script);memset(reference,0,sizeof reference);
 const int16_t one=1,words=(int16_t)kainPolicy111->unhideWords;memcpy(event+2,&one,2);event[4]=1;memcpy(script,&words,2);memcpy(reference,&one,2);
 const uintptr_t data=(uintptr_t)code,ref=(uintptr_t)reference;references[0]=ref;
 const uintptr_t list=(uintptr_t)references;memcpy(event+0x10,&list,8);memcpy(script+8,&data,8);memcpy(reference+(uintptr_t)kainPolicy111->actorRefOffset,&actor,8);
 uint32_t before=0,after=0,before2=0,after2=0;readAt(actor+0x24,&before,4);readAt(actor+0x28,&before2,4);readAt(actor+0x60,reference+4,4);readAt(actor+0x64,reference+8,4);
 int16_t fadeBefore=0;const int16_t visibleFade=(int16_t)kainPolicy112->visibleFade;
 if(!readAt(actor+(uintptr_t)kainPolicy112->fadeOffset,&fadeBefore,2))return false;
 memcpy((void*)(actor+(uintptr_t)kainPolicy112->fadeOffset),&visibleFade,2);
 uintptr_t previousEvent=0,previousLevel=0;int16_t previousAbort=0;readAt(base+0x2bb510,&previousEvent,8);readAt(base+0x2bb608,&previousLevel,8);readAt(base+0x2bb520,&previousAbort,2);
 const uintptr_t current=(uintptr_t)event;const int16_t zero=0;memcpy((void*)(base+0x2bb510),&current,8);memcpy((void*)(base+0x2bb608),&kainStory108.level,8);memcpy((void*)(base+0x2bb520),&zero,2);
 const int result=((int(*)(uintptr_t,uintptr_t,uintptr_t))(base+0x45730))(current,(uintptr_t)script,data);
 memcpy((void*)(base+0x2bb510),&previousEvent,8);memcpy((void*)(base+0x2bb608),&previousLevel,8);memcpy((void*)(base+0x2bb520),&previousAbort,2);
 if(!kainStoryMember108(actor,gen))return false;
 ((void(*)(uintptr_t))(base+(uintptr_t)kainPolicy111->nativeRebindRva))(actor);
 readAt(actor+0x24,&after,4);readAt(actor+0x28,&after2,4);
 const int fade=((int(*)(uintptr_t))(base+(uintptr_t)kainPolicy112->fadeQueryRva))(actor);int16_t position[3]={0};uintptr_t matrix=0,process=0;readAt(actor+0x9c,position,6);readAt(actor+0x68,&matrix,8);readAt(actor+0x198,&process,8);
 record("kain112 cinematic-state generation=%u fade=%d/%d xyz=%d/%d/%d matrix=%u process=%llx",gen,fadeBefore,fade,position[0],position[1],position[2],matrix!=0,(unsigned long long)(process?process-base:0));
 record("kain111 cinematic-visible generation=%u result=%d flags=%x/%x flags2=%x/%x native-rebound=1",gen,result,before,after,before2,after2);
 return result==1&&!(after&0x800u);
}
static void kainStoryVictoryVisible111(void){
 memset(kainCinema114,0,sizeof kainCinema114);
 uintptr_t actor=kainStory108.oldActor;
 for(unsigned i=0;actor&&i<9;i++){
  const uint32_t gen=generation(actor);if(!gen||!kainStoryVisible111(actor,gen))break;
  kainCinema114[i].actor=actor;kainCinema114[i].generation=gen;
  if(!readAt(actor+(i?host->siblingOffset:host->childOffset),&actor,8))break;
 }
}
static bool kainStoryDefeat108(void){
 if(!kainStory108.owned||kainStory108.committed||sluagh80.hp>0||!sluaghMember80())return false;
 uintptr_t opening=0,victory=0,progress=0,script=0,start=0;uint8_t playing=0;
 if(!kainStoryContext108(kainStory108.table,kainStory108.level,&opening,&victory,&progress)||victory!=kainStory108.victory||
  !readAt(victory+5,&playing,1)||playing||!kainStoryMember108(kainStory108.oldActor,kainStory108.oldGeneration)||
  !kainStoryScript108(progress,2,29,L"c93fccb76be54c765c41cc0f920acf8767e4a58b8eb944b8efbc2ff3b43328cb",&script)||!readAt(script+8,&start,8))return false;
 kainStory108.committed=true;kainStory108.owned=false;kainStory108.pending=false;
 // Remove private enemy and every owned effect first. Native original actor
 // must be restored before its authored cinematic starts resolving objects.
 sluaghCleanup80();kainStatusRestore114();kainStoryRestore108();kainStoryVictoryVisible111();
 uintptr_t previousEvent=0,previousLevel=0;int16_t previousAbort=0;readAt(base+0x2bb510,&previousEvent,8);readAt(base+0x2bb608,&previousLevel,8);readAt(base+0x2bb520,&previousAbort,2);
 memcpy((void*)(base+0x2bb510),&progress,8);memcpy((void*)(base+0x2bb608),&kainStory108.level,8);const int16_t zero=0;memcpy((void*)(base+0x2bb520),&zero,2);
 const int result=((int(*)(uintptr_t,uintptr_t,uintptr_t))(base+0x45730))(progress,script,start);
 memcpy((void*)(base+0x2bb510),&previousEvent,8);memcpy((void*)(base+0x2bb608),&previousLevel,8);memcpy((void*)(base+0x2bb520),&previousAbort,2);
 readAt(victory+5,&playing,1);record("kain108 native-victory action-result=%d scene=%d playing=%u once=1",result,(int)kainPolicy108->victoryEvent,playing);
 kainFadeReads115=0;kainVictoryFrame115(kainStory108.table,kainStory108.level);return true;
}
static void kainStoryJoin109(const Sr1LocalFrame *frame,uintptr_t actor,uint64_t now){
 if(!InterlockedCompareExchange(&portableActive60,0,0)||!actor||frame->realm!=1||frame->worldGeneration!=(unsigned)kainPolicy108->storyStream||
  kainStory108.committed||kainStory108.owned||kainStory108.pending||kainStory108.failed||sluagh80.player)return;
 const uintptr_t level=((uintptr_t(*)(int32_t))(base+0x115b00))((int32_t)kainPolicy108->storyStream);uintptr_t table=0,opening=0,victory=0,progress=0,script=0;unsigned reason=0;
 if(!level||!readAt(level+(uintptr_t)kainPolicy108->eventLevelTableOffset,&table,8)||!kainStoryContext108(table,level,&opening,&victory,&progress))reason=1;
 uint8_t playing=0;uint16_t waiting=0;int16_t vars[5]={0};
 if(!reason){if(!readAt(opening+5,&playing,1)||playing)reason=2;else if(!kainStoryScript108(opening,0,(unsigned)kainPolicy108->openingWords,kainPolicy108->openingSha,&script)&&!kainStoryScript108(opening,0,(unsigned)kainPolicy108->openingWords,kainPolicy109->openingRuntimeSha,&script))reason=1;}
 if(!reason&&(!readAt(script+2,&waiting,2)||(waiting&(unsigned)kainPolicy109->openingPendingMask)))reason=2;
 if(!reason&&(!readAt(progress+6,vars,sizeof vars)||vars[0]!=1||vars[2]!=0))reason=3;
 if(!reason&&(!frame->ready||!frame->grounded||!kainGameplayReady113(frame)))reason=4;
 if(!reason&&!InterlockedCompareExchange(&sluaghReady80,0,0))reason=5;
 if(!reason&&(!kainStoryOld108()||!kainStoryCenter108(level)))reason=6;
 if(!reason){const uintptr_t info=((QueryInstance)(base+signals->queryRva))(kainStory108.oldActor,30);if(info&1u)reason=3;}
 static uint64_t last;static unsigned previous=UINT_MAX;
 if(reason){if(reason!=previous||now-last>=1000){previous=reason;last=now;record("kain109 join-wait reason=%u vars=%d/%d/%d script-flags=%x ready=%u grounded=%u render=%u resources=%ld",reason,vars[0],vars[1],vars[2],waiting,frame->ready,frame->grounded,frame->renderBlend,sluaghReady80);}return;}
 kainStory108.player=actor;kainStory108.playerGeneration=generation(actor);kainStory108.level=level;kainStory108.table=table;kainStory108.opening=opening;kainStory108.victory=victory;kainStory108.progress=progress;
 kainStatusCapture114(actor); // unfinished-save fallback; real door snapshot wins
 if(!kainStory108.modelRequested109){((uintptr_t(*)(const char*))(base+0x115b40))("ronin");kainStory108.modelRequested109=true;}
 kainStory108.pending=true;InterlockedCompareExchange(&sluaghCommand80,1,0);previous=UINT_MAX;
 uint32_t nativeWorld=0;readAt(kainStory108.oldActor+0x60,&nativeWorld,4);record("kain109 unfinished-encounter accepted=1 observed-opening=%u original-stream=%u pending-script=0",kainStory108.openingSeen,nativeWorld);
}
static void kainEvents108(uintptr_t table,uintptr_t level){
 const DWORD error=GetLastError();uintptr_t actor=0;uint32_t world=0;readAt(base+host->actorRva,&actor,8);if(actor)readAt(actor+0x60,&world,4);
 const bool active=InterlockedCompareExchange(&portableActive60,0,0)!=0;
 uintptr_t opening=0,victory=0,progress=0;uint8_t before=0;
 const bool context=active&&actor&&(world==(unsigned)kainPolicy108->storyStream||world==31443u)&&
  ((uintptr_t(*)(int32_t))(base+0x115b00))((int32_t)kainPolicy108->storyStream)==level&&kainStoryContext108(table,level,&opening,&victory,&progress);
 if(context){
  if(!kainStory108.player){kainStory108.player=actor;kainStory108.playerGeneration=generation(actor);}
  // A reloaded room owns a new event table even when the player is unchanged.
  kainStory108.level=level;kainStory108.table=table;kainStory108.opening=opening;kainStory108.victory=victory;kainStory108.progress=progress;
  readAt(opening+5,&before,1);
  if(before&&!kainStory108.openingSeen){kainStory108.openingSeen=true;if(!kainStory108.modelRequested109){((uintptr_t(*)(const char*))(base+0x115b40))("ronin");kainStory108.modelRequested109=true;}record("kain108 opening-seen preload-requested=1 original-scene-unchanged=1");}
 }
 if(context)kainScenePause118();
 SetLastError(error);kainOriginalEvents108(table,level);const DWORD resultError=GetLastError();
 if(context)kainScenePause118();
 kainVictoryFrame115(table,level);
 if(context){const Sr1LocalFrame frame=readLocalFrame(true);kainStoryJoin109(&frame,actor,GetTickCount64());}
 SetLastError(resultError);
}
static bool kainStoryPrepare108(void){
 if(!matches((uintptr_t)kainPolicy114->nativeFadeRva,(unsigned char[]){0x48,0x83,0xec,0x08,0x48,0x8b,0x41,0x30},8)||
 MH_CreateHook((void*)(base+(uintptr_t)kainPolicy114->nativeFadeRva),kainFade114,(void**)&kainOriginalFade114)!=MH_OK||
 MH_CreateHook((void*)(base+0x55a00),kainSpiral114,(void**)&kainOriginalSpiral114)!=MH_OK)return false;
 const unsigned char entry[]={0x40,0x55,0x41,0x54,0x41,0x55,0x48,0x83,0xec,0x30};
 const unsigned char bindEntry[]={0x48,0x89,0x5c,0x24,0x08,0x48,0x89,0x6c,0x24,0x10};
 return matches((uintptr_t)kainPolicy112->fadeQueryRva,(unsigned char[]){0x40,0x53,0x48,0x83,0xec,0x20,0x0f,0xbf,0x81,0x90,0x01,0,0},13)&&
 MH_CreateHook((void*)(base+kainPolicy112->fadeQueryRva),kainOpacity115,(void**)&kainOriginalOpacity115)==MH_OK&&matches((uintptr_t)kainPolicy111->nativeRebindRva,bindEntry,sizeof bindEntry)&&matches((uintptr_t)kainPolicy108->eventsRva,entry,sizeof entry)&&MH_CreateHook((void*)(base+(uintptr_t)kainPolicy108->eventsRva),kainEvents108,(void**)&kainOriginalEvents108)==MH_OK;
}
