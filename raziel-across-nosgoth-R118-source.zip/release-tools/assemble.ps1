param([switch]$Refresh)
$ErrorActionPreference='Stop'
Add-Type -AssemblyName System.IO.Compression.FileSystem
$releaseRoot118=Split-Path (Split-Path $PSScriptRoot)
$stage118=Join-Path $PSScriptRoot 'build'
$source118=Join-Path $stage118 'source'
$payload118=Join-Path $stage118 'payload'
$publish118=Join-Path $releaseRoot118 'output/R118'
function Hash118([string]$file){(Get-FileHash -LiteralPath $file).Hash.ToLowerInvariant()}
function Zip118([string]$directory,[string]$destination,[switch]$Sources){
 if(Test-Path -LiteralPath $destination){throw "Archive already exists $destination"}
 $zip118=[IO.Compression.ZipFile]::Open($destination,[IO.Compression.ZipArchiveMode]::Create)
 try{foreach($file118 in Get-ChildItem -LiteralPath $directory -Recurse -File){
  $relative118=[IO.Path]::GetRelativePath($directory,$file118.FullName).Replace('\','/')
  if($Sources -and ($relative118.StartsWith('rebuilt-helpers/') -or $file118.Extension -in '.exe','.asi','.dll','.pdb','.d')){continue}
  [IO.Compression.ZipFileExtensions]::CreateEntryFromFile($zip118,$file118.FullName,$relative118,[IO.Compression.CompressionLevel]::Optimal)|Out-Null
 }}finally{$zip118.Dispose()}
}
$native118=Join-Path $source118 'workbench/defiance-kain-r1/build/gameplay80/SR1LocalController.asi'
Copy-Item -LiteralPath $native118 -Destination (Join-Path $payload118 'scripts/SR1LocalController.asi')
foreach($name118 in 'RazielBootstrap.exe','RazielUpdater.exe','Uninstall R60.exe'){
 Copy-Item -LiteralPath (Join-Path $source118 "rebuilt-helpers/$name118") -Destination (Join-Path $payload118 "RazielR60/$name118")
}
$runtimeManifest118='RazielR60/runtime/workbench/sr1-local-controller-test/build/defiance-combat-r60/host-manifest.json'
$manifest118=Get-Content -LiteralPath (Join-Path $payload118 $runtimeManifest118) -Raw|ConvertFrom-Json
$manifest118.sha256=Hash118 $native118
$manifest118|Add-Member -NotePropertyName release -NotePropertyValue 'R118' -Force
$manifest118|ConvertTo-Json -Depth 20 -Compress|Set-Content -LiteralPath (Join-Path $payload118 $runtimeManifest118) -Encoding utf8NoBOM
Copy-Item -LiteralPath (Join-Path $payload118 $runtimeManifest118) -Destination (Join-Path $source118 'runtime/workbench/sr1-local-controller-test/build/defiance-combat-r60/host-manifest.json')
$credits118=Join-Path $payload118 'RazielR60/licenses/CREDITS.txt'
[IO.File]::WriteAllText($credits118,[IO.File]::ReadAllText($credits118).Replace('R79','R118'))
foreach($file118 in 'prepare.mjs','assemble.ps1','serve-release118.mjs','scope.json'){
 $tools118=Join-Path $source118 'release-tools'
 New-Item -ItemType Directory -Force -Path $tools118|Out-Null
 Copy-Item -LiteralPath (Join-Path $PSScriptRoot $file118) -Destination (Join-Path $tools118 $file118)
}
Copy-Item -LiteralPath (Join-Path $publish118 '03-GitHub/repository/README.txt') -Destination (Join-Path $payload118 'RazielR60/README.txt')
$sourceZip118=Join-Path $publish118 '03-GitHub/raziel-across-nosgoth-R118-source.zip'
Zip118 $source118 $sourceZip118 -Sources
Copy-Item -LiteralPath $sourceZip118 -Destination (Join-Path $payload118 'RazielR60/SOURCE.zip') -Force
$inventory118=@(Get-ChildItem -LiteralPath $payload118 -Recurse -File|Where-Object FullName -ne (Join-Path $payload118 'RazielR60/package.json')|ForEach-Object{
 @{path=[IO.Path]::GetRelativePath($payload118,$_.FullName).Replace('\','/');sha256=Hash118 $_.FullName}
})
@{version='R118';files=$inventory118}|ConvertTo-Json -Depth 8|Set-Content -LiteralPath (Join-Path $payload118 'RazielR60/package.json') -Encoding utf8NoBOM
$payloadZip118=Join-Path $publish118 '01-Copy-Paste/R118-Copy-Paste.zip'
Zip118 $payload118 $payloadZip118
& (Join-Path $source118 'Build-Helpers.ps1') -PayloadZip $payloadZip118
if($LASTEXITCODE -ne 0){throw 'Setup rebuild failed'}
$installer118=Join-Path $publish118 '02-Installer/Raziel R118 Setup.exe'
Copy-Item -LiteralPath (Join-Path $source118 'rebuilt-helpers/Raziel R118 Setup.exe') -Destination $installer118
Copy-Item -LiteralPath $installer118 -Destination (Join-Path $publish118 '03-GitHub/Raziel.R118.Setup.exe')
$wrapper118=Join-Path $stage118 'installer-wrapper'
New-Item -ItemType Directory -Force -Path $wrapper118|Out-Null
Copy-Item -LiteralPath $installer118 -Destination $wrapper118
Copy-Item -LiteralPath (Join-Path $publish118 '02-Installer/README.txt') -Destination $wrapper118
Zip118 $wrapper118 (Join-Path $publish118 '03-GitHub/Raziel-R118-Installer.zip')
$checks118=@('Raziel-R118-Installer.zip','Raziel.R118.Setup.exe','raziel-across-nosgoth-R118-source.zip')|ForEach-Object{
 (Hash118 (Join-Path $publish118 "03-GitHub/$_"))+'  '+$_
}
$checks118|Set-Content -LiteralPath (Join-Path $publish118 '03-GitHub/SHA256SUMS.txt') -Encoding utf8NoBOM
Copy-Item -LiteralPath $sourceZip118 -Destination (Join-Path $publish118 '03-GitHub/repository/raziel-across-nosgoth-R118-source.zip')
Copy-Item -LiteralPath (Join-Path $publish118 '03-GitHub/SHA256SUMS.txt') -Destination (Join-Path $publish118 '03-GitHub/repository/SHA256SUMS.txt')
@{release='R118';nativeSHA256=(Hash118 $native118);packageFiles=$inventory118.Count;directInstallerBytes=(Get-Item $installer118).Length;sourceSHA256=(Hash118 $sourceZip118)}|ConvertTo-Json|Set-Content -LiteralPath (Join-Path $releaseRoot118 'reports/release118/assembled.json')
Get-Content -LiteralPath (Join-Path $releaseRoot118 'reports/release118/assembled.json')
