// SPDX-License-Identifier: GPL-3.0-or-later
// Both resource packets are decoded from the selected installations in RAM.
import net from 'node:net';
import assert from 'node:assert/strict';
import {gameplayResource} from '../defiance-kain-r1/gameplay-resource.mjs';
await import('../sr1-local-controller-test/serve-ground-poses.mjs');
const pid=Number(process.argv[2]);
assert(Number.isInteger(pid)&&pid>0&&pid<=0xffffffff);
const {payload}=gameplayResource();
const count=Buffer.alloc(4);count.writeUInt32LE(payload.length);
const deadline=Date.now()+60000;
await new Promise((resolve,reject)=>{
 function connect(){
  const client=net.createConnection('\\\\.\\pipe\\SR1KainResource92-'+pid);
  client.setTimeout(10000,()=>client.destroy(new Error('Kain resource transfer timed out')));
  client.once('connect',()=>client.end(Buffer.concat([count,payload])));
  client.once('error',error=>{
   if(error.code==='ENOENT'&&Date.now()<deadline)setTimeout(connect,100);
   else reject(error);
  });
  client.once('close',error=>{if(!error)resolve();});
 }
 connect();
});
console.log('R118 Kain resources delivered in RAM.');
