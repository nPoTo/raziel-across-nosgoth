// SPDX-License-Identifier: GPL-3.0-or-later
using System;using System.IO;using System.Drawing;using System.Reflection;using System.Windows.Forms;
internal static class Setup60 {
 [STAThread]static int Main(){Application.EnableVisualStyles();Application.SetCompatibleTextRenderingDefault(false);Application.Run(new Wizard60());return 0;}
 sealed class Wizard60:Form {
  int step;Label title,body;TextBox host,donor;Button next,back,browseHost,browseDonor;string selected;
  internal Wizard60(){Text="Raziel R73 Setup";Width=740;Height=490;StartPosition=FormStartPosition.CenterScreen;FormBorderStyle=FormBorderStyle.FixedDialog;MaximizeBox=false;
   title=new Label{Left=24,Top=20,Width=670,Height=40,Font=new Font("Segoe UI",17,FontStyle.Bold)};body=new Label{Left=24,Top=76,Width=670,Height=145,Font=new Font("Segoe UI",10)};
   host=new TextBox{Left=24,Top=238,Width=555,Text=PortableCore60.Detect("Soul Reaver I-II")};donor=new TextBox{Left=24,Top=302,Width=555,Text=PortableCore60.ReadDonor()};if(!PortableCore60.Donor(donor.Text))donor.Text=PortableCore60.Detect("Legacy of Kain Defiance Remastered");
   browseHost=new Button{Left=592,Top=237,Width=94,Text="SR1..."};browseDonor=new Button{Left=592,Top=301,Width=94,Text="Defiance..."};browseHost.Click+=(s,e)=>Browse(host);browseDonor.Click+=(s,e)=>Browse(donor);
   next=new Button{Left=570,Top=390,Width=116,Height=32};back=new Button{Left=440,Top=390,Width=116,Height=32,Text="Back"};var cancel=new Button{Left=24,Top=390,Width=116,Height=32,Text="Cancel"};cancel.Click+=(s,e)=>Close();back.Click+=(s,e)=>{step--;ShowStep();};next.Click+=(s,e)=>Advance();Controls.AddRange(new Control[]{title,body,host,donor,browseHost,browseDonor,next,back,cancel});ShowStep();
  }
  void Browse(TextBox text){using(var d=new FolderBrowserDialog{SelectedPath=text.Text})if(d.ShowDialog()==DialogResult.OK)text.Text=d.SelectedPath;}
  void ShowStep(){back.Visible=step==1||step==2;bool folders=step==1;body.Height=folders?145:280;host.Visible=donor.Visible=browseHost.Visible=browseDonor.Visible=folders;next.Text=step==2?"Install":step==3?"Finish":"Next";
   if(step==0){title.Text="Welcome";body.Text="Raziel R73 local test package\n\nRequires supported Soul Reaver 1 & 2 Remastered and Defiance Remastered installed on this PC. Defiance does not need to run.\n\nClose both games. Existing saves are preserved. No original game archives are included. F10 toggles the mod; F7 opens the guide. This candidate still needs your gameplay test.";}
   if(step==1){title.Text="Game folders";body.Text="Choose the SR1 root containing SRX.exe and 1\\sr1.dll.\nChoose Defiance Remastered containing defiance.exe and bigfile.x64.dat.\n\nSelect SR1 below, then Defiance. Unsupported SRX builds and conflicting mod files are refused before installation.";}
   if(step==2){title.Text="Ready to install";body.Text="Install into:\n"+host.Text+"\n\nRead resources from:\n"+donor.Text+"\n\nChanged owned files are backed up under %LOCALAPPDATA%\\RazielAcrossNosgoth\\R60. No saves or original archives are overwritten.";}
   if(step==3){title.Text="Installation complete";body.Text="Launch SR1 from Steam, SRX.exe or your existing shortcut. Load your save. The first resource preparation takes time; F10 can queue activation. Then F10 switches On/Off.\n\nF7: guide; F6: base Reaver On/Off; F9: all powers toggle (temporarily suspends the mod). Cheats can persist when the game saves. Native Debug: F10 Off, then E + left click or B + X.\n\nUninstall: RazielR60\\Uninstall R60.exe.\n\n"+selected;}
  }
  void Advance(){try{if(step==3){Close();return;}if(step==1){if(!PortableCore60.GamesClosed())throw new IOException("Close both games before continuing.");if(!PortableCore60.Host(host.Text))throw new IOException("Unsupported SR1 folder/build.");if(!PortableCore60.Donor(donor.Text))throw new IOException("Defiance folder not found.");}if(step==2){next.Enabled=false;back.Enabled=false;Application.DoEvents();using(var p=Assembly.GetExecutingAssembly().GetManifestResourceStream("payload.zip")){if(p==null)throw new IOException("Missing embedded payload");var result=InstallEngine60.Install(p,host.Text,donor.Text);selected="Files installed: "+result.files.Length;}next.Enabled=true;}step++;ShowStep();}catch(Exception ex){next.Enabled=true;MessageBox.Show(ex.Message,"Raziel R73 Setup",MessageBoxButtons.OK,MessageBoxIcon.Error);ShowStep();}}
 }
}

