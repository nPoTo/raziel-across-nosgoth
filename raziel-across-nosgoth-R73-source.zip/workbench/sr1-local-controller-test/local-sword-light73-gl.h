// SPDX-License-Identifier: GPL-3.0-or-later
#pragma once
#include "local-light-transaction73.h"
#include "../../output/github-v0.2-staging/source/workbench/reaver-force-on-r20/native/shader-source-reader.h"
static PFNGLUNIFORM4FVPROC localUniform73;
static _Thread_local bool localLightFailed73;
typedef struct{GLuint program;uint64_t frame;GLint position,color;bool allowed;}LocalLightProgram73;
static _Thread_local LocalLightProgram73 localLightPrograms73[64];static _Thread_local unsigned localLightProgramsCount73;static _Thread_local HGLRC localLightContext73;
static bool localLightHashes73(const char*v,const char*f){return !strcmp(v,"2e9d8aca544f52c43f0577a1e694b9ee99e4d9c71ec95e90c6538b049f0e6de6")&&(!strcmp(f,"c5409ef638c1b75b951e2d5117a52b53fb59aceea26310acf202dfbf09daf33b")||!strcmp(f,"f169337c2bfffbd23b9c18102175bd50efa5adb24f7733c4bfcdb73eedfe0715")||!strcmp(f,"edc9f50076f29e9ccc7a586517515c8222ed7ed02321a62942680af3a355f333"));}
static LocalLightProgram73*localLightProgram73(GLuint program){
 const HGLRC context=wglGetCurrentContext();if(context!=localLightContext73){memset(localLightPrograms73,0,sizeof localLightPrograms73);localLightProgramsCount73=0;localLightContext73=context;localLightFailed73=false;}
 LocalLightProgram73*p=NULL;for(unsigned i=0;i<localLightProgramsCount73;i++)if(localLightPrograms73[i].program==program)p=&localLightPrograms73[i];
 if(!p){if(localLightProgramsCount73==64)return NULL;p=&localLightPrograms73[localLightProgramsCount73++];p->program=program;}
 const uint64_t frame=localBladeFrame();if(p->frame==frame)return p->allowed?p:NULL;p->frame=frame;p->allowed=false;p->position=p->color=-1;
 GLint linked=0,attached=0;ghGetProgramiv(program,GL_LINK_STATUS,&linked);ghGetProgramiv(program,GL_ATTACHED_SHADERS,&attached);if(!linked||attached!=2)return NULL;
 shaderInit();if(!shaderReady)return NULL;GLuint shaders[2];GLsizei count=0;shaderAttached(program,2,&count,shaders);if(count!=2)return NULL;
 char vertex[65]={0},fragment[65]={0};for(unsigned i=0;i<2;i++){ShaderRecord s={0};if(!shaderRead(program,shaders[i],&s))return NULL;char*target=s.type==GL_VERTEX_SHADER?vertex:s.type==GL_FRAGMENT_SHADER?fragment:NULL;
  const bool valid=target&&!target[0]&&boundedSha256(s.source,(DWORD)s.length,65536,target);HeapFree(GetProcessHeap(),0,s.source);if(!valid)return NULL;}
 if(!localLightHashes73(vertex,fragment))return NULL;
 GLint active=0;ghGetProgramiv(program,GL_ACTIVE_UNIFORMS,&active);if(active<0||active>1024)return NULL;
 for(GLuint i=0;i<(GLuint)active;i++){char name[256]={0};GLsizei length=0;GLint size=0,block=0;GLenum type=0;cglGetActiveUniform(program,i,sizeof name,&length,&size,&type,name);if(length<=0||length>=255||type!=GL_FLOAT_VEC4||size!=1)continue;
  const char*tail=strrchr(name,'.');tail=tail?tail+1:name;GLint*location=!strcmp(tail,"uLightPos[0]")?&p->position:!strcmp(tail,"uLightCol[0]")?&p->color:NULL;if(!location)continue;
  cglGetActiveUniformsiv(program,1,&i,GL_UNIFORM_BLOCK_INDEX,&block);if(block!=-1||*location>=0)return NULL;*location=ghGetUniformLocation(program,name);if(*location<0)return NULL;}
 p->allowed=p->position>=0&&p->color>=0;return p->allowed?p:NULL;
}
typedef struct{GLuint program;GLenum mode,type;GLsizei count;const void*indices;DWORD error;}LocalLightDrawContext73;
static void localLightUniform73(void*opaque,int location,float values[4],bool read){LocalLightDrawContext73*c=opaque;if(read)cglGetUniformfv(c->program,location,values);else localUniform73(location,1,values);}
static void localLightOriginal73(void*opaque){LocalLightDrawContext73*c=opaque;originalLocalIndexed(c->mode,c->count,c->type,c->indices);c->error=GetLastError();}
static bool localLightNativeHand73(float point[3],uint32_t*packed){
 uintptr_t matrix=0,after=0,blade=0,extra=0;unsigned char raw[32];float decoded[16];
 if(!readAt(player+0x68,&matrix,8)||!matrix||matrix>UINTPTR_MAX-41*32||!readAt(matrix+40*32,raw,32)||!decodeHostRoot(raw,decoded)||!readAt(player+0x68,&after,8)||after!=matrix||!readAt(base+host->reaverRva,&blade,8)||!localBladeMatches(blade)||!readAt(blade+0x2c0,&extra,8)||!extra||!readAt(extra+24,packed,4))return false;
 memcpy(point,decoded+12,12);return true;
}
static bool localSwordWorldDraw73(GLenum mode,GLsizei count,GLenum type,const void*indices){
 if(!InterlockedCompareExchange(&portableActive60,0,0)){memset(&localSword73,0,sizeof(localSword73));return false;}
 if(localLightFailed73||!cameraReady||cameraContext!=wglGetCurrentContext()||mode!=GL_TRIANGLES||count<=0||count>6000000||(type!=GL_UNSIGNED_INT&&type!=GL_UNSIGNED_SHORT))return false;
 const DWORD error=GetLastError();const Sr1LocalFrame f=readFrame();const uint64_t now=GetTickCount64();const unsigned form=localCurrentForm(f.realm);
 if(!localSwordCurrent73(&localSword73,&f,player,(uintptr_t)wglGetCurrentContext(),form,now)||localPhysicalCarry(player))return false;
 GLint program=0,framebuffer=0;glGetIntegerv(GL_DRAW_FRAMEBUFFER_BINDING,&framebuffer);glGetIntegerv(GL_CURRENT_PROGRAM,&program);if(framebuffer||program<=0||!cglIsProgram((GLuint)program))return false;
 LocalLightProgram73*p=localLightProgram73((GLuint)program);if(!p)return false;
 if(!localUniform73){PROC address=wglGetProcAddress("glUniform4fv");if(!address||(uintptr_t)address<=3||(uintptr_t)address==UINTPTR_MAX)return false;localUniform73=(PFNGLUNIFORM4FVPROC)address;}
 float priorPos[4],priorCol[4],nativeHand[3]={0};uint32_t packed=0;cglGetUniformfv(program,p->position,priorPos);cglGetUniformfv(program,p->color,priorCol);const bool native=localLightNativeHand73(nativeHand,&packed);
 bool unused=true;for(unsigned k=0;k<4;k++)unused&=isfinite(priorCol[k])&&fabsf(priorCol[k])<=1e-6f;
 if((!unused&&!native)||!localSwordNativeSlot73(priorPos,priorCol,nativeHand,packed))return false;
 const Sheet_sr1SwordLight73*policy=&sheet_sr1SwordLight73_swing_switch_world_light;const uint32_t rgb=localFxColor51(form);const uint64_t age=now-localSword73.owner.tick;
 float amount=localSword73.reveal*localSwordGain73(&localSword73);if(age>50)amount*=fmaxf(0,1-(float)(age-50)/(float)(policy->sourceFreshMs-50));
 if(localSword73.flash&&now>=localSword73.flash&&now-localSword73.flash<(uint64_t)policy->flashMs)amount*=1+.5f*(1-(float)(now-localSword73.flash)/(float)policy->flashMs);
 float position[4]={localSword73.position[0],localSword73.position[1],localSword73.position[2],(float)policy->lightRadius},color[4]={((rgb>>16)&255)/255.f,((rgb>>8)&255)/255.f,(rgb&255)/255.f,0};for(unsigned k=0;k<3;k++)color[k]*=policy->lightGainPermille/1000.f*amount;
 LocalLightDrawContext73 call={(GLuint)program,mode,type,count,indices,error};const bool drawn=localLightTransaction73(&call,localLightUniform73,localLightOriginal73,p->position,p->color,priorPos,priorCol,position,color,&localLightFailed73);
 static unsigned rendered;if(drawn&&(!rendered++||rendered%1200==0||localLightFailed73))record("reaver-world-light73 draws=%u form=%u full=%u restored=%u borrowed-empty=%u",rendered,form,localSword73.charged>.99f,!localLightFailed73,unused);
 SetLastError(drawn?call.error:error);return drawn;
}
