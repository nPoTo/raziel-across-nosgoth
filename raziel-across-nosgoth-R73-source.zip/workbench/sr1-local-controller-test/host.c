// SPDX-License-Identifier: GPL-3.0-or-later
#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <bcrypt.h>
#include <limits.h>
#include <stdarg.h>
#include <stdio.h>
#include <string.h>
#include <wchar.h>
#include "MinHook.h"
#include "controller.h"
#ifdef SR1_LOCAL_COMBAT56
#include "local-finish-arm56.h"
#ifdef SR1_LOCAL_COMBAT57
#include "local-extra-pose57.h"
#include "local-pose57.h"
#endif
#endif
#include "exploration-sheets.h"
#include "host-proof.h"
#include "reader-hash.h"
#include "movement-response.h"

typedef struct { uint32_t held, pressed, released; int32_t x, y; } NativePad;
typedef void (*ComposePad)(NativePad *, NativePad *, int);
typedef int (*DecodeHold)(int *, int *);
typedef uintptr_t (*QueryInstance)(uintptr_t, uint32_t);
typedef uintptr_t (*PostInstance)(uintptr_t, uint32_t, uintptr_t);

static const Sheet_c0WeaponObservation *const host = &sheet_c0WeaponObservation_observation;
static const Sheet_desktopFinisherLocalInput *const pad = &sheet_desktopFinisherLocalInput_stock_input_without_global_story_flag_write;
static const Sheet_c1HostHitEvents *const hit = &sheet_c1HostHitEvents_native_post;
static const Sheet_sr1LocalMotion *const motion = &sheet_sr1LocalMotion_ground_response;
#ifdef SR1_LOCAL_GROUND_ACTIONS
static const Sheet_sr1LocalGroundActions *const groundActions = &sheet_sr1LocalGroundActions_standalone_ground;
#endif
static uintptr_t base;
static HANDLE trace = INVALID_HANDLE_VALUE;
static ComposePad originalPad;
#ifdef SR1_LOCAL_COMBAT60
static volatile LONG portableActive60,portableWanted60,portableReady60,portableDebugCommand60;
static _Thread_local bool portableProbe60;
static HINSTANCE portableModule60;
static wchar_t portableReports60[1024],portableRoot60[1024];
static void portableFrame60(void);
static bool portableMenuChord65(void);
#ifdef SR1_LOCAL_COMBAT66
static void arenaFrame66(void);
#endif
static void portableStatus60(const char *text);
static bool portableStart60(void);
static bool portableFormsProof60(void);
static void portableFormsRestore60(void);
#endif
#ifdef SR1_MEASURED_GROUND_COMBO
static PostInstance originalComboPost;
#endif
#if !defined(SR1_MOVEMENT_ONLY) || defined(SR1_LOCAL_JUMP_REPEAT)
static const Sheet_sr1LocalHostSignals *const signals = &sheet_sr1LocalHostSignals_sr1;
#endif
#ifndef SR1_MOVEMENT_ONLY
static DecodeHold originalDecode;
static PostInstance originalPost;
static _Thread_local uintptr_t finishTarget;
static _Thread_local uint64_t requestSerial;
static _Thread_local uint32_t requestTargetGeneration;
static _Thread_local bool pulse;
#else
static _Thread_local bool shaping;
#endif
static _Thread_local Sr1LocalController controller;
static _Thread_local uintptr_t player;
static _Thread_local uint64_t serial;
static _Thread_local bool hasControl, moving, jumpReported;
#ifdef SR1_LOCAL_REPEAT_ON_LANDING_SECTION
static _Thread_local bool glideReported;
#endif
static _Thread_local int16_t previousPosition[3];
#ifdef SR1_DEFIANCE_GROUND_BLEND
#include "ground-transition.h"
static volatile LONG64 groundIntentTick;
#endif
#ifdef SR1_DEFIANCE_GROUND_CALIBRATION
#include "ground-gait.h"
static volatile LONG fullGroundIntent, calibratedDrawReady;
#ifdef SR1_LOCAL_REPEAT_DRAW_LEASE
static volatile LONG groundDrawRefused;
#endif
#endif
#ifdef SR1_DEFIANCE_GROUND_RESPONSIVE
static volatile LONG64 groundStartRequested;
#endif
#ifdef SR1_LOCAL_DEFIANCE_JUMP
#include "local-air-ownership.h"
#endif
#ifdef SR1_LOCAL_DEFIANCE_COMBAT
static const Sheet_sr1LocalCombat *const combatPolicy = &sheet_sr1LocalCombat_ground_reaver;
static const Sheet_hostAcquisitionRead *const acquisition = &sheet_hostAcquisitionRead_readOnly;
static SRWLOCK strikeLock = SRWLOCK_INIT;
static LocalActionOwner strikePress;
#ifdef SR1_LOCAL_STRIKE_COMBO
#include "ground-pose-proof.h"
static const Sheet_sr1LocalStrikeIndex *const strikeIndex = &sheet_sr1LocalStrikeIndex_attack_section_1;
#endif

#ifdef SR1_LOCAL_COMBAT_CLOCK
static bool readAt(uintptr_t address, void *value, size_t size);
#ifdef SR1_LOCAL_CONTROL_EDGES
static void record(const char *message, ...);
#endif
static bool readLocalStrikeTime(Sr1LocalFrame *frame, uintptr_t actor, uintptr_t descriptor) {
    const uintptr_t section = actor + combatPolicy->sectionOffset;
    uintptr_t keys, interpolation, running;
    uint8_t timing[8];
    uint32_t status;
    int16_t elapsed;
    if (!readAt(section + combatPolicy->keylistOffset, &keys, sizeof(keys)) || !keys ||
        !readAt(keys, timing, sizeof(timing)) || !readAt(section + 4, &elapsed, sizeof(elapsed)) ||
        !readAt(section + 0x20, &status, sizeof(status)) ||
        !readAt(section + combatPolicy->interpolationOffset, &interpolation, sizeof(interpolation))) return false;
    if (interpolation && (!readAt(interpolation + 0x10, &running, sizeof(running)) ||
        (running && !readAt(interpolation + 2, &elapsed, sizeof(elapsed))))) return false;
    int16_t count, interval;
    memcpy(&count, timing + 4, sizeof(count));
    memcpy(&interval, timing + 6, sizeof(interval));
    const int end = (count - 1) * interval + timing[1];
    if (count <= 1 || count > 512 || interval <= 0 || end <= 1 || end > 32767 || elapsed < 0) return false;
#ifndef SR1_LOCAL_COMBAT_PRESENTATION
    if (elapsed >= end) return false;
#endif
    frame->strikeIdentity = descriptor;
    frame->strikeTime = elapsed < end ? elapsed : end - 1;
    frame->strikeEnd = end;
#ifdef SR1_LOCAL_GROUND_ACTIONS
    uint8_t gate;
    if (!timing[1] || !readAt(descriptor + 5, &gate, sizeof(gate))) return false;
    frame->strikeKey = frame->strikeTime / timing[1];
    frame->strikeGate = gate;
#endif
#ifdef SR1_LOCAL_STRIKE_COMBO
    uint64_t ordinal;
    if (!readAt(base + strikeIndex->indexRva, &ordinal, sizeof(ordinal)) || ordinal >= LOCAL_STRIKE_COUNT) return false;
    frame->strikeOrdinal = (unsigned)ordinal;
#endif
#ifdef SR1_LOCAL_CONTROL_EDGES
    static _Thread_local unsigned lastReported = UINT_MAX;
    if (lastReported != frame->strikeOrdinal && timing[1]) {
        uint8_t gate;
        if (readAt(descriptor + 5, &gate, sizeof(gate))) {
            lastReported = frame->strikeOrdinal;
            record("defiance-native-combo-window ordinal=%u key=%u gate=%u max=%u end=%d",
                frame->strikeOrdinal, elapsed / timing[1], gate, (end - 1) / timing[1], end);
        }
    }
#endif
    frame->groundStrike = (status & 1u) == 0 && elapsed < end;
    return true;
}
#endif
#endif

static void record(const char *message, ...) {
    if (trace == INVALID_HANDLE_VALUE) return;
    char line[288];
    const unsigned long long tick = GetTickCount64();
    int prefix = snprintf(line, sizeof(line), "%llu ", tick);
    va_list args;
    va_start(args, message);
    int length = vsnprintf(line + prefix, sizeof(line) - (size_t)prefix - 2, message, args);
    va_end(args);
    if (length < 0 || (size_t)(length + prefix) >= sizeof(line) - 2) return;
    line[prefix + length] = '\n';
    DWORD written;
    WriteFile(trace, line, (DWORD)(prefix + length + 1), &written, NULL);
}

static bool readAt(uintptr_t address, void *value, size_t size) {
    SIZE_T count = 0;
    return ReadProcessMemory(GetCurrentProcess(), (void *)address, value, size, &count) && count == size;
}

static uint32_t generation(uintptr_t instance) {
    uint32_t result = 0;
    if (instance) readAt(instance + hit->generationOffset, &result, sizeof(result));
    return result;
}

#ifdef SR1_LOCAL_GUARD_LOCOMOTION
static bool localPhysicalCarry(uintptr_t actor) {
    uintptr_t child, reaver, parent;
    if (!readAt(actor + host->childOffset, &child, sizeof(child)) ||
        !readAt(base + host->reaverRva, &reaver, sizeof(reaver))) return true;
    if (child && child == reaver &&
        !readAt(child + host->siblingOffset, &child, sizeof(child))) return true;
    if (!child) return false;
    // Any attached non-Reaver object should keep SR1's full carrying behavior.
    return !readAt(child + host->parentOffset, &parent, sizeof(parent)) || parent == actor;
}
#endif

#ifdef SR1_LOCAL_BATTLE46
#include "local-battle46.h"
#endif
#ifdef SR1_LOCAL_COMBAT48
#include "local-pickup48.h"
#endif
#ifndef SR1_MOVEMENT_ONLY
static uintptr_t selectedTarget(uint32_t stream) {
    uint32_t flags = 0, targetStream = 0;
    uintptr_t slots = 0, target = 0;
    if (!readAt(base + host->interactionFlagsRva, &flags, sizeof(flags)) || !(flags & signals->finishEngagementMask) ||
        !readAt(base + host->targetsRva, &slots, sizeof(slots)) || !slots ||
        !readAt(slots + signals->finishTargetOffset, &target, sizeof(target)) || !target || target == player ||
        !readAt(target + 0x60, &targetStream, sizeof(targetStream)) || targetStream != stream) return 0;
    return target;
}
#endif

#ifdef SR1_LOCAL_COMBAT48
#include "local-support48.h"
#endif
static Sr1LocalFrame readLocalFrame(bool requireFocus) {
    Sr1LocalFrame frame = {.session = GetCurrentProcessId(), .serial = ++serial};
#ifdef SR1_LOCAL_COMBAT60
    if(!portableProbe60&&!InterlockedCompareExchange(&portableActive60,0,0))return frame;
#endif
    uintptr_t actor, owner, callbacks[3];
    uint32_t realm, flags;
    uint16_t mode;
    int32_t vertical;
    DWORD focus = 0;
    GetWindowThreadProcessId(GetForegroundWindow(), &focus);
    if ((requireFocus && focus != GetCurrentProcessId()) || !readAt(base + host->actorRva, &actor, sizeof(actor)) || !actor ||
        !readAt(base + host->stateActorRva, &owner, sizeof(owner)) || actor != owner ||
        !readAt(base + host->realmRva, &realm, sizeof(realm)) ||
        !readAt(actor + 0x60, &frame.worldGeneration, sizeof(frame.worldGeneration)) ||
        !readAt(base + 0x2a89536, &mode, sizeof(mode)) || !readAt(base + 0x2a8950c, &flags, sizeof(flags)) ||
        !readAt(actor + 0x2d4, &vertical, sizeof(vertical))) return frame;
    for (unsigned i = 0; i < ARRAYSIZE(callbacks); ++i) {
        if (!readAt(base + host->callbackRva + i * host->sectionStride, &callbacks[i], sizeof(callbacks[i]))) return frame;
    }
    frame.playerGeneration = generation(actor);
    frame.realm = realm == host->materialRealm ? SR1_LOCAL_MATERIAL :
                  realm == host->spectralRealm ? SR1_LOCAL_SPECTRAL : SR1_LOCAL_UNKNOWN;
    frame.ready = true;
#ifdef SR1_LOCAL_COMBAT48
    frame.groundContact48=vertical==0 || (vertical<0&&vertical>=-sheet_sr1Combat48_combat_charge.groundVelocityBand&&localGroundSupport48(&frame,actor,GetTickCount64()));
    frame.grounded = frame.groundContact48;
#else
    frame.grounded = vertical == 0;
#endif
    frame.verticalVelocity = vertical;
#ifdef SR1_LOCAL_GROUND_ACTIONS
    for (unsigned i = 0; i < ARRAYSIZE(callbacks); ++i) {
        if (callbacks[i] == base + (uintptr_t)groundActions->feedingRva) {
            frame.nativeControl = true;
            frame.grounded = false;
            player = actor;
            return frame;
        }
    }
#endif
#ifdef SR1_LOCAL_DEFIANCE_JUMP
    const uintptr_t primary = callbacks[0] - base;
    if (primary == (uintptr_t)groundPolicy->compressRva) frame.airState = SR1_AIR_COMPRESS;
    else if (primary == (uintptr_t)groundPolicy->jumpRva) frame.airState = SR1_AIR_JUMP;
    else if (primary == (uintptr_t)groundPolicy->fallRva) frame.airState = SR1_AIR_FALL;
    else if (primary == (uintptr_t)groundPolicy->landRva) frame.airState = SR1_AIR_LAND;
#endif
#ifdef SR1_DEFIANCE_GROUND_BLEND
    frame.renderBlend = !mode && !(flags & (0x10000000u | motion->scriptedPadMask));
#endif
#ifdef SR1_LOCAL_COMBAT_PRESENTATION
    bool strikeGroundContext = true;
#endif
#ifdef SR1_LOCAL_BATTLE46
    uint32_t battleAbilities46=0,battleMirror46=0,battleKind46=0;
    const bool battleOwned46=!mode&&!(flags&(0x10000000u|motion->scriptedPadMask))&&
        readAt(base+acquisition->abilitiesRva,&battleAbilities46,4)&&
        readAt(base+acquisition->mirrorRva,&battleMirror46,4)&&battleAbilities46==battleMirror46&&
        (battleAbilities46&combatPolicy->reaverAbility)&&
        readAt(base+host->interactionTypeRva,&battleKind46,4)&&battleKind46==0x1000;
    bool battleKnown46=true,battleSeen46=false;
#ifdef SR1_LOCAL_LOCK47
#ifndef SR1_LOCAL_COMBAT52
    LocalActionOwner extraPress47={0};
    if (TryAcquireSRWLockShared(&strikeLock)) {extraPress47=strikePress;ReleaseSRWLockShared(&strikeLock);}
#endif
    const bool extraCombat47=battleOwned46 &&
#ifdef SR1_LOCAL_COMBAT48
        !localPhysicalPickup48(&frame,actor) &&
#endif
#ifdef SR1_LOCAL_COMBAT52
        true; // Known acquired Reaver switch remains presentation-owned beyond the last attack edge.
#else
        sameLocalAction(&extraPress47,&frame,actor,GetTickCount64(),900);
#endif
#endif
#endif
    for (unsigned i = 0; i < ARRAYSIZE(callbacks); ++i) {
        bool ordinary = false;
        for (size_t j = 0; j < sheet_retargetGroundStates_count; ++j) {
            ordinary |= callbacks[i] == base + sheet_retargetGroundStates_rows[j]->rva;
        }
#ifdef SR1_DEFIANCE_GROUND_BLEND
        const uintptr_t rva = callbacks[i] - base;
        ordinary |= rva == (uintptr_t)groundPolicy->startTurnRva ||
                    rva == (uintptr_t)groundPolicy->stopMoveRva;
#ifdef SR1_LOCAL_BATTLE46
        ordinary |= battleOwned46&&localBattleFace46(rva);
#ifdef SR1_LOCAL_LOCK47
        ordinary |= extraCombat47 && rva==(uintptr_t)sheet_sr1Lock47_locked_combat.extraCombatRva;
#ifdef SR1_LOCAL_COMBAT53
        ordinary |= battleOwned46&&!localPhysicalPickup48(&frame,actor)&&rva==(uintptr_t)sheet_sr1Combat53_fast_force_held_soul.wallReactionRva;
#endif
        battleSeen46 |= extraCombat47 && rva==(uintptr_t)sheet_sr1Lock47_locked_combat.extraCombatRva;
#endif
        battleKnown46 &= ordinary||rva==(uintptr_t)combatPolicy->nativeAttackRva;
        battleSeen46 |= localBattleFace46(rva)||rva==(uintptr_t)combatPolicy->nativeAttackRva;
#endif
        frame.renderBlend &= ordinary || rva == (uintptr_t)groundPolicy->compressRva ||
            rva == (uintptr_t)groundPolicy->landRva || rva == (uintptr_t)groundPolicy->jumpRva ||
            rva == (uintptr_t)groundPolicy->fallRva;
#endif
        frame.grounded &= ordinary;
#ifdef SR1_LOCAL_COMBAT_PRESENTATION
        strikeGroundContext &= ordinary || callbacks[i] == base + combatPolicy->nativeAttackRva;
#endif
    }
    if (callbacks[0] == base + 0xf2ae0 && !jumpReported) {
        jumpReported = true;
        record("jump-native realm=%u", frame.realm);
    }
    if (frame.grounded) jumpReported = false;
    frame.nativeControl = !frame.grounded || mode || (flags & (0x10000000u | motion->scriptedPadMask));
#ifdef SR1_LOCAL_GUARD_LOCOMOTION
    if (localPhysicalCarry(actor)) {
        frame.nativeControl = true;
        frame.grounded = false;
        frame.renderBlend = false;
        player = actor;
        return frame;
    }
#endif
#ifdef SR1_LOCAL_DEFIANCE_COMBAT
    if (
#ifdef SR1_LOCAL_COMBAT48
        frame.groundContact48 &&
#else
        vertical == 0 &&
#endif
        !mode && !(flags & (0x10000000u | motion->scriptedPadMask)) &&
#ifdef SR1_LOCAL_COMBAT_PRESENTATION
        strikeGroundContext &&
#endif
#ifdef SR1_LOCAL_THIRD_SWEEP
        (callbacks[0] == base + combatPolicy->nativeAttackRva || callbacks[1] == base + combatPolicy->nativeAttackRva ||
         callbacks[2] == base + combatPolicy->nativeAttackRva)) {
#else
        callbacks[1] == base + combatPolicy->nativeAttackRva) {
#endif
        LocalActionOwner press = {0};
        if (TryAcquireSRWLockShared(&strikeLock)) {
            press = strikePress;
            ReleaseSRWLockShared(&strikeLock);
        }
        uint32_t abilities, mirror, kind;
        uintptr_t blade, descriptor;
        uint8_t clip;
        uint16_t sectionClip;
        const bool pressFresh = sameLocalAction(&press, &frame, actor, GetTickCount64(), 900);
        if (
#ifndef SR1_LOCAL_THIRD_SWEEP
            pressFresh &&
#endif
            readAt(base + acquisition->abilitiesRva, &abilities, sizeof(abilities)) &&
            readAt(base + acquisition->mirrorRva, &mirror, sizeof(mirror)) && abilities == mirror &&
            (abilities & combatPolicy->reaverAbility) &&
            readAt(base + host->interactionTypeRva, &kind, sizeof(kind)) && kind == 0x1000 &&
            readAt(base + host->reaverRva, &blade, sizeof(blade)) && blade) {
#ifdef SR1_LOCAL_THIRD_SWEEP
            frame.strikeTransition = true;
#endif
            const bool clipsMatch =
#ifdef SR1_LOCAL_THIRD_SWEEP
                callbacks[1] == base + combatPolicy->nativeAttackRva &&
#endif
                readAt(base + combatPolicy->descriptorRva, &descriptor, sizeof(descriptor)) &&
            readAt(descriptor, &clip, sizeof(clip)) &&
            readAt(actor + 0x3c4, &sectionClip, sizeof(sectionClip)) && clip == sectionClip;
#ifdef SR1_LOCAL_COMBAT_CLOCK
            frame.renderBlend = clipsMatch && readLocalStrikeTime(&frame, actor, descriptor);
#ifdef SR1_LOCAL_THIRD_FINISH
            frame.strikeSettled = frame.renderBlend && !frame.groundStrike && frame.airState == SR1_AIR_NONE;
#endif
#ifdef SR1_LOCAL_THIRD_SWEEP
            if (!pressFresh) {
                frame.groundStrike = false;
                frame.renderBlend = frame.strikeSettled;
            }
#endif
#ifdef SR1_LOCAL_COMBAT_PRESENTATION
            frame.strikePending = !frame.renderBlend &&
                sameLocalAction(&press, &frame, actor, GetTickCount64(), strikePresentation->pendingMs);
#endif
#else
            frame.groundStrike = clipsMatch;
            frame.renderBlend = clipsMatch;
#endif
        }
    }
#endif
#ifdef SR1_LOCAL_BATTLE46
    localBattleFrame46(&frame,battleOwned46,battleKnown46,battleSeen46);
#ifdef SR1_LOCAL_COMBAT54
    // The native attack can survive a wall/edge loss of support. Preserve actual fall physics.
    if(sheet_sr1Combat54_utility_aim_hud.attackFallPresentation&&!frame.renderBlend&&battleOwned46&&battleKnown46&&
#ifdef SR1_LOCAL_COMBAT57
       (callbacks[0]==base+combatPolicy->nativeAttackRva||callbacks[1]==base+combatPolicy->nativeAttackRva||callbacks[2]==base+combatPolicy->nativeAttackRva)&&
#else
       callbacks[0]==base+combatPolicy->nativeAttackRva&&
#endif
       vertical<0&&!localPhysicalPickup48(&frame,actor)){
        frame.renderBlend=true;frame.grounded=false;frame.groundStrike=false;frame.strikePending=false;
        frame.nativeControl=true;frame.airState=SR1_AIR_FALL;
    }
#endif
#endif
#ifdef SR1_LOCAL_COMBAT68
    if(localNativeContextFrame68(&frame,actor,callbacks)){
        frame.nativeControl=true;frame.grounded=false;frame.renderBlend=false;
        frame.groundStrike=false;frame.strikePending=false;frame.strikeTransition=false;
    }
#endif
    player = actor;
    return frame;
}

static Sr1LocalFrame readFrame(void) {
    return readLocalFrame(true);
}
#ifdef SR1_LOCAL_BATTLE46
static void localBattleAdmissionTrace46(const Sr1LocalFrame *frame,uintptr_t actor) {
    if(!frame->ready||!actor)return;
    struct {uint32_t callbacks[3],world,generation,realm,flags,kind;int32_t velocity;uint16_t mode;uint8_t render,native,carry;} next={0};
    for(unsigned i=0;i<3;i++){uintptr_t callback=0;if(!readAt(base+host->callbackRva+i*host->sectionStride,&callback,8))return;next.callbacks[i]=(uint32_t)(callback-base);}
    if(!readAt(base+0x2a89536,&next.mode,2)||!readAt(base+0x2a8950c,&next.flags,4)||!readAt(base+host->interactionTypeRva,&next.kind,4))return;
    next.world=frame->worldGeneration;next.generation=frame->playerGeneration;next.realm=frame->realm;next.velocity=0;next.render=frame->renderBlend;next.native=frame->nativeControl;next.carry=localPhysicalCarry(actor);
    static _Thread_local unsigned char previous[sizeof(next)];static _Thread_local unsigned reports;
    if(memcmp(previous,&next,sizeof(next))&&reports<1024){memcpy(previous,&next,sizeof(next));reports++;record("combat-admission render=%u native=%u carry=%u kind=%x callbacks=%x/%x/%x flags=%x mode=%u vz=%ld realm=%u",next.render,next.native,next.carry,next.kind,next.callbacks[0],next.callbacks[1],next.callbacks[2],next.flags,next.mode,(long)frame->verticalVelocity,next.realm);
#ifdef SR1_LOCAL_COMBAT58
        if(!next.render){uint32_t powers=0,mirror=0,sensed=0;uintptr_t slots=0,target=0;
            const bool powerRead=readAt(base+acquisition->abilitiesRva,&powers,4)&&readAt(base+acquisition->mirrorRva,&mirror,4);
            const bool senseRead=readAt(base+host->interactionFlagsRva,&sensed,4)&&readAt(base+host->targetsRva,&slots,8)&&slots&&readAt(slots+0x30,&target,8);
            record("defiance-native-yield-audit powers-read=%u powers=%x mirror=%x pickup=%u sense-read=%u sense=%x target=%u",powerRead,powers,mirror,localPhysicalPickup48(frame,actor),senseRead,sensed,target?generation(target):0);
        }
#endif
    }
}
#endif
#ifdef SR1_LOCAL_FORMS45
static bool matches(uintptr_t,const unsigned char *,size_t);
#include "local-forms45.h"
#ifdef SR1_LOCAL_LOCK47
#include "local-target47.h"
#ifdef SR1_LOCAL_COMBAT48
#include "local-runtime48-proof.h"
#include "local-charge48.h"
#include "local-impact48.h"
#ifdef SR1_LOCAL_COMBAT51
#include "local-fx51.h"
static void localCastAudio51(const Sr1LocalFrame *,uintptr_t,unsigned,uint64_t,uint64_t);
static bool localFullHitAudio51(const Sr1LocalFrame *,uintptr_t,unsigned,bool,uint64_t);
#endif
#endif
#endif
static void localSlamImpactAudio(const Sr1LocalFrame *,uintptr_t,uint64_t,uint64_t);
#endif

#ifdef SR1_LOCAL_COMBAT_FACING
#include "local-combat-facing.h"
static _Thread_local LocalActionOwner groundAim;
static _Thread_local unsigned groundAimYaw;
#ifdef SR1_LOCAL_COMBAT_LINKS
static _Thread_local LocalActionOwner guardFacing;
static _Thread_local uint16_t guardFacingYaw;
static _Thread_local LocalActionOwner directionRestart;
#endif

static bool readCombatBearing(int32_t x, int32_t y, unsigned *desired) {
    const Sheet_sr1GroundSteering *p = &sheet_sr1GroundSteering_camera_relative_start;
    uint16_t camera;
    if (!combatDirectionHeld(x,y,(int32_t)motion->moveThreshold) ||
        !readAt(base+p->cameraRva,&camera,sizeof(camera))) return false;
    *desired=combatCameraYaw(x,y,camera);
    return true;
}
#endif

#ifdef SR1_LOCAL_AIR_CONTACT
#ifdef SR1_LOCAL_TEMPEST_FLIGHT
static bool applyLocalTempestPhysics(uintptr_t, int32_t, int32_t, int32_t, uint64_t, DWORD);
#else
static unsigned localSpecialAirFactor(const Sr1LocalFrame *,uintptr_t,uint64_t);
#endif
#endif
#ifdef SR1_LOCAL_AIR_SLAM
static bool matches(uintptr_t rva, const unsigned char *proof, size_t count);
static bool verifyDrawBlock(uintptr_t rva, DWORD length, const char *digest);
#include "local-air-slam.h"
#endif
#ifdef SR1_LOCAL_JUMP_REPEAT
#include "local-jump-repeat.h"
#endif
#ifdef SR1_LOCAL_CALIBRATED_COMBAT
#include "local-dodge.h"
#endif
#ifdef SR1_LOCAL_NATIVE_CONTROLS
#ifdef SR1_LOCAL_AIR_CONTACT
#include "local-special-combat.h"
#endif
#include "local-controls.h"
#endif
#ifdef SR1_LOCAL_GROUND_X
#include "local-ground-x.h"
#endif
#ifdef SR1_LOCAL_COMBO_ADMISSION
#include "local-combo-admission.h"
#endif
#ifdef SR1_LOCAL_NATIVE_COMBO_CLOCK
#include "native-combo-clock-proof.h"
#include "local-native-combo-clock.h"
#endif
#ifdef SR1_LOCAL_COMBAT_SYNC42
#include "local-combat-sync.h"
#endif

#ifdef SR1_LOCAL_GROUND_ACTIONS
static void armMovingStrike(const Sr1LocalFrame *frame, uint64_t now) {
    uint32_t abilities, mirror, kind;
    uintptr_t blade;
    if (frame->grounded && !frame->nativeControl && frame->realm != SR1_LOCAL_UNKNOWN &&
        readAt(base + acquisition->abilitiesRva, &abilities, sizeof(abilities)) &&
        readAt(base + acquisition->mirrorRva, &mirror, sizeof(mirror)) && abilities == mirror &&
        (abilities & combatPolicy->reaverAbility) &&
        readAt(base + host->interactionTypeRva, &kind, sizeof(kind)) && kind == 0x1000 &&
        readAt(base + host->reaverRva, &blade, sizeof(blade)) && blade) {
        movingStrikePress = localActionOwner(frame, player, now);
    }
}
#endif

#ifdef SR1_LOCAL_COMBAT59
#include "local-input59.h"
#endif
// Contextual physical-weapon input is applied only after the actual frame is read.
#ifdef SR1_LOCAL_COMBAT67
#include "local-physical67.h"
#endif
#ifdef SR1_LOCAL_COMBAT70
#include "local-debug70.h"
#endif
#ifdef SR1_LOCAL_COMBAT72
#include "local-target-release72.h"
#endif
static void compose(NativePad *output, NativePad *physical, int port) {
    const uintptr_t caller = (uintptr_t)__builtin_return_address(0);
    originalPad(output, physical, port);
    const DWORD error = GetLastError();
    if (port || !output || (uintptr_t)physical != (uintptr_t)output + 0x48 ||
        caller != base + (uintptr_t)pad->returnRva) return;

#ifdef SR1_LOCAL_COMBAT60
#ifdef SR1_LOCAL_COMBAT70
    localDebugObserve70();
    const bool debugChord70=portableMenuChord65();
    if(debugChord70)InterlockedExchange(&portableWanted60,0);
#else
    if(portableMenuChord65())InterlockedExchange(&portableWanted60,0);
#endif
    portableFrame60();
#ifdef SR1_LOCAL_COMBAT66
    arenaFrame66();
#endif
    if(!InterlockedCompareExchange(&portableActive60,0,0)){
#ifdef SR1_LOCAL_COMBAT70
        if(debugChord70)localDebugInput70(output);
#endif
        SetLastError(error);return;
    }
#endif
    Sr1LocalFrame frame = readFrame();
#ifdef SR1_LOCAL_COMBAT72
    localTargetBoundary72(output,&frame,GetTickCount64());
#endif
#ifdef SR1_LOCAL_COMBAT68
    static _Thread_local uint32_t contextual68;
    if(
#ifdef SR1_LOCAL_COMBAT69
       localContextHeld69(&frame,player)
#else
       localNativeContext68(&frame,player)
#endif
    ){
        if(contextual68!=frame.worldGeneration){
            localCancelCombo57();record("native-context68-priority world=%u",frame.worldGeneration);
        }
        contextual68=frame.worldGeneration;SetLastError(error);return;
    }
    contextual68=0;
#endif
#ifdef SR1_LOCAL_COMBAT67
    localPhysicalInput67(output,&frame);
#endif
#ifdef SR1_LOCAL_COMBAT59
    localDpadInput59(output,&frame);
#endif
#ifdef SR1_LOCAL_BATTLE46
    localBattleAdmissionTrace46(&frame,player);
#endif
#ifdef SR1_LOCAL_FORMS45
    localFormsInput(&frame,player);
#endif
#ifdef SR1_LOCAL_AIR_SLAM
    localSlamOnPad(&frame, player, GetTickCount64());
#endif
#ifdef SR1_LOCAL_NATIVE_CONTROLS
#ifdef SR1_LOCAL_COMBAT48
    uint32_t chargeAttack=0;
    if(readAt(base+signals->attackMaskRva,&chargeAttack,4)&&chargeAttack)localChargeInput48(output,&frame,player,chargeAttack,GetTickCount64());
#endif
    receiveLocalCombatInput(output, &frame);
#endif
#ifdef SR1_LOCAL_GROUND_X
    const LocalGroundX x = readGroundX(&frame, player, GetTickCount64());
#ifdef SR1_LOCAL_COMBAT_FACING
    groundAim=(LocalActionOwner){0};
    if ((frame.groundStrike || frame.strikePending || x.owner.tick) && frame.ready &&
        frame.airState==SR1_AIR_NONE && readCombatBearing(output->x,output->y,&groundAimYaw))
        groundAim=localActionOwner(&frame,player,GetTickCount64());
#endif
    if (x.owner.tick) {
        // The composed action remains fully remappable. Only directional input yields to authored X travel.
        const uint32_t directions = 0xfu;
        output->x = output->y = 0;
        output->held &= ~directions;
        output->pressed &= ~directions;
        output->released &= ~directions;
    }
#endif
#ifdef SR1_LOCAL_DEFIANCE_COMBAT
    uint32_t attackMask;
    const bool attackReadable = readAt(base + signals->attackMaskRva, &attackMask, sizeof(attackMask)) && attackMask;
#ifdef SR1_LOCAL_CALIBRATED_COMBAT
    if (attackReadable && readLocalDodge(&frame, player, GetTickCount64(), 0).owner.tick) {
        output->pressed &= ~attackMask;
        output->held &= ~attackMask;
    }
#endif
#ifdef SR1_LOCAL_AIR_STRIKE
    if (attackReadable) localAirStrikeOnPad(output, attackMask, &frame, player, GetTickCount64(), slamRecoveryDuration());
#endif
#if defined(SR1_LOCAL_GROUND_X) && !defined(SR1_LOCAL_GROUND_ACTIONS)
#ifdef SR1_LOCAL_THIRD_FINISH
    // A close follow-up can advance SR1's live combo gate. A press during ordinary recovery cannot
    // re-enter native ordinal zero while the displayed stroke is still finishing.
    if (attackReadable && groundXBlocksRestart(x.owner.tick != 0, frame.groundStrike)) {
#else
    // Extra presses cannot replace the final stroke during its grounded return.
    if (attackReadable && x.owner.tick && x.ordinal == 2 && !frame.groundStrike) {
#endif
        output->pressed &= ~attackMask;
    }
#endif
#ifdef SR1_LOCAL_GROUND_ACTIONS
    bool authoredStrike = x.owner.tick != 0;
#ifdef SR1_LOCAL_COMBAT_RHYTHM
    // The final step is already published. Send the next edge before retiring its render ownership.
    if (authoredStrike && !x.nativeStrike &&
#ifdef SR1_LOCAL_NATIVE_COMBO_CLOCK
        !groundXRecoveryRemaining(x.ordinal, x.owner.tick - x.start, x.fastClock)
#else
        !groundXHasRemaining(x.ordinal, groundXPlaybackAge(x.ordinal,
#ifdef SR1_LOCAL_COMBAT_SYNC42
            combatGroundPoseAge(x.ordinal,x.owner.tick-x.start)
#else
            x.owner.tick-x.start
#endif
        ))
#endif
    )
        authoredStrike = false;
#endif
    const bool attackEdge = attackReadable && requestGroundCombo(output, &frame, attackMask, authoredStrike);
    if (attackEdge && !frame.groundStrike) armMovingStrike(&frame, GetTickCount64());
#elif defined(SR1_LOCAL_COMBO_ADMISSION)
    const bool attackEdge = attackReadable && requestThirdNativeStrike(output, &frame, attackMask);
#else
    const bool attackEdge = attackReadable && (output->pressed & attackMask);
#endif
    if (frame.ready && (frame.grounded || frame.groundStrike) && frame.realm != SR1_LOCAL_UNKNOWN && attackEdge) {
#ifdef SR1_MEASURED_GROUND_COMBO
        record("defiance-strike-input realm=%u active=%u ordinal=%u phase=%ld/%ld", frame.realm,
            frame.groundStrike, frame.strikeOrdinal, (long)frame.strikeTime, (long)frame.strikeEnd);
#endif
        AcquireSRWLockExclusive(&strikeLock);
        strikePress = localActionOwner(&frame, player, GetTickCount64());
        ReleaseSRWLockExclusive(&strikeLock);
    }
#endif
#ifdef SR1_LOCAL_JUMP_REPEAT
    localRepeatInput(output, &frame);
#endif
#ifdef SR1_LOCAL_REPEAT_ON_LANDING_SECTION
    uintptr_t current = 0;
    const bool gliding = frame.ready && readAt(base + host->callbackRva, &current, sizeof(current)) &&
        current == base + 0xefb50;
    if (gliding && !glideReported) record("defiance-native-glide realm=%u", frame.realm);
    glideReported = gliding;
#endif
#ifndef SR1_MOVEMENT_ONLY
    uint32_t jump, attack, contextual;
    if (!readAt(base + signals->jumpMaskRva, &jump, sizeof(jump)) || !jump ||
        !readAt(base + signals->attackMaskRva, &attack, sizeof(attack)) || !attack ||
        !readAt(base + signals->contextMaskRva, &contextual, sizeof(contextual)) || !contextual) {
        frame.ready = false;
        jump = attack = contextual = 0;
    }
    if (output->held & jump) frame.pressed |= SR1_LOCAL_PRESS_JUMP;
    if (output->held & attack) frame.pressed |= SR1_LOCAL_PRESS_STRIKE;
    const bool finishKey = (GetAsyncKeyState(VK_F8) & 0x8000) != 0;
    const bool newFinish = finishKey && !(controller.previousPressed & SR1_LOCAL_PRESS_FINISH);
    if (finishKey) frame.pressed |= SR1_LOCAL_PRESS_FINISH;
    if (frame.ready && !frame.nativeControl && newFinish) {
        finishTarget = selectedTarget(frame.worldGeneration);
        const QueryInstance query = (QueryInstance)(base + signals->queryRva);
        if (finishTarget && (query(finishTarget, 0) & (uintptr_t)signals->stunnedMask)) {
            frame.finishTargetGeneration = generation(finishTarget);
        }
        if (!frame.finishTargetGeneration) record("finish-no-stunned-target realm=%u", frame.realm);
    }
#endif
    if (output->x >= INT16_MIN && output->x <= INT16_MAX && output->y >= INT16_MIN && output->y <= INT16_MAX) {
        frame.moveX = (int16_t)output->x;
        frame.moveY = (int16_t)output->y;
#ifdef SR1_MOVEMENT_ONLY
        sr1LocalShapeAxes(&frame.moveX, &frame.moveY, (int)motion->moveThreshold, (int)motion->fullAxis);
#endif
    } else {
        frame.ready = false;
    }
#ifdef SR1_DEFIANCE_GROUND_BLEND
    const int threshold = (int)motion->moveThreshold;
    const bool intent = frame.ready && (frame.moveX > threshold || frame.moveX < -threshold ||
        frame.moveY > threshold || frame.moveY < -threshold);
    InterlockedExchange64(&groundIntentTick, intent ? (LONG64)GetTickCount64() : 0);
#ifdef SR1_DEFIANCE_GROUND_CALIBRATION
    const int fullThreshold = 9 * (int)motion->fullAxis / 10;
    InterlockedExchange(&fullGroundIntent, intent && !(output->held & ~0x0fu) &&
        (int64_t)frame.moveX * frame.moveX + (int64_t)frame.moveY * frame.moveY >=
        (int64_t)fullThreshold * fullThreshold);
#ifdef SR1_DEFIANCE_GROUND_RESPONSIVE
    if (intent && !(output->held & ~0x0fu)) {
        InterlockedCompareExchange64(&groundStartRequested, (LONG64)GetTickCount64(), 0);
    } else {
        InterlockedExchange64(&groundStartRequested, 0);
    }
#endif
#endif
#endif
    const Sr1LocalCommand command = sr1LocalUpdate(&controller, &frame);
    if (command.apply) {
        if (hasControl != command.ownsControl) {
            hasControl = command.ownsControl;
            record("control-%s realm=%u world=%u actor=%u", hasControl ? "local" : "native",
                   frame.realm, frame.worldGeneration, frame.playerGeneration);
            moving = false;
        }
#ifndef SR1_MOVEMENT_ONLY
        if (pulse && !(output->held & contextual)) output->released |= contextual;
        pulse = false;
#endif
        if (command.ownsControl) {
#ifdef SR1_MOVEMENT_ONLY
            const bool changed = output->x != command.moveX || output->y != command.moveY;
            if (changed && !shaping) record("axis-response realm=%u input=%ld,%ld output=%d,%d",
                frame.realm, (long)output->x, (long)output->y, command.moveX, command.moveY);
            shaping = changed;
#endif
            output->x = command.moveX;
            output->y = command.moveY;
            int16_t position[3];
            if (readAt(player + 0x9c, position, sizeof(position))) {
                if (!moving && (command.moveX || command.moveY) &&
                    memcmp(position, previousPosition, 2 * sizeof(position[0]))) {
                    record("travel-observed realm=%u", frame.realm);
                    moving = true;
                }
                if (!command.moveX && !command.moveY) moving = false;
                memcpy(previousPosition, position, sizeof(position));
            }
#ifndef SR1_MOVEMENT_ONLY
            if (command.action == SR1_LOCAL_JUMP || command.action == SR1_LOCAL_STRIKE) {
                output->pressed |= command.action == SR1_LOCAL_JUMP ? jump : attack;
            } else if (command.action == SR1_LOCAL_FINISH && !(output->held & (contextual | attack))) {
                output->held |= contextual;
                output->pressed |= contextual;
                output->released &= ~contextual;
                requestSerial = frame.serial;
                requestTargetGeneration = command.finishTargetGeneration;
                pulse = true;
                record("finish-request realm=%u target=%u", frame.realm, requestTargetGeneration);
            }
#endif
        }
#ifdef SR1_MOVEMENT_ONLY
        else shaping = false;
#endif
    }
#ifdef SR1_LOCAL_REPEAT_ON_PAD
    localRepeatFromPad(&frame);
#endif
    SetLastError(error);
}

#ifndef SR1_MOVEMENT_ONLY
static int decode(int *message, int *value) {
    const uintptr_t caller = (uintptr_t)__builtin_return_address(0);
    const int native = originalDecode(message, value);
    if (caller != base + (uintptr_t)signals->decodeHoldReturnRva || !pulse || requestSerial != serial) return native;
    const QueryInstance query = (QueryInstance)(base + signals->queryRva);
    if (finishTarget != selectedTarget(controller.worldGeneration) || generation(finishTarget) != requestTargetGeneration ||
        !(query(finishTarget, 0) & (uintptr_t)signals->stunnedMask)) return 0;
    if (controller.realm == SR1_LOCAL_SPECTRAL && native && *message == (int)0x80000000u) {
        uintptr_t reaver = 0;
        uint32_t heldClass = 0;
        if (!readAt(base + host->reaverRva, &reaver, sizeof(reaver)) || !reaver ||
            !readAt(base + host->interactionTypeRva, &heldClass, sizeof(heldClass)) || heldClass != 0x1000) return 0;
        *message = 0x1000023;
        *value = 1;
    }
    const bool admitted = native && *message == 0x1000023 && *value != 0;
    record("finish-decode realm=%u target=%u admitted=%u", controller.realm, requestTargetGeneration, admitted);
    return admitted;
}

static uintptr_t post(uintptr_t target, uint32_t id, uintptr_t data) {
    const uintptr_t caller = (uintptr_t)__builtin_return_address(0);
    const uint32_t rva = (uint32_t)(caller - base);
    if (target == finishTarget && id == 0x1000023 && rva == signals->stockFinishReturnRva &&
        generation(target) == requestTargetGeneration) {
        record("finish-native-reach realm=%u target=%u", controller.realm, requestTargetGeneration);
    } else if (target != player && id == hit->standardId && (rva == hit->collisionReturnRva || rva == hit->forwardReturnRva)) {
        record("strike-native-post realm=%u target=%u", controller.realm, generation(target));
    } else if (target == player && rva == 0xaf88e && id == 0x1000016) {
        record("soul-native-receipt realm=%u", controller.realm);
    }
    return originalPost(target, id, data);
}
#endif

#ifdef SR1_LOCAL_AIR_CONTACT
#ifdef SR1_LOCAL_COMBAT55
#include "local-spell-policy55.h"
#endif
#include "local-air-contact.h"
#ifdef SR1_LOCAL_COMBAT55
#include "local-spell55.h"
#endif
#ifdef SR1_LOCAL_COMBAT48
#include "local-charge-cast48.h"
#ifdef SR1_LOCAL_COMBAT53
#include "local-utility53.h"
#ifdef SR1_LOCAL_COMBAT55
#include "local-utility-native55.h"
#endif
#endif
#endif
#endif

#ifdef SR1_MEASURED_GROUND_COMBO
#ifdef SR1_LOCAL_COMBAT48
#include "local-soul48.h"
#endif
static uintptr_t traceComboPost(uintptr_t target, uint32_t id, uintptr_t data) {
    const uintptr_t caller = (uintptr_t)__builtin_return_address(0);
#ifdef SR1_LOCAL_COMBAT53
    if(caller-base==C4_NATIVE_REWARD_RETURN&&id==C4_NATIVE_REWARD_MESSAGE&&target==player&&localRewardSoul48&&localRewardGeneration48){
        const DWORD incoming53=GetLastError();const Sr1LocalFrame f53=readLocalFrame(false);const bool absorbed53=localFinishRead53().absorbed;
        if(localFinishReward53(&f53,localRewardSoul48,localRewardGeneration48,data)){
            if(!absorbed53&&localSoulReward48(caller-base,target,id))localChargeCredit48(&f53,player,GetTickCount64(),sheet_sr1Combat48_combat_charge.finisherCharge,"native-finisher-soul-reward");
            SetLastError(incoming53);return 0;
        }SetLastError(incoming53);
    }
#endif
#ifdef SR1_LOCAL_COMBAT48
    if(localSoulReward48(caller-base,target,id)){
        const uintptr_t result=originalComboPost(target,id,data);const DWORD error=GetLastError();
        const Sr1LocalFrame frame=readLocalFrame(false);
        localChargeCredit48(&frame,player,GetTickCount64(),sheet_sr1Combat48_combat_charge.finisherCharge,"native-soul-reward");
        SetLastError(error);return result;
    }
#endif
#ifdef SR1_LOCAL_AIR_CONTACT
    const DWORD error = GetLastError();
    localObserveStasisPost(caller-base,target,id,data);
    const bool projected = localForwardAirContact(caller-base,target,id,data);
    SetLastError(error);
    if (projected) return 0;
#endif
    if (id == (uint32_t)hit->standardId && target &&
        (caller == base + (uintptr_t)hit->collisionReturnRva || caller == base + (uintptr_t)hit->forwardReturnRva)) {
        const DWORD error = GetLastError();
        const Sr1LocalFrame frame = readFrame();
        if (frame.groundStrike && target != player) {
            record("defiance-strike-native-contact realm=%u ordinal=%u phase=%ld/%ld target=%u route=%s",
                frame.realm, frame.strikeOrdinal, (long)frame.strikeTime, (long)frame.strikeEnd, generation(target),
                caller == base + (uintptr_t)hit->collisionReturnRva ? "collision" : "forward");
        }
        SetLastError(error);
    }
#ifdef SR1_LOCAL_COMBAT48
    // Custom Reaver damage uses the submitted visible blade and the same native narrow phase.
    if(id==(uint32_t)hit->standardId&&target&&target!=player&&data&&
       (caller==base+(uintptr_t)hit->collisionReturnRva||caller==base+(uintptr_t)hit->forwardReturnRva)){
        const Sr1LocalFrame frame=readFrame();LocalVictimAttack attack=LOCAL_VICTIM_NO_ACTION;
        const LocalActionOwner owner=localStrikeContactAction(&frame,player,GetTickCount64(),&attack);
        C2NativeHit nativeHit;
        if(owner.tick&&!localPhysicalCarry(player)&&readAt(data,&nativeHit,sizeof nativeHit)&&nativeHit.actor==player)return 0;
    }
#endif
    return originalComboPost(target, id, data);
}
#endif

static bool matches(uintptr_t rva, const unsigned char *proof, size_t count) {
    unsigned char bytes[1024];
    return count <= sizeof(bytes) && readAt(base + rva, bytes, count) && !memcmp(bytes, proof, count);
}

#ifdef SR1_DEFIANCE_MOTION
#include "defiance-ground-draw.h"
#endif
#ifdef SR1_DEFIANCE_GROUND_CALIBRATION
#ifdef SR1_LOCAL_COMBAT57
#include "local-spacing57.h"
#endif
#include "local-motion-forward.h"
#ifdef SR1_LOCAL_STRIKE_TRAVEL
#include "local-strike-travel.h"
#endif
#ifdef SR1_LOCAL_COMBAT_PRESENTATION
#include "local-blade-visibility.h"
#ifdef SR1_LOCAL_ROTOR44
#include "local-native-audio.h"
#endif
#endif
#ifdef SR1_LOCAL_REAVER_PRESENTATION
#include "local-blade-render.h"
#endif
#endif
#ifdef SR1_DEFIANCE_GROUND_RESPONSIVE
#include "local-ground-start.h"
#endif
#ifdef SR1_LOCAL_DEFIANCE_JUMP
#include "local-jump-launch.h"
#endif

#ifdef SR1_LOCAL_COMBAT60
#ifdef SR1_LOCAL_COMBAT66
#include "local-arena66.h"
#endif
#include "local-portable60.h"
#endif
static DWORD WINAPI start(void *ignored) {
    (void)ignored;
    wchar_t file[1024];
#ifdef SR1_LOCAL_COMBAT60
    if(!portableStart60())return 0;
    swprintf(file, ARRAYSIZE(file), L"%ls/sr1-%lu.log", portableReports60,
#else
    swprintf(file, ARRAYSIZE(file), L"%ls/sr1-%lu.log", REPORT_PATH,
#endif
        (unsigned long)GetCurrentProcessId());
    trace = CreateFileW(file, FILE_APPEND_DATA, FILE_SHARE_READ, NULL, CREATE_NEW, FILE_ATTRIBUTE_NORMAL, NULL);
    HMODULE image = NULL;
    for (unsigned n = 0; !image && n < 1800; ++n) {
        image = GetModuleHandleW(L"sr1.dll");
        if (!image) Sleep(100);
    }
    if (!image) { record("refused no-sr1-module"); return 0; }
    base = (uintptr_t)image;
    char digest[65];
    if (!GetModuleFileNameW(image, file, ARRAYSIZE(file)) || !hashFile(file, digest) ||
        strcmp(digest, "c006dea45509cdc3fbfab3a4230b47869c306ecdd7df8b4fd2499fd3654a2205") ||
        !GetModuleFileNameW(NULL, file, ARRAYSIZE(file)) || !hashFile(file, digest) ||
        strcmp(digest, "0fb3aef0530ebf0510191f934dc371b69b43574331d3623eda694b72f060db93")) {
        record("refused unknown-build");
        return 0;
    }
    const unsigned char padProof[] = PROOF_PAD;
#ifdef SR1_LOCAL_COMBAT55
    const unsigned char utilityDecodeProof55[]=PROOF_DECODE;
    if(!matches(signals->decodeHoldRva,utilityDecodeProof55,sizeof utilityDecodeProof55)){record("refused utility-decode-boundary");return 0;}
#endif
#ifndef SR1_MOVEMENT_ONLY
    const unsigned char decodeProof[] = PROOF_DECODE, postProof[] = PROOF_POST;
#elif defined(SR1_MEASURED_GROUND_COMBO)
    const unsigned char postProof[] = PROOF_POST;
#endif
    if (!matches(pad->composerRva, padProof, sizeof(padProof))
#ifndef SR1_MOVEMENT_ONLY
        ||
        !matches(signals->decodeHoldRva, decodeProof, sizeof(decodeProof)) ||
        !matches(hit->postRva, postProof, sizeof(postProof))
#elif defined(SR1_MEASURED_GROUND_COMBO)
        || !matches(hit->postRva, postProof, sizeof(postProof))
#endif
    ) {
        record("refused runtime-code-mismatch");
        return 0;
    }
#ifdef SR1_LOCAL_FORMS45
#ifdef SR1_LOCAL_COMBAT60
    if(!portableFormsProof60()){record("refused reaver-form-health-boundary");portableStatus60("Failed: native health proof");return 0;}
#else
    if(!localFormsPrepare()){record("refused reaver-form-health-boundary");return 0;}
#endif
#endif
#ifdef SR1_LOCAL_BATTLE46
    if(!verifyDrawBlock(sheet_sr1Battle46_defiance_combat.autoFaceRva,(DWORD)sheet_sr1Battle46_defiance_combat.autoFaceBytes,LOCAL_BATTLE_FACE46_SHA)){record("refused auto-face-code-boundary");return 0;}
#endif
    if (MH_Initialize() != MH_OK ||
        MH_CreateHook((void *)(base + pad->composerRva), compose, (void **)&originalPad) != MH_OK
#ifndef SR1_MOVEMENT_ONLY
        ||
        MH_CreateHook((void *)(base + signals->decodeHoldRva), decode, (void **)&originalDecode) != MH_OK ||
        MH_CreateHook((void *)(base + hit->postRva), post, (void **)&originalPost) != MH_OK
#elif defined(SR1_MEASURED_GROUND_COMBO)
        || MH_CreateHook((void *)(base + hit->postRva), traceComboPost, (void **)&originalComboPost) != MH_OK
#endif
#ifdef SR1_LOCAL_COMBAT55
        || MH_CreateHook((void*)(base+signals->decodeHoldRva),localUtilityDecode55,(void**)&originalUtilityDecode55)!=MH_OK
#endif
    ) {
        MH_Uninitialize();
        record("refused hook-installation");
        return 0;
    }
#ifdef SR1_LOCAL_COMBO_ADMISSION
    const unsigned char comboKeyProof[] = PROOF_COMBO_KEY;
    const unsigned char comboCallerProof[] = PROOF_COMBO_KEY_CALLER;
    if (!matches(comboAdmission->keyGetterRva, comboKeyProof, sizeof(comboKeyProof)) ||
        !matches(comboAdmission->keyCallerReturnRva - sizeof(comboCallerProof), comboCallerProof, sizeof(comboCallerProof)) ||
        MH_CreateHook((void *)(base + comboAdmission->keyGetterRva), nativeStrikeKey,
            (void **)&originalNativeStrikeKey) != MH_OK) {
        MH_Uninitialize();
        record("refused native-combo-key-hook");
        return 0;
    }
#endif
#ifdef SR1_LOCAL_GROUND_ACTIONS
    const unsigned char groundSwitchProof[] = PROOF_GROUND_SWITCH;
    const unsigned char movingStrikeCallerProof[] = PROOF_MOVING_STRIKE_CALLER;
    if (!matches(groundActions->switchRva, groundSwitchProof, sizeof(groundSwitchProof)) ||
        !matches(groundActions->movingAttackReturnRva - sizeof(movingStrikeCallerProof),
            movingStrikeCallerProof, sizeof(movingStrikeCallerProof)) ||
        MH_CreateHook((void *)(base + groundActions->switchRva), nativeGroundSwitch,
            (void **)&originalGroundSwitch) != MH_OK) {
        MH_Uninitialize();
        record("refused grounded-strike-entry-hook");
        return 0;
    }
#endif
#ifdef SR1_LOCAL_NATIVE_COMBO_CLOCK
    const unsigned char nativeClockEntry[] = NATIVE_CLOCK_ENTRY;
    const unsigned char nativeClockCaller[] = NATIVE_CLOCK_CALLER;
    const unsigned char nativeClockDispatch[] = NATIVE_CLOCK_DISPATCH;
    const unsigned char nativeClockUpdate[] = NATIVE_CLOCK_UPDATE;
    if (!matches(nativeClock->advanceRva, nativeClockEntry, sizeof(nativeClockEntry)) ||
        !matches(nativeClock->callerReturnRva-5, nativeClockCaller, sizeof(nativeClockCaller)) ||
        !matches(nativeClock->dispatchJumpRva,nativeClockDispatch,sizeof(nativeClockDispatch)) ||
        !matches(nativeClock->updateReturnRva-5,nativeClockUpdate,sizeof(nativeClockUpdate)) ||
        MH_CreateHook((void *)(base + nativeClock->advanceRva), advanceNativeGroundSection,
            (void **)&originalNativeSectionAdvance) != MH_OK) {
        MH_Uninitialize();
        record("refused native-ground-combo-clock");
        return 0;
    }
#endif
#ifdef SR1_DEFIANCE_MOTION
    const bool groundPose = prepareGroundDraw();
#endif
#ifdef SR1_LOCAL_COMBAT_SYNC42
    if (!prepareSynchronizedClock()) {
        MH_Uninitialize();
        record("refused synchronized-ground-combo-clock");
        return 0;
    }
    record("synchronized-ground-combo-clock ready=1");
#endif
#ifdef SR1_DEFIANCE_GROUND_CALIBRATION
    const bool speed = groundPose && prepareLocalMotion();
    record("calibrated-ground-controllers ready=%u", (unsigned)speed);
#endif
#ifdef SR1_LOCAL_STRIKE_TRAVEL
    record("defiance-strike-travel ready=%u", (unsigned)(speed && prepareLocalStrikeTravel()));
#endif
#ifdef SR1_LOCAL_COMBAT_PRESENTATION
    record("native-reaver-visibility ready=%u", (unsigned)prepareLocalBladeVisibility());
#endif
#ifdef SR1_DEFIANCE_GROUND_RESPONSIVE
    const bool startMotion = groundPose && prepareLocalGroundStart();
    record("responsive-ground-start ready=%u", (unsigned)startMotion);
#endif
#ifdef SR1_LOCAL_DEFIANCE_JUMP
    const bool jumpMotion = groundPose && prepareLocalJump();
    record("defiance-jump-controller ready=%u", (unsigned)jumpMotion);
#endif
#ifdef SR1_LOCAL_JUMP_REPEAT
    const bool repeatMotion = jumpMotion && prepareLocalRepeat();
    record("defiance-repeat-jump ready=%u", (unsigned)repeatMotion);
#ifdef SR1_LOCAL_SURFACE_TRACE
    const bool floorReader = repeatMotion && prepareLocalSurface();
    record("defiance-jump-support-reader ready=%u", (unsigned)floorReader);
#ifdef SR1_LOCAL_AIR_SLAM
    const bool slamReady = floorReader && prepareLocalSlam();
    InterlockedExchange(&localAirSlamReady, (LONG)slamReady);
    record("defiance-slam-controller ready=%u", (unsigned)slamReady);
#endif
#endif
#endif
#ifdef SR1_LOCAL_AIR_CONTACT
    if (!prepareLocalAirContact()) {
        MH_Uninitialize();
        record("refused standalone-air-contact");
        return 0;
    }
#endif
#ifdef SR1_LOCAL_ROTOR44
    if(!prepareLocalNativeAudio()) {
        MH_Uninitialize();record("refused native-sword-audio boundary");return 0;
    }
    if(InterlockedCompareExchange(&localAudioReady,0,0)) {
        HANDLE audioWorker=CreateThread(NULL,0,localAudioWorker,NULL,0,NULL);
        if(audioWorker)CloseHandle(audioWorker);
    }
#endif
#ifdef SR1_LOCAL_COMBAT48
    if(!verifyDrawBlock(sheet_sr1Combat48_combat_charge.characterSwitchRva,163,LOCAL_CHARACTER48_SHA)||
       MH_CreateHook((void *)(base+sheet_sr1Combat48_combat_charge.characterSwitchRva),localCharacter48,(void **)&originalCharacter48)!=MH_OK){
        MH_Uninitialize();record("refused character-state-switch-hook");return 0;
    }
    const unsigned char soulProof48[]=LOCAL_SOUL48_PROOF;
    if(!matches(717440u,soulProof48,sizeof soulProof48)||MH_CreateHook((void *)(base+717440u),localSoulUpdate48,(void **)&originalSoul48)!=MH_OK){
        MH_Uninitialize();record("refused native-soul-reward-observer");return 0;
    }
#endif
#ifdef SR1_LOCAL_COMBAT55
    if(!localSpellPrepare55()){MH_Uninitialize();record("refused spell-regen-boundary");return 0;}
#endif
#ifdef SR1_LOCAL_COMBAT66
    if(!arenaPrepare66()){MH_Uninitialize();record("refused arena-native-boundary");return 0;}
#endif
    if (MH_EnableHook(
#ifdef SR1_LOCAL_COMBAT60
        (void*)(base+pad->composerRva)
#else
        MH_ALL_HOOKS
#endif
    ) != MH_OK) {
        MH_Uninitialize();
        record("refused hook-activation");
        return 0;
    }
#ifdef SR1_LOCAL_REAVER_PRESENTATION
    record("defiance-blade-render ready=%u", (unsigned)(groundPose && prepareLocalBladeRender()));
#endif
#ifdef SR1_DEFIANCE_MOTION
    record("ready sr1-local-defiance-ground=%u", (unsigned)groundPose);
#ifdef SR1_LOCAL_COMBAT60
    InterlockedExchange(&portableReady60,(LONG)groundPose);portableStatus60(groundPose?"Off — F10 to enable":"Failed: RAM resources");
#endif
#elif defined(SR1_MOVEMENT_ONLY)
    record("ready sr1-local-movement");
#else
    record("ready sr1-local");
#endif
    return 0;
}

BOOL WINAPI DllMain(HINSTANCE instance, DWORD reason, void *reserved) {
    (void)reserved;
    if (reason == DLL_PROCESS_ATTACH) {
        DisableThreadLibraryCalls(instance);
#ifdef SR1_LOCAL_COMBAT60
        portableModule60=instance;
#endif
        HANDLE worker = CreateThread(NULL, 0, start, NULL, 0, NULL);
        if (worker) CloseHandle(worker);
    }
    return TRUE;
}

