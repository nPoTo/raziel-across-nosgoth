// SPDX-License-Identifier: GPL-3.0-or-later
#pragma once

#include "native-pair.h"
#include "local-damage61.h"
#ifdef SR1_LOCAL_COMBAT48
#include "local-contact-geometry48.h"
#endif
#include "sphere-center.h"
#include "local-victim-reaction.h"
#ifdef SR1_LOCAL_COMBAT55
#include "local-contact55.h"
#endif

typedef uintptr_t (*LocalBroad)(uintptr_t);
typedef uintptr_t (*LocalNarrow)(uintptr_t,uintptr_t,uint32_t);
typedef uintptr_t (*LocalTransform)(uintptr_t,int32_t *,uint32_t *);
typedef void (*LocalEnemyEvent)(uintptr_t,uintptr_t);
typedef int (*LocalEnemyDamage)(uintptr_t,int32_t,uint32_t);
typedef void (*LocalVictimTransition)(uintptr_t,uint32_t);
typedef void (*LocalVictimMove)(uintptr_t);

typedef struct {
    LocalActionOwner owner;
    C2VisibleSegment segment;
    uintptr_t blade;
    uint64_t drawTick;
#ifdef SR1_LOCAL_COMBAT48
    uint64_t motionKey;
#endif
    int16_t root[3];
    LocalVictimAttack attack;
} LocalStrikeDraw;

typedef struct {
    uintptr_t actor,state;
    uint32_t generation,mainState,monsterClass;
#ifdef SR1_LOCAL_COMBAT59
    unsigned nativeKind;
#endif
    int16_t hp;
} LocalTarget;

typedef struct {
    C2NativeSphere native;
    uintptr_t primitive,entry;
    unsigned char flags;
} LocalSphere;

typedef struct {
    LocalTarget target;
    LocalActionOwner owner;
    LocalVictimAttack attack;
    uintptr_t payload;
    uint64_t tick;
    C2NativeSphere sphere;
} LocalContactTicket;

static const Sheet_sr1LocalAirContact *const contactPolicy=&sheet_sr1LocalAirContact_standalone_contact;
static const Sheet_c2HostGeometry *const contactGeometry=&sheet_c2HostGeometry_host_observation;
static LocalBroad originalLocalBroad;
static LocalTransform originalLocalTransform;
static LocalEnemyEvent originalLocalEnemyEvent;
static LocalEnemyDamage originalLocalEnemyDamage;
static LocalVictimTransition originalLocalVictimTransition;
static LocalVictimMove originalLocalVictimMove;
static SRWLOCK localContactDrawLock=SRWLOCK_INIT;
static LocalStrikeDraw localContactDraw;
#ifdef SR1_LOCAL_COMBAT48
static LocalStrikeDraw localPreviousDraw48;
static _Thread_local struct {LocalActionOwner owner;uint32_t target;} localHitReceipts48[512];
static _Thread_local unsigned localHitCursor48;
static bool localAlreadyHit48(const LocalActionOwner *owner,uint32_t target){
 for(unsigned i=0;i<512;i++){
  const LocalActionOwner *prior=&localHitReceipts48[i].owner;
  if(prior->tick==owner->tick&&prior->actor==owner->actor&&prior->generation==owner->generation&&prior->world==owner->world&&prior->realm==owner->realm&&localHitReceipts48[i].target==target)return true;
 }return false;
}
#endif
static _Thread_local LocalContactTicket localTickets[8];
static _Thread_local LocalContactTicket *activeLocalTicket;
static _Thread_local bool localDamageConfirmed;
#ifdef SR1_LOCAL_COMBAT60
static _Thread_local bool localReactionConfirmed61;
static _Thread_local unsigned localExpectedDamage61;
#endif
static _Thread_local C2NativePairPlan localPair;
static _Thread_local uintptr_t localPairTarget;
static _Thread_local LocalContactTicket localPairTicket;
static _Thread_local LocalActionOwner localContactForwarded;
static _Thread_local LocalVictimFlight localFlight;
static _Thread_local LocalContactTicket localFlightTicket;
static _Thread_local uint64_t localVictimGroundedAt;
static _Thread_local bool localStasisDispatch;
typedef struct {
    LocalActionOwner owner;
    uintptr_t projectile;
    uint32_t generation;
    uint64_t spawned;
#ifdef SR1_LOCAL_COMBAT54
    uintptr_t selected;
    uint32_t selectedGen;
    bool closeAttempted;
#ifdef SR1_LOCAL_COMBAT60
    LocalContactTicket lifted62;
    int32_t direction62[2];
#endif
#endif
} LocalStasisShot;
static _Thread_local LocalStasisShot localStasisShot;
#ifdef SR1_LOCAL_COMBAT53
static _Thread_local LocalStasisShot localForceShots53[32];static _Thread_local unsigned localForceShotCursor53;
typedef struct {LocalActionOwner owner;uintptr_t target,payload;uint32_t gen;uint64_t tick;} LocalForceReceipt53;
#ifdef SR1_LOCAL_COMBAT60
typedef struct {LocalForceReceipt53 receipt;LocalContactTicket lifted;int32_t direction[2];}LocalForceThrow62;
static _Thread_local LocalForceThrow62 localForceThrows62[32];static _Thread_local unsigned localForceThrowCursor62;
static void localCaptureForce62(LocalStasisShot*,const Sr1LocalFrame*,uintptr_t,uint32_t,uint64_t);
#endif
static _Thread_local LocalForceReceipt53 localForceReceipts53[32],localForceActive53;static _Thread_local unsigned localForceReceiptCursor53;
#endif
static _Thread_local LocalContactTicket localStasisImpact;
static _Thread_local uint64_t localStasisLockedUntil;

static LocalActionOwner localStrikeContactAction(const Sr1LocalFrame *frame, uintptr_t actor,
    uint64_t now, LocalVictimAttack *attack) {
    if (!frame->ready || !frame->renderBlend || frame->realm==SR1_LOCAL_UNKNOWN)
        return (LocalActionOwner){0};
    const LocalAirSlam slam=readLocalSlam(frame,actor,now,slamRecoveryDuration());
    if ((slam.falling
#ifdef SR1_LOCAL_COMBAT49
        || slam.windup
#endif
    ) && !slam.impact) {
        *attack=slam.rebound?LOCAL_VICTIM_REBOUNDING_SLAM_HIT:LOCAL_VICTIM_SLAM_HIT;
        return slam.owner;
    }
    const LocalSpecial special=localReadSpecial(frame,actor,now);
    if (special.move && special.move!=LOCAL_SPECIAL_EMPYREAL && (sheet_sr1LocalSpecialBanks_rows[special.bank]->hitFrame
#ifdef SR1_LOCAL_COMBAT55
        || localPerforateContact55(special.move==LOCAL_SPECIAL_PERFORATE,special.bank,special.first,special.owner.tick,now,localSpecialDuration(special.bank))
#endif
    )) {
        *attack=special.move==LOCAL_SPECIAL_SHATTER?LOCAL_VICTIM_LIFT_HIT:
            special.move==LOCAL_SPECIAL_TEMPEST?LOCAL_VICTIM_AIR_X_HIT:LOCAL_VICTIM_NO_ACTION;
        LocalActionOwner owner=special.owner;
#ifdef SR1_LOCAL_LOCK47
        if (special.move==LOCAL_SPECIAL_TEMPEST && special.bank==special.first+1 && special.spinStarted && special.spins) {
            uint64_t turn=combatRotorShownAge(now-special.spinStarted,special.spins)/combatRotorPeriod();
            if (turn>=special.spins) turn=special.spins-1;
            owner.tick=special.spinStarted+turn*combatRotorPeriod();
        }
#endif
        return owner;
    }
    const LocalAirStrike strike=readLocalAirStrike(frame,actor,now);
    if (strike.owner.tick) {
        *attack=LOCAL_VICTIM_AIR_X_HIT;
        return strike.owner;
    }
    const LocalCombatInput input=readLocalCombatInput();
    if (!input.airborneLift && frame->grounded && localYPresentation(&input,frame,actor,now)) {
        *attack=LOCAL_VICTIM_LIFT_HIT;
        return input.lift;
    }
#ifdef SR1_LOCAL_COMBAT48
    const LocalGroundX ground=readGroundX(frame,actor,now);
    if(ground.owner.tick&&ground.start){LocalActionOwner owner=ground.owner;owner.tick=ground.start;*attack=LOCAL_VICTIM_NO_ACTION;return owner;}
#endif
    return (LocalActionOwner){0};
}

static void localPublishContactDraw(uintptr_t actor,const float matrix[16],float length) {
    const uint64_t now=GetTickCount64();
    const Sr1LocalFrame frame=readLocalFrame(true);
    LocalStrikeDraw draw={.drawTick=now};
    draw.owner=localStrikeContactAction(&frame,actor,now,&draw.attack);
#ifdef SR1_LOCAL_COMBAT48
    draw.motionKey=draw.owner.tick;
    const LocalSpecial spinning=localReadSpecial(&frame,actor,now);
    if(spinning.move==LOCAL_SPECIAL_TEMPEST&&spinning.bank==spinning.first+1)draw.motionKey=spinning.spinStarted;
#endif
    if (!draw.owner.tick || player!=actor || !isfinite(length) || length<=0.f ||
        !readAt(base+host->reaverRva,&draw.blade,8) || !draw.blade ||
        !readAt(actor+contactGeometry->rootOffset,draw.root,sizeof(draw.root))) return;
    for (unsigned i=0;i<3;i++) {
        draw.segment.palm[i]=matrix[12+i];
        draw.segment.tip[i]=matrix[12+i]+matrix[8+i]*length;
        if (!isfinite(draw.segment.palm[i]) || !isfinite(draw.segment.tip[i])) return;
    }
    AcquireSRWLockExclusive(&localContactDrawLock);
#ifdef SR1_LOCAL_COMBAT48
    if(localContactDraw.drawTick!=draw.drawTick)localPreviousDraw48=localContactDraw;
#endif
    localContactDraw=draw;
    ReleaseSRWLockExclusive(&localContactDrawLock);
}

#ifdef SR1_LOCAL_COMBAT59
#include "local-native59.h"
#endif
static bool localReadContactTarget(uintptr_t target,uint32_t stream,LocalTarget *out) {
    uintptr_t collision=0,message=0,data=0,object=0,name=0,parent=0;
    uint32_t magic=0,flags=0,room=0;
    char nameText[9];
    LocalTarget read={.actor=target,.generation=generation(target)};
    if (!target || !read.generation ||
        !readAt(target+0x60,&room,4) || room!=stream || !readAt(target+0x28,&flags,4) || (flags&0x24040000u) ||
        !readAt(target+host->parentOffset,&parent,8) || parent ||
        !readAt(target+0x1a0,&collision,8) || collision!=base+contactPolicy->monsterCollisionRva ||
        !readAt(target+0x1b8,&message,8) ||
#ifndef SR1_LOCAL_COMBAT59
        message!=base+contactPolicy->monsterMessageRva ||
#endif
        !readAt(target+0x40,&data,8) || !data || !readAt(data,&magic,4) || magic!=contactPolicy->monsterMagic ||
        !readAt(target+0x30,&object,8) || !object || !readAt(object+0x30,&name,8) || !name ||
        !readAt(name,nameText,sizeof(nameText)) || !memcmp(nameText,"soul____",9) ||
        !readAt(target+0x2c0,&read.state,8) || !read.state ||
        !readAt(target+contactPolicy->stateOffset,&read.mainState,4) ||
        !readAt(read.state+contactPolicy->healthOffset,&read.hp,2) || read.hp<0) return false;
#ifdef SR1_LOCAL_COMBAT59
    if(!localMonsterMessage59(message,nameText))return false;
#endif
    read.monsterClass=(uint32_t)((QueryInstance)(base+signals->queryRva))(target,1);
    if (read.monsterClass&AIR_PROTECTED_MONSTER_MASK) return false;
    *out=read;
    return true;
}

#ifdef SR1_LOCAL_LOCK47
#ifdef SR1_LOCAL_COMBAT59
static bool localLockCandidate59(uintptr_t target,const Sr1LocalFrame *frame,LocalTarget *current){
    if(localReadContactTarget(target,frame->worldGeneration,current))return current->hp>0||current->mainState==9;
    if(frame->realm!=SR1_LOCAL_MATERIAL||!localNativeTarget59(target,frame->worldGeneration,current))return false;
    if(current->nativeKind==LOCAL_NATIVE59_LIMB)return current->mainState==6&&current->hp>0;
    if(current->nativeKind==LOCAL_NATIVE59_BODY)return current->mainState==6;
    return current->nativeKind==LOCAL_NATIVE59_KAIN&&(current->mainState==6||current->mainState==13);
}
#endif
static bool localLockReadTarget47(uintptr_t target,const Sr1LocalFrame *frame,uint32_t *gen,int16_t pos[3]) {
    LocalTarget current;
#ifdef SR1_LOCAL_COMBAT59
    if(!localLockCandidate59(target,frame,&current)||!readAt(target+0x9c,pos,6))return false;
#else
    if(!localReadContactTarget(target,frame->worldGeneration,&current)||!readAt(target+0x9c,pos,6))return false;
#endif
    *gen=current.generation; return true;
}
#endif

static bool localNativeLineClear(uintptr_t actor,uint32_t stream,const float origin[3],const int16_t to[3]) {
    const uintptr_t unit=((uintptr_t (*)(int32_t))(base+contactPolicy->streamRva))((int32_t)stream);
    uintptr_t terrain=0;
    if (!unit || !readAt(unit,&terrain,8) || !terrain) return false;
    int16_t start[4]={0},end[4]={0};
    uint64_t query[12]={0};
    for (unsigned i=0;i<3;i++) {
        if (!isfinite(origin[i]) || origin[i]<INT16_MIN || origin[i]>INT16_MAX) return false;
        start[i]=(int16_t)lroundf(origin[i]);
        end[i]=to[i];
    }
    if (!memcmp(start,end,sizeof(start))) return true;
    query[4]=(uintptr_t)end;
    query[5]=(uintptr_t)start;
    query[7]=1;
    query[8]=actor;
    ((void (*)(void *,uintptr_t))(base+contactPolicy->lineRva))(query,unit);
    return (query[0]&0xffffu)==0;
}

#ifdef SR1_LOCAL_COMBAT49
#include "local-scene49.h"
#endif
static bool localContactSphere(uintptr_t actor,bool blade,bool first,const C2VisibleSegment *segment,
    const LocalSphere *sword,LocalSphere *out) {
    uintptr_t models=0,entries=0,palette=0;
    int16_t model;
    uint32_t count=0;
    const Sheet_c2HostGeometry *p=contactGeometry;
    if (!readAt(actor+p->collisionModelsOffset,&models,8) || !models ||
        !readAt(actor+p->modelIndexOffset,&model,2) || model<0 || model>31 ||
        !readAt(models+(uintptr_t)model*16,&entries,8) || !entries ||
        !readAt(models+(uintptr_t)model*16+8,&count,4) || !count || count>128 ||
        !readAt(actor+p->currentPaletteOffset,&palette,8) || !palette) return false;
    for (uint32_t i=0;i<count;i++) {
        unsigned char entry[16],sphere[16],matrix[32];
        LocalSphere candidate={.entry=entries+(uintptr_t)i*16};
        if (!readAt(candidate.entry,entry,sizeof(entry))) return false;
        if (!c2SphereEntryUsable(entry,blade,first)) continue;
        memcpy(&candidate.primitive,entry+8,sizeof(candidate.primitive));
        if (!candidate.primitive || !readAt(candidate.primitive,sphere,sizeof(sphere))) continue;
        if (blade ? !c2PrimaryBladeSphere(sphere) :
#ifdef SR1_LOCAL_COMBAT59
            !localNativeSphere59(actor,readFrame().worldGeneration,entry,sphere)
#else
            sphere[4]!=8
#endif
        ) continue;
        if (!readAt(palette+(uintptr_t)entry[3]*32,matrix,sizeof(matrix)) ||
            !sr1CollisionSphereCenter(matrix,sphere,candidate.native.center,&candidate.native.radius)) continue;
        int16_t projected[3];
        if (!blade && segment && sword && !c2SphereProjection(segment,&sword->native,&candidate.native,projected)) continue;
        candidate.flags=entry[0];
        *out=candidate;
        return true;
    }
    return false;
}

#ifdef SR1_LOCAL_COMBAT54
#include "local-force-close54.h"
#endif

static LocalVictimIdentity localContactIdentity(const LocalContactTicket *ticket) {
    return (LocalVictimIdentity){GetCurrentProcessId(),ticket->owner.world,ticket->owner.realm,
        ticket->owner.generation,ticket->target.generation};
}

static bool localTicketCurrent(const LocalContactTicket *ticket,const Sr1LocalFrame *frame,
    uint64_t now,uint64_t age,LocalTarget *current) {
    return ticket->target.actor && sameLocalAction(&ticket->owner,frame,player,now,age) &&
        frame->renderBlend && (localReadContactTarget(ticket->target.actor,frame->worldGeneration,current)
#ifdef SR1_LOCAL_COMBAT59
        || (ticket->target.nativeKind&&localNativeTarget59(ticket->target.actor,frame->worldGeneration,current)&&current->nativeKind==ticket->target.nativeKind)
#endif
        ) &&
        current->generation==ticket->target.generation && current->state==ticket->target.state;
}

static bool localPairForTarget(const LocalStrikeDraw *draw,const C2VisibleSegment *segment,
    uintptr_t target,bool swordFirst,LocalSphere *sword,LocalContactTicket *ticket,C2NativePairPlan *plan) {
    LocalTarget victim;
    LocalSphere sphere;
    if (!(localReadContactTarget(target,draw->owner.world,&victim)
#ifdef SR1_LOCAL_COMBAT59
        || (localNativeTarget59(target,draw->owner.world,&victim)&&localNativeWindow59(&victim,draw))
#endif
        ) ||
#ifdef SR1_LOCAL_COMBAT48
        localAlreadyHit48(&draw->owner,victim.generation) ||
#endif
        ((int (*)(uintptr_t,uintptr_t))(base+contactPolicy->sameFamilyRva))(draw->blade,target) ||
        !localContactSphere(draw->blade,true,swordFirst,NULL,NULL,sword) ||
        !localContactSphere(target,false,!swordFirst,segment,sword,&sphere)) return false;
    const C2ContactAuthority authority={.epoch=GetCurrentProcessId(),.marker=draw->owner.tick,
        .sourceGeneration=draw->owner.generation,.sourcePoseSerial=draw->drawTick,.hostSourcePoseSerial=draw->drawTick,
        .realm=draw->owner.realm,.sourceForm=
#ifdef SR1_LOCAL_FORMS45
        localCurrentForm(draw->owner.realm),
#else
        draw->owner.realm==SR1_LOCAL_SPECTRAL?1u:2u,
#endif
        .playerGeneration=draw->owner.generation,.targetGeneration=victim.generation,
        .acquired=true,.hostCanStrike=true,.targetCanReceive=true,.sceneClear=true};
    if (!c2BuildNativePair(plan,&authority,segment,&sword->native,&sphere.native,sword->primitive+8,swordFirst) ||
        !localNativeLineClear(draw->owner.actor,draw->owner.world,segment->palm,sphere.native.center)) return false;
    *ticket=(LocalContactTicket){.target=victim,.owner=draw->owner,.attack=draw->attack,.sphere=sphere.native};
    return true;
}

static bool localSubmitPair(const LocalStrikeDraw *draw,const C2VisibleSegment *segment,uintptr_t target) {
    LocalSphere sword;
    C2NativePairPlan plan;
    LocalContactTicket ticket;
    bool first=true;
    if (!localPairForTarget(draw,segment,target,first,&sword,&ticket,&plan)) {
        first=false;
        if (!localPairForTarget(draw,segment,target,first,&sword,&ticket,&plan)) return false;
    }
    unsigned char entry=0;
    if (!readAt(sword.entry,&entry,1) || entry!=sword.flags) return false;
    const unsigned char enabled=(unsigned char)(entry|c2SphereEntryMask(first));
    localPair=plan;
    localPairTarget=target;
    localPairTicket=ticket;
    *(volatile unsigned char *)sword.entry=enabled;
    const LocalNarrow narrow=(LocalNarrow)(base+contactPolicy->narrowRva);
    narrow(first?draw->blade:target,first?target:draw->blade,first?1u:0u);
#ifdef SR1_LOCAL_COMBAT59
    if(ticket.target.nativeKind==LOCAL_NATIVE59_BELL){
        uint32_t flags59=0;
        if(localNativeIdentity59(target,draw->owner.world)==LOCAL_NATIVE59_BELL&&generation(target)==ticket.target.generation&&
            readAt(target+0x24,&flags59,4)&&(flags59&CATHEDRAL_BELL_CONTACT_BIT)){
            const unsigned receipt59=localHitCursor48++%512;localHitReceipts48[receipt59].owner=draw->owner;localHitReceipts48[receipt59].target=ticket.target.generation;
            record("defiance-native-bell-contact target=%u flag=%u",ticket.target.generation,flags59&CATHEDRAL_BELL_CONTACT_BIT);
        }
    }
#endif
    uintptr_t primitive=0;
    unsigned char after=0;
    if (readAt(sword.entry+8,&primitive,8) && primitive==sword.primitive &&
        readAt(sword.entry,&after,1) && (after==enabled || after==(enabled&~1u)))
        *(volatile unsigned char *)sword.entry=entry;
    localPair=(C2NativePairPlan){0};
    localPairTarget=0;
    localPairTicket=(LocalContactTicket){0};
#ifdef SR1_LOCAL_COMBAT48
    return localAlreadyHit48(&draw->owner,ticket.target.generation);
#else
    return localContactForwarded.tick==draw->owner.tick;
#endif
}

static void localTryAirContact(void) {
    if (localPair.ready) return;
    AcquireSRWLockShared(&localContactDrawLock);
    const LocalStrikeDraw draw=localContactDraw;
#ifdef SR1_LOCAL_COMBAT48
    const LocalStrikeDraw priorDraw=localPreviousDraw48;
#endif
    ReleaseSRWLockShared(&localContactDrawLock);
    const uint64_t now=GetTickCount64();
    if (!draw.owner.tick || draw.drawTick>now || now-draw.drawTick>(uint64_t)contactPolicy->drawFreshMs) return;
    const Sr1LocalFrame frame=readLocalFrame(true);
    LocalVictimAttack attack=LOCAL_VICTIM_NO_ACTION;
    const LocalActionOwner live=localStrikeContactAction(&frame,player,now,&attack);
    if (draw.owner.tick!=live.tick || draw.attack!=attack || !sameLocalAction(&draw.owner,&frame,player,now,UINT64_MAX) ||
#ifndef SR1_LOCAL_COMBAT48
        (sameLocalAction(&localContactForwarded,&frame,player,now,UINT64_MAX) && localContactForwarded.tick==live.tick) ||
#endif
        !localAirStrikeEquipped()) return;
    uintptr_t blade=0,parent=0,weaponHook=0,list=0,node=0;
    uint32_t count=0;
    int16_t root[3];
    C2VisibleSegment segment;
    if (!readAt(base+host->reaverRva,&blade,8) || blade!=draw.blade ||
        !readAt(blade+host->parentOffset,&parent,8) || parent!=player ||
        !readAt(blade+contactGeometry->collisionCallbackOffset,&weaponHook,8) ||
        weaponHook!=base+contactPolicy->reaverRva ||
        !readAt(player+contactGeometry->rootOffset,root,sizeof(root)) ||
        !c2RebaseSegment(&draw.segment,draw.root,root,(unsigned)contactPolicy->maxRootStep,&segment) ||
        !readAt(base+contactPolicy->listRva,&list,8) || !list || !readAt(list,&count,4) || count>512 ||
        !readAt(list+8,&node,8)) return;
    uintptr_t previous=0;
    while (count--) {
        uintptr_t next=0,back=0;
        if (!node || !readAt(node+0x10,&next,8) || !readAt(node+0x18,&back,8) || back!=previous) return;
        if (node!=blade && node!=player){
            const bool hit=localSubmitPair(&draw,&segment,node);
#ifdef SR1_LOCAL_COMBAT48
            if(!hit&&priorDraw.motionKey==draw.motionKey&&priorDraw.motionKey&&priorDraw.attack==draw.attack&&
              priorDraw.owner.actor==draw.owner.actor&&priorDraw.owner.world==draw.owner.world&&priorDraw.owner.generation==draw.owner.generation&&
              priorDraw.owner.realm==draw.owner.realm&&draw.drawTick>=priorDraw.drawTick&&draw.drawTick-priorDraw.drawTick<=80){
                C2VisibleSegment previousSegment;
                if(c2RebaseSegment(&priorDraw.segment,priorDraw.root,root,(unsigned)contactPolicy->maxRootStep,&previousSegment))
                 for(unsigned sample=1;sample<32&&sample<(unsigned)sheet_sr1Combat48_combat_charge.sweepSamples;sample++){
                  C2VisibleSegment swept;if(!localSweepSample48(&previousSegment,&segment,sample,&swept))continue;
                  if(localSubmitPair(&draw,&swept,node))break;
                 }
            }
#else
            if(hit)return;
#endif
        }
        previous=node;
        node=next;
    }
}

static uintptr_t localContactTransform(uintptr_t center,int32_t *out,uint32_t *flags) {
    const uintptr_t site=(uintptr_t)__builtin_return_address(0)-base;
    const uintptr_t result=originalLocalTransform(center,out,flags);
    c2NativePairCenter(&localPair,(uint32_t)site,center,out);
    return result;
}

static bool localForwardAirContact(uintptr_t site,uintptr_t recipient,uint32_t id,uintptr_t payload) {
    if (!localPair.ready || site!=contactPolicy->hitReturn || id!=hit->standardId || recipient!=player) return false;
    C2NativeHit data;
    const uint64_t now=GetTickCount64();
    const Sr1LocalFrame frame=readLocalFrame(true);
    LocalTarget current;
    const bool listed=localTicketCurrent(&localPairTicket,&frame,now,UINT64_MAX,&current);
    if (!payload || !readAt(payload,&data,sizeof(data)) ||
        !c2ShouldForwardHit(true,
#ifdef SR1_LOCAL_COMBAT48
            listed&&localAlreadyHit48(&localPairTicket.owner,current.generation),
#else
            localContactForwarded.tick==localPairTicket.owner.tick,
#endif
            listed,site,recipient,
            id,&data,player,localPairTarget)) return true;
#ifdef SR1_LOCAL_COMBAT59
    if(current.nativeKind){
        LocalStrikeDraw nativeDraw={.owner=localPairTicket.owner,.attack=localPairTicket.attack};
        if(!localNativeWindow59(&current,&nativeDraw))return true;
#ifdef SR1_LOCAL_COMBAT71
        const Sheet_sr1KainReaver70 *throne71=&sheet_sr1KainReaver70_throne_and_reaver;
        const Sheet_sr1KainHit71 *hit71=&sheet_sr1KainHit71_first_kain_native_hit;
        uint32_t intro71=0,flags71=0;const bool firstKain71=current.nativeKind==LOCAL_NATIVE59_KAIN&&
            readAt(current.actor+0x64,&intro71,4)&&intro71==(uint32_t)throne71->intro&&
            (frame.worldGeneration==(uint32_t)throne71->throneStream||frame.worldGeneration==(uint32_t)throne71->authoredStream);
        if(firstKain71&&(id!=(uint32_t)hit71->sourceMessage||!readAt(current.state+hit71->privateFlagsOffset,&flags71,4)))return true;
#endif
        const unsigned receipt59=localHitCursor48++%512;localHitReceipts48[receipt59].owner=localPairTicket.owner;localHitReceipts48[receipt59].target=current.generation;
        // Original narrow-phase payload stays unchanged. First Kain requires
        // his original immediate hit message rather than the general hit queue.
        // Never apply generic form damage, flight, soul or spell logic to puzzle/boss phases.
        originalComboPost(localPairTarget,
#ifdef SR1_LOCAL_COMBAT71
            firstKain71?(uint32_t)hit71->nativeMessage:
#endif
            id,payload);
#ifdef SR1_LOCAL_COMBAT71
        const DWORD nativeError71=GetLastError();
        if(firstKain71){uint32_t stateAfter71=0,flagsAfter71=0;const bool read71=readAt(current.actor+contactPolicy->stateOffset,&stateAfter71,4)&&readAt(current.state+hit71->privateFlagsOffset,&flagsAfter71,4);
            record("kain-native-hit71 target=%u message=%x before=%u after=%u flags-before=%x flags-after=%x read=%u",current.generation,(unsigned)hit71->nativeMessage,current.mainState,stateAfter71,flags71,flagsAfter71,read71);}
#endif
        record("defiance-native-object-contact kind=%u target=%u state=%u",current.nativeKind,current.generation,current.mainState);
#ifdef SR1_LOCAL_COMBAT71
        SetLastError(nativeError71);
#endif
        return true;
    }
#endif
    LocalContactTicket *slot=NULL;
    for (unsigned i=0;i<ARRAYSIZE(localTickets);i++) {
        if (!localTickets[i].payload || now-localTickets[i].tick>(uint64_t)contactPolicy->ticketFreshMs) {
            slot=&localTickets[i];
            break;
        }
    }
    if (!slot) return true;
    const uintptr_t event=((uintptr_t (*)(uintptr_t,uintptr_t,uint32_t,uint32_t,uint16_t))
        (base+contactPolicy->hitDataRva))(player,0,data.power,(uint32_t)contactPolicy->reactionDistance,
        (uint16_t)contactPolicy->reactionDuration);
    if (!event) return true;
    *slot=localPairTicket;
    slot->tick=now;
    slot->payload=event;
    localContactForwarded=localPairTicket.owner;
#ifdef SR1_LOCAL_COMBAT48
    const unsigned receipt=localHitCursor48++%512;localHitReceipts48[receipt].owner=localPairTicket.owner;localHitReceipts48[receipt].target=current.generation;
#endif
    originalComboPost(localPairTarget,id,event);
    record("standalone-contact realm=%u target=%u move=%u",frame.realm,current.generation,localPairTicket.attack);
    return true;
}

static void localObserveStasisPost(uintptr_t site,uintptr_t recipient,uint32_t id,uintptr_t payload) {
    const uint64_t now=GetTickCount64();
    if (localStasisDispatch && site==localStasisPolicy->spawnReturn && id==localStasisPolicy->projectileMessage) {
        uintptr_t actorType=0,object=0,name=0;
        char identifier[9];
        if (recipient && payload && readAt(recipient+0x1a0,&actorType,8) &&
            actorType==base+localStasisPolicy->projectileCollision && readAt(recipient+0x30,&object,8) && object &&
            readAt(object+0x30,&name,8) && name && readAt(name,identifier,sizeof(identifier)) &&
            (!memcmp(identifier,"force___",9) || !memcmp(identifier,"reaver__",9))) {
            localStasisShot.projectile=recipient;
            localStasisShot.generation=generation(recipient);
            localStasisShot.spawned=now;
#ifdef SR1_LOCAL_COMBAT53
            if(localStasisShot.generation){
#ifdef SR1_LOCAL_COMBAT57
 localTkPose57=localStasisShot.owner;localTkPose57.tick=now;
#endif
 localForceShots53[localForceShotCursor53++%32]=localStasisShot;record("defiance-force-spawn projectile=%u",localStasisShot.generation);}
#endif
        }
        return;
    }
#ifdef SR1_LOCAL_COMBAT53
    if(site!=localStasisPolicy->impactPostReturn||id!=localStasisPolicy->impactMessage||!payload)return;
    uintptr_t source53=0;if(!readAt(payload,&source53,8))return;
    const Sr1LocalFrame f53=readLocalFrame(true);LocalTarget target53;
    for(unsigned i=0;i<32;i++){LocalStasisShot *shot=&localForceShots53[i];
        if(shot->projectile!=source53||!shot->generation||generation(source53)!=shot->generation||now<shot->spawned||
           now-shot->spawned>(uint64_t)localStasisPolicy->collisionAgeMs||!sameLocalAction(&shot->owner,&f53,player,now,2000)||
           !f53.renderBlend||!localReadContactTarget(recipient,f53.worldGeneration,&target53))continue;
        localForceReceipts53[localForceReceiptCursor53++%32]=(LocalForceReceipt53){.owner=shot->owner,.target=recipient,.payload=payload,.gen=target53.generation,.tick=now};
#ifdef SR1_LOCAL_COMBAT60
        if(shot->lifted62.target.actor==recipient&&shot->lifted62.target.generation==target53.generation){
            LocalForceThrow62 *thrown=&localForceThrows62[localForceThrowCursor62++%32];
            *thrown=(LocalForceThrow62){.receipt={.owner=shot->owner,.target=recipient,.payload=payload,.gen=target53.generation,.tick=now},.lifted=shot->lifted62};
            memcpy(thrown->direction,shot->direction62,sizeof thrown->direction);
        }
#endif
        shot->generation=0;record("defiance-force-contact target=%u",target53.generation);break;
    }
    return;
#else
    if (site!=localStasisPolicy->impactPostReturn || id!=localStasisPolicy->impactMessage || !payload ||
        !localStasisShot.generation || localStasisShot.spawned>now ||
        now-localStasisShot.spawned>(uint64_t)localStasisPolicy->collisionAgeMs) return;
    uintptr_t source=0;
    if (!readAt(payload,&source,8) || source!=localStasisShot.projectile ||
        generation(source)!=localStasisShot.generation) return;
    const Sr1LocalFrame frame=readLocalFrame(true);
    LocalTarget target;
    if (sameLocalAction(&localStasisShot.owner,&frame,player,now,
            (uint64_t)(localStasisPolicy->collisionAgeMs+localStasisPolicy->castWindowMs)) &&
        frame.renderBlend && localReadContactTarget(recipient,frame.worldGeneration,&target)) {
        localStasisImpact=(LocalContactTicket){.target=target,.owner=localStasisShot.owner,.payload=payload,.tick=now};
        localStasisShot.generation=0;
    }
#endif
}

static void localCastStasis(void) {
    const LocalActionOwner request=localStasisPress;
    if (!request.tick) return;
    localStasisPress=(LocalActionOwner){0};
    const uint64_t now=GetTickCount64();
    const Sr1LocalFrame frame=readLocalFrame(true);
    uintptr_t blade=0,owner=0,handler=0,playerData=0,list=0,tuning=0;
    uint32_t abilities=0;
    uint16_t speed=0;
    if (!sameLocalAction(&request,&frame,player,now,(uint64_t)localStasisPolicy->castWindowMs) ||
        !frame.renderBlend || !localAirStrikeEquipped() ||
        !readAt(base+acquisition->abilitiesRva,&abilities,4) || !(abilities&AIR_FORCE_ABILITY) ||
        !readAt(base+host->reaverRva,&blade,8) || !blade ||
        !readAt(blade+host->parentOffset,&owner,8) || owner!=player ||
        !readAt(blade+0x1b8,&handler,8) || handler!=base+AIR_REAVER_POST ||
        !readAt(base+AIR_PLAYER_DATA_RVA,&playerData,8) || !playerData ||
        !readAt(playerData+0x20,&list,8) || !list || !readAt(list+0x28,&tuning,8) || !tuning ||
        !readAt(tuning+0x18,&speed,2) || !speed) return;
    typedef uintptr_t (*BuildThrow)(uintptr_t,uintptr_t,uint16_t,uint16_t,uint16_t,uint16_t,uint16_t,uint16_t);
    uintptr_t chosen53=0;
#ifdef SR1_LOCAL_COMBAT53
    uint32_t chosenGen53=0;
#ifdef SR1_LOCAL_COMBAT54
    (void)localForceTarget54(&frame,&chosen53,&chosenGen53);
#else
    (void)localNearestTarget49(&frame,player,&chosen53,&chosenGen53);
#endif
#endif
    const uintptr_t payload=((BuildThrow)(base+localStasisPolicy->buildThrowRva))(chosen53,0,chosen53?1:0,0,speed,0,0,0);
    if (!payload) return;
    memset(&localStasisShot,0,sizeof(localStasisShot));
    localStasisShot.owner=request;
#ifdef SR1_LOCAL_COMBAT54
    localStasisShot.selected=chosen53;localStasisShot.selectedGen=chosenGen53;
#ifdef SR1_LOCAL_COMBAT60
    localCaptureForce62(&localStasisShot,&frame,chosen53,chosenGen53,now);
#endif
#endif
    localStasisDispatch=true;
    originalComboPost(blade,(uint32_t)localStasisPolicy->projectileMessage,payload);
    localStasisDispatch=false;
#ifdef SR1_LOCAL_COMBAT53
    if(localStasisShot.generation){localForceCooldown53=(C6ForceCooldown){{frame.session,player,frame.playerGeneration},GetTickCount64()};record("defiance-force-cooldown interval=500 target=%u",chosenGen53);}
#endif
    if (localStasisShot.generation) record("standalone-stasis-projectile generation=%u",localStasisShot.generation);
}

static bool localStockFlight(const LocalTarget *target,uint32_t realm) {
    if (!airMaterialEnemy(realm,target->monsterClass)) return false;
    uintptr_t (*lookup)(uintptr_t,uint32_t)=(void *)(base+AIR_STATE_PAIR_LOOKUP);
    const uintptr_t flight=lookup(target->actor,AIR_FLIGHT_STATE);
    const uintptr_t roll=lookup(target->actor,AIR_SLAM_ROLL_STATE);
    uintptr_t f[2],r[2];
    return flight && roll && readAt(flight,f,sizeof(f)) && readAt(roll,r,sizeof(r)) &&
        ((f[0]==base+0xa7390 && f[1]==base+0xa7260)
#ifdef SR1_LOCAL_COMBAT59
            || localWallFlight59(target->actor,f)
#endif
        ) && r[0]==base+0xa5cb0 && r[1]==base+0xa5b70;
}

#ifdef SR1_LOCAL_COMBAT60
#include "local-air-follow62.h"
#endif
static bool localFlightClear(const LocalContactTicket *ticket,int16_t top,int16_t ceiling) {
    const int radius=ticket->sphere.radius/2;
    const int offsets[5][2]={{0,0},{-radius,0},{radius,0},{0,-radius},{0,radius}};
    for (unsigned i=0;i<ARRAYSIZE(offsets);i++) {
        const int x=ticket->sphere.center[0]+offsets[i][0],y=ticket->sphere.center[1]+offsets[i][1];
        if (x<INT16_MIN || x>INT16_MAX || y<INT16_MIN || y>INT16_MAX) return false;
        const float from[3]={(float)x,(float)y,(float)top};
        const int16_t to[3]={(int16_t)x,(int16_t)y,ceiling};
        if (!localNativeLineClear(ticket->target.actor,ticket->owner.world,from,to)) return false;
    }
    return true;
}

#ifdef SR1_LOCAL_COMBAT50
#include "local-slam-recovery50.h"
#endif
static bool localStartNativeFlight(const LocalContactTicket *ticket,LocalTarget current,bool bounce) {
    int16_t ground,launch,top,ceiling;
    int32_t velocity=AIR_FLIGHT_VELOCITY,gravity=AIR_FLIGHT_GRAVITY;
    if (!readAt(current.actor+0xa0,&ground,2) ||
        !airTakeoffHeights(ground,ticket->sphere.center[2],ticket->sphere.radius,&launch,&top,&ceiling)) return false;
#ifdef SR1_LOCAL_COMBAT56
    const bool reliftAir56=!bounce&&(current.mainState==AIR_FLIGHT_STATE||ticket->target.mainState==AIR_FLIGHT_STATE);
    if(reliftAir56)launch=ground; // In-flight relift changes velocity, never teleports another128 units upward.
#endif
#ifdef SR1_LOCAL_COMBAT48
    if(!bounce){
        const int headroom=(int)ceiling+sheet_sr1Combat48_combat_charge.liftRise;
        if(headroom>INT16_MAX)return false;
        velocity=(int32_t)ceilf(sqrtf((float)velocity*velocity+2.f*(-gravity)*sheet_sr1Combat48_combat_charge.liftRise));
        ceiling=(int16_t)headroom;
    }
#endif
    if (bounce) {
        const int next=(int)top+AIR_SLAM_BOUNCE_CLEARANCE;
        if (next>INT16_MAX || !localFlightClear(ticket,top,(int16_t)next)) return false;
        velocity=AIR_SLAM_BOUNCE_VELOCITY;
        gravity=AIR_SLAM_BOUNCE_GRAVITY;
    } else if (!localFlightClear(ticket,top,ceiling)) {
        int clearance=0,blocked=(int)ceiling-top,offset=0;
        while (blocked-clearance>8) {
            const int mid=clearance+(blocked-clearance)/2;
            if (localFlightClear(ticket,top,(int16_t)(top+mid))) clearance=mid;
            else blocked=mid;
        }
        if (!airReducedLift(clearance,&offset,&velocity)) return false;
        launch=(int16_t)(ground+offset);
#ifdef SR1_LOCAL_COMBAT56
        if(reliftAir56)launch=ground;
#endif
    }
    originalLocalVictimTransition(current.actor,AIR_FLIGHT_STATE);
    LocalTarget after;
    if (!localReadContactTarget(current.actor,ticket->owner.world,&after) || after.state!=current.state ||
        after.generation!=current.generation || after.mainState!=AIR_FLIGHT_STATE) return false;
    const int32_t initial[3]={0,0,velocity},acceleration[3]={0,0,gravity};
    memcpy((void *)(current.actor+0xa0),&launch,sizeof(launch));
    memcpy((void *)(current.actor+0x2cc),initial,sizeof(initial));
    memcpy((void *)(current.actor+0x2d8),acceleration,sizeof(acceleration));
    return true;
}

#ifdef SR1_LOCAL_COMBAT56
#include "local-relift56.h"
#endif
static void localApplyVictimHit(const LocalContactTicket *ticket,const LocalTarget *current,uint64_t now) {
    if (!localStockFlight(current,ticket->owner.realm)) return;
#ifdef SR1_LOCAL_COMBAT56
    LocalLiftChain56*chain56=NULL;
    if(ticket->attack==LOCAL_VICTIM_LIFT_HIT){
        chain56=localLiftChain56(ticket,now);if(chain56->expelled){record("defiance-victim-lift-wait-upright target=%u",current->generation);return;}
        if(ticket->owner.tick<=chain56->sequence)return;
        if(chain56->lifts>=(unsigned)sheet_sr1Combat56_action_facing_relift.liftLimit){
            if(localExpelVictim56(ticket,*current,now)){chain56->lifts++;chain56->sequence=ticket->owner.tick;chain56->expelled=true;chain56->upright=0;}return;
        }
    }
#endif
    const LocalVictimHit sample={.identity=localContactIdentity(ticket),.sequence=ticket->owner.tick,.tick=now,
        .monsterClass=current->monsterClass,.stateBefore=ticket->target.mainState,
        .stateAfter=current->mainState,.nativeApplied=true,.attack=ticket->attack};
    LocalVictimFlight next=localFlight;
    const LocalVictimCommand command=localVictimHit(&next,sample);
#ifdef SR1_LOCAL_COMBAT50
    int16_t victimFloor50=0,playerFloor50=0;
    bool floors50=command==LOCAL_VICTIM_START_FLIGHT&&readAt(current->actor+0xa0,&victimFloor50,2)&&readAt(player+0xa0,&playerFloor50,2);
    if(floors50){const Sr1LocalFrame frame=readFrame();const LocalJumpReceipt jump=readLocalJump();
        if(sameLocalAction(&jump.owner,&frame,player,now,airPolicy->maxFlightMs)&&
           (frame.airState==SR1_AIR_JUMP||frame.airState==SR1_AIR_FALL))playerFloor50=jump.floor;}
#endif
    if (command==LOCAL_VICTIM_UNCHANGED ||
        (command==LOCAL_VICTIM_START_FLIGHT && !localStartNativeFlight(ticket,*current,false))) return;
#ifdef SR1_LOCAL_COMBAT56
    if(command==LOCAL_VICTIM_START_FLIGHT&&chain56){
        chain56->lifts++;chain56->sequence=ticket->owner.tick;chain56->upright=0;
        if(localVictimSame(localFlight.identity,next.identity)&&localFlight.haveFloors50&&ticket->target.mainState==AIR_FLIGHT_STATE){victimFloor50=localFlight.victimFloor50;playerFloor50=localFlight.playerFloor50;floors50=true;}
        record("defiance-victim-relift target=%u count=%u before=%u after=%u",current->generation,chain56->lifts,sample.stateBefore,sample.stateAfter);
    }
#endif
#ifdef SR1_LOCAL_COMBAT51
    if(command==LOCAL_VICTIM_EXTEND_FLIGHT){
        int16_t height=0;next.hopUntil51=0;
        if(readAt(current->actor+0xa0,&height,2)&&height<=INT16_MAX-128-AIR_HIT_HOP_RISE&&
            localFlightClear(ticket,(int16_t)(height+128),(int16_t)(height+128+AIR_HIT_HOP_RISE))){
            next.hopOrigin51=height;next.hopUntil51=now+AIR_HIT_HOP_MS;
        }
    }
#endif
#ifdef SR1_LOCAL_COMBAT50
    if(command==LOCAL_VICTIM_START_FLIGHT){next.haveFloors50=floors50;next.playerFloor50=playerFloor50;next.victimFloor50=victimFloor50;}
    if(command==LOCAL_VICTIM_START_FALL){next.hold=(AirVictimHold){0};next.apexPassed=true;}
#endif
    if (command==LOCAL_VICTIM_START_FLIGHT || command==LOCAL_VICTIM_START_FALL) localVictimGroundedAt=0;
    if (command!=LOCAL_VICTIM_EXTEND_FLIGHT) localStasisLockedUntil=0;
    localFlight=next;
    localFlightTicket=*ticket;
    record("standalone-victim realm=%u target=%u reaction=%u",ticket->owner.realm,current->generation,command);
}

static void localApplyStasis(LocalContactTicket ticket) {
    const uint64_t now=GetTickCount64();
    const Sr1LocalFrame frame=readLocalFrame(true);
    LocalTarget current;
    if (!localTicketCurrent(&ticket,&frame,now,UINT64_MAX,&current) || !localStockFlight(&current,frame.realm)) return;
    if (current.mainState!=AIR_FLIGHT_STATE) {
        if (current.mainState==ticket.target.mainState && current.hp>=ticket.target.hp) return;
        if (current.mainState!=4 && current.mainState!=8 && current.mainState!=9) return;
        ticket.sphere.radius=82;
        if (!readAt(current.actor+contactGeometry->rootOffset,ticket.sphere.center,sizeof(ticket.sphere.center)) ||
            ticket.sphere.center[2]>INT16_MAX-82) return;
        ticket.sphere.center[2]+=82;
        if (!localStartNativeFlight(&ticket,current,false)) return;
    }
    localStasisLockedUntil=now+(uint64_t)localStasisPolicy->holdMs;
    localFlight=(LocalVictimFlight){.identity=localContactIdentity(&ticket),.sequence=ticket.owner.tick,
        .lastHit=now,.launch=now,.hold={.until=localStasisLockedUntil,.hitMarker=ticket.owner.tick}};
    localFlightTicket=ticket;
    localVictimGroundedAt=0;
    record("standalone-stasis-target generation=%u hold=%lld",current.generation,localStasisPolicy->holdMs);
}

#ifdef SR1_LOCAL_FORMS45
static _Thread_local unsigned localDirectReaverDamage45;
static _Thread_local uintptr_t localDirectReaverTarget45;
static _Thread_local uint32_t localDirectReaverGeneration45;
#endif
static void localContactEnemyEvent(uintptr_t target,uintptr_t event) {
#ifdef SR1_LOCAL_FORMS45
    const unsigned priorFormDamage45=localDirectReaverDamage45;localDirectReaverDamage45=0;
    const uintptr_t priorFormTarget45=localDirectReaverTarget45;localDirectReaverTarget45=target;
    const uint32_t priorFormGeneration45=localDirectReaverGeneration45;localDirectReaverGeneration45=generation(target);
#endif
    const DWORD incoming=GetLastError();
    LocalContactTicket *previous=activeLocalTicket;
    const bool priorDamage=localDamageConfirmed;
#ifdef SR1_LOCAL_COMBAT60
    const bool priorReaction61=localReactionConfirmed61;localReactionConfirmed61=false;
    const unsigned priorExpected61=localExpectedDamage61;localExpectedDamage61=0;
#endif
    LocalContactTicket ticket={0};
    uint32_t message=0;
    uintptr_t payload=0;
    LocalContactTicket stasis={0};
    activeLocalTicket=NULL;
    localDamageConfirmed=false;
    if (readAt(event,&message,4) && readAt(event+8,&payload,8) && payload &&
        message==localStasisPolicy->impactMessage && target==localStasisImpact.target.actor &&
        payload==localStasisImpact.payload) {
        const uint64_t now=GetTickCount64();
        if (now>=localStasisImpact.tick && now-localStasisImpact.tick<=(uint64_t)contactPolicy->ticketFreshMs)
            stasis=localStasisImpact;
        localStasisImpact=(LocalContactTicket){0};
    }
    if (message==hit->standardId && payload) {
        const uint64_t now=GetTickCount64();
        for (unsigned i=0;i<ARRAYSIZE(localTickets);i++) {
            LocalContactTicket *slot=&localTickets[i];
            if (slot->payload!=payload || slot->target.actor!=target) continue;
            ticket=*slot;
            *slot=(LocalContactTicket){0};
            const Sr1LocalFrame frame=readLocalFrame(true);
            LocalTarget current;
            C2NativeHit data;
            if (now>=ticket.tick && now-ticket.tick<=(uint64_t)contactPolicy->ticketFreshMs &&
                readAt(payload,&data,sizeof(data)) && data.actor==ticket.owner.actor && data.power==4096 &&
                data.distance==contactPolicy->reactionDistance && data.duration==contactPolicy->reactionDuration &&
                localTicketCurrent(&ticket,&frame,now,UINT64_MAX,&current)) {
                ticket.target=current;
                activeLocalTicket=&ticket;
            }
            break;
        }
    }
    #ifdef SR1_LOCAL_FORMS45
    if(message==hit->standardId&&payload){
        const Sr1LocalFrame frame=readFrame();const uint64_t now=GetTickCount64();
        const LocalGroundX strike=readGroundX(&frame,player,now);
        const bool authored=activeLocalTicket||(frame.groundStrike||strike.owner.tick);
        C2NativeHit data;LocalTarget victim;uint32_t abilities=0,mirror=0;
        const unsigned form=localCurrentForm(frame.realm);
        if(authored&&frame.ready&&frame.renderBlend&&localAirStrikeEquipped()&&
            readAt(payload,&data,sizeof(data))&&data.actor==player&&data.power==4096&&
            localReadContactTarget(target,frame.worldGeneration,&victim)&&
            readAt(base+acquisition->abilitiesRva,&abilities,4)&&readAt(base+acquisition->mirrorRva,&mirror,4))
            localDirectReaverDamage45=localFormsDamage(frame.realm,form,abilities,mirror);
    }
    #endif
    SetLastError(incoming);
#ifdef SR1_LOCAL_COMBAT53
    const LocalForceReceipt53 priorForce53=localForceActive53;localForceActive53=(LocalForceReceipt53){0};
    if(message==localStasisPolicy->impactMessage&&payload){const Sr1LocalFrame forceFrame53=readFrame();const uint64_t forceNow53=GetTickCount64();
        for(unsigned i=0;i<32;i++){LocalForceReceipt53 *receipt=&localForceReceipts53[i];
            if(receipt->target==target&&receipt->payload==payload&&receipt->gen==generation(target)&&forceNow53>=receipt->tick&&forceNow53-receipt->tick<=150&&sameLocalAction(&receipt->owner,&forceFrame53,player,forceNow53,2000)){
                localForceActive53=*receipt;*receipt=(LocalForceReceipt53){0};break;
            }
        }
    }
    SetLastError(incoming);
#endif
#ifdef SR1_LOCAL_COMBAT55
    LocalSpellHealth55 spellBefore55;const bool spellObserved55=localSpellEventBefore55(target,message,&spellBefore55);
#endif
    originalLocalEnemyEvent(target,event);
    const DWORD outgoing=GetLastError();
#ifdef SR1_LOCAL_COMBAT60
    localCommitForce62(target,message,payload,GetTickCount64());
#endif
#ifdef SR1_LOCAL_COMBAT55
    if(spellObserved55)localSpellEventAfter55(message,&spellBefore55);
#endif
#ifdef SR1_LOCAL_COMBAT53
    localForceActive53=priorForce53;
#endif
    if (stasis.target.actor) localApplyStasis(stasis);
    if (activeLocalTicket && (localDamageConfirmed
#ifdef SR1_LOCAL_COMBAT60
        || localReactionConfirmed61
#endif
    )) {
        const uint64_t now=GetTickCount64();
        const Sr1LocalFrame frame=readLocalFrame(true);
        LocalTarget current;
        if (localTicketCurrent(&ticket,&frame,now,UINT64_MAX,&current)) {
            if(localDamageConfirmed){
            record("standalone-hit-confirmed target=%u move=%u hp=%d/%d",current.generation,ticket.attack,ticket.target.hp,current.hp);
#ifdef SR1_LOCAL_COMBAT60
            const LocalSpecial rotor60=localReadSpecial(&frame,player,now);
            if(rotor60.owner.tick&&rotor60.move==LOCAL_SPECIAL_TEMPEST)
                record("defiance-rotor-damage target=%u bank=%u funded=%u normal=%u marker=%llu hp=%d/%d",current.generation,rotor60.bank,rotor60.spins,localExpectedDamage61,(unsigned long long)ticket.owner.tick,ticket.target.hp,current.hp);
#endif
            }
#ifdef SR1_LOCAL_COMBAT60
            else record("standalone-stunned-contact target=%u move=%u damage=0 hp=%d/%d",current.generation,ticket.attack,ticket.target.hp,current.hp);
#endif
#ifdef SR1_LOCAL_LOCK47
            localTargetHit47(ticket.owner,current.actor,current.generation);
#endif
            localApplyVictimHit(&ticket,&current,now);
        }
    }
    activeLocalTicket=previous;
    localDamageConfirmed=priorDamage;
#ifdef SR1_LOCAL_COMBAT60
    localReactionConfirmed61=priorReaction61;localExpectedDamage61=priorExpected61;
#endif
#ifdef SR1_LOCAL_FORMS45
    localDirectReaverDamage45=priorFormDamage45;
    localDirectReaverTarget45=priorFormTarget45;localDirectReaverGeneration45=priorFormGeneration45;
#endif
    SetLastError(outgoing);
}

static int localContactDamage(uintptr_t target,int32_t amount,uint32_t kind) {
#ifdef SR1_LOCAL_FORMS45
    const DWORD incomingDamageError45=GetLastError();
#endif
    const uintptr_t site=(uintptr_t)__builtin_return_address(0)-base;
#ifdef SR1_LOCAL_COMBAT53
    LocalTarget forceBefore53={0};const Sr1LocalFrame forceFrame53=readFrame();
    const bool forceReceipt53=target==localForceActive53.target&&localForceActive53.gen==generation(target)&&
        site==C6_DAMAGE_RETURN&&kind==C6_DAMAGE_KIND&&sameLocalAction(&localForceActive53.owner,&forceFrame53,player,GetTickCount64(),2000)&&
        forceFrame53.renderBlend&&localReadContactTarget(target,forceFrame53.worldGeneration,&forceBefore53)&&forceBefore53.hp>0;
    if(forceReceipt53)amount=C6_FORCE_DAMAGE;
#endif
#ifdef SR1_LOCAL_FORMS45
#ifdef SR1_LOCAL_COMBAT48
    const bool formReceipt48=localDirectReaverDamage45&&target==localDirectReaverTarget45&&generation(target)==localDirectReaverGeneration45&&site==contactPolicy->damageReturn&&kind==contactPolicy->damageKind;
#endif
    if(localDirectReaverDamage45&&target==localDirectReaverTarget45&&generation(target)==localDirectReaverGeneration45&&site==contactPolicy->damageReturn&&kind==contactPolicy->damageKind){
        const int32_t selected=(int32_t)localDirectReaverDamage45;localDirectReaverDamage45=0;
#ifdef SR1_LOCAL_COMBAT60
        localExpectedDamage61=(unsigned)selected;
#endif
        record("reaver-form-damage amount=%d native=%d target=%u",selected,amount,generation(target));amount=selected;
    }
#endif
#ifdef SR1_LOCAL_FORMS45
    SetLastError(incomingDamageError45);
#endif
#ifdef SR1_LOCAL_COMBAT48
    LocalTarget hitBefore48={0};const Sr1LocalFrame hitFrame48=readFrame();
#ifdef SR1_LOCAL_COMBAT51
    const bool fullBefore51=localFullCharge51(&hitFrame48,player,GetTickCount64());
    const unsigned hitForm51=localCurrentForm(hitFrame48.realm);
#endif
    const bool tracked48=formReceipt48&&target==localDirectReaverTarget45&&kind==contactPolicy->damageKind&&
        hitFrame48.ready&&hitFrame48.renderBlend&&localAirStrikeEquipped()&&localReadContactTarget(target,hitFrame48.worldGeneration,&hitBefore48);
    SetLastError(incomingDamageError45);
#endif
    const int result=originalLocalEnemyDamage(target,amount,kind);
#ifdef SR1_LOCAL_COMBAT53
    const DWORD forceError53=GetLastError();LocalTarget forceAfter53;
    if(forceReceipt53&&localReadContactTarget(target,forceFrame53.worldGeneration,&forceAfter53)&&forceAfter53.generation==forceBefore53.generation&&forceAfter53.hp<forceBefore53.hp){
        localImpactTarget52(&forceFrame53,player,GetTickCount64(),target,forceAfter53.generation,localCurrentForm(forceFrame53.realm));
        record("defiance-force-damage target=%u amount=%u hp=%d/%d",forceAfter53.generation,C6_FORCE_DAMAGE,forceBefore53.hp,forceAfter53.hp);
    }
    SetLastError(forceError53);
#endif
#ifdef SR1_LOCAL_COMBAT48
    const DWORD hitError48=GetLastError();LocalTarget hitAfter48;
    const bool currentHit48=tracked48&&localReadContactTarget(target,hitFrame48.worldGeneration,&hitAfter48)&&
        hitAfter48.generation==hitBefore48.generation&&hitAfter48.state==hitBefore48.state;
#ifdef SR1_LOCAL_COMBAT60
    if(currentHit48)localDamageAudit62(&hitFrame48,hitAfter48.generation,localExpectedDamage61,hitBefore48.hp,hitAfter48.hp);
#endif
    if(currentHit48&&localDamageHealth61(hitBefore48.hp,hitAfter48.hp,result)){
#ifdef SR1_LOCAL_COMBAT64
        localAirHitFx64(&hitFrame48,target,hitBefore48.hp);
#endif
#ifdef SR1_LOCAL_COMBAT51
        localFullHitAudio51(&hitFrame48,player,hitForm51,fullBefore51,GetTickCount64());
#endif
        int16_t point[3];if(readAt(target+0x9c,point,6)){if(activeLocalTicket)memcpy(point,activeLocalTicket->sphere.center,6);else point[2]+=128;
#ifdef SR1_LOCAL_COMBAT52
            localImpactTarget52(&hitFrame48,player,GetTickCount64(),target,hitAfter48.generation,localCurrentForm(hitFrame48.realm));
            if(fullBefore51)localFxTarget52(&hitFrame48,player,GetTickCount64(),hitForm51,target,hitAfter48.generation,true);
#else
            localImpactQueue48(&hitFrame48,player,GetTickCount64(),point,localCurrentForm(hitFrame48.realm));
#ifdef SR1_LOCAL_COMBAT51
            if(fullBefore51)localFxQueue51(&hitFrame48,player,GetTickCount64(),localCurrentForm(hitFrame48.realm),point,hitAfter48.generation,false,true,true);
#endif
#endif
        }
        localChargeCredit48(&hitFrame48,player,GetTickCount64(),sheet_sr1Combat48_combat_charge.hitCharge,"hit");
    }
    SetLastError(hitError48);
#endif
    if (activeLocalTicket && activeLocalTicket->target.actor==target && site==contactPolicy->damageReturn &&
        kind==contactPolicy->damageKind) {
        const DWORD error=GetLastError();
        LocalTarget current;
        if (localReadContactTarget(target,activeLocalTicket->owner.world,&current) &&
            current.generation==activeLocalTicket->target.generation && current.state==activeLocalTicket->target.state)
        {
            localDamageConfirmed=localDamageHealth61(activeLocalTicket->target.hp,current.hp,result);
#ifdef SR1_LOCAL_COMBAT60
            localReactionConfirmed61=airVictimDamageConfirmed(activeLocalTicket->target.hp,current.hp,result);
#endif
        }
        SetLastError(error);
    }
    return result;
}

static void localContactTransition(uintptr_t actor,uint32_t state) {
    const uintptr_t site=(uintptr_t)__builtin_return_address(0)-base;
    if (activeLocalTicket && activeLocalTicket->target.actor==actor &&
        activeLocalTicket->attack!=LOCAL_VICTIM_LIFT_HIT &&
        localVictimWindow(localFlight.launch,GetTickCount64()) && localFlight.launch &&
        localVictimSame(localFlight.identity,localContactIdentity(activeLocalTicket)) &&
        airDeferVictimReaction(site,state,localDamageConfirmed
#ifdef SR1_LOCAL_COMBAT60
            ||localReactionConfirmed61
#endif
        )) {
#ifdef SR1_LOCAL_COMBAT60
        if(state==9)localDeferStun62(activeLocalTicket,GetTickCount64());
#endif
        return;
    }
    originalLocalVictimTransition(actor,state);
}

static void localContactMove(uintptr_t actor) {
    const uintptr_t site=(uintptr_t)__builtin_return_address(0)-base;
    const uint64_t now=GetTickCount64();
    if (site!=AIR_VICTIM_MOVE_RETURN || !localFlight.launch || actor!=localFlightTicket.target.actor ||
        !localVictimWindow(localFlight.launch,now)) {
        originalLocalVictimMove(actor);
        return;
    }
    const DWORD before=GetLastError();
    const Sr1LocalFrame frame=readLocalFrame(true);
    LocalTarget current;
    int32_t velocity=0,gravity=0,temporary=0;
    const bool slam=localFlight.slam && now>=localFlight.slam && now-localFlight.slam<=AIR_SLAM_MAX_MS;
    const bool validFlight=localTicketCurrent(&localFlightTicket,&frame,now,UINT64_MAX,&current)&&current.mainState==AIR_FLIGHT_STATE;
#if defined(SR1_LOCAL_COMBAT48) && !defined(SR1_LOCAL_COMBAT51)
    int32_t apexVelocity=0;
    if(validFlight&&!slam&&readAt(actor+0x2d4,&apexVelocity,4)&&localVictimApex48(&localFlight,apexVelocity,now)){
        record("defiance-victim-initial-apex target=%u until=%llu",current.generation,(unsigned long long)localFlight.apexUntil);
    }
#endif
#ifdef SR1_LOCAL_COMBAT51
    // Source0.2 moving apex. No initial zero-velocity lease; collision still owns every step.
    if(validFlight&&!slam&&!localVictimHeld(&localFlight.hold,localFlight.launch,now)&&
       readAt(actor+0x2d4,&velocity,4)&&readAt(actor+0x2e0,&gravity,4)){
        const int32_t tuned=!localFlight.slam&&gravity==AIR_FLIGHT_GRAVITY?airApexGravity(velocity):gravity;
        if(tuned!=gravity){memcpy((void *)(actor+0x2e0),&tuned,4);
            if(!localFlight.apexSeen51){localFlight.apexSeen51=true;record("defiance-victim-moving-apex target=%u velocity=%d gravity=%d",current.generation,velocity,tuned);}}
        SetLastError(before);originalLocalVictimMove(actor);const DWORD after51=GetLastError();
        LocalTarget after;int32_t observed=0;
        if(tuned!=gravity&&localReadContactTarget(actor,localFlightTicket.owner.world,&after)&&
            after.generation==localFlightTicket.target.generation&&after.state==localFlightTicket.target.state&&
            readAt(actor+0x2e0,&observed,4)&&observed==tuned)memcpy((void *)(actor+0x2e0),&gravity,4);
        SetLastError(after51);return;
    }
#endif
    if (!validFlight ||
        !readAt(actor+0x2d4,&velocity,4) || !readAt(actor+0x2e0,&gravity,4) ||
        (!slam && !localVictimHeld(&localFlight.hold,localFlight.launch,now))) {
        SetLastError(before);
        originalLocalVictimMove(actor);
        return;
    }
    if (slam) {
        temporary=frame.verticalVelocity<0?frame.verticalVelocity:-48;
#ifdef SR1_LOCAL_COMBAT50
        const LocalAirSlam descent=localSlamSnapshot();
        const bool same=descent.owner.tick==localFlightTicket.owner.tick&&sameLocalAction(&descent.owner,&frame,player,now,airPolicy->maxFlightMs);
        if(same&&(descent.falling||descent.impact))localFlight.descent50=true;
        temporary=localVictimSlamVelocity50(localFlight.descent50,false,false,0,0,frame.verticalVelocity);
        if(localFlight.descent50&&localFlight.haveFloors50){
            int16_t playerZ=0,victimZ=0;
            if(readAt(player+0xa0,&playerZ,2)&&readAt(actor+0xa0,&victimZ,2)){
                temporary=localVictimSlamVelocity50(true,true,same&&descent.impact,(int)playerZ-localFlight.playerFloor50,
                    (int)victimZ-localFlight.victimFloor50,frame.verticalVelocity);
            }
        }
        if(!localFlight.rollPose50&&localFlight.descent50)localFlight.rollPose50=localRollPose50(&current);
#elif defined(SR1_LOCAL_COMBAT49)
        const LocalAirSlam descent=readLocalSlam(&frame,player,now,0);
        temporary=localVictimDescent49(frame.verticalVelocity,descent.falling!=0);
#endif
        if (temporary < -AIR_SLAM_MAX_SPEED) temporary=-AIR_SLAM_MAX_SPEED;
    }
#ifdef SR1_LOCAL_COMBAT51
    else if(now>=localStasisLockedUntil){int16_t height=0;
        if(readAt(actor+0xa0,&height,2))temporary=airHitHopStep(height,localFlight.hopOrigin51,localFlight.hopUntil51,now);
    }
#endif
    const int32_t zero=0;
    const int32_t zeroPlanar[2]={0,0};
    int32_t planar[2],planarAcceleration[2];
    const bool holdPlanar=!slam && now<localStasisLockedUntil &&
        readAt(actor+0x2cc,planar,sizeof(planar)) && readAt(actor+0x2d8,planarAcceleration,sizeof(planarAcceleration));
    if (holdPlanar) {
        memcpy((void *)(actor+0x2cc),zeroPlanar,sizeof(zeroPlanar));
        memcpy((void *)(actor+0x2d8),zeroPlanar,sizeof(zeroPlanar));
    }
    memcpy((void *)(actor+0x2d4),&temporary,4);
    memcpy((void *)(actor+0x2e0),&zero,4);
    SetLastError(before);
    originalLocalVictimMove(actor);
    const DWORD after=GetLastError();
#ifdef SR1_LOCAL_COMBAT50
    const bool updatedOwner50=localReadContactTarget(actor,localFlightTicket.owner.world,&current)&&
        current.generation==localFlightTicket.target.generation&&current.state==localFlightTicket.target.state;
#else
    const Sr1LocalFrame updated=readLocalFrame(true);
#endif
#ifdef SR1_LOCAL_COMBAT50
    if(updatedOwner50){
#else
    if (localTicketCurrent(&localFlightTicket,&updated,now,UINT64_MAX,&current)
#ifndef SR1_LOCAL_COMBAT50
        && current.mainState==AIR_FLIGHT_STATE
#endif
    ) {
#endif
#ifdef SR1_LOCAL_COMBAT50
        localRestoreVictimGravity50(&localFlightTicket,gravity);
        if(!slam&&current.mainState==AIR_FLIGHT_STATE)memcpy((void *)(actor+0x2d4),&velocity,4);
#else
        if (!slam) memcpy((void *)(actor+0x2d4),&velocity,4);
        memcpy((void *)(actor+0x2e0),&gravity,4);
#endif
        if (holdPlanar) {
            memcpy((void *)(actor+0x2cc),planar,sizeof(planar));
            memcpy((void *)(actor+0x2d8),planarAcceleration,sizeof(planarAcceleration));
        }
    }
    SetLastError(after);
}

static void localObserveVictimLanding(void) {
    if (!localFlight.slam) return;
    const uint64_t now=GetTickCount64();
    const Sr1LocalFrame frame=readLocalFrame(true);
    LocalTarget current;
    uint32_t flags=0;
    int32_t vertical=0;
    if (!localTicketCurrent(&localFlightTicket,&frame,now,UINT64_MAX,&current) || now<localFlight.slam ||
        now-localFlight.slam>AIR_SLAM_MAX_MS) {
        // Keep the consumed native hit sequence for duplicate rejection.
        localFlight.launch=localFlight.slam=0;
        return;
    }
#ifdef SR1_LOCAL_COMBAT51
    static _Thread_local uint64_t diagnosticAt51,diagnosticMarker51;
    if(diagnosticMarker51!=localFlight.slam||now>=diagnosticAt51+150){
        diagnosticAt51=now;diagnosticMarker51=localFlight.slam;int16_t z51=0;int32_t g51=0,v51=0;uint32_t flags51=0;
        readAt(current.actor+0xa0,&z51,2);readAt(current.actor+0x2d4,&v51,4);readAt(current.actor+0x2e0,&g51,4);readAt(current.state,&flags51,4);
        record("defiance-victim-slam-observe target=%u marker=%llu state=%u z=%d velocity=%d gravity=%d flags=%x floor=%d descending=%u",current.generation,(unsigned long long)localFlight.slam,current.mainState,z51,v51,g51,flags51,localFlight.victimFloor50,localFlight.descent50);
    }
#endif
    if (!localVictimGroundedAt && current.mainState==AIR_SLAM_ROLL_STATE &&
        readAt(current.state,&flags,4) && (flags&2u) && readAt(current.actor+0x2d4,&vertical,4) && !vertical)
        localVictimGroundedAt=now;
#ifdef SR1_LOCAL_COMBAT50
    const LocalAirSlam slam=localSlamSnapshot();
    const uint64_t playerContact=slam.owner.tick==localFlightTicket.owner.tick&&sameLocalAction(&slam.owner,&frame,player,now,airPolicy->maxFlightMs)?slam.impact:0;
#else
    const LocalAirSlam slam=readLocalSlam(&frame,player,now,slamRecoveryDuration());
    const uint64_t playerContact=slam.impact;
#endif
    const LocalVictimCommand command=localVictimLand(&localFlight,localContactIdentity(&localFlightTicket),
        localVictimGroundedAt,playerContact,now,localStockFlight(&current,frame.realm));
    if (command==LOCAL_VICTIM_REBOUND) {
#ifdef SR1_LOCAL_COMBAT50
        localCommitSlamGround50(&frame,&localFlightTicket,current,now);
#else
        int16_t point[3];
        if (readAt(current.actor+contactGeometry->rootOffset,point,sizeof(point)) &&
            point[2]<=INT16_MAX-localFlightTicket.sphere.radius) {
            point[2]+=(int16_t)localFlightTicket.sphere.radius;
            memcpy(localFlightTicket.sphere.center,point,sizeof(point));
            if (localStartNativeFlight(&localFlightTicket,current,true))
                record("standalone-victim-rebound target=%u",current.generation);
        }
#endif
    } else if (command==LOCAL_VICTIM_LANDED) {
        record("standalone-victim-landed target=%u",current.generation);
    }
}

static uintptr_t localContactBroad(uintptr_t list) {
    const uintptr_t site=(uintptr_t)__builtin_return_address(0)-base;
    const uintptr_t result=originalLocalBroad(list);
    if (site==contactPolicy->broadReturn) {
        const DWORD error=GetLastError();
#ifdef SR1_LOCAL_COMBAT56
        const Sr1LocalFrame chainFrame56=readFrame();localObserveLiftChains56(&chainFrame56,GetTickCount64());
#endif
        localObserveVictimLanding();
#ifdef SR1_LOCAL_COMBAT60
        localPollStun62();
#endif
#ifdef SR1_LOCAL_COMBAT50
        const Sr1LocalFrame frame50=readLocalFrame(true);localObserveRoll50(&frame50,GetTickCount64());
#endif
        localCastStasis();
#ifdef SR1_LOCAL_COMBAT54
        localForcePoll54();
#endif
        localTryAirContact();
        SetLastError(error);
    }
    return result;
}

static bool prepareLocalAirContact(void) {
#ifdef SR1_LOCAL_COMBAT59
    if(!prepareLocalNative59())return false;
#endif
    return MH_CreateHook((void *)(base+contactPolicy->broadRva),localContactBroad,(void **)&originalLocalBroad)==MH_OK &&
        MH_CreateHook((void *)(base+contactPolicy->transformRva),localContactTransform,(void **)&originalLocalTransform)==MH_OK &&
        MH_CreateHook((void *)(base+contactPolicy->enemyEventRva),localContactEnemyEvent,(void **)&originalLocalEnemyEvent)==MH_OK &&
        MH_CreateHook((void *)(base+contactPolicy->damageRva),localContactDamage,(void **)&originalLocalEnemyDamage)==MH_OK &&
        MH_CreateHook((void *)(base+AIR_VICTIM_TRANSITION),localContactTransition,(void **)&originalLocalVictimTransition)==MH_OK &&
        MH_CreateHook((void *)(base+AIR_VICTIM_MOVE),localContactMove,(void **)&originalLocalVictimMove)==MH_OK;
}
