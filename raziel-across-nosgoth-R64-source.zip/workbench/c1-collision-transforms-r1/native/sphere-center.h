// SPDX-License-Identifier: GPL-3.0-or-later
#pragma once
#include <stdbool.h>
#include <stdint.h>
#include <string.h>
#include "exploration-sheets.h"

// Decode an owned copy of one SR1 collision matrix and its local sphere.
// The engine uses signed 16-bit centers. Refuse out-of-range coordinates
// instead of interpreting a wrapped center as a valid measurement.
static bool sr1CollisionSphereCenter(const unsigned char *matrix, const unsigned char *sphere,
                                     int16_t center[3], uint16_t *radius) {
    const Sheet_c1CollisionGeometry *layout = &sheet_c1CollisionGeometry_host_sword_sphere;
    int16_t local[3], rotation[3][3], result[3];
    int32_t translation[3];
    uint16_t localRadius;
    memcpy(local, sphere + layout->localCenterOffset, sizeof(local));
    memcpy(&localRadius, sphere + layout->radiusOffset, sizeof(localRadius));
    memcpy(rotation, matrix, sizeof(rotation));
    memcpy(translation, matrix + layout->translationOffset, sizeof(translation));
    const int64_t divisor = INT64_C(1) << layout->rotationFractionBits;

    for (unsigned axis = 0; axis < 3; ++axis) {
        int64_t dot = 0;
        for (unsigned component = 0; component < 3; ++component)
            dot += (int64_t)rotation[axis][component] * local[component];
        if (dot < INT32_MIN || dot > INT32_MAX) return false;
        // Floor division matches SAR for both positive and negative coordinates.
        const int64_t scaled = dot / divisor - (dot % divisor < 0);
        const int64_t world = scaled + translation[axis];
        if (world < INT16_MIN || world > INT16_MAX) return false;
        result[axis] = (int16_t)world;
    }
    memcpy(center, result, sizeof(result));
    *radius = localRadius;
    return true;
}
