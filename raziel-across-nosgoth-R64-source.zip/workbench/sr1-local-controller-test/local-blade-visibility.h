// SPDX-License-Identifier: GPL-3.0-or-later
#pragma once

#include "reaver-function-bytes.h"
#include "ribbon-code-proof.h"

static void (*originalBladeVisual)(uintptr_t);
static void (*originalBladeRibbon)(uintptr_t, uintptr_t);
static uintptr_t (*originalRibbonPrimitive)(uintptr_t);
static _Thread_local uintptr_t bladeRibbonTracker;

static bool localBladeMatches(uintptr_t candidate) {
    uintptr_t actor, owner, blade, object, name, extra;
    char label[8];
    return candidate &&
        readAt(base + host->actorRva, &actor, sizeof(actor)) && actor && actor != candidate &&
        readAt(base + host->stateActorRva, &owner, sizeof(owner)) && owner == actor &&
        readAt(base + host->reaverRva, &blade, sizeof(blade)) && blade == candidate &&
        readAt(blade + 0x30, &object, sizeof(object)) && object &&
        readAt(blade + 0x2c0, &extra, sizeof(extra)) && extra &&
        readAt(object + 0x30, &name, sizeof(name)) && readAt(name, label, sizeof(label)) &&
        memcmp(label, "sreavr__", sizeof(label)) == 0;
}

static void localBladeVisual(uintptr_t opaque) {
    uintptr_t candidate;
    if (readAt(base + strikePresentation->bladeRenderInstanceRva, &candidate, sizeof(candidate)) &&
        localBladeMatches(candidate)) {
        static volatile LONG hidden;
        if (InterlockedIncrement(&hidden) == 1) record("native-reaver-blade hidden");
        return;
    }
    originalBladeVisual(opaque);
}

static void localBladeRibbon(uintptr_t node, uintptr_t tracker) {
    uintptr_t callback, owner, vertices;
    int16_t count, start, end;
    uint16_t type;
    const bool owned = tracker &&
        readAt(node + 8, &callback, sizeof(callback)) && callback == base + (uintptr_t)strikePresentation->ribbonContinuationRva &&
        readAt(node + 16, &owner, sizeof(owner)) && localBladeMatches(owner) &&
        readAt(node + 24, &type, sizeof(type)) && type == 0 &&
        readAt(node + 0x28, &count, sizeof(count)) && count == 4 &&
        readAt(node + 0x30, &vertices, sizeof(vertices)) && vertices >= 65536 &&
        readAt(node + 0x38, &start, sizeof(start)) && start == 0 &&
        readAt(node + 0x3a, &end, sizeof(end)) && end == 1;
    const uintptr_t previous = bladeRibbonTracker;
    bladeRibbonTracker = owned ? tracker : 0;
    originalBladeRibbon(node, tracker);
    bladeRibbonTracker = previous;
}

static uintptr_t localRibbonPrimitive(uintptr_t tracker) {
    const uintptr_t caller = (uintptr_t)__builtin_return_address(0);
    if (tracker && tracker == bladeRibbonTracker && (caller == base + 0x52775 || caller == base + 0x52854)) {
        static volatile LONG hidden;
        if (InterlockedIncrement(&hidden) == 1) record("native-reaver-ribbon hidden");
        return 0;
    }
    return originalRibbonPrimitive(tracker);
}

static bool prepareLocalBladeVisibility(void) {
    if (!matches(strikePresentation->bladeRenderRva, reaverExpected, sizeof(reaverExpected))) return false;
    for (unsigned i = 0; i < ARRAYSIZE(ribbonCodeProofs); ++i) {
        const uintptr_t expected = i ? strikePresentation->ribbonAllocatorRva : strikePresentation->ribbonContinuationRva;
        if (ribbonCodeProofs[i].rva != expected ||
            !verifyDrawBlock(expected, ribbonCodeProofs[i].size, ribbonCodeProofs[i].sha256)) return false;
    }
    const uintptr_t rvas[] = {strikePresentation->bladeRenderRva, strikePresentation->ribbonContinuationRva,
        strikePresentation->ribbonAllocatorRva};
    void *const hooks[] = {(void *)localBladeVisual, (void *)localBladeRibbon, (void *)localRibbonPrimitive};
    void **const originals[] = {(void **)&originalBladeVisual, (void **)&originalBladeRibbon,
        (void **)&originalRibbonPrimitive};
    for (unsigned i = 0; i < ARRAYSIZE(rvas); ++i) {
        if (MH_CreateHook((void *)(base + rvas[i]), hooks[i], originals[i]) == MH_OK) continue;
        for (unsigned j = 0; j < i; ++j) MH_RemoveHook((void *)(base + rvas[j]));
        return false;
    }
    return true;
}
