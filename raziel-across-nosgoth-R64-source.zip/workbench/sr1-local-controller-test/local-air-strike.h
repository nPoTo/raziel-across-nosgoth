// SPDX-License-Identifier: GPL-3.0-or-later
#pragma once

#include "local-air-strike-motion.h"

typedef struct {
    LocalActionOwner owner;
    uint64_t flight, priorAge;
    unsigned ordinal;
#ifdef SR1_LOCAL_COMBAT_FACING
    bool stationary;
#endif
#ifdef SR1_LOCAL_COMBAT_TEMPO
    unsigned queued;
#ifdef SR1_LOCAL_AIR_COMBO_RESERVE
    bool reserveFinal;
#endif
#else
    bool queued;
#endif
} LocalAirStrike;

static const Sheet_sr1LocalAirStrikeMotion *const airStrikeMotion = &sheet_sr1LocalAirStrikeMotion_air_strike_momentum;
static SRWLOCK localAirStrikeLock = SRWLOCK_INIT;
static LocalAirStrike localAirStrike;

static uint64_t localAirStrikeDuration(unsigned ordinal) {
    const uint64_t length = (sheet_sr1LocalAirStrikeClip_rows[ordinal]->clipKeys * 1000u + 29u) / 30u;
#ifdef SR1_LOCAL_COMBAT_TEMPO
    return localAirComboDuration(length);
#else
    return length;
#endif
}

static LocalAirStrike localAirStrikeSnapshot(void) {
    LocalAirStrike strike = {0};
    if (TryAcquireSRWLockShared(&localAirStrikeLock)) {
        strike = localAirStrike;
        ReleaseSRWLockShared(&localAirStrikeLock);
    }
    return strike;
}

static LocalAirStrike readLocalAirStrike(const Sr1LocalFrame *frame, uintptr_t actor, uint64_t now) {
    const LocalAirStrike strike = localAirStrikeSnapshot();
    if (!localSlamAirborne(frame) ||
        !sameLocalAction(&strike.owner, frame, actor, now, localAirStrikeDuration(strike.ordinal)) ||
        readLocalJump().owner.tick != strike.flight) return (LocalAirStrike){0};
    return strike;
}

static bool localAirStrikeEquipped(void) {
    uint32_t abilities, mirror, kind;
    uintptr_t blade;
    return readAt(base + acquisition->abilitiesRva, &abilities, sizeof(abilities)) &&
        readAt(base + acquisition->mirrorRva, &mirror, sizeof(mirror)) && abilities == mirror &&
        (abilities & combatPolicy->reaverAbility) &&
        readAt(base + host->interactionTypeRva, &kind, sizeof(kind)) && kind == 0x1000 &&
        readAt(base + host->reaverRva, &blade, sizeof(blade)) && blade;
}

static void localAirStrikeOnPad(NativePad *pad, uint32_t attack, const Sr1LocalFrame *frame, uintptr_t actor,
    uint64_t now, uint64_t recoveryMs) {
    const LocalJumpReceipt jump = readLocalJump();
    const bool eligible = InterlockedCompareExchange(&localAirSlamReady, 0, 0) && localSlamAirborne(frame) &&
        sameLocalAction(&jump.owner, frame, actor, now, airPolicy->maxFlightMs) &&
        !readLocalSlam(frame, actor, now, recoveryMs).owner.tick;
    const bool edge = (pad->pressed & attack) != 0;
    const bool equipped = eligible && localAirStrikeEquipped();
    bool started = false;
    unsigned ordinal = 0;
    AcquireSRWLockExclusive(&localAirStrikeLock);
    LocalAirStrike *strike = &localAirStrike;
    if (!equipped || strike->flight != jump.owner.tick ||
        !sameLocalAction(&strike->owner, frame, actor, now, localAirStrikeDuration(strike->ordinal))) {
        *strike = (LocalAirStrike){0};
    }
#ifdef SR1_LOCAL_COMBAT_FACING
    const bool directional=combatDirectionHeld(pad->x,pad->y,(int32_t)motion->moveThreshold);
    if (directional) strike->stationary=false;
#endif
    if (equipped && (edge || strike->queued)) {
        if (!strike->owner.tick) {
            strike->flight = jump.owner.tick;
#ifdef SR1_LOCAL_COMBAT_FACING
            strike->stationary=!directional && jump.forward==airPolicy->standingForward;
#endif
            started = true;
        } else if (strike->ordinal + 1 < sheet_sr1LocalAirStrikeClip_count) {
            const uint64_t age = now - strike->owner.tick;
#ifdef SR1_LOCAL_COMBAT_TEMPO
            const unsigned remaining = (unsigned)sheet_sr1LocalAirStrikeClip_count - 1 - strike->ordinal;
            if (edge && strike->queued < remaining) {
                ++strike->queued;
#ifdef SR1_LOCAL_AIR_COMBO_RESERVE
                if (localAirCanReserveFinal(strike->ordinal, age)) strike->reserveFinal = true;
#endif
            }
            if (strike->queued && localAirComboCanAdvance(strike->ordinal, age)) {
                --strike->queued;
#ifdef SR1_LOCAL_AIR_COMBO_RESERVE
                if (strike->ordinal == 0) strike->reserveFinal = strike->queued > 0;
#endif
#else
            const uint64_t chainMs = sheet_sr1LocalAirStrikeClip_rows[strike->ordinal]->chainKey * 1000u / 30u;
            strike->queued = age < chainMs;
            if (!strike->queued) {
#endif
                strike->priorAge = age;
                ++strike->ordinal;
                started = true;
            }
        }
        if (started) {
            strike->owner = localActionOwner(frame, actor, now);
            ordinal = strike->ordinal;
        }
        pad->pressed &= ~attack;
    }
    ReleaseSRWLockExclusive(&localAirStrikeLock);
    if (started) record("defiance-air-x realm=%u ordinal=%u", frame->realm, ordinal);
}

static bool applyLocalAirStrikePhysics(uintptr_t actor, int32_t segment, int32_t time, int32_t clamp,
    uint64_t now, DWORD previousError) {
    static _Thread_local uint64_t reportedSlowdown, reportedResume;
    const LocalAirStrike strike = localAirStrikeSnapshot();
    if (strike.owner.actor != actor || !strike.owner.tick || strike.owner.tick > now) return false;
#ifdef SR1_LOCAL_AIR_STRIKE_HOLD
#ifdef SR1_LOCAL_AIR_COMBO_RESERVE
    const unsigned speed = localAirReservedChainSpeed(strike.ordinal, now - strike.owner.tick, strike.priorAge,
        strike.reserveFinal);
#else
    const unsigned speed = localAirStrikeChainSpeed(strike.ordinal, now - strike.owner.tick, strike.priorAge);
#endif
#else
    const unsigned speed = localAirStrikeSpeed(airStrikeMotion, now - strike.owner.tick);
#endif
    const bool reportResume = speed == 1000 && reportedSlowdown == strike.owner.tick &&
        reportedResume != strike.owner.tick;
#ifdef SR1_LOCAL_COMBAT_FACING
    const bool stationary=strike.stationary;
#else
    const bool stationary=false;
#endif
    if (speed == 1000 && !reportResume && !stationary) return false;
    const Sr1LocalFrame frame = readFrame();
    if (!localSlamAirborne(&frame) || actor != player ||
        !sameLocalAction(&strike.owner, &frame, actor, now, localAirStrikeDuration(strike.ordinal)) ||
        readLocalJump().owner.tick != strike.flight) return false;
    if (reportResume) {
        reportedResume = strike.owner.tick;
        record("defiance-air-x-resume realm=%u ordinal=%u", frame.realm, strike.ordinal);
        if (!stationary) return false;
    }
#ifdef SR1_LOCAL_AIR_STRIKE_HOLD
    static _Thread_local uint64_t reportedHold;
#ifdef SR1_LOCAL_COMBAT_RHYTHM
    const LocalAirStrikeStep step = localAirStrikeAxisStep(time, speed);
    const int32_t stepTime = step.planarTime;
    const int32_t verticalTime = step.verticalTime;
    const uintptr_t kinematics = actor + (uintptr_t)slamPolicy->kinematicsOffset;
    const uintptr_t verticalVelocity = kinematics + offsetof(LocalSlamKinematics, velocity) + 2 * sizeof(int32_t);
    const uintptr_t verticalAcceleration = kinematics + offsetof(LocalSlamKinematics, acceleration) + 2 * sizeof(int32_t);
    int32_t velocity, acceleration, limit;
    if (!readAt(verticalVelocity, &velocity, sizeof(velocity)) ||
        !readAt(verticalAcceleration, &acceleration, sizeof(acceleration)) ||
        !readAt(kinematics + sizeof(LocalSlamKinematics) + 2 * sizeof(int32_t), &limit, sizeof(limit)) ||
        limit < 0) return false;
    const int32_t limitedVelocity = localAirStrikeStepVelocity(velocity, step);
    const int32_t limitedAcceleration = localAirStrikeStepAcceleration(acceleration, step);
#ifdef SR1_LOCAL_COMBAT_FACING
    int32_t planarVelocity[2],planarAcceleration[2];
    const uintptr_t velocityXY=kinematics+offsetof(LocalSlamKinematics,velocity);
    const uintptr_t accelerationXY=kinematics+offsetof(LocalSlamKinematics,acceleration);
    if (stationary && (!readAt(velocityXY,planarVelocity,sizeof(planarVelocity)) ||
        !readAt(accelerationXY,planarAcceleration,sizeof(planarAcceleration)))) return false;
#endif
#else
    const int32_t stepTime = (int32_t)((int64_t)time * speed / 1000);
    const int32_t verticalTime = stepTime;
#endif
    int16_t before[3];
    const bool observeHold = !verticalTime && reportedHold != strike.owner.tick &&
        readAt(actor + 0x9c, before, sizeof(before));
    if (reportedSlowdown != strike.owner.tick) {
        reportedSlowdown = strike.owner.tick;
        record("defiance-air-x-slowdown realm=%u ordinal=%u permille=%u", frame.realm, strike.ordinal, speed);
    }
#ifdef SR1_LOCAL_COMBAT_RHYTHM
    // Preserve the original collision path and advance only the vertical clock during suspension.
    memcpy((void *)verticalVelocity, &limitedVelocity, sizeof(limitedVelocity));
    memcpy((void *)verticalAcceleration, &limitedAcceleration, sizeof(limitedAcceleration));
#ifdef SR1_LOCAL_COMBAT_FACING
    if (stationary) {
        const int32_t stopped[2]={0};
        memcpy((void *)velocityXY,stopped,sizeof(stopped));
        memcpy((void *)accelerationXY,stopped,sizeof(stopped));
    }
#endif
#endif
    SetLastError(previousError);
    originalSlamPhysics(actor, segment, stepTime, clamp);
    const DWORD nativeError = GetLastError();
#ifdef SR1_LOCAL_COMBAT_RHYTHM
    const int32_t continuation = verticalTime ?
        localAirStrikeNativeVelocity(velocity, acceleration, verticalTime, limit) : velocity;
    memcpy((void *)verticalVelocity, &continuation, sizeof(continuation));
    memcpy((void *)verticalAcceleration, &acceleration, sizeof(acceleration));
#ifdef SR1_LOCAL_COMBAT_FACING
    if (stationary) {
        memcpy((void *)velocityXY,planarVelocity,sizeof(planarVelocity));
        memcpy((void *)accelerationXY,planarAcceleration,sizeof(planarAcceleration));
    }
#endif
#endif
    if (observeHold) {
        int16_t after[3];
        if (readAt(actor + 0x9c, after, sizeof(after))) {
            reportedHold = strike.owner.tick;
            record("defiance-air-x-hold realm=%u ordinal=%u step=%ld->%ld vertical=0 delta=%d,%d,%d",
                frame.realm, strike.ordinal, (long)time, (long)stepTime, (int)after[0] - before[0], (int)after[1] - before[1],
                (int)after[2] - before[2]);
        }
    }
    SetLastError(nativeError);
#else
    const uintptr_t velocities = actor + (uintptr_t)slamPolicy->kinematicsOffset;
    LocalSlamKinematics native;
    int32_t limits[2];
    if (!readAt(velocities, &native, sizeof(native)) ||
        !readAt(velocities + sizeof(native), limits, sizeof(limits)) ||
        limits[0] < 0 || limits[1] < 0) return false;
    LocalSlamKinematics limited = native;
    int32_t continuation[2];
    for (unsigned axis = 0; axis < 2; ++axis) {
        limited.velocity[axis] = (int32_t)((int64_t)native.velocity[axis] * speed / 1000);
        limited.acceleration[axis] = (int32_t)((int64_t)native.acceleration[axis] * speed / 1000);
        continuation[axis] = localAirStrikeNativeVelocity(native.velocity[axis], native.acceleration[axis], time, limits[axis]);
    }
    if ((native.velocity[0] || native.velocity[1]) && reportedSlowdown != strike.owner.tick) {
        reportedSlowdown = strike.owner.tick;
        record("defiance-air-x-slowdown realm=%u ordinal=%u permille=%u planar=%ld,%ld", frame.realm,
            strike.ordinal, speed, (long)native.velocity[0], (long)native.velocity[1]);
    }
    memcpy((void *)velocities, &limited, sizeof(limited));
    SetLastError(previousError);
    originalSlamPhysics(actor, segment, time, clamp);
    const DWORD nativeError = GetLastError();
    memcpy((void *)velocities, continuation, sizeof(continuation));
    memcpy((void *)(velocities + sizeof(native.velocity)), native.acceleration, sizeof(native.acceleration));
    SetLastError(nativeError);
#endif
    return true;
}
