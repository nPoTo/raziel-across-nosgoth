// SPDX-License-Identifier: GPL-3.0-or-later
#pragma once

#ifndef SR1_LOCAL_IMMEDIATE_REPEAT
#include "instant-root-proof.h"
#endif
#ifdef SR1_DEFIANCE_GROUND_STEERING
#include "direction-snapshot-r8-proof.h"
static const Sheet_sr1GroundSteering *const steeringPolicy = &sheet_sr1GroundSteering_camera_relative_start;
#endif

typedef uintptr_t (*LocalGroundStateFn)(uintptr_t, int32_t, uintptr_t);
typedef uintptr_t (*LocalGroundSwitchFn)(uintptr_t, uintptr_t, uintptr_t);
static LocalGroundStateFn originalGroundState[2];
static _Thread_local bool groundSwitching;
static _Thread_local uint64_t handledGroundStart;
#ifdef SR1_DEFIANCE_GROUND_STEERING
static _Thread_local uint64_t steeredGroundStart;

static bool writeLocalHalfword(uintptr_t at, uint16_t value) {
    SIZE_T count = 0;
    return WriteProcessMemory(GetCurrentProcess(), (void *)at, &value, sizeof(value), &count) && count == sizeof(value);
}

static void steerGroundBeforeOriginal(uintptr_t state, uint64_t request, uint64_t now) {
    if (groundSwitching || !request || request == steeredGroundStart || request > now ||
        now - request > (uint64_t)groundPolicy->maxGapMs ||
        !InterlockedCompareExchange(&calibratedDrawReady, 0, 0)) return;
    const Sr1LocalFrame frame = readFrame();
    const Sheet_sr1GroundSteering *p = steeringPolicy;
    uintptr_t actor, callback, inputPointer;
    NativePad input;
    uint16_t desired, camera, actual, previousError;
    uint32_t local;
    if (!frame.ready || frame.nativeControl || frame.realm == SR1_LOCAL_UNKNOWN ||
        !readAt(state, &actor, sizeof(actor)) || actor != player ||
        !readAt(state + 0x10, &callback, sizeof(callback)) ||
        (callback != base + (uintptr_t)responsePolicy->idleRva &&
         callback != base + (uintptr_t)responsePolicy->startMoveRva) ||
        !readAt(base + p->inputPointerRva, &inputPointer, sizeof(inputPointer)) ||
        !readAt(inputPointer, &input, sizeof(input)) ||
        !(input.held & 0x8000000fu) || (input.held & ~0x8000000fu) ||
        !readAt(base + p->desiredRva, &desired, sizeof(desired)) ||
        !readAt(base + p->localRva, &local, sizeof(local)) || local > 4095 ||
        !readAt(base + p->cameraRva, &camera, sizeof(camera)) ||
        ((local + camera) & 4095u) != (desired & 4095u) ||
        !readAt(actor + p->yawOffset, &actual, sizeof(actual)) ||
        !readAt(base + p->errorRva, &previousError, sizeof(previousError))) return;
    for (unsigned i = 0; i < 3; ++i) {
        uintptr_t current;
        if (!readAt(base + host->callbackRva + i * host->sectionStride, &current, sizeof(current)) ||
            current == base + (uintptr_t)groundPolicy->startTurnRva) return;
    }
    const unsigned delta = (desired - actual) & 4095u;
    const unsigned turn = delta > 2048u ? 4096u - delta : delta;
    if (turn < (unsigned)p->angularThreshold) return;
    const uintptr_t yawAt = actor + p->yawOffset;
    if (!writeLocalHalfword(yawAt, desired & 4095u)) return;
    if (!writeLocalHalfword(base + p->errorRva, 0)) {
        writeLocalHalfword(yawAt, actual);
        return;
    }
    steeredGroundStart = request;
#ifdef SR1_LOCAL_DEFIANCE_JUMP
    publishLocalTurn(&frame, actor, now, desired & 4095u, localSignedTurn(actual, desired));
#endif
    record("ground-quick-turn realm=%u units=%u angle=%.1f age=%llu error=%d", frame.realm, turn,
        (double)turn * 360.0 / 4096.0, (unsigned long long)(now - request), (int)(int16_t)previousError);
}
#endif

static uintptr_t localGroundStart(unsigned kind, uintptr_t state, int32_t section, uintptr_t data) {
#ifdef SR1_DEFIANCE_GROUND_STEERING
    if (!section) {
        const DWORD savedError = GetLastError();
        const uint64_t beforeRequest = (uint64_t)InterlockedCompareExchange64(&groundStartRequested, 0, 0);
        steerGroundBeforeOriginal(state, beforeRequest, GetTickCount64());
        SetLastError(savedError);
    }
#endif
    const uintptr_t result = originalGroundState[kind](state, section, data);
    const uint64_t request = (uint64_t)InterlockedCompareExchange64(&groundStartRequested, 0, 0);
    const uint64_t now = GetTickCount64();
    if (groundSwitching || section || !request || request == handledGroundStart || request > now ||
        now - request > (uint64_t)groundPolicy->maxGapMs ||
        !InterlockedCompareExchange(&calibratedDrawReady, 0, 0)) return result;

    uintptr_t actor, process;
    const Sr1LocalFrame frame = readFrame();
    if (!frame.ready || frame.nativeControl || frame.realm == SR1_LOCAL_UNKNOWN ||
        !readAt(state, &actor, sizeof(actor)) || actor != player ||
        !readAt(state + 0x10, &process, sizeof(process)) ||
        (process != base + (uintptr_t)responsePolicy->idleRva &&
         process != base + (uintptr_t)responsePolicy->startMoveRva)) return result;
    for (unsigned i = 0; i < 3; ++i) {
        uintptr_t callback;
        if (!readAt(base + host->callbackRva + i * host->sectionStride, &callback, sizeof(callback)) ||
            callback == base + (uintptr_t)groundPolicy->startTurnRva) return result;
    }

    handledGroundStart = request;
    groundSwitching = true;
    const LocalGroundSwitchFn change = (LocalGroundSwitchFn)(base + responsePolicy->switchRva);
    change(state, base + responsePolicy->moveRva, 0);
    groundSwitching = false;
    const bool switched = readAt(state + 0x10, &process, sizeof(process)) &&
        process == base + (uintptr_t)responsePolicy->moveRva;
    record("ground-start realm=%u applied=%u request-age=%llu", frame.realm, (unsigned)switched,
        (unsigned long long)(now - request));
    return result;
}

static uintptr_t localGroundIdle(uintptr_t state, int32_t section, uintptr_t data) {
    return localGroundStart(0, state, section, data);
}

static uintptr_t localGroundInitialMove(uintptr_t state, int32_t section, uintptr_t data) {
    return localGroundStart(1, state, section, data);
}

static bool prepareLocalGroundStart(void) {
#ifdef SR1_DEFIANCE_GROUND_STEERING
    if (!verifyDrawBlock(SR_DIRECTION_PRODUCER_RVA, SR_DIRECTION_PRODUCER_SIZE, SR_DIRECTION_PRODUCER_SHA)) return false;
    for (unsigned i = 0; i < ARRAYSIZE(srDirectionProofs); ++i) {
        unsigned char observed[32];
        const size_t size = srDirectionProofs[i].size;
        if (size > sizeof(observed) || !readAt(base + srDirectionProofs[i].rva, observed, size) ||
            memcmp(observed, srDirectionProofs[i].bytes, size)) return false;
    }
#endif
    const uintptr_t rvas[] = {responsePolicy->idleRva, responsePolicy->startMoveRva};
    const uintptr_t proofRvas[] = {rvas[0], rvas[1], responsePolicy->moveRva, responsePolicy->switchRva};
    for (unsigned i = 0; i < ARRAYSIZE(proofRvas); ++i) {
        bool verified = false;
        for (unsigned j = 0; j < ARRAYSIZE(instantRootProofs); ++j) {
            if (instantRootProofs[j].rva != proofRvas[i]) continue;
            verified = verifyDrawBlock(proofRvas[i], instantRootProofs[j].size, instantRootProofs[j].sha256);
            break;
        }
        if (!verified) return false;
    }
    void *const hooks[] = {(void *)localGroundIdle, (void *)localGroundInitialMove};
    for (unsigned i = 0; i < ARRAYSIZE(hooks); ++i) {
        if (MH_CreateHook((void *)(base + rvas[i]), hooks[i], (void **)&originalGroundState[i]) != MH_OK) {
            for (unsigned j = 0; j < i; ++j) MH_RemoveHook((void *)(base + rvas[j]));
            return false;
        }
    }
    return true;
}
