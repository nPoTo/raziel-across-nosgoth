// SPDX-License-Identifier: GPL-3.0-or-later
// Adapted from released0.2 pure meter/hold policies, source hashes fb30a00a437e7e8d7450d6b79416d9624b51101b2562b38b5806f7134d8ee536 / c56843d6be21e6bffb3892d0e660c55924b50050a74fa2cee91e13871b81c354
#pragma once
#define C5_METER_MAX 100u
#define C5_GLYPH_FRESH_MS 150u
#define DESKTOP_C5_HOLD_MS 1000u
typedef struct { uint64_t epoch; uintptr_t actor; uint32_t generation; } C5ChargeOwner;
typedef struct { C5ChargeOwner owner; uint32_t glyphs; unsigned charge; } C5Meter;

static inline bool c5SameOwner(C5ChargeOwner a,C5ChargeOwner b) {
    return a.epoch==b.epoch && a.actor==b.actor && a.generation==b.generation;
}

static inline void c5SyncMeter(C5Meter *meter,C5ChargeOwner owner,uint32_t abilities) {
    const uint32_t glyphs=abilities&(uint32_t)sheet_sr1Form45_rows[8]->required;
    if (!c5SameOwner(meter->owner,owner) || (meter->glyphs&~glyphs)) meter->charge=0;
    meter->owner=owner;
    meter->glyphs=glyphs;
}

static inline unsigned c5AddCharge(C5Meter *meter,unsigned gain) {
    const unsigned before=meter->charge;
    meter->charge=gain<C5_METER_MAX-before ? before+gain : C5_METER_MAX;
    return before;
}

// SPDX-License-Identifier: GPL-3.0-or-later
#pragma once





typedef enum { C5_X_NATIVE, C5_X_HELD, C5_X_TAP, C5_X_CAST } C5XRoute;
typedef struct { uint64_t start,last; bool down,owned,draining; } C5XHold;

static inline C5XRoute c5HoldX(C5XHold *hold,uint64_t now,bool down,bool eligible) {
    const bool began=down&&!hold->down;
    const bool continuous=hold->last && now>=hold->last && now-hold->last<=C5_GLYPH_FRESH_MS;
    hold->down=down;
    hold->last=now;
    if (hold->draining) {
        hold->draining=down;
        return C5_X_HELD;
    }
    if (hold->owned) {
        if (!eligible||!continuous) {
            hold->owned=false;
            hold->draining=down;
            return C5_X_HELD;
        }
        if (now-hold->start>=DESKTOP_C5_HOLD_MS) {
            hold->owned=false;
            hold->draining=down;
            return C5_X_CAST;
        }
        if (down) return C5_X_HELD;
        hold->owned=false;
        return C5_X_TAP;
    }
    if (!began||!eligible) return C5_X_NATIVE;
    hold->start=now;
    hold->owned=true;
    return C5_X_HELD;
}

static inline unsigned c5GlyphFromForm(uint32_t form) {
    switch(form) {
        case 3: return 1;
        case 8: return 2;
        case 5: return 3;
        case 7: return 4;
        case 6: return 5;
        case 4: return 6;
        default: return 0;
    }
}
