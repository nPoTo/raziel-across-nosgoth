// SPDX-License-Identifier: GPL-3.0-or-later
#pragma once
// Own only gameplay D-pad input; native puzzle, physical-item and menu input remains native.
typedef struct {LocalActionOwner owner;bool directional;} LocalIntent59;
static SRWLOCK localIntentLock59=SRWLOCK_INIT;
static LocalIntent59 localIntent59;
static bool localNativeKey59(uint32_t code){
 uint32_t vk=0;const uintptr_t exe=(uintptr_t)GetModuleHandleW(NULL);
 return code<(uint32_t)sheet_sr1Combat59_input_and_native_coverage.keyMapCount&&
  readAt(exe+sheet_sr1Combat59_input_and_native_coverage.keyMapRva+4u*code,&vk,4)&&vk&&vk<256&&(GetAsyncKeyState((int)vk)&0x8000)!=0;
}
static void localDpadInput59(NativePad *out,const Sr1LocalFrame *frame){
 static uint32_t previous;static bool admitted;static LocalActionOwner menu;
 XINPUT_STATE state={0};const bool connected=localFormsPad&&localFormsPad(0,&state)==ERROR_SUCCESS;
 const uint32_t buttons=connected?state.Gamepad.wButtons:0,edge=buttons&~previous;previous=buttons;
 const bool live=frame->ready&&frame->renderBlend&&!localPhysicalCarry(player);
 const bool same=sameLocalAction(&menu,frame,player,GetTickCount64(),UINT64_MAX);
 if(live&&(buttons&15u)){
  // Native compose lets hat directions override the raw stick axes. Restore the real stick
  // plus actual remapped movement keys, never infer stick movement from the hat.
  int x=connected?(int)lroundf(state.Gamepad.sThumbLX*(float)motion->fullAxis/32767.f):0;
  int y=connected?-(int)lroundf(state.Gamepad.sThumbLY*(float)motion->fullAxis/32767.f):0;
  if(abs(state.Gamepad.sThumbLX)<XINPUT_GAMEPAD_LEFT_THUMB_DEADZONE)x=0;
  if(abs(state.Gamepad.sThumbLY)<XINPUT_GAMEPAD_LEFT_THUMB_DEADZONE)y=0;
  LocalBinding rows[BINDING_COUNT];const uintptr_t exe=(uintptr_t)GetModuleHandleW(NULL);
  if(readAt(exe+sheet_sr1LocalInputBoundary_native_binding_table.tableRva,rows,sizeof rows)){
   // Checked SRX rows0..3 are forward/left/back/right. Keys are SRX indices,
   // converted through its installed VK table; these are not Win32 virtual keys.
   const bool up=localNativeKey59(rows[0].key),down=localNativeKey59(rows[2].key);
   const bool left=localNativeKey59(rows[1].key),right=localNativeKey59(rows[3].key);
   if(up||down)y=(int)motion->fullAxis*((int)down-(int)up);if(left||right)x=(int)motion->fullAxis*((int)right-(int)left);
  }
  out->x=x;out->y=y;out->held&=~15u;out->pressed&=~15u;out->released&=~15u;
  if(y<-(int)motion->moveThreshold)out->held|=1;if(y>(int)motion->moveThreshold)out->held|=2;
  if(x<-(int)motion->moveThreshold)out->held|=4;if(x>(int)motion->moveThreshold)out->held|=8;
  if(edge&15u)record("defiance-dpad-filter raw=%x axes=%d/%d",buttons&15u,x,y);
 }
 // Open SR1's actual Glyph/Shift choice. A already maps to native confirm (jump).
 // Native Glyph code owns portal/ability restrictions and the complete realm transition.
 if(live&&admitted&&(edge&2u)&&frame->grounded&&!frame->nativeControl&&!frame->groundStrike&&!frame->strikePending){
  out->held|=0x8000u;out->pressed|=0x8000u;out->released&=~0x8000u;
  menu=localActionOwner(frame,player,GetTickCount64());record("defiance-realm-menu request=down confirm=A native-gates=1");
 }else if(!same)menu=(LocalActionOwner){0};
 admitted=live;
 LocalIntent59 intent={.owner=live?localActionOwner(frame,player,GetTickCount64()):(LocalActionOwner){0},
  .directional=abs(out->x)>(int)motion->moveThreshold||abs(out->y)>(int)motion->moveThreshold};
 AcquireSRWLockExclusive(&localIntentLock59);localIntent59=intent;ReleaseSRWLockExclusive(&localIntentLock59);
}
static bool localNeutralGuard59(const Sr1LocalFrame *frame,uint64_t now){
 LocalIntent59 intent;AcquireSRWLockShared(&localIntentLock59);intent=localIntent59;ReleaseSRWLockShared(&localIntentLock59);
 const LocalCombatInput guard=readLocalCombatInput();
 return !intent.directional&&sameLocalAction(&intent.owner,frame,player,now,sheet_sr1Combat59_input_and_native_coverage.neutralRootMs)&&
  sameLocalAction(&guard.guard,frame,player,now,UINT64_MAX)&&frame->ready&&frame->renderBlend&&frame->grounded&&!frame->nativeControl&&
  frame->airState==SR1_AIR_NONE&&!frame->groundStrike&&!frame->strikePending&&
  !readGroundX(frame,player,now).owner.tick&&!localYPresentation(&guard,frame,player,now)&&
  !localReadSpecial(frame,player,now).move&&!readLocalDodge(frame,player,now,0).owner.tick&&!localFinishActive53(frame,player,now);
}
