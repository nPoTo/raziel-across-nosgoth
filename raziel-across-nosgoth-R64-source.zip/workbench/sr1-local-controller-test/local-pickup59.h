// SPDX-License-Identifier: GPL-3.0-or-later
#pragma once
// Restored original 0.2 identities. These only yield control; they never link/unlink or move an item.
static bool localMorlockPickup59(uintptr_t item,uintptr_t parent,uintptr_t actor,uint32_t world){
 uintptr_t object=0,name=0,child=0;uint32_t room=0;char label[8];const uint32_t gen=generation(parent);
 if(!parent||parent==actor||parent==item||!gen||!readAt(parent+0x60,&room,4)||room!=world||
  !readAt(parent+host->childOffset,&child,8)||child!=item||!readAt(parent+0x30,&object,8)||!object||
  !readAt(object+0x30,&name,8)||!name||!readAt(name,label,8)||memcmp(label,"morlock",7)||(label[7]&&label[7]!='_'))return false;
 uintptr_t again=0;return generation(parent)==gen&&readAt(item+host->parentOffset,&again,8)&&again==parent&&
  readAt(parent+host->childOffset,&again,8)&&again==item;
}
static bool localZephonEggPickup59(uintptr_t item,uint32_t world){
 if(world!=(uint32_t)-4744)return false;
 uintptr_t object=0,name=0,message=0,process=0;char label[9];
 return readAt(item+0x30,&object,8)&&object&&readAt(object+0x30,&name,8)&&name&&readAt(name,label,9)&&
  !memcmp(label,"walbose_",9)&&readAt(item+0x1b8,&message,8)&&message==base+623120u&&
  readAt(item+0x1a8,&process,8)&&process==base+623264u;
}
