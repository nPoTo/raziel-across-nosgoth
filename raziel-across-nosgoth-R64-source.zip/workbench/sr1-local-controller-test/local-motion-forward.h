// SPDX-License-Identifier: GPL-3.0-or-later
#pragma once

#include "motion-code-proof.h"

typedef uintptr_t (*LocalMotionFn)(uintptr_t, int32_t, int32_t, uintptr_t);
static LocalMotionFn originalLocalMotion[2];
#ifdef SR1_LOCAL_COMBAT57
static uintptr_t localSpacingMotion57(unsigned kind,uintptr_t animation,int32_t section,int32_t type,uintptr_t vector){
 const DWORD spacingError57=GetLastError();
 if(!section&&type==34&&animation==player+(kind?0x448:0x328)){
  float wide[3];int16_t narrow[3];
  if(kind){if(!readAt(vector,wide,sizeof wide)){SetLastError(spacingError57);return originalLocalMotion[kind](animation,section,type,vector);}}
  else{if(!readAt(vector,narrow,sizeof narrow)){SetLastError(spacingError57);return originalLocalMotion[kind](animation,section,type,vector);}for(unsigned k=0;k<3;k++)wide[k]=narrow[k];}
  if(wide[2]==0&&isfinite(wide[0])&&isfinite(wide[1])&&fabsf(wide[0])<INT16_MAX&&fabsf(wide[1])<INT16_MAX){
#ifdef SR1_LOCAL_COMBAT59
   const Sr1LocalFrame neutral59=readFrame();
   if(localNeutralGuard59(&neutral59,GetTickCount64()))wide[0]=wide[1]=0;
#endif
   localSpacingVector57(player,&wide[0],&wide[1]);for(unsigned k=0;k<3;k++)narrow[k]=(int16_t)lroundf(wide[k]);SetLastError(spacingError57);return originalLocalMotion[kind](animation,section,type,(uintptr_t)(kind?(void*)wide:(void*)narrow));}
 }
 SetLastError(spacingError57);return originalLocalMotion[kind](animation,section,type,vector);
}
static uintptr_t localSpacingShort57(uintptr_t a,int32_t s,int32_t t,uintptr_t v){return localSpacingMotion57(0,a,s,t,v);}
static uintptr_t localSpacingFloat57(uintptr_t a,int32_t s,int32_t t,uintptr_t v){return localSpacingMotion57(1,a,s,t,v);}
#endif
static _Thread_local unsigned speedChanged;
#ifdef SR1_LOCAL_COMBAT_PRESENTATION
static uintptr_t localHeldStrikeVector(unsigned kind, uintptr_t animation);
#endif

static uintptr_t localMotionForward(unsigned kind, uintptr_t animation, int32_t section, int32_t type,
                                    uintptr_t vector, uintptr_t caller) {
    const LocalMotionFn original =
#ifdef SR1_LOCAL_COMBAT57
        kind?localSpacingFloat57:localSpacingShort57;
#else
        originalLocalMotion[kind];
#endif
    const uintptr_t expected = kind ? gaitPolicy->floatCallerRva : gaitPolicy->shortCallerRva;
#ifdef SR1_LOCAL_COMBAT_PRESENTATION
    if (caller == base + expected && section == 0 && type == 34) {
        const uintptr_t strikeVector = localHeldStrikeVector(kind, animation);
        if (strikeVector) return original(animation, section, type, strikeVector);
    }
#endif
    const uint64_t tick = GetTickCount64();
#ifdef SR1_LOCAL_COMBAT_HANDOFF
    if (caller == base + expected && !section && type == 34) {
        const LocalCombatInput controls = readLocalCombatInput();
        if (!controls.airborneLift && groundLiftWindow(controls.lift.tick, tick, guardClips->liftMs)) {
            const Sr1LocalFrame frame = readFrame();
            if (frame.ready && frame.renderBlend && animation == player + (kind ? 0x448 : 0x328) &&
                localYPresentation(&controls, &frame, player, tick)) {
                // Retire the native stop/run displacement during the grounded Y presentation.
                // Carry over the native vertical component and leave ordinary physics active.
                if (kind) {
                    float stopped[3];
                    if (readAt(vector, stopped, sizeof(stopped))) {
                        stopped[0] = stopped[1] = 0.f;
                        return original(animation, section, type, (uintptr_t)stopped);
                    }
                } else {
                    int16_t stopped[3];
                    if (readAt(vector, stopped, sizeof(stopped))) {
                        stopped[0] = stopped[1] = 0;
                        return original(animation, section, type, (uintptr_t)stopped);
                    }
                }
            }
        }
    }
#endif
    const uint64_t input = (uint64_t)InterlockedCompareExchange64(&groundIntentTick, 0, 0);
    if (caller != base + expected || section || type != 34 || !input || tick < input ||
        tick - input > (uint64_t)groundPolicy->maxGapMs ||
        !InterlockedCompareExchange(&calibratedDrawReady, 0, 0)) {
        return original(animation, section, type, vector);
    }
    const bool full = InterlockedCompareExchange(&fullGroundIntent, 0, 0) != 0;
#ifdef SR1_LOCAL_CONTROL_FIX
    const LocalCombatInput guard = readLocalCombatInput();
    const bool guardDrive = guard.guardHeld && guard.guardSpeed > 0.f && guard.guardSample <= tick &&
        tick - guard.guardSample <= (uint64_t)groundPolicy->maxGapMs;
#else
    const bool guardDrive = false;
#endif
#ifndef SR1_LOCAL_CALIBRATED_MOVEMENT
    if (!full && !guardDrive) return original(animation, section, type, vector);
#endif
    const Sr1LocalFrame frame = readFrame();
    int32_t time;
    if (!frame.ready || frame.nativeControl || frame.realm == SR1_LOCAL_UNKNOWN ||
        animation != player + (kind ? 0x448 : 0x328) ||
        !readAt(base + gaitPolicy->motionTimeRva, &time, sizeof(time))) {
        return original(animation, section, type, vector);
    }
    float wide[3];
    int16_t shortVector[3];
    if (kind) {
        if (!readAt(vector, wide, sizeof(wide))) return original(animation, section, type, vector);
    } else {
        if (!readAt(vector, shortVector, sizeof(shortVector))) return original(animation, section, type, vector);
        for (unsigned k = 0; k < 3; ++k) wide[k] = (float)shortVector[k];
    }
    if (wide[2] != 0) return original(animation, section, type, vector);
#ifdef SR1_LOCAL_CONTROL_FIX
    if (guardDrive && sameLocalAction(&guard.guard, &frame, player, tick, UINT64_MAX) &&
        time > 0 && time <= 2 * gaitPolicy->clockDenominator) {
        const float length = hypotf(wide[0], wide[1]);
        if (isfinite(length) && length > 0.f && length <= (float)gaitPolicy->maxStep) {
            const float stockScale = (float)time / (float)gaitPolicy->clockDenominator;
            const float sourceSpeed = (float)sheet_sr1LocalGuardDirection_combat_run.unitsPerSecond;
            const float target = stockScale * guard.guardSpeed * sourceSpeed / (float)gaitPolicy->nominalUpdatesHz;
            const float factor = target / length;
#ifdef SR1_LOCAL_COMBAT_CONTINUITY
            uint16_t bodyYaw;
            if (guard.guardDirectional && readAt(player+sheet_sr1GroundSteering_camera_relative_start.yawOffset,
                &bodyYaw,sizeof(bodyYaw))) {
                combatDodgeVector(bodyYaw,guard.guardBearing,target,&wide[0],&wide[1]);
            } else
#endif
            {
                wide[0]*=factor;
                wide[1]*=factor;
            }
            for (unsigned axis = 0; axis < 2; ++axis) {
                shortVector[axis] = (int16_t)roundf(wide[axis]);
            }
            if (kind && (speedChanged++ < 8 || speedChanged % 240 == 0)) {
                record("defiance-guard-drive realm=%u time=%ld stock=%.2f calibrated=%.2f",
                    frame.realm, (long)time, length, target);
            }
            return original(animation, section, type, (uintptr_t)(kind ? (void *)wide : (void *)shortVector));
        }
    }
#endif
#ifdef SR1_LOCAL_CALIBRATED_MOVEMENT
    if (!full && !guardDrive && frame.grounded && frame.airState == SR1_AIR_NONE &&
        !frame.groundStrike && !frame.strikePending && !frame.strikeTransition &&
        !guard.guardHeld && time > 0 && time <= 2 * gaitPolicy->clockDenominator) {
        const float length = hypotf(wide[0], wide[1]);
        if (isfinite(length) && length > 0.f && length <= (float)gaitPolicy->maxStep) {
            for (unsigned axis = 0; axis < 2; ++axis) {
                wide[axis] *= gaitPartialScale();
                shortVector[axis] = (int16_t)roundf(wide[axis]);
            }
            return original(animation, section, type, (uintptr_t)(kind ? (void *)wide : (void *)shortVector));
        }
    }
#endif
    if (!full || wide[0] != 0) return original(animation, section, type, vector);
    const float prior = wide[1];
    wide[1] = gaitForwardStep(prior, time, true);
    if (wide[1] != prior) {
        shortVector[1] = (int16_t)wide[1];
        vector = (uintptr_t)(kind ? (void *)wide : (void *)shortVector);
        if (kind && (speedChanged++ < 8 || speedChanged % 240 == 0)) {
            record("ground-drive realm=%u time=%ld stock=%.2f calibrated=%.2f", frame.realm, (long)time, prior, wide[1]);
        }
    }
    return original(animation, section, type, vector);
}

static uintptr_t localMotionShort(uintptr_t anim, int32_t section, int32_t type, uintptr_t vector) {
    return localMotionForward(0, anim, section, type, vector, (uintptr_t)__builtin_return_address(0));
}

static uintptr_t localMotionFloat(uintptr_t anim, int32_t section, int32_t type, uintptr_t vector) {
    return localMotionForward(1, anim, section, type, vector, (uintptr_t)__builtin_return_address(0));
}

static bool prepareLocalMotion(void) {
    void *const hooks[] = {(void *)localMotionShort, (void *)localMotionFloat};
    for (unsigned i = 0; i < ARRAYSIZE(hooks); ++i) {
        if (!verifyDrawBlock(motionCodeProofs[i].rva, motionCodeProofs[i].size, motionCodeProofs[i].sha256)) return false;
    }
    for (unsigned i = 0; i < ARRAYSIZE(hooks); ++i) {
        void *target = (void *)(base + motionCodeProofs[i].rva);
        if (MH_CreateHook(target, hooks[i], (void **)&originalLocalMotion[i]) != MH_OK) {
            for (unsigned j = 0; j < i; ++j) MH_RemoveHook((void *)(base + motionCodeProofs[j].rva));
            return false;
        }
    }
    return true;
}
