// SPDX-License-Identifier: GPL-3.0-or-later
#pragma once
// Blade-local procedural geometry; the existing original-hand/MVP path owns its transform.
static _Thread_local struct {ReaverGLVertex v[2048];uint16_t i[3072];unsigned n;} localFxMesh51;
static bool localFxDraw51(const float mvp[16],unsigned texture,unsigned blend){
 const unsigned n=localFxMesh51.n;localFxMesh51.n=0;
 return !n||reaverGLDraw(&c2ImpactGl,localFxMesh51.v,n*4,localFxMesh51.i,n*6,texture,blend,mvp,0,-1);
}
static void localFxQuad51(const float c[3],const float r[3],const float u[3],float w,float h,const float color[4]){
 if(localFxMesh51.n<512)c2ImpactQuad(localFxMesh51.v,localFxMesh51.i,localFxMesh51.n++,c,r,u,0,0,w,h,color);
}
static void localFxSegment51(const float a[3],const float b[3],const float right[3],const float up[3],float width,const float color[4]){
 float c[3],along[3],across[3];float length=0;
 for(unsigned k=0;k<3;k++){along[k]=b[k]-a[k];length+=along[k]*along[k];c[k]=(a[k]+b[k])*.5f;}
 length=sqrtf(length);if(!isfinite(length)||length<.001f)return;
 float x=0,y=0;for(unsigned k=0;k<3;k++){along[k]/=length;x+=along[k]*right[k];y+=along[k]*up[k];}
 float l=hypotf(x,y);if(l<.001f){x=1;y=0;l=1;}
 for(unsigned k=0;k<3;k++)across[k]=(-y*right[k]+x*up[k])/l;
 localFxQuad51(c,along,across,length*.5f,width,color);
}
static float localFxTaper51(float t){if(t<=0)return 1;if(t>=1)return 0;const float f=1-t;return f*f*(3-2*f);}
static void localFxCoilPoint51(float p[3],float t,float start,float tip,float phase,float helix){
 const float taper=localFxTaper51(t),angle=phase+helix+t*(float)sheet_sr1Combat51_aerial_charged_fx.coilTurns*6.28318530718f+.10f*sinf(t*91+phase*7);
 const float r=((float)sheet_sr1Combat51_aerial_charged_fx.coilRadius+4*sinf(t*113+phase*11))*taper;
 p[0]=cosf(angle)*r;p[1]=sinf(angle)*r;p[2]=start+(tip-start)*t;
}
static bool localDrawCoil51(const Sr1LocalFrame *f,uintptr_t actor,const float mvp[16],float start,float tip,float reveal,uint64_t now){
 static _Thread_local float amount;static _Thread_local uint64_t last;static _Thread_local uint32_t priorWorld,priorGen,priorRealm,priorForm;
 const unsigned form=localCurrentForm(f->realm);const bool same=priorWorld==f->worldGeneration&&priorGen==f->playerGeneration&&priorRealm==(uint32_t)f->realm&&priorForm==form;
 if(!same){amount=0;last=now;priorWorld=f->worldGeneration;priorGen=f->playerGeneration;priorRealm=f->realm;priorForm=form;}
 const bool full=localFullCharge51(f,actor,now);
 const float step=(float)(last&&now>=last?(now-last>50?50:now-last):0)/(float)sheet_sr1Combat51_aerial_charged_fx.coilFadeMs;last=now;
 amount=fmaxf(0,fminf(1,amount+(full?step:-step)));if(amount<=0||reveal<=0||!isfinite(start)||!isfinite(tip)||tip<=start)return true;
 float r[3],u[3],center[3]={0,0,(start+tip)*.5f};if(!c2ImpactBillboard(mvp,0,center,r,u)||!c2ImpactInit())return false;
 const float phase=(float)(now%1600)*6.28318530718f/1600.f;float color[4];c2ImpactColor(localFxColor51(form),amount*reveal,color);
 color[0]*=1.5f;color[1]*=1.5f;color[2]*=1.5f;
 localFxMesh51.n=0;
 for(unsigned h=0;h<2;h++)for(unsigned s=0;s<(unsigned)sheet_sr1Combat51_aerial_charged_fx.coilSegments;s++){
  float a[3],b[3];const float t=(float)s/(float)sheet_sr1Combat51_aerial_charged_fx.coilSegments,next=(float)(s+1)/(float)sheet_sr1Combat51_aerial_charged_fx.coilSegments;
  localFxCoilPoint51(a,t,start,tip,phase,h*3.14159265359f);localFxCoilPoint51(b,next,start,tip,phase,h*3.14159265359f);
  float tint[4];memcpy(tint,color,sizeof tint);tint[3]*=localFxTaper51((t+next)*.5f);
  const unsigned before=localFxMesh51.n;const float width=(float)sheet_sr1Combat51_aerial_charged_fx.coilWidth*localFxTaper51(t);
  localFxSegment51(a,b,r,u,width,tint);
  if(localFxMesh51.n>before){
   const float ratio=localFxTaper51(next)/localFxTaper51(t);
   // The two end vertices collapse exactly to the centerline at t=1, never past its tip.
   for(unsigned v=1;v<4;v+=2)for(unsigned k=0;k<3;k++){
    ReaverGLVertex *vertex=&localFxMesh51.v[before*4+v];vertex->position[k]=b[k]+(vertex->position[k]-b[k])*ratio;
   }
  }
 }
 return localFxDraw51(mvp,4,2);
}
static void localDrawChargedFx51(uintptr_t actor,const float palm[16],const float mvp[16],float start,float tip,float reveal){
 const Sr1LocalFrame f=readFrame();const uint64_t now=GetTickCount64();if(!f.ready||!f.renderBlend||actor!=player)return;
 localDrawCoil51(&f,actor,mvp,start,tip,reveal,now);
 LocalFx51 list[64];AcquireSRWLockShared(&localFxLock51);memcpy(list,localFxPool51,sizeof list);ReleaseSRWLockShared(&localFxLock51);
 for(unsigned i=0;i<64;i++){
  const LocalFx51 *fx=&list[i];if(!localFxCurrent51(fx,&f,actor,now))continue;
  float c[3]={0},r[3],u[3],color[4];if(!fx->hand){
#ifdef SR1_LOCAL_COMBAT52
   int16_t point[3];memcpy(point,fx->point,6);
   if(fx->targetActor&&!localTargetPoint52(fx->targetActor,fx->target,f.worldGeneration,point))continue;
   c2ImpactLocal(point,palm,c);
#else
   c2ImpactLocal(fx->point,palm,c);
#endif
  }
  if(!c2ImpactBillboard(mvp,0,c,r,u)||!c2ImpactInit())continue;
#ifdef SR1_LOCAL_COMBAT52
  const bool spell=fx->hand||(!fx->smoke&&fx->beam);
  const float duration=(float)(spell?sheet_sr1Combat52_target_cast_camera.castMs:sheet_sr1Combat51_aerial_charged_fx.hitMs);
  const float life=(float)(now-fx->tick)/duration,fade=1-life;
  const bool pulse=fx->form==1||fx->form==2||fx->form==9;
  const float extent=fx->hand?(float)(pulse?sheet_sr1Combat52_target_cast_camera.castRadius:sheet_sr1Combat52_target_cast_camera.otherCastRadius):
    (float)(spell?sheet_sr1Combat52_target_cast_camera.targetRadius:sheet_sr1Combat51_aerial_charged_fx.hitRadius);
  const float radius=extent*(spell?(.85f+.15f*life):(.45f+.55f*life));
#else
  const float life=(float)(now-fx->tick)/(float)(fx->hand?sheet_sr1Combat51_aerial_charged_fx.castMs:sheet_sr1Combat51_aerial_charged_fx.hitMs),fade=1-life;
  const float radius=(float)(fx->hand?sheet_sr1Combat51_aerial_charged_fx.handRadius:sheet_sr1Combat51_aerial_charged_fx.hitRadius)*(.45f+.55f*life);
#endif
  c2ImpactColor(localFxColor51(fx->form),fade,color);
  color[0]*=2.5f;color[1]*=2.5f;color[2]*=2.5f;color[3]*=.9f;
  localFxMesh51.n=0;localFxQuad51(c,r,u,radius*.5f,radius*.5f,color);localFxDraw51(mvp,1,2);
#ifdef SR1_LOCAL_COMBAT52
  if(spell){localFxMesh51.n=0;localFxQuad51(c,r,u,radius,radius,color);localFxDraw51(mvp,2,2);}
#endif
  localFxMesh51.n=0;
  for(unsigned ray=0;ray<16;ray++){
   const float angle=(ray+(float)(fx->tick%17)/17)*6.28318530718f/16;float end[3];
   for(unsigned k=0;k<3;k++)end[k]=c[k]+radius*(.55f+.1f*(ray%4))*(r[k]*cosf(angle)+u[k]*sinf(angle));
   localFxSegment51(c,end,r,u,radius*.025f,color);
  }
  if(fx->beam){float a[3]={0,0,tip};
#ifdef SR1_LOCAL_COMBAT52
   if(spell){int16_t source[3];if(readAt(actor+0x9c,source,6)&&source[2]<=INT16_MAX-sheet_sr1Combat52_target_cast_camera.sourceHeight){source[2]+=(int16_t)sheet_sr1Combat52_target_cast_camera.sourceHeight;c2ImpactLocal(source,palm,a);}}
   const float beamWidth=(float)(spell?sheet_sr1Combat52_target_cast_camera.beamWidth:sheet_sr1Combat51_aerial_charged_fx.beamWidth);
   float sourcePoint[3];memcpy(sourcePoint,a,sizeof a);
   const unsigned bolts=spell?3:1;
   for(unsigned bolt=0;bolt<bolts;bolt++){memcpy(a,sourcePoint,sizeof a);
#endif
   for(unsigned s=1;s<=9;s++){float b[3];const float t=s/9.f,jitter=s==9?0:18.f*sinf((float)(now/32+fx->target+s*17));
#ifdef SR1_LOCAL_COMBAT52
    for(unsigned k=0;k<3;k++)b[k]=sourcePoint[k]*(1-t)+c[k]*t+(jitter+((float)bolt-1)*30.f*sinf(t*3.14159265f))*(r[k]+.4f*u[k]);
    localFxSegment51(a,b,r,u,beamWidth*fade,color);memcpy(a,b,sizeof a);
#else
    for(unsigned k=0;k<3;k++)b[k]=(k==2?tip:0)*(1-t)+c[k]*t+jitter*(r[k]+.4f*u[k]);
    localFxSegment51(a,b,r,u,(float)sheet_sr1Combat51_aerial_charged_fx.beamWidth*fade,color);memcpy(a,b,sizeof a);
#endif
   }
#ifdef SR1_LOCAL_COMBAT52
   }
#endif
  }
  localFxDraw51(mvp,3,2);
  if(fx->smoke){localFxMesh51.n=0;float tint[4];c2ImpactColor(localFxColor51(fx->form),fade*.3f,tint);
   const float puff=(float)sheet_sr1Combat51_aerial_charged_fx.smokeRadius*(.25f+.85f*life);
   for(unsigned s=0;s<7;s++){float p[3];const float angle=s*2.399963f;
    for(unsigned k=0;k<3;k++)p[k]=c[k]+puff*.45f*(r[k]*cosf(angle)+u[k]*sinf(angle));
    localFxQuad51(p,r,u,puff,puff,tint);
   }localFxDraw51(mvp,1,1);
  }
 }
}
