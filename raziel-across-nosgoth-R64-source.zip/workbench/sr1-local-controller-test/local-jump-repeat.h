// SPDX-License-Identifier: GPL-3.0-or-later
#pragma once
#include "repeat-jump-advance-proof.h"
#if defined(SR1_LOCAL_REPEAT_ON_FALL_EXIT) || defined(SR1_LOCAL_JUMP_EDGE)
#include "local-landing-entry-proof.h"
#endif
#ifdef SR1_LOCAL_JUMP_EDGE
#include "local-jump-edge.h"
#endif
#ifdef SR1_LOCAL_IMMEDIATE_REPEAT
#include "instant-root-proof.h"
#endif
#ifdef SR1_LOCAL_SURFACE_TRACE
#include "host-ground-forward.h"
#endif

static bool verifyDrawBlock(uintptr_t rva, DWORD length, const char *digest);
static const Sheet_sr1LocalJumpRepeat *const repeatPolicy = &sheet_sr1LocalJumpRepeat_ordinary_repeat;
typedef uintptr_t (*LocalRepeatFn)(uintptr_t, int32_t, uintptr_t);
typedef void (*LocalRepeatQueueFn)(uintptr_t, uint32_t, uintptr_t);
typedef int (*LocalRepeatClipFn)(uintptr_t, int32_t);
static LocalRepeatFn originalLocalRepeat[2];
#ifdef SR1_LOCAL_REPEAT_ON_FALL_EXIT
static LocalRepeatFn originalLocalRepeatFall;
#endif
static _Thread_local struct {
    LocalActionOwner input;
#ifdef SR1_LOCAL_JUMP_EDGE
    bool rawJumpHeld;
#endif
#ifdef SR1_LOCAL_IMMEDIATE_REPEAT
    LocalActionOwner heldJump;
    bool dispatching;
#endif
#ifdef SR1_LOCAL_MOVING_LANDING
    uint64_t waitFlight;
    uint32_t waitMask;
#endif
    uint64_t armedLanding, coastHandled, syntheticHold;
    bool repeatPending, shortenedLanding, shortenedCompression;
} repeatJump;

static void armLocalLanding(const Sr1LocalFrame *frame, uint64_t now) {
    const LocalJumpReceipt flight = readLocalJump();
    if (sameLocalAction(&flight.owner, frame, player, now, airPolicy->maxFlightMs) &&
        repeatJump.armedLanding != flight.owner.tick) {
        repeatJump.armedLanding = flight.owner.tick;
        repeatJump.input = localActionOwner(frame, player, now);
        repeatJump.repeatPending = true;
        repeatJump.shortenedLanding = false;
    }
}

static bool localLandingVelocity(int32_t vertical) {
#ifdef SR1_LOCAL_LANDING_CONTACT
    return vertical <= 0 && vertical >= -repeatPolicy->contactFallLimit;
#else
    return vertical == 0;
#endif
}

static void localRepeatInput(NativePad *output, const Sr1LocalFrame *frame) {
    uint32_t mask;
    if (!frame->ready || !frame->renderBlend || frame->realm == SR1_LOCAL_UNKNOWN ||
        !readAt(base + signals->jumpMaskRva, &mask, sizeof(mask)) || !mask ||
        output->held & ~(0x8000000fu | mask)) {
        repeatJump.repeatPending = false;
        repeatJump.input.tick = repeatJump.syntheticHold = 0;
#ifdef SR1_LOCAL_IMMEDIATE_REPEAT
        repeatJump.heldJump.tick = 0;
#endif
        return;
    }
    const uint64_t now = GetTickCount64();
#ifdef SR1_LOCAL_JUMP_EDGE
    const bool rawPress = localFreshJumpPress(&repeatJump.rawJumpHeld, (output->held & mask) != 0,
        (output->pressed & mask) != 0);
    if (!rawPress) output->pressed &= ~mask;
    else record("defiance-jump-press realm=%u stage=%u", frame->realm, frame->airState);
#endif
#ifdef SR1_LOCAL_IMMEDIATE_REPEAT
    if (output->held & mask) repeatJump.heldJump = localActionOwner(frame, player, now);
    else repeatJump.heldJump.tick = 0;
#endif
    const bool sameInput = sameLocalAction(&repeatJump.input, frame, player, now, repeatPolicy->bufferMs);
    if (!sameInput) {
        repeatJump.repeatPending = false;
        repeatJump.input.tick = repeatJump.syntheticHold = 0;
    }
    if (frame->airState == SR1_AIR_LAND && localLandingVelocity(frame->verticalVelocity) &&
#ifdef SR1_LOCAL_JUMP_EDGE
        rawPress
#else
        ((output->held | output->pressed) & mask)
#endif
    ) {
        armLocalLanding(frame, now);
#ifdef SR1_LOCAL_JUMP_EDGE
        if (repeatJump.repeatPending) output->pressed &= ~mask;
#endif
    }
    if (frame->grounded && !frame->nativeControl) {
        const bool pending = repeatJump.repeatPending;
        if (pending) {
            repeatJump.repeatPending = false;
            repeatJump.syntheticHold = now + (uint64_t)repeatPolicy->minimumHoldMs;
            output->held |= mask;
            output->pressed |= mask;
            output->released &= ~mask;
            record("defiance-jump-buffer delivered realm=%u age=%llu", frame->realm,
                (unsigned long long)(now - repeatJump.input.tick));
        }
        if (output->pressed & mask) {
            repeatJump.input = localActionOwner(frame, player, now);
            repeatJump.shortenedCompression = false;
        }
    }
    if (repeatJump.syntheticHold && now < repeatJump.syntheticHold &&
        (frame->grounded || frame->airState == SR1_AIR_COMPRESS)) {
        output->held |= mask;
        output->released &= ~mask;
    }
}

static bool localSectionState(uintptr_t state, unsigned section, uintptr_t *callback, bool requireEmpty) {
    if (!readAt(state + 0x10 + section * 0x228, callback, sizeof(*callback))) return false;
    if (!requireEmpty) return true;
    int32_t queue[2];
    return readAt(state + 0x18 + section * 0x228, queue, sizeof(queue)) &&
        queue[0] >= 0 && queue[0] <= 15 && queue[1] == queue[0];
}

#ifdef SR1_LOCAL_IMMEDIATE_REPEAT
static bool localGroundJumpCallback(uintptr_t callback) {
    return callback == base + responsePolicy->idleRva || callback == base + responsePolicy->moveRva ||
        callback == base + responsePolicy->startMoveRva;
}

static bool localJumpEntry(uintptr_t state, uintptr_t landing, uintptr_t data, LocalRepeatQueueFn enqueue) {
    // All three Landing queues were empty before the ordinary completion was posted.
    for (unsigned i = 0; i < 3; ++i) {
        uintptr_t current;
        if (localSectionState(state, i, &current, false) && current == landing) {
            originalLocalRepeat[0](state, (int32_t)i, data);
        }
    }
    const Sr1LocalFrame ground = readFrame();
    if (!ground.ready || ground.nativeControl || !sameLocalAction(&repeatJump.input, &ground,
            player, GetTickCount64(), repeatPolicy->bufferMs)) return false;
    uintptr_t entry;
    if (!localSectionState(state, 0, &entry, true) || !localGroundJumpCallback(entry)) return false;
    for (unsigned i = 1; i < 3; ++i) {
        uintptr_t current;
        if (!localSectionState(state, i, &current, true) ||
#ifdef SR1_LOCAL_MOVING_LANDING
            !localGroundJumpCallback(current)
#else
            current != entry
#endif
        ) return false;
    }
    enqueue(state + 0x18, (uint32_t)repeatPolicy->jumpPressEvent, 0);
    ((LocalRepeatFn)entry)(state, 0, data);
    const uintptr_t compression = base + groundPolicy->compressRva;
    uintptr_t current;
    if (!localSectionState(state, 0, &current, true) || current != compression) return false;
    repeatJump.repeatPending = false;
    repeatJump.syntheticHold = GetTickCount64() + (uint64_t)repeatPolicy->minimumHoldMs;
    return true;
}
#endif

#ifdef SR1_LOCAL_MOVING_LANDING
static void recordLocalRepeatWait(const Sr1LocalFrame *frame, uint64_t now, unsigned reason, int32_t detail) {
    if (frame->airState != SR1_AIR_LAND ||
        !sameLocalAction(&repeatJump.heldJump, frame, player, now, repeatPolicy->freshPadMs)) return;
    const LocalJumpReceipt flight = readLocalJump();
    if (!sameLocalAction(&flight.owner, frame, player, now, airPolicy->maxFlightMs)) return;
    if (repeatJump.waitFlight != flight.owner.tick) {
        repeatJump.waitFlight = flight.owner.tick;
        repeatJump.waitMask = 0;
    }
    if (repeatJump.waitMask & (1u << reason)) return;
    repeatJump.waitMask |= 1u << reason;
    const char *const reasons[] = {"velocity", "callbacks", "clip", "queued", "render", "motion-clock"};
    record("defiance-repeat-wait realm=%u reason=%s value=%ld", frame->realm, reasons[reason], (long)detail);
}
#endif

static void stopReleasedLanding(const Sr1LocalFrame *frame, uintptr_t actor, uint64_t now, uint32_t mode) {
    const LocalJumpReceipt flight = readLocalJump();
    if (!(mode & repeatPolicy->landingModeMask) ||
        !sameLocalAction(&flight.owner, frame, actor, now, airPolicy->maxFlightMs) ||
        repeatJump.coastHandled == flight.owner.tick ||
        InterlockedCompareExchange64(&groundIntentTick, 0, 0)) return;
    int32_t speed[2];
    const uintptr_t at = actor + repeatPolicy->velocityOffset;
    if (!readAt(at, speed, sizeof(speed))) return;
    repeatJump.coastHandled = flight.owner.tick;
    const int32_t rest[2] = {0};
    SIZE_T written = 0;
    const bool stopped = speed[0] == 0 && speed[1] == flight.forward &&
        WriteProcessMemory(GetCurrentProcess(), (void *)at, rest, sizeof(rest), &written) && written == sizeof(rest);
    record("defiance-landing-coast realm=%u vx=%ld vy=%ld stopped=%u", frame->realm,
        (long)speed[0], (long)speed[1], (unsigned)stopped);
}

#if defined(SR1_LOCAL_REPEAT_ON_FALL_EXIT) || defined(SR1_LOCAL_REPEAT_ON_PAD)
static bool localLandingEntryQueues(uintptr_t state) {
    for (unsigned i = 0; i < 3; ++i) {
        const uintptr_t queueAt = state + 0x18 + i * 0x228;
        uint32_t cursors[2];
        if (!readAt(queueAt, cursors, sizeof(cursors)) || cursors[0] > 15 || cursors[1] > 15) return false;
        const unsigned size = (cursors[1] - cursors[0]) & 15;
        if (size > 2) return false;
        for (unsigned j = 0; j < size; ++j) {
            const uintptr_t message = queueAt + 8 + ((cursors[0] + j) & 15) * 16;
            uint32_t id;
            uintptr_t payload;
            if (!readAt(message, &id, sizeof(id)) || id != (uint32_t)repeatPolicy->nativeSectionStopEvent ||
                !readAt(message + 8, &payload, sizeof(payload)) || payload) return false;
        }
    }
    return true;
}
#endif

static uintptr_t observeLocalRepeat(unsigned kind, uintptr_t state, int32_t section, uintptr_t data);

#ifdef SR1_LOCAL_REPEAT_DRAW_LEASE
static bool localRepeatOwnsFlight(const Sr1LocalFrame *frame, uint64_t now) {
    if (InterlockedCompareExchange(&groundDrawRefused, 0, 0)) return false;
    const LocalJumpReceipt flight = readLocalJump();
    if (!sameLocalAction(&flight.owner, frame, player, now, airPolicy->maxFlightMs)) return false;
    return sameLocalAction(&repeatJump.heldJump, frame, player, now, repeatPolicy->freshPadMs) ||
        (repeatJump.armedLanding == flight.owner.tick &&
         sameLocalAction(&repeatJump.input, frame, player, now, repeatPolicy->bufferMs));
}
#endif

static uintptr_t advanceLocalRepeat(unsigned kind, uintptr_t state, int32_t section, uintptr_t data,
                                   uintptr_t result, const char *earlySource) {
#ifdef SR1_LOCAL_REPEAT_ON_LANDING_SECTION
    if (section != 2 && (kind || section < 0 || section > 2)) return result;
#else
    if (section != 2) return result;
#endif
#ifdef SR1_LOCAL_IMMEDIATE_REPEAT
    if (repeatJump.dispatching) return result;
#endif
    const uint64_t now = GetTickCount64();
    const Sr1LocalFrame frame = readFrame();
    const bool drawReady = InterlockedCompareExchange(&calibratedDrawReady, 0, 0) != 0;
#ifdef SR1_LOCAL_REPEAT_DRAW_LEASE
    const bool inherited = frame.ready && frame.renderBlend && !drawReady && localRepeatOwnsFlight(&frame, now);
    if (!drawReady && !inherited) {
        if (!kind) recordLocalRepeatWait(&frame, now, 4, frame.renderBlend);
        return result;
    }
#else
    if (!drawReady) return result;
#endif
    const Sr1LocalAirState air = kind ? SR1_AIR_COMPRESS : SR1_AIR_LAND;
    const uintptr_t expected = base + (kind ? groundPolicy->compressRva : groundPolicy->landRva);
    uintptr_t actor;
    int32_t count, time;
    uint32_t mode;
    if (!frame.ready || !frame.renderBlend || frame.realm == SR1_LOCAL_UNKNOWN ||
        frame.airState != air ||
        !readAt(state, &actor, sizeof(actor)) || actor != player ||
        !readAt(state + 8, &count, sizeof(count)) || count != 3 ||
        !readAt(base + 0x2a88c10, &mode, sizeof(mode))) return result;
    if (!readAt(base + gaitPolicy->motionTimeRva, &time, sizeof(time)) || time <= 0 || time > 8192) {
#ifdef SR1_LOCAL_MOVING_LANDING
        if (!kind) recordLocalRepeatWait(&frame, now, 5, 0);
#endif
        return result;
    }
    if (kind ? frame.verticalVelocity != 0 : !localLandingVelocity(frame.verticalVelocity)) {
#ifdef SR1_LOCAL_MOVING_LANDING
        if (!kind) recordLocalRepeatWait(&frame, now, 0, frame.verticalVelocity);
#endif
        return result;
    }
    // Known native state and matching contact are required even with A held.
    for (unsigned i = 0; i < 3; ++i) {
        uintptr_t current;
        if (!localSectionState(state, i, &current, false) || current != expected) {
#ifdef SR1_LOCAL_MOVING_LANDING
            if (!kind) recordLocalRepeatWait(&frame, now, 1, (int32_t)i);
#endif
            return result;
        }
    }
    const int clip = ((LocalRepeatClipFn)(base + 0x10dc10))(state, 0);
    const bool ordinaryLand = !kind && (mode == 0x1008 || mode == 0x1010) && (clip == 29 || clip == 37);
    if (ordinaryLand) stopReleasedLanding(&frame, actor, now, mode);
#ifdef SR1_LOCAL_MOVING_LANDING
    if (!kind && !ordinaryLand) {
        recordLocalRepeatWait(&frame, now, 2, clip == 29 || clip == 37 ? (int32_t)mode : clip);
    }
#endif
#if defined(SR1_LOCAL_IMMEDIATE_REPEAT) && !defined(SR1_LOCAL_JUMP_EDGE)
    if (ordinaryLand && sameLocalAction(&repeatJump.heldJump, &frame, actor, now, repeatPolicy->freshPadMs)) {
        armLocalLanding(&frame, now);
    }
#endif
    if (!sameLocalAction(&repeatJump.input, &frame, actor, now, repeatPolicy->bufferMs)) return result;
    const bool eligible = kind ?
        !repeatJump.shortenedCompression && (mode == 8 || mode == 16) && (clip == 26 || clip == 34) :
        ordinaryLand && repeatJump.repeatPending && !repeatJump.shortenedLanding;
    if (!eligible) return result;
#if defined(SR1_LOCAL_REPEAT_ON_FALL_EXIT) || defined(SR1_LOCAL_REPEAT_ON_PAD)
    if (earlySource) {
        if (!localLandingEntryQueues(state)) {
            recordLocalRepeatWait(&frame, now, 3, -1);
            return result;
        }
        repeatJump.dispatching = true;
        for (unsigned i = 0; i < 3; ++i) originalLocalRepeat[0](state, (int32_t)i, data);
        repeatJump.dispatching = false;
    }
#else
    (void)earlySource;
#endif
    for (unsigned i = 0; i < 3; ++i) {
        uintptr_t current;
        if (!localSectionState(state, i, &current, true) || current != expected) {
#ifdef SR1_LOCAL_MOVING_LANDING
            if (!kind) recordLocalRepeatWait(&frame, now, 3, (int32_t)i);
#endif
            return result;
        }
    }
    if (kind) repeatJump.shortenedCompression = true;
    else repeatJump.shortenedLanding = true;
    const LocalRepeatQueueFn enqueue = (LocalRepeatQueueFn)(base + 0x10ccc0);
#ifdef SR1_LOCAL_LANDING_CONTACT
    // Original Landing uses this event to zero its residual launch motion.
    int32_t vertical = frame.verticalVelocity;
#if defined(SR1_LOCAL_REPEAT_ON_FALL_EXIT) || defined(SR1_LOCAL_REPEAT_ON_PAD)
    if (earlySource) readAt(actor + 0x2d4, &vertical, sizeof(vertical));
#endif
    if (!kind && vertical) enqueue(state + 0x18, (uint32_t)repeatPolicy->nativeSectionStopEvent, 0);
#endif
    for (unsigned i = 0; i < 3; ++i) enqueue(state + 0x18 + i * 0x228, 0x08000000, 0);
    record("defiance-jump-advance realm=%u phase=%s age=%llu", frame.realm, kind ? "compression" : "landing",
        (unsigned long long)(now - repeatJump.input.tick));
#ifdef SR1_LOCAL_REPEAT_DRAW_LEASE
    if (inherited) record("defiance-repeat-flight-lease realm=%u section=%s", frame.realm, kind ? "compression" : "landing");
#endif
#ifdef SR1_LOCAL_IMMEDIATE_REPEAT
    repeatJump.dispatching = true;
    if (!kind && localJumpEntry(state, expected, data, enqueue)) {
        repeatJump.shortenedCompression = false;
        // Dispatch only after the native entry initialized all sections.
        repeatJump.dispatching = false;
        observeLocalRepeat(1, state, 2, data);
        const LocalJumpReceipt launched = readLocalJump();
        const bool didLaunch = launched.owner.tick >= now && launched.owner.tick != repeatJump.armedLanding;
#ifdef SR1_LOCAL_REPEAT_ON_LANDING_SECTION
        if (didLaunch) repeatJump.syntheticHold = 0;
#endif
        record("defiance-repeat-contact realm=%u launch=%u elapsed=%llu source=%s section=%d", frame.realm,
            (unsigned)didLaunch, (unsigned long long)(GetTickCount64() - now),
            earlySource ? earlySource : "landing", section);
        return result;
    }
    if (kind) {
        for (unsigned i = 0; i < 3; ++i) {
            uintptr_t current;
            if (localSectionState(state, i, &current, false) && current == expected) {
                originalLocalRepeat[1](state, (int32_t)i, data);
            }
        }
    }
    repeatJump.dispatching = false;
#endif
    return result;
}

static uintptr_t observeLocalRepeat(unsigned kind, uintptr_t state, int32_t section, uintptr_t data) {
    const uintptr_t result = originalLocalRepeat[kind](state, section, data);
    return advanceLocalRepeat(kind, state, section, data, result, NULL);
}

#ifdef SR1_LOCAL_REPEAT_ON_PAD
static void localRepeatFromPad(const Sr1LocalFrame *frame) {
    if (frame->airState != SR1_AIR_LAND || !repeatJump.repeatPending || !frame->renderBlend ||
        host->stateActorRva + 0x10 != host->callbackRva || host->sectionStride != 0x228) return;
    advanceLocalRepeat(0, base + host->stateActorRva, 2, 0, 0, "input");
}
#endif

#ifdef SR1_LOCAL_SURFACE_TRACE
static HostGroundFn originalLocalSurface;
static _Thread_local uint64_t reportedSurfaceFlight;
static const Sheet_hostGroundObserver *const surfacePolicy = &sheet_hostGroundObserver_completed_query;

static uint32_t localJumpSurface(uintptr_t actor, int16_t *payload, uint16_t flags) {
    const uintptr_t caller = (uintptr_t)__builtin_return_address(0);
    const DWORD originalError = GetLastError();
    uint32_t before;
    const bool candidate = actor == player && flags == surfacePolicy->queryFlags &&
        caller == base + surfacePolicy->callerReturnRva &&
        readAt(base + surfacePolicy->controlRva, &before, sizeof(before)) &&
        (before & 0x04000008u) == 8;
    SetLastError(originalError);
    const uint32_t result = hostGroundForward(originalLocalSurface, actor, payload, flags);
    const DWORD error = GetLastError();
    uint32_t after;
    if (candidate && (result & 1) && readAt(base + surfacePolicy->controlRva, &after, sizeof(after)) &&
        (after & 0x04000008u) == 8) {
        const uint64_t now = GetTickCount64();
#ifdef SR1_LOCAL_COMBAT48
        const Sr1LocalFrame support=readLocalFrame(false);
        if(support.ready)localPublishGroundSupport48(&support,actor,now);
#endif
        const LocalJumpReceipt flight = readLocalJump();
#ifdef SR1_LOCAL_AIR_SLAM
        const Sr1LocalFrame surface = readFrame();
        if (surface.ready && surface.renderBlend && surface.verticalVelocity <= 0 &&
            (surface.airState == SR1_AIR_FALL || surface.airState == SR1_AIR_LAND)) {
            confirmLocalSlamImpact(&surface, actor, now);
        }
#endif
        if (flight.owner.tick && reportedSurfaceFlight != flight.owner.tick) {
            const Sr1LocalFrame frame = readFrame();
            if (frame.ready && (frame.airState == SR1_AIR_FALL || frame.airState == SR1_AIR_LAND) &&
                frame.verticalVelocity <= 0 && sameLocalAction(&flight.owner, &frame, actor, now, airPolicy->maxFlightMs)) {
                reportedSurfaceFlight = flight.owner.tick;
                record("defiance-jump-support realm=%u flight=%llu stage=%u vz=%ld forward=%ld",
                    frame.realm, (unsigned long long)flight.owner.tick, frame.airState,
                    (long)frame.verticalVelocity, (long)flight.forward);
            }
        }
    }
    SetLastError(error);
    return result;
}

static bool prepareLocalSurface(void) {
    return verifyDrawBlock(surfacePolicy->targetRva, surfacePolicy->targetBytes, LOCAL_SURFACE_SHA) &&
        MH_CreateHook((void *)(base + surfacePolicy->targetRva), (void *)localJumpSurface,
            (void **)&originalLocalSurface) == MH_OK;
}
#endif

#ifdef SR1_LOCAL_REPEAT_ON_FALL_EXIT
static uintptr_t localRepeatFall(uintptr_t state, int32_t section, uintptr_t data) {
    const uintptr_t result = originalLocalRepeatFall(state, section, data);
    if (section != 2) return result;
    return advanceLocalRepeat(0, state, section, data, result, "fall-exit");
}
#endif

static uintptr_t localRepeatLanding(uintptr_t state, int32_t section, uintptr_t data) {
#ifdef SR1_LOCAL_JUMP_EDGE
    const uintptr_t returnRva = (uintptr_t)__builtin_return_address(0) - base;
    if (returnRva == (uintptr_t)repeatPolicy->sectionInitReturnRva ||
        returnRva == (uintptr_t)repeatPolicy->characterInitReturnRva) {
        return originalLocalRepeat[0](state, section, data);
    }
#endif
    return observeLocalRepeat(0, state, section, data);
}

static uintptr_t localRepeatCompression(uintptr_t state, int32_t section, uintptr_t data) {
    return observeLocalRepeat(1, state, section, data);
}

static bool prepareLocalRepeat(void) {
    for (unsigned i = 0; i < ARRAYSIZE(repeatJumpAdvanceProofs); ++i) {
        if (!verifyDrawBlock(repeatJumpAdvanceProofs[i].rva, repeatJumpAdvanceProofs[i].size,
                             repeatJumpAdvanceProofs[i].sha256)) return false;
    }
#ifdef SR1_LOCAL_IMMEDIATE_REPEAT
    // Native early input enters Compression through the same proven stock ground callbacks.
    const uintptr_t entryRvas[] = {responsePolicy->idleRva, responsePolicy->moveRva, responsePolicy->startMoveRva};
    for (unsigned i = 0; i < ARRAYSIZE(entryRvas); ++i) {
        bool matched = false;
        for (unsigned j = 0; j < ARRAYSIZE(instantRootProofs); ++j) {
            if (entryRvas[i] != instantRootProofs[j].rva) continue;
            matched = verifyDrawBlock(entryRvas[i], instantRootProofs[j].size, instantRootProofs[j].sha256);
            break;
        }
        if (!matched) return false;
    }
#endif
#if defined(SR1_LOCAL_REPEAT_ON_FALL_EXIT) || defined(SR1_LOCAL_JUMP_EDGE)
    for (unsigned i = 0; i < ARRAYSIZE(localLandingEntryProofs); ++i) {
        if (!verifyDrawBlock(localLandingEntryProofs[i].rva, localLandingEntryProofs[i].size,
            localLandingEntryProofs[i].sha256)) return false;
    }
#endif
#ifdef SR1_LOCAL_JUMP_EDGE
    if (!repeatPolicy->oneJumpPerPress || !verifyDrawBlock(0x10ffc0, 163,
        "63eb4bed3b211f66b7a81f4e0ff1d3705e7883fcfcc1ab6362bcc3bffb576202")) return false;
#endif
    const uintptr_t rvas[] = {groundPolicy->landRva, groundPolicy->compressRva,
#ifdef SR1_LOCAL_REPEAT_ON_FALL_EXIT
        groundPolicy->fallRva,
#endif
    };
    void *const hooks[] = {(void *)localRepeatLanding, (void *)localRepeatCompression,
#ifdef SR1_LOCAL_REPEAT_ON_FALL_EXIT
        (void *)localRepeatFall,
#endif
    };
    LocalRepeatFn *const originals[] = {&originalLocalRepeat[0], &originalLocalRepeat[1],
#ifdef SR1_LOCAL_REPEAT_ON_FALL_EXIT
        &originalLocalRepeatFall,
#endif
    };
    for (unsigned i = 0; i < ARRAYSIZE(hooks); ++i) {
        if (MH_CreateHook((void *)(base + rvas[i]), hooks[i], (void **)originals[i]) != MH_OK) {
            for (unsigned j = 0; j < i; ++j) MH_RemoveHook((void *)(base + rvas[j]));
            return false;
        }
    }
    return true;
}
