// SPDX-License-Identifier: GPL-3.0-or-later
#pragma once
// Installed Fall handler and per-section switch that initializes Landing.
static const struct {uintptr_t rva; unsigned size; const char *sha256;} localLandingEntryProofs[] = {
    {0xef480,897,"d2143b8afa849f2e197f508cf728f1ac8121cb06231a144e6bdcfc7c1abd020d"},
    {0x1100f0,158,"f772c7eb6ec0515e78785beba3bb29f6571c64604196a01461798f9a7f926061"}
};
