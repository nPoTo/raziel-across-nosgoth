// SPDX-License-Identifier: GPL-3.0-or-later
#pragma once

#include "local-native-combo-time.h"

typedef int32_t (*NativeSectionAdvance)(uintptr_t, int16_t);
static NativeSectionAdvance originalNativeSectionAdvance;
static const Sheet_sr1CombatNativeClock *const nativeClock = &sheet_sr1CombatNativeClock_section_advance;

static int32_t advanceNativeGroundSection(uintptr_t section, int16_t interval) {
    const uintptr_t caller = (uintptr_t)__builtin_return_address(0);
    if (caller != base + (uintptr_t)nativeClock->callerReturnRva ||
        !player || section != player + (uintptr_t)nativeClock->sectionOffset) {
        return originalNativeSectionAdvance(section, interval);
    }
    const DWORD error = GetLastError();
    const Sr1LocalFrame frame = readFrame();
    if (frame.ready && frame.groundStrike && frame.airState == SR1_AIR_NONE &&
        frame.realm != SR1_LOCAL_UNKNOWN && section == player + (uintptr_t)nativeClock->sectionOffset &&
        nativeGroundLinkKnown(frame.strikeOrdinal, frame.strikeEnd)) {
        static _Thread_local uintptr_t loggedDescriptor;
        const int16_t adjusted = nativeGroundLinkInterval(frame.strikeOrdinal, interval);
        if (adjusted != interval && loggedDescriptor != frame.strikeIdentity) {
            loggedDescriptor = frame.strikeIdentity;
            record("defiance-ground-timing realm=%u ordinal=%u interval=%d->%d",
                frame.realm, frame.strikeOrdinal, (int)interval, (int)adjusted);
        }
        interval = adjusted;
    }
    SetLastError(error);
    return originalNativeSectionAdvance(section, interval);
}
