// SPDX-License-Identifier: GPL-3.0-or-later
#pragma once

#include "sr1-jump-exit-blend.h"

static const Sheet_sr1GroundTransition *const groundPolicy = &sheet_sr1GroundTransition_defiance_ground_blend;
#ifdef SR1_LOCAL_COMBAT_PRESENTATION
static const Sheet_sr1LocalCombatPresentation *const strikePresentation =
    &sheet_sr1LocalCombatPresentation_smooth_strike_and_hide_native_blade;
#endif
#ifdef SR1_LOCAL_COMBAT_TIMING
#include "local-combat-timing.h"
#endif
#ifdef SR1_DEFIANCE_GROUND_AUTHORED
static const Sheet_sr1GroundAuthored *const authoredPolicy = &sheet_sr1GroundAuthored_authored_locomotion;
#endif
#ifdef SR1_DEFIANCE_GROUND_RESPONSIVE
static const Sheet_sr1GroundResponsiveness *const responsePolicy = &sheet_sr1GroundResponsiveness_immediate_ground;
#endif
#ifdef SR1_LOCAL_DEFIANCE_JUMP
#include "local-air-timing.h"
#endif
typedef enum { GROUND_NATIVE, GROUND_IDLE, GROUND_RUN, GROUND_JUMP, GROUND_FALL, GROUND_LAND, GROUND_STRIKE } GroundPhase;
typedef struct {
    GroundPhase phase;
    bool active;
#ifdef SR1_LOCAL_COMBAT_PRESENTATION
    bool restartStrike, holdStrikePose;
#ifdef SR1_LOCAL_COMBAT_RHYTHM
    bool repeatGroundCombo;
#endif
#endif
#ifdef SR1_LOCAL_COMBO_FLOW
    bool airStrikeLanding;
#endif
#ifdef SR1_DEFIANCE_GROUND_RESPONSIVE
    bool strongEntry;
#endif
    uint64_t start, lastTick, duration;
    JumpLocal from[66], shown[66];
} GroundTransition;

static inline void groundBlendRotation(const float a[4], const float b[4], float alpha, float out[4]) {
    float dot = 0, norm = 0;
    for (unsigned k = 0; k < 4; ++k) dot += a[k] * b[k];
    const float direction = dot < 0 ? -1.f : 1.f;
    for (unsigned k = 0; k < 4; ++k) {
        out[k] = (1 - alpha) * a[k] + alpha * direction * b[k];
        norm += out[k] * out[k];
    }
    const float magnitude = sqrtf(norm);
    for (unsigned k = 0; k < 4; ++k) out[k] /= magnitude;
}

static inline void groundBlendLocal(const JumpLocal *from, const JumpLocal *to, float alpha, JumpLocal *out) {
    groundBlendRotation(from->q, to->q, alpha, out->q);
    jumpEdge(from->p, to->p, alpha, out->p);
}

static inline void groundComposeBone(const float parent[13], const float rotation[9],
                                    const float position[3], float out[13]) {
    for (unsigned row = 0; row < 3; ++row) {
        for (unsigned col = 0; col < 3; ++col) {
            out[3 * row + col] = 0;
            for (unsigned k = 0; k < 3; ++k) out[3 * row + col] += parent[3 * row + k] * rotation[3 * k + col];
        }
        out[10 + row] = parent[10 + row];
        for (unsigned k = 0; k < 3; ++k) out[10 + row] += parent[3 * row + k] * position[k];
    }
}

static inline void groundAttachWing(const float nativeAnchor[13], const float adaptedAnchor[13],
                                    const float wing[13], float out[13]) {
    float relativeRotation[9] = {0};
    float relativePosition[3] = {0};
    for (unsigned row = 0; row < 3; ++row) {
        for (unsigned k = 0; k < 3; ++k) {
            for (unsigned col = 0; col < 3; ++col) {
                relativeRotation[3 * row + col] += nativeAnchor[3 * k + row] * wing[3 * k + col];
            }
            relativePosition[row] += nativeAnchor[3 * k + row] * (wing[10 + k] - nativeAnchor[10 + k]);
        }
    }
    groundComposeBone(adaptedAnchor, relativeRotation, relativePosition, out);
}

static inline bool groundTransitionDraw(GroundTransition *state, GroundPhase phase, uint64_t now,
    const int16_t parents[66], const float native[66][13], const JumpLocal donor[66], float out[66][13]) {
    const Sheet_sr1GroundTransition *p = groundPolicy;
    if (state->active && (now < state->lastTick || now - state->lastTick > (uint64_t)p->maxGapMs)) {
        state->active = false;
    }
    if (!state->active && phase == GROUND_NATIVE) return false;
    JumpLocal live[66] = {0};
    if (!jumpLocals(native, parents, live)) {
        state->active = false;
        return false;
    }
    bool restart = !state->active || phase != state->phase;
#ifdef SR1_LOCAL_COMBAT_PRESENTATION
    restart |= state->restartStrike;
    const bool holdStrikePose = state->active && state->holdStrikePose && !restart && phase != GROUND_NATIVE;
#endif
    if (restart) {
        memcpy(state->from, state->active ? state->shown : live, sizeof(state->from));
        state->start = now;
        state->duration = (uint64_t)p->durationMs;
#ifdef SR1_DEFIANCE_GROUND_AUTHORED
        if (state->active && state->phase != GROUND_NATIVE && phase != GROUND_NATIVE) {
            state->duration = (uint64_t)(phase == GROUND_RUN ? authoredPolicy->startupBlendMs : authoredPolicy->stopBlendMs);
#ifdef SR1_DEFIANCE_GROUND_RESPONSIVE
            if (phase == GROUND_RUN && state->strongEntry) state->duration = (uint64_t)responsePolicy->strongEntryMs;
#endif
        }
#endif
#ifdef SR1_LOCAL_DEFIANCE_JUMP
        if (state->active && phase != GROUND_NATIVE &&
            (phase >= GROUND_JUMP || state->phase >= GROUND_JUMP)) state->duration = (uint64_t)airPolicy->phaseBlendMs;
#ifdef SR1_LOCAL_COMBO_FLOW
        if (phase == GROUND_LAND && state->airStrikeLanding)
            state->duration = sheet_sr1LocalAirStrikeFlow_air_links.landingBlendMs;
#endif
#endif
#ifdef SR1_LOCAL_COMBAT_PRESENTATION
        if (phase == GROUND_STRIKE || (state->active && state->phase == GROUND_STRIKE)) {
#ifdef SR1_LOCAL_COMBAT_TIMING
            state->duration = phase == GROUND_STRIKE ? combatTiming->groundXEnterMs : combatTiming->groundXExitMs;
#ifdef SR1_LOCAL_X_TEMPO
            state->duration = groundXBlendMs(state->duration);
#ifdef SR1_LOCAL_COMBAT_RHYTHM
            if (phase == GROUND_STRIKE && state->repeatGroundCombo) state->duration = groundXTempo->repeatBlendMs;
#ifdef SR1_LOCAL_COMBAT_SYNC42
            if (phase == GROUND_STRIKE && state->repeatGroundCombo)
                state->duration=sheet_sr1CombatSync42_synchronized_combat.linkBlendMs;
#endif
#endif
#endif
#else
            state->duration = (uint64_t)strikePresentation->transitionMs;
#endif
        }
#endif
        state->phase = phase;
        state->active = true;
    }
    state->lastTick = now;
    const uint64_t elapsed = now - state->start;
    if (phase == GROUND_NATIVE && elapsed >= state->duration) {
        state->active = false;
        return false;
    }
    const float u = fminf(1.f, (float)elapsed / (float)state->duration);
    const float alpha = u * u * (3 - 2 * u);
    memcpy(out, native, 66 * sizeof(*out));
    for (unsigned i = 1; i < (unsigned)p->wingFirst; ++i) {
        JumpLocal target = phase == GROUND_NATIVE ? live[i] : donor[i];
#ifdef SR1_LOCAL_COMBAT_PRESENTATION
        if (holdStrikePose) target = state->shown[i];
#endif
        JumpLocal *shown = &state->shown[i];
        const bool neck = i >= (unsigned)p->neckFirst && i <= (unsigned)p->neckLast;
        const bool wrap = i > (unsigned)p->neckLast && i <= (unsigned)p->wrapLast;
        const bool nativePivot = neck || wrap
#ifndef SR1_DEFIANCE_GROUND_CALIBRATION
            || i == 1
#endif
            ;
        if (nativePivot) memcpy(target.p, live[i].p, sizeof(target.p));
        if (wrap) memcpy(target.q, live[i].q, sizeof(target.q));
        float weight = alpha;
#ifdef SR1_LOCAL_COMBAT_PRESENTATION
        if (holdStrikePose) weight = 1.f;
#endif
        groundBlendLocal(&state->from[i], &target, weight, shown);
#ifdef SR1_DEFIANCE_GROUND_CALIBRATION
        // Like v0.2, interpolate pelvis displacement linearly in parent space.
        if (i == 1) for (unsigned k = 0; k < 3; ++k) {
            const float start = state->from[i].p[k];
            shown->p[k] = start + weight * (target.p[k] - start);
        }
#endif
        if (nativePivot) memcpy(shown->p, live[i].p, sizeof(shown->p));
        if (wrap) memcpy(shown->q, live[i].q, sizeof(shown->q));
        float rotation[9];
        jumpMatrix(shown->q, rotation);
        groundComposeBone(out[parents[i]], rotation, shown->p, out[i]);
        if (!skeletonRigid(out[i])) {
            state->active = false;
            return false;
        }
    }
    for (unsigned i = (unsigned)p->wingFirst; i <= (unsigned)p->wingLast; ++i) {
        groundAttachWing(native[p->wingAnchor], out[p->wingAnchor], native[i], out[i]);
        if (!skeletonRigid(out[i])) {
            state->active = false;
            return false;
        }
    }
    return true;
}
