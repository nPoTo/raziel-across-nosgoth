// SPDX-License-Identifier: GPL-3.0-or-later
#pragma once
#include "local-hud45-quad.h"
static unsigned char *localHud45Bytes;
static uint32_t localHud45BankBytes,localHud45FrameBytes[9];
static _Thread_local ReaverGL localHud45GL;
static uint32_t localHud45U32(const unsigned char *p){uint32_t v;memcpy(&v,p,4);return v;}
#ifdef SR1_LOCAL_COMBAT54
#include "local-hud-lightning54.h"
#endif
static bool loadLocalHud45(HANDLE pipe,uint64_t deadline) {
 unsigned char *data=HeapAlloc(GetProcessHeap(),0,LOCAL_HUD45_BYTES);if(!data)return false;
 DWORD filled=0;while(filled<LOCAL_HUD45_BYTES&&GetTickCount64()<deadline){DWORD got=0,available=0;if(!PeekNamedPipe(pipe,NULL,0,NULL,&available,NULL))break;if(!available){Sleep(2);continue;}DWORD n=LOCAL_HUD45_BYTES-filled;if(!ReadFile(pipe,data+filled,available<n?available:n,&got,NULL)||!got)break;filled+=got;}
 char hash[65];bool valid=filled==LOCAL_HUD45_BYTES&&boundedSha256(data,filled,LOCAL_HUD45_BYTES,hash)&&!strcmp(hash,LOCAL_HUD45_HASH);
 if(valid){localHud45BankBytes=localHud45U32(data);size_t cursor=40+localHud45BankBytes;for(unsigned i=0;i<9;i++){localHud45FrameBytes[i]=localHud45U32(data+4+i*4);cursor+=localHud45FrameBytes[i];}valid=cursor==LOCAL_HUD45_BYTES;}
 if(!valid){HeapFree(GetProcessHeap(),0,data);return false;}
 localHud45Bytes=data;record("reaver-menu RAM-ready forms=9 original-textures=19");return true;
}
#ifdef SR1_LOCAL_COMBAT48
static void localHudCharge48(const unsigned char *packet,const unsigned char *bank,unsigned textures,const GLint viewport[4],unsigned selected){
 const LocalChargeView48 charge=localChargeRead48();if(!charge.charge||charge.charge>100)return;
 const unsigned animation=(unsigned)(GetTickCount64()*20/1000)%20;
 const unsigned id=selected==1?(animation?1472+animation:4737):1452+animation;
 unsigned char quad[80];memcpy(quad,packet+96,sizeof quad);memcpy(quad,&id,4);
 const float fraction=.0500000007f+(.649999976f-.0500000007f)*charge.charge/100.f;
 for(unsigned axis=0;axis<2;axis++){
  const float a=hudF32(quad+16+axis*4),b=hudF32(quad+24+axis*4),c=hudF32(quad+32+axis*4),d=hudF32(quad+40+axis*4);
  const float top=a+(b-a)*fraction,bottom=d+(c-d)*fraction;
  memcpy(quad+24+axis*4,&top,4);memcpy(quad+32+axis*4,&bottom,4);
 }
 memcpy(quad+56,&fraction,4);
 for(unsigned j=0;j<textures;j++)if(localHud45U32(bank+80+j*32)==id){hudDrawQuad(&localHud45GL,quad,j,viewport);return;}
}
#endif
static void localHud45Draw(void) {
 if(!localHud45Bytes)return;const Sr1LocalFrame frame=readFrame();
 const unsigned selected=localCurrentForm(frame.realm);if(!frame.ready||!frame.renderBlend||!selected)return;
 const LocalForms45 source=localFormsRead();if(source.world!=frame.worldGeneration||source.generation!=frame.playerGeneration)return;
 GLint framebuffer=0,viewport[4];glGetIntegerv(GL_DRAW_FRAMEBUFFER_BINDING,&framebuffer);if(framebuffer)return;glGetIntegerv(GL_VIEWPORT,viewport);
 const unsigned char *bank=localHud45Bytes+40;const unsigned count=localHud45U32(bank+12);if(count>HUD_MAX_TEXTURES)return;
 if(localHud45GL.context!=wglGetCurrentContext()){memset(&localHud45GL,0,sizeof(localHud45GL));if(!reaverGLInit(&localHud45GL))return;}
 for(unsigned i=0;i<count;i++){const unsigned char *r=bank+80+i*32;if(!localHud45GL.textures[i]&&!reaverGLTexture(&localHud45GL,i,localHud45U32(r+4),localHud45U32(r+8),bank+localHud45U32(r+12),true,false))return;}
 size_t offset=40+localHud45BankBytes;for(unsigned i=1;i<selected;i++)offset+=localHud45FrameBytes[i-1];
 const unsigned char *packet=localHud45Bytes+offset;const unsigned quads=localHud45U32(packet+12);if(quads>HUD_MAX_QUADS)return;
 for(unsigned i=0;i<quads;i++){
  const unsigned char *q=packet+96+i*80;const uint32_t id=localHud45U32(q);
#ifdef SR1_LOCAL_COMBAT48
  if(i==1)localHudCharge48(packet,bank,count,viewport,selected);
#endif
  if(id>=1423&&id<=1430&&!(source.mask&(1u<<(id-1422))))continue;
  for(unsigned j=0;j<count;j++)if(localHud45U32(bank+80+j*32)==id){hudDrawQuad(&localHud45GL,q,j,viewport);break;}
 }
#ifdef SR1_LOCAL_COMBAT54
 localHudLightning54(packet,viewport,selected);
#endif
}
