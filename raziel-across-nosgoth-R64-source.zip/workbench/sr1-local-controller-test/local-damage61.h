// SPDX-License-Identifier: GPL-3.0-or-later
#pragma once
// A native accepted/stunned response is not necessarily a health change.
// Keep the former for reaction authority, but never mint impact/charge from it.
static inline bool localDamageHealth61(int16_t before,int16_t after,int result){
#ifdef SR1_LOCAL_COMBAT60
 (void)result;
 return sheet_sr1Contact61_confirmed_damage.strictDamage && before>0 && after>=0 && after<before;
#else
 return airVictimDamageConfirmed(before,after,result);
#endif
}
