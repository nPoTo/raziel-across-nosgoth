// SPDX-License-Identifier: GPL-3.0-or-later
#pragma once
static SRWLOCK localSupportLock48=SRWLOCK_INIT;
static LocalActionOwner localSupportContact48;
static bool localGroundSupport48(const Sr1LocalFrame *frame,uintptr_t actor,uint64_t now){
 AcquireSRWLockShared(&localSupportLock48);const LocalActionOwner support=localSupportContact48;ReleaseSRWLockShared(&localSupportLock48);
 return sameLocalAction(&support,frame,actor,now,(uint64_t)sheet_sr1GroundTransition_defiance_ground_blend.maxGapMs);
}
static void localPublishGroundSupport48(const Sr1LocalFrame *frame,uintptr_t actor,uint64_t now){
 AcquireSRWLockExclusive(&localSupportLock48);localSupportContact48=localActionOwner(frame,actor,now);ReleaseSRWLockExclusive(&localSupportLock48);
}
