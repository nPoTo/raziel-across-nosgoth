// SPDX-License-Identifier: GPL-3.0-or-later
#pragma once
typedef struct{LocalActionOwner owner;uint32_t mask;int32_t x,y;}LocalDodgeQueue56;
static _Thread_local LocalDodgeQueue56 localDodgeQueue56;
static _Thread_local LocalDodgeQueue56 localDodgeRequest56;
static bool localDodgeUtilityBusy56(const Sr1LocalFrame*f,uintptr_t actor,uint64_t now){
 const LocalChargeView48 cast=localChargeRead48();
 return (cast.casting&&sameLocalAction(&cast.owner,f,actor,now,5000))||localFinishActive53(f,actor,now);
}
static void releaseStrikeMotion(void);
static void localCancelCombo57(void);
static void localDodgeCancelOthers56(void){
#ifdef SR1_LOCAL_COMBAT57
 localCancelCombo57();
#endif
 AcquireSRWLockExclusive(&localSpecialLock);localSpecial=(LocalSpecial){0};specialRecovery=(LocalSpecialRecovery){0};specialFollowup=(LocalActionOwner){0};specialFollowupMask=0;ReleaseSRWLockExclusive(&localSpecialLock);
 AcquireSRWLockExclusive(&localCombatInputLock);combatInput.lift=(LocalActionOwner){0};combatInput.liftJumpRequest=(LocalActionOwner){0};combatInput.liftHeldThrough=false;combatInput.guardSpeed=0;combatInput.guardDirectional=false;ReleaseSRWLockExclusive(&localCombatInputLock);
 localHold48=(C5XHold){0};localDodgeQueue56=(LocalDodgeQueue56){0};releaseStrikeMotion();
 record("defiance-action-cancel-others");
}
static bool localDodgeChargeBlocked56(const NativePad*p,const Sr1LocalFrame*f,uintptr_t actor,uint64_t now){
 if(localDodgeBusy56(f,actor,now)||localDodgeUtilityBusy56(f,actor,now))return true;
 uint32_t face=0;return canLocalDodge(f)&&readAt(base+sheet_sr1StandaloneBlade_standalone_default_blade.combatMaskRva,&face,4)&&
  ((p->held|p->pressed)&face)&&(p->pressed&0x80u);
}
static void localDodgeQueuePad56(NativePad*p,const NativePad*raw,const Sr1LocalFrame*f,uint32_t attack,uint32_t lift,uint64_t now){
 if(localDodgeBusy56(f,player,now)){
  const uint32_t edge=raw->pressed&(attack|lift);
  if(edge){localDodgeQueue56=(LocalDodgeQueue56){.owner=localActionOwner(f,player,now),.mask=(edge&attack)?attack:lift,.x=raw->x,.y=raw->y};record("defiance-dodge-attack-queued mask=%x",localDodgeQueue56.mask);}
  const uint32_t mask=attack|lift|0x80u;p->held&=~mask;p->pressed&=~mask;p->released&=~mask;p->x=p->y=0;return;
 }
 const LocalDodgeQueue56 queued=localDodgeQueue56;if(!queued.owner.tick)return;localDodgeQueue56=(LocalDodgeQueue56){0};
 if(canLocalDodge(f)&&sameLocalAction(&queued.owner,f,player,now,(uint64_t)sheet_sr1Combat56_action_facing_relift.dodgeQueueMs)){
  p->held|=queued.mask;p->pressed|=queued.mask;p->released&=~queued.mask;
  if(!p->x&&!p->y){p->x=queued.x;p->y=queued.y;}record("defiance-dodge-attack-release mask=%x",queued.mask);
 }
}
static bool localDodgeDeferred56(NativePad*p,const NativePad*raw,const Sr1LocalFrame*f,bool held,uint32_t kind,bool available,uint64_t now){
 if(localDodgeBusy56(f,player,now)){localDodgeRequest56=(LocalDodgeQueue56){0};return false;}
 if(held&&kind==0x1000&&f->airState==SR1_AIR_NONE){
  if((raw->pressed&0x80u)&&!dodgeJumpClaimed){
   if(!localDodgeUtilityBusy56(f,player,now)){localDodgeRequest56=(LocalDodgeQueue56){.owner=localActionOwner(f,player,now),.x=raw->x,.y=raw->y};record("defiance-dodge-request-queued");}
   dodgeJumpClaimed=true;
  }
  p->held&=~0x80u;p->pressed&=~0x80u;p->released&=~0x80u; // Ground LB+A never becomes a native jump when an attack is busy.
 }
 if(localDodgeRequest56.owner.tick){
  const LocalDodgeQueue56 request=localDodgeRequest56;
  if(!sameLocalAction(&request.owner,f,player,now,(uint64_t)sheet_sr1Combat56_action_facing_relift.dodgeAdmissionMs))localDodgeRequest56=(LocalDodgeQueue56){0};
  else if(available){localDodgeRequest56=(LocalDodgeQueue56){0};startLocalDodge(f,player,now,request.x,request.y);return true;}
 }
 return false;
}
