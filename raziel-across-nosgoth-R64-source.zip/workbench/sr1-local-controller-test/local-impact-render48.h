// SPDX-License-Identifier: GPL-3.0-or-later
// Rendering functions and masks adapted from released0.2 reaver-impact-render.h.
#pragma once
#include "../../output/github-v0.2-staging/source/workbench/c4-linked-finisher-r5/build/linked/c2-slam-policy.h"
typedef struct {int64_t durationMs;const wchar_t *id;int64_t radius,rayGainPermille;} LocalImpactPolicy48;
static _Thread_local ReaverGL c2ImpactGl;

static void c2ImpactClear(void) {
    AcquireSRWLockExclusive(&localImpactLock48);memset(localImpacts48,0,sizeof(localImpacts48));ReleaseSRWLockExclusive(&localImpactLock48);
    if (c2ImpactGl.context) reaverGLDestroy(&c2ImpactGl);
}

static bool c2ImpactUpload(unsigned slot,float (*mask)(float,float)) {
    enum {side=64};
    unsigned char pixels[side][side][4];
    for (unsigned y=0;y<side;++y) for (unsigned x=0;x<side;++x) {
        unsigned char *texel=pixels[y][x];
        texel[0]=texel[1]=texel[2]=255;
        texel[3]=(unsigned char)(255.0f*mask(2.0f*x/(side-1)-1,2.0f*y/(side-1)-1));
    }
    return reaverGLTexture(&c2ImpactGl,slot,side,side,&pixels[0][0][0],true,false);
}

static bool c2ImpactInit(void) {
    static const unsigned char white[]={255,255,255,255};
    if (c2ImpactGl.context) return c2ImpactGl.context==wglGetCurrentContext();
    if (!reaverGLInit(&c2ImpactGl)) return false;
    if (c2ImpactUpload(1,c2ImpactCoreAlpha) &&
        c2ImpactUpload(2,c2ImpactStarAlpha) && c2ImpactUpload(3,c2ImpactRayAlpha) &&
        reaverGLTexture(&c2ImpactGl,4,1,1,white,false,false)) return true;
    reaverGLDestroy(&c2ImpactGl);
    return false;
}

static void c2ImpactQuad(ReaverGLVertex *vertices,uint16_t *indices,unsigned quad,
    const float center[3],const float right[3],const float up[3],float x,float y,
    float halfWidth,float halfHeight,const float color[4]) {
    const uint16_t base=(uint16_t)(quad*4);
    for (unsigned i=0;i<4;++i) {
        ReaverGLVertex *v=&vertices[base+i];
        v->uv[0]=(float)(i&1);
        v->uv[1]=(float)(i>>1);
        for (unsigned k=0;k<3;++k)
            v->position[k]=center[k]+(x+(v->uv[0]*2-1)*halfWidth)*right[k]+
                (y+(v->uv[1]*2-1)*halfHeight)*up[k];
        memcpy(v->rgba,color,sizeof(v->rgba));
    }
    const uint16_t order[]={base,base+1,base+2,base+3,base+2,base+1};
    memcpy(indices+quad*6,order,sizeof(order));
}


static void localDrawImpacts48(uintptr_t actor,const float palm[16],const float mvp[16],bool bladeDrawn){
 const Sr1LocalFrame frame=readFrame();const uint64_t now=GetTickCount64();
 if(!frame.ready||!frame.renderBlend||actor!=player)return;
 C2Impact c2Impacts[16]={0};AcquireSRWLockShared(&localImpactLock48);
 for(unsigned i=0;i<16;i++)if(localImpacts48[i].realm==frame.realm){c2Impacts[i]=localImpacts48[i].hit;
#ifdef SR1_LOCAL_COMBAT52
  if(localImpacts48[i].target&&!localTargetPoint52(localImpacts48[i].target,localImpacts48[i].targetGeneration,frame.worldGeneration,c2Impacts[i].point))c2Impacts[i].epoch=0;
#endif
 }
 ReleaseSRWLockShared(&localImpactLock48);
 const LocalImpactPolicy48 policyValue={300,L"released_02",205,1100};
    enum {sparks=8,raysPerHit=12};
    ReaverGLVertex stars[ARRAYSIZE(c2Impacts)*sparks*4];
    uint16_t starIndices[ARRAYSIZE(c2Impacts)*sparks*6];
    ReaverGLVertex rays[ARRAYSIZE(c2Impacts)*raysPerHit*4];
    uint16_t rayIndices[ARRAYSIZE(c2Impacts)*raysPerHit*6];
    C2Impact *queued[ARRAYSIZE(c2Impacts)];
    float projected[ARRAYSIZE(c2Impacts)][4];
    unsigned count=0,starCount=0,rayCount=0;
    const LocalImpactPolicy48 *policy=&policyValue;
    for (unsigned i=0;i<ARRAYSIZE(c2Impacts);++i) {
        C2Impact *impact=&c2Impacts[i];
        if (!c2ImpactCurrent(impact,now,frame.session,frame.playerGeneration,(int32_t)frame.worldGeneration,(unsigned)policy->durationMs)) continue;
        const float life=(float)(now-impact->tick)/(float)policy->durationMs;
        const float fade=1.0f-life;
        if (!bladeDrawn) continue;
        const int baseRadius=impact->slam?
#ifdef SR1_LOCAL_COMBAT49
            sheet_sr1Combat49_combat_physics.groundSparkRadius:
#else
            AIR_SLAM_IMPACT_RADIUS:
#endif
            impact->landing?C2_SLAM_STAR_RADIUS:policy->radius;
        const float radius=(float)baseRadius*(0.72f+0.50f*life);
        float center[3],color[4],right[3],up[3],clip[4];
        c2ImpactLocal(impact->point,palm,center);
        if (!c2ImpactBillboard(mvp,0,center,right,up)) continue;
        c2ImpactClip(mvp,center,clip);
        if (!c2ImpactInFrustum(clip)) continue;
        queued[count]=impact;
        memcpy(projected[count],clip,sizeof(clip));
        c2ImpactColor(impact->color,fade,color);
        const float gain=(float)policy->rayGainPermille/1000.0f*
            (impact->slam?
#ifdef SR1_LOCAL_COMBAT49
                sheet_sr1Combat49_combat_physics.groundSparkGain/1000.0f:
#else
                AIR_SLAM_IMPACT_GAIN_PERMILLE/1000.0f:
#endif
                1.0f);
        const float rayColor[4]={gain*(0.14f+0.86f*color[0]),gain*(0.14f+0.86f*color[1]),
            gain*(0.14f+0.86f*color[2]),fade*(0.57f+0.26f*fade)};
        if (impact->landing) {
            for (unsigned j=0;j<sparks;++j) {
                const float angle=(j+0.32f*(j%3))*6.28318530718f/sparks;
                const float distance=radius*(0.24f+life*(0.74f+0.19f*(j%3)));
                const float dx=distance*cosf(angle),dy=distance*sinf(angle);
                const float dz=C2_SLAM_HEIGHT_ABOVE_FLOOR+radius*life*fade*(0.45f+0.24f*(j%3));
                const float size=radius*(0.095f-0.03f*life);
                float spark[3];
                for (unsigned axis=0;axis<3;++axis)
                    spark[axis]=center[axis]+palm[axis*4]*dx+palm[axis*4+1]*dy+palm[axis*4+2]*dz;
                c2ImpactQuad(stars,starIndices,starCount++,spark,right,up,0,0,size,size,rayColor);
            }
            ++count;
            continue;
        }
        const float awayLength=hypotf(hypotf(mvp[3],mvp[7]),mvp[11]);
        const float toward[3]={-mvp[3]/awayLength,-mvp[7]/awayLength,-mvp[11]/awayLength};
        for (unsigned j=0;j<raysPerHit;++j) {
            const float angle=(j+0.21f*(j%3)+(float)(impact->marker%11)/11)*6.28318530718f/raysPerHit;
            const float c=cosf(angle),s=sinf(angle);
            float along[3],across[3];
            const float depth=0.42f+0.12f*(j%4);
            const float lateral=sqrtf(1-depth*depth);
            for (unsigned k=0;k<3;++k) {
                along[k]=lateral*(c*right[k]+s*up[k])+depth*toward[k];
                across[k]=c*up[k]-s*right[k];
            }
            const float half=radius*(0.44f+0.065f*(j%5));
            c2ImpactQuad(rays,rayIndices,rayCount++,center,along,across,half,0,half,
                radius*(0.043f+0.006f*(j%3)),rayColor);
        }
        ++count;
        const float star[4]={rayColor[0],rayColor[1],rayColor[2],fade*0.62f};
        float sparkPlane[3];
        for (unsigned k=0;k<3;++k) sparkPlane[k]=center[k]+toward[k]*(float)impact->targetRadius*0.80f;
        for (unsigned j=0;j<sparks;++j) {
            const float angle=(j+(float)(impact->marker%7)/7.0f)*6.28318530718f/sparks;
            const float distance=radius*(0.28f+life*(0.7f+(float)(j%3)*0.12f));
            const float size=radius*(0.095f-0.03f*life);
            c2ImpactQuad(stars,starIndices,starCount++,sparkPlane,right,up,distance*cosf(angle),distance*sinf(angle),
                size,size,star);
        }
    }
    if (!count || !c2ImpactInit() ||
        (rayCount && !reaverGLDraw(&c2ImpactGl,rays,rayCount*4,rayIndices,rayCount*6,3,2,mvp,0,-1)) ||
        !reaverGLDraw(&c2ImpactGl,stars,starCount*4,starIndices,starCount*6,2,2,mvp,0,-1)) return;
#ifdef SR1_LOCAL_COMBAT50
    for(unsigned i=0;i<count;i++)localSlamSparkDrawn50(queued[i]);
#endif

 static _Thread_local uint64_t reported;
 if(count&&queued[count-1]->tick!=reported){reported=queued[count-1]->tick;record("defiance-impact-draw count=%u rays=%u stars=%u",count,rayCount,starCount);}
}
