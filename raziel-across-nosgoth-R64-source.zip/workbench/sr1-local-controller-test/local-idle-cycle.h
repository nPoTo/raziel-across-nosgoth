// SPDX-License-Identifier: GPL-3.0-or-later
#pragma once

typedef struct {
    unsigned bank, from;
    float sample, mix;
} LocalIdleSample;

static inline LocalIdleSample localIdleSample(uint64_t ms, bool stopping, const unsigned counts[],
    unsigned banks, unsigned idleBetweenMs, unsigned blendMs) {
    const double stopMs = counts[0] * (1000.0 / 60);
    double time = (double)ms;
    if (stopping && time < stopMs) return (LocalIdleSample){0, 0, (float)(time * .060), 1};
    if (stopping) time -= stopMs;
    double cycleMs = 0;
    for (unsigned bank = 2; bank < banks; ++bank) cycleMs += idleBetweenMs + counts[bank] * (1000.0 / 60);
    unsigned previous = time >= cycleMs ? banks - 1 : stopping ? 0 : 1;
    time = fmod(time, cycleMs);
    for (unsigned bank = 2; bank < banks; ++bank) {
        if (time < idleBetweenMs) {
            const float mix = previous == 1 ? 1 : fminf(1, (float)(time / blendMs));
            return (LocalIdleSample){1, previous, (float)fmod(time * .060, counts[1]), mix};
        }
        time -= idleBetweenMs;
        const double variantMs = counts[bank] * (1000.0 / 60);
        if (time < variantMs || bank + 1 == banks) {
            const float mix = fminf(1, (float)(time / blendMs));
            return (LocalIdleSample){bank, 1,
                (float)fmin(time * .060, counts[bank] - 1), mix};
        }
        time -= variantMs;
        previous = bank;
    }
    return (LocalIdleSample){1, 1, 0, 1};
}
