// SPDX-License-Identifier: GPL-3.0-or-later
#pragma once
#ifdef SR1_LOCAL_COMBAT59
#include "local-pickup59.h"
#endif
// Installed f3c40: native sensed bit8, slot+0x30 and Query23 grab-animation tune.
// A positive physical candidate retains SR1's complete pickup/carry lifetime.
static bool localPhysicalPickup48(const Sr1LocalFrame *frame,uintptr_t actor){
 uint32_t flags=0,world=0,objectFlags=0;uintptr_t slots=0,target=0,reaver=0,collision=0,parent=0;
 if(!readAt(base+host->interactionFlagsRva,&flags,4))return true;
 if(!(flags&8u))return false;
 if(!readAt(base+host->targetsRva,&slots,8)||!slots||!readAt(slots+0x30,&target,8))return true;
 if(!target||target==actor)return false;
 if(!readAt(base+host->reaverRva,&reaver,8))return true;if(target==reaver)return false;
 if(!readAt(target+0x60,&world,4)||world!=frame->worldGeneration||!generation(target)||
  !readAt(target+0x28,&objectFlags,4)||(objectFlags&0x24040000u)||!readAt(target+host->parentOffset,&parent,8)||
#ifdef SR1_LOCAL_COMBAT59
  (parent&&!localMorlockPickup59(target,parent,actor,frame->worldGeneration))||
#else
  parent||
#endif
  !readAt(target+0x1a0,&collision,8)||collision==base+(uintptr_t)sheet_sr1LocalAirContact_standalone_contact.monsterCollisionRva)return false;
 typedef uintptr_t (*LocalPickupQuery48)(uintptr_t,uint32_t);
#ifdef SR1_LOCAL_COMBAT49
 if(((LocalPickupQuery48)(base+signals->queryRva))(target,1)&10u)return false;
#endif
#ifdef SR1_LOCAL_COMBAT59
 if(localZephonEggPickup59(target,frame->worldGeneration))return true;
#endif
 const uintptr_t tune=((LocalPickupQuery48)(base+signals->queryRva))(target,23);
 unsigned char animations[4];
 if(!tune||!readAt(tune+0x14,animations,4))return false;
 return animations[0]!=255||animations[1]!=255||animations[2]!=255||animations[3]!=255;
}
