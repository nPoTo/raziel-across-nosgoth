// SPDX-License-Identifier: GPL-3.0-or-later
#pragma once
#ifdef SR1_LOCAL_COMBAT56
#include "local-input56.h"
#endif

#ifdef SR1_LOCAL_SPECIAL_INPUT
#include "local-special-input.h"
#include "local-combat-edges.h"
#endif

#ifdef SR1_LOCAL_TEMPEST_FLIGHT
#include "local-tempest-flight.h"
#endif

typedef enum { LOCAL_SPECIAL_NONE, LOCAL_SPECIAL_PERFORATE, LOCAL_SPECIAL_TEMPEST,
    LOCAL_SPECIAL_SHATTER, LOCAL_SPECIAL_EMPYREAL } LocalSpecialMove;

typedef struct {
    LocalActionOwner owner;
    LocalSpecialMove move;
    unsigned bank, first, last, queued, previous;
#ifdef SR1_LOCAL_SPECIAL_INPUT
    unsigned bearing;
    bool directional;
#endif
#ifdef SR1_LOCAL_COMBAT_LINKS
    unsigned spins;
#ifdef SR1_LOCAL_COMBAT48
    unsigned fixedYaw;bool fixedFacing;
#endif
#endif
#ifdef SR1_LOCAL_COMBAT_REPAIR
    uint64_t spinStarted;
#endif
#ifdef SR1_LOCAL_TEMPEST_FLIGHT
    uint64_t flight;
#endif
} LocalSpecial;

static SRWLOCK localSpecialLock=SRWLOCK_INIT;
static LocalSpecial localSpecial;
#ifdef SR1_LOCAL_COMBAT_SYNC42
static LocalActionOwner rotorFlightSpent;
#endif
#ifdef SR1_LOCAL_SPECIAL_RECOVERY
typedef struct { LocalSpecial move; uint64_t released; } LocalSpecialRecovery;
static LocalSpecialRecovery specialRecovery;
static LocalActionOwner specialFollowup;
static uint32_t specialFollowupMask;

static LocalSpecialRecovery readSpecialRecovery(const Sr1LocalFrame *frame,uintptr_t actor,uint64_t now) {
    AcquireSRWLockShared(&localSpecialLock);
    const LocalSpecialRecovery recovery=specialRecovery;
    ReleaseSRWLockShared(&localSpecialLock);
    const uint64_t duration=sheet_sr1CombatSpecialRecovery_special_recovery.recoveryMs;
    if (!frame->ready || !frame->renderBlend || frame->airState!=SR1_AIR_NONE ||
        (!frame->groundStrike && (frame->nativeControl || !frame->grounded)) ||
        !recovery.released || now<recovery.released || now-recovery.released>=duration ||
        !sameLocalAction(&recovery.move.owner,frame,actor,now,UINT64_MAX)) return (LocalSpecialRecovery){0};
    return recovery;
}
#endif
static const Sheet_sr1LocalStasis *const localStasisPolicy=&sheet_sr1LocalStasis_standalone_stasis;
static _Thread_local LocalActionOwner localStasisPress;
#ifdef SR1_LOCAL_COMBAT53
#include "local-utility-policy53.h"
#endif

static uint64_t localSpecialDuration(unsigned bank) {
#ifdef SR1_LOCAL_COMBAT_SYNC42
    if (bank>=8 && bank<=10) return combatRotorDuration(bank);
#endif
    return (uint64_t)sheet_sr1LocalSpecialBanks_rows[bank]->durationMs;
}

static uint64_t localSpecialFlightLimit(void) {
#ifdef SR1_LOCAL_COMBAT_SYNC42
    return (uint64_t)airPolicy->maxFlightMs+combatRotorDuration(8)+combatRotorDuration(9)+combatRotorDuration(10);
#else
    return (uint64_t)airPolicy->maxFlightMs
#ifdef SR1_LOCAL_COMBAT_LINKS
        +(uint64_t)combatLinks->maxTempestSpins*localSpecialDuration(9)
#endif
        ;
#endif
}

static bool localSpecialAir(LocalSpecialMove move) {
    return move==LOCAL_SPECIAL_TEMPEST || move==LOCAL_SPECIAL_EMPYREAL;
}

static bool localSpecialPhase(LocalSpecialMove move,const Sr1LocalFrame *frame) {
    if (localSpecialAir(move)) return localSlamAirborne(frame) ||
        (move==LOCAL_SPECIAL_EMPYREAL && frame->ready && frame->renderBlend && frame->airState==SR1_AIR_LAND);
    return frame->ready && frame->renderBlend && frame->grounded && !frame->nativeControl;
}

static bool localSpecialEnding(const LocalSpecial *move) {
    return move->bank==move->last
#ifdef SR1_LOCAL_TEMPEST_FLIGHT
#ifndef SR1_LOCAL_COMBAT_SYNC42
        || (move->move==LOCAL_SPECIAL_TEMPEST && move->bank==move->first && !move->queued)
#endif
#endif
        ;
}

static LocalSpecial localReadSpecial(const Sr1LocalFrame *frame,uintptr_t actor,uint64_t now) {
    AcquireSRWLockShared(&localSpecialLock);
    const LocalSpecial move=localSpecial;
    ReleaseSRWLockShared(&localSpecialLock);
    if (!move.move || !localSpecialPhase(move.move,frame)) return (LocalSpecial){0};
    uint64_t ageLimit=localSpecialDuration(move.bank);
#ifdef SR1_LOCAL_TEMPEST_FLIGHT
    if (move.move==LOCAL_SPECIAL_TEMPEST) {
        const LocalJumpReceipt jump=readLocalJump();
        if (move.flight!=jump.owner.tick || !sameLocalAction(&jump.owner,frame,actor,now,localSpecialFlightLimit()))
            return (LocalSpecial){0};
        // Keep the last sample visible across the handoff to a committed follow-up.
        if (!localSpecialEnding(&move)) ageLimit+=(uint64_t)groundPolicy->maxGapMs;
    }
#endif
#ifdef SR1_LOCAL_COMBAT_FACING
    if (move.move!=LOCAL_SPECIAL_TEMPEST && (!localSpecialEnding(&move)
#ifdef SR1_LOCAL_SPECIAL_RECOVERY
        || move.move==LOCAL_SPECIAL_PERFORATE
#endif
    ))
        ageLimit+=(uint64_t)groundPolicy->maxGapMs;
#endif
    if (!sameLocalAction(&move.owner,frame,actor,now,ageLimit)) return (LocalSpecial){0};
    return move;
}

#ifdef SR1_LOCAL_COMBAT48
static bool localRotorYaw48(const Sr1LocalFrame *frame,uintptr_t actor,uint64_t now,unsigned *yaw) {
    if(!TryAcquireSRWLockShared(&localSpecialLock))return false;
    const LocalSpecial special=localSpecial;ReleaseSRWLockShared(&localSpecialLock);
    if(special.move!=LOCAL_SPECIAL_TEMPEST||!special.fixedFacing||!localSpecialPhase(special.move,frame)||
        !sameLocalAction(&special.owner,frame,actor,now,localSpecialDuration(special.bank)+groundPolicy->maxGapMs))return false;
    *yaw=special.fixedYaw;return true;
}
#endif
static unsigned localSpecialDirection(int32_t x,int32_t y) {
    const int64_t ax=x<0?-(int64_t)x:x,ay=y<0?-(int64_t)y:y;
    if (ax<=motion->moveThreshold && ay<=motion->moveThreshold) return 0;
    return ax>ay?(x>0?1u:2u):(y>0?3u:4u);
}

static void localSpecialPad(NativePad *output,const Sr1LocalFrame *frame,uint32_t attack,uint32_t lift,uint64_t now) {
    static _Thread_local uint64_t tap;
    static _Thread_local unsigned priorDirection;
    static _Thread_local LocalActionOwner directionOwner;
    const bool grounded=localSpecialPhase(LOCAL_SPECIAL_PERFORATE,frame);
    const bool airborne=localSlamAirborne(frame);
    const unsigned direction=localSpecialDirection(output->x,output->y);
    if (!sameLocalAction(&directionOwner,frame,player,now,UINT64_MAX) || (!grounded&&!airborne)) {
        directionOwner=localActionOwner(frame,player,now);
        priorDirection=direction;
        tap=0;
    }
    if (direction && direction!=priorDirection) tap=now;
    priorDirection=direction;
#ifdef SR1_LOCAL_SPECIAL_INPUT
    static _Thread_local bool attackHeld,liftHeld;
    const bool x=localCombatPress(&attackHeld,(output->held&attack)!=0,(output->pressed&attack)!=0);
    const bool y=localCombatPress(&liftHeld,(output->held&lift)!=0,(output->pressed&lift)!=0);
#else
    const bool x=(output->pressed&attack)!=0,y=(output->pressed&lift)!=0;
#endif
#ifdef SR1_LOCAL_COMBAT_FACING
    const bool tempestTap=airborne && x && tap && tap<=now && now-tap<=(uint64_t)combatFacing->airSpecialChordMs;
    const bool shortDirection=tempestTap || (direction && tap && tap<=now &&
        now-tap<=(uint64_t)
#ifdef SR1_LOCAL_COMBAT56
        localSpecialChordMs56(grounded,x,y,(uint64_t)localStasisPolicy->inputChordMs));
#else
        localStasisPolicy->inputChordMs);
#endif
#else
    const bool shortDirection=direction && tap && tap<=now && now-tap<=(uint64_t)localStasisPolicy->inputChordMs;
#endif
#ifdef SR1_LOCAL_TEMPEST_FLIGHT
    const LocalJumpReceipt jump=readLocalJump();
    const bool currentFlight=airborne && sameLocalAction(&jump.owner,frame,player,now,localSpecialFlightLimit());
    uint32_t jumpMask=0;
    const bool jumpEdge=grounded && readAt(base+signals->jumpMaskRva,&jumpMask,sizeof(jumpMask)) &&
        (output->pressed&jumpMask);
#endif
    LocalSpecialMove started=LOCAL_SPECIAL_NONE;
    unsigned stage=0;
#ifdef SR1_LOCAL_SPECIAL_INPUT
    uint32_t releasedPress=0;
#endif
    AcquireSRWLockExclusive(&localSpecialLock);
    LocalSpecial *move=&localSpecial;
    if (move->move && (!localSpecialPhase(move->move,frame) ||
        !sameLocalAction(&move->owner,frame,player,now,UINT64_MAX))) *move=(LocalSpecial){0};
#ifdef SR1_LOCAL_TEMPEST_FLIGHT
    if (move->move==LOCAL_SPECIAL_TEMPEST && (!currentFlight || move->flight!=jump.owner.tick ||
        now-move->owner.tick>localSpecialDuration(move->bank)+(uint64_t)groundPolicy->maxGapMs))
        *move=(LocalSpecial){0};
#endif
#ifdef SR1_LOCAL_COMBAT_FACING
    if (move->move && now-move->owner.tick>localSpecialDuration(move->bank)+(uint64_t)groundPolicy->maxGapMs)
        *move=(LocalSpecial){0};
#endif
#ifdef SR1_LOCAL_SPECIAL_INPUT
    const bool wasSpecial=move->move!=LOCAL_SPECIAL_NONE;
#endif
    if (move->move) {
#ifdef SR1_LOCAL_SPECIAL_INPUT
        unsigned bearing;
        uint32_t face=0;
        readAt(base+sheet_sr1StandaloneBlade_standalone_default_blade.combatMaskRva,&face,sizeof(face));
        if (move->move==LOCAL_SPECIAL_PERFORATE && move->directional &&
            readCombatBearing(output->x,output->y,&bearing) &&
            specialDirectionBreak(move->bearing,bearing,(output->held&face)!=0)) {
            // A change of direction starts one ordinary native X. Do not reinterpret this edge
            // as a new direction-chord special in this same input invocation.
            specialRecovery=(LocalSpecialRecovery){*move,now};
            specialFollowup=(LocalActionOwner){0};
            specialFollowupMask=0;
            *move=(LocalSpecial){0};
            releasedPress=attack;
            output->pressed=(output->pressed&~lift)|attack;
            output->held&=~lift;
            groundAim=localActionOwner(frame,player,now);
            groundAimYaw=bearing;
            record("standalone-perforate-break realm=%u bearing=%u",frame->realm,bearing);
        }
        if (move->move) {
#endif
#ifdef SR1_LOCAL_SPECIAL_RECOVERY
        if (move->move==LOCAL_SPECIAL_PERFORATE && move->bank==move->last && x!=y && (x||y)
#ifdef SR1_LOCAL_SPECIAL_INPUT
            && specialFreshFollowup(now-move->owner.tick,localSpecialDuration(move->bank))
#endif
        ) {
            specialFollowup=localActionOwner(frame,player,now);
            specialFollowupMask=x?attack:lift;
        }
#endif
        unsigned queueLimit=move->last-move->bank;
#ifdef SR1_LOCAL_COMBAT_SYNC42
        if (move->move==LOCAL_SPECIAL_TEMPEST && move->bank<move->last && x &&
            move->spins<combatRotorTurns())
#ifdef SR1_LOCAL_COMBAT59
            {move->spins=localRotorCredit59(move->spins);record("defiance-rotor-credit funded=%u maximum=%u per-click=2",move->spins,combatRotorTurns());}
#else
            ++move->spins;
#endif
#endif
#ifdef SR1_LOCAL_COMBAT_LINKS
        if (move->move==LOCAL_SPECIAL_TEMPEST && move->bank<move->last)
            queueLimit=(unsigned)combatLinks->maxTempestSpins;
#endif
        if (x && move->bank<move->last && move->queued<queueLimit
#ifdef SR1_LOCAL_COMBAT_SYNC42
            && move->move!=LOCAL_SPECIAL_TEMPEST
#endif
        ) ++move->queued;
        const uint64_t phaseDuration=
#ifdef SR1_LOCAL_COMBAT_SYNC42
            move->move==LOCAL_SPECIAL_TEMPEST && move->bank==move->first+1 ?
                combatRotorPeriod()*(move->spins?move->spins:1u) :
#endif
            localSpecialDuration(move->bank);
        if (now-move->owner.tick >= phaseDuration) {
            if (localSpecialEnding(move)) {
#ifdef SR1_LOCAL_SPECIAL_RECOVERY
                if (move->move==LOCAL_SPECIAL_PERFORATE) {
                    specialRecovery=(LocalSpecialRecovery){*move,now};
                    if (sameLocalAction(&specialFollowup,frame,player,now,
#ifdef SR1_LOCAL_SPECIAL_INPUT
                        sheet_sr1CombatInput41_special_input.followupMs))
#else
                        sheet_sr1LocalComboAdmission_spectral_third_native.maxBufferedAgeMs))
#endif
                    {
                        output->pressed|=specialFollowupMask;
#ifdef SR1_LOCAL_SPECIAL_INPUT
                        releasedPress=specialFollowupMask;
#endif
                    }
                    specialFollowup=(LocalActionOwner){0};
                    specialFollowupMask=0;
                }
#endif
                *move=(LocalSpecial){0};
            }
            else {
                move->previous=move->bank;
#ifdef SR1_LOCAL_COMBAT_SYNC42
                if (move->move==LOCAL_SPECIAL_TEMPEST) {
                    move->bank=move->bank==move->first?move->first+1:move->last;
                    move->queued=0;
                    if (!move->spins) move->spins=
#ifdef SR1_LOCAL_COMBAT59
                localRotorCredit59(0);
#else
                1;
#endif
                } else
#endif
                if (move->queued) {
                    --move->queued;
#ifdef SR1_LOCAL_COMBAT_LINKS
                    if (move->move==LOCAL_SPECIAL_TEMPEST && move->bank==move->first+1 &&
                        move->spins<(unsigned)combatLinks->maxTempestSpins) ++move->spins;
                    else
#endif
                    ++move->bank;
                } else move->bank=move->last;
                move->owner.tick=now;
#ifdef SR1_LOCAL_COMBAT_LINKS
                if (move->move==LOCAL_SPECIAL_TEMPEST && move->bank==move->first+1 && !move->spins) move->spins=1;
#endif
#ifdef SR1_LOCAL_COMBAT_REPAIR
                if (move->move==LOCAL_SPECIAL_TEMPEST && move->bank==move->first+1 && !move->spinStarted)
                    move->spinStarted=now;
#endif
                started=move->move;
            }
        }
#ifdef SR1_LOCAL_SPECIAL_INPUT
        }
#endif
    } else if ((grounded||airborne) && (x!=y) && shortDirection &&
#ifdef SR1_LOCAL_TEMPEST_FLIGHT
        !jumpEdge && (!airborne || !x || currentFlight) &&
#ifdef SR1_LOCAL_COMBAT_SYNC42
        (!airborne || !x || !sameLocalAction(&rotorFlightSpent,frame,player,now,localSpecialFlightLimit()) ||
            rotorFlightSpent.tick!=jump.owner.tick) &&
#endif
#endif
        !frame->groundStrike && !frame->strikePending && !readLocalAirStrike(frame,player,now).owner.tick &&
        !readLocalSlam(frame,player,now,0).owner.tick && localAirStrikeEquipped()) {
        const LocalSpecialMove next=x?(grounded?LOCAL_SPECIAL_PERFORATE:LOCAL_SPECIAL_TEMPEST):
            (grounded?LOCAL_SPECIAL_SHATTER:LOCAL_SPECIAL_EMPYREAL);
        unsigned first=next==LOCAL_SPECIAL_PERFORATE?0u:next==LOCAL_SPECIAL_TEMPEST?8u:
            next==LOCAL_SPECIAL_SHATTER?11u:12u;
        unsigned last=next==LOCAL_SPECIAL_PERFORATE?7u:next==LOCAL_SPECIAL_TEMPEST?10u:first;
        bool admitted=true;
        if (next==LOCAL_SPECIAL_EMPYREAL) {
            requestLocalSlam(frame,player,now,true);
            AcquireSRWLockExclusive(&localAirSlamLock);
            admitted=localAirSlam.owner.tick==now && localAirSlam.owner.actor==player;
            if (admitted) localAirSlam.rebound=true;
            ReleaseSRWLockExclusive(&localAirSlamLock);
        }
        if (admitted) {
#ifdef SR1_LOCAL_SPECIAL_RECOVERY
            specialRecovery=(LocalSpecialRecovery){0};
            specialFollowup=(LocalActionOwner){0};
            specialFollowupMask=0;
#endif
            *move=(LocalSpecial){.owner=localActionOwner(frame,player,now),.move=next,.bank=first,.first=first,.last=last};
#ifdef SR1_LOCAL_SPECIAL_INPUT
            move->directional=readCombatBearing(output->x,output->y,&move->bearing);
#endif
#ifdef SR1_LOCAL_TEMPEST_FLIGHT
            if (next==LOCAL_SPECIAL_TEMPEST) {
                move->flight=jump.owner.tick;
#ifdef SR1_LOCAL_COMBAT_SYNC42
                rotorFlightSpent=jump.owner;
                move->spins=
#ifdef SR1_LOCAL_COMBAT59
                    localRotorCredit59(0);
#else
                    1;
#endif
#endif
            }
#endif
#ifdef SR1_LOCAL_COMBAT48
            if(next==LOCAL_SPECIAL_TEMPEST){
                unsigned yaw=0;uint16_t current=0;
                if(!localTargetFace47(frame,player,now,&yaw)&&readAt(player+sheet_sr1GroundSteering_camera_relative_start.yawOffset,&current,2))yaw=current;
                move->fixedYaw=yaw&4095u;move->fixedFacing=true;
            }
#endif
            started=next;
            tap=0;
        }
    }
    const bool active=move->move!=LOCAL_SPECIAL_NONE;
    stage=move->bank;
    const bool lockPlanar=active&&!localSpecialAir(move->move);
    ReleaseSRWLockExclusive(&localSpecialLock);
    const uint32_t aim=(uint32_t)localStasisPolicy->aimMask;
    uint32_t abilities=0;
#ifdef SR1_LOCAL_COMBAT53
#ifndef SR1_LOCAL_COMBAT55
    if(!active)localTkInput53(output,frame,now);
#endif
    (void)aim;(void)abilities;
#else
    if (!active && !x && !y && (grounded||airborne) && shortDirection && (output->pressed&aim) &&
        localAirStrikeEquipped() && readAt(base+acquisition->abilitiesRva,&abilities,4) && (abilities&4u)) {
        localStasisPress=localActionOwner(frame,player,now);
        tap=0;
        output->pressed &= ~aim;
        output->held &= ~aim;
        output->released &= ~aim;
    }
#endif
    if (active
#ifdef SR1_LOCAL_SPECIAL_INPUT
        || wasSpecial
#endif
    ) {
        output->pressed &= ~(attack|lift);
        output->held &= ~(attack|lift);
        output->released &= ~(attack|lift);
#ifdef SR1_LOCAL_SPECIAL_INPUT
        if (!active) output->pressed|=releasedPress;
#endif
    }
    if (lockPlanar) {
        output->x=output->y=0;
        output->pressed &= ~0xfu;
        output->held &= ~0xfu;
        output->released &= ~0xfu;
    }
    if (started) record("standalone-special realm=%u move=%u stage=%u",frame->realm,started,stage);
}

#ifdef SR1_LOCAL_TEMPEST_FLIGHT
static bool applyLocalTempestPhysics(uintptr_t actor, int32_t segment, int32_t time, int32_t clamp,
    uint64_t now, DWORD previousError) {
    const Sr1LocalFrame frame=readFrame();
    const LocalSpecial special=localReadSpecial(&frame,actor,now);
    if (special.move!=LOCAL_SPECIAL_TEMPEST) return false;
    const unsigned stage=special.bank-special.first;
    const unsigned factor=tempestPlanarPermille(stage,now-special.owner.tick);
    if (factor==1000) return false;
    int32_t planarTime=(int32_t)((int64_t)time*factor/1000);
    if (!planarTime) planarTime=1;

    const LocalJumpReceipt jump=readLocalJump();
    const uintptr_t kinematics=actor+(uintptr_t)slamPolicy->kinematicsOffset;
    LocalSlamKinematics native;
    int16_t position[3];
    int32_t limit;
    if (jump.owner.tick!=special.flight || !readAt(actor+0x9c,position,sizeof(position)) ||
        !readAt(kinematics,&native,sizeof(native)) ||
        !readAt(kinematics+sizeof(native)+2*sizeof(int32_t),&limit,sizeof(limit)) || limit<0)
        return false;

    const int clearance=(int)position[2]-jump.floor;
    const uintptr_t velocityZ=kinematics+offsetof(LocalSlamKinematics,velocity)+2*sizeof(int32_t);
    const uintptr_t accelerationZ=kinematics+offsetof(LocalSlamKinematics,acceleration)+2*sizeof(int32_t);
    const int32_t velocity=native.velocity[2],acceleration=native.acceleration[2];
    const bool slowDescent=stage<2;
    const int32_t continuation=slowDescent ? tempestDescentVelocity(stage,clearance,velocity,acceleration,time) :
        localAirStrikeNativeVelocity(velocity,acceleration,time,limit);
    const LocalAirStrikeStep step={planarTime,time};
    const int32_t limitedVelocity=slowDescent ? localAirStrikeStepVelocity(continuation,step) :
        localAirStrikeStepVelocity(velocity,step);
    const int32_t limitedAcceleration=slowDescent ? 0 : localAirStrikeStepAcceleration(acceleration,step);

    static _Thread_local uint64_t reported;
    if (reported!=special.owner.tick) {
        reported=special.owner.tick;
        record("standalone-tempest-flight realm=%u stage=%u clearance=%d planar=%u vz=%ld->%ld",
            frame.realm,stage,clearance,factor,(long)velocity,(long)continuation);
    }
    memcpy((void *)velocityZ,&limitedVelocity,sizeof(limitedVelocity));
    memcpy((void *)accelerationZ,&limitedAcceleration,sizeof(limitedAcceleration));
    SetLastError(previousError);
    originalSlamPhysics(actor,segment,planarTime,clamp);
    const DWORD nativeError=GetLastError();
    memcpy((void *)velocityZ,&continuation,sizeof(continuation));
    memcpy((void *)accelerationZ,&acceleration,sizeof(acceleration));
    SetLastError(nativeError);
    return true;
}
#else
static unsigned localSpecialAirFactor(const Sr1LocalFrame *frame,uintptr_t actor,uint64_t now) {
    const LocalSpecial special=localReadSpecial(frame,actor,now);
    if (special.move!=LOCAL_SPECIAL_TEMPEST) return 1000;
    // Keep the subsequent exit under the regular airborne descent path.
    return special.bank==special.last?1000:340;
}
#endif
