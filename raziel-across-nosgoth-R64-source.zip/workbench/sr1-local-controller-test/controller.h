// SPDX-License-Identifier: GPL-3.0-or-later
#pragma once

#include <stdbool.h>
#include <stdint.h>

typedef enum { SR1_LOCAL_UNKNOWN, SR1_LOCAL_MATERIAL, SR1_LOCAL_SPECTRAL } Sr1LocalRealm;
typedef enum { SR1_LOCAL_NONE, SR1_LOCAL_JUMP, SR1_LOCAL_STRIKE, SR1_LOCAL_FINISH } Sr1LocalAction;
typedef enum { SR1_AIR_NONE, SR1_AIR_COMPRESS, SR1_AIR_JUMP, SR1_AIR_FALL, SR1_AIR_LAND } Sr1LocalAirState;

enum { SR1_LOCAL_PRESS_JUMP = 1, SR1_LOCAL_PRESS_STRIKE = 2, SR1_LOCAL_PRESS_FINISH = 4 };

typedef struct {
    uint64_t session, serial;
    uint32_t worldGeneration, playerGeneration;
    Sr1LocalRealm realm;
    bool ready, nativeControl, grounded, renderBlend;
#ifdef SR1_LOCAL_COMBAT48
    bool groundContact48;
#endif
    bool groundStrike;
    bool strikePending;
#ifdef SR1_LOCAL_GROUND_ACTIONS
    unsigned strikeKey, strikeGate;
#endif
#ifdef SR1_LOCAL_THIRD_FINISH
    bool strikeSettled;
#endif
#ifdef SR1_LOCAL_THIRD_SWEEP
    bool strikeTransition;
#endif
    uintptr_t strikeIdentity;
    int32_t strikeTime, strikeEnd;
    unsigned strikeOrdinal;
    Sr1LocalAirState airState;
    int32_t verticalVelocity;
    // Set only from an SR1-confirmed target that is eligible for a finisher now.
    uint32_t finishTargetGeneration;
    uint8_t pressed;
    int16_t moveX, moveY;
} Sr1LocalFrame;

typedef struct {
    bool apply;
    bool ownsControl;
    int16_t moveX, moveY;
    Sr1LocalAction action;
    uint32_t finishTargetGeneration;
} Sr1LocalCommand;

typedef struct {
    uint64_t session, serial;
    uint32_t worldGeneration, playerGeneration;
    Sr1LocalRealm realm;
    uint8_t previousPressed;
    bool ownsControl;
} Sr1LocalController;

Sr1LocalCommand sr1LocalUpdate(Sr1LocalController *state, const Sr1LocalFrame *frame);
