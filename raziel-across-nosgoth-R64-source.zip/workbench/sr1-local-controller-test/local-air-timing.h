// SPDX-License-Identifier: GPL-3.0-or-later
#pragma once

static const Sheet_sr1LocalDefianceJump *const airPolicy = &sheet_sr1LocalDefianceJump_local_defiance_jump;

static inline int localSignedTurn(unsigned before, unsigned after) {
    return (int)((before - after + 2048u) & 4095u) - 2048;
}

static inline float visualTurnRemainder(float units, uint64_t elapsed) {
    const float u = fminf(1.f, (float)elapsed / (float)airPolicy->turnMs);
    return units * (1 - u * u * (3 - 2 * u));
}

static inline float turnFromVisibleRoot(const float root[13], unsigned target, int units) {
    const float current = atan2f(root[3], root[0]) * (4096.f / 6.2831853071795864769f);
    const float change = (float)target - current;
    const float correction = change - 4096.f * roundf(change / 4096.f);
    // The native palette can remain on the previous heading for one draw.
    float remaining = (float)units + correction;
    if (remaining > 2048.f) remaining -= 4096.f;
    if (remaining < -2048.f) remaining += 4096.f;
    return remaining;
}

static inline void rotateVisibleYaw(float pose[66][13], float units) {
    const float angle = units * (6.2831853071795864769f / 4096.f);
    const float c = cosf(angle), s = sinf(angle), ox = pose[0][10], oy = pose[0][11];
    for (unsigned i = 0; i < 66; ++i) {
        float *m = pose[i];
        for (unsigned k = 0; k < 3; ++k) {
            const float x = m[k], y = m[3 + k];
            m[k] = c * x - s * y;
            m[3 + k] = s * x + c * y;
        }
        const float x = m[10] - ox, y = m[11] - oy;
        m[10] = ox + c * x - s * y;
        m[11] = oy + s * x + c * y;
    }
}

static inline bool ordinaryLaunchArgs(uintptr_t caller, int32_t gravity, int32_t x, int32_t y, int32_t z) {
    return gravity == airPolicy->normalGravity && x == 0 && z == airPolicy->originalVertical &&
        ((caller == (uintptr_t)airPolicy->standingReturnRva && y == airPolicy->standingForward) ||
         (caller == (uintptr_t)airPolicy->runningReturnRva && y == airPolicy->runningForward));
}

static inline bool useAuthoredFall(int32_t vertical, int rise) {
    return vertical < 0 && rise <= airPolicy->fallStartAbove;
}
