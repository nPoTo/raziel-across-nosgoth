// SPDX-License-Identifier: GPL-3.0-or-later
#pragma once
// Port of released0.2 C6 close native collision. No damage or victim position writes.
static bool localForceTarget54(const Sr1LocalFrame*f,uintptr_t*out,uint32_t*gen){
 const LocalContactTicket flight=localFlightTicket;LocalTarget target;int16_t root[3],to[3];
 // Keep the actual lifted opponent when in the original close airborne envelope.
 if(flight.target.actor&&sameLocalAction(&flight.owner,f,player,GetTickCount64(),5000)&&
  localReadContactTarget(flight.target.actor,f->worldGeneration,&target)&&target.generation==flight.target.generation&&
  target.mainState==AIR_FLIGHT_STATE&&readAt(player+0x9c,root,6)&&readAt(target.actor+0x9c,to,6)&&airForceClose(root,to,true)&&to[2]<=INT16_MAX-128){
  const float from[3]={root[0],root[1],root[2]+128.f};to[2]+=128;
  if(localNativeLineClear(player,f->worldGeneration,from,to)){*out=target.actor;*gen=target.generation;return true;}
 }
 return localNearestTarget49(f,player,out,gen);
}
static bool localForceTransforms54(uintptr_t actor){
 uintptr_t current=0,previous=0;unsigned char matrix[32];
 return readAt(actor+AIR_FORCE_PROJECTILE_CURRENT_PALETTE,&current,8)&&current&&readAt(current,matrix,32)&&
  readAt(actor+AIR_FORCE_PROJECTILE_PREVIOUS_PALETTE,&previous,8)&&previous&&readAt(previous,matrix,32);
}
static bool localForceSphere54(uintptr_t actor,LocalSphere*out){
 const Sheet_c2HostGeometry*p=contactGeometry;uintptr_t models=0,entries=0;int16_t index=0;uint32_t count=0;
 if(!readAt(actor+p->collisionModelsOffset,&models,8)||!models||!readAt(actor+p->modelIndexOffset,&index,2)||index<0||index>31||
  !readAt(models+(uintptr_t)index*16,&entries,8)||!entries||!readAt(models+(uintptr_t)index*16+8,&count,4)||!count||count>128)return false;
 for(unsigned pass=0;pass<2;pass++)for(unsigned i=0;i<count;i++){
  unsigned char entry[16],sphere[16];LocalSphere s={.entry=entries+i*16};
  if(!readAt(s.entry,entry,16))return false;if(!c2SphereEntryUsable(entry,false,pass==0))continue;
  memcpy(&s.primitive,entry+8,8);if(!s.primitive||!readAt(s.primitive,sphere,16))return false;
  memcpy(&s.native.radius,sphere+14,2);s.flags=entry[0];if(s.native.radius){*out=s;return true;}
 }
 return false;
}
static bool localForceClose54(LocalStasisShot*shot,const Sr1LocalFrame*f,uint64_t now){
 const uintptr_t projectile=shot->projectile;const uint32_t projectileGen=shot->generation;LocalTarget target;
 uint32_t flags=0,room=0,variant=0;uintptr_t callback=0,state=0,prior=0;int16_t root[3],to[3];LocalSphere body,own;
 if(!sameLocalAction(&shot->owner,f,player,now,2000)||!f->renderBlend||!projectileGen||generation(projectile)!=projectileGen||
  !readAt(projectile+0x60,&room,4)||room!=f->worldGeneration||!readAt(projectile+0x28,&flags,4)||(flags&0x24041000u)||
  !readAt(projectile+0x1a0,&callback,8)||callback!=base+AIR_NATIVE_PROJECTILE_COLLISION||
  !readAt(projectile+0x2c0,&state,8)||!state||!readAt(state+4,&variant,4)||(variant!=3&&variant!=4)||
  !localReadContactTarget(shot->selected,f->worldGeneration,&target)||target.generation!=shot->selectedGen||
  !readAt(player+0x9c,root,6)||!readAt(target.actor+0x9c,to,6)||!airForceClose(root,to,f->airState!=SR1_AIR_NONE||target.mainState==AIR_FLIGHT_STATE)||
  ((int(*)(uintptr_t,uintptr_t))(base+contactPolicy->sameFamilyRva))(projectile,target.actor))return false;
 if((!localContactSphere(target.actor,false,false,NULL,NULL,&body)&&!localContactSphere(target.actor,false,true,NULL,NULL,&body))||
  !body.native.radius||!localForceSphere54(projectile,&own)||!localForceTransforms54(projectile)||
  !readAt(projectile+AIR_FORCE_COLLISION_SLOT,&prior,8))return false;
 const float from[3]={root[0],root[1],root[2]+128.f};
 if(!localNativeLineClear(player,f->worldGeneration,from,body.native.center))return false;
 AirForceCollision contact={.ownType=1,.otherType=1,.ownPrimitive=own.primitive,.otherPrimitive=body.primitive,.projectile=projectile,.target=target.actor};
 const uintptr_t slot=(uintptr_t)&contact;SIZE_T written=0;
 if(!WriteProcessMemory(GetCurrentProcess(),(void*)(projectile+AIR_FORCE_COLLISION_SLOT),&slot,8,&written)||written!=8)return false;
 shot->closeAttempted=true;
 ((void(*)(uintptr_t,uintptr_t))(base+AIR_NATIVE_PROJECTILE_COLLISION))(projectile,base+AIR_FORCE_COLLISION_TRACKER);
 uintptr_t current=0;if(generation(projectile)==projectileGen&&readAt(projectile+AIR_FORCE_COLLISION_SLOT,&current,8)&&current==slot)
  WriteProcessMemory(GetCurrentProcess(),(void*)(projectile+AIR_FORCE_COLLISION_SLOT),&prior,8,&written);
 const bool hit=shot->generation==0; // Set only by the authenticated native impact post, never by selection.
 if(hit&&generation(projectile)==projectileGen){uint32_t life=0;
  if(readAt(projectile+0x24,&life,4)&&!(life&0x20u)&&readAt(projectile+0x28,&flags,4)&&!(flags&0x24041000u))
   ((void(*)(uintptr_t))(base+AIR_FORCE_RETIRE_RVA))(projectile);
 }
 record("defiance-force-close target=%u projectile=%u hit=%u air=%u age=%llu",target.generation,projectileGen,hit,f->airState!=SR1_AIR_NONE,(unsigned long long)(now-shot->spawned));return hit;
}
static void localForcePoll54(void){
 const Sr1LocalFrame f=readLocalFrame(true);const uint64_t now=GetTickCount64();
 for(unsigned i=0;i<32;i++){LocalStasisShot*shot=&localForceShots53[i];
  if(!shot->generation||!shot->selected||shot->closeAttempted||now<shot->spawned||now-shot->spawned>AIR_FORCE_CLOSE_WAIT_MS||now==shot->spawned)continue;
  (void)localForceClose54(shot,&f,now);
 }
}
