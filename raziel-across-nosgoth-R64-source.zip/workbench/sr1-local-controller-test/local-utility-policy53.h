// SPDX-License-Identifier: GPL-3.0-or-later
#pragma once
#include "../../output/github-v0.2-staging/source/workbench/c6-force-cooldown-r1/native/force-cooldown.h"
#include "../../output/github-v0.2-staging/source/workbench/c5-charged-animation-r4/build/linked/c6-force-damage-policy.h"
#include "../../output/github-v0.2-staging/source/workbench/c4-linked-finisher-r10/native/finish-health.h"
static _Thread_local C6ForceCooldown localForceCooldown53;
#ifdef SR1_LOCAL_COMBAT57
static LocalActionOwner localTkPose57;
#endif
static bool localUtilityInput53(NativePad *,const Sr1LocalFrame *,uint64_t);
static void localTkInput53(NativePad *,const Sr1LocalFrame *,uint64_t);
static void localUtilityTick53(const Sr1LocalFrame *,uint64_t);
typedef struct {LocalActionOwner owner;uintptr_t target,soul;uint32_t targetGen,intro,soulGen,form;uint64_t start,lastPull;bool posted,death,absorbed;
#ifdef SR1_LOCAL_COMBAT56
 uint16_t yaw;int16_t aim[3];bool facing;
#endif
} LocalFinish53;
static SRWLOCK localFinishLock53=SRWLOCK_INIT;
static LocalFinish53 localFinish53;
static LocalFinish53 localFinishRead53(void){AcquireSRWLockShared(&localFinishLock53);LocalFinish53 f=localFinish53;ReleaseSRWLockShared(&localFinishLock53);return f;}
static void localFinishStore53(LocalFinish53 f){AcquireSRWLockExclusive(&localFinishLock53);localFinish53=f;ReleaseSRWLockExclusive(&localFinishLock53);}
static bool localFinishActive53(const Sr1LocalFrame *f,uintptr_t actor,uint64_t now){const LocalFinish53 s=localFinishRead53();return sameLocalAction(&s.owner,f,actor,now,5000)&&now>=s.start&&now-s.start<=(uint64_t)sheet_sr1Combat53_fast_force_held_soul.finishMs+100u;}
typedef struct {LocalActionOwner owner;int16_t point[3];} LocalFinishPoint53;
static SRWLOCK localFinishPointLock53=SRWLOCK_INIT;static LocalFinishPoint53 localFinishPoint53;
static void localFinishBladePoint53(const Sr1LocalFrame *f,uintptr_t actor,const float matrix[16],float tip,uint64_t now){
 if(!localFinishActive53(f,actor,now)||!isfinite(tip)||tip<=0)return;LocalFinishPoint53 next={.owner=localActionOwner(f,actor,now)};
 for(unsigned i=0;i<3;i++){const float p=matrix[12+i]+matrix[8+i]*tip;if(!isfinite(p)||p<INT16_MIN||p>INT16_MAX)return;next.point[i]=(int16_t)lroundf(p);}
 AcquireSRWLockExclusive(&localFinishPointLock53);localFinishPoint53=next;ReleaseSRWLockExclusive(&localFinishPointLock53);
}
