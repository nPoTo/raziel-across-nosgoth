// SPDX-License-Identifier: GPL-3.0-or-later
#pragma once

#include "local-binding-profile.h"
#ifdef SR1_LOCAL_CONTROL_EDGES
#include "local-combat-edges.h"
#endif

static const Sheet_sr1LocalInputBoundary *const inputBoundary = &sheet_sr1LocalInputBoundary_native_binding_table;
static const Sheet_sr1LocalGuardClips *const guardClips = &sheet_sr1LocalGuardClips_measured_guard_and_y;
static volatile LONG localBindingsReady;
#ifdef SR1_LOCAL_COMBAT60
static LocalBinding portableBindingsBefore60[BINDING_COUNT],portableBindingsAfter60[BINDING_COUNT];
static bool portableBindingsOwned60;
#endif
static SRWLOCK localCombatInputLock = SRWLOCK_INIT;
typedef struct {
    LocalActionOwner guard, lift;
#ifdef SR1_LOCAL_COMBAT_TEMPO
    LocalActionOwner liftJumpRequest;
    uint64_t liftJumpFlight;
    bool liftHeldThrough;
#endif
    bool guardHeld, airborneLift;
    float guardAtEdge, guardSpeed;
    uint64_t guardSample;
#ifdef SR1_LOCAL_COMBAT_CONTINUITY
    unsigned guardBearing;
    bool guardDirectional;
#endif
} LocalCombatInput;
static LocalCombatInput combatInput;
#ifdef SR1_LOCAL_CONTROL_FIX
static _Thread_local bool dodgeJumpClaimed;
#endif
#ifdef SR1_LOCAL_CONTROL_EDGES
static _Thread_local bool liftWasHeld;
#endif

static bool applyLocalCombatBindings(void) {
    if (InterlockedCompareExchange(&localBindingsReady, 0, 0)) return true;
    const uintptr_t executable = (uintptr_t)GetModuleHandleW(NULL);
    LocalBinding rows[BINDING_COUNT], stock[BINDING_COUNT];
    const uintptr_t table = executable + (uintptr_t)inputBoundary->tableRva;
    if (!readAt(table, rows, sizeof(rows)) ||
        !readAt(executable + inputBoundary->stockRva, stock, sizeof(stock))) return false;
#ifdef SR1_LOCAL_COMBAT60
    LocalBinding before60[BINDING_COUNT];memcpy(before60,rows,sizeof rows);
#endif
    const unsigned result = localBindingProfile(rows, stock, &sheet_sr1LocalControlDefaults_release_02_bindings);
    if (!result) return false;
    // This runs on the ordinary player input thread, after SRX has initialized the table.
    if ((result & 3u) && !WriteProcessMemory(GetCurrentProcess(), (void *)table, rows, sizeof(rows), NULL)) return false;
#ifdef SR1_LOCAL_COMBAT60
    if(result&3u){memcpy(portableBindingsBefore60,before60,sizeof rows);memcpy(portableBindingsAfter60,rows,sizeof rows);portableBindingsOwned60=true;}
#endif
    InterlockedExchange(&localBindingsReady, 1);
    record("defiance-native-bindings keyboard-default=%u controller-default=%u B=%u RB=%u LB=%u Y=%u",
        (result & 1u) != 0, (result & 2u) != 0, rows[BIND_AIM].pad, rows[BIND_FEED].pad,
        rows[BIND_FACE].pad, rows[BIND_LIFT].pad);
    // The input bits for this first call were sampled before the new table was installed.
    return false;
}

static LocalCombatInput readLocalCombatInput(void) {
    LocalCombatInput input = {0};
    if (TryAcquireSRWLockShared(&localCombatInputLock)) {
        input = combatInput;
        ReleaseSRWLockShared(&localCombatInputLock);
    }
    return input;
}
#ifdef SR1_LOCAL_COMBAT56
#include "local-dodge-control56.h"
#endif

static float localGuardWeight(const LocalCombatInput *input, uint64_t now) {
    const float target = input->guardHeld ? 1.f : 0.f;
    const uint64_t duration = input->guardHeld ? guardClips->entryMs : guardClips->exitMs;
    if (now - input->guard.tick >= duration) return target;
    const float t = (float)(now - input->guard.tick) / (float)duration;
    return input->guardAtEdge + (target - input->guardAtEdge) * t * t * (3.f - 2.f * t);
}

static bool localYPresentation(const LocalCombatInput *input, const Sr1LocalFrame *frame,
    uintptr_t actor, uint64_t now) {
    uint64_t length = input->airborneLift ? guardClips->airWindupMs + guardClips->airStrikeMs : guardClips->liftMs;
#if defined(SR1_LOCAL_COMBAT_TIMING) && !defined(SR1_LOCAL_COMBAT_RECOVERY)
    if (!input->airborneLift) length += combatTiming->groundYExitMs;
#endif
    if (!sameLocalAction(&input->lift, frame, actor, now, length) || frame->groundStrike || frame->strikePending)
        return false;
#ifdef SR1_LOCAL_COMBAT_HANDOFF
    if (!input->airborneLift && !groundLiftWindow(input->lift.tick, now, length)) return false;
#endif
    return input->airborneLift ? frame->airState == SR1_AIR_JUMP || frame->airState == SR1_AIR_FALL ||
        frame->airState == SR1_AIR_LAND : frame->grounded && !frame->nativeControl;
}

#ifdef SR1_LOCAL_COMBAT_TEMPO
static const Sheet_sr1LocalHeldLiftJump *const heldLift = &sheet_sr1LocalHeldLiftJump_held_lift;

static bool localLiftJumpPresentation(const LocalCombatInput *input, const Sr1LocalFrame *frame,
    uintptr_t actor, uint64_t now) {
    if (!sameLocalAction(&input->lift, frame, actor, now,
            heldLift->holdMs + heldLift->requestMs + heldLift->upperBodyMs)) return false;
    if (frame->airState == SR1_AIR_COMPRESS)
        return sameLocalAction(&input->liftJumpRequest, frame, actor, now, heldLift->requestMs);
    if (!localSlamAirborne(frame) || !input->liftJumpFlight || input->liftJumpFlight > now ||
        now - input->liftJumpFlight >= (uint64_t)heldLift->upperBodyMs) return false;
    const LocalJumpReceipt jump = readLocalJump();
    return jump.owner.tick == input->liftJumpFlight &&
        sameLocalAction(&jump.owner, frame, actor, now, heldLift->upperBodyMs);
}

static void confirmLocalLiftJump(const Sr1LocalFrame *frame, uintptr_t actor, uint64_t now) {
    AcquireSRWLockExclusive(&localCombatInputLock);
    const bool confirmed = !combatInput.liftJumpFlight &&
        sameLocalAction(&combatInput.liftJumpRequest, frame, actor, now, heldLift->requestMs);
    if (confirmed) combatInput.liftJumpFlight = now;
    ReleaseSRWLockExclusive(&localCombatInputLock);
    if (confirmed) record("defiance-lift-jump-launch realm=%u", frame->realm);
}
#endif

#ifdef SR1_LOCAL_AIR_SLAM
static uint64_t slamRecoveryDuration(void) {
    return localSlamRecoveryMs(guardClips->airStrikeMs, slamPolicy->donorContactMs);
}
#endif

#ifdef SR1_LOCAL_CONTROL_EDGES
static bool hasLocalCombatTarget(const Sr1LocalFrame *frame) {
    uint32_t flags, stream;
    uintptr_t slots, enemy;
    return readAt(base + host->interactionFlagsRva, &flags, sizeof(flags)) && (flags & signals->finishEngagementMask) &&
        readAt(base + host->targetsRva, &slots, sizeof(slots)) && slots &&
        readAt(slots + signals->finishTargetOffset, &enemy, sizeof(enemy)) && enemy && enemy != player &&
        readAt(enemy + 0x60, &stream, sizeof(stream)) && stream == frame->worldGeneration;
}
#endif

static void receiveLocalCombatInput(NativePad *output, const Sr1LocalFrame *frame) {
    const bool eligible = frame->ready && frame->renderBlend && frame->realm != SR1_LOCAL_UNKNOWN;
#ifdef SR1_LOCAL_CALIBRATED_COMBAT
    if (!canLocalDodge(frame)) cancelLocalDodge();
#endif
    if (!eligible || !applyLocalCombatBindings()) {
#ifdef SR1_LOCAL_CONTROL_FIX
        dodgeJumpClaimed = false;
#endif
        AcquireSRWLockExclusive(&localCombatInputLock);
        combatInput = (LocalCombatInput){0};
        ReleaseSRWLockExclusive(&localCombatInputLock);
        return;
    }
    uint32_t face, lift, kind;
    if (!readAt(base + sheet_sr1StandaloneBlade_standalone_default_blade.combatMaskRva, &face, sizeof(face)) || !face ||
        !readAt(base + host->interactionTypeRva, &kind, sizeof(kind))) return;
    lift = (uint32_t)inputBoundary->liftNativeMask;
    const uint64_t now = GetTickCount64();
#ifdef SR1_LOCAL_COMBAT53
    if(localUtilityInput53(output,frame,now)){
        AcquireSRWLockExclusive(&localCombatInputLock);combatInput.lift=(LocalActionOwner){0};combatInput.liftHeldThrough=false;ReleaseSRWLockExclusive(&localCombatInputLock);
        return;
    }
#ifdef SR1_LOCAL_COMBAT55
    localTkInput53(output,frame,now); // Runs even while a special or dodge owns its own movement.
#endif
#endif
    const bool held = (output->held & face) != 0;
#ifdef SR1_LOCAL_COMBAT56
    uint32_t attack56=0;readAt(base+signals->attackMaskRva,&attack56,4);
    const NativePad raw56=*output;localDodgeQueuePad56(output,&raw56,frame,attack56,lift,now);
#endif
#ifdef SR1_LOCAL_LOCK47
    localTargetInput47(frame,player,held && kind==0x1000,now);
#endif
#ifdef SR1_LOCAL_AIR_CONTACT
    uint32_t attack=0;
    if (readAt(base+signals->attackMaskRva,&attack,4) && attack &&
        !readLocalDodge(frame,player,now,0).owner.tick)
        localSpecialPad(output,frame,attack,lift,now);
#endif
#ifdef SR1_LOCAL_COMBAT_LINKS
    if (!held) guardFacing=(LocalActionOwner){0};
    else if (!sameLocalAction(&guardFacing,frame,player,now,UINT64_MAX)) {
        if (readAt(player+sheet_sr1GroundSteering_camera_relative_start.yawOffset,&guardFacingYaw,sizeof(guardFacingYaw)))
            guardFacing=localActionOwner(frame,player,now);
    }
#endif
#ifdef SR1_LOCAL_CONTROL_EDGES
    const bool liftEdge = localCombatPress(&liftWasHeld, (output->held & lift) != 0, (output->pressed & lift) != 0);
#else
    const bool liftEdge = (output->pressed & lift) != 0;
#endif
    const bool ground = frame->grounded && !frame->nativeControl;
    const bool air = frame->airState == SR1_AIR_JUMP || frame->airState == SR1_AIR_FALL;
#ifdef SR1_LOCAL_COMBAT_TEMPO
    uint32_t nativeJump = 0;
    const bool jumpAvailable = readAt(base + signals->jumpMaskRva, &nativeJump, sizeof(nativeJump)) && nativeJump &&
        !((output->held | output->pressed) & nativeJump);
    const bool liftHeld = (output->held & lift) != 0;
#endif
#ifdef SR1_LOCAL_CONTROL_FIX
    const uint32_t jump = 0x80u; // SRX 0x4000 maps here in both checked native tables.
    if (!(output->held & jump)) dodgeJumpClaimed = false;
#ifdef SR1_LOCAL_CALIBRATED_COMBAT
    const LocalCombatInput prior = readLocalCombatInput();
    LocalDodge dodge = readLocalDodge(frame, player, now, 0);
    if (canLocalDodge(frame) && !dodge.owner.tick && held && !dodgeJumpClaimed &&
        (output->pressed & jump) && !localYPresentation(&prior, frame, player, now)) {
        startLocalDodge(frame, player, now, output->x, output->y);
        dodge = readLocalDodge(frame, player, now, 0);
        dodgeJumpClaimed = true;
#ifdef SR1_LOCAL_COMBAT56
        localDodgeQueuePad56(output,&raw56,frame,attack56,lift,now);
#endif
    }
#ifdef SR1_LOCAL_COMBAT56
    if(localDodgeDeferred56(output,&raw56,frame,held,kind,canLocalDodge(frame)&&!dodge.owner.tick&&!localYPresentation(&prior,frame,player,now),now)){
        dodge=readLocalDodge(frame,player,now,0);dodgeJumpClaimed=true;localDodgeQueuePad56(output,&raw56,frame,attack56,lift,now);
    }
#endif
#else
    if (ground && held && !dodgeJumpClaimed && (output->pressed & jump)) {
        dodgeJumpClaimed = true;
        record("defiance-dodge-input realm=%u axes=%ld/%ld", frame->realm, (long)output->x, (long)output->y);
    }
#endif
    if (dodgeJumpClaimed
#ifdef SR1_LOCAL_CALIBRATED_COMBAT
        || dodge.owner.tick
#endif
    ) {
        output->pressed &= ~jump;
        output->held &= ~jump;
        output->released &= ~jump;
    }
#endif

    AcquireSRWLockExclusive(&localCombatInputLock);
    if (!sameLocalAction(&combatInput.guard, frame, player, now, UINT64_MAX)) {
        combatInput.guard = (LocalActionOwner){0};
        combatInput.guardHeld = false;
        combatInput.guardAtEdge = 0;
    }
    const bool guardEdge = held != combatInput.guardHeld;
    if (guardEdge) {
        combatInput.guardAtEdge = localGuardWeight(&combatInput, now);
        combatInput.guard = localActionOwner(frame, player, now);
        combatInput.guardHeld = held;
    }
    combatInput.guardSample = now;
    combatInput.guardSpeed = ground && held ?
        fminf(1.f, hypotf((float)output->x, (float)output->y) / (float)motion->fullAxis) : 0.f;
#ifdef SR1_LOCAL_COMBAT_CONTINUITY
    combatInput.guardDirectional=held && readCombatBearing(output->x,output->y,&combatInput.guardBearing);
#endif
#ifdef SR1_LOCAL_AIR_SLAM
    if (liftEdge && kind == 0x1000 && air) {
        const int threshold = (int)motion->moveThreshold;
        const bool directionalInput = output->x < -threshold || output->x > threshold ||
            output->y < -threshold || output->y > threshold;
        requestLocalSlam(frame, player, now, directionalInput);
    }
    const bool lockSlamMove = readLocalSlam(frame, player, now, slamRecoveryDuration()).owner.tick != 0;
    bool admitLift = liftEdge && kind == 0x1000 && ground && !frame->groundStrike && !lockSlamMove;
#else
    bool admitLift = liftEdge && kind == 0x1000 && (ground || air) && !frame->groundStrike;
#endif
#ifdef SR1_LOCAL_COMBAT_HANDOFF
    const bool groundLiftBusy = !combatInput.airborneLift && localYPresentation(&combatInput, frame, player, now);
    if (groundLiftBusy || frame->strikePending) admitLift = false;
#endif

#ifdef SR1_LOCAL_CALIBRATED_COMBAT
    if (dodge.owner.tick) admitLift = false;
#endif
    if (admitLift) {
        combatInput.lift = localActionOwner(frame, player, now);
        combatInput.airborneLift = air;
#ifdef SR1_LOCAL_COMBAT_TEMPO
        combatInput.liftJumpRequest = (LocalActionOwner){0};
        combatInput.liftJumpFlight = 0;
        combatInput.liftHeldThrough = liftHeld;
#endif
    }
#ifdef SR1_LOCAL_COMBAT_TEMPO
    if (!liftHeld || !ground || kind != 0x1000 || !jumpAvailable || frame->strikePending)
        combatInput.liftHeldThrough = false;
    const bool launchLift = combatInput.liftHeldThrough &&
        sameLocalAction(&combatInput.lift, frame, player, now, guardClips->liftMs) &&
        now - combatInput.lift.tick >= (uint64_t)heldLift->holdMs;
    if (launchLift) {
        combatInput.liftHeldThrough = false;
        combatInput.liftJumpRequest = localActionOwner(frame, player, now);
    }
    if (frame->groundStrike || (!ground && !air && frame->airState != SR1_AIR_LAND &&
        !localLiftJumpPresentation(&combatInput, frame, player, now))) combatInput.lift.tick = 0;
#else
    if (frame->groundStrike || (!ground && !air && frame->airState != SR1_AIR_LAND)) combatInput.lift.tick = 0;
#endif
#ifdef SR1_LOCAL_COMBAT_HANDOFF
    const bool lockLiftMove = kind == 0x1000 && !combatInput.airborneLift &&
        localYPresentation(&combatInput, frame, player, now);
    if (lockLiftMove) combatInput.guardSpeed = 0.f;
#endif
    ReleaseSRWLockExclusive(&localCombatInputLock);

#ifdef SR1_LOCAL_COMBAT_TEMPO
    if (launchLift) {
        output->held |= nativeJump;
        output->pressed |= nativeJump;
        output->released &= ~nativeJump;
        record("defiance-lift-jump-request realm=%u", frame->realm);
    }
#endif
    if (guardEdge) record("defiance-guard-input held=%u realm=%u axes=%ld/%ld", held,
        frame->realm, (long)output->x, (long)output->y);
    if (liftEdge) record("defiance-y-input realm=%u pose=%s", frame->realm,
        admitLift ? (air ? "air" : "ground") :
#ifdef SR1_LOCAL_COMBAT_HANDOFF
        groundLiftBusy ? "ground-busy" :
#endif
        "none");
#ifdef SR1_LOCAL_COMBAT_HANDOFF
    if (lockLiftMove
#ifdef SR1_LOCAL_CALIBRATED_COMBAT
        || dodge.owner.tick
#endif
#ifdef SR1_LOCAL_AIR_SLAM
        || lockSlamMove
#endif
    ) {
        const uint32_t directions = 0xfu; // Same composed direction bits used by the grounded input shaper.
        output->x = output->y = 0;
        output->held &= ~directions;
        output->pressed &= ~directions;
        output->released &= ~directions;
    }
#endif
#ifdef SR1_LOCAL_CONTROL_EDGES
    // Face/Sneak is only useful to the native controller when it has a real target.
    if (
#ifdef SR1_LOCAL_LOCK47
        (kind==0x1000 || (ground && !hasLocalCombatTarget(frame)))
#else
        ground && held && !hasLocalCombatTarget(frame)
#endif
    ) {
        output->held &= ~face;
        output->pressed &= ~face;
        output->released &= ~face;
    }
#endif
    output->held &= ~lift;
    output->pressed &= ~lift;
    output->released &= ~lift;
}
