// SPDX-License-Identifier: GPL-3.0-or-later
#pragma once
#include "local-charge-policy48.h"
typedef struct {LocalActionOwner owner;uint64_t start;unsigned form,charge;bool casting;} LocalChargeView48;
static SRWLOCK localChargeLock48=SRWLOCK_INIT;
static LocalChargeView48 localChargeView48;
static _Thread_local C5Meter localMeter48;
static _Thread_local C5XHold localHold48;
static _Thread_local LocalChargeView48 localCast48;
static _Thread_local bool localCastCommitted48;
static _Thread_local unsigned localHoldForm48;
#ifdef SR1_LOCAL_COMBAT56
static bool localDodgeBusy56(const Sr1LocalFrame*,uintptr_t,uint64_t);
static bool localDodgeChargeBlocked56(const NativePad*,const Sr1LocalFrame*,uintptr_t,uint64_t);
#endif
static void localChargeCommit48(const Sr1LocalFrame *,uintptr_t,uint64_t);
static LocalChargeView48 localChargeRead48(void){AcquireSRWLockShared(&localChargeLock48);LocalChargeView48 v=localChargeView48;ReleaseSRWLockShared(&localChargeLock48);return v;}
#ifdef SR1_LOCAL_COMBAT51
static bool localFullCharge51(const Sr1LocalFrame *f,uintptr_t actor,uint64_t now){
 const LocalChargeView48 v=localChargeRead48();return v.charge==100&&f->ready&&f->renderBlend&&
  sameLocalAction(&v.owner,f,actor,now,1500)&&localCurrentForm(f->realm)>0;
}
#endif
static void localChargePublish48(const Sr1LocalFrame *f,uintptr_t actor,uint64_t now){
 LocalChargeView48 view=localCast48;view.charge=localMeter48.charge;
 if(!view.casting)view.owner=localActionOwner(f,actor,now);
 AcquireSRWLockExclusive(&localChargeLock48);localChargeView48=view;ReleaseSRWLockExclusive(&localChargeLock48);
}
static bool localChargeSync48(const Sr1LocalFrame *f,uintptr_t actor,uint64_t now){
 uint32_t abilities=0,mirror=0;int32_t hp=0;
 if(!f->ready||!actor||f->realm==SR1_LOCAL_UNKNOWN||!readAt(base+acquisition->abilitiesRva,&abilities,4)||
  !readAt(base+acquisition->mirrorRva,&mirror,4)||abilities!=mirror||!readAt(base+0x2a88cd0,&hp,4))return false;
 const C5ChargeOwner owner={f->session,actor,f->playerGeneration};
 if(hp<=0||!(abilities&2048u)){localMeter48=(C5Meter){0};localCast48=(LocalChargeView48){0};}
 else c5SyncMeter(&localMeter48,owner,abilities);
 localChargePublish48(f,actor,now);return hp>0&&(abilities&2048u);
}
static void localChargeCredit48(const Sr1LocalFrame *f,uintptr_t actor,uint64_t now,unsigned gain,const char *event){
 if(!localChargeSync48(f,actor,now))return;
 const unsigned before=c5AddCharge(&localMeter48,gain);localChargePublish48(f,actor,now);
 record("defiance-charge event=%s before=%u after=%u",event,before,localMeter48.charge);
}
static void localChargeInput48(NativePad *pad,const Sr1LocalFrame *f,uintptr_t actor,uint32_t attack,uint64_t now){
 const bool valid=localChargeSync48(f,actor,now);
 const bool casting=localCast48.casting&&sameLocalAction(&localCast48.owner,f,actor,now,5000);
 if(localCast48.casting&&!casting){localCast48=(LocalChargeView48){0};localCastCommitted48=false;}
 const bool down=(pad->held&attack)!=0;
 const unsigned form=localCurrentForm(f->realm);
 const bool eligible=valid&&f->renderBlend&&f->grounded&&!f->nativeControl&&!localPhysicalCarry(actor)&&
#ifdef SR1_LOCAL_COMBAT56
  !localDodgeChargeBlocked56(pad,f,actor,now)&&
#endif
#ifndef SR1_LOCAL_COMBAT49
  !f->groundStrike&&!f->strikePending&&
#endif
  !casting&&form&&localMeter48.charge==100;
#ifdef SR1_LOCAL_COMBAT49
 if(down&&!localHold48.down&&eligible)record("defiance-charge-hold form=%u ground-strike=%u",form,f->groundStrike);
#endif
 if(down&&!localHold48.down&&eligible)localHoldForm48=form;
 const C5XRoute route=c5HoldX(&localHold48,now,down,eligible&&(!localHold48.owned||form==localHoldForm48));
 if(route==C5_X_CAST){
  localCast48=(LocalChargeView48){.owner=localActionOwner(f,actor,now),.start=now,.form=localHoldForm48,.casting=true};
  localCastCommitted48=false;record("defiance-charge-cast form=%u hold=%llu",localCast48.form,(unsigned long long)(now-localHold48.start));
 }
 if(route==C5_X_HELD||route==C5_X_CAST||casting){pad->held&=~attack;pad->pressed&=~attack;pad->released&=~attack;}
 if(route==C5_X_TAP){pad->pressed|=attack;pad->held|=attack;pad->released&=~attack;}
 if(casting||route==C5_X_CAST){
  const uint32_t blocked=0x8fu|(uint32_t)sheet_sr1LocalInputBoundary_native_binding_table.liftNativeMask;
  pad->x=pad->y=0;pad->held&=~blocked;pad->pressed&=~blocked;pad->released&=~blocked;
 }
 localChargePublish48(f,actor,now);
}
