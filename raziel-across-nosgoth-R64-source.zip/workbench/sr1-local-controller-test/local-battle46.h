// SPDX-License-Identifier: GPL-3.0-or-later
#pragma once
#include "local-battle46-proof.h"
static bool localBattleFace46(uintptr_t rva){return rva==(uintptr_t)sheet_sr1Battle46_defiance_combat.autoFaceRva;}
static void localBattleFrame46(Sr1LocalFrame *frame,bool owned,bool known,bool battle) {
 if(!owned||!known||!battle||!frame->ready||frame->realm==SR1_LOCAL_UNKNOWN||
#ifdef SR1_LOCAL_COMBAT48
 (frame->verticalVelocity>0 || frame->verticalVelocity < -sheet_sr1Combat48_combat_charge.groundVelocityBand || (frame->verticalVelocity<0&&!frame->groundContact48))
#else
 frame->verticalVelocity
#endif
 )return;
 // SR1 still advances its actual attack/collision clock. A missing presentation
 // descriptor is not permission to show the old combat pose or drop the HUD.
 frame->renderBlend=true;
 if(!frame->groundStrike){frame->grounded=true;frame->nativeControl=false;}
}
