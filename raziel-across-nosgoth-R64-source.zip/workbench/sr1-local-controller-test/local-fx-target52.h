// SPDX-License-Identifier: GPL-3.0-or-later
#pragma once
// Cosmetic attachment only: exact actor generation and room; never select/damage an enemy.
static bool localTargetPoint52(uintptr_t target,uint32_t gen,uint32_t world,int16_t out[3]){
 uint32_t room=0;int16_t point[3];
 if(!target||!gen||generation(target)!=gen||!readAt(target+0x60,&room,4)||room!=world||!readAt(target+0x9c,point,6))return false;
 const int z=(int)point[2]+(int)sheet_sr1Combat52_target_cast_camera.targetHeight;
 if(z>INT16_MAX||z<INT16_MIN)return false;point[2]=(int16_t)z;memcpy(out,point,6);return true;
}
