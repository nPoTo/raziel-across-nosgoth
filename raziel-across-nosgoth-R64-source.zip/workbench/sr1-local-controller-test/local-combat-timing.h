// SPDX-License-Identifier: GPL-3.0-or-later
#pragma once

static const Sheet_sr1LocalCombatTiming *const combatTiming = &sheet_sr1LocalCombatTiming_standalone_combat_timing;

#ifdef SR1_LOCAL_X_TEMPO
static const Sheet_sr1LocalGroundXTempo *const groundXTempo = &sheet_sr1LocalGroundXTempo_ground_combo_tempo;

static inline float groundXBaseRate(void) {
    return (float)groundXTempo->strikePermille / 1000.f;
}

static inline float groundXThirdRampAge(float elapsed) {
    return fmaxf(0.f, elapsed - (float)groundXTempo->thirdFinishAtSourceMs / groundXBaseRate());
}

static inline float groundXThirdRateGain(void) {
    return (float)(groundXTempo->thirdFinishPermille - groundXTempo->strikePermille) / 1000.f;
}

static inline uint64_t groundXBlendMs(uint64_t measured) {
    return (measured * 1000 + groundXTempo->strikePermille / 2) / groundXTempo->strikePermille;
}
#endif

static inline float combatEase(uint64_t elapsed, uint64_t duration) {
    if (elapsed >= duration) return 1.f;
    const float fraction = (float)elapsed / (float)duration;
    return fraction * fraction * (3.f - 2.f * fraction);
}

static inline float combatSample(uint64_t elapsed, uint64_t duration, unsigned samples) {
    return elapsed >= duration ? (float)(samples - 1) :
        (float)elapsed * (float)(samples - 1) / (float)duration;
}

#ifdef SR1_LOCAL_COMBAT_RECOVERY
static inline float groundLiftWeight(uint64_t elapsed, uint64_t length) {
    if (elapsed >= length) return 0.f;
    return combatEase(elapsed, combatTiming->groundYEnterMs) *
        combatEase(length - elapsed, combatTiming->groundYExitMs);
}

static inline float limitThirdDrive(float step, uint64_t elapsed) {
    const float limit = (float)combatTiming->thirdDriveUnitsPerSecond *
        (float)(elapsed > 50 ? 50 : elapsed) / 1000.f;
    if (step < -limit) return -limit;
    if (step > limit) return limit;
    return step;
}
#endif

#ifdef SR1_LOCAL_COMBAT_HANDOFF
static inline bool groundLiftWindow(uint64_t start, uint64_t now, uint64_t duration) {
    return start && now >= start && now - start < duration;
}

static inline float thirdDrivePhase(uint64_t start, uint64_t now) {
    return fminf(1.f, (float)(now - start) / (float)combatTiming->groundThirdMs);
}

static inline void bladeRevealPosition(float out[3], const float source[3], float wristZ, float amount) {
    out[0] = source[0] * amount;
    out[1] = source[1] * amount;
    out[2] = (source[2] - wristZ) * amount;
}
#endif
