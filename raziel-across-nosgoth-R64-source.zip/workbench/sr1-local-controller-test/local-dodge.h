// SPDX-License-Identifier: GPL-3.0-or-later
#pragma once

#include "local-dodge-curve.h"

typedef struct {
    LocalActionOwner owner;
    unsigned direction;
#ifdef SR1_LOCAL_COMBAT57
    uint16_t bodyYaw;
#endif
#ifdef SR1_LOCAL_COMBAT_FACING
    unsigned bearing;
    bool directional;
#endif
} LocalDodge;

static SRWLOCK localDodgeLock = SRWLOCK_INIT;
static LocalDodge localDodge;
#ifdef SR1_LOCAL_COMBAT56
static bool localDodgeUtilityBusy56(const Sr1LocalFrame*,uintptr_t,uint64_t);
static void localDodgeCancelOthers56(void);
static bool localDodgeBusy56(const Sr1LocalFrame*f,uintptr_t actor,uint64_t now){
 AcquireSRWLockShared(&localDodgeLock);const LocalDodge d=localDodge;ReleaseSRWLockShared(&localDodgeLock);
 return f->ready&&f->renderBlend&&f->grounded&&f->airState==SR1_AIR_NONE&&d.direction<4&&
  sameLocalAction(&d.owner,f,actor,now,(uint64_t)sheet_sr1CombatDodgeReference_rows[d.direction]->durationMs-1u);
}
#endif

static bool canLocalDodge(const Sr1LocalFrame *frame) {
    return frame->ready && frame->renderBlend && frame->grounded && !frame->nativeControl &&
#ifdef SR1_LOCAL_COMBAT56
        !localDodgeUtilityBusy56(frame,player,GetTickCount64())&&
#endif
        !frame->groundStrike && !frame->strikePending && !frame->strikeTransition &&
        frame->airState == SR1_AIR_NONE && frame->realm != SR1_LOCAL_UNKNOWN;
}

static LocalDodge readLocalDodge(const Sr1LocalFrame *frame, uintptr_t actor, uint64_t now, uint64_t tail) {
    if (!canLocalDodge(frame)) return (LocalDodge){0};
    AcquireSRWLockShared(&localDodgeLock);
    const LocalDodge dodge = localDodge;
    ReleaseSRWLockShared(&localDodgeLock);
    const uint64_t duration = sheet_sr1CombatDodgeReference_rows[dodge.direction]->durationMs;
    return sameLocalAction(&dodge.owner, frame, actor, now, duration + tail) ? dodge : (LocalDodge){0};
}

static void cancelLocalDodge(void) {
    AcquireSRWLockExclusive(&localDodgeLock);
    localDodge = (LocalDodge){0};
    ReleaseSRWLockExclusive(&localDodgeLock);
}

static void startLocalDodge(const Sr1LocalFrame *frame, uintptr_t actor, uint64_t now, int32_t x, int32_t y) {
#ifdef SR1_LOCAL_COMBAT56
    localDodgeCancelOthers56();
#endif
#ifdef SR1_LOCAL_COMBAT_FACING
    LocalDodge dodge={.owner=localActionOwner(frame,actor,now),.direction=1};
    const Sheet_sr1GroundSteering *p=&sheet_sr1GroundSteering_camera_relative_start;
    uint16_t yaw;
    dodge.directional=readCombatBearing(x,y,&dodge.bearing) && readAt(actor+p->yawOffset,&yaw,sizeof(yaw));
#ifdef SR1_LOCAL_COMBAT_LINKS
    if (sameLocalAction(&guardFacing,frame,actor,now,UINT64_MAX)) yaw=guardFacingYaw;
#endif
    
#ifdef SR1_LOCAL_COMBAT57
    if(!readAt(actor+p->yawOffset,&dodge.bodyYaw,2))return;
    yaw=dodge.bodyYaw;
#endif
    if (dodge.directional) {
        const int delta=combatYawDelta(yaw,dodge.bearing);
#ifdef SR1_LOCAL_COMBAT_REPAIR
        dodge.direction=localDodgeFromBearing(delta);
#else
        if (delta>512 && delta<1536) dodge.direction=0;
        if (delta<-512 && delta>-1536) dodge.direction=2;
#endif
    }
#else
    const unsigned direction = localDodgeDirection(x, y, (int32_t)motion->moveThreshold);
    const LocalDodge dodge={localActionOwner(frame,actor,now),direction};
#endif
    AcquireSRWLockExclusive(&localDodgeLock);
    localDodge = dodge;
    ReleaseSRWLockExclusive(&localDodgeLock);
    record("defiance-dodge-start realm=%u direction=%u axes=%ld/%ld", frame->realm, dodge.direction, (long)x, (long)y);
}
