// SPDX-License-Identifier: GPL-3.0-or-later
#pragma once
static bool localForearmBlade50(float out[16],const float elbow[13],const float wrist[13]){
 float basis[16];if(!localWristBlade48(basis,wrist,wrist+10))return false;
 float z[3],x[3],length=0;for(unsigned k=0;k<3;k++){z[k]=wrist[10+k]-elbow[10+k];length+=z[k]*z[k];}
 length=sqrtf(length);if(!isfinite(length)||length<1.f)return false;for(unsigned k=0;k<3;k++)z[k]/=length;
 float dot=0,norm=0;for(unsigned k=0;k<3;k++)dot+=basis[k]*z[k];
 for(unsigned k=0;k<3;k++){x[k]=basis[k]-dot*z[k];norm+=x[k]*x[k];}
 if(norm<.0001f){ // Deterministic wrist-local fallback, never world-up aiming.
  dot=0;norm=0;for(unsigned k=0;k<3;k++)dot+=basis[4+k]*z[k];
  for(unsigned k=0;k<3;k++){x[k]=basis[4+k]-dot*z[k];norm+=x[k]*x[k];}
 }
 norm=sqrtf(norm);if(!isfinite(norm)||norm<.0001f)return false;for(unsigned k=0;k<3;k++)x[k]/=norm;
 const float y[3]={z[1]*x[2]-z[2]*x[1],z[2]*x[0]-z[0]*x[2],z[0]*x[1]-z[1]*x[0]};
 float next[16]={0};next[15]=1;for(unsigned k=0;k<3;k++){next[k]=x[k];next[4+k]=y[k];next[8+k]=z[k];next[12+k]=wrist[10+k];}
 memcpy(out,next,sizeof next);return true;
}
