// SPDX-License-Identifier: GPL-3.0-or-later
#pragma once
typedef struct {uintptr_t actor,state;uint32_t generation;int16_t hp;} LocalSpellHealth55;
static bool localSpellEventBefore55(uintptr_t,uint32_t,LocalSpellHealth55*);
static void localSpellEventAfter55(uint32_t,const LocalSpellHealth55*);
static void localSpellPause55(const Sr1LocalFrame*,uintptr_t,uint32_t,uintptr_t,int16_t,int16_t,unsigned,uint64_t);
