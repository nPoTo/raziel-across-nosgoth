// SPDX-License-Identifier: GPL-3.0-or-later
#pragma once

enum { BINDING_COUNT = 13, BIND_FEED = 6, BIND_AIM = 7, BIND_MAP = 8,
       BIND_LIFT = 10, BIND_FACE = 11, BIND_GLYPH = 12 };
typedef struct { uint32_t action, key, pad; } LocalBinding;
_Static_assert(sizeof(LocalBinding) == 12, "SRX binding stride");

static unsigned localBindingProfile(LocalBinding rows[BINDING_COUNT],
    const LocalBinding stock[BINDING_COUNT], const Sheet_sr1LocalControlDefaults *profile) {
    bool keyboardDefault = true, controllerDefault = true;
    for (unsigned i = 0; i < BINDING_COUNT; ++i) {
        if (!stock[i].action || rows[i].action != stock[i].action) return 0;
        keyboardDefault &= rows[i].key == stock[i].key;
        controllerDefault &= rows[i].pad == stock[i].pad;
    }
    if (keyboardDefault) {
        rows[BIND_AIM].key = profile->telekinesisKey;
        rows[BIND_MAP].key = profile->mapKey;
        rows[BIND_LIFT].key = profile->liftKey;
        rows[BIND_GLYPH].key = profile->glyphKey;
    }
    if (controllerDefault) {
        rows[BIND_FEED].pad = profile->feedPad;
        rows[BIND_AIM].pad = profile->telekinesisPad;
        rows[BIND_MAP].pad = profile->mapPad;
        rows[BIND_LIFT].pad = profile->liftPad;
        rows[BIND_FACE].pad = profile->facePad;
    }
    return 4u | (keyboardDefault ? 1u : 0u) | (controllerDefault ? 2u : 0u);
}
