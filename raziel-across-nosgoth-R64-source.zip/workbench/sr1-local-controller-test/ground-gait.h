// SPDX-License-Identifier: GPL-3.0-or-later
#pragma once

#include <float.h>

static const Sheet_sr1GroundCalibration *const gaitPolicy = &sheet_sr1GroundCalibration_calibrated_ground;

typedef struct {
    uint64_t tick;
    float runMix, runSamples, idleSamples;
} GroundGait;

static inline float gaitForwardStep(float current, int32_t time, bool fullIntent) {
    const float factor = (float)time / (float)gaitPolicy->clockDenominator;
    if (!fullIntent || time <= 0 || time > 2 * gaitPolicy->clockDenominator || !isfinite(current) || current >= 0) return current;
    const float magnitude = -current / factor;
    // Accept only the three stock forward tiers, allowing the legacy int16 rounding.
    const float slack = 1.f / factor + .01f;
    if (fabsf(magnitude - 60) <= slack) return -(float)gaitPolicy->runSpeedMilli * factor / 1000.f;
    if (fabsf(magnitude - 35) <= slack || fabsf(magnitude - 16) <= slack) {
        return -(float)gaitPolicy->startSpeedMilli * factor / 1000.f;
    }
    return current;
}

#ifdef SR1_LOCAL_CALIBRATED_MOVEMENT
static inline float gaitPartialScale(void) {
    // Preserve the input response and ratio between the planar axes.
    return (float)gaitPolicy->runSpeedMilli / 60000.f;
}
#endif

static inline void updateGroundGait(GroundGait *s, uint64_t tick, float step, bool moving,
                                    unsigned idleCount, unsigned runCount) {
    if (!s->tick || tick < s->tick || tick - s->tick > (uint64_t)groundPolicy->maxGapMs) {
        *s = (GroundGait){.tick = tick};
        return;
    }
    const float elapsed = (float)(tick - s->tick);
    const float change = elapsed / (float)gaitPolicy->mixMs;
    s->tick = tick;
    s->runMix = moving ? fminf(1.f, s->runMix + change) : fmaxf(0.f, s->runMix - change);
    if (isfinite(step) && step > 0 && step <= (float)gaitPolicy->maxStep) {
        const float unitsPerSecond = (float)gaitPolicy->runSpeedMilli / 1000.f * (float)gaitPolicy->nominalUpdatesHz;
        s->runSamples = fmodf(s->runSamples + step * 60.f / unitsPerSecond, (float)runCount);
    }
    s->idleSamples = fmodf(s->idleSamples + elapsed * .060f, (float)idleCount);
}

#ifdef SR1_LOCAL_MOVING_LANDING
static inline float blendLandingTravel(float *distance, bool advancing, float step, float maximum) {
    if (!advancing) {
        *distance = 0;
        return 0;
    }
    if (step > 0 && step <= (float)gaitPolicy->maxStep) *distance = fminf(maximum, *distance + step);
    const float fraction = *distance / maximum;
    return fraction * fraction * (3.f - 2.f * fraction);
}
#endif
