// SPDX-License-Identifier: GPL-3.0-or-later
#pragma once
#include <mmsystem.h>
#include "local-audio-proof.h"
typedef struct {uint32_t id,rate,offset,bytes,flags;float rateMultiplier;} LocalAudioWave;
typedef struct {uint32_t clip,form,key,keys,wave,volume;float pitch,variance;uint32_t group,weight;} LocalAudioEvent;
_Static_assert(sizeof(LocalAudioWave)==24 && sizeof(LocalAudioEvent)==40,"Sound RAM ABI");
static unsigned char *localAudioBytes;
static LocalAudioWave *localAudioWaves;
static LocalAudioEvent *localAudioEvents;
static unsigned char *localAudioPcm;
static volatile LONG localAudioReady;
typedef struct {unsigned wave,volume;float pitch;uint64_t tick;uintptr_t actor;uint32_t world,generation,realm,form;} LocalAudioJob;
static LocalAudioJob localAudioJobs[128];
static unsigned localAudioRead,localAudioWrite;
static SRWLOCK localAudioLock=SRWLOCK_INIT;
static volatile LONG64 localAudioHeartbeat;
static LocalAudioJob localAudioOwner;
static void localAudioPulse(const Sr1LocalFrame *frame,uintptr_t actor,uint64_t now) {
 AcquireSRWLockExclusive(&localAudioLock);
 localAudioOwner=(LocalAudioJob){.actor=actor,.world=frame->worldGeneration,.generation=frame->playerGeneration,.realm=frame->realm};
 ReleaseSRWLockExclusive(&localAudioLock);
 InterlockedExchange64(&localAudioHeartbeat,(LONG64)now);
}
static bool localAudioJobCurrent(const LocalAudioJob *job,const Sr1LocalFrame *frame,uintptr_t actor) {
 return frame->ready&&frame->renderBlend&&job->actor==actor&&job->world==frame->worldGeneration&&
  job->generation==frame->playerGeneration&&job->realm==(uint32_t)frame->realm;
}
static bool localAudioLoad(HANDLE pipe,uint64_t deadline) {
 unsigned char *bytes=HeapAlloc(GetProcessHeap(),0,LOCAL_AUDIO_BYTES);if(!bytes)return false;
 DWORD filled=0;
 while(filled<LOCAL_AUDIO_BYTES && GetTickCount64()<deadline) {
  DWORD available=0,got=0;if(!PeekNamedPipe(pipe,NULL,0,NULL,&available,NULL))break;
  if(!available){Sleep(2);continue;}
  const DWORD remaining=LOCAL_AUDIO_BYTES-filled;
  if(!ReadFile(pipe,bytes+filled,available<remaining?available:remaining,&got,NULL)||!got)break;
  filled+=got;
 }
 char digest[65];uint32_t head[8];memcpy(head,bytes,sizeof(head));
 const bool valid=filled==LOCAL_AUDIO_BYTES && !memcmp(bytes,"DA44",4) && head[1]==1 &&
  head[2]==LOCAL_AUDIO_WAVES && head[3]==LOCAL_AUDIO_EVENTS && head[4]==LOCAL_AUDIO_PCM &&
  boundedSha256(bytes,filled,LOCAL_AUDIO_BYTES,digest)&&!strcmp(digest,LOCAL_AUDIO_HASH);
 if(!valid){HeapFree(GetProcessHeap(),0,bytes);return false;}
 LocalAudioWave *waves=(LocalAudioWave *)(bytes+32);
 LocalAudioEvent *events=(LocalAudioEvent *)(waves+LOCAL_AUDIO_WAVES);
 for(unsigned i=0;i<LOCAL_AUDIO_WAVES;i++)if(waves[i].bytes%2 || waves[i].offset>LOCAL_AUDIO_PCM ||
  waves[i].bytes>LOCAL_AUDIO_PCM-waves[i].offset || waves[i].rate<1000 || waves[i].rate>192000 ||
  !isfinite(waves[i].rateMultiplier)||waves[i].rateMultiplier<=0.f || waves[i].rateMultiplier>4.f) {
  HeapFree(GetProcessHeap(),0,bytes);return false;
 }
 for(unsigned i=0;i<LOCAL_AUDIO_EVENTS;i++)if(events[i].wave>=LOCAL_AUDIO_WAVES || events[i].form<1 || events[i].form>9 ||
  events[i].key>=events[i].keys || events[i].volume>127 || !isfinite(events[i].pitch)||!isfinite(events[i].variance)) {
  HeapFree(GetProcessHeap(),0,bytes);return false;
 }
 localAudioBytes=bytes;localAudioWaves=waves;localAudioEvents=events;
 localAudioPcm=(unsigned char *)(events+LOCAL_AUDIO_EVENTS);
 InterlockedExchange(&localAudioReady,1);record("defiance-sword-audio RAM-ready waves=%u events=%u forms=1..9",LOCAL_AUDIO_WAVES,LOCAL_AUDIO_EVENTS);
 return true;
}
static bool localAudioQueue(const LocalAudioEvent *event,uint64_t token,uint64_t now) {
 const unsigned seed=(unsigned)(token^(token>>32)^event->wave*2654435761u);
 const float random=(float)(seed%65536u)/32767.5f-1.f;
 AcquireSRWLockExclusive(&localAudioLock);
 const unsigned next=(localAudioWrite+1)%ARRAYSIZE(localAudioJobs);bool queued=false;
 if(next!=localAudioRead) {
  localAudioJobs[localAudioWrite]=localAudioOwner;
  localAudioJobs[localAudioWrite].wave=event->wave;localAudioJobs[localAudioWrite].volume=event->volume;
  localAudioJobs[localAudioWrite].form=event->form;
  localAudioJobs[localAudioWrite].pitch=event->pitch+random*event->variance;localAudioJobs[localAudioWrite].tick=now;
  localAudioWrite=next;queued=true;
 }
 ReleaseSRWLockExclusive(&localAudioLock);
 return queued;
}
typedef struct {uint64_t token;unsigned clip,form;uint8_t fired[(LOCAL_AUDIO_EVENTS+7)/8];} LocalAudioTrack;
static _Thread_local LocalAudioTrack localAudioTracks[32];
static _Thread_local unsigned localAudioTrackNext;
static void localAudioTrackForm(unsigned clip,uint64_t token,float key,unsigned form,uint64_t now) {
 if(!token || !isfinite(key) || !InterlockedCompareExchange(&localAudioReady,0,0))return;
 if(form<1||form>sheet_sr1AudioPolicy44_owned_sword.maximumForm)return;
 InterlockedExchange64(&localAudioHeartbeat,(LONG64)now);
 LocalAudioTrack *track=NULL;
 for(unsigned i=0;i<ARRAYSIZE(localAudioTracks);i++)if(localAudioTracks[i].token==token &&
  localAudioTracks[i].clip==clip && localAudioTracks[i].form==form){track=&localAudioTracks[i];break;}
 if(!track) {
  track=&localAudioTracks[localAudioTrackNext++%ARRAYSIZE(localAudioTracks)];
  *track=(LocalAudioTrack){.token=token,.clip=clip,.form=form};
 }
 for(unsigned i=0;i<LOCAL_AUDIO_EVENTS;i++) {
  const LocalAudioEvent *event=&localAudioEvents[i];
  if(event->clip!=clip || event->form!=form || key<(float)event->key || (track->fired[i/8]&(1u<<(i%8))))continue;
  track->fired[i/8]|=(uint8_t)(1u<<(i%8));
  if(event->group) {
   unsigned sum=0;for(unsigned j=0;j<LOCAL_AUDIO_EVENTS;j++)if(localAudioEvents[j].group==event->group)sum+=localAudioEvents[j].weight;
   unsigned choice=(unsigned)(token^(token>>32)^event->group*2654435761u)%sum;
   const LocalAudioEvent *selected=NULL;
   for(unsigned j=0;j<LOCAL_AUDIO_EVENTS;j++)if(localAudioEvents[j].group==event->group) {
    track->fired[j/8]|=(uint8_t)(1u<<(j%8));
    if(!selected){if(choice<localAudioEvents[j].weight)selected=&localAudioEvents[j];else choice-=localAudioEvents[j].weight;}
   }
   if(selected)localAudioQueue(selected,token,now);
  } else localAudioQueue(event,token,now);
 }
}
static void localAudioTrack(unsigned clip,uint64_t token,float key,unsigned realm,uint64_t now) {
#ifdef SR1_LOCAL_FORMS45
 const unsigned form=localCurrentForm(realm);
#else
 // Source form must follow the blade that is actually drawn. Current standalone renderer: Normal only.
 const unsigned form=realm==SR1_LOCAL_SPECTRAL?(unsigned)sheet_sr1AudioPolicy44_owned_sword.spectralForm:
  (unsigned)sheet_sr1AudioPolicy44_owned_sword.normalForm;
#endif
 localAudioTrackForm(clip,token,key,form,now);
}
#ifdef SR1_LOCAL_COMBAT51
// Called only after native damage confirmation; fullBefore is captured before damage/credit.
static bool localFullHitAudio51(const Sr1LocalFrame *frame,uintptr_t actor,unsigned form,bool fullBefore,uint64_t now){
 uintptr_t current=0;
 if(!fullBefore||!now||!frame->ready||!frame->renderBlend||!actor||form<1||form>9||
    !InterlockedCompareExchange(&localAudioReady,0,0)||!readAt(base+host->actorRva,&current,sizeof(current))||current!=actor)return false;
#ifdef SR1_LOCAL_FORMS45
 if(form!=localCurrentForm(frame->realm))return false;
#endif
 localAudioPulse(frame,actor,now);
 const unsigned clip=(unsigned)sheet_sr1ChargedAudio51_rows[form-1]->clip;
 for(unsigned i=0;i<LOCAL_AUDIO_EVENTS;i++)if(localAudioEvents[i].clip==clip&&localAudioEvents[i].form==form){
  if(!localAudioQueue(&localAudioEvents[i],now,now))return false;
  record("defiance-full-hit-audio form=%u id=%u full-before=1 tick=%llu",form,localAudioWaves[localAudioEvents[i].wave].id,(unsigned long long)now);
  return true;
 }
 return false;
}
static void localCastAudio51(const Sr1LocalFrame *frame,uintptr_t actor,unsigned form,uint64_t start,uint64_t now){
 if(form<1||form>9||now<start)return;
 localAudioPulse(frame,actor,now);
 localAudioTrackForm((unsigned)sheet_sr1ChargeClip48_rows[form-1]->runtimeClip,start,(float)(now-start)*.03f,form,now);
}
#endif
#ifdef SR1_LOCAL_FORMS45
static void localSlamImpactAudio(const Sr1LocalFrame *frame,uintptr_t actor,uint64_t token,uint64_t now) {
 localAudioPulse(frame,actor,now);localAudioTrack(100,token,0.f,frame->realm,now);
 record("defiance-slam-ground-audio token=%llu form=%u",(unsigned long long)token,localCurrentForm(frame->realm));
}
#endif
typedef struct {HWAVEOUT device;WAVEHDR header;unsigned char *data;LocalAudioJob owner;} LocalAudioVoice;
static void localAudioClose(LocalAudioVoice *voice,bool reset) {
 if(!voice->device)return;
 if(reset)waveOutReset(voice->device);
 if(waveOutUnprepareHeader(voice->device,&voice->header,sizeof(voice->header))==MMSYSERR_NOERROR) {
  waveOutClose(voice->device);HeapFree(GetProcessHeap(),0,voice->data);memset(voice,0,sizeof(*voice));
 }
}
static DWORD WINAPI localAudioWorker(void *unused) {
 (void)unused;LocalAudioVoice voices[24]={0};
 for(;;) {
  const uint64_t now=GetTickCount64();DWORD foreground=0;
  GetWindowThreadProcessId(GetForegroundWindow(),&foreground);
  const uint64_t heartbeat=(uint64_t)InterlockedCompareExchange64(&localAudioHeartbeat,0,0);
  uint8_t enabled=0;
  const Sr1LocalFrame frame=readFrame();uintptr_t actor=0;
  const bool live=foreground==GetCurrentProcessId()&&frame.ready&&frame.renderBlend&&
   readAt(base+host->actorRva,&actor,sizeof(actor))&&actor&&heartbeat&&now>=heartbeat&&
   now-heartbeat<(uint64_t)sheet_sr1AudioPolicy44_owned_sword.heartbeatMs &&
   readAt(base+sheet_sr1Audio44_installed_audio.sfxEnabledRva,&enabled,sizeof(enabled))&&enabled!=0;
  for(unsigned i=0;i<ARRAYSIZE(voices);i++)if(voices[i].device) {
   const bool current=live&&localAudioJobCurrent(&voices[i].owner,&frame,actor);
   if(!current||(voices[i].header.dwFlags&WHDR_DONE))localAudioClose(&voices[i],!current);
  }
  LocalAudioJob job={0};bool available=false;
  AcquireSRWLockExclusive(&localAudioLock);
  if(localAudioRead!=localAudioWrite){job=localAudioJobs[localAudioRead];localAudioRead=(localAudioRead+1)%ARRAYSIZE(localAudioJobs);available=true;}
  ReleaseSRWLockExclusive(&localAudioLock);
  if(available && live && localAudioJobCurrent(&job,&frame,actor) && now>=job.tick && now-job.tick<=(uint64_t)sheet_sr1AudioPolicy44_owned_sword.freshMs && job.wave<LOCAL_AUDIO_WAVES) {
   LocalAudioVoice *voice=NULL;for(unsigned i=0;i<ARRAYSIZE(voices);i++)if(!voices[i].device){voice=&voices[i];break;}
   if(voice) {
    voice->owner=job;
    const LocalAudioWave *source=&localAudioWaves[job.wave];
    const float ratio=source->rateMultiplier*powf(2.f,job.pitch/12.f);
    const uint32_t rate=(uint32_t)fmaxf(1000.f,fminf(192000.f,source->rate*ratio));
    WAVEFORMATEX format={WAVE_FORMAT_PCM,1,rate,rate*2,2,16,0};
    voice->data=HeapAlloc(GetProcessHeap(),0,source->bytes);
    if(voice->data) {
     const int16_t *pcm=(const int16_t *)(localAudioPcm+source->offset);int16_t *output=(int16_t *)voice->data;
     for(unsigned i=0;i<source->bytes/2;i++)output[i]=(int16_t)((int32_t)pcm[i]*(int32_t)job.volume/127);
     MMRESULT result=waveOutOpen(&voice->device,WAVE_MAPPER,&format,0,0,CALLBACK_NULL);
     if(result==MMSYSERR_NOERROR) {
      voice->header=(WAVEHDR){.lpData=(LPSTR)voice->data,.dwBufferLength=source->bytes};
      result=waveOutPrepareHeader(voice->device,&voice->header,sizeof(voice->header));
      if(result==MMSYSERR_NOERROR)result=waveOutWrite(voice->device,&voice->header,sizeof(voice->header));
      if(result!=MMSYSERR_NOERROR)localAudioClose(voice,true);
     } else {HeapFree(GetProcessHeap(),0,voice->data);memset(voice,0,sizeof(*voice));}
     static unsigned reported,playedForms;
     const bool firstForm=job.form>0&&job.form<=9&&!(playedForms&(1u<<job.form));if(firstForm)playedForms|=1u<<job.form;
     if(reported++<24||firstForm)record("defiance-sword-audio play form=%u id=%u rate=%u volume=%u result=%u",job.form,source->id,rate,job.volume,(unsigned)result);
     if(source->id==321||source->id==322)record("defiance-ground-impact-play queued=%llu form=%u id=%u result=%u",(unsigned long long)job.tick,job.form,source->id,(unsigned)result);
     if(source->id>=51001&&source->id<=51009)record("defiance-full-hit-play queued=%llu form=%u id=%u result=%u",(unsigned long long)job.tick,job.form,source->id,(unsigned)result);
    }
   }
  }
  Sleep(2);
 }
 return 0;
}
