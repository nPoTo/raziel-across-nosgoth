// SPDX-License-Identifier: GPL-3.0-or-later
#pragma once

static inline unsigned combatSyncInterval(unsigned interval,unsigned rate) {
    if (!interval || interval>sheet_sr1CombatSync42_synchronized_combat.stockMaxInterval) return interval;
    return (interval*rate+500u)/1000u;
}

static inline uint64_t combatRotorPeriod(void) {
#ifdef SR1_LOCAL_COMBAT49
    return sheet_sr1Combat49_combat_physics.rotorPeriodMs;
#elif defined(SR1_LOCAL_BATTLE46)
    return sheet_sr1Battle46_defiance_combat.rotorPeriodMs;
#elif defined(SR1_LOCAL_FORMS45)
    return sheet_sr1Forms45_release_02.rotorPeriodMs;
#else
    const uint64_t source=(sheet_sr1LocalAirStrikeClip_air_third.clipKeys*1000u+29u)/30u;
    const uint64_t rate=sheet_sr1LocalAirComboTempo_air_combo.posePermille;
    const uint64_t original=(source*1000u+rate-1u)/rate;
#ifdef SR1_LOCAL_ROTOR44
    return (original*1000u+sheet_sr1Rotor44_rotor_only.speedPermille-1u)/sheet_sr1Rotor44_rotor_only.speedPermille;
#else
    return original;
#endif
#endif
}

static inline unsigned combatRotorTurns(void) {
#ifdef SR1_LOCAL_COMBAT60
    return (unsigned)sheet_sr1Combat60_portable_lifecycle.rotorTurns;
#elif defined(SR1_LOCAL_COMBAT59)
    return (unsigned)sheet_sr1Combat59_input_and_native_coverage.rotorTurns;
#elif defined(SR1_LOCAL_COMBAT49)
    return (unsigned)sheet_sr1Combat49_combat_physics.rotorTurns;
#elif defined(SR1_LOCAL_LOCK47)
    return (unsigned)sheet_sr1Lock47_locked_combat.maxRotorTurns;
#else
    return (unsigned)sheet_sr1CombatSync42_synchronized_combat.rotorTurns;
#endif
}

#ifdef SR1_LOCAL_COMBAT59
static inline unsigned localRotorCredit59(unsigned turns){
 const unsigned maximum=combatRotorTurns(),credit=(unsigned)sheet_sr1Combat59_input_and_native_coverage.turnsPerPress;
 return turns>=maximum||credit>=maximum-turns?maximum:turns+credit;
}
#endif
static inline uint64_t combatRotorEntry(void) {
    return combatRotorPeriod()*sheet_sr1CombatSync42_synchronized_combat.rotorSample/
        (sheet_sr1CombatSync42_synchronized_combat.rotorSamples-1u);
}

static inline uint64_t combatRotorDuration(unsigned bank) {
    if (bank==8) return combatRotorEntry();
    if (bank==9) return combatRotorPeriod()*combatRotorTurns();
    return combatRotorPeriod()-combatRotorEntry();
}

static inline uint64_t combatRotorShownAge(uint64_t age,unsigned turns) {
    const unsigned maximum=combatRotorTurns();
    if (!turns) turns=1;
    if (turns>maximum) turns=maximum;
    const uint64_t end=combatRotorPeriod()*turns;
    return age<end?age:end;
}
