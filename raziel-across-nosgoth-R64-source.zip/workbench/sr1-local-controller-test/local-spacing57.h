// SPDX-License-Identifier: GPL-3.0-or-later
#pragma once
static void localSpacingVector57(uintptr_t actor,float*side,float*forward){
 if(!isfinite(*side)||!isfinite(*forward)||hypotf(*side,*forward)<.001f)return;
 const Sr1LocalFrame f=readFrame();uintptr_t target=0;uint32_t gen=0;int16_t root[3],point[3];uint16_t yaw;
 if(actor!=player||!f.ready||!f.renderBlend||(!f.grounded&&!f.groundContact48)||f.airState!=SR1_AIR_NONE||localPhysicalCarry(actor)||!localAirStrikeEquipped()||
 !localNearestTarget49(&f,actor,&target,&gen)||generation(target)!=gen||!readAt(actor+0x9c,root,6)||!readAt(target+0x9c,point,6)||
 abs((int)point[2]-root[2])>300||!readAt(actor+sheet_sr1GroundSteering_camera_relative_start.yawOffset,&yaw,2))return;
 const float a=yaw*(6.28318530718f/4096.f),c=cosf(a),s=sinf(a);float dx=c**side-s**forward,dy=s**side+c**forward;
 const float scale=localSpacingClip57((float)point[0]-root[0],(float)point[1]-root[1],(float)sheet_sr1Combat57_spacing_gait_dodge.minimumRadius,&dx,&dy);
 *side=c*dx+s*dy;*forward=-s*dx+c*dy;
 if(scale<1){static _Thread_local uint64_t reported;const uint64_t now=GetTickCount64();if(now-reported>250){record("defiance-spacing target=%u radius=%lld scale=%.3f",gen,(long long)sheet_sr1Combat57_spacing_gait_dodge.minimumRadius,scale);reported=now;}}
}
