// SPDX-License-Identifier: GPL-3.0-or-later
#pragma once
// Cosmetic receipts only. No target selection, native dispatch, damage or position writes here.
#ifdef SR1_LOCAL_COMBAT52
#include "local-fx-target52.h"
#endif
typedef struct {uint64_t tick,session;uintptr_t actor,targetActor;uint32_t world,generation,realm,form,target;int16_t point[3];bool hand,beam,smoke;} LocalFx51;
static SRWLOCK localFxLock51=SRWLOCK_INIT;
static LocalFx51 localFxPool51[64];static unsigned localFxCursor51;
static uint32_t localFxColor51(unsigned form){
 static const uint32_t colors[]={0,0x66e5ff,0x66e5ff,0xb460ff,0xffd970,0x55ffe8,0xff6325,0x3c88ff,0x8ee64d,0xf185ff};
 return form<10?colors[form]:0;
}
static bool localFxCurrent51(const LocalFx51 *fx,const Sr1LocalFrame *f,uintptr_t actor,uint64_t now){
 return fx->tick&&f->ready&&f->renderBlend&&fx->actor==actor&&fx->session==f->session&&fx->world==f->worldGeneration&&
  fx->generation==f->playerGeneration&&fx->realm==(uint32_t)f->realm&&fx->form==localCurrentForm(f->realm)&&
  now>=fx->tick&&now-fx->tick<(uint64_t)
#ifdef SR1_LOCAL_COMBAT52
  ((fx->hand||(!fx->smoke&&fx->beam))?sheet_sr1Combat52_target_cast_camera.castMs:sheet_sr1Combat51_aerial_charged_fx.hitMs);
#else
  (fx->hand?sheet_sr1Combat51_aerial_charged_fx.castMs:sheet_sr1Combat51_aerial_charged_fx.hitMs);
#endif
}
static void localFxEnqueue51(const Sr1LocalFrame *f,uintptr_t actor,uint64_t now,unsigned form,const int16_t point[3],uint32_t target,bool hand,bool beam,bool smoke,uintptr_t attached){
 if(!now||!f->ready||!f->renderBlend||actor!=player||!localFxColor51(form)||form!=localCurrentForm(f->realm)||(!hand&&(!point||!target)))return;
 LocalFx51 fx={.tick=now,.session=f->session,.actor=actor,.targetActor=attached,.world=f->worldGeneration,.generation=f->playerGeneration,.realm=f->realm,.form=form,.target=target,.hand=hand,.beam=beam,.smoke=smoke};
 if(point)memcpy(fx.point,point,6);
 AcquireSRWLockExclusive(&localFxLock51);localFxPool51[localFxCursor51++%64]=fx;ReleaseSRWLockExclusive(&localFxLock51);
 record("defiance-charge-fx form=%u target=%u hand=%u beam=%u smoke=%u",form,target,hand,beam,smoke);
}
static void localFxQueue51(const Sr1LocalFrame *f,uintptr_t actor,uint64_t now,unsigned form,const int16_t point[3],uint32_t target,bool hand,bool beam,bool smoke){localFxEnqueue51(f,actor,now,form,point,target,hand,beam,smoke,0);}
#ifdef SR1_LOCAL_COMBAT52
static void localFxTarget52(const Sr1LocalFrame *f,uintptr_t actor,uint64_t now,unsigned form,uintptr_t target,uint32_t gen,bool smoke){
 int16_t point[3];if(localTargetPoint52(target,gen,f->worldGeneration,point))localFxEnqueue51(f,actor,now,form,point,gen,false,true,smoke,target);
}
static bool localFxActive52(const Sr1LocalFrame *f,uintptr_t actor,uint64_t now){
 bool found=false;AcquireSRWLockShared(&localFxLock51);
 for(unsigned i=0;i<64&&!found;i++)found=localFxCurrent51(&localFxPool51[i],f,actor,now);
 ReleaseSRWLockShared(&localFxLock51);return found;
}
#endif
