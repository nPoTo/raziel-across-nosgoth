// SPDX-License-Identifier: GPL-3.0-or-later
#pragma once

typedef struct {
    int32_t velocity[3], acceleration[3];
} LocalSlamKinematics;

static inline LocalSlamKinematics localSlamStep(const Sheet_sr1LocalAirSlam *policy, bool windup,
    bool enteringFall, int32_t vertical, int32_t gravity, int32_t time) {
    LocalSlamKinematics step = {0};
    if (windup) return step;
    if (enteringFall || vertical > policy->fallVelocity) vertical = (int32_t)policy->fallVelocity;
    if (vertical < policy->terminalVelocity) vertical = (int32_t)policy->terminalVelocity;
    step.velocity[2] = vertical;
    const int32_t cap = (int32_t)((policy->terminalVelocity - vertical) * 4096 / time);
    step.acceleration[2] = gravity < cap ? cap : gravity;
    return step;
}

static inline uint64_t localSlamRecoveryMs(uint64_t donorLength, uint64_t donorContactMs) {
    return donorLength - donorContactMs;
}

#ifdef SR1_LOCAL_SLAM_COAST
static inline int32_t localSlamCoastAxis(int32_t entry, int32_t current, uint64_t age, uint64_t duration) {
    if (age >= duration || !entry || !current || (entry < 0) != (current < 0)) return 0;
    const int64_t remaining = (int64_t)(duration - age);
    const int32_t eased = (int32_t)((int64_t)entry * remaining * remaining / (int64_t)(duration * duration));
    // Preserve any stronger slowdown already imposed by native movement or collision.
    if (entry > 0) return current < eased ? current : eased;
    return current > eased ? current : eased;
}
#endif
