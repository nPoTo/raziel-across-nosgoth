// SPDX-License-Identifier: GPL-3.0-or-later
#pragma once
static DecodeHold originalUtilityDecode55;
static bool localBlockNativeFinish55(int native,uintptr_t caller,const int*message){
 return sheet_sr1Combat55_finish_contact_regen.blockNativeFinish&&native&&message&&*message==(int)C4_NATIVE_FINISH_POST&&
  caller==signals->decodeHoldReturnRva&&localAirStrikeEquipped()&&!localPhysicalCarry(player);
}
static int localUtilityDecode55(int*message,int*value){
 const uintptr_t caller=(uintptr_t)__builtin_return_address(0)-base;const int native=originalUtilityDecode55(message,value);const DWORD error=GetLastError();
 const bool blocked=localBlockNativeFinish55(native,caller,message);if(blocked)record("defiance-native-finisher-blocked caller=%llx",(unsigned long long)caller);
 SetLastError(error);return blocked?0:native;
}
