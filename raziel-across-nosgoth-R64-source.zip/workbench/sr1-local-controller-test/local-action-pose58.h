// SPDX-License-Identifier: GPL-3.0-or-later
#pragma once
// Presentation-only helpers. The native actor root and physics are never changed.
typedef struct{uintptr_t actor;uint32_t generation,world,realm;uint64_t session;}LocalPoseIdentity58;
typedef struct{LocalPoseIdentity58 identity;unsigned kind;uint64_t action,last,start,duration;bool valid;JumpLocal from[66],shown[66];}LocalPoseTransition58;
static bool localPoseSame58(LocalPoseIdentity58 a,LocalPoseIdentity58 b){return a.actor==b.actor&&a.generation==b.generation&&a.world==b.world&&a.realm==b.realm&&a.session==b.session;}
static bool localPoseCompose58(float out[66][13],const JumpLocal local[66],const int16_t parents[66],const float root[13]){
 memcpy(out[0],root,52);for(unsigned b=1;b<66;b++){if(parents[b]<0||parents[b]>=(int)b)return false;float r[9];jumpMatrix(local[b].q,r);memcpy(out[b],root,52);groundComposeBone(out[parents[b]],r,local[b].p,out[b]);if(!skeletonRigid(out[b]))return false;}return true;
}
static bool localGuardUpper58(JumpLocal pose[66],const JumpLocal guard[66],const int16_t parents[66]){
 const float identity[13]={1,0,0,0,1,0,0,0,1,0,0,0,0};float reference[66][13],moving[66][13];JumpLocal relative[66];
 if(!localPoseCompose58(reference,guard,parents,identity)||!localPoseCompose58(moving,pose,parents,identity))return false;
 memcpy(reference[parents[14]],moving[parents[14]],52);if(!jumpLocals(reference,parents,relative))return false;
 for(unsigned b=14;b<50;b++)pose[b]=guard[b];pose[14]=relative[14];return true;
}
static bool localPoseBlend58(LocalPoseTransition58*s,LocalPoseIdentity58 identity,unsigned kind,uint64_t action,uint64_t now,float pose[66][13],const int16_t parents[66],uint64_t enter,uint64_t exit,uint64_t link,uint64_t gap){
 JumpLocal target[66]={0};target[0].q[3]=1;if(!jumpLocals(pose,parents,target)){memset(s,0,sizeof *s);return false;}
 if(!s->valid||!localPoseSame58(s->identity,identity)||now<s->last||now-s->last>gap){
  memset(s,0,sizeof *s);s->identity=identity;s->valid=true;s->kind=kind;s->action=action;s->last=now;memcpy(s->shown,target,sizeof target);return false;
 }
 if(s->kind!=kind||s->action!=action){const bool old=s->kind!=0;memcpy(s->from,s->shown,sizeof s->from);s->start=now;s->duration=old?(kind?link:exit):(kind?enter:0);s->kind=kind;s->action=action;}
 s->last=now;const float alpha=!s->duration?1.f:fminf(1.f,(float)(now-s->start)/(float)s->duration),w=alpha*alpha*(3.f-2.f*alpha);
 for(unsigned b=0;b<66;b++){if(w>=1)s->shown[b]=target[b];else groundBlendLocal(&s->from[b],&target[b],w,&s->shown[b]);}
 if(w>=1)return false;float next[66][13];if(!localPoseCompose58(next,s->shown,parents,pose[0])){memset(s,0,sizeof *s);return false;}memcpy(pose,next,sizeof next);return true;
}
static bool localAlignLimb58(float pose[66][13],unsigned first,unsigned child,unsigned last,const float direction[3],float weight){
 float from[3],to[3],pivot[3],a=0,b=0;if(!isfinite(weight)||weight<=0||first>=child||child>last||last>=66)return false;
 for(unsigned k=0;k<3;k++){pivot[k]=pose[first][10+k];from[k]=pose[child][10+k]-pivot[k];to[k]=direction[k];a+=from[k]*from[k];b+=to[k]*to[k];}
 if(!isfinite(a)||!isfinite(b)||a<.01f||b<.001f)return false;a=sqrtf(a);b=sqrtf(b);float dot=0;
 for(unsigned k=0;k<3;k++){from[k]/=a;to[k]/=b;dot+=from[k]*to[k];}dot=fmaxf(-1,fminf(1,dot));
 float axis[3]={from[1]*to[2]-from[2]*to[1],from[2]*to[0]-from[0]*to[2],from[0]*to[1]-from[1]*to[0]},n=sqrtf(axis[0]*axis[0]+axis[1]*axis[1]+axis[2]*axis[2]);
 if(n<.0001f){if(dot>0)return true;axis[0]=-from[1];axis[1]=from[0];axis[2]=0;n=hypotf(axis[0],axis[1]);if(n<.0001f){axis[0]=1;n=1;}}
 for(unsigned k=0;k<3;k++)axis[k]/=n;for(unsigned bone=first;bone<=last;bone++)for(unsigned k=0;k<13;k++)if(k!=9&&!isfinite(pose[bone][k]))return false;
 const float angle=acosf(dot)*fminf(1,weight),c=cosf(angle),s=sinf(angle),t=1-c,x=axis[0],y=axis[1],z=axis[2];const float r[9]={c+x*x*t,x*y*t-z*s,x*z*t+y*s,y*x*t+z*s,c+y*y*t,y*z*t-x*s,z*x*t-y*s,z*y*t+x*s,c+z*z*t};
 for(unsigned bone=first;bone<=last;bone++){float old[13];memcpy(old,pose[bone],52);for(unsigned row=0;row<3;row++){for(unsigned col=0;col<3;col++){float v=0;for(unsigned k=0;k<3;k++)v+=r[row*3+k]*old[k*3+col];pose[bone][row*3+col]=v;}float v=pivot[row];for(unsigned k=0;k<3;k++)v+=r[row*3+k]*(old[10+k]-pivot[k]);pose[bone][10+row]=v;}}return true;
}
static bool localRotorT58(float pose[66][13],float weight){
 if(!isfinite(weight)||weight<=0)return false;float pivot[3],axis[3];if(!bodyAxisFromPose(pose,pivot,axis))return false;
 float down[3],right[3],left[3],dot=0;for(unsigned k=0;k<3;k++){down[k]=-axis[k];right[k]=pose[41][10+k]-pose[39][10+k];dot+=right[k]*axis[k];}
 for(unsigned k=0;k<3;k++){right[k]-=dot*axis[k];left[k]=-right[k];}if(hypotf(hypotf(right[0],right[1]),right[2])<1)return false;
 float scratch[66][13];memcpy(scratch,pose,sizeof scratch);
 if(!localAlignLimb58(scratch,6,7,9,down,weight)||!localAlignLimb58(scratch,7,8,9,down,weight)||
 !localAlignLimb58(scratch,10,11,13,down,weight)||!localAlignLimb58(scratch,11,12,13,down,weight)||
 !localAlignLimb58(scratch,39,40,49,right,weight)||!localAlignLimb58(scratch,40,41,49,right,weight)||
 !localAlignLimb58(scratch,29,30,37,left,weight)||!localAlignLimb58(scratch,30,31,37,left,weight))return false;
 memcpy(pose,scratch,sizeof scratch);return true;
}
