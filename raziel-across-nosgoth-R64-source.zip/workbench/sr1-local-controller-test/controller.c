// SPDX-License-Identifier: GPL-3.0-or-later
#include "controller.h"

Sr1LocalCommand sr1LocalUpdate(Sr1LocalController *state, const Sr1LocalFrame *frame) {
    Sr1LocalCommand command = {0};
    if (!frame->session || !frame->serial) {
        state->ownsControl = false;
        command.apply = true;
        return command;
    }

    const bool sameSession = state->session == frame->session;
    if (sameSession && frame->serial <= state->serial) return command;
    command.apply = true;

    const bool samePlayer = sameSession && state->realm == frame->realm &&
        state->worldGeneration == frame->worldGeneration &&
        state->playerGeneration == frame->playerGeneration;
    const uint8_t edges = samePlayer && state->ownsControl ?
        frame->pressed & (uint8_t)~state->previousPressed : 0;
    const bool playableRealm = frame->realm == SR1_LOCAL_MATERIAL || frame->realm == SR1_LOCAL_SPECTRAL;
    const bool mayControl = frame->ready && !frame->nativeControl && playableRealm &&
        frame->worldGeneration && frame->playerGeneration;

    *state = (Sr1LocalController){
        .session = frame->session, .serial = frame->serial,
        .worldGeneration = frame->worldGeneration, .playerGeneration = frame->playerGeneration,
        .realm = frame->realm, .previousPressed = frame->pressed, .ownsControl = mayControl
    };
    if (!mayControl) return command;

    command.ownsControl = true;
    command.moveX = frame->moveX;
    command.moveY = frame->moveY;
    if ((edges & SR1_LOCAL_PRESS_FINISH) && frame->grounded && frame->finishTargetGeneration) {
        command.action = SR1_LOCAL_FINISH;
        command.finishTargetGeneration = frame->finishTargetGeneration;
    } else if (edges & SR1_LOCAL_PRESS_STRIKE) {
        command.action = SR1_LOCAL_STRIKE;
    } else if ((edges & SR1_LOCAL_PRESS_JUMP) && frame->grounded) {
        command.action = SR1_LOCAL_JUMP;
    }
    return command;
}
