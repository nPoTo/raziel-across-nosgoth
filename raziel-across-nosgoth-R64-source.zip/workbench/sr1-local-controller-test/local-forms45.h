// SPDX-License-Identifier: GPL-3.0-or-later
#pragma once
#include <Xinput.h>
#include <stdatomic.h>
#include "local-forms45-proof.h"
#ifdef SR1_LOCAL_BATTLE46
#include "local-wheel46.h"
#endif
typedef struct {uintptr_t actor;uint32_t world,generation,realm,abilities,mask,selected;} LocalForms45;
static LocalForms45 localForms;
static SRWLOCK localFormsLock=SRWLOCK_INIT;
static DWORD (WINAPI *localFormsPad)(DWORD,XINPUT_STATE *);
static uint32_t localFormsMask(uint32_t realm,uint32_t abilities,uint32_t mirror) {
 if(abilities!=mirror || !(abilities&sheet_sr1Forms45_release_02.acquired))return 0;
 if(realm==SR1_LOCAL_SPECTRAL)return 1u;
 if(realm!=SR1_LOCAL_MATERIAL)return 0;
 uint32_t mask=0;for(unsigned i=1;i<9;i++)if((abilities&sheet_sr1Form45_rows[i]->required)==sheet_sr1Form45_rows[i]->required)mask|=1u<<i;
 return mask;
}
static unsigned localFormsCycle(unsigned selected,uint32_t mask,int direction) {
 static const unsigned order[]={0,1,2,3,4,6,5,7,8,9,16,17,18};
 unsigned start=13;for(unsigned i=0;i<13;i++)if(order[i]==selected)start=i;
 if(start==13)return mask&2u?2:0;
 for(unsigned n=1;n<13;n++){unsigned next=order[(start+(direction>0?n:13-n))%13];if(next>=2&&next<=9&&(mask&(1u<<(next-1))))return next;}
 return 0;
}
static unsigned localFormsDamage(uint32_t realm,unsigned form,uint32_t abilities,uint32_t mirror) {
 if(!form||!(localFormsMask(realm,abilities,mirror)&(1u<<(form-1))))return 0;
 if(form==9)return sheet_sr1Forms45_release_02.spiritDamage;
 unsigned damage=sheet_sr1Forms45_release_02.baseDamage;
 for(unsigned i=2;i<8;i++)if((abilities&sheet_sr1Form45_rows[i]->required)==sheet_sr1Form45_rows[i]->required)damage+=sheet_sr1Forms45_release_02.perElement;
 return damage;
}
static LocalForms45 localFormsRead(void){LocalForms45 s;AcquireSRWLockShared(&localFormsLock);s=localForms;ReleaseSRWLockShared(&localFormsLock);return s;}
static unsigned localCurrentForm(unsigned realm) {
 const LocalForms45 s=localFormsRead();uintptr_t actor=0;uint32_t abilities=0,mirror=0;
 if(s.realm!=realm || !s.actor || !readAt(base+host->actorRva,&actor,8)||actor!=s.actor ||
  generation(actor)!=s.generation || !readAt(base+acquisition->abilitiesRva,&abilities,4)||
  !readAt(base+acquisition->mirrorRva,&mirror,4))return 0;
 return s.selected&&(localFormsMask(realm,abilities,mirror)&(1u<<(s.selected-1)))?s.selected:0;
}
static void localFormsInput(const Sr1LocalFrame *frame,uintptr_t actor) {
 static uint32_t previous;static bool admitted;
 XINPUT_STATE padState={0};uint32_t buttons=0;
 if(localFormsPad&&localFormsPad(0,&padState)==ERROR_SUCCESS)buttons=padState.Gamepad.wButtons&0xcu;
 if(GetAsyncKeyState((int)sheet_sr1Forms45_release_02.previousKey)&0x8000)buttons|=4;
 if(GetAsyncKeyState((int)sheet_sr1Forms45_release_02.nextKey)&0x8000)buttons|=8;
#ifdef SR1_LOCAL_BATTLE46
 buttons|=localDigitBits46();
#endif
 // Preserve only the selection preference during an unreadable/background frame.
 // Every use still revalidates actual actor/generation/acquisition; no cached grant.
 if(!frame->playerGeneration||!frame->worldGeneration){
#ifdef SR1_LOCAL_BATTLE46
  localWheelSteps46(false);
#endif
  admitted=false;previous=buttons;return;}
 uint32_t abilities=0,mirror=0;LocalForms45 next={0};
 const bool known=actor&&
  readAt(base+acquisition->abilitiesRva,&abilities,4)&&readAt(base+acquisition->mirrorRva,&mirror,4);
#ifdef SR1_LOCAL_COMBAT48
 if(!known){admitted=false;previous=buttons;localWheelSteps46(false);return;}
#endif
 const bool live=known&&frame->ready&&frame->renderBlend;
#ifdef SR1_LOCAL_BATTLE46
 const int wheel=localWheelSteps46(live&&localFormsMask(frame->realm,abilities,mirror)!=0);
#endif
 if(known){next=(LocalForms45){actor,frame->worldGeneration,frame->playerGeneration,frame->realm,abilities,localFormsMask(frame->realm,abilities,mirror),0};}
 AcquireSRWLockExclusive(&localFormsLock);
 const bool same=next.actor&&next.actor==localForms.actor&&next.world==localForms.world&&next.generation==localForms.generation&&next.realm==localForms.realm;
#ifdef SR1_LOCAL_BATTLE46
 if(!same||!admitted)localWheelSteps46(false);
#endif
 const bool preference=
#ifdef SR1_LOCAL_COMBAT48
 next.actor && next.actor==localForms.actor && next.generation==localForms.generation && next.realm==localForms.realm;
#else
 same;
#endif
 if(next.mask){next.selected=preference&&localForms.selected&&(next.mask&(1u<<(localForms.selected-1)))?localForms.selected:(next.realm==SR1_LOCAL_SPECTRAL?1:2);}
 const uint32_t edge=live&&admitted&&same?buttons&~previous:0;
#ifdef SR1_LOCAL_BATTLE46
 const unsigned direct=localDigitSelect46(edge,next.realm,next.mask);
 if(direct)next.selected=direct;
 else if(next.realm==SR1_LOCAL_MATERIAL){
  const unsigned cycle=edge&12u;
  if(cycle==4||cycle==8){const unsigned changed=localFormsCycle(next.selected,next.mask,cycle==4?
#ifdef SR1_LOCAL_COMBAT59
 1:-1
#else
 -1:1
#endif
 );if(changed)next.selected=changed;}
  else if(live&&admitted&&same)for(int n=0;n<(wheel<0?-wheel:wheel);n++){const unsigned changed=localFormsCycle(next.selected,next.mask,wheel>0?1:-1);if(changed)next.selected=changed;}
 }
#else
 if(next.realm==SR1_LOCAL_MATERIAL&&(edge==4||edge==8)){const unsigned changed=localFormsCycle(next.selected,next.mask,edge==4?-1:1);if(changed)next.selected=changed;}
#endif
#ifdef SR1_LOCAL_LOCK47
 if(live&&admitted&&same&&(direct||(edge&12u)||wheel))
  record("reaver-selection-input source=%s edge=%x wheel=%d selected=%u changed=%u",direct?"digit":(edge&12u)?"cycle":"wheel",edge,wheel,next.selected,next.selected!=localForms.selected);
#endif
 if(next.selected!=localForms.selected||next.mask!=localForms.mask||next.generation!=localForms.generation)
  record("reaver-forms selected=%u mask=%02x abilities=%08x damage=%u realm=%u",next.selected,next.mask,abilities,localFormsDamage(next.realm,next.selected,abilities,mirror),next.realm);
 localForms=next;ReleaseSRWLockExclusive(&localFormsLock);
 admitted=live;previous=buttons;
}
static bool localFormsPrepare(void) {
 wchar_t dll[MAX_PATH];const UINT n=GetSystemDirectoryW(dll,ARRAYSIZE(dll));
 if(n&&n+16<ARRAYSIZE(dll)){wcscat(dll,L"\\xinput1_4.dll");HMODULE m=LoadLibraryW(dll);if(m)localFormsPad=(void *)GetProcAddress(m,"XInputGetState");}
 // Same three byte-gated health-only branches used by the original mod.
 static const struct {uintptr_t start;unsigned offset,size;unsigned char bytes[16];} patches[]=LOCAL_FORMS_HEALTH_BRANCHES;
 for(unsigned i=0;i<ARRAYSIZE(patches);i++)if(!matches(patches[i].start,patches[i].bytes,patches[i].size))return false;
 unsigned written=0;bool complete=true;
 for(;written<ARRAYSIZE(patches);written++){
  const uintptr_t at=base+patches[written].start+patches[written].offset;DWORD flags,ignored;
  if(!VirtualProtect((void *)at,1,PAGE_EXECUTE_READWRITE,&flags))break;
  unsigned char old=patches[written].bytes[patches[written].offset];
  const bool ok=atomic_compare_exchange_strong((_Atomic unsigned char *)at,&old,0xebu);
  const bool restored=VirtualProtect((void *)at,1,flags,&ignored)!=0;
  FlushInstructionCache(GetCurrentProcess(),(void *)at,1);
  if(!ok||!restored){if(ok)written++;complete=false;break;}
 }
 if(complete&&written==ARRAYSIZE(patches)){record("reaver-health acquired-only branches=3 active health-unmodified=1");return true;}
 while(written){const unsigned i=--written;const uintptr_t at=base+patches[i].start+patches[i].offset;DWORD flags,ignored;if(VirtualProtect((void *)at,1,PAGE_EXECUTE_READWRITE,&flags)){unsigned char expected=0xeb;atomic_compare_exchange_strong((_Atomic unsigned char *)at,&expected,patches[i].bytes[patches[i].offset]);VirtualProtect((void *)at,1,flags,&ignored);FlushInstructionCache(GetCurrentProcess(),(void *)at,1);}}
 return false;
}
