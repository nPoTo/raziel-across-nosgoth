// SPDX-License-Identifier: GPL-3.0-or-later
#pragma once

typedef int (*NativeStrikeKey)(uintptr_t, int32_t);
static NativeStrikeKey originalNativeStrikeKey;
static const Sheet_sr1LocalComboAdmission *const comboAdmission = &sheet_sr1LocalComboAdmission_spectral_third_native;
static _Thread_local struct {
    LocalActionOwner secondRequest, queuedThird, forwardedThird;
    uintptr_t secondStrike;
#if (defined(SR1_LOCAL_SPECIAL_INPUT) && !defined(SR1_LOCAL_COMBAT_SYNC42)) || (defined(SR1_LOCAL_COMBAT_LINKS) && !defined(SR1_LOCAL_COMBAT_REPAIR))
    LocalActionOwner forwardedSecond;
    uintptr_t firstStrike;
#endif
#if defined(SR1_LOCAL_SPECIAL_INPUT) && !defined(SR1_LOCAL_COMBAT_SYNC42)
    LocalActionOwner phase;
    uintptr_t phaseIdentity;
    unsigned phaseOrdinal;
#endif
#ifdef SR1_LOCAL_GROUND_ACTIONS
    bool secondForwarded;
#endif
} groundedChain;

#ifdef SR1_LOCAL_COMBAT_CONTINUITY
static SRWLOCK continuationLock=SRWLOCK_INIT;
static LocalActionOwner continuationOwner;
static unsigned continuationMask;

static bool hasGroundContinuation(const Sr1LocalFrame *frame,uintptr_t actor,uint64_t now,unsigned ordinal) {
    AcquireSRWLockShared(&continuationLock);
    const bool pending=ordinal<2 && (continuationMask&(1u<<(ordinal+1))) &&
        sameLocalAction(&continuationOwner,frame,actor,now,comboAdmission->maxBufferedAgeMs);
    ReleaseSRWLockShared(&continuationLock);
    return pending;
}
#endif

#ifdef SR1_LOCAL_GROUND_ACTIONS
typedef void (*NativeGroundSwitch)(uintptr_t, int32_t, uintptr_t, uintptr_t);
static NativeGroundSwitch originalGroundSwitch;
static _Thread_local LocalActionOwner movingStrikePress;
#ifdef SR1_LOCAL_COMBAT_TEMPO
static _Thread_local LocalActionOwner groundRestartPress;
static _Thread_local bool groundRestartHeld;
#endif

static void nativeGroundSwitch(uintptr_t state, int32_t section, uintptr_t callback, uintptr_t entry) {
    const uintptr_t caller = (uintptr_t)__builtin_return_address(0);
#ifdef SR1_LOCAL_LOCK47
    if (state==base+(uintptr_t)host->stateActorRva && section>=0 && section<3 &&
        callback==base+(uintptr_t)sheet_sr1Lock47_locked_combat.extraCombatRva) {
        const DWORD error=GetLastError();const Sr1LocalFrame frame=readFrame();
        LocalActionOwner press={0};uint32_t abilities=0,mirror=0,kind=0;
        if(TryAcquireSRWLockShared(&strikeLock)){press=strikePress;ReleaseSRWLockShared(&strikeLock);}
        if(frame.ready && frame.renderBlend && frame.realm!=SR1_LOCAL_UNKNOWN && !localPhysicalCarry(player) &&
#ifdef SR1_LOCAL_COMBAT48
            !localPhysicalPickup48(&frame,player) &&
#endif
            sameLocalAction(&press,&frame,player,GetTickCount64(),900) &&
            readAt(base+acquisition->abilitiesRva,&abilities,4) && readAt(base+acquisition->mirrorRva,&mirror,4) &&
            abilities==mirror && (abilities&combatPolicy->reaverAbility) &&
            readAt(base+host->interactionTypeRva,&kind,4) && kind==0x1000) {
            callback=base+(uintptr_t)combatPolicy->nativeAttackRva;entry=(uintptr_t)groundActions->standingEntry;
            record("defiance-reaver-route section=%ld realm=%u",(long)section,frame.realm);
        }
        SetLastError(error);
    }
#endif
    if (caller == base + (uintptr_t)groundActions->movingAttackReturnRva &&
        state == base + (uintptr_t)host->stateActorRva && section == 0 &&
        callback == base + (uintptr_t)combatPolicy->nativeAttackRva &&
        entry == (uintptr_t)groundActions->movingEntry && movingStrikePress.tick) {
        const DWORD error = GetLastError();
        const Sr1LocalFrame frame = readFrame();
        if (frame.ready && sameLocalAction(&movingStrikePress, &frame, player, GetTickCount64(),
                groundActions->pressLeaseMs)) {
            entry = (uintptr_t)groundActions->standingEntry;
            movingStrikePress = (LocalActionOwner){0};
            record("defiance-moving-strike-entry realm=%u", frame.realm);
        }
        SetLastError(error);
    }
    originalGroundSwitch(state, section, callback, entry);
}

#ifdef SR1_LOCAL_COMBAT48
static void (*originalCharacter48)(uintptr_t,uintptr_t,uintptr_t);
static void localCharacter48(uintptr_t state,uintptr_t callback,uintptr_t entry){
 if(state==base+(uintptr_t)host->stateActorRva&&callback==base+(uintptr_t)sheet_sr1Lock47_locked_combat.extraCombatRva){
  const DWORD error=GetLastError();const Sr1LocalFrame frame=readFrame();LocalActionOwner press={0};uint32_t powers=0,mirror=0,kind=0;
  if(TryAcquireSRWLockShared(&strikeLock)){press=strikePress;ReleaseSRWLockShared(&strikeLock);}
  if(frame.ready&&frame.renderBlend&&!localPhysicalCarry(player)&&!localPhysicalPickup48(&frame,player)&&sameLocalAction(&press,&frame,player,GetTickCount64(),900)&&
   readAt(base+acquisition->abilitiesRva,&powers,4)&&readAt(base+acquisition->mirrorRva,&mirror,4)&&powers==mirror&&(powers&combatPolicy->reaverAbility)&&
   readAt(base+host->interactionTypeRva,&kind,4)&&kind==0x1000){
    callback=base+(uintptr_t)combatPolicy->nativeAttackRva;entry=(uintptr_t)groundActions->standingEntry;
    record("defiance-character-route realm=%u",frame.realm);
  }SetLastError(error);
 }
 originalCharacter48(state,callback,entry);
}
#endif
#ifdef SR1_LOCAL_COMBAT57
static void localCancelCombo57(void){
 memset(&groundedChain,0,sizeof groundedChain);groundRestartPress=(LocalActionOwner){0};groundRestartHeld=false;movingStrikePress=(LocalActionOwner){0};
 AcquireSRWLockExclusive(&groundXLock);groundXPlayback=(LocalGroundX){0};ReleaseSRWLockExclusive(&groundXLock);
 AcquireSRWLockExclusive(&strikeLock);strikePress=(LocalActionOwner){0};ReleaseSRWLockExclusive(&strikeLock);
 AcquireSRWLockExclusive(&continuationLock);continuationOwner=(LocalActionOwner){0};continuationMask=0;ReleaseSRWLockExclusive(&continuationLock);
 record("defiance-combo-retired-for-action");
}
#endif
static bool requestGroundCombo(NativePad *output, const Sr1LocalFrame *frame, uint32_t attack, bool authoredStrike) {
#ifdef SR1_LOCAL_COMBAT57
 if(localDodgeBusy56(frame,player,GetTickCount64())){localCancelCombo57();output->pressed&=~attack;output->held&=~attack;return false;}
#endif
    const uint64_t now = GetTickCount64();
    const bool edge = (output->pressed & attack) != 0;
#ifdef SR1_LOCAL_COMBAT_TEMPO
    const bool restartEdge = edge && !groundRestartHeld;
    groundRestartHeld = (output->held & attack) != 0;
    const uint64_t restartWindow = sheet_sr1LocalGroundComboRestart_ground_combo_restart.bufferMs;
    const bool canRetainRestart = frame->ready && frame->renderBlend && frame->realm != SR1_LOCAL_UNKNOWN &&
        frame->airState == SR1_AIR_NONE;
    if (!canRetainRestart || !sameLocalAction(&groundRestartPress, frame, player, now, restartWindow))
        groundRestartPress = (LocalActionOwner){0};
    if (canRetainRestart && restartEdge &&
        ((frame->groundStrike && frame->strikeOrdinal == 2) || (authoredStrike && !frame->groundStrike))) {
        groundRestartPress = localActionOwner(frame, player, now);
    }
#endif
    if (!frame->groundStrike && !frame->strikePending && !frame->strikeTransition) {
        memset(&groundedChain, 0, sizeof(groundedChain));
#ifdef SR1_LOCAL_COMBAT_CONTINUITY
        AcquireSRWLockExclusive(&continuationLock);
        continuationOwner=(LocalActionOwner){0};
        continuationMask=0;
        ReleaseSRWLockExclusive(&continuationLock);
#endif
#ifdef SR1_LOCAL_COMBAT_TEMPO
        if (!authoredStrike && canRetainRestart && frame->grounded && !frame->nativeControl && groundRestartPress.tick) {
            groundRestartPress = (LocalActionOwner){0};
            output->pressed |= attack;
            record("defiance-ground-x-restart realm=%u", frame->realm);
            return true;
        }
#endif
        if (!authoredStrike) return edge;
        output->pressed &= ~attack;
        return false;
    }

    output->pressed &= ~attack;
    const bool first = frame->groundStrike && frame->strikeOrdinal == 0;
    const bool second = frame->groundStrike && frame->strikeOrdinal == 1;
#if defined(SR1_LOCAL_SPECIAL_INPUT) && !defined(SR1_LOCAL_COMBAT_SYNC42)
    if ((first||second) && (!sameLocalAction(&groundedChain.phase,frame,player,now,UINT64_MAX) ||
        groundedChain.phaseIdentity!=frame->strikeIdentity || groundedChain.phaseOrdinal!=frame->strikeOrdinal)) {
        groundedChain.phase=localActionOwner(frame,player,now);
        groundedChain.phaseIdentity=frame->strikeIdentity;
        groundedChain.phaseOrdinal=frame->strikeOrdinal;
    }
    const bool timedLink=(first||second) && now>=groundedChain.phase.tick &&
        now-groundedChain.phase.tick>=combatGroundLinkMs(frame->strikeOrdinal);
#endif
    if (edge && (first || frame->strikePending) && !groundedChain.secondRequest.tick) {
        groundedChain.secondRequest = localActionOwner(frame, player, now);
    } else if (edge && (first || second || frame->strikePending) && !groundedChain.queuedThird.tick &&
        !groundedChain.forwardedThird.tick) {
        groundedChain.queuedThird = localActionOwner(frame, player, now);
    }
#ifdef SR1_LOCAL_COMBAT_CONTINUITY
    if (edge && (first || second || frame->strikePending)) {
        AcquireSRWLockExclusive(&continuationLock);
        continuationOwner=localActionOwner(frame,player,now);
        continuationMask=(groundedChain.secondRequest.tick ? 2u : 0u) |
            (groundedChain.queuedThird.tick || groundedChain.forwardedThird.tick ? 4u : 0u);
        ReleaseSRWLockExclusive(&continuationLock);
    }
#endif
    if (!frame->strikeKey) return false;
    if (first && !groundedChain.secondForwarded &&
#if defined(SR1_LOCAL_SPECIAL_INPUT) && !defined(SR1_LOCAL_COMBAT_SYNC42)
        timedLink &&
#else
        frame->strikeKey >= frame->strikeGate &&
#endif
        sameLocalAction(&groundedChain.secondRequest, frame, player, now, comboAdmission->maxBufferedAgeMs)) {
        groundedChain.secondForwarded = true;
#if (defined(SR1_LOCAL_SPECIAL_INPUT) && !defined(SR1_LOCAL_COMBAT_SYNC42)) || (defined(SR1_LOCAL_COMBAT_LINKS) && !defined(SR1_LOCAL_COMBAT_REPAIR))
        groundedChain.forwardedSecond=localActionOwner(frame,player,now);
        groundedChain.firstStrike=frame->strikeIdentity;
#endif
        output->pressed |= attack;
        return true;
    }
    if (second &&
#if defined(SR1_LOCAL_SPECIAL_INPUT) && !defined(SR1_LOCAL_COMBAT_SYNC42)
        timedLink &&
#endif
        sameLocalAction(&groundedChain.queuedThird, frame, player, now, comboAdmission->maxBufferedAgeMs)) {
        groundedChain.queuedThird = (LocalActionOwner){0};
        groundedChain.forwardedThird = localActionOwner(frame, player, now);
        groundedChain.secondStrike = frame->strikeIdentity;
        output->pressed |= attack;
        return true;
    }
    return false;
}
#else
static bool requestThirdNativeStrike(NativePad *output, const Sr1LocalFrame *frame, uint32_t attack) {
    const uint64_t now = GetTickCount64();
    const bool edge = (output->pressed & attack) != 0;
    if (!frame->groundStrike) {
        if (frame->grounded || !frame->renderBlend) memset(&groundedChain, 0, sizeof(groundedChain));
        return edge;
    }
    if (frame->strikeOrdinal == 0 && edge) {
        if (sameLocalAction(&groundedChain.secondRequest, frame, player, now, comboAdmission->maxBufferedAgeMs)) {
            groundedChain.queuedThird = localActionOwner(frame, player, now);
        } else {
            groundedChain.secondRequest = localActionOwner(frame, player, now);
        }
    }
    if (frame->strikeOrdinal != 1) return edge;
    const bool buffered = sameLocalAction(&groundedChain.queuedThird, frame, player, now, comboAdmission->maxBufferedAgeMs);
    if (!edge && !buffered) return false;
    groundedChain.queuedThird = (LocalActionOwner){0};
    groundedChain.forwardedThird = localActionOwner(frame, player, now);
    groundedChain.secondStrike = frame->strikeIdentity;
    if (buffered) output->pressed |= attack;
    return true;
}
#endif

static int nativeStrikeKey(uintptr_t state, int32_t section) {
    const uintptr_t caller = (uintptr_t)__builtin_return_address(0);
    const int original = originalNativeStrikeKey(state, section);
    if (caller != base + (uintptr_t)comboAdmission->keyCallerReturnRva || section != 1 ||
        state != base + (uintptr_t)host->stateActorRva ||
#if (defined(SR1_LOCAL_SPECIAL_INPUT) && !defined(SR1_LOCAL_COMBAT_SYNC42)) || (defined(SR1_LOCAL_COMBAT_LINKS) && !defined(SR1_LOCAL_COMBAT_REPAIR))
        (!groundedChain.forwardedSecond.tick && !groundedChain.forwardedThird.tick)
#else
        !groundedChain.forwardedThird.tick
#endif
    ) return original;
    const DWORD error = GetLastError();
    const Sr1LocalFrame frame = readFrame();
    const uint64_t now = GetTickCount64();
    int result = original;
#if (defined(SR1_LOCAL_SPECIAL_INPUT) && !defined(SR1_LOCAL_COMBAT_SYNC42)) || (defined(SR1_LOCAL_COMBAT_LINKS) && !defined(SR1_LOCAL_COMBAT_REPAIR))
    if (frame.groundStrike && frame.strikeOrdinal==0 && frame.strikeIdentity==groundedChain.firstStrike &&
        sameLocalAction(&groundedChain.forwardedSecond,&frame,player,now,comboAdmission->maxBufferedAgeMs)) {
        uint8_t descriptor[6];
        uint16_t clip;
        if (readAt(frame.strikeIdentity,descriptor,sizeof(descriptor)) &&
            readAt(player+0x3c4,&clip,sizeof(clip)) && descriptor[0]==clip && descriptor[5]==frame.strikeGate &&
            result<descriptor[5]) result=descriptor[5];
    }
#endif
    if (frame.groundStrike && frame.strikeOrdinal == 1 && frame.strikeIdentity == groundedChain.secondStrike &&
        sameLocalAction(&groundedChain.forwardedThird, &frame, player, now,
#if defined(SR1_LOCAL_COMBAT_LINKS) && !defined(SR1_LOCAL_COMBAT_REPAIR)
            comboAdmission->maxBufferedAgeMs
#else
            comboAdmission->maxContinuationAgeMs
#endif
        )) {
        uint8_t descriptor[6], keyUnit;
        uintptr_t keys;
        if (readAt(frame.strikeIdentity, descriptor, sizeof(descriptor)) &&
            descriptor[0] == comboAdmission->nativeSecondClip && descriptor[5] == comboAdmission->nativeSecondGate &&
            readAt(player + combatPolicy->sectionOffset + combatPolicy->keylistOffset, &keys, sizeof(keys)) && keys &&
            readAt(keys + 1, &keyUnit, sizeof(keyUnit)) && keyUnit &&
            (frame.strikeEnd - 1) / keyUnit < descriptor[5]) {
            // The exact caller stores the return only for its next-attack input gate.
            // Its own messages still decide whether to advance and whether a swing hits.
            result = descriptor[5];
        }
    }
    SetLastError(error);
    return result;
}
