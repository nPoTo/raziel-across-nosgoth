// SPDX-License-Identifier: GPL-3.0-or-later
#pragma once

#include "local-measured-combo.h"
#include "ground-x-proof.h"
#ifdef SR1_LOCAL_THIRD_FINISH
#include "ground-x-finish-proof.h"
#endif

static const Sheet_sr1LocalGroundX *const groundXTiming = &sheet_sr1LocalGroundX_authored_ground_combo;

static inline uint64_t groundXDuration(unsigned ordinal) {
    if (ordinal == 0) return groundXTiming->firstMs;
    if (ordinal == 1) return groundXTiming->secondMs;
    return combatTiming->groundThirdMs;
}

static inline float groundXSourceAge(unsigned ordinal, uint64_t age) {
#ifdef SR1_LOCAL_X_TEMPO
    const float baseAge = (float)age * groundXBaseRate();
    if (ordinal != 2) return baseAge;
    const float extraAge = groundXThirdRampAge((float)age);
    const float ramp = (float)groundXTempo->rampMs;
    const float inRamp = fminf(extraAge, ramp);
    return baseAge + groundXThirdRateGain() * (inRamp * inRamp / (2.f * ramp) + extraAge - inRamp);
#else
    (void)ordinal;
    return (float)age;
#endif
}

#ifdef SR1_LOCAL_CALIBRATED_COMBAT
static inline uint64_t groundXPlaybackAge(unsigned ordinal, uint64_t age) {
    if (ordinal != 2) return age;
    // R30 reaches its last 60 Hz third-strike sample at 821 ms.
    const uint64_t sourceEnd = 821;
    const uint64_t measuredEnd = sheet_sr1CombatGroundReference_third.chainMs;
    return age >= measuredEnd ? sourceEnd : age * sourceEnd / measuredEnd;
}
#else
static inline uint64_t groundXPlaybackAge(unsigned ordinal, uint64_t age) {
    (void)ordinal;
    return age;
}
#endif

static inline bool groundXHasRemaining(unsigned ordinal, uint64_t age) {
    uint64_t duration = groundXDuration(ordinal);
#ifdef SR1_LOCAL_COMBAT_RHYTHM
    if (ordinal == 2) {
        // Last inclusive 60 Hz pose and the final recoil sample; the source clip has trailing time.
        const uint64_t lastPoseMs = ((uint64_t)(localStrikePoses[2] - 1) * 1000 + 59) / 60;
        duration = (uint64_t)groundXTiming->thirdClockOffsetMs + lastPoseMs;
    }
#endif
    return groundXSourceAge(ordinal, age) < (float)duration;
}

static inline float groundXSampleAtAge(unsigned ordinal, float sourceAge, unsigned count) {
    const uint64_t offset = ordinal == 0 ? groundXTiming->firstClockOffsetMs :
        ordinal == 1 ? groundXTiming->secondClockOffsetMs : groundXTiming->thirdClockOffsetMs;
    // Archive keys are resampled at 60 Hz. The capture includes the native entry interpolation.
    return fminf((float)(count - 1), fmaxf(0.f, sourceAge - (float)offset) * .060f);
}

static inline float groundXSample(unsigned ordinal, uint64_t age, unsigned count) {
    return groundXSampleAtAge(ordinal, fminf(groundXSourceAge(ordinal, age), (float)groundXDuration(ordinal)), count);
}

#ifdef SR1_LOCAL_COMBO_FLOW
static inline float groundXFlowSample(unsigned ordinal, uint64_t age, unsigned count) {
    if (ordinal == 2) return groundXSample(ordinal, age, count);
    const Sheet_sr1LocalGroundStrikeFlow *const flow = &sheet_sr1LocalGroundStrikeFlow_ground_links;
    const float afterWindup = groundXSampleAtAge(ordinal, groundXSourceAge(ordinal, flow->tailStartMs), count);
    // Use the remaining authored motion through the observed next-strike boundary.
    if (age < (uint64_t)flow->tailStartMs)
        return afterWindup * (float)age / (float)flow->tailStartMs;
    const float tail = fminf(1.f, (float)(age - flow->tailStartMs) / (float)(flow->linkMs - flow->tailStartMs));
    return afterWindup + tail * ((float)(count - 1) - afterWindup);
}
#endif

#ifdef SR1_LOCAL_X_TEMPO
static inline float limitThirdDriveAtTempo(float step, uint64_t dt, uint64_t age) {
    const float gain = groundXThirdRateGain() *
        fminf(1.f, groundXThirdRampAge((float)age) / (float)groundXTempo->rampMs);
    const float rate = groundXBaseRate() + gain;
    return rate * limitThirdDrive(step / rate, dt);
}
#endif

#ifdef SR1_LOCAL_THIRD_FINISH
static const Sheet_sr1LocalThirdFinish *const thirdFinish = &sheet_sr1LocalThirdFinish_ground_x_third_finish;

static inline bool groundXBlocksRestart(bool ownsStroke, bool nativeStrike) {
    return ownsStroke && !nativeStrike;
}

static inline float groundXThirdRecoil(float sample, float firstDistance) {
    const unsigned last = sizeof(groundXRecoilCenti) / sizeof(groundXRecoilCenti[0]) - 1;
    const float key = fminf((float)last, fmaxf(0.f, sample - thirdFinish->recoilFirstSample));
    const unsigned lower = (unsigned)fminf(key, (float)(last - 1));
    const float a = groundXRecoilCenti[lower], b = groundXRecoilCenti[lower + 1];
    return firstDistance * (a + (key - lower) * (b - a)) /
        (float)sheet_sr1LocalMeasuredCombo_ordinary_ground_chain.referenceFirstTravelCenti;
}

static inline float bladeSocketEnvelope(float sample, float begin, float full, float release, float end) {
    if (sample <= begin || sample >= end) return 0.f;
    const float in = fminf(1.f, (sample - begin) / (full - begin));
    const float out = fminf(1.f, (end - sample) / (end - release));
    const float blend = in * out;
    return blend * blend * (3.f - 2.f * blend);
}

#ifdef SR1_LOCAL_THIRD_SWEEP
static const Sheet_sr1LocalThirdSweep *const thirdSweep = &sheet_sr1LocalThirdSweep_third_x_low_sweep;

static inline float groundXLowSweepWeight(float sample) {
    return bladeSocketEnvelope(sample, thirdSweep->beginSample, thirdSweep->fullSample,
        thirdSweep->releaseSample, thirdSweep->endSample);
}
#endif

static inline float groundXBladeSocketWeight(float sample) {
    const float final = bladeSocketEnvelope(sample, thirdFinish->bladeBeginSample, thirdFinish->bladeFullSample,
        thirdFinish->bladeReleaseSample, thirdFinish->bladeEndSample);
#ifdef SR1_LOCAL_THIRD_SWEEP
    return fmaxf(final, groundXLowSweepWeight(sample));
#else
    return final;
#endif
}

#ifdef SR1_LOCAL_BLADE_ARC
static const Sheet_sr1LocalThirdBladeArc *const thirdBladeArc = &sheet_sr1LocalThirdBladeArc_continuous_third_x;

static inline float groundXBladeArcWeight(float sample) {
    const float begin = thirdBladeArc->beginSample, full = thirdBladeArc->fullSample;
    const float progress = fminf(1.f, fmaxf(0.f, (sample - begin) / (full - begin)));
    return progress * progress * (3.f - 2.f * progress);
}

static inline float groundXVisibleBladeLength(void) {
    return (float)thirdBladeArc->visibleTipDistanceMilli / 1000.f;
}

static inline float groundXBladeClearance(void) {
    return (float)thirdBladeArc->floorClearanceMilli / 1000.f;
}

static inline float groundXVisibleTipGap(const float matrix[16], float wristHeight, float amount) {
    const float across = (float)thirdBladeArc->visibleTipXMilli / 1000.f;
    return wristHeight + amount * (matrix[2] * across + matrix[10] * groundXVisibleBladeLength());
}
#endif

static inline bool groundXBladeDirection(float out[3], const float palm[3], const float socket[3],
    float weight, float wristHeight, float bladeLength) {
    for (unsigned i = 0; i < 3; ++i) out[i] = palm[i] + weight * (socket[i] - palm[i]);
    const float length = hypotf(hypotf(out[0], out[1]), out[2]);
    if (!isfinite(length) || length < .001f) return false;
    for (unsigned i = 0; i < 3; ++i) out[i] /= length;
    if (isfinite(wristHeight) && wristHeight > 0.f && bladeLength > wristHeight) {
        const float floorZ = -wristHeight / bladeLength;
        const float horizontal = hypotf(out[0], out[1]);
        if (out[2] < floorZ && horizontal > .001f) {
            const float scale = sqrtf(1.f - floorZ * floorZ) / horizontal;
            out[0] *= scale;
            out[1] *= scale;
            out[2] = floorZ;
        }
    }
    return true;
}
#endif

static inline float groundXDistance(unsigned ordinal, uint64_t age, float firstDistance) {
    const float progress = fminf(1.f, groundXSourceAge(ordinal, age) / (float)groundXDuration(ordinal));
#ifdef SR1_LOCAL_THIRD_FINISH
    if (ordinal == 2) {
        // Keep the recorded forward strike. After it, integrate only the authored planted step back.
        const float forward = measuredStrikeTravel(ordinal, fminf(progress, .6f), firstDistance);
        return forward + groundXThirdRecoil(groundXSample(ordinal, age, localStrikePoses[2]), firstDistance);
    }
#endif
    if (ordinal) return measuredStrikeTravel(ordinal, progress, firstDistance);
    const float key = 10.f * progress;
    const unsigned lower = (unsigned)fminf(key, 9.f);
    const float a = groundXFirstTravel[lower], b = groundXFirstTravel[lower + 1];
    return -firstDistance * (a + (key - lower) * (b - a)) / 1000.f;
}

#ifdef SR1_LOCAL_NATIVE_COMBO_CLOCK
#include "local-native-combo-time.h"

static inline uint64_t groundXPoseAge(unsigned ordinal, uint64_t age, bool fastClock) {
    if (!fastClock || ordinal >= sheet_sr1CombatNativeLink_count) return groundXPlaybackAge(ordinal, age);
    const Sheet_sr1CombatNativeLink *const link = sheet_sr1CombatNativeLink_rows[ordinal];
    if (age >= (uint64_t)link->referenceMs) return (uint64_t)link->baselineMs;
    return age * (uint64_t)link->baselineMs / (uint64_t)link->referenceMs;
}

static inline bool groundXRecoveryRemaining(unsigned ordinal, uint64_t age, bool fastClock) {
    if (!ordinal) return age < (uint64_t)sheet_sr1CombatGroundReference_solo_first.chainMs;
    return groundXHasRemaining(ordinal, groundXPoseAge(ordinal, age, fastClock));
}
#endif

#ifdef SR1_LOCAL_CALIBRATED_COMBAT
static inline float calibratedGroundXDistance(unsigned ordinal, uint64_t age) {
    const float unit = -groundXDistance(ordinal, 5000, 1.f);
    const float budget = (float)sheet_sr1CombatGroundReference_rows[ordinal]->distance / unit;
    return groundXDistance(ordinal, groundXPlaybackAge(ordinal, age), budget);
}
#endif

#ifdef SR1_LOCAL_NATIVE_COMBO_CLOCK
static inline float nativeClockGroundXDistance(unsigned ordinal, uint64_t age, bool fastClock) {
    if (ordinal == 2) return calibratedGroundXDistance(ordinal, age);
    const uint64_t playback = groundXPoseAge(ordinal, age, fastClock);
    const float base = calibratedGroundXDistance(ordinal, playback);
    const uint64_t tailFirst = sheet_sr1CombatNativeLink_first.baselineMs;
    if (ordinal || age <= tailFirst) return base;
    const uint64_t tailLast = sheet_sr1CombatGroundReference_solo_first.chainMs;
    const float remaining = sheet_sr1CombatGroundReference_solo_first.distance - sheet_sr1CombatGroundReference_first.distance;
    const float weight = combatEase(age - tailFirst, tailLast - tailFirst);
    return base - weight * remaining;
}
#endif
