// SPDX-License-Identifier: GPL-3.0-or-later
#pragma once
#ifdef SR1_LOCAL_COMBAT_SYNC42
#include "local-combat-sync-policy.h"
#endif

static inline bool specialFreshFollowup(uint64_t age,uint64_t duration) {
    const uint64_t window=sheet_sr1CombatInput41_special_input.followupMs;
    return age>=duration || duration-age<=window;
}

static inline bool specialDirectionBreak(unsigned original,unsigned desired,bool guard) {
    const int delta=(int)((desired-original+2048u)&4095u)-2048;
    const int threshold=(int)sheet_sr1CombatInput41_special_input.directionBreak;
    return !guard && (delta>=threshold || delta<=-threshold);
}

static inline uint64_t combatGroundLinkMs(unsigned ordinal) {
#ifdef SR1_LOCAL_COMBAT_SYNC42
    if (ordinal<2) return (500000u+sheet_sr1CombatSync42_synchronized_combat.ratePermille-1u)/
        sheet_sr1CombatSync42_synchronized_combat.ratePermille;
#endif
    return ordinal==0 ? sheet_sr1CombatInput41_special_input.firstLinkMs :
        ordinal==1 ? sheet_sr1CombatInput41_special_input.secondLinkMs :
        sheet_sr1LocalGroundStrikeFlow_ground_links.linkMs;
}

static inline uint64_t combatGroundPoseAge(unsigned ordinal,uint64_t age) {
#ifdef SR1_LOCAL_COMBAT_SYNC42
    return ordinal<2 ? age*sheet_sr1CombatSync42_synchronized_combat.ratePermille/1000u : age;
#else
    return ordinal<2 ? age*(uint64_t)sheet_sr1LocalGroundStrikeFlow_ground_links.linkMs/combatGroundLinkMs(ordinal) : age;
#endif
}
