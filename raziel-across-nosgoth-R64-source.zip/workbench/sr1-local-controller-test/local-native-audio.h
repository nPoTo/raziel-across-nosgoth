// SPDX-License-Identifier: GPL-3.0-or-later
#pragma once
typedef uintptr_t (*LocalNativeSound)(uintptr_t,int32_t,int32_t,int32_t,int32_t);
static LocalNativeSound originalLocalSound;
static uintptr_t localNativeSound(uintptr_t position,int32_t id,int32_t pitch,int32_t volume,int32_t distance) {
 const DWORD savedError=GetLastError();
 const Sheet_sr1Audio44 *const source=&sheet_sr1Audio44_installed_audio;
 const Sheet_sr1AudioPolicy44 *const policy=&sheet_sr1AudioPolicy44_owned_sword;
 bool suppress=false;
 if(InterlockedCompareExchange(&localAudioReady,0,0)) {
  const uintptr_t candidate=position>source->positionOffset?position-source->positionOffset:0;
  suppress=localBladeMatches(candidate);
  uintptr_t actor=0;uint32_t kind=0;
  if(!suppress && readAt(base+host->actorRva,&actor,sizeof(actor)) && candidate==actor &&
   (id==policy->legacySwingId || id==policy->legacyWeaponId) &&
   readAt(base+host->interactionTypeRva,&kind,sizeof(kind)) && kind==0x1000) {
   const Sr1LocalFrame frame=readFrame();
   suppress=frame.ready&&frame.renderBlend;
  }
 }
 if(suppress) {
  static volatile LONG reported;
  if(InterlockedIncrement(&reported)<=24)record("native-sword-audio suppressed id=%d caller=%llx",id,
   (unsigned long long)((uintptr_t)__builtin_return_address(0)-base));
  SetLastError(savedError);return 0;
 }
 SetLastError(savedError);
 return originalLocalSound(position,id,pitch,volume,distance);
}
static bool prepareLocalNativeAudio(void) {
 const Sheet_sr1Audio44 *const source=&sheet_sr1Audio44_installed_audio;
 if(!verifyDrawBlock(source->nativePlayRva,(DWORD)source->nativePlayBytes,LOCAL_NATIVE_AUDIO_HASH))return false;
 return MH_CreateHook((void *)(base+source->nativePlayRva),(void *)localNativeSound,(void **)&originalLocalSound)==MH_OK;
}
