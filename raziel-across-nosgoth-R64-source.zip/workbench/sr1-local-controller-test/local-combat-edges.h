// SPDX-License-Identifier: GPL-3.0-or-later
#pragma once

static inline bool localCombatPress(bool *previous, bool held, bool nativePress) {
    const bool edge = held && nativePress && !*previous;
    *previous = held;
    return edge;
}
