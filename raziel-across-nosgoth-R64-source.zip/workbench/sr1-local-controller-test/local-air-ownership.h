// SPDX-License-Identifier: GPL-3.0-or-later
#pragma once

typedef struct {
    uintptr_t actor;
    uint32_t world, generation;
    Sr1LocalRealm realm;
    uint64_t tick;
} LocalActionOwner;

typedef struct { LocalActionOwner owner; unsigned target; int units; } LocalTurnReceipt;
typedef struct { LocalActionOwner owner; int16_t floor; int32_t forward; } LocalJumpReceipt;
static SRWLOCK localTurnLock = SRWLOCK_INIT, localJumpLock = SRWLOCK_INIT;
static LocalTurnReceipt localTurn;
static LocalJumpReceipt localJump;

static LocalActionOwner localActionOwner(const Sr1LocalFrame *frame, uintptr_t actor, uint64_t tick) {
    return (LocalActionOwner){actor, frame->worldGeneration, frame->playerGeneration, frame->realm, tick};
}

static bool sameLocalAction(const LocalActionOwner *owner, const Sr1LocalFrame *frame, uintptr_t actor,
                            uint64_t now, uint64_t maxAge) {
    return owner->tick && owner->tick <= now && now - owner->tick <= maxAge &&
        owner->actor == actor && owner->world == frame->worldGeneration &&
        owner->generation == frame->playerGeneration && owner->realm == frame->realm;
}

static void publishLocalTurn(const Sr1LocalFrame *frame, uintptr_t actor, uint64_t tick, unsigned target, int units) {
    AcquireSRWLockExclusive(&localTurnLock);
    localTurn = (LocalTurnReceipt){localActionOwner(frame, actor, tick), target, units};
    ReleaseSRWLockExclusive(&localTurnLock);
}

static void publishLocalJump(const Sr1LocalFrame *frame, uintptr_t actor, uint64_t tick, int16_t floor, int32_t forward) {
    AcquireSRWLockExclusive(&localJumpLock);
    localJump = (LocalJumpReceipt){localActionOwner(frame, actor, tick), floor, forward};
    ReleaseSRWLockExclusive(&localJumpLock);
}

static LocalJumpReceipt readLocalJump(void) {
    LocalJumpReceipt r = {0};
    if (TryAcquireSRWLockShared(&localJumpLock)) {
        r = localJump;
        ReleaseSRWLockShared(&localJumpLock);
    }
    return r;
}

static LocalTurnReceipt readLocalTurn(void) {
    LocalTurnReceipt r = {0};
    if (TryAcquireSRWLockShared(&localTurnLock)) {
        r = localTurn;
        ReleaseSRWLockShared(&localTurnLock);
    }
    return r;
}
