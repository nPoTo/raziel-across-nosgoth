// SPDX-License-Identifier: GPL-3.0-or-later
#pragma once
static bool localSweepSample48(const C2VisibleSegment *from,const C2VisibleSegment *to,unsigned sample,C2VisibleSegment *out){
 const unsigned count=(unsigned)sheet_sr1Combat48_combat_charge.sweepSamples;
 if(count<2||count>32||!sample||sample>=count)return false;
 C2VisibleSegment next=*to;const float blend=(float)sample/count;
 for(unsigned k=0;k<3;k++){
  next.palm[k]=from->palm[k]+blend*(to->palm[k]-from->palm[k]);next.tip[k]=from->tip[k]+blend*(to->tip[k]-from->tip[k]);
  if(!isfinite(next.palm[k])||!isfinite(next.tip[k]))return false;
 }
 *out=next;return true;
}
