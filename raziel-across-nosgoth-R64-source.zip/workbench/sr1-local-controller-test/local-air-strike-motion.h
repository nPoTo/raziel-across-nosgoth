// SPDX-License-Identifier: GPL-3.0-or-later
#pragma once

static inline unsigned localAirStrikeEase(uint64_t elapsed, uint64_t duration) {
    const uint64_t t = elapsed * 1000 / duration;
    return (unsigned)(t * t * (3000 - 2 * t) / 1000000);
}

static inline unsigned localAirStrikeSpeed(const Sheet_sr1LocalAirStrikeMotion *policy, uint64_t age) {
    const uint64_t dip = (uint64_t)policy->slowdownMs;
    const uint64_t resume = (uint64_t)policy->resumeMs;
    if (age >= resume) return 1000;
    const uint64_t eased = age <= dip ? localAirStrikeEase(age, dip) :
        localAirStrikeEase(resume - age, resume - dip);
    return 1000 - (unsigned)(eased * (1000 - policy->minSpeedPermille) / 1000);
}

#ifdef SR1_LOCAL_AIR_STRIKE_HOLD
static inline unsigned localAirStrikeHoldSpeed(const Sheet_sr1LocalAirStrikeHold *hold, uint64_t age) {
    const uint64_t start = (uint64_t)(hold->beginMs - hold->easeInMs);
    const uint64_t end = (uint64_t)(hold->endMs + hold->easeOutMs);
    if (age <= start || age >= end) return 1000;
    if (age < (uint64_t)hold->beginMs)
        return 1000 - localAirStrikeEase(age - start, hold->easeInMs);
    if (age <= (uint64_t)hold->endMs) return 0;
    return localAirStrikeEase(age - hold->endMs, hold->easeOutMs);
}

static inline unsigned localAirStrikeChainSpeed(unsigned ordinal, uint64_t age, uint64_t priorAge) {
    const unsigned current = localAirStrikeHoldSpeed(sheet_sr1LocalAirStrikeHold_rows[ordinal], age);
    if (!ordinal) return current;
    const unsigned previous = localAirStrikeHoldSpeed(sheet_sr1LocalAirStrikeHold_rows[ordinal - 1], age + priorAge);
    return current < previous ? current : previous;
}
#endif

#ifdef SR1_LOCAL_COMBAT_TEMPO
static const Sheet_sr1LocalAirComboTempo *const airComboTempo = &sheet_sr1LocalAirComboTempo_air_combo;

static inline uint64_t localAirComboDuration(uint64_t sourceMs) {
    const uint64_t rate = airComboTempo->posePermille;
    return (sourceMs * 1000 + rate - 1) / rate;
}

static inline bool localAirComboCanAdvance(unsigned ordinal, uint64_t age) {
    return age >= (uint64_t)(ordinal == 0 ? airComboTempo->secondStartMs : airComboTempo->thirdStartMs);
}
#endif

#ifdef SR1_LOCAL_AIR_COMBO_RESERVE
static inline bool localAirCanReserveFinal(unsigned ordinal, uint64_t age) {
    return ordinal == 1 && age <= (uint64_t)sheet_sr1CombatAirReserve_reserved_final_swing.minQueueDeadlineMs;
}

static inline unsigned localAirReservedChainSpeed(unsigned ordinal, uint64_t age, uint64_t previous,
    bool reserveFinal) {
    if (reserveFinal) {
        const Sheet_sr1CombatAirReserve *const reserve = &sheet_sr1CombatAirReserve_reserved_final_swing;
        if ((ordinal == 1 && age >= (uint64_t)reserve->minQueueDeadlineMs &&
                age < (uint64_t)(airComboTempo->thirdStartMs + reserve->joinMs)) ||
            (ordinal == 2 && age < (uint64_t)reserve->joinMs)) return 0;
    }
    return localAirStrikeChainSpeed(ordinal, age, previous);
}
#endif

#ifdef SR1_LOCAL_COMBO_FLOW
static const Sheet_sr1LocalAirStrikeFlow *const airStrikeFlow = &sheet_sr1LocalAirStrikeFlow_air_links;

static inline uint64_t localAirStrikeOutgoingAge(uint64_t priorAge, uint64_t blendAge) {
    return priorAge + blendAge;
}

static inline unsigned localAirStrikeRecoveryWeight(unsigned ordinal, uint64_t age) {
    if (ordinal != 2) return 1000;
    const Sheet_sr1LocalAirStrikeHold *const hold = &sheet_sr1LocalAirStrikeHold_air_third;
    if (age <= (uint64_t)hold->endMs) return 1000;
    const uint64_t recovery = age - hold->endMs;
    if (recovery >= (uint64_t)hold->easeOutMs) return 0;
    return 1000 - localAirStrikeEase(recovery, hold->easeOutMs);
}
#endif

#ifdef SR1_LOCAL_COMBAT_RHYTHM
typedef struct {
    int32_t planarTime, verticalTime;
} LocalAirStrikeStep;

static inline LocalAirStrikeStep localAirStrikeAxisStep(int32_t time, unsigned vertical) {
    const int64_t floor =
#ifdef SR1_LOCAL_COMBAT_LINKS
        sheet_sr1CombatLinks_standalone_links.minAirPlanarPermille;
#else
        sheet_sr1LocalAirStrikeAxes_moving_air_attack.minPlanarPermille;
#endif
    const int64_t planar = floor + (1000 - floor) * vertical / 1000;
    const int32_t planarTime = (int32_t)((int64_t)time * planar / 1000);
    return (LocalAirStrikeStep){planarTime ? planarTime : 1, (int32_t)((int64_t)time * vertical / 1000)};
}

static inline int32_t localAirStrikeStepVelocity(int32_t velocity, LocalAirStrikeStep step) {
    return (int32_t)((int64_t)velocity * step.verticalTime / step.planarTime);
}

static inline int32_t localAirStrikeStepAcceleration(int32_t acceleration, LocalAirStrikeStep step) {
    return (int32_t)((int64_t)acceleration * step.verticalTime * step.verticalTime /
        ((int64_t)step.planarTime * step.planarTime));
}
#endif

static inline int32_t localAirStrikeNativeVelocity(int32_t v, int32_t a, int32_t time, int32_t limit) {
    const int64_t next = v + (int64_t)a * time / 4096;
    if (next < -limit) return -limit;
    if (next > limit) return limit;
    return (int32_t)next;
}
