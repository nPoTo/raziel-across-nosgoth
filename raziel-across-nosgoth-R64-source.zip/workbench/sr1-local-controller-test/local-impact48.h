// SPDX-License-Identifier: GPL-3.0-or-later
#pragma once
#ifdef SR1_LOCAL_COMBAT50
#include "air-combat-policy.h"
#endif
#include "../../output/github-v0.2-staging/source/workbench/c4-linked-finisher-r5/native/reaver-impact.h"
static SRWLOCK localImpactLock48=SRWLOCK_INIT;
#ifdef SR1_LOCAL_COMBAT52
#include "local-fx-target52.h"
#endif
typedef struct {C2Impact hit;Sr1LocalRealm realm;uintptr_t target;uint32_t targetGeneration;} LocalImpact48;
static LocalImpact48 localImpacts48[16];static unsigned localImpactCursor48;
#ifdef SR1_LOCAL_COMBAT50
static C2Impact localSlamSpark50;
static void localSlamSparkDrawn50(const C2Impact *hit){
 if(!hit->slam||!hit->landing)return;
 AcquireSRWLockExclusive(&localImpactLock48);if(hit->tick>=localSlamSpark50.tick)localSlamSpark50=*hit;ReleaseSRWLockExclusive(&localImpactLock48);
}
static C2Impact localSlamSparkRead50(void){AcquireSRWLockShared(&localImpactLock48);C2Impact hit=localSlamSpark50;ReleaseSRWLockShared(&localImpactLock48);return hit;}
static void localVictimGroundSpark50(const Sr1LocalFrame *f,const int16_t point[3],uint64_t marker,uint64_t now){
 LocalImpact48 next={.hit={.tick=now,.epoch=f->session,.marker=marker,.actorGeneration=f->playerGeneration,.stream=f->worldGeneration,
  .color=0xe5f7ff,.landing=true,.slam=true,.targetRadius=AIR_SLAM_IMPACT_RADIUS},.realm=f->realm};memcpy(next.hit.point,point,6);
 AcquireSRWLockExclusive(&localImpactLock48);localImpacts48[localImpactCursor48++%16]=next;ReleaseSRWLockExclusive(&localImpactLock48);
 record("defiance-victim-ground-spark marker=%llu",(unsigned long long)marker);
}
#endif
static void localImpactQueue48(const Sr1LocalFrame *f,uintptr_t actor,uint64_t now,const int16_t point[3],unsigned form){
 static const uint32_t colors[]={0,0x66e5ff,0x66e5ff,0xb460ff,0xffd970,0x55ffe8,0xff6325,0x3c88ff,0x8ee64d,0xf185ff};
 if(!f->ready||!f->renderBlend||actor!=player||form<1||form>9)return;
 LocalImpact48 next={.hit={.tick=now,.epoch=f->session,.marker=now,.actorGeneration=f->playerGeneration,.stream=f->worldGeneration,.color=colors[form]},.realm=f->realm};
 memcpy(next.hit.point,point,6);AcquireSRWLockExclusive(&localImpactLock48);localImpacts48[localImpactCursor48++%16]=next;ReleaseSRWLockExclusive(&localImpactLock48);
 record("defiance-impact-queued form=%u point=%d,%d,%d",form,point[0],point[1],point[2]);
}
#ifdef SR1_LOCAL_COMBAT52
static void localImpactTarget52(const Sr1LocalFrame *f,uintptr_t actor,uint64_t now,uintptr_t target,uint32_t gen,unsigned form){
 int16_t point[3];if(!f->ready||!f->renderBlend||actor!=player||form<1||form>9||!localTargetPoint52(target,gen,f->worldGeneration,point))return;
 static const uint32_t colors[]={0,0x66e5ff,0x66e5ff,0xb460ff,0xffd970,0x55ffe8,0xff6325,0x3c88ff,0x8ee64d,0xf185ff};
 LocalImpact48 next={.hit={.tick=now,.epoch=f->session,.marker=now,.actorGeneration=f->playerGeneration,.stream=f->worldGeneration,.color=colors[form]},.realm=f->realm,.target=target,.targetGeneration=gen};memcpy(next.hit.point,point,6);
 AcquireSRWLockExclusive(&localImpactLock48);localImpacts48[localImpactCursor48++%16]=next;ReleaseSRWLockExclusive(&localImpactLock48);
 record("defiance-impact-target form=%u target=%u point=%d,%d,%d",form,gen,point[0],point[1],point[2]);
}
#endif
#ifdef SR1_LOCAL_COMBAT49
static void localGroundSpark49(const Sr1LocalFrame *f,uintptr_t actor,uint64_t now){
 int16_t point[3];if(actor!=player||!f->ready||!f->renderBlend||!readAt(actor+0x9c,point,6))return;
 const unsigned form=localCurrentForm(f->realm);if(!form)return;
 LocalImpact48 next={.hit={.tick=now,.epoch=f->session,.marker=now,.actorGeneration=f->playerGeneration,.stream=f->worldGeneration,
   .color=0xe5f7ff,.slam=true},.realm=f->realm};memcpy(next.hit.point,point,6);
 AcquireSRWLockExclusive(&localImpactLock48);localImpacts48[localImpactCursor48++%16]=next;ReleaseSRWLockExclusive(&localImpactLock48);
 record("defiance-ground-spark form=%u point=%d,%d,%d",form,point[0],point[1],point[2]);
}
#endif
