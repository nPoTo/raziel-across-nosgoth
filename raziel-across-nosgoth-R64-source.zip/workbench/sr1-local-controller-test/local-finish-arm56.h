// SPDX-License-Identifier: GPL-3.0-or-later
#pragma once
#include <math.h>
#include <string.h>
// Scratch pose only. Rigid forearm/hand rotation preserves native bone lengths and actor world position.
static bool localFinishArm56(float pose[66][13],const int16_t target[3],float weight){
 if(!isfinite(weight)||weight<=0)return false;weight=fminf(weight,1.f);
 float from[3],to[3],pivot[3],a=0,b=0;
 for(unsigned k=0;k<3;k++){pivot[k]=pose[40][10+k];from[k]=pose[41][10+k]-pivot[k];to[k]=target[k]-pivot[k];a+=from[k]*from[k];b+=to[k]*to[k];}
 if(!isfinite(a)||!isfinite(b)||a<1||b<=a)return false;a=sqrtf(a);b=sqrtf(b);
 float dot=0;for(unsigned k=0;k<3;k++){from[k]/=a;to[k]/=b;dot+=from[k]*to[k];}
 dot=fmaxf(-1.f,fminf(1.f,dot));float axis[3]={from[1]*to[2]-from[2]*to[1],from[2]*to[0]-from[0]*to[2],from[0]*to[1]-from[1]*to[0]};
 float n=sqrtf(axis[0]*axis[0]+axis[1]*axis[1]+axis[2]*axis[2]);
 if(n<.0001f){if(dot>0)return true;axis[0]=-from[1];axis[1]=from[0];axis[2]=0;n=hypotf(axis[0],axis[1]);if(n<.0001f){axis[0]=1;n=1;}}
 for(unsigned k=0;k<3;k++)axis[k]/=n;
 for(unsigned bone=40;bone<=48;bone++)for(unsigned k=0;k<13;k++)if(k!=9&&!isfinite(pose[bone][k]))return false;
 const float angle=acosf(dot)*weight,c=cosf(angle),s=sinf(angle),t=1-c,x=axis[0],y=axis[1],z=axis[2];
 const float r[9]={c+x*x*t,x*y*t-z*s,x*z*t+y*s,y*x*t+z*s,c+y*y*t,y*z*t-x*s,z*x*t-y*s,z*y*t+x*s,c+z*z*t};
 for(unsigned bone=40;bone<=48;bone++){float old[13];memcpy(old,pose[bone],sizeof old);
  for(unsigned row=0;row<3;row++){for(unsigned col=0;col<3;col++){float v=0;for(unsigned k=0;k<3;k++)v+=r[row*3+k]*old[k*3+col];pose[bone][row*3+col]=v;}
   float v=pivot[row];for(unsigned k=0;k<3;k++)v+=r[row*3+k]*(old[10+k]-pivot[k]);pose[bone][10+row]=v;
  }
 }return true;
}
