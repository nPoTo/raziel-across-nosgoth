// SPDX-License-Identifier: GPL-3.0-or-later
#pragma once

#include <math.h>
#include "measured-combo-proof.h"

static inline float measuredStrikeTravel(unsigned ordinal, float progress, float initialDistance) {
    if (ordinal < 1 || ordinal > 2 || !isfinite(progress)) return 0.f;
    const float key = 10.f * fminf(fmaxf(progress, 0.f), 1.f);
    const unsigned lower = (unsigned)fminf(key, 9.f);
    const unsigned row = ordinal - 1;
    const float a = measuredTravelShape[row][lower], b = measuredTravelShape[row][lower + 1];
    const float portion = (a + (key - lower) * (b - a)) / 1000.f;
    return -initialDistance * measuredTravelRatio[row] * portion;
}

static inline float measuredStrikeVisualSample(float nativeSample, unsigned count, uint64_t ageMs) {
    // Only the wind-up leads. Contact, drive and attack transitions use the native clock.
    const float time = (float)(ageMs < MEASURED_STRIKE_LEAD_MS ? ageMs : MEASURED_STRIKE_LEAD_MS);
    return fminf((float)(count - 1), fmaxf(nativeSample, time * .060f));
}
