// SPDX-License-Identifier: GPL-3.0-or-later
#pragma once
static HWND localWheelWindow46;
static WNDPROC localWheelPrevious46;
static bool localWheelUnicode46;
static volatile LONG localWheelActive46,localWheelDelta46;
static volatile LONG64 localWheelTick46;
static LRESULT CALLBACK localWheelProc46(HWND window,UINT message,WPARAM wparam,LPARAM lparam) {
 const DWORD incoming=GetLastError();const WNDPROC previous=localWheelPrevious46;const bool unicode=localWheelUnicode46;
 if(message==WM_MOUSEWHEEL&&window==localWheelWindow46){
  const uint64_t now=GetTickCount64(),tick=(uint64_t)InterlockedCompareExchange64(&localWheelTick46,0,0);
  if(InterlockedCompareExchange(&localWheelActive46,0,0)&&tick&&now>=tick&&now-tick<=(uint64_t)sheet_sr1Battle46_defiance_combat.wheelFreshMs){
   InterlockedExchangeAdd(&localWheelDelta46,(SHORT)HIWORD(wparam));SetLastError(incoming);return 0;
  }
 }
 if(message==WM_KILLFOCUS||(message==WM_ACTIVATEAPP&&!wparam)||message==WM_NCDESTROY){
  InterlockedExchange(&localWheelActive46,0);InterlockedExchange(&localWheelDelta46,0);
 }
 if(message==WM_NCDESTROY&&window==localWheelWindow46){
  const WNDPROC current=(WNDPROC)(unicode?GetWindowLongPtrW(window,GWLP_WNDPROC):GetWindowLongPtrA(window,GWLP_WNDPROC));
  if(current==localWheelProc46){if(unicode)SetWindowLongPtrW(window,GWLP_WNDPROC,(LONG_PTR)previous);else SetWindowLongPtrA(window,GWLP_WNDPROC,(LONG_PTR)previous);}
  localWheelWindow46=NULL;localWheelPrevious46=NULL;
 }
 SetLastError(incoming);return previous?(unicode?CallWindowProcW(previous,window,message,wparam,lparam):CallWindowProcA(previous,window,message,wparam,lparam)):(unicode?DefWindowProcW(window,message,wparam,lparam):DefWindowProcA(window,message,wparam,lparam));
}
static bool localWheelInstall46(HWND window) {
 if(localWheelWindow46==window&&localWheelPrevious46)return true;
 if(localWheelWindow46||!window)return false;DWORD pid=0;GetWindowThreadProcessId(window,&pid);
 if(pid!=GetCurrentProcessId()||GetAncestor(window,GA_ROOT)!=window)return false;
 const bool unicode=IsWindowUnicode(window)!=0;
 const WNDPROC prior=(WNDPROC)(unicode?GetWindowLongPtrW(window,GWLP_WNDPROC):GetWindowLongPtrA(window,GWLP_WNDPROC));if(!prior)return false;
 localWheelPrevious46=prior;localWheelWindow46=window;localWheelUnicode46=unicode;
 SetLastError(0);const WNDPROC previous=(WNDPROC)(unicode?SetWindowLongPtrW(window,GWLP_WNDPROC,(LONG_PTR)localWheelProc46):SetWindowLongPtrA(window,GWLP_WNDPROC,(LONG_PTR)localWheelProc46));
 if(!previous){localWheelPrevious46=NULL;localWheelWindow46=NULL;return false;}localWheelPrevious46=previous;
 record("reaver-wheel window-ready=1");return true;
}
static int localWheelSteps46(bool live) {
 static int remainder;
 if(!live){InterlockedExchange(&localWheelActive46,0);InterlockedExchange(&localWheelDelta46,0);remainder=0;return 0;}
 if(!localWheelWindow46)localWheelInstall46(GetForegroundWindow());
 const uint64_t now=GetTickCount64(),prior=(uint64_t)InterlockedCompareExchange64(&localWheelTick46,0,0);
 if(prior&&now>=prior&&now-prior>(uint64_t)sheet_sr1Battle46_defiance_combat.wheelFreshMs){InterlockedExchange(&localWheelDelta46,0);remainder=0;}
 InterlockedExchange64(&localWheelTick46,(LONG64)now);InterlockedExchange(&localWheelActive46,localWheelWindow46!=NULL);
 const int delta=(int)InterlockedExchange(&localWheelDelta46,0);
 const int quantum=(int)sheet_sr1Battle46_defiance_combat.wheelDelta;
 const int limit=(int)sheet_sr1Battle46_defiance_combat.maxWheelSteps;
 remainder+=delta;int steps=remainder/quantum;remainder%=quantum;
 return steps>limit?limit:steps< -limit?-limit:steps;
}
static unsigned localDigitBits46(void) {
 unsigned bits=0;for(unsigned i=0;i<8;i++){const Sheet_sr1ReaverKey46 *p=sheet_sr1ReaverKey46_rows[i];if((GetAsyncKeyState((int)p->key)|GetAsyncKeyState((int)p->numpad))&0x8000)bits|=1u<<(8+i);}return bits;
}
static unsigned localDigitSelect46(unsigned edge,unsigned realm,unsigned mask) {
 for(unsigned i=0;i<8;i++)if(edge&(1u<<(8+i))){const unsigned form=realm==SR1_LOCAL_SPECTRAL?(i==0?1:0):(unsigned)sheet_sr1ReaverKey46_rows[i]->form;return form&&(mask&(1u<<(form-1)))?form:0;}return 0;
}
