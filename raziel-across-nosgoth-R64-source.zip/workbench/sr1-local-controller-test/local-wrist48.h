// SPDX-License-Identifier: GPL-3.0-or-later
#pragma once
static bool localWristBlade48(float matrix[16],const float wrist[13],const float anchor[3]){
 for(unsigned i=0;i<9;i++)if(!isfinite(wrist[i]))return false;
 float next[16]={0};next[15]=1.f;
 for(unsigned column=0;column<3;column++)for(unsigned row=0;row<3;row++)for(unsigned k=0;k<3;k++)
  next[column*4+row]+=wrist[row*3+k]*localWristGrip48[column*3+k];
 for(unsigned k=0;k<3;k++){if(!isfinite(anchor[k]))return false;next[12+k]=anchor[k];}
 for(unsigned col=0;col<3;col++){
  const float norm=hypotf(hypotf(next[col*4],next[col*4+1]),next[col*4+2]);if(fabsf(norm-1.f)>.02f)return false;
 }
 memcpy(matrix,next,sizeof next);return true;
}
static bool localWristAim48(float matrix[16],const float target[3]){
 const float norm=hypotf(hypotf(target[0],target[1]),target[2]);if(!isfinite(norm)||norm<.00001f)return false;
 float desired[3],axis[3];for(unsigned k=0;k<3;k++)desired[k]=target[k]/norm;
 const float *before=matrix+8;axis[0]=before[1]*desired[2]-before[2]*desired[1];axis[1]=before[2]*desired[0]-before[0]*desired[2];axis[2]=before[0]*desired[1]-before[1]*desired[0];
 const float sine=hypotf(hypotf(axis[0],axis[1]),axis[2]);const float cosine=fmaxf(-1.f,fminf(1.f,before[0]*desired[0]+before[1]*desired[1]+before[2]*desired[2]));
 if(sine<.00001f){if(cosine>0)return true;for(unsigned k=0;k<3;k++)axis[k]=matrix[k];}
 else for(unsigned k=0;k<3;k++)axis[k]/=sine;
 const float angle=atan2f(sine,cosine),c=cosf(angle),s=sinf(angle);
 for(unsigned col=0;col<3;col++){
  float v[3];memcpy(v,matrix+col*4,sizeof v);const float dot=axis[0]*v[0]+axis[1]*v[1]+axis[2]*v[2];
  const float cross[3]={axis[1]*v[2]-axis[2]*v[1],axis[2]*v[0]-axis[0]*v[2],axis[0]*v[1]-axis[1]*v[0]};
  for(unsigned k=0;k<3;k++)matrix[col*4+k]=c*v[k]+s*cross[k]+(1-c)*dot*axis[k];
 }
 return true;
}
