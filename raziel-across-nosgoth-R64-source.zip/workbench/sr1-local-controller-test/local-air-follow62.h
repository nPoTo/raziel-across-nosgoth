// SPDX-License-Identifier: GPL-3.0-or-later
#pragma once
typedef struct{LocalContactTicket ticket;uint64_t until;bool entering63;}LocalPendingStun62;
static _Thread_local LocalPendingStun62 localPendingStuns62[128];static _Thread_local unsigned localPendingStunCursor62;
static bool localPendingCurrent62(LocalPendingStun62*p,const Sr1LocalFrame*f,uint64_t now,LocalTarget*out){
 if(!p->ticket.target.actor)return false;
 if(now>=p->until||!localTicketCurrent(&p->ticket,f,now,UINT64_MAX,out)||out->hp!=0){memset(p,0,sizeof*p);return false;}return true;
}
static void localDeferStun62(const LocalContactTicket*t,uint64_t now){
 const Sr1LocalFrame f=readLocalFrame(false);LocalTarget current;
 if(!t||!localTicketCurrent(t,&f,now,UINT64_MAX,&current)||current.hp!=0||current.mainState!=AIR_FLIGHT_STATE)return;
 unsigned slot=128;for(unsigned i=0;i<128;i++)if(localPendingStuns62[i].ticket.target.actor==current.actor&&localPendingStuns62[i].ticket.target.generation==current.generation){slot=i;break;}
 const bool first=slot==128;if(first)slot=localPendingStunCursor62++%128;
 localPendingStuns62[slot]=(LocalPendingStun62){.ticket=*t,.until=now+(uint64_t)sheet_sr1Contact62_air_stun_force_audit.pendingStunMs};
 if(first)record("defiance-air-stun-pending target=%u requested=9 hp=0 marker=%llu",current.generation,(unsigned long long)t->owner.tick);
}
static bool localStunRegenHold62(uintptr_t actor){
 bool listed=false;for(unsigned i=0;i<128;i++)if(actor&&localPendingStuns62[i].ticket.target.actor==actor){listed=true;break;}if(!listed)return false;
 const Sr1LocalFrame f=readLocalFrame(false);const uint64_t now=GetTickCount64();LocalTarget current;
 for(unsigned i=0;i<128;i++)if(localPendingStuns62[i].ticket.target.actor==actor&&localPendingCurrent62(&localPendingStuns62[i],&f,now,&current))return true;
 return false;
}
static void localPollStun62(void){
 const Sr1LocalFrame f=readLocalFrame(false);const uint64_t now=GetTickCount64();
 for(unsigned i=0;i<128;i++){LocalPendingStun62*p=&localPendingStuns62[i];LocalTarget current;uint32_t flags=0;int32_t vertical=0;
  if(!localPendingCurrent62(p,&f,now,&current)||!readAt(current.state,&flags,4))continue;
  // Native transition9 only schedules entry. Keep the HP0 lease through the
  // intervening regen pass until native entry initializes its own stun flag.
  // Do not re-request entry every broad phase or extend native stun duration.
  if(p->entering63){
   if(current.mainState==9&&!(flags&(uint32_t)sheet_sr1Contact62_air_stun_force_audit.stunEntryPendingMask)&&
      (flags&(uint32_t)sheet_sr1Contact62_air_stun_force_audit.stunReadyMask)){
    record("defiance-air-stun-ready target=%u state=%u hp=%d flags=%x",current.generation,current.mainState,current.hp,flags);
    memset(p,0,sizeof*p);
   }else if(current.mainState!=9){record("defiance-air-stun-handoff-lost target=%u state=%u hp=%d",current.generation,current.mainState,current.hp);memset(p,0,sizeof*p);}
   continue;
  }
  if(!(flags&2u)||!readAt(current.actor+0x2d4,&vertical,4)||vertical>0)continue;
  if(current.mainState!=4&&current.mainState!=8&&current.mainState!=9&&current.mainState!=AIR_FLIGHT_STATE&&current.mainState!=AIR_SLAM_ROLL_STATE)continue;
  p->entering63=true;if(current.mainState!=9)originalLocalVictimTransition(current.actor,9);
  LocalTarget after;if(localReadContactTarget(current.actor,f.worldGeneration,&after)&&after.generation==current.generation&&after.state==current.state)
   record("defiance-air-stun-landed target=%u state=%u hp=%d",after.generation,after.mainState,after.hp);
 }
}
static void localReleaseStuns62(void){
 const Sr1LocalFrame f=readLocalFrame(false);const uint64_t now=GetTickCount64();
 for(unsigned i=0;i<128;i++){LocalTarget current;
  if(localPendingCurrent62(&localPendingStuns62[i],&f,now,&current)&&
   (current.mainState==4||current.mainState==8||current.mainState==AIR_FLIGHT_STATE||current.mainState==AIR_SLAM_ROLL_STATE))originalLocalVictimTransition(current.actor,9);
 }memset(localPendingStuns62,0,sizeof localPendingStuns62);
}
#ifdef SR1_LOCAL_COMBAT64
// Airborne reactions defer the native hit/stun entry which normally dispatches
// the damage presentation. Restore only that presentation on a real HP loss;
// the original species callback owns vertex blood and particles, never damage.
typedef struct{int16_t location[4],velocity[4],amount,type;}LocalNativeHitFx64;
_Static_assert(sizeof(LocalNativeHitFx64)==20,"native evFXHitData ABI");
static bool localAirHitFx64(const Sr1LocalFrame*f,uintptr_t actor,int before){
 const LocalContactTicket*t=activeLocalTicket;LocalTarget current;int16_t maximum=0;uintptr_t matrices=0;
 const uint64_t now=GetTickCount64();
 if(!t||t->target.actor!=actor||t->attack!=LOCAL_VICTIM_AIR_X_HIT||
    !localTicketCurrent(t,f,now,2000,&current)||before<=0||current.hp>=before||
    !readAt(current.state+sheet_sr1Presentation64_air_hit_presentation.maxHealthOffset,&maximum,2)||maximum<=0||
    !readAt(actor+0x68,&matrices,8)||!matrices)return false;
 typedef uintptr_t(*Lookup)(uintptr_t);typedef void(*Effect)(uintptr_t,const LocalNativeHitFx64*);
 const uintptr_t fn=((Lookup)(base+sheet_sr1Presentation64_air_hit_presentation.damageEffectLookupRva))(actor);
 MEMORY_BASIC_INFORMATION memory;
 if(!fn||!VirtualQuery((void*)fn,&memory,sizeof memory)||memory.State!=MEM_COMMIT||
    (memory.Protect&(PAGE_GUARD|PAGE_NOACCESS))||!(memory.Protect&(PAGE_EXECUTE|PAGE_EXECUTE_READ|PAGE_EXECUTE_READWRITE|PAGE_EXECUTE_WRITECOPY)))return false;
 LocalNativeHitFx64 effect={.amount=(int16_t)sheet_sr1Presentation64_air_hit_presentation.bloodAmount,.type=(int16_t)sheet_sr1Presentation64_air_hit_presentation.hitKind};
 memcpy(effect.location,t->sphere.center,6);effect.velocity[2]=16;
 ((Effect)fn)(actor,&effect);
 record("defiance-air-hit-presentation target=%u hp=%d/%d type=%d amount=%d",current.generation,before,current.hp,effect.type,effect.amount);return true;
}
#endif
static void localDamageAudit62(const Sr1LocalFrame*f,unsigned target,unsigned nominal,int before,int after){
 const uint64_t now=GetTickCount64();const LocalSpecial special=localReadSpecial(f,player,now);
 const bool rotor=special.owner.tick&&special.move==LOCAL_SPECIAL_TEMPEST;
 unsigned turn=0;const uint64_t marker=activeLocalTicket?activeLocalTicket->owner.tick:0;
 if(rotor&&special.spinStarted&&marker>=special.spinStarted)turn=(unsigned)((marker-special.spinStarted)/combatRotorPeriod())+1;
 if(turn>combatRotorTurns())turn=combatRotorTurns();
 const char*action=rotor?"ROTOR":activeLocalTicket&&activeLocalTicket->attack==LOCAL_VICTIM_AIR_X_HIT?"AIR":activeLocalTicket&&activeLocalTicket->attack==LOCAL_VICTIM_LIFT_HIT?"LIFT":"GROUND";
 record("defiance-damage-audit action=%s target=%u turn=%u form=%u nominal=%u hp=%d/%d actual=%d marker=%llu",action,target,turn,localCurrentForm(f->realm),nominal,before,after,before>after?before-after:0,(unsigned long long)marker);
}
// Released0.2 C6 direction-at-release; actual native contact authenticates throw.
static void localCaptureForce62(LocalStasisShot*shot,const Sr1LocalFrame*f,uintptr_t selected,uint32_t gen,uint64_t now){
 LocalTarget target;int16_t from[3],to[3];uint16_t yaw=UINT16_MAX;
 if(f->airState!=SR1_AIR_JUMP&&f->airState!=SR1_AIR_FALL)return;
 if(!selected||localFlightTicket.target.actor!=selected||localFlightTicket.target.generation!=gen||!localFlight.launch||localFlight.slam||
  !localVictimWindow(localFlight.launch,now)||!localTicketCurrent(&localFlightTicket,f,now,UINT64_MAX,&target)||target.mainState!=AIR_FLIGHT_STATE||
  !readAt(player+0x9c,from,6)||!readAt(selected+0x9c,to,6))return;
 if(from[0]==to[0]&&from[1]==to[1])readAt(player+sheet_sr1GroundSteering_camera_relative_start.yawOffset,&yaw,2);
 if(!airForceThrowDirection((int)to[0]-from[0],(int)to[1]-from[1],yaw,shot->direction62))return;
 shot->lifted62=localFlightTicket;
 record("defiance-force-air-armed target=%u direction=%ld/%ld",gen,(long)shot->direction62[0],(long)shot->direction62[1]);
}
static bool localForceVictim62(const LocalForceThrow62*t,const Sr1LocalFrame*f,uint64_t now){
 LocalTarget current;const LocalContactTicket*lift=&t->lifted;
 if(!t->receipt.target||t->receipt.target!=lift->target.actor||t->receipt.gen!=lift->target.generation||now<t->receipt.tick||now-t->receipt.tick>150||
  !sameLocalAction(&t->receipt.owner,f,player,now,2000)||!localTicketCurrent(lift,f,now,UINT64_MAX,&current)||!localStockFlight(&current,f->realm)||
  (!t->direction[0]&&!t->direction[1])||
  (current.mainState!=AIR_FLIGHT_STATE&&current.mainState!=4&&current.mainState!=8&&current.mainState!=9))return false;
 uintptr_t attrs=0,categories=0,data=0,animations=0;int8_t index=-1;
 if(!readAt(current.state+0x280,&attrs,8)||!attrs||!readAt(attrs,&categories,8)||!categories||
  !readAt(categories+AIR_FLIGHT_ANIMATION,&index,1)||index<0||!readAt(current.actor+0x40,&data,8)||!data||
  !readAt(data+0x60,&animations,8)||!animations)return false;
 if(current.mainState!=AIR_FLIGHT_STATE)originalLocalVictimTransition(current.actor,AIR_FLIGHT_STATE);
 LocalTarget after;if(!localReadContactTarget(current.actor,f->worldGeneration,&after)||after.generation!=current.generation||after.state!=current.state||after.mainState!=AIR_FLIGHT_STATE)return false;
 ((void(*)(uintptr_t,uint32_t,uint32_t))(base+AIR_VICTIM_ANIMATION))(current.actor,AIR_FLIGHT_ANIMATION,AIR_FLIGHT_ANIMATION_MODE);
 const int32_t velocity[3]={t->direction[0],t->direction[1],AIR_FORCE_THROW_RISE},gravity[3]={0,0,AIR_FLIGHT_GRAVITY};
 memcpy((void*)(current.actor+0x2cc),velocity,sizeof velocity);memcpy((void*)(current.actor+0x2d8),gravity,sizeof gravity);
 if(localFlightTicket.target.actor==current.actor&&localFlightTicket.target.generation==current.generation){
  localFlight=(LocalVictimFlight){0};localFlightTicket=(LocalContactTicket){0};localStasisLockedUntil=0;localVictimGroundedAt=0;
 }
 record("defiance-force-air-throw target=%u velocity=%ld/%ld/%ld",current.generation,(long)velocity[0],(long)velocity[1],(long)velocity[2]);return true;
}
static void localCommitForce62(uintptr_t target,uint32_t message,uintptr_t payload,uint64_t now){
 if(message!=localStasisPolicy->impactMessage||!payload)return;const Sr1LocalFrame f=readLocalFrame(true);
 for(unsigned i=0;i<32;i++){LocalForceThrow62*t=&localForceThrows62[i];if(t->receipt.target!=target||t->receipt.payload!=payload)continue;
  const LocalForceThrow62 owned=*t;memset(t,0,sizeof*t);(void)localForceVictim62(&owned,&f,now);break;
 }
}
