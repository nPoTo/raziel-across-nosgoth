// SPDX-License-Identifier: GPL-3.0-or-later
#pragma once

static const Sheet_sr1CombatTempestFlight *const tempestFlight = &sheet_sr1CombatTempestFlight_standalone_tempest;

static inline unsigned tempestPlanarPermille(unsigned stage, uint64_t age) {
    if (stage == 0) return (unsigned)tempestFlight->entryPlanarPermille;
    const unsigned spin = (unsigned)tempestFlight->spinPlanarPermille;
    if (stage == 1) return spin;
    const uint64_t release = (uint64_t)tempestFlight->releaseMs;
    return age >= release ? 1000 : spin + (1000 - spin) * localAirStrikeEase(age, release) / 1000;
}

static inline int32_t tempestDescentVelocity(unsigned stage, int clearance, int32_t velocity,
    int32_t acceleration, int32_t fullTime) {
    int32_t cap = (int32_t)(stage == 0 ? tempestFlight->entryFallPerStep : tempestFlight->spinFallPerStep);
    const int32_t room = clearance - (int32_t)tempestFlight->settleClearance;
    if (room <= 0) return 0;
    const int32_t supportCap = (int32_t)((int64_t)room * 4096 / fullTime);
    if (cap > supportCap) cap = supportCap;
    const int64_t falling = velocity + (int64_t)acceleration * fullTime / 4096;
    if (falling >= 0) return 0;
    return falling < -cap ? -cap : (int32_t)falling;
}
