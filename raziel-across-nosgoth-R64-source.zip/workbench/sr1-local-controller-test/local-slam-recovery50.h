// SPDX-License-Identifier: GPL-3.0-or-later
#pragma once
#include "local-damage61.h"
// Adapted from released0.2 c3AnimDescriptor/c3PlayPose/c3StartRollBounce/ground commit.
static _Thread_local struct {LocalContactTicket ticket;uint64_t impact,started;int16_t floor,peak;} localRoll50;
static bool localRollDescriptor50(const LocalTarget *target,uintptr_t *descriptor){
 uintptr_t attrs=0,categories=0,data=0,animations=0;int8_t index=-1;
 if(!readAt(target->state+0x280,&attrs,8)||!attrs||!readAt(attrs,&categories,8)||!categories||
    !readAt(categories+AIR_SLAM_ROLL_ANIMATION,&index,1)||index<0||!readAt(target->actor+0x40,&data,8)||!data||
    !readAt(data+0x60,&animations,8)||!animations)return false;
 *descriptor=animations+(uintptr_t)index*16;return true;
}
static bool localRollPose50(const LocalTarget *target){
 uintptr_t descriptor=0;if(!localRollDescriptor50(target,&descriptor))return false;
 ((void(*)(uintptr_t,uint32_t,uint32_t))(base+AIR_VICTIM_ANIMATION))(target->actor,AIR_SLAM_ROLL_ANIMATION,AIR_SLAM_ROLL_POSE_MODE);
 return true;
}
static bool localRestoreVictimGravity50(const LocalContactTicket *ticket,int32_t gravity){
 LocalTarget current;int32_t applied=0;
 if(!localReadContactTarget(ticket->target.actor,ticket->owner.world,&current)||current.generation!=ticket->target.generation||
    current.state!=ticket->target.state||!readAt(current.actor+0x2e0,&applied,4)||applied!=0)return false;
 memcpy((void *)(current.actor+0x2e0),&gravity,4);return true;
}
static bool localStartRollBounce50(const LocalContactTicket *ticket,LocalTarget current,int16_t height,uint32_t flags){
 const int top=(int)height+128,ceiling=top+AIR_SLAM_BOUNCE_CLEARANCE+60;
 if(current.mainState!=AIR_SLAM_ROLL_STATE||!(flags&2u)||(flags&1u)||ceiling>INT16_MAX||
    !localFlightClear(ticket,(int16_t)top,(int16_t)ceiling))return false;
 const int16_t start=(int16_t)(height+AIR_SLAM_BOUNCE_CLEARANCE);
 const int32_t velocity=AIR_SLAM_BOUNCE_VELOCITY,gravity=AIR_SLAM_BOUNCE_GRAVITY;flags&=~2u;
 memcpy((void *)current.state,&flags,4);memcpy((void *)(current.actor+0xa0),&start,2);
 memcpy((void *)(current.actor+0x2d4),&velocity,4);memcpy((void *)(current.actor+0x2e0),&gravity,4);
 originalLocalVictimMove(current.actor);return true; // Remain in roll state15; original recovery owns getting up.
}
static bool localCommitSlamGround50(const Sr1LocalFrame *f,const LocalContactTicket *ticket,LocalTarget current,uint64_t now){
 uint32_t powers=0,mirror=0;int16_t playerRoot[3],victimRoot[3];
 if(!f->ready||!f->renderBlend||!localAirStrikeEquipped()||!localStockFlight(&current,f->realm)||
    (current.mainState!=AIR_SLAM_ROLL_STATE&&current.mainState!=9)||!readAt(player+0x9c,playerRoot,6)||
    !readAt(current.actor+0x9c,victimRoot,6)||!airSlamReach(playerRoot,victimRoot,(int)playerRoot[2]-1,(int)victimRoot[2]-1)||
    playerRoot[2]>INT16_MAX-128||victimRoot[2]>INT16_MAX-128||
    !readAt(base+acquisition->abilitiesRva,&powers,4)||!readAt(base+acquisition->mirrorRva,&mirror,4))return false;
 const unsigned form=localCurrentForm(f->realm),damage=localFormsDamage(f->realm,form,powers,mirror);
 if(!damage)return false;
 const float origin[3]={playerRoot[0],playerRoot[1],playerRoot[2]+128.f};
 const int16_t point[3]={victimRoot[0],victimRoot[1],(int16_t)(victimRoot[2]+128)};
 if(!localNativeLineClear(player,f->worldGeneration,origin,point))return false;
#ifdef SR1_LOCAL_COMBAT51
 const bool fullBefore51=localFullCharge51(f,player,now);
#endif
 const int result=originalLocalEnemyDamage(current.actor,(int32_t)damage,(uint32_t)contactPolicy->damageKind);LocalTarget after;
 if(!localReadContactTarget(current.actor,f->worldGeneration,&after)||after.generation!=current.generation||after.state!=current.state||
    !airVictimDamageConfirmed(current.hp,after.hp,result))return false;
 const bool damaged61=localDamageHealth61(current.hp,after.hp,result);
 if(damaged61){
 localChargeCredit48(f,player,now,sheet_sr1Combat48_combat_charge.hitCharge,"slam-ground");
#ifdef SR1_LOCAL_COMBAT51
 localFullHitAudio51(f,player,form,fullBefore51,now);
#ifdef SR1_LOCAL_COMBAT52
 if(fullBefore51)localFxTarget52(f,player,now,form,current.actor,after.generation,true);
#else
 if(fullBefore51)localFxQueue51(f,player,now,form,point,after.generation,false,true,true);
#endif
#endif
 }
 localVictimGroundSpark50(f,victimRoot,ticket->owner.tick,now);
 localRoll50=(__typeof__(localRoll50)){.ticket=*ticket,.impact=now};
 record("defiance-slam-ground-hit target=%u damage=%u hp=%d/%d",current.generation,damaged61?damage:0,current.hp,after.hp);return true;
}
static void localObserveRoll50(const Sr1LocalFrame *f,uint64_t now){
 if(!localRoll50.ticket.target.actor)return;
 LocalTarget current;uint32_t flags=0;int16_t height=0;int32_t velocity=0;
 const uint64_t age=now>=localRoll50.impact?now-localRoll50.impact:UINT64_MAX;
 if(age>AIR_SLAM_BOUNCE_MAX_MS+(localRoll50.started?200u:0u)||!localTicketCurrent(&localRoll50.ticket,f,now,UINT64_MAX,&current)||
    !localStockFlight(&current,f->realm)||!readAt(current.state,&flags,4)||!readAt(current.actor+0xa0,&height,2)||!readAt(current.actor+0x2d4,&velocity,4)){
  localRoll50=(__typeof__(localRoll50)){0};return;
 }
 if(localRoll50.started){
  if(height>localRoll50.peak)localRoll50.peak=height;
  if(current.mainState!=AIR_SLAM_ROLL_STATE||((flags&2)&&velocity<=0)){
   record("defiance-slam-roll-return target=%u state=%u rise=%d",current.generation,current.mainState,(int)localRoll50.peak-localRoll50.floor);
   localRoll50=(__typeof__(localRoll50)){0};
  }return;
 }
 if(current.mainState!=AIR_SLAM_ROLL_STATE||!(flags&2)||(flags&1))return;
 const C2Impact spark=localSlamSparkRead50();uintptr_t descriptor=0,active=0;
 if(spark.epoch!=f->session||spark.actorGeneration!=f->playerGeneration||spark.stream!=(int32_t)f->worldGeneration||
    spark.marker!=localRoll50.ticket.owner.tick||spark.tick!=localRoll50.impact||
    !airSlamBounceReady(localRoll50.impact,spark.tick,now)||!localRollDescriptor50(&current,&descriptor)||
    !readAt(current.state+0x1b0,&active,8)||active!=descriptor)return;
 LocalContactTicket bounce=localRoll50.ticket;memcpy(bounce.sphere.center,spark.point,6);
 if(localStartRollBounce50(&bounce,current,height,flags)){
  localRoll50.started=now;localRoll50.floor=height;localRoll50.peak=height+AIR_SLAM_BOUNCE_CLEARANCE;
  record("defiance-slam-roll-bounce target=%u floor=%d",current.generation,height);
 }else localRoll50=(__typeof__(localRoll50)){0};
}
