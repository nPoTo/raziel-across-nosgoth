// SPDX-License-Identifier: GPL-3.0-or-later
#pragma once
#include "local-combat-sync-policy.h"

typedef void (*LocalAnimationUpdate)(uintptr_t);
typedef uint32_t (*LocalAnimationClock)(void);
static LocalAnimationUpdate originalSynchronizedUpdate;
static LocalAnimationClock originalSynchronizedClock;
static _Thread_local struct {unsigned rate,legacy,remaster;} synchronizedClock;

static uint32_t localSynchronizedClockAt(uintptr_t caller) {
    const DWORD error=GetLastError();
    const uint32_t native=originalSynchronizedClock();
    const Sheet_sr1CombatSync42 *const policy=&sheet_sr1CombatSync42_synchronized_combat;
    const bool legacy=caller==base+policy->legacyClockReturn;
    const bool remaster=caller==base+policy->remasterClockReturn;
    uint32_t result=native;
    if (synchronizedClock.rate && (legacy||remaster)) {
        if (legacy) ++synchronizedClock.legacy;
        else ++synchronizedClock.remaster;
        result=combatSyncInterval(native,synchronizedClock.rate);
    }
    SetLastError(error);
    return result;
}

static uint32_t localSynchronizedClock(void) {
    return localSynchronizedClockAt((uintptr_t)__builtin_return_address(0));
}

static void localSynchronizedUpdateAt(uintptr_t state,uintptr_t caller) {
    const DWORD error=GetLastError();
    const Sheet_sr1CombatSync42 *const policy=&sheet_sr1CombatSync42_synchronized_combat;
    uintptr_t actor=0;
    const bool boundary=caller==base+policy->animationUpdateCallerRva &&
        state==base+host->stateActorRva && player && readAt(state,&actor,sizeof(actor)) && actor==player;
    const Sr1LocalFrame frame=boundary?readFrame():(Sr1LocalFrame){0};
    const bool owned=boundary && frame.ready && frame.groundStrike && frame.airState==SR1_AIR_NONE &&
        frame.realm!=SR1_LOCAL_UNKNOWN && frame.strikeOrdinal<2;
    const unsigned oldRate=synchronizedClock.rate,oldLegacy=synchronizedClock.legacy,oldRemaster=synchronizedClock.remaster;
    // One snapshot covers both legacy and remaster section loops. Native interpolation,
    // event dispatch and collision keep their original implementation and matching pace.
    synchronizedClock.rate=owned?(unsigned)policy->ratePermille:0;
    synchronizedClock.legacy=synchronizedClock.remaster=0;
    SetLastError(error);
    originalSynchronizedUpdate(state);
    const DWORD nativeError=GetLastError();
    if (owned) {
        static _Thread_local uintptr_t reported;
        if (reported!=frame.strikeIdentity) {
            reported=frame.strikeIdentity;
            record("standalone-sync-clock realm=%u ordinal=%u rate=%u legacy=%u remaster=%u",
                frame.realm,frame.strikeOrdinal,synchronizedClock.rate,synchronizedClock.legacy,synchronizedClock.remaster);
        }
    }
    synchronizedClock.rate=oldRate;
    synchronizedClock.legacy=oldLegacy;
    synchronizedClock.remaster=oldRemaster;
    SetLastError(nativeError);
}

static void localSynchronizedUpdate(uintptr_t state) {
    localSynchronizedUpdateAt(state,(uintptr_t)__builtin_return_address(0));
}

#ifndef LOCAL_SYNCHRONIZED_CLOCK_FIXTURE
#include "combat-sync-proof.h"
static bool prepareSynchronizedClock(void) {
    const Sheet_sr1CombatSync42 *const p=&sheet_sr1CombatSync42_synchronized_combat;
    if (!verifyDrawBlock(p->animationUpdateRva,p->animationUpdateBytes,COMBAT_SYNC_UPDATE_SHA) ||
        !verifyDrawBlock(p->clockRva,p->clockBytes,COMBAT_SYNC_CLOCK_SHA)) return false;
    if (MH_CreateHook((void *)(base+p->animationUpdateRva),localSynchronizedUpdate,
        (void **)&originalSynchronizedUpdate)!=MH_OK) return false;
    if (MH_CreateHook((void *)(base+p->clockRva),localSynchronizedClock,
        (void **)&originalSynchronizedClock)!=MH_OK) {
        MH_RemoveHook((void *)(base+p->animationUpdateRva));
        return false;
    }
    return true;
}
#endif
