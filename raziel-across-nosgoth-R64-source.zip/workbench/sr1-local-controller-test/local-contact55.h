// SPDX-License-Identifier: GPL-3.0-or-later
#pragma once
static bool localPerforateContact55(bool perforate,unsigned bank,unsigned first,uint64_t start,uint64_t now,uint64_t duration){
 return perforate&&bank==first&&duration&&now>=start&&
  (now-start)*1000u>=duration*(uint64_t)sheet_sr1Combat55_finish_contact_regen.perforateHitPermille;
}
