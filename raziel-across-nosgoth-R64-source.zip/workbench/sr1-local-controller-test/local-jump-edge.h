// SPDX-License-Identifier: GPL-3.0-or-later
#pragma once

static inline bool localFreshJumpPress(bool *heldLastSample, bool held, bool pressed) {
    const bool fresh = pressed && !*heldLastSample;
    *heldLastSample = held;
    return fresh;
}
