// SPDX-License-Identifier: GPL-3.0-or-later
// Read-only adapter around released0.2 native soul-update/reward boundaries.
#pragma once
static void (*originalSoul48)(uintptr_t);
static _Thread_local uintptr_t localRewardSoul48;
static _Thread_local uint32_t localRewardGeneration48;
static _Thread_local struct {uintptr_t actor;uint32_t generation;} localConsumedSouls48[64];
static _Thread_local unsigned localSoulCursor48;
static void localSoulUpdate48(uintptr_t soul){
 const DWORD incoming=GetLastError();const Sr1LocalFrame frame=readLocalFrame(false);
 uintptr_t object=0,name=0;uint32_t stream=0;char text[9]={0};
 const uintptr_t previous=localRewardSoul48;const uint32_t priorGen=localRewardGeneration48;
 localRewardSoul48=0;localRewardGeneration48=0;
 if(frame.ready&&frame.realm!=SR1_LOCAL_UNKNOWN&&soul&&readAt(soul+0x60,&stream,4)&&stream==frame.worldGeneration&&
  readAt(soul+0x30,&object,8)&&object&&readAt(object+0x30,&name,8)&&name&&readAt(name,text,9)&&!memcmp(text,"soul____",9)){
   localRewardGeneration48=generation(soul);if(localRewardGeneration48)localRewardSoul48=soul;
 }
 SetLastError(incoming);originalSoul48(soul);const DWORD outgoing=GetLastError();
 localRewardSoul48=previous;localRewardGeneration48=priorGen;SetLastError(outgoing);
}
static bool localSoulReward48(uintptr_t caller,uintptr_t recipient,uint32_t message){
 if(caller!=718990u||message!=16777238u||recipient!=player||!localRewardSoul48||!localRewardGeneration48)return false;
 for(unsigned i=0;i<64;i++)if(localConsumedSouls48[i].actor==localRewardSoul48&&localConsumedSouls48[i].generation==localRewardGeneration48)return false;
 const unsigned slot=localSoulCursor48++%64;localConsumedSouls48[slot].actor=localRewardSoul48;localConsumedSouls48[slot].generation=localRewardGeneration48;return true;
}
