// SPDX-License-Identifier: GPL-3.0-or-later
#pragma once
static uint64_t localSpecialChordMs56(bool ground,bool x,bool y,uint64_t ordinary){
 return ground&&x&&!y?(uint64_t)sheet_sr1Combat56_action_facing_relift.perforateChordMs:ordinary;
}
