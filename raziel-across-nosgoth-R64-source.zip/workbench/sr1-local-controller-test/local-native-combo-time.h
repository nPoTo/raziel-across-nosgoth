// SPDX-License-Identifier: GPL-3.0-or-later
#pragma once

static inline bool nativeGroundLinkKnown(unsigned ordinal, int32_t end) {
    return ordinal < sheet_sr1CombatNativeLink_count &&
        end == sheet_sr1CombatNativeLink_rows[ordinal]->clipEnd;
}

static inline int16_t nativeGroundLinkInterval(unsigned ordinal, int16_t interval) {
    const Sheet_sr1CombatNativeClock *const policy = &sheet_sr1CombatNativeClock_section_advance;
    if (ordinal >= sheet_sr1CombatNativeLink_count || interval <= 0 ||
        interval > policy->stockMaxInterval) return interval;
    const Sheet_sr1CombatNativeLink *const link = sheet_sr1CombatNativeLink_rows[ordinal];
    return (int16_t)((interval * link->baselineMs + link->referenceMs / 2) / link->referenceMs);
}
