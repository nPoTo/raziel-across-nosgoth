// SPDX-License-Identifier: GPL-3.0-or-later
#pragma once
typedef struct{LocalActionOwner owner;uintptr_t target,state;uint32_t gen;unsigned lifts;uint64_t sequence,upright;bool expelled;}LocalLiftChain56;
static _Thread_local LocalLiftChain56 localLiftChains56[128];static _Thread_local unsigned localLiftCursor56;
static LocalLiftChain56*localLiftChain56(const LocalContactTicket*t,uint64_t now){
 const Sr1LocalFrame f=readFrame();
 for(unsigned i=0;i<128;i++){LocalLiftChain56*c=&localLiftChains56[i];if(c->target==t->target.actor&&c->gen==t->target.generation&&
  sameLocalAction(&c->owner,&f,player,now,UINT64_MAX)&&c->state==t->target.state)return c;}
 LocalLiftChain56*c=&localLiftChains56[localLiftCursor56++%128];*c=(LocalLiftChain56){.owner=t->owner,.target=t->target.actor,.state=t->target.state,.gen=t->target.generation};return c;
}
static bool localExpelVictim56(const LocalContactTicket*t,LocalTarget current,uint64_t now){
 int16_t from[3],to[3];if(!readAt(player+0x9c,from,6)||!readAt(current.actor+0x9c,to,6))return false;
 int dx=(int)to[0]-from[0],dy=(int)to[1]-from[1];int32_t velocity[3]={0,0,(int32_t)sheet_sr1Combat56_action_facing_relift.expelVelocity};
 if(!dx&&!dy){uint16_t yaw=0;if(!readAt(player+sheet_sr1GroundSteering_camera_relative_start.yawOffset,&yaw,2))return false;const float a=yaw*6.28318530718f/4096.f;dx=(int)lroundf(sinf(a)*1024);dy=(int)lroundf(-cosf(a)*1024);}
 const double length=hypot(dx,dy);if(length<1)return false;
 velocity[0]=(int32_t)lround(dx*sheet_sr1Combat56_action_facing_relift.expelSpeed/length);velocity[1]=(int32_t)lround(dy*sheet_sr1Combat56_action_facing_relift.expelSpeed/length);
 originalLocalVictimTransition(current.actor,AIR_FLIGHT_STATE);LocalTarget after;
 if(!localReadContactTarget(current.actor,t->owner.world,&after)||after.generation!=current.generation||after.state!=current.state||after.mainState!=AIR_FLIGHT_STATE)return false;
 const int32_t gravity[3]={0,0,(int32_t)sheet_sr1Combat56_action_facing_relift.expelGravity};
 memcpy((void*)(current.actor+0x2cc),velocity,sizeof velocity);memcpy((void*)(current.actor+0x2d8),gravity,sizeof gravity);
 localFlight=(LocalVictimFlight){0};localFlightTicket=*t;localVictimGroundedAt=0;localStasisLockedUntil=0;
 record("defiance-victim-fifth-expel target=%u velocity=%ld/%ld/%ld tick=%llu",current.generation,(long)velocity[0],(long)velocity[1],(long)velocity[2],(unsigned long long)now);return true;
}
static void localObserveLiftChains56(const Sr1LocalFrame*f,uint64_t now){
 for(unsigned i=0;i<128;i++){LocalLiftChain56*c=&localLiftChains56[i];if(!c->target)continue;LocalTarget target;int32_t vertical=0;uint32_t flags=0;
  if(!sameLocalAction(&c->owner,f,player,now,UINT64_MAX)||!localReadContactTarget(c->target,f->worldGeneration,&target)||target.generation!=c->gen||target.state!=c->state){memset(c,0,sizeof*c);continue;}
  const bool upright=target.hp>0&&target.mainState<11&&target.mainState!=4&&target.mainState!=8&&target.mainState!=9&&
   readAt(target.actor+0x2d4,&vertical,4)&&!vertical&&readAt(target.state,&flags,4)&&(flags&2u);
  if(!upright){c->upright=0;continue;}if(!c->upright)c->upright=now;
  if(now-c->upright>=(uint64_t)sheet_sr1Combat56_action_facing_relift.recoverMs){record("defiance-victim-lift-reset target=%u count=%u",c->gen,c->lifts);memset(c,0,sizeof*c);}
 }
}
