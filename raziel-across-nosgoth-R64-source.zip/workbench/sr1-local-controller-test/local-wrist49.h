// SPDX-License-Identifier: GPL-3.0-or-later
#pragma once
#include "local-wrist48.h"
static bool localThrustWrist49(float pose[66][13],const int16_t parents[66],float weight){
 if(!isfinite(weight)||weight<=0.f)return false;if(weight>1.f)weight=1.f;
 const unsigned wrist=sheet_reaverPalmBasis_anatomical.targetWrist;const int elbow=parents[wrist];
 if(elbow<0||elbow>=66)return false;
 float grip[16];if(!localWristBlade48(grip,pose[wrist],pose[wrist]+10))return false;
 float desired[3],length=0;for(unsigned k=0;k<3;k++){desired[k]=pose[wrist][10+k]-pose[elbow][10+k];length+=desired[k]*desired[k];}
 length=sqrtf(length);if(!isfinite(length)||length<1.f)return false;for(unsigned k=0;k<3;k++)desired[k]/=length;
 float axis[3]={grip[9]*desired[2]-grip[10]*desired[1],grip[10]*desired[0]-grip[8]*desired[2],grip[8]*desired[1]-grip[9]*desired[0]};
 const float sine=hypotf(hypotf(axis[0],axis[1]),axis[2]);const float dot=fmaxf(-1.f,fminf(1.f,grip[8]*desired[0]+grip[9]*desired[1]+grip[10]*desired[2]));
 if(sine<.00001f){if(dot>0)return true;for(unsigned k=0;k<3;k++)axis[k]=grip[k];}else for(unsigned k=0;k<3;k++)axis[k]/=sine;
 const float angle=atan2f(sine,dot)*weight,c=cosf(angle),s=sinf(angle);float rotation[3][3];
 for(unsigned column=0;column<3;column++){
  const float v[3]={column==0,column==1,column==2},cross[3]={axis[1]*v[2]-axis[2]*v[1],axis[2]*v[0]-axis[0]*v[2],axis[0]*v[1]-axis[1]*v[0]};
  for(unsigned row=0;row<3;row++)rotation[row][column]=c*v[row]+s*cross[row]+(1-c)*axis[column]*axis[row];
 }
 const float pivot[3]={pose[wrist][10],pose[wrist][11],pose[wrist][12]};
 for(unsigned bone=0;bone<66;bone++){
  int ancestor=(int)bone;for(unsigned step=0;ancestor>=0&&ancestor!=(int)wrist&&step<66;step++)ancestor=parents[ancestor];if(ancestor!=(int)wrist)continue;
  float before[13];memcpy(before,pose[bone],sizeof before);
  for(unsigned row=0;row<3;row++){
   pose[bone][10+row]=pivot[row];for(unsigned k=0;k<3;k++)pose[bone][10+row]+=rotation[row][k]*(before[10+k]-pivot[k]);
   for(unsigned column=0;column<3;column++){pose[bone][row*3+column]=0;for(unsigned k=0;k<3;k++)pose[bone][row*3+column]+=rotation[row][k]*before[k*3+column];}
  }
 }
 return true;
}
