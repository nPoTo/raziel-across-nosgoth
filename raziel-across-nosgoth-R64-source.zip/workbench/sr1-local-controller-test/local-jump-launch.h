// SPDX-License-Identifier: GPL-3.0-or-later
#pragma once

#include "lift-launch-proof.h"

typedef void (*LocalJumpLaunchFn)(uintptr_t, int32_t, int32_t, int32_t, int32_t);
static LocalJumpLaunchFn originalLocalJump;

static void localJumpLaunch(uintptr_t actor, int32_t gravity, int32_t x, int32_t y, int32_t z) {
    const uintptr_t caller = (uintptr_t)__builtin_return_address(0) - base;
    if (!ordinaryLaunchArgs(caller, gravity, x, y, z)) {
        originalLocalJump(actor, gravity, x, y, z);
        return;
    }

    const DWORD savedError = GetLastError();
    const Sr1LocalFrame frame = readFrame();
    int16_t position[3];
    const bool drawReady = InterlockedCompareExchange(&calibratedDrawReady, 0, 0) != 0;
#ifdef SR1_LOCAL_REPEAT_DRAW_LEASE
    const bool repeatReady = repeatJump.shortenedCompression && localRepeatOwnsFlight(&frame, GetTickCount64());
#else
    const bool repeatReady = false;
#endif
    if (!frame.ready || !frame.renderBlend || frame.airState != SR1_AIR_COMPRESS ||
        frame.realm == SR1_LOCAL_UNKNOWN || actor != player || frame.verticalVelocity != 0 ||
        (!drawReady && !repeatReady) || !readAt(actor + 0x9c, position, sizeof(position))) {
        SetLastError(savedError);
        originalLocalJump(actor, gravity, x, y, z);
        return;
    }

    SetLastError(savedError);
    originalLocalJump(actor, gravity, x, y, airPolicy->vertical);
    const DWORD nativeError = GetLastError();
    const uint64_t launchAt = GetTickCount64();
    publishLocalJump(&frame, actor, launchAt, position[2], y);
#ifdef SR1_LOCAL_COMBAT_TEMPO
    confirmLocalLiftJump(&frame, actor, launchAt);
#endif
    record("defiance-jump-launch realm=%u forward=%ld vz=%ld->%ld gravity=%ld",
        frame.realm, (long)y, (long)z, (long)airPolicy->vertical, (long)gravity);
    SetLastError(nativeError);
}

static bool prepareLocalJump(void) {
    const Sheet_sr1LocalDefianceJump *p = airPolicy;
    if (!verifyDrawBlock(p->launchRva, 56, LIFT_LAUNCH_SHA) ||
        !verifyDrawBlock(p->standingReturnRva - 30, 30, JUMP_STANDING_SHA) ||
        !verifyDrawBlock(p->runningReturnRva - 30, 30, LIFT_COMPRESSION_SHA)) return false;
    return MH_CreateHook((void *)(base + p->launchRva), localJumpLaunch, (void **)&originalLocalJump) == MH_OK;
}
