// SPDX-License-Identifier: GPL-3.0-or-later
#pragma once

#ifdef SR1_LOCAL_SPECIAL_INPUT
static inline void combatBlendBladeBasis(float palm[16],const float socket[16],float weight) {
    float a[9],b[9],qa[4],qb[4],q[4],rotation[9];
    for (unsigned row=0;row<3;++row) for (unsigned col=0;col<3;++col) {
        a[row*3+col]=palm[col*4+row];
        b[row*3+col]=socket[col*4+row];
    }
    jumpQuat(a,qa);
    jumpQuat(b,qb);
    groundBlendRotation(qa,qb,weight,q);
    jumpMatrix(q,rotation);
    for (unsigned row=0;row<3;++row) for (unsigned col=0;col<3;++col)
        palm[col*4+row]=rotation[row*3+col];
}
#endif

static inline float combatPelvisYaw(const float q[4]) {
    return atan2f(2.f*(q[0]*q[1]+q[2]*q[3]),1.f-2.f*(q[1]*q[1]+q[2]*q[2]));
}

static inline void combatSetPelvisYaw(float q[4],float desired) {
    const float half=(desired-combatPelvisYaw(q))*.5f;
    const float c=cosf(half),s=sinf(half);
    const float x=q[0],y=q[1],z=q[2],w=q[3];
    q[0]=c*x-s*y;
    q[1]=c*y+s*x;
    q[2]=c*z+s*w;
    q[3]=c*w-s*z;
}

static inline float combatSpinPhase(uint64_t age) {
    const uint64_t loop=
#ifdef SR1_LOCAL_COMBAT_SYNC42
        combatRotorPeriod();
#elif defined(SR1_LOCAL_SPECIAL_RECOVERY)
        sheet_sr1CombatSpecialRecovery_special_recovery.spinLoopMs;
#else
        sheet_sr1CombatContinuity_continuous_combat.spinLoopMs;
#endif
    return (float)(age%loop)/(float)loop;
}
