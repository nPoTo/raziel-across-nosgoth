// SPDX-License-Identifier: GPL-3.0-or-later
#pragma once
#include <math.h>
#include <string.h>
// Rotate an anatomical subtree, preserving all lengths. No world/physics writes.
static bool localAlignArm57(float pose[66][13],unsigned first,unsigned child,const float direction[3],float weight){
 float from[3],to[3],pivot[3],a=0,b=0;
 if(!isfinite(weight)||weight<=0||first>=child||child>41)return false;
 for(unsigned k=0;k<3;k++){pivot[k]=pose[first][10+k];from[k]=pose[child][10+k]-pivot[k];to[k]=direction[k];a+=from[k]*from[k];b+=to[k]*to[k];}
 if(!isfinite(a)||!isfinite(b)||a<1||b<.001f)return false;a=sqrtf(a);b=sqrtf(b);float dot=0;
 for(unsigned k=0;k<3;k++){from[k]/=a;to[k]/=b;dot+=from[k]*to[k];}
 dot=fmaxf(-1,fminf(1,dot));float axis[3]={from[1]*to[2]-from[2]*to[1],from[2]*to[0]-from[0]*to[2],from[0]*to[1]-from[1]*to[0]};
 float n=sqrtf(axis[0]*axis[0]+axis[1]*axis[1]+axis[2]*axis[2]);
 if(n<.0001f){if(dot>0)return true;axis[0]=-from[1];axis[1]=from[0];axis[2]=0;n=hypotf(axis[0],axis[1]);if(n<.0001f){axis[0]=1;n=1;}}
 for(unsigned k=0;k<3;k++)axis[k]/=n;
 for(unsigned bone=first;bone<=49;bone++)for(unsigned k=0;k<13;k++)if(k!=9&&!isfinite(pose[bone][k]))return false;
 const float angle=acosf(dot)*fminf(1,weight),c=cosf(angle),s=sinf(angle),t=1-c,x=axis[0],y=axis[1],z=axis[2];
 const float r[9]={c+x*x*t,x*y*t-z*s,x*z*t+y*s,y*x*t+z*s,c+y*y*t,y*z*t-x*s,z*x*t-y*s,z*y*t+x*s,c+z*z*t};
 for(unsigned bone=first;bone<=49;bone++){float old[13];memcpy(old,pose[bone],sizeof old);for(unsigned row=0;row<3;row++){
  for(unsigned col=0;col<3;col++){float v=0;for(unsigned k=0;k<3;k++)v+=r[row*3+k]*old[k*3+col];pose[bone][row*3+col]=v;}
  float v=pivot[row];for(unsigned k=0;k<3;k++)v+=r[row*3+k]*(old[10+k]-pivot[k]);pose[bone][10+row]=v;
 }}return true;
}
static bool localFinishExtend57(float pose[66][13],unsigned yaw,float weight){
 const float angle=(yaw&4095u)*(6.28318530718f/4096.f),direction[3]={sinf(angle),-cosf(angle),0};
 float scratch[66][13];memcpy(scratch,pose,sizeof scratch);
 if(!localAlignArm57(scratch,39,40,direction,weight)||!localAlignArm57(scratch,40,41,direction,weight))return false;
 memcpy(pose,scratch,sizeof scratch);return true;
}
// Clip inward displacement at the first circle crossing; never teleport outward.
static float localSpacingClip57(float x,float y,float radius,float*dx,float*dy){
 if(!isfinite(x)||!isfinite(y)||!isfinite(radius)||radius<=0||!isfinite(*dx)||!isfinite(*dy))return 1;
 const float distance=x*x+y*y,step=*dx**dx+*dy**dy,dot=x**dx+y**dy;
 if(distance<1||step<.0001f||dot<=0)return 1;
 if(distance<=radius*radius){const float inward=dot/distance;*dx-=inward*x;*dy-=inward*y;return 0;}
 const float disc=dot*dot-step*(distance-radius*radius);if(disc<0)return 1;
 const float t=(dot-sqrtf(disc))/step;if(t<0||t>=1)return 1;
 *dx*=t;*dy*=t;return t;
}
