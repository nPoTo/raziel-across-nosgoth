// SPDX-License-Identifier: GPL-3.0-or-later
#pragma once

#ifdef SR1_LOCAL_COMBAT_REPAIR
static inline unsigned localDodgeFromBearing(int delta) {
#ifdef SR1_LOCAL_SPECIAL_RECOVERY
    if (delta>=512 && delta<1536) return 2;
    if (delta<=-512 && delta>-1536) return 0;
#else
    if (delta>=512 && delta<1536) return 0;
    if (delta<=-512 && delta>-1536) return 2;
#endif
    return delta>-512 && delta<512 ? 3 : 1;
}
#endif

static inline unsigned localDodgeDirection(int32_t x, int32_t y, int32_t threshold) {
    if (x >= -threshold && x <= threshold) return 1;
    const int64_t side = x < 0 ? -(int64_t)x : x;
    const int64_t forward = y < 0 ? -(int64_t)y : y;
    return side < forward ? 1 : x < 0 ? 2 : 0;
}

static inline float localDodgeDistance(unsigned direction, uint64_t age) {
    const Sheet_sr1CombatDodgeReference *const row = sheet_sr1CombatDodgeReference_rows[direction];
    if (age >= (uint64_t)row->durationMs) return (float)row->distance;
    const float sample = (float)age * 10.f / (float)row->durationMs;
    const unsigned lower = (unsigned)sample;
    const unsigned *curve = localDodgeCurves[direction];
    const float weight = sample - lower;
    return row->distance * (curve[lower] + weight * (curve[lower+1] - curve[lower])) / 1000.f;
}
