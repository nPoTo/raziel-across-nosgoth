// SPDX-License-Identifier: GPL-3.0-or-later
#pragma once
static bool localNearestTarget49(const Sr1LocalFrame *f,uintptr_t actor,uintptr_t *chosen,uint32_t *chosenGeneration){
 uintptr_t list=0,node=0,previous=0;uint32_t count=0;int16_t origin[3];
 if(!f->ready||!f->renderBlend||!readAt(actor+0x9c,origin,6)||!readAt(base+contactPolicy->listRva,&list,8)||!list||
    !readAt(list,&count,4)||!count||count>512||!readAt(list+8,&node,8))return false;
 const uint32_t playerClass=(uint32_t)((QueryInstance)(base+signals->queryRva))(actor,1);
 if(!playerClass)return false;
 const float sight[3]={origin[0],origin[1],origin[2]+128.f};
 int64_t best=sheet_sr1Combat49_combat_physics.targetRadius*sheet_sr1Combat49_combat_physics.targetRadius;
 uintptr_t selected=0;uint32_t selectedGen=0;bool sourceFound=false;
 while(count--){
  uintptr_t next=0,back=0;if(!node||!readAt(node+0x10,&next,8)||!readAt(node+0x18,&back,8)||back!=previous)return false;
  if(node==actor)sourceFound=true;
  else{
   LocalTarget candidate;int16_t point[3];uintptr_t attributes=0,allegiance=0;uint32_t enemies=0;
#ifdef SR1_LOCAL_COMBAT59
   if(localLockCandidate59(node,f,&candidate)&&
      ((candidate.nativeKind>=LOCAL_NATIVE59_LIMB)||(
#else
   if(localReadContactTarget(node,f->worldGeneration,&candidate)&&
#endif
      readAt(candidate.state+0x280,&attributes,8)&&attributes&&readAt(attributes+0x18,&allegiance,8)&&allegiance&&
      readAt(allegiance,&enemies,4)&&(enemies&playerClass)
#ifdef SR1_LOCAL_COMBAT59
      ))
#endif
      &&readAt(node+0x9c,point,6)){
    int64_t distance=0;for(unsigned k=0;k<3;k++){const int64_t d=(int)point[k]-origin[k];distance+=d*d;}
    if(distance<=best&&(!selected||distance<best||candidate.generation<selectedGen)&&point[2]<=INT16_MAX-128){
     point[2]+=128;
     if(localNativeLineClear(actor,f->worldGeneration,sight,point)){selected=node;selectedGen=candidate.generation;best=distance;}
    }
   }
  }
  previous=node;node=next;
 }
 if(node||!sourceFound)return false;
 *chosen=selected;*chosenGeneration=selectedGen;return selected!=0;
}
static bool localDodgeClear49(const Sr1LocalFrame *f,uintptr_t actor,float side,float forward){
 int16_t root[3];uint16_t yaw;
 if(!readAt(actor+0x9c,root,6)||!readAt(actor+sheet_sr1GroundSteering_camera_relative_start.yawOffset,&yaw,2))return false;
 const float angle=yaw*(6.28318530718f/4096.f),s=sinf(angle),c=cosf(angle);
 const float dx=c*side-s*forward,dy=s*side+c*forward;
 const Sheet_sr1Combat49 *p=&sheet_sr1Combat49_combat_physics;
 for(unsigned height=0;height<2;height++)for(int edge=-1;edge<=1;edge++){
  const float from[3]={root[0]+edge*p->dodgeWidth*c,root[1]+edge*p->dodgeWidth*s,root[2]+(height?p->dodgeHigh:p->dodgeLow)};
  const float end[3]={from[0]+dx,from[1]+dy,from[2]};int16_t to[3];
  for(unsigned k=0;k<3;k++){if(!isfinite(end[k])||end[k]<INT16_MIN||end[k]>INT16_MAX)return false;to[k]=(int16_t)lroundf(end[k]);}
  if(!localNativeLineClear(actor,f->worldGeneration,from,to))return false;
 }
 const float above[3]={root[0]+dx,root[1]+dy,root[2]+p->dodgeFloorAbove};
 const float below= root[2]-p->dodgeFloorBelow;
 if(below<INT16_MIN||above[0]<INT16_MIN||above[0]>INT16_MAX||above[1]<INT16_MIN||above[1]>INT16_MAX)return false;
 const int16_t floor[3]={(int16_t)lroundf(above[0]),(int16_t)lroundf(above[1]),(int16_t)below};
 return !localNativeLineClear(actor,f->worldGeneration,above,floor);
}
