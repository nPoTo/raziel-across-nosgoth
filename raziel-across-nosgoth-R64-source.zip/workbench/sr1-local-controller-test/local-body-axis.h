// SPDX-License-Identifier: GPL-3.0-or-later
#pragma once

static inline bool bodyAxisFromPose(const float pose[66][13],float pivot[3],float axis[3]) {
    const Sheet_sr1BodyAxis43 *const policy=&sheet_sr1BodyAxis43_chest_head_axis;
    if (policy->pivotBone<1 || policy->headBone<1 || policy->pivotBone>=66 || policy->headBone>=66) return false;
    float length=0.f;
    for (unsigned i=0;i<3;++i) {
        pivot[i]=pose[policy->pivotBone][10+i];
        axis[i]=pose[policy->headBone][10+i]-pivot[i];
        if (!isfinite(pivot[i]) || !isfinite(axis[i])) return false;
        length+=axis[i]*axis[i];
    }
    length=sqrtf(length);
    if (!isfinite(length) || length<policy->minAxisMilli/1000.f) return false;
    for (unsigned i=0;i<3;++i) axis[i]/=length;
    return true;
}

static inline float bodyAxisBlendAngle(float angle,float weight) {
    if (weight>=1.f) return angle;
    if (weight<=0.f) return 0.f;
    const float half=.5f*angle,c=cosf(half),direction=c<0.f?-1.f:1.f;
    return 2.f*atan2f(weight*direction*sinf(half),1.f-weight+weight*direction*c);
}

static inline float bodyAxisSampleAngle(const float *values,unsigned count,float sample) {
    if (count<2 || !isfinite(sample)) return 0.f;
    sample=fminf(count-1.f,fmaxf(0.f,sample));
    const unsigned lower=(unsigned)fminf(count-2.f,sample);
    return values[lower]+(sample-lower)*(values[lower+1]-values[lower]);
}

static inline float bodyAxisDirection(const float *values,unsigned count) {
    return count>=2 && values[count-1]<values[0]?-1.f:1.f;
}

static inline bool bodyAxisRotatePose(float pose[66][13],float angle) {
    float pivot[3],axis[3];
    if (!isfinite(angle) || !bodyAxisFromPose(pose,pivot,axis)) return false;
    // Validate before changing scratch. The actor root and caller-owned matrices stay untouched.
    for (unsigned bone=1;bone<66;++bone) for (unsigned i=0;i<13;++i)
        if (i!=9 && !isfinite(pose[bone][i])) return false;
    const float c=cosf(angle),s=sinf(angle),t=1.f-c,x=axis[0],y=axis[1],z=axis[2];
    const float rotation[9]={c+x*x*t,x*y*t-z*s,x*z*t+y*s,
        y*x*t+z*s,c+y*y*t,y*z*t-x*s,z*x*t-y*s,z*y*t+x*s,c+z*z*t};
    for (unsigned bone=1;bone<66;++bone) {
        float before[13];memcpy(before,pose[bone],sizeof(before));
        for (unsigned row=0;row<3;++row) {
            for (unsigned col=0;col<3;++col) {
                float value=0.f;
                for (unsigned k=0;k<3;++k) value+=rotation[row*3+k]*before[k*3+col];
                pose[bone][row*3+col]=value;
            }
            float value=pivot[row];
            for (unsigned k=0;k<3;++k) value+=rotation[row*3+k]*(before[10+k]-pivot[k]);
            pose[bone][10+row]=value;
        }
    }
    return true;
}
