// SPDX-License-Identifier: GPL-3.0-or-later
#pragma once

static const Sheet_sr1CombatFacing *const combatFacing = &sheet_sr1CombatFacing_standalone_combat_facing;
#ifdef SR1_LOCAL_COMBAT_LINKS
static const Sheet_sr1CombatLinks *const combatLinks = &sheet_sr1CombatLinks_standalone_links;
#endif

static inline bool combatDirectionHeld(int32_t x, int32_t y, int32_t threshold) {
    return x > threshold || x < -threshold || y > threshold || y < -threshold;
}

static inline unsigned combatCameraYaw(int32_t x, int32_t y, unsigned camera) {
    const float turns = atan2f((float)y, (float)x) * (4096.f / 6.2831853071795864769f);
    return (camera + 1024u - (int)turns) & 4095u;
}

static inline int combatYawDelta(unsigned from, unsigned to) {
    return (int)((to - from + 2048u) & 4095u) - 2048;
}

static inline unsigned combatTurnStep(unsigned from, unsigned to) {
    const int limit = (int)combatFacing->maxGroundTurn;
    const int delta = combatYawDelta(from, to);
    return (from + (delta < -limit ? -limit : delta > limit ? limit : delta)) & 4095u;
}

static inline void combatDodgeVector(unsigned yaw, unsigned desired, float distance, float *side, float *forward) {
    const float radians = combatYawDelta(yaw, desired) * (6.2831853071795864769f / 4096.f);
    *side = sinf(radians) * distance;
    *forward = -cosf(radians) * distance;
}
