// SPDX-License-Identifier: GPL-3.0-or-later
#pragma once

#include "local-air-slam-motion.h"
#include "physics-code-proof.h"

typedef struct {
    LocalActionOwner owner;
    uint64_t flight, windup, lastStep, falling, impact;
    bool cancelled;
#ifdef SR1_LOCAL_AIR_CONTACT
    bool rebound;
#endif
#ifdef SR1_LOCAL_SLAM_COAST
    bool carryDirection;
    int32_t entryVelocity[2];
    int16_t origin[2];
#endif
} LocalAirSlam;

static const Sheet_sr1LocalAirSlam *const slamPolicy = &sheet_sr1LocalAirSlam_standalone_downward_strike;
#ifdef SR1_LOCAL_SLAM_COAST
static const Sheet_sr1LocalAirSlamCoast *const slamCoast = &sheet_sr1LocalAirSlamCoast_moving_slam;
#endif
static SRWLOCK localAirSlamLock = SRWLOCK_INIT;
static LocalAirSlam localAirSlam;
static volatile LONG localAirSlamReady;
typedef void (*LocalSlamPhysics)(uintptr_t, int32_t, int32_t, int32_t);
static LocalSlamPhysics originalSlamPhysics;

static bool localSlamAirborne(const Sr1LocalFrame *frame) {
    return frame->ready && frame->renderBlend && frame->realm != SR1_LOCAL_UNKNOWN &&
        (frame->airState == SR1_AIR_JUMP || frame->airState == SR1_AIR_FALL);
}

static LocalAirSlam localSlamSnapshot(void) {
    LocalAirSlam slam = {0};
    if (TryAcquireSRWLockShared(&localAirSlamLock)) {
        slam = localAirSlam;
        ReleaseSRWLockShared(&localAirSlamLock);
    }
    return slam;
}

static LocalAirSlam readLocalSlam(const Sr1LocalFrame *frame, uintptr_t actor, uint64_t now,
    uint64_t recoveryMs) {
    const LocalAirSlam slam = localSlamSnapshot();
    if (slam.cancelled || !frame->ready || !frame->renderBlend ||
        !sameLocalAction(&slam.owner, frame, actor, now, airPolicy->maxFlightMs) ||
        readLocalJump().owner.tick != slam.flight)
        return (LocalAirSlam){0};
    if (slam.impact) {
        if (now < slam.impact || now - slam.impact >= recoveryMs ||
            !(localSlamAirborne(frame) || frame->airState == SR1_AIR_LAND || frame->grounded))
            return (LocalAirSlam){0};
    } else {
        const uint64_t latest = slam.lastStep ? slam.lastStep : slam.owner.tick;
        if (!localSlamAirborne(frame) || now < latest || now - latest > (uint64_t)groundPolicy->maxGapMs)
            return (LocalAirSlam){0};
    }
    return slam;
}

static void requestLocalSlam(const Sr1LocalFrame *frame, uintptr_t actor, uint64_t now, bool directionalInput) {
    const LocalJumpReceipt jump = readLocalJump();
    int16_t position[3];
    if (!InterlockedCompareExchange(&localAirSlamReady, 0, 0) || !localSlamAirborne(frame) ||
        !sameLocalAction(&jump.owner, frame, actor, now, airPolicy->maxFlightMs) ||
        !readAt(actor + 0x9c, position, sizeof(position)) || (int)position[2] - jump.floor < slamPolicy->minRise)
        return;
    AcquireSRWLockExclusive(&localAirSlamLock);
    const bool admit = localAirSlam.flight != jump.owner.tick ||
        !sameLocalAction(&localAirSlam.owner, frame, actor, now, UINT64_MAX);
    if (admit) {
        const LocalActionOwner owner = localActionOwner(frame, actor, now);
        localAirSlam = (LocalAirSlam){.owner = owner, .flight = jump.owner.tick};
#ifdef SR1_LOCAL_SLAM_COAST
        localAirSlam.carryDirection = directionalInput || jump.forward == airPolicy->runningForward;
        memcpy(localAirSlam.origin, position, sizeof(localAirSlam.origin));
#else
        (void)directionalInput;
#endif
    }
    ReleaseSRWLockExclusive(&localAirSlamLock);
}

static void confirmLocalSlamImpact(const Sr1LocalFrame *frame, uintptr_t actor, uint64_t now) {
    const LocalJumpReceipt jump = readLocalJump();
    AcquireSRWLockExclusive(&localAirSlamLock);
    LocalAirSlam *slam = &localAirSlam;
    const bool admitted = frame->ready && !slam->cancelled && !slam->impact && slam->falling && slam->lastStep <= now &&
        now - slam->lastStep <= (uint64_t)groundPolicy->maxGapMs &&
        jump.owner.tick == slam->flight &&
        sameLocalAction(&slam->owner, frame, actor, now, airPolicy->maxFlightMs);
    if (admitted) slam->impact = now;
#ifdef SR1_LOCAL_FORMS45
    const uint64_t audioToken=slam->owner.tick;
#endif
#ifdef SR1_LOCAL_SLAM_COAST
    int16_t origin[2];
    memcpy(origin, slam->origin, sizeof(origin));
#endif
    ReleaseSRWLockExclusive(&localAirSlamLock);
    if (admitted) {
#ifdef SR1_LOCAL_COMBAT49
        localGroundSpark49(frame,actor,now);
#endif
#ifdef SR1_LOCAL_FORMS45
        localSlamImpactAudio(frame,actor,audioToken,now);
#endif
#ifdef SR1_LOCAL_SLAM_COAST
        int16_t position[2];
        if (readAt(actor + 0x9c, position, sizeof(position))) {
            record("defiance-slam-impact realm=%u vz=%ld planar=%d,%d", frame->realm, (long)frame->verticalVelocity,
                (int)position[0] - origin[0], (int)position[1] - origin[1]);
            return;
        }
#endif
        record("defiance-slam-impact realm=%u vz=%ld", frame->realm, (long)frame->verticalVelocity);
    }
}

static void localSlamOnPad(const Sr1LocalFrame *frame, uintptr_t actor, uint64_t now) {
    const LocalAirSlam slam = localSlamSnapshot();
    if (!frame->ready || slam.cancelled || !sameLocalAction(&slam.owner, frame, actor, now, airPolicy->maxFlightMs))
        return;
    if (frame->renderBlend && frame->airState == SR1_AIR_LAND) {
        confirmLocalSlamImpact(frame, actor, now);
    } else if (!frame->renderBlend || (!slam.impact && !localSlamAirborne(frame))) {
        AcquireSRWLockExclusive(&localAirSlamLock);
        if (localAirSlam.owner.tick == slam.owner.tick) localAirSlam.cancelled = true;
        ReleaseSRWLockExclusive(&localAirSlamLock);
    }
}

#ifdef SR1_LOCAL_AIR_STRIKE
#include "local-air-strike.h"
#endif

static void localSlamPhysicsAt(uintptr_t actor, int32_t segment, int32_t time, int32_t clamp,uintptr_t caller) {
    if (actor != player || (caller != (uintptr_t)slamPolicy->standardReturnRva &&
        caller != (uintptr_t)slamPolicy->alternateReturnRva) || segment || clamp || time <= 0 ||
        time > slamPolicy->integrationMax) {
        originalSlamPhysics(actor, segment, time, clamp);
        return;
    }
    const DWORD previousError = GetLastError();
    const uint64_t now = GetTickCount64();
    const LocalAirSlam snapshot = localSlamSnapshot();
    const uint64_t previous = snapshot.lastStep ? snapshot.lastStep : snapshot.owner.tick;
    if (snapshot.owner.actor != actor || snapshot.cancelled || snapshot.impact || previous > now ||
        now - previous > (uint64_t)groundPolicy->maxGapMs) {
#ifdef SR1_LOCAL_AIR_CONTACT
#ifdef SR1_LOCAL_TEMPEST_FLIGHT
        if (applyLocalTempestPhysics(actor, segment, time, clamp, now, previousError)) return;
#else
        const Sr1LocalFrame specialFrame=readFrame();
        const unsigned factor=localSpecialAirFactor(&specialFrame,actor,now);
        if (factor<1000) {
            SetLastError(previousError);
            originalSlamPhysics(actor,segment,(int32_t)((int64_t)time*factor/1000),clamp);
            return;
        }
#endif
#endif
#ifdef SR1_LOCAL_AIR_STRIKE
        if (applyLocalAirStrikePhysics(actor, segment, time, clamp, now, previousError)) return;
#endif
        SetLastError(previousError);
        originalSlamPhysics(actor, segment, time, clamp);
        return;
    }
    const Sr1LocalFrame frame = readFrame();
    const LocalJumpReceipt jump = readLocalJump();
    LocalSlamKinematics before;
    const uintptr_t kinematics = actor + (uintptr_t)slamPolicy->kinematicsOffset;
    bool first = false, release = false, windup = false, owns = false;
#ifdef SR1_LOCAL_SLAM_COAST
    int32_t planar[2] = {0};
#endif
    if (localSlamAirborne(&frame) && actor == player &&
        sameLocalAction(&jump.owner, &frame, actor, now, airPolicy->maxFlightMs) &&
        readAt(kinematics, &before, sizeof(before))) {
        AcquireSRWLockExclusive(&localAirSlamLock);
        LocalAirSlam *slam = &localAirSlam;
        const uint64_t latest = slam->lastStep ? slam->lastStep : slam->owner.tick;
        owns = !slam->cancelled && !slam->impact && slam->flight == jump.owner.tick && latest <= now &&
            now - latest <= (uint64_t)groundPolicy->maxGapMs &&
            sameLocalAction(&slam->owner, &frame, actor, now, airPolicy->maxFlightMs);
        if (owns) {
            first = !slam->windup;
            if (first) slam->windup = now;
            windup = now - slam->windup < (uint64_t)slamPolicy->windupMs;
            release = !windup && !slam->falling;
            if (release) slam->falling = now;
            slam->lastStep = now;
#ifdef SR1_LOCAL_SLAM_COAST
            if (slam->carryDirection) {
                if (first) memcpy(slam->entryVelocity, before.velocity, sizeof(slam->entryVelocity));
                for (unsigned axis = 0; axis < 2; ++axis) {
                    planar[axis] = localSlamCoastAxis(slam->entryVelocity[axis], before.velocity[axis],
                        now - slam->windup, slamCoast->durationMs);
                }
            }
#endif
        }
        ReleaseSRWLockExclusive(&localAirSlamLock);
    }
    if (owns) {
        LocalSlamKinematics step = localSlamStep(slamPolicy, windup, release, before.velocity[2],
            (int32_t)airPolicy->normalGravity, time);
#ifdef SR1_LOCAL_SLAM_COAST
        memcpy(step.velocity, planar, sizeof(planar));
#endif
        memcpy((void *)kinematics, &step, sizeof(step));
#ifdef SR1_LOCAL_SLAM_COAST
        if (first || release) record("defiance-slam-%s realm=%u vz=%ld planar=%ld,%ld",
            first ? "windup" : "fall", frame.realm, (long)step.velocity[2], (long)planar[0], (long)planar[1]);
#else
        if (first || release) record("defiance-slam-%s realm=%u vz=%ld", first ? "windup" : "fall",
            frame.realm, (long)step.velocity[2]);
#endif
    }
    SetLastError(previousError);
    originalSlamPhysics(actor, segment, time, clamp);
    if (owns) {
        const DWORD afterError = GetLastError();
        memcpy((void *)(kinematics + sizeof(before.velocity)), before.acceleration, sizeof(before.acceleration));
        SetLastError(afterError);
    }
}

static void localSlamPhysics(uintptr_t actor,int32_t segment,int32_t time,int32_t clamp) {
    const uintptr_t caller=(uintptr_t)__builtin_return_address(0)-base;
    localSlamPhysicsAt(actor,segment,time,clamp,caller);
#ifdef SR1_LOCAL_LOCK47
    if (actor==player && !segment && !clamp && time>0 && time<=slamPolicy->integrationMax &&
        (caller==(uintptr_t)slamPolicy->standardReturnRva || caller==(uintptr_t)slamPolicy->alternateReturnRva)) {
        const DWORD error=GetLastError();const Sr1LocalFrame frame=readFrame();
        localTargetApply47(&frame,actor,GetTickCount64());SetLastError(error);
    }
#endif
}

static bool prepareLocalSlam(void) {
    const unsigned char standard[] = PROOF_SLAM_STANDARD_CALLER, alternate[] = PROOF_SLAM_ALTERNATE_CALLER;
    return verifyDrawBlock(slamPolicy->integrateRva, SR_PHYSICS_SIZE, SR_PHYSICS_SHA) &&
        matches(slamPolicy->standardReturnRva - sizeof(standard), standard, sizeof(standard)) &&
        matches(slamPolicy->alternateReturnRva - sizeof(alternate), alternate, sizeof(alternate)) &&
        MH_CreateHook((void *)(base + slamPolicy->integrateRva), localSlamPhysics, (void **)&originalSlamPhysics) == MH_OK;
}
