// SPDX-License-Identifier: GPL-3.0-or-later
#pragma once
static bool localTargetTilt47(float pose[66][13],const int16_t target[3],float weight) {
    float pivot[3],axis[3];
    if (!isfinite(weight) || weight<=0.f || !bodyAxisFromPose(pose,pivot,axis)) return false;
    const float dx=target[0]-pivot[0],dy=target[1]-pivot[1],distance=hypotf(dx,dy);
    if (!isfinite(distance) || distance<sheet_sr1Lock47_locked_combat.minTiltDistance) return false;
    const float lean=sheet_sr1Lock47_locked_combat.rotorTiltDegrees*(3.14159265358979323846f/180.f);
    const float desired[3]={dx/distance*sinf(lean),dy/distance*sinf(lean),cosf(lean)};
    float rotationAxis[3]={axis[1]*desired[2]-axis[2]*desired[1],axis[2]*desired[0]-axis[0]*desired[2],axis[0]*desired[1]-axis[1]*desired[0]};
    const float length=sqrtf(rotationAxis[0]*rotationAxis[0]+rotationAxis[1]*rotationAxis[1]+rotationAxis[2]*rotationAxis[2]);
    if (!isfinite(length) || length<.00001f) return false;
    for(unsigned i=0;i<3;i++)rotationAxis[i]/=length;
    const float dot=fmaxf(-1.f,fminf(1.f,axis[0]*desired[0]+axis[1]*desired[1]+axis[2]*desired[2]));
    const float angle=acosf(dot)*fminf(1.f,weight),c=cosf(angle),s=sinf(angle),t=1.f-c;
    const float x=rotationAxis[0],y=rotationAxis[1],z=rotationAxis[2];
    const float rotation[9]={c+x*x*t,x*y*t-z*s,x*z*t+y*s,y*x*t+z*s,c+y*y*t,y*z*t-x*s,z*x*t-y*s,z*y*t+x*s,c+z*z*t};
    for(unsigned bone=1;bone<66;bone++)for(unsigned i=0;i<13;i++)if(i!=9&&!isfinite(pose[bone][i]))return false;
    for(unsigned bone=1;bone<66;bone++) {
        float before[13];memcpy(before,pose[bone],sizeof before);
        for(unsigned row=0;row<3;row++) {
            for(unsigned col=0;col<3;col++) {
                float value=0.f;for(unsigned k=0;k<3;k++)value+=rotation[row*3+k]*before[k*3+col];
                pose[bone][row*3+col]=value;
            }
            float value=pivot[row];for(unsigned k=0;k<3;k++)value+=rotation[row*3+k]*(before[10+k]-pivot[k]);
            pose[bone][10+row]=value;
        }
    }
    return true;
}
