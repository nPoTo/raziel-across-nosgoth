// SPDX-License-Identifier: GPL-3.0-or-later
#pragma once
// Native desired-distance lease adapted from released0.2 camera-distance-policy/lease.
static _Thread_local struct {uintptr_t actor;uint32_t generation,world;int16_t original,applied,baseline;bool owned;} localCamera50;
#ifdef SR1_LOCAL_COMBAT52
static bool localCameraRotor52(const Sr1LocalFrame *,uintptr_t);
#endif
static bool localCameraRead50(uintptr_t *focus,int16_t *mode,int16_t *distance){
 const Sheet_sr1Combat50 *p=&sheet_sr1Combat50_forearm_slam_camera;
 return readAt(base+p->cameraRva+p->cameraFocusOffset,focus,8)&&readAt(base+p->cameraRva+p->cameraModeOffset,mode,2)&&
  readAt(base+p->cameraRva+p->cameraDesiredOffset,distance,2);
}
static bool localCameraWrite50(int16_t value){
 const Sheet_sr1Combat50 *p=&sheet_sr1Combat50_forearm_slam_camera;SIZE_T written=0;
 return WriteProcessMemory(GetCurrentProcess(),(void *)(base+p->cameraRva+p->cameraDesiredOffset),&value,2,&written)&&written==2;
}
static void localCameraRestore50(void){
 uintptr_t focus=0;int16_t mode=0,distance=0;
 if(localCamera50.owned&&localCameraRead50(&focus,&mode,&distance)&&focus==localCamera50.actor&&distance==localCamera50.applied)
  localCameraWrite50(localCamera50.original);
 localCamera50=(__typeof__(localCamera50)){0};
}
static void localCameraUpdate50(const Sr1LocalFrame *frame,uintptr_t actor){
 const Sheet_sr1Combat50 *p=&sheet_sr1Combat50_forearm_slam_camera;uintptr_t focus=0;int16_t mode=0,distance=0;
 if(!localCameraRead50(&focus,&mode,&distance))return; // Keep ownership over transient reads; never compound our scale.
 const bool eligible=frame->ready&&frame->renderBlend&&!localPhysicalCarry(actor)&&focus==actor&&mode==p->cameraMode;
#ifdef SR1_LOCAL_COMBAT52
 const bool rotor=eligible&&localCameraRotor52(frame,actor);
 static _Thread_local int16_t lastRaw,lastMode;static _Thread_local bool lastRotor;static _Thread_local unsigned reports;
 if((distance!=lastRaw||mode!=lastMode||rotor!=lastRotor)&&reports++<512){record("defiance-camera-observe raw=%d mode=%d rotor=%u owned=%u",distance,mode,rotor,localCamera50.owned);lastRaw=distance;lastMode=mode;lastRotor=rotor;}
 if(localCamera50.owned&&(focus!=localCamera50.actor||frame->playerGeneration!=localCamera50.generation||frame->worldGeneration!=localCamera50.world)){
  localCameraRestore50();return;
 }
 if(!eligible){localCameraRestore50();return;}
 const bool overwritten=localCamera50.owned&&distance!=localCamera50.applied;
 if((!localCamera50.owned||overwritten)&&(distance<=0||distance>p->cameraMax||(!rotor&&distance<p->cameraMin))){localCamera50=(__typeof__(localCamera50)){0};return;}
 int16_t baseline=localCamera50.owned?localCamera50.baseline:distance;
 if((!localCamera50.owned||overwritten)&&!rotor)baseline=distance;
 if(baseline<p->cameraMin)baseline=(int16_t)p->cameraMin;
 const int32_t scaled52=(int32_t)baseline*(int32_t)sheet_sr1Combat52_target_cast_camera.cameraPermille;
 int32_t desired52=scaled52/1000,remainder52=scaled52%1000;
 if(remainder52>500||(remainder52==500&&(desired52&1)))desired52++;
 if(rotor&&desired52<sheet_sr1Combat52_target_cast_camera.rotorMin)desired52=(int32_t)sheet_sr1Combat52_target_cast_camera.rotorMin;
 if(desired52>p->cameraLimit)desired52=(int32_t)p->cameraLimit;
 const int16_t restore=(!localCamera50.owned||overwritten)?distance:localCamera50.original;
 if(distance==(int16_t)desired52&&localCamera50.owned)return;
 uintptr_t again52=0;int16_t mode52=0,raw52=0;
 if(!localCameraRead50(&again52,&mode52,&raw52)||again52!=focus||mode52!=mode||raw52!=distance)return;
 if(localCameraWrite50((int16_t)desired52)){
  localCamera50=(__typeof__(localCamera50)){.actor=actor,.generation=frame->playerGeneration,.world=frame->worldGeneration,.original=restore,.applied=(int16_t)desired52,.baseline=baseline,.owned=true};
  record("defiance-camera-distance original=%d desired=%ld permille=%lld rotor=%u overwritten=%u",restore,(long)desired52,sheet_sr1Combat52_target_cast_camera.cameraPermille,rotor,overwritten);
 }
 return;
#else
 if(localCamera50.owned){
  if(focus!=localCamera50.actor||distance!=localCamera50.applied){localCamera50=(__typeof__(localCamera50)){0};return;}
  if(!eligible||frame->playerGeneration!=localCamera50.generation||frame->worldGeneration!=localCamera50.world){localCameraRestore50();return;}
  return;
 }
 if(!eligible||distance<p->cameraMin||distance>p->cameraMax)return;
 const int32_t scaled=(int32_t)distance*(int32_t)p->cameraPermille;
 int32_t desired=scaled/1000;const int32_t remainder=scaled%1000;
 if(remainder>500||(remainder==500&&(desired&1)))desired++; // .NET Round: nearest even.
 const int16_t next=(int16_t)(desired>p->cameraLimit?p->cameraLimit:desired);
 uintptr_t again=0;int16_t nextMode=0,current=0;
 if(!localCameraRead50(&again,&nextMode,&current)||again!=focus||nextMode!=mode||current!=distance)return;
 if(localCameraWrite50(next)){
  localCamera50=(__typeof__(localCamera50)){.actor=actor,.generation=frame->playerGeneration,.world=frame->worldGeneration,.original=distance,.applied=next,.owned=true};
  record("defiance-camera-distance original=%d desired=%d permille=%lld",distance,next,p->cameraPermille);
 }
#endif
}
