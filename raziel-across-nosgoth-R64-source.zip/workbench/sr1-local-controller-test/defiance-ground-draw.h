// SPDX-License-Identifier: GPL-3.0-or-later
#pragma once

#include <math.h>
#include "bounded-sha256.h"
#ifdef SR1_LOCAL_ROTOR44
#include "local-audio.h"
#endif
#include "ground-pose-proof.h"
#ifdef SR1_LOCAL_COMBAT49
#include "local-wrist49.h"
#endif
#ifdef SR1_LOCAL_COMBAT48
#include "local-charge-pose48.h"
#ifdef SR1_LOCAL_COMBAT53
#include "local-utility-pose53.h"
#endif
#endif
#include "sr1-native-pose-forward.h"
#include "sr1-skeleton-shared.h"
#ifdef SR1_LOCAL_BODY_AXIS43
#include "local-body-axis.h"
#ifdef SR1_LOCAL_LOCK47
#include "local-target-tilt47.h"
#endif
#endif
#ifdef SR1_LOCAL_COMBAT_CONTINUITY
#include "local-combat-continuity.h"
#endif

#ifdef SR1_LOCAL_DEFIANCE_JUMP
#ifndef GROUND_POSE_STRIKE
#define GROUND_POSE_STRIKE 0
#endif
#ifndef GROUND_POSE_STRIKE_EXTRA
#define GROUND_POSE_STRIKE_EXTRA 0
#endif
#define GROUND_POSE_BASE (GROUND_POSE_IDLE + GROUND_POSE_MOVE + GROUND_POSE_JUMP + GROUND_POSE_FALL + GROUND_POSE_LAND + GROUND_POSE_STRIKE + GROUND_POSE_STRIKE_EXTRA)
#ifdef SR1_LOCAL_NATIVE_CONTROLS
#define GROUND_POSE_GUARD_END (GROUND_POSE_BASE + LOCAL_GUARD_POSES + LOCAL_GUARD_ENTRY_POSES + LOCAL_GUARD_EXIT_POSES)
#define GROUND_POSE_ACTION_END (GROUND_POSE_GUARD_END + LOCAL_LIFT_POSES + LOCAL_WINDUP_POSES + LOCAL_SLAM_POSES)
#ifdef SR1_LOCAL_GUARD_LOCOMOTION
#ifdef SR1_LOCAL_AIR_STRIKE
#define GROUND_POSE_AIR_STRIKE (GROUND_POSE_ACTION_END + LOCAL_GUARD_RUN_POSES)
#ifdef SR1_LOCAL_CALIBRATED_COMBAT
#define GROUND_POSE_DODGE (GROUND_POSE_AIR_STRIKE + LOCAL_AIR_STRIKE_POSES)
#ifdef SR1_LOCAL_AIR_CONTACT
#define GROUND_POSE_SPECIAL (GROUND_POSE_DODGE + LOCAL_DODGE_POSES)
#define GROUND_POSE_TOTAL (GROUND_POSE_SPECIAL + LOCAL_SPECIAL_POSES)
#else
#define GROUND_POSE_TOTAL (GROUND_POSE_DODGE + LOCAL_DODGE_POSES)
#endif
#else
#define GROUND_POSE_TOTAL (GROUND_POSE_AIR_STRIKE + LOCAL_AIR_STRIKE_POSES)
#endif
#else
#define GROUND_POSE_TOTAL (GROUND_POSE_ACTION_END + LOCAL_GUARD_RUN_POSES)
#endif
#else
#define GROUND_POSE_TOTAL GROUND_POSE_ACTION_END
#endif
#else
#define GROUND_POSE_TOTAL GROUND_POSE_BASE
#endif
#else
#define GROUND_POSE_TOTAL (GROUND_POSE_IDLE + GROUND_POSE_MOVE)
#endif

#ifdef SR1_DEFIANCE_GROUND_CALIBRATION
typedef struct { uint8_t bone[4]; float weighted[3][4]; } GroundSolePoint;
_Static_assert(sizeof(GroundSolePoint) == 52, "Packed sole probe layout");
static struct {
    float frames[GROUND_POSE_TOTAL][66][13];
    GroundSolePoint soles[GROUND_SOLE_VERTICES];
#ifdef SR1_LOCAL_BODY_AXIS43
    float airThirdTwist[BODY_AXIS_SAMPLES];
#ifdef SR1_LOCAL_ROTOR44
    float rotorFrames[BODY_AXIS_SAMPLES][66][13];
#ifdef SR1_LOCAL_COMBAT48
    float chargedFrames[LOCAL_CHARGE_POSES48][66][13];
#endif
#endif
#endif
} groundPayload;
#define groundFrames groundPayload.frames
#else
static float groundFrames[GROUND_POSE_TOTAL][66][13];
#define groundPayload groundFrames
#endif
static Sr1NativePoseFn originalGroundDraw;
static volatile LONG drawThread;
#ifndef SR1_LOCAL_REPEAT_DRAW_LEASE
static volatile LONG groundDrawRefused;
#endif
static _Thread_local float drawScratch[66][13];
static _Thread_local bool insideGroundDraw;
#ifdef SR1_DEFIANCE_GROUND_BLEND
static JumpLocal groundLocalFrames[GROUND_POSE_TOTAL
#ifdef SR1_LOCAL_ROTOR44
    + BODY_AXIS_SAMPLES
#endif
#ifdef SR1_LOCAL_COMBAT48
    + LOCAL_CHARGE_POSES48
#endif
][66];
static _Thread_local GroundTransition groundTransition;
#ifdef SR1_LOCAL_COMBAT_CLOCK
static _Thread_local uintptr_t strikeIdentity;
static _Thread_local int32_t strikeTime;
#ifdef SR1_MEASURED_GROUND_COMBO
#include "local-measured-combo.h"
static _Thread_local unsigned drawnStrikeOrdinal;
#endif
#ifdef SR1_LOCAL_CONTROL_EDGES
static _Thread_local float drawnStrikeSample;
static _Thread_local uint64_t drawnStrikeTick;
#endif
#ifdef SR1_LOCAL_COMBAT_TIMING
#ifdef SR1_LOCAL_GROUND_X
static _Thread_local uint64_t drawnGroundXStart;
#ifdef SR1_LOCAL_THIRD_FINISH
static _Thread_local LocalActionOwner drawnGroundXOwner;
static _Thread_local bool backgroundStrikeReturn;
#endif
#ifdef SR1_LOCAL_THIRD_SWEEP
static _Thread_local float renderedThirdSample = -1.f;
static _Thread_local bool reportedStrikeBridge;
#endif
#else
static _Thread_local LocalActionOwner visualThird;
#endif
#endif
#endif
static _Thread_local unsigned nativeChecks;
static _Thread_local uintptr_t lastActor, checkedModel;
static _Thread_local uint32_t lastWorld, lastGeneration;
static _Thread_local Sr1LocalRealm lastRealm;
static _Thread_local uint64_t lastTravel;
static _Thread_local float lastPosition[2];
#ifdef SR1_LOCAL_DEFIANCE_JUMP
static _Thread_local uint64_t suppressedFlight, loggedTurn;
#endif
#ifdef SR1_LOCAL_LANDING_CONTACT
static _Thread_local struct {
    uint64_t tick;
#ifdef SR1_LOCAL_IMMEDIATE_REPEAT
    uint64_t settledAt;
#endif
    float foot[2];
    bool reported;
} landingPlant;
#endif
#ifdef SR1_DEFIANCE_GROUND_CALIBRATION
static _Thread_local GroundGait gait;
static _Thread_local float actualGroundStep;
#ifdef SR1_LOCAL_COMBAT58
#include "local-action-pose58.h"
static _Thread_local LocalPoseTransition58 actionPose58;
#endif
#ifdef SR1_LOCAL_CALIBRATED_MOVEMENT
static _Thread_local struct {
    uint64_t first, last;
    float path;
    int16_t start[3];
} movementWitness;

static void observeCalibratedRun(const Sr1LocalFrame *frame, uint64_t now, const int16_t position[3],
    bool sameActor, float step) {
    const uint64_t requested = (uint64_t)InterlockedCompareExchange64(&groundStartRequested, 0, 0);
    const bool eligible = sameActor && frame->grounded && !frame->nativeControl && !frame->groundStrike &&
        !frame->strikePending && !frame->strikeTransition && frame->airState == SR1_AIR_NONE &&
        requested && requested <= now && now - requested >= 200 &&
        InterlockedCompareExchange(&fullGroundIntent, 0, 0);
    if (!eligible) {
        movementWitness.first = 0;
        return;
    }
    if (!movementWitness.first || movementWitness.last > now || now - movementWitness.last > 85 ||
        abs((int)position[2] - movementWitness.start[2]) >= 15) {
        movementWitness.first = movementWitness.last = now;
        movementWitness.path = 0.f;
        memcpy(movementWitness.start, position, sizeof(movementWitness.start));
        return;
    }
    movementWitness.last = now;
    movementWitness.path += step;
    const uint64_t span = now - movementWitness.first;
    if (span < 650) return;
    const float displacement = hypotf((float)position[0] - movementWitness.start[0],
        (float)position[1] - movementWitness.start[1]);
    if (movementWitness.path >= 300.f && displacement / movementWitness.path > .985f)
        record("defiance-movement-run realm=%u sampled=%llu distance=%.2f speed=%.2f target=%.2f",
            frame->realm, (unsigned long long)span, movementWitness.path, movementWitness.path * 1000.f / span,
            gaitPolicy->runSpeedMilli * gaitPolicy->nominalUpdatesHz / 1000.f);
    movementWitness.first = 0;
}
#endif
#ifdef SR1_LOCAL_MOVING_LANDING
static _Thread_local float landingTravel, landingStep;
#endif
static _Thread_local GroundPhase gaitLastPhase;
static _Thread_local int16_t actorPosition[3], groundZ, flightPeak;
static _Thread_local uint64_t flightStart;
static _Thread_local bool loggedSupport;
#ifdef SR1_LOCAL_GROUND_ACTIONS
#include "local-idle-cycle.h"
static _Thread_local bool idleFromRun;
static _Thread_local unsigned reportedIdleBank;
#elif defined(SR1_DEFIANCE_GROUND_AUTHORED)
static _Thread_local float idleStart;
#endif
#ifdef SR1_DEFIANCE_GROUND_RESPONSIVE
static _Thread_local uint64_t firstTravelRequest;
static _Thread_local unsigned verticalTravelRecords;
#endif

static float lowestSoleHeight(const float rendered[66][13]) {
    float low = INFINITY;
    for (unsigned i = 0; i < ARRAYSIZE(groundPayload.soles); ++i) {
        const GroundSolePoint *point = &groundPayload.soles[i];
        float z = 0;
        for (unsigned j = 0; j < 3; ++j) {
            const float *m = rendered[point->bone[j]];
            const float *v = point->weighted[j];
            z += m[6] * v[0] + m[7] * v[1] + m[8] * v[2] + m[12] * v[3];
        }
        low = fminf(low, z);
    }
    return low;
}

static void supportGroundSoles(const float root[13], uint64_t tick, Sr1LocalRealm realm, float weight) {
    if (root[8] < .97f || weight <= 0) return;
    const float correction = root[12] + GROUND_SOLE_FLOOR - lowestSoleHeight(drawScratch);
    if (!isfinite(correction) || correction < .001f || correction > GROUND_SOLE_LIMIT) return;
    const float progress = fminf(1.f, (float)(tick - groundTransition.start) / (float)groundTransition.duration);
    const float lift = correction * progress * weight;
    for (unsigned i = 1; i < 66; ++i) drawScratch[i][12] += lift;
    for (unsigned k = 0; k < 3; ++k) groundTransition.shown[1].p[k] += root[6 + k] * lift;
    if (!loggedSupport && lift > .01f) {
        record("ground-sole-support realm=%u correction=%.2f", realm, lift);
        loggedSupport = true;
    }
}
#endif

static bool checkGroundHierarchy(uintptr_t model) {
    if (model == checkedModel) return true;
    const Sheet_sr1GroundTransition *p = groundPolicy;
    int32_t count;
    uintptr_t segments;
    unsigned char bytes[66 * 32];
    if (p->segmentBytes != 32 || p->segmentParentOffset != 18 ||
        !readAt(model + p->modelCountOffset, &count, sizeof(count)) || count != 66 ||
        !readAt(model + p->modelSegmentsOffset, &segments, sizeof(segments)) || !segments ||
        !readAt(segments, bytes, sizeof(bytes))) return false;
    for (unsigned i = 0; i < ARRAYSIZE(groundParents); ++i) {
        int16_t parent;
        memcpy(&parent, bytes + i * p->segmentBytes + p->segmentParentOffset, sizeof(parent));
        if (parent != groundParents[i]) return false;
    }
    checkedModel = model;
    return true;
}

static GroundPhase groundPhase(const Sr1LocalFrame *frame, uintptr_t actor, uint64_t now, const float root[13]) {
    const bool sameActor = lastActor == actor && lastWorld == frame->worldGeneration &&
        lastGeneration == frame->playerGeneration && lastRealm == frame->realm;
    if (!sameActor) {
        groundTransition.active = false;
        lastTravel = 0;
#ifdef SR1_DEFIANCE_GROUND_CALIBRATION
        gait = (GroundGait){0};
        flightStart = 0;
#ifdef SR1_LOCAL_MOVING_LANDING
        landingTravel = 0;
#endif
#endif
    }
#ifdef SR1_DEFIANCE_GROUND_CALIBRATION
    int16_t position[3];
#ifdef SR1_LOCAL_MOVING_LANDING
    landingStep = 0;
#endif
    if (readAt(actor + 0x9c, position, sizeof(position))) {
        const float dx = (float)position[0] - (float)actorPosition[0];
        const float dy = (float)position[1] - (float)actorPosition[1];
        const float step = hypotf(dx, dy);
        actualGroundStep = sameActor && !frame->nativeControl && step <= gaitPolicy->maxStep ? step : 0;
#ifdef SR1_LOCAL_CALIBRATED_MOVEMENT
        observeCalibratedRun(frame, now, position, sameActor, actualGroundStep);
#endif
#ifdef SR1_LOCAL_MOVING_LANDING
        if (sameActor && frame->airState == SR1_AIR_LAND && step <= (float)gaitPolicy->maxStep) landingStep = step;
#endif
#ifdef SR1_DEFIANCE_GROUND_RESPONSIVE
        if (actualGroundStep > 0) {
            const uint64_t request = (uint64_t)InterlockedCompareExchange64(&groundStartRequested, 0, 0);
            if (request && request <= now && request != firstTravelRequest) {
                firstTravelRequest = request;
                record("ground-first-travel realm=%u age=%llu step=%.2f", frame->realm,
                    (unsigned long long)(now - request), actualGroundStep);
            }
            if (position[2] != actorPosition[2] && verticalTravelRecords++ < 18) {
                record("ground-vertical-step realm=%u delta=%d planar=%.2f", frame->realm,
                    (int)position[2] - actorPosition[2], actualGroundStep);
            }
        }
#endif
        if (frame->grounded
#ifdef SR1_LOCAL_COMBAT_PRESENTATION
            || frame->groundStrike || frame->strikePending
#endif
        ) {
#ifdef SR1_LOCAL_COMBAT_PRESENTATION
            if (!frame->grounded) flightStart = 0;
#endif
            if (flightStart) {
                const int rise = (int)flightPeak - groundZ;
                if (rise > 0) record("local-jump realm=%u rise=%d duration=%llu", frame->realm, rise,
                    (unsigned long long)(now - flightStart));
                flightStart = 0;
            }
            groundZ = position[2];
        } else if (sameActor) {
            if (!flightStart) {
                flightStart = now;
                flightPeak = position[2];
            }
            if (flightPeak < position[2]) flightPeak = position[2];
        }
        memcpy(actorPosition, position, sizeof(position));
    } else {
        actualGroundStep = 0;
        flightStart = 0;
    }
    if (actualGroundStep > 0) lastTravel = now;
#else
    const float dx = root[10] - lastPosition[0], dy = root[11] - lastPosition[1];
    if (sameActor && isfinite(dx) && isfinite(dy) && dx * dx + dy * dy > 0.0001f) lastTravel = now;
#endif
    lastActor = actor;
    lastWorld = frame->worldGeneration;
    lastGeneration = frame->playerGeneration;
    lastRealm = frame->realm;
    lastPosition[0] = root[10];
    lastPosition[1] = root[11];
    if (frame->nativeControl) return GROUND_NATIVE;
    const uint64_t intent = (uint64_t)InterlockedCompareExchange64(&groundIntentTick, 0, 0);
    return intent && intent <= now && now - intent <= (uint64_t)groundPolicy->maxGapMs &&
        lastTravel && now - lastTravel < (uint64_t)groundPolicy->stopGraceMs ? GROUND_RUN : GROUND_IDLE;
}

static void sampleGroundLocalsForStrike(GroundPhase phase, float sample, unsigned ordinal, JumpLocal out[66]) {
    static const unsigned starts[] = {0, 0, GROUND_POSE_IDLE
#ifdef SR1_LOCAL_DEFIANCE_JUMP
        , GROUND_POSE_IDLE + GROUND_POSE_MOVE,
        GROUND_POSE_IDLE + GROUND_POSE_MOVE + GROUND_POSE_JUMP,
        GROUND_POSE_IDLE + GROUND_POSE_MOVE + GROUND_POSE_JUMP + GROUND_POSE_FALL
#endif
#ifdef SR1_LOCAL_DEFIANCE_COMBAT
        , GROUND_POSE_BASE - GROUND_POSE_STRIKE - GROUND_POSE_STRIKE_EXTRA
#endif
    };
    static const unsigned counts[] = {0, GROUND_POSE_IDLE, GROUND_POSE_MOVE
#ifdef SR1_LOCAL_DEFIANCE_JUMP
        , GROUND_POSE_JUMP, GROUND_POSE_FALL, GROUND_POSE_LAND
#endif
#ifdef SR1_LOCAL_DEFIANCE_COMBAT
        , GROUND_POSE_STRIKE
#endif
    };
    unsigned count = counts[phase], first = starts[phase];
#ifdef SR1_LOCAL_STRIKE_COMBO
    if (phase == GROUND_STRIKE && ordinal < LOCAL_STRIKE_COUNT) {
        for (unsigned i = 0; i < ordinal; ++i) first += localStrikePoses[i];
        count = localStrikePoses[ordinal];
    }
#else
    (void)ordinal;
#endif
    unsigned index = (unsigned)sample % count;
    unsigned next = (index + 1) % count;
#ifdef SR1_DEFIANCE_GROUND_AUTHORED
    if (phase != GROUND_RUN) {
        sample = fminf((float)count - 1.f, sample);
        index = (unsigned)sample;
        next = index + 1 < count ? index + 1 : index;
    }
#endif
    const JumpLocal *a = groundLocalFrames[first + index];
    const JumpLocal *b = groundLocalFrames[first + next];
    const float alpha = sample - (float)(unsigned)sample;
    for (unsigned i = 1; i < (unsigned)groundPolicy->wingFirst; ++i) groundBlendLocal(&a[i], &b[i], alpha, &out[i]);
}

static void sampleGroundLocals(GroundPhase phase, float sample, JumpLocal out[66]) {
    sampleGroundLocalsForStrike(phase, sample, 0, out);
}
#ifdef SR1_LOCAL_GROUND_ACTIONS
static unsigned localIdleOffset(unsigned bank) {
    unsigned offset = 0;
    for (unsigned i = 0; i < bank; ++i) offset += localIdlePoses[i];
    return offset;
}

static void sampleLocalIdle(uint64_t elapsed, JumpLocal out[66], Sr1LocalRealm realm) {
    const LocalIdleSample idle = localIdleSample(elapsed, idleFromRun, localIdlePoses,
        ARRAYSIZE(localIdlePoses), groundActions->idleBetweenMs, groundActions->idleBlendMs);
    const unsigned offset = localIdleOffset(idle.bank);
    const unsigned count = localIdlePoses[idle.bank];
    const float sample = idle.bank == 1 ? fmodf(idle.sample, count) : fminf(idle.sample, count - 1);
    const unsigned i = (unsigned)sample;
    const unsigned j = i + 1 < count ? i + 1 : idle.bank == 1 ? 0 : i;
    const JumpLocal *previous = NULL;
    if (idle.mix < 1) {
        const unsigned fromCount = localIdlePoses[idle.from];
        const unsigned fromSample = idle.from == 1 ?
            (unsigned)(groundActions->idleBetweenMs * 60 / 1000) % fromCount : fromCount - 1;
        previous = groundLocalFrames[localIdleOffset(idle.from) + fromSample];
    }
    const float mix = idle.mix * idle.mix * (3 - 2 * idle.mix);
    for (unsigned bone = 1; bone < (unsigned)groundPolicy->wingFirst; ++bone) {
        groundBlendLocal(&groundLocalFrames[offset + i][bone], &groundLocalFrames[offset + j][bone],
            sample - (float)i, &out[bone]);
        if (previous) {
            const JumpLocal target = out[bone];
            groundBlendLocal(&previous[bone], &target, mix, &out[bone]);
        }
    }
    if (reportedIdleBank != idle.bank) {
        reportedIdleBank = idle.bank;
        record("defiance-idle-bank realm=%u bank=%u", realm, idle.bank);
    }
}
#endif
#ifdef SR1_LOCAL_NATIVE_CONTROLS
static void blendCombatBankRange(JumpLocal pose[66], unsigned boneFirst, unsigned boneEnd, unsigned offset,
    unsigned count, float sample, float weight) {
    sample = fminf((float)count - 1.f, sample);
    const unsigned index = (unsigned)sample;
    const unsigned next = index + 1 < count ? index + 1 : index;
    const JumpLocal *a = groundLocalFrames[offset + index];
    const JumpLocal *b = groundLocalFrames[offset + next];
    for (unsigned i = boneFirst; i < boneEnd; ++i) {
        JumpLocal target;
        groundBlendLocal(&a[i], &b[i], sample - (float)index, &target);
        const JumpLocal original = pose[i];
        groundBlendLocal(&original, &target, weight, &pose[i]);
    }
}

static void blendCombatBank(JumpLocal pose[66], unsigned boneFirst, unsigned offset,
    unsigned count, float sample, float weight) {
    blendCombatBankRange(pose, boneFirst, (unsigned)groundPolicy->wingFirst, offset, count, sample, weight);
}

#ifdef SR1_LOCAL_AIR_SLAM
static bool applyLocalSlamPose(JumpLocal pose[66], const Sr1LocalFrame *frame, uintptr_t actor, uint64_t now) {
    const uint64_t recoveryMs = slamRecoveryDuration();
    const LocalAirSlam slam = readLocalSlam(frame, actor, now, recoveryMs);
    if (!slam.windup) return false;
    const unsigned windupBank = GROUND_POSE_GUARD_END + LOCAL_LIFT_POSES;
    const unsigned fallBank = windupBank + LOCAL_WINDUP_POSES;
    const uint64_t entryBlendMs = airPolicy->phaseBlendMs;
    if (!slam.falling) {
        const uint64_t elapsed = now - slam.windup;
        blendCombatBank(pose, 1, windupBank, LOCAL_WINDUP_POSES,
            combatSample(elapsed, slamPolicy->windupMs, LOCAL_WINDUP_POSES), combatEase(elapsed, entryBlendMs));
        return true;
    }
    const uint64_t fallAge = now - slam.falling;
    const uint64_t sourceContact = (uint64_t)slamPolicy->donorContactMs;
    const uint64_t poseAge = slam.impact ? sourceContact + now - slam.impact :
        fallAge < sourceContact ? fallAge : sourceContact;
    if (fallAge < entryBlendMs && !slam.impact)
        blendCombatBank(pose, 1, windupBank, LOCAL_WINDUP_POSES, LOCAL_WINDUP_POSES - 1.f, 1.f);
    const float weight = slam.impact ? combatEase(recoveryMs - (now - slam.impact), entryBlendMs) :
        combatEase(fallAge, entryBlendMs);
    blendCombatBank(pose, 1, fallBank, LOCAL_SLAM_POSES,
        combatSample(poseAge, guardClips->airStrikeMs, LOCAL_SLAM_POSES), weight);
#ifdef SR1_LOCAL_ROTOR44
    localAudioTrack(36,slam.owner.tick,combatSample(poseAge,guardClips->airStrikeMs,LOCAL_SLAM_POSES)*.5f,frame->realm,now);
#endif
    return true;
}
#endif

#ifdef SR1_LOCAL_AIR_STRIKE
static unsigned localAirStrikeOffset(unsigned ordinal) {
    unsigned offset = GROUND_POSE_AIR_STRIKE;
    for (unsigned i = 0; i < ordinal; ++i) offset += localAirStrikePoses[i];
    return offset;
}

#ifdef SR1_LOCAL_COMBO_FLOW
static _Thread_local LocalActionOwner lastAirStrikeDraw;
#endif

static bool applyLocalAirStrikePose(JumpLocal pose[66], const Sr1LocalFrame *frame, uintptr_t actor, uint64_t now) {
    const LocalAirStrike strike = readLocalAirStrike(frame, actor, now);
    if (!strike.owner.tick) return false;
    const uint64_t age = now - strike.owner.tick;
#ifdef SR1_LOCAL_COMBO_FLOW
    lastAirStrikeDraw = localActionOwner(frame, actor, now);
    const uint64_t blend =
#ifdef SR1_LOCAL_COMBAT_LINKS
        combatLinks->linkBlendMs;
#else
        airStrikeFlow->linkBlendMs;
#endif
#else
    const uint64_t blend = airPolicy->phaseBlendMs;
#endif
    if (strike.ordinal && age < blend) {
        const unsigned previous = strike.ordinal - 1;
        const unsigned count = localAirStrikePoses[previous];
        blendCombatBank(pose, 1, localAirStrikeOffset(previous), count,
#ifdef SR1_LOCAL_COMBO_FLOW
            combatSample(localAirStrikeOutgoingAge(strike.priorAge, age), localAirStrikeDuration(previous), count), 1.f);
#else
            combatSample(strike.priorAge, localAirStrikeDuration(previous), count), 1.f);
#endif
    }
    const unsigned count = localAirStrikePoses[strike.ordinal];
    const uint64_t duration = localAirStrikeDuration(strike.ordinal);
    float weight = fminf(combatEase(age, blend), combatEase(duration - age, blend));
#ifdef SR1_LOCAL_COMBO_FLOW
    weight = fminf(weight, localAirStrikeRecoveryWeight(strike.ordinal, age) / 1000.f);
#endif
    blendCombatBank(pose, 1, localAirStrikeOffset(strike.ordinal), count, combatSample(age, duration, count), weight);
#ifdef SR1_LOCAL_ROTOR44
    localAudioTrack(33u+strike.ordinal,strike.owner.tick,combatSample(age,duration,count)*.5f,frame->realm,now);
#endif
    return true;
}
#endif

static void applyLocalCombatPose(JumpLocal pose[66], GroundPhase phase, const Sr1LocalFrame *frame,
    const LocalCombatInput *input, uintptr_t actor, uint64_t now) {
#ifdef SR1_LOCAL_AIR_CONTACT
    const LocalSpecial special=localReadSpecial(frame,actor,now);
    if (special.move) {
        const uint64_t duration=localSpecialDuration(special.bank);
        const uint64_t elapsed=now-special.owner.tick;
        const uint64_t age=elapsed<duration?elapsed:duration;
        const uint64_t blend=
#ifdef SR1_LOCAL_COMBAT_LINKS
            combatLinks->linkBlendMs;
#else
            airStrikeFlow->linkBlendMs;
#endif
        unsigned count=localSpecialPoses[special.bank];
        unsigned offset=GROUND_POSE_SPECIAL;
        for (unsigned i=0;i<special.bank;i++) offset+=localSpecialPoses[i];
#ifdef SR1_LOCAL_SPECIAL_INPUT
        if (special.move==LOCAL_SPECIAL_TEMPEST
#ifndef SR1_LOCAL_COMBAT_SYNC42
            && special.bank==special.first+1
#endif
        ) {
            const unsigned ordinal=(unsigned)sheet_sr1CombatInput41_special_input.spinOrdinal;
            count=localAirStrikePoses[ordinal];
            offset=localAirStrikeOffset(ordinal);
#ifdef SR1_LOCAL_ROTOR44
            offset=GROUND_POSE_TOTAL;
#endif
        }
#endif
        const bool sameSpin=
#ifdef SR1_LOCAL_COMBAT_REPAIR
            special.move==LOCAL_SPECIAL_TEMPEST && special.bank==special.first+1 && special.previous==special.bank;
#else
            false;
#endif
        if (special.bank>special.first && age<blend && !sameSpin
#ifdef SR1_LOCAL_COMBAT_SYNC42
            && special.move!=LOCAL_SPECIAL_TEMPEST
#endif
        ) {
            const unsigned previous=localSpecialPoses[special.previous];
            unsigned priorOffset=GROUND_POSE_SPECIAL;
            for (unsigned i=0;i<special.previous;i++) priorOffset+=localSpecialPoses[i];
            blendCombatBank(pose,1,priorOffset,previous,previous-1.f,1.f);
        }
        float weight=fminf(combatEase(age,blend),localSpecialEnding(&special)?combatEase(duration-age,blend):1.f);
#ifdef SR1_LOCAL_SPECIAL_RECOVERY
        if (special.move==LOCAL_SPECIAL_PERFORATE) weight=combatEase(age,blend);
#endif
        float sample=combatSample(age,duration,count);
#ifdef SR1_LOCAL_COMBAT_SYNC42
        if (special.move==LOCAL_SPECIAL_TEMPEST) {
            const float active=(float)sheet_sr1CombatSync42_synchronized_combat.rotorSample;
            sample=special.bank==special.first?active*(float)age/(float)duration:
                special.bank==special.last?active+(count-1.f-active)*(float)age/(float)duration:active;
            weight=special.bank==special.first?combatEase(age,blend):
                special.bank==special.last?combatEase(duration-age,blend):1.f;
        }
#endif
#ifdef SR1_LOCAL_COMBAT_REPAIR
        if (special.move==LOCAL_SPECIAL_TEMPEST && special.bank==special.first+1 && special.spinStarted) {
            const uint64_t spinAge=now-special.spinStarted;
#ifdef SR1_LOCAL_COMBAT_CONTINUITY
#ifdef SR1_LOCAL_SPECIAL_INPUT
            sample=fminf(count-1.f,(float)sheet_sr1CombatInput41_special_input.spinSample);
#elif defined(SR1_LOCAL_SPECIAL_RECOVERY)
            sample=fminf(count-1.f,(float)sheet_sr1CombatSpecialRecovery_special_recovery.spinSample);
#else
            const float phase=combatSpinPhase(spinAge);
            sample=phase*(count-1.f);
#endif
#else
            const uint64_t loop=sheet_sr1CombatRepair_standalone_repair.spinLoopMs;
            sample=(float)(spinAge%loop)*(count-1.f)/(float)loop;
#endif
#ifdef SR1_LOCAL_COMBAT_SYNC42
            weight=1.f;
#else
            weight=combatEase(spinAge,blend);
#endif
        }
#endif
        blendCombatBank(pose,1,offset,count,sample,weight);
#ifdef SR1_LOCAL_ROTOR44
        static const unsigned soundClips[]={46,48,49,50,49,50,49,47,53,54,55,44,45};
        if(special.move==LOCAL_SPECIAL_TEMPEST&&special.bank==special.first+1&&special.spinStarted) {
            const uint64_t spinAge=combatRotorShownAge(now-special.spinStarted,special.spins);
            const uint64_t turn=spinAge/combatRotorPeriod();
            if(turn<special.spins)localAudioTrack(54,special.spinStarted+turn,
                (float)(spinAge%combatRotorPeriod())*18.f/(float)combatRotorPeriod(),frame->realm,now);
        } else if(special.bank<ARRAYSIZE(soundClips))localAudioTrack(soundClips[special.bank],special.owner.tick,
            combatSample(age,duration,localSpecialPoses[special.bank])*.5f,frame->realm,now);
#endif
#if defined(SR1_LOCAL_COMBAT_CONTINUITY) && !defined(SR1_LOCAL_BODY_AXIS43)
        if (special.move==LOCAL_SPECIAL_TEMPEST && special.bank==special.first+1 && special.spinStarted) {
            const float phase=combatSpinPhase(
#ifdef SR1_LOCAL_COMBAT_SYNC42
                combatRotorShownAge(now-special.spinStarted,special.spins)
#else
                now-special.spinStarted
#endif
            );
#ifndef SR1_LOCAL_SPECIAL_RECOVERY
            const float seam=sheet_sr1CombatContinuity_continuous_combat.spinSeamPermille/1000.f;
            if (phase>1.f-seam) {
                const float t=(phase-(1.f-seam))/seam;
                const float smooth=t*t*(3.f-2.f*t);
                blendCombatBank(pose,1,offset,count,0.f,smooth);
            }
#endif
#ifdef SR1_LOCAL_SPECIAL_RECOVERY
#ifdef SR1_LOCAL_SPECIAL_INPUT
            const unsigned held=(unsigned)sheet_sr1CombatInput41_special_input.spinSample;
#else
            const unsigned held=(unsigned)sheet_sr1CombatSpecialRecovery_special_recovery.spinSample;
#endif
            const float start=combatPelvisYaw(groundLocalFrames[offset+(held<count?held:count-1)][1].q);
#else
            const float start=combatPelvisYaw(groundLocalFrames[offset][1].q);
#endif
            const float desired=start+phase*6.2831853071795864769f;
            combatSetPelvisYaw(pose[1].q,desired);
        }
#endif
        return;
    }
#ifdef SR1_LOCAL_SPECIAL_RECOVERY
    const LocalSpecialRecovery recovery=readSpecialRecovery(frame,actor,now);
    if (recovery.released) {
        const LocalSpecial move=recovery.move;
        unsigned offset=GROUND_POSE_SPECIAL;
        for (unsigned i=0;i<move.bank;++i) offset+=localSpecialPoses[i];
        const unsigned count=localSpecialPoses[move.bank];
        const uint64_t age=now-recovery.released;
        const float weight=1.f-combatEase(age,sheet_sr1CombatSpecialRecovery_special_recovery.recoveryMs);
        const float sample=combatSample(recovery.released-move.owner.tick,localSpecialDuration(move.bank),count);
        blendCombatBank(pose,1,offset,count,sample,weight);
    }
#endif
#endif
#ifdef SR1_LOCAL_CALIBRATED_COMBAT
    const LocalDodge dodge = readLocalDodge(frame, actor, now, 0);
    if (dodge.owner.tick) {
        const uint64_t age = now - dodge.owner.tick;
        const uint64_t duration = sheet_sr1CombatDodgeReference_rows[dodge.direction]->durationMs;
        unsigned offset = GROUND_POSE_DODGE;
        for (unsigned i = 0; i < dodge.direction; ++i) offset += localDodgePoses[i];
        const unsigned count = localDodgePoses[dodge.direction];
        const uint64_t blend = airStrikeFlow->linkBlendMs;
        const float weight = fminf(combatEase(age, blend), combatEase(duration - age, blend));
        blendCombatBank(pose, 1, offset, count, combatSample(age, duration, count), weight);
#ifdef SR1_LOCAL_COMBAT_REPAIR
        static _Thread_local uint64_t reportedDodge;
        if (reportedDodge!=dodge.owner.tick) {
            reportedDodge=dodge.owner.tick;
            record("standalone-dodge-draw realm=%u direction=%u offset=%u count=%u",frame->realm,dodge.direction,offset,count);
        }
#endif
        return;
    }
#endif
#ifdef SR1_LOCAL_GUARD_LOCOMOTION
    static _Thread_local float combatRunSamples;
    static _Thread_local uint64_t combatRunEdge;
    const bool running = phase == GROUND_RUN && input->guardHeld &&
        sameLocalAction(&input->guard, frame, actor, now, UINT64_MAX);
#ifdef SR1_LOCAL_COMBAT_TIMING
    static _Thread_local LocalActionOwner legExit;
    static _Thread_local JumpLocal guardLegs[14];
    if (!running && combatRunEdge && !input->guardHeld && phase == GROUND_RUN &&
        groundTransition.active && groundTransition.phase == GROUND_RUN &&
        sameLocalAction(&input->guard, frame, actor, now, combatTiming->guardLegExitMs)) {
        legExit = localActionOwner(frame, actor, input->guard.tick);
        memcpy(guardLegs, groundTransition.shown, sizeof(guardLegs));
        gait.runSamples = combatRunSamples * GROUND_POSE_MOVE / LOCAL_GUARD_RUN_POSES;
        sampleGroundLocals(GROUND_RUN, gait.runSamples, pose);
        record("defiance-guard-to-run realm=%u step=%.2f phase=%.2f", frame->realm, actualGroundStep, gait.runSamples);
    }
    if (phase != GROUND_RUN || running) legExit = (LocalActionOwner){0};
    if (sameLocalAction(&legExit, frame, actor, now, combatTiming->guardLegExitMs)) {
        const float weight = combatEase(now - legExit.tick, combatTiming->guardLegExitMs);
        for (unsigned bone = 1; bone < ARRAYSIZE(guardLegs); ++bone) {
            const JumpLocal walk = pose[bone];
            groundBlendLocal(&guardLegs[bone], &walk, weight, &pose[bone]);
        }
    }
#endif
    if (!running || input->guard.tick != combatRunEdge) combatRunSamples = 0;
    combatRunEdge = running ? input->guard.tick : 0;
#endif
    if (phase == GROUND_NATIVE || phase == GROUND_STRIKE || frame->strikePending) return;
#ifdef SR1_LOCAL_AIR_SLAM
    if (applyLocalSlamPose(pose, frame, actor, now)) return;
#endif
#ifdef SR1_LOCAL_AIR_STRIKE
    if (applyLocalAirStrikePose(pose, frame, actor, now)) return;
#endif
#ifdef SR1_LOCAL_COMBAT_TEMPO
    if (localLiftJumpPresentation(input, frame, actor, now)) {
        const uint64_t age = now - input->lift.tick;
        const uint64_t remaining = input->liftJumpFlight ?
            heldLift->upperBodyMs - (now - input->liftJumpFlight) : heldLift->upperBodyMs;
        blendCombatBank(pose, 14u, GROUND_POSE_GUARD_END, LOCAL_LIFT_POSES,
            combatSample(age, guardClips->liftMs, LOCAL_LIFT_POSES),
            combatEase(remaining, airPolicy->phaseBlendMs));
#ifdef SR1_LOCAL_ROTOR44
        localAudioTrack(38,input->lift.tick,combatSample(age,guardClips->liftMs,LOCAL_LIFT_POSES)*.5f,frame->realm,now);
#endif
        return;
    }
#endif
    if (localYPresentation(input, frame, actor, now)
#ifdef SR1_LOCAL_COMBAT_RECOVERY
        && input->airborneLift
#endif
    ) {
        const uint64_t elapsed = now - input->lift.tick;
        unsigned windup = (unsigned)guardClips->airWindupMs;
        unsigned offset = GROUND_POSE_GUARD_END;
        unsigned count = LOCAL_LIFT_POSES;
        uint64_t length = guardClips->liftMs, clipElapsed = elapsed;
        if (input->airborneLift) {
            offset += LOCAL_LIFT_POSES;
            count = LOCAL_WINDUP_POSES;
            length = windup;
            if (elapsed >= windup) {
                offset += LOCAL_WINDUP_POSES;
                count = LOCAL_SLAM_POSES;
                length = guardClips->airStrikeMs;
                clipElapsed -= windup;
            }
        }
        const uint64_t end = input->airborneLift ? windup + guardClips->airStrikeMs : length;
#ifdef SR1_LOCAL_COMBAT_TIMING
        if (!input->airborneLift) {
            const float weight = elapsed < length ? combatEase(elapsed, combatTiming->groundYEnterMs) :
                1.f - combatEase(elapsed - length, combatTiming->groundYExitMs);
            blendCombatBank(pose, 1, offset, count, combatSample(elapsed, length, count), weight);
#ifdef SR1_LOCAL_ROTOR44
            localAudioTrack(38,input->lift.tick,combatSample(elapsed,length,count)*.5f,frame->realm,now);
#endif
            return;
        }
#endif
        const float blendMs = (float)strikePresentation->transitionMs;
        const float weight = fminf(1.f, fminf((float)elapsed, (float)(end - elapsed)) / blendMs);
        blendCombatBank(pose, 1, offset, count, (float)clipElapsed * (count - 1.f) / (float)length, weight);
        return;
    }
    if ((phase != GROUND_IDLE && phase != GROUND_RUN) ||
        !sameLocalAction(&input->guard, frame, actor, now, UINT64_MAX)) return;
    const float weight = localGuardWeight(input, now);
    if (weight > 0.f) {
        const uint64_t elapsed = now - input->guard.tick;
        const unsigned duration = input->guardHeld ? guardClips->entryMs : guardClips->exitMs;
        const float sample = fmodf((float)(elapsed % (LOCAL_GUARD_POSES * 1000)) * .060f, (float)LOCAL_GUARD_POSES);
        if (phase == GROUND_IDLE) {
            blendCombatBank(pose, 1u, GROUND_POSE_BASE, LOCAL_GUARD_POSES, sample, weight);
        }
#ifdef SR1_LOCAL_GUARD_LOCOMOTION
        if (running) {
            const float speed = (float)sheet_sr1LocalGuardDirection_combat_run.unitsPerSecond;
            combatRunSamples = fmodf(combatRunSamples + actualGroundStep * 60.f / speed,
                (float)LOCAL_GUARD_RUN_POSES);
            #ifdef SR1_LOCAL_COMBAT57
            uint16_t yaw57;
            if(input->guardDirectional&&readAt(actor+sheet_sr1GroundSteering_camera_relative_start.yawOffset,&yaw57,2)){
                #ifdef SR1_LOCAL_COMBAT58
                JumpLocal guard58[66];memcpy(guard58,pose,sizeof guard58);blendCombatBank(guard58,1,GROUND_POSE_BASE,LOCAL_GUARD_POSES,sample,weight);
#endif
                const unsigned offset57=GROUND_POSE_TOTAL+BODY_AXIS_SAMPLES+LOCAL_CHARGE_POSES48-LOCAL_EXTRA_POSES57;
                const float delta57=combatYawDelta(yaw57,input->guardBearing)*(6.28318530718f/4096.f);
                const float sx=sinf(delta57),fy=-cosf(delta57),side=fabsf(sx),front=fabsf(fy),mix=side/(side+front);
                const unsigned lateral=sx<0?0u:1u;
                unsigned lateralOffset=offset57+(lateral?localExtraPoseCounts57[0]:0);
                unsigned longitudinalOffset=fy<0?GROUND_POSE_ACTION_END:offset57+localExtraPoseCounts57[0]+localExtraPoseCounts57[1];
                unsigned longitudinalCount=fy<0?LOCAL_GUARD_RUN_POSES:localExtraPoseCounts57[2];
                JumpLocal along57[66],side57[66];memcpy(along57,pose,sizeof along57);memcpy(side57,pose,sizeof side57);
                const float phase57=combatRunSamples/LOCAL_GUARD_RUN_POSES;
                blendCombatBankRange(along57,1,14,longitudinalOffset,longitudinalCount,phase57*longitudinalCount,1);
                blendCombatBankRange(side57,1,14,lateralOffset,localExtraPoseCounts57[lateral],phase57*localExtraPoseCounts57[lateral],1);
                for(unsigned b=1;b<14;b++){JumpLocal mixed;groundBlendLocal(&along57[b],&side57[b],mix,&mixed);groundBlendLocal(&pose[b],&mixed,weight,&pose[b]);}
#ifdef SR1_LOCAL_COMBAT58
                localGuardUpper58(pose,guard58,groundParents);
#endif
            }
#else
            blendCombatBank(pose, 1u, GROUND_POSE_ACTION_END, LOCAL_GUARD_RUN_POSES, combatRunSamples, weight);
#endif
        }
#endif
        if (elapsed < duration) {
            const unsigned offset = GROUND_POSE_BASE + LOCAL_GUARD_POSES +
                (input->guardHeld ? 0 : LOCAL_GUARD_ENTRY_POSES);
            const unsigned count = input->guardHeld ? LOCAL_GUARD_ENTRY_POSES : LOCAL_GUARD_EXIT_POSES;
            blendCombatBank(pose, 14u, offset, count, (float)elapsed * (count - 1.f) / (float)duration, weight);
        } else if (phase == GROUND_RUN
#ifdef SR1_LOCAL_GUARD_LOCOMOTION
            && !running
#endif
        ) {
            blendCombatBank(pose, 14u, GROUND_POSE_BASE, LOCAL_GUARD_POSES, sample, weight);
        }
    }
}
#endif
#ifdef SR1_LOCAL_DEFIANCE_JUMP
static bool ordinaryPreparation(uintptr_t actor) {
    uint16_t child[2];
    return readAt(actor + 0x374, &child[0], sizeof(child[0])) &&
        readAt(actor + 0x49c, &child[1], sizeof(child[1])) &&
        (child[0] == 26 || child[0] == 34) && (child[1] == 26 || child[1] == 34);
}

static GroundPhase localJumpPhase(const Sr1LocalFrame *frame, uintptr_t actor, uint64_t now,
    GroundPhase ground, LocalJumpReceipt flight, float *clipSample) {
    if (frame->airState == SR1_AIR_COMPRESS) {
        return ordinaryPreparation(actor) ? GROUND_JUMP : ground;
    }
    if (!sameLocalAction(&flight.owner, frame, actor, now, airPolicy->maxFlightMs) ||
        flight.owner.tick <= suppressedFlight) return ground;
    if (frame->airState == SR1_AIR_LAND) return GROUND_LAND;
    if (frame->airState != SR1_AIR_JUMP && frame->airState != SR1_AIR_FALL) {
        suppressedFlight = flight.owner.tick;
        return ground;
    }
    int16_t position[3];
    if (!readAt(actor + 0x9c, position, sizeof(position))) return ground;
    if (useAuthoredFall(frame->verticalVelocity, (int)position[2] - flight.floor)) return GROUND_FALL;
    *clipSample = (float)(now - flight.owner.tick) * .060f;
    return GROUND_JUMP;
}

static void animateLocalTurn(const Sr1LocalFrame *frame, uintptr_t actor, uint64_t now) {
    if (frame->nativeControl) return;
    const LocalTurnReceipt turn = readLocalTurn();
    if (!sameLocalAction(&turn.owner, frame, actor, now, airPolicy->turnMs)) return;
    const float headingChange = turnFromVisibleRoot(drawScratch[0], turn.target, turn.units);
    const float offset = visualTurnRemainder(headingChange, now - turn.owner.tick);
    rotateVisibleYaw(drawScratch, offset);
    if (loggedTurn != turn.owner.tick) {
        loggedTurn = turn.owner.tick;
        record("ground-visual-turn realm=%u span=%ld first-offset=%.1f", frame->realm, (long)airPolicy->turnMs, offset);
    }
}
#ifdef SR1_LOCAL_LANDING_CONTACT
static void plantNeutralLanding(const Sr1LocalFrame *frame, uintptr_t actor, uint64_t now,
                                const float root[13], GroundPhase phase) {
    const uint64_t intent = (uint64_t)InterlockedCompareExchange64(&groundIntentTick, 0, 0);
    if (intent && intent <= now && now - intent < (uint64_t)groundPolicy->maxGapMs) {
        landingPlant.tick = 0;
        return;
    }
    const LocalJumpReceipt flight = readLocalJump();
    if (!sameLocalAction(&flight.owner, frame, actor, now, airPolicy->maxFlightMs)) {
        landingPlant.tick = 0;
        return;
    }
    const float *left = drawScratch[authoredPolicy->leftToe], *right = drawScratch[authoredPolicy->rightToe];
    float centre[2] = {(left[10] + right[10]) * .5f, (left[11] + right[11]) * .5f};
    if (landingPlant.tick != flight.owner.tick) {
        if (phase != GROUND_LAND) return;
        landingPlant.tick = flight.owner.tick;
        landingPlant.foot[0] = centre[0];
        landingPlant.foot[1] = centre[1];
        landingPlant.reported = false;
#ifdef SR1_LOCAL_IMMEDIATE_REPEAT
        landingPlant.settledAt = 0;
#endif
    }
    float shiftX = landingPlant.foot[0] - centre[0], shiftY = landingPlant.foot[1] - centre[1];
    const float distance = hypotf(shiftX, shiftY);
    if (!isfinite(distance) || distance < .01f) return;
#ifdef SR1_LOCAL_IMMEDIATE_REPEAT
    float weight = fminf(1.f, (float)repeatPolicy->plantLimit / distance);
    if (phase == GROUND_IDLE) {
        if (!landingPlant.settledAt) landingPlant.settledAt = now;
        const float u = fminf(1.f, (float)(now - landingPlant.settledAt) / (float)authoredPolicy->plantAfterMs);
        if (u == 1.f) {
            landingPlant.tick = 0;
            return;
        }
        weight *= 1.f - u * u * (3.f - 2.f * u);
    }
    shiftX *= weight;
    shiftY *= weight;
#else
    if (distance > (float)repeatPolicy->plantLimit) return;
#endif
    for (unsigned i = 1; i < 66; ++i) {
        drawScratch[i][10] += shiftX;
        drawScratch[i][11] += shiftY;
    }
    for (unsigned k = 0; k < 3; ++k) {
        groundTransition.shown[1].p[k] += root[k] * shiftX + root[3 + k] * shiftY;
    }
    if (!landingPlant.reported && distance > 2.f) {
        landingPlant.reported = true;
        record("defiance-landing-plant realm=%u planar=%.2f", frame->realm, distance);
    }
}
#endif
#endif
#else
static _Thread_local unsigned nativeChecks, lastPhase = 2;
static _Thread_local uint64_t startTick, lastTravel;
static _Thread_local uintptr_t lastActor;
static _Thread_local float lastPosition[2];
#endif

#ifdef SR1_LOCAL_REAVER_PRESENTATION
static void loadLocalBlade(HANDLE pipe, uint64_t deadline);
#ifdef SR1_LOCAL_FORMS45
static bool loadLocalHud45(HANDLE,uint64_t);
#endif
static void localBladeCapture(uintptr_t actor, uintptr_t model, const float submitted[66][13],
    const Sr1LocalFrame *frame);
#endif

static bool loadGroundFrames(void) {
    wchar_t pipeName[96];
    swprintf(pipeName, ARRAYSIZE(pipeName), L"\\\\.\\pipe\\RazielSR1GroundMotion-%lu", (unsigned long)GetCurrentProcessId());
    HANDLE pipe = INVALID_HANDLE_VALUE;
    for (unsigned attempt = 0; attempt <
#ifdef SR1_LOCAL_COMBAT60
        3000
#else
        600
#endif
    ; ++attempt) {
        pipe = CreateFileW(pipeName, GENERIC_READ, 0, NULL, OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, NULL);
        if (pipe != INVALID_HANDLE_VALUE) break;
        Sleep(100);
    }
    if (pipe == INVALID_HANDLE_VALUE) return false;
    const uint64_t deadline = GetTickCount64() + 10000;
    DWORD filled = 0;
    while (filled < sizeof(groundPayload) && GetTickCount64() < deadline) {
        DWORD available, got;
        if (!PeekNamedPipe(pipe, NULL, 0, NULL, &available, NULL)) break;
        if (!available) {
            Sleep(4);
            continue;
        }
        const DWORD remaining = sizeof(groundPayload) - filled;
        const DWORD request = available < remaining ? available : remaining;
        if (!ReadFile(pipe, (unsigned char *)&groundPayload + filled, request, &got, NULL) || !got) break;
        filled += got;
    }
    char digest[65];
    const bool valid = filled == sizeof(groundPayload) &&
        boundedSha256(&groundPayload, filled, sizeof(groundPayload), digest) && !strcmp(digest, GROUND_POSE_HASH);
#ifdef SR1_LOCAL_REAVER_PRESENTATION
    if (valid) loadLocalBlade(pipe, deadline);
#endif
#ifdef SR1_LOCAL_ROTOR44
    if(valid&&!localAudioLoad(pipe,deadline))record("defiance-sword-audio refused RAM payload");
#endif
#ifdef SR1_LOCAL_FORMS45
    if(valid&&!loadLocalHud45(pipe,deadline))record("reaver-menu refused RAM payload");
#endif
    CloseHandle(pipe);
    if (!valid) return false;
#ifdef SR1_DEFIANCE_GROUND_CALIBRATION
    for (unsigned i = 0; i < ARRAYSIZE(groundPayload.soles); ++i) {
        for (unsigned j = 0; j < 3; ++j) if (groundPayload.soles[i].bone[j] >= 66) return false;
    }
#endif
    for (unsigned i = 0; i < ARRAYSIZE(groundFrames); ++i) {
        if (!skeletonLocalValid(groundFrames[i])) return false;
#ifdef SR1_DEFIANCE_GROUND_BLEND
        if (!jumpLocals(groundFrames[i], groundParents, groundLocalFrames[i])) return false;
#endif
    }
#ifdef SR1_LOCAL_ROTOR44
    for (unsigned i=0;i<BODY_AXIS_SAMPLES;++i) {
        if (!skeletonLocalValid(groundPayload.rotorFrames[i]) ||
            !jumpLocals(groundPayload.rotorFrames[i],groundParents,groundLocalFrames[GROUND_POSE_TOTAL+i])) return false;
    }
#endif
#ifdef SR1_LOCAL_COMBAT48
    for(unsigned i=0;i<LOCAL_CHARGE_POSES48;i++)if(!skeletonLocalValid(groundPayload.chargedFrames[i])||
        !jumpLocals(groundPayload.chargedFrames[i],groundParents,groundLocalFrames[GROUND_POSE_TOTAL+BODY_AXIS_SAMPLES+i]))return false;
#endif
    return true;
}

static bool drawIsPlayer(const uintptr_t args[8], uintptr_t *actor) {
    uintptr_t object, render, models, model;
    int16_t index;
    return readAt(base + host->actorRva, actor, sizeof(*actor)) && *actor &&
        readAt(*actor + 0x1c6, &index, sizeof(index)) && !index &&
        readAt(*actor + 0x30, &object, sizeof(object)) && object &&
        readAt(object + 0x10, &models, sizeof(models)) && models &&
        readAt(models, &model, sizeof(model)) &&
        readAt(*actor + 0x70, &render, sizeof(render)) &&
        sr1NativePoseArgumentsMatch(args[0], args[1], args[3], object, model, render, 0x70);
}

static uintptr_t groundDraw(uintptr_t a, uintptr_t b, uintptr_t c, uintptr_t d,
    uintptr_t e, uintptr_t f, uintptr_t g, uintptr_t h) {
    uintptr_t args[8] = {a,b,c,d,e,f,g,h}, actor;
    if (insideGroundDraw || groundDrawRefused || !drawIsPlayer(args, &actor)) {
        return sr1NativePoseForward(originalGroundDraw, args);
    }
    const LONG thread = (LONG)GetCurrentThreadId();
    const LONG prior = InterlockedCompareExchange(&drawThread, thread, 0);
    if (prior && prior != thread) return sr1NativePoseForward(originalGroundDraw, args);

    int32_t extra;
    unsigned char weights[66];
    float current[66][13];
    if (!readAt(a + 0xc, &extra, sizeof(extra)) || extra || !readAt(a + 0x69c, weights, sizeof(weights)) ||
        !readAt(d, current, sizeof(current))) return sr1NativePoseForward(originalGroundDraw, args);
    unsigned weighted = 0;
    for (unsigned i = 0; i < ARRAYSIZE(weights); ++i) weighted += weights[i] != 0;
    if (weighted != 57) return sr1NativePoseForward(originalGroundDraw, args);

    Sr1LocalFrame frame = readFrame();
#ifdef SR1_LOCAL_THIRD_FINISH
    const uint64_t presentationTick = GetTickCount64();
#ifdef SR1_LOCAL_THIRD_SWEEP
    const bool strikePoseFresh = groundTransition.active && groundTransition.phase == GROUND_STRIKE &&
        presentationTick >= groundTransition.lastTick &&
        presentationTick - groundTransition.lastTick <= (uint64_t)groundPolicy->maxGapMs;
#endif
    bool displayOnly = false;
    if (!frame.ready && drawnGroundXOwner.actor == actor) {
        DWORD focus = 0;
        GetWindowThreadProcessId(GetForegroundWindow(), &focus);
        const Sr1LocalFrame observed = focus != GetCurrentProcessId() ? readLocalFrame(false) : (Sr1LocalFrame){0};
        const bool canSettle = observed.renderBlend && !observed.groundStrike && !observed.strikePending &&
            (observed.grounded || observed.strikeSettled);
#ifdef SR1_LOCAL_THIRD_SWEEP
        const bool canHold = observed.strikeTransition && strikePoseFresh;
#else
        const bool canHold = false;
#endif
        if (observed.ready && observed.airState == SR1_AIR_NONE && (canSettle || canHold) &&
            sameLocalAction(&drawnGroundXOwner, &observed, actor, presentationTick, UINT64_MAX)) {
            // With no focus, restore the visual stance only after the authenticated strike has ended.
            // Input and world travel still require the foreground frame.
            frame = observed;
            displayOnly = true;
        }
    }
    if (displayOnly && !backgroundStrikeReturn
#ifdef SR1_LOCAL_THIRD_SWEEP
        && (!frame.strikeTransition || frame.strikeSettled)
#endif
    ) record("ground-x-stance-return realm=%u focus=0", frame.realm);
    backgroundStrikeReturn = displayOnly;
    if (frame.strikeSettled) {
        frame.grounded = true;
        frame.nativeControl = false;
    }
    if (frame.ready && !sameLocalAction(&drawnGroundXOwner, &frame, actor, presentationTick, UINT64_MAX))
        drawnGroundXOwner = (LocalActionOwner){0};
#endif
#ifdef SR1_DEFIANCE_GROUND_BLEND
#ifdef SR1_LOCAL_COMBAT_PRESENTATION
#ifdef SR1_LOCAL_THIRD_SWEEP
    const bool bridgeStrike = frame.strikeTransition && !frame.strikeSettled &&
        (!frame.groundStrike || displayOnly) && strikePoseFresh &&
        sameLocalAction(&drawnGroundXOwner, &frame, actor, presentationTick,
            displayOnly ? UINT64_MAX : (uint64_t)groundPolicy->maxGapMs);
    if (bridgeStrike && !reportedStrikeBridge)
        record("ground-x-presentation-hold realm=%u focus=%u", frame.realm, !displayOnly);
    reportedStrikeBridge = bridgeStrike;
#endif
    const bool holdStrike = (frame.strikePending
#ifdef SR1_LOCAL_THIRD_SWEEP
        || bridgeStrike
#endif
        ) && groundTransition.active && groundTransition.phase != GROUND_NATIVE &&
        lastActor == actor && lastWorld == frame.worldGeneration && lastGeneration == frame.playerGeneration && lastRealm == frame.realm;
#else
    const bool holdStrike = false;
#endif
    if (!frame.ready || (!frame.renderBlend && !holdStrike) || frame.realm == SR1_LOCAL_UNKNOWN ||
        actor != player || !checkGroundHierarchy(b)) {
#ifdef SR1_LOCAL_THIRD_SWEEP
        if (groundTransition.active && groundTransition.phase == GROUND_STRIKE && lastActor == actor) {
            record("ground-x-presentation-release realm=%u ready=%u render=%u transition=%u settled=%u",
                frame.realm, frame.ready, frame.renderBlend, frame.strikeTransition, frame.strikeSettled);
        }
        renderedThirdSample = -1.f;
#endif
#ifdef SR1_LOCAL_GROUND_X
        drawnGroundXStart = 0;
#elif defined(SR1_LOCAL_COMBAT_TIMING)
        visualThird = (LocalActionOwner){0};
#endif
        groundTransition.active = false;
        lastActor = 0;
#ifdef SR1_LOCAL_DEFIANCE_JUMP
        const LocalJumpReceipt inactive = readLocalJump();
        if (inactive.owner.tick > suppressedFlight) suppressedFlight = inactive.owner.tick;
#endif
#ifdef SR1_DEFIANCE_GROUND_CALIBRATION
        InterlockedExchange(&calibratedDrawReady, 0);
        flightStart = 0;
#endif
        return sr1NativePoseForward(originalGroundDraw, args);
    }
    const uint64_t now = GetTickCount64();
    const GroundPhase motionPhase = groundPhase(&frame, actor, now, current[0]);
#ifdef SR1_LOCAL_ROTOR44
    localAudioPulse(&frame,actor,now);
#endif
#ifdef SR1_LOCAL_GROUND_X
    const LocalGroundX groundX =
#ifdef SR1_LOCAL_THIRD_FINISH
        displayOnly ? (LocalGroundX){0} :
#endif
        readGroundX(&frame, actor, now);
#ifdef SR1_LOCAL_THIRD_FINISH
    if (groundX.owner.tick) drawnGroundXOwner = groundX.owner;
#endif
    const bool continuingStrike = !frame.groundStrike && groundX.owner.tick;
#elif defined(SR1_LOCAL_COMBAT_TIMING)
    const LocalCombatInput combatDrawInput = readLocalCombatInput();
    const bool continuingStrike = !frame.groundStrike && !frame.strikePending &&
        (motionPhase == GROUND_RUN || motionPhase == GROUND_IDLE) && frame.airState == SR1_AIR_NONE &&
        sameLocalAction(&visualThird, &frame, actor, now, combatTiming->groundThirdMs) &&
        !localYPresentation(&combatDrawInput, &frame, actor, now);
    if (!frame.groundStrike && !continuingStrike && !holdStrike) visualThird = (LocalActionOwner){0};
#endif
#if defined(SR1_DEFIANCE_GROUND_CALIBRATION) && !defined(SR1_DEFIANCE_GROUND_AUTHORED)
    const GroundPhase phase = motionPhase == GROUND_NATIVE ? GROUND_NATIVE : GROUND_IDLE;
#elif defined(SR1_LOCAL_DEFIANCE_JUMP)
    float airSample = 0;
#ifdef SR1_LOCAL_COMBAT_FACING
    const LocalSpecial displaySpecial=displayOnly ? (LocalSpecial){0} : localReadSpecial(&frame,actor,now);
    const GroundPhase fallbackPhase=motionPhase==GROUND_NATIVE && displaySpecial.move ?
        (localSpecialAir(displaySpecial.move) ? GROUND_FALL : GROUND_IDLE) : motionPhase;
#else
    const GroundPhase fallbackPhase=motionPhase;
#endif
    const GroundPhase phase = holdStrike ? groundTransition.phase : (frame.groundStrike
#ifdef SR1_LOCAL_COMBAT_TIMING
        || continuingStrike
#endif
        ) ? GROUND_STRIKE :
#ifdef SR1_LOCAL_COMBAT_SYNC42
        displaySpecial.move==LOCAL_SPECIAL_TEMPEST ? GROUND_FALL :
#endif
        localJumpPhase(&frame, actor, now, fallbackPhase, readLocalJump(), &airSample);
#else
    const GroundPhase phase = motionPhase;
#endif
    const GroundPhase previous = groundTransition.active ? groundTransition.phase : GROUND_NATIVE;
#ifdef SR1_LOCAL_COMBAT_CLOCK
#ifdef SR1_LOCAL_GROUND_X
    const bool newStrike = phase == GROUND_STRIKE && !holdStrike &&
        (groundX.owner.tick ? drawnGroundXStart != groundX.start || previous != GROUND_STRIKE :
            frame.strikeIdentity != strikeIdentity || frame.strikeTime < strikeTime ||
            frame.strikeOrdinal != drawnStrikeOrdinal);
#ifdef SR1_LOCAL_COMBAT_RHYTHM
    groundTransition.repeatGroundCombo = newStrike && groundX.owner.tick &&
        previous == GROUND_STRIKE && drawnGroundXStart &&
#ifdef SR1_LOCAL_COMBO_FLOW
        groundX.ordinal == (drawnStrikeOrdinal + 1) % 3;
#else
        groundX.ordinal == 0 && drawnStrikeOrdinal == 2;
#endif
#endif
    if (!holdStrike) drawnGroundXStart = groundX.start;
#else
    const bool newStrike = phase == GROUND_STRIKE && !holdStrike &&
#ifdef SR1_LOCAL_COMBAT_TIMING
        !continuingStrike &&
#endif
        (frame.strikeIdentity != strikeIdentity || frame.strikeTime < strikeTime
#ifdef SR1_MEASURED_GROUND_COMBO
            || frame.strikeOrdinal != drawnStrikeOrdinal
#endif
        );
#endif
    if (!holdStrike
#ifdef SR1_LOCAL_COMBAT_TIMING
        && !continuingStrike
#endif
    ) {
        strikeIdentity = frame.strikeIdentity;
        strikeTime = frame.strikeTime;
#ifdef SR1_MEASURED_GROUND_COMBO
        drawnStrikeOrdinal = frame.strikeOrdinal;
#endif
    }
#if defined(SR1_LOCAL_COMBAT_TIMING) && !defined(SR1_LOCAL_GROUND_X)
    if (newStrike) {
        visualThird = (LocalActionOwner){0};
        if (frame.strikeOrdinal == 2) visualThird = localActionOwner(&frame, actor, now);
    }
#endif
#ifdef SR1_LOCAL_COMBAT_PRESENTATION
    groundTransition.restartStrike = newStrike;
    groundTransition.holdStrikePose = holdStrike;
#else
    if (newStrike && previous == GROUND_STRIKE) groundTransition.phase = GROUND_NATIVE;
#endif
#else
    const bool newStrike = false;
#endif
    const bool changed = phase != previous || newStrike;
#ifdef SR1_LOCAL_THIRD_SWEEP
    if (!holdStrike) renderedThirdSample = -1.f;
#endif
    if (nativeChecks < 20) {
        if (phase != GROUND_IDLE && phase != GROUND_RUN) return sr1NativePoseForward(originalGroundDraw, args);
        memcpy(drawScratch, current, sizeof(drawScratch));
    } else {
        JumpLocal donor[66] = {0};
#ifdef SR1_DEFIANCE_GROUND_CALIBRATION
        float gaitMotionStep = actualGroundStep;
#ifdef SR1_LOCAL_COMBAT_PRESENTATION
        if (holdStrike || (phase == GROUND_STRIKE
#if defined(SR1_LOCAL_COMBAT_TIMING) && !defined(SR1_LOCAL_GROUND_X)
            && !continuingStrike
#endif
        )) gaitMotionStep = 0;
#endif
#ifdef SR1_DEFIANCE_GROUND_AUTHORED
        if (changed && phase == GROUND_RUN && previous == GROUND_IDLE) gait.runSamples = 0;
#ifdef SR1_DEFIANCE_GROUND_RESPONSIVE
        groundTransition.strongEntry = InterlockedCompareExchange(&fullGroundIntent, 0, 0) != 0;
#endif
#endif
#ifdef SR1_LOCAL_MOVING_LANDING
        const uint64_t directionTick = (uint64_t)InterlockedCompareExchange64(&groundIntentTick, 0, 0);
        const bool movingLand = phase == GROUND_LAND && directionTick && directionTick <= now &&
            now - directionTick <= (uint64_t)groundPolicy->maxGapMs;
        const float landingMix = blendLandingTravel(&landingTravel, movingLand, landingStep,
            (float)repeatPolicy->movingBlendDistance);
        if (movingLand && landingStep > 0 && landingTravel == landingStep) {
            record("defiance-moving-landing realm=%u step=%.2f", frame.realm, landingStep);
        }
        updateGroundGait(&gait, now, movingLand ? landingStep : gaitMotionStep,
            movingLand || motionPhase == GROUND_RUN, GROUND_POSE_IDLE, GROUND_POSE_MOVE);
#else
        updateGroundGait(&gait, now, gaitMotionStep, motionPhase == GROUND_RUN, GROUND_POSE_IDLE, GROUND_POSE_MOVE);
#endif
#ifdef SR1_DEFIANCE_GROUND_AUTHORED
        if (phase == GROUND_RUN) sampleGroundLocals(phase, gait.runSamples, donor);
        if (phase == GROUND_IDLE) {
#ifdef SR1_LOCAL_GROUND_ACTIONS
            if (changed) {
                idleFromRun = previous == GROUND_RUN;
                reportedIdleBank = UINT_MAX;
            }
            sampleLocalIdle(changed ? 0 : now - groundTransition.start, donor, frame.realm);
#else
            if (changed) {
                const float settled = 2.f * (float)authoredPolicy->plantAfterMs * .060f;
                idleStart = previous == GROUND_RUN ? 0.f : settled;
            }
            const float elapsed = changed ? 0.f : (float)(now - groundTransition.start);
            sampleGroundLocals(phase, idleStart + elapsed * .060f, donor);
#endif
        }
#ifdef SR1_LOCAL_DEFIANCE_JUMP
        if (phase >= GROUND_JUMP && !holdStrike) {
#ifdef SR1_LOCAL_GROUND_X
            if (phase == GROUND_STRIKE && groundX.owner.tick) {
                const unsigned ordinal = groundX.ordinal;
#ifdef SR1_LOCAL_NATIVE_COMBO_CLOCK
                const uint64_t age = groundXPoseAge(ordinal, now - groundX.start, groundX.fastClock);
#else
                const uint64_t age = groundXPlaybackAge(ordinal,
#ifdef SR1_LOCAL_SPECIAL_INPUT
                    combatGroundPoseAge(ordinal,now-groundX.start)
#else
                    now-groundX.start
#endif
                );
#endif
#ifdef SR1_LOCAL_COMBO_FLOW
                const float sample = groundXFlowSample(ordinal, age, localStrikePoses[ordinal]);
#else
                float sample = groundXSample(ordinal, age, localStrikePoses[ordinal]);
#ifdef SR1_LOCAL_X_TEMPO
                // Finish the second clip through SR1's live continuation gate so the faster clock
                // does not add another held pose before a confirmed third strike.
                if (ordinal == 1 && frame.groundStrike)
                    sample = groundXSampleAtAge(ordinal, groundXSourceAge(ordinal, age), localStrikePoses[ordinal]);
#endif
#endif
                sampleGroundLocalsForStrike(phase, sample, ordinal, donor);
#ifdef SR1_LOCAL_ROTOR44
                localAudioTrack(29u+ordinal,groundX.start,sample*.5f,frame.realm,now);
#endif
#if defined(SR1_LOCAL_COMBAT_CONTINUITY) && !defined(SR1_LOCAL_COMBAT_SYNC42)
                const uint64_t prelude=sheet_sr1CombatContinuity_continuous_combat.groundAnticipationMs;
                const uint64_t link=sheet_sr1LocalGroundStrikeFlow_ground_links.linkMs;
                if (ordinal<2 && age+prelude>link && hasGroundContinuation(&frame,actor,now,ordinal)) {
                    JumpLocal incoming[66]={0};
                    sampleGroundLocalsForStrike(GROUND_STRIKE,0.f,ordinal+1,incoming);
                    const float mix=combatEase(age+prelude-link,prelude);
                    for (unsigned i=1;i<(unsigned)groundPolicy->wingFirst;++i) {
                        const JumpLocal outgoing=donor[i];
                        groundBlendLocal(&outgoing,&incoming[i],mix,&donor[i]);
                        // Authored foot travel continues to own the current step until native admission.
                        if (i==1) memcpy(donor[i].p,outgoing.p,sizeof(outgoing.p));
                    }
                }
#endif
#ifdef SR1_LOCAL_THIRD_SWEEP
                if (ordinal == 2) renderedThirdSample = sample;
#endif
            } else
#elif defined(SR1_LOCAL_COMBAT_TIMING)
            if (phase == GROUND_STRIKE && sameLocalAction(&visualThird, &frame, actor, now, UINT64_MAX)) {
                const uint64_t age = now - visualThird.tick;
                sampleGroundLocalsForStrike(phase, combatSample(age, combatTiming->groundThirdMs,
                    localStrikePoses[2]), 2, donor);
                if (continuingStrike && motionPhase == GROUND_RUN) {
                    JumpLocal walk[66] = {0};
                    sampleGroundLocals(GROUND_RUN, gait.runSamples, walk);
                    const float walkMix = combatEase(age, combatTiming->groundThirdMs);
                    for (unsigned i = 1; i < 14; ++i) {
                        const JumpLocal finishingStrike = donor[i];
                        groundBlendLocal(&finishingStrike, &walk[i], walkMix, &donor[i]);
                    }
                }
            } else
#endif
            {
            if (phase == GROUND_LAND || phase == GROUND_FALL || phase == GROUND_STRIKE) {
                airSample = changed ? 0.f : (float)(now - groundTransition.start) * .060f;
            }
#ifdef SR1_LOCAL_COMBAT_CLOCK
            if (phase == GROUND_STRIKE) {
                unsigned count = GROUND_POSE_STRIKE;
#ifdef SR1_LOCAL_STRIKE_COMBO
                count = localStrikePoses[frame.strikeOrdinal];
#endif
                airSample = (count - 1.f) * (float)frame.strikeTime / (float)(frame.strikeEnd - 1);
#ifdef SR1_MEASURED_GROUND_COMBO
                if (!changed && now >= groundTransition.start)
                    airSample = measuredStrikeVisualSample(airSample, count, now - groundTransition.start);
#endif
#ifdef SR1_LOCAL_CONTROL_EDGES
                // SR1 simulation and drawing are not synchronized to the same cadence.
                // Move the shown pose between native samples and leave native contact untouched.
                const uint64_t elapsed = !changed && drawnStrikeTick <= now ? now - drawnStrikeTick : 0;
                if (!elapsed || elapsed > (uint64_t)groundPolicy->maxGapMs) {
                    drawnStrikeSample = airSample;
                } else {
                    const float follow = fminf(1.f, (float)elapsed / (1000.f / (float)gaitPolicy->nominalUpdatesHz));
                    drawnStrikeSample += (airSample - drawnStrikeSample) * follow;
                }
                drawnStrikeTick = now;
                airSample = drawnStrikeSample;
#endif
            }
#endif
            sampleGroundLocalsForStrike(phase, airSample, frame.strikeOrdinal, donor);
            }
        }
#ifdef SR1_LOCAL_MOVING_LANDING
        if (landingMix > 0) {
            JumpLocal run[66] = {0};
            sampleGroundLocals(GROUND_RUN, gait.runSamples, run);
            for (unsigned i = 1; i < (unsigned)groundPolicy->wingFirst; ++i) {
                const JumpLocal landing = donor[i];
                groundBlendLocal(&landing, &run[i], landingMix, &donor[i]);
            }
        }
#endif
#endif
#else
        if (phase != GROUND_NATIVE) {
            JumpLocal run[66] = {0};
            sampleGroundLocals(GROUND_IDLE, gait.idleSamples, donor);
            sampleGroundLocals(GROUND_RUN, gait.runSamples, run);
            const float weight = gait.runMix * gait.runMix * (3 - 2 * gait.runMix);
            for (unsigned i = 1; i < (unsigned)groundPolicy->wingFirst; ++i) {
                const JumpLocal idle = donor[i];
                groundBlendLocal(&idle, &run[i], weight, &donor[i]);
                if (i == 1) for (unsigned k = 0; k < 3; ++k) {
                    donor[i].p[k] = idle.p[k] + weight * (run[i].p[k] - idle.p[k]);
                }
            }
        }
#endif
        if (motionPhase != gaitLastPhase) {
            record("ground-gait realm=%u moving=%u native=%u phase=%.2f mix=%.2f",
                frame.realm, motionPhase == GROUND_RUN, motionPhase == GROUND_NATIVE, gait.runSamples, gait.runMix);
            gaitLastPhase = motionPhase;
        }
#else
        if (phase != GROUND_NATIVE) {
            const uint64_t elapsed = !groundTransition.active || changed || now < groundTransition.lastTick ||
                now - groundTransition.lastTick > (uint64_t)groundPolicy->maxGapMs ? 0 : now - groundTransition.start;
            const unsigned count = phase == GROUND_RUN ? GROUND_POSE_MOVE : GROUND_POSE_IDLE;
            sampleGroundLocals(phase, (float)(elapsed * 60 % (1000 * count)) / 1000.f, donor);
        }
#endif
#ifdef SR1_LOCAL_NATIVE_CONTROLS
        if (!holdStrike) {
            const LocalCombatInput input = readLocalCombatInput();
            applyLocalCombatPose(donor, phase, &frame, &input, actor, now);
#ifdef SR1_LOCAL_COMBAT_RECOVERY
            if ((phase == GROUND_IDLE || phase == GROUND_RUN) && !input.airborneLift &&
                localYPresentation(&input, &frame, actor, now)) {
                const uint64_t age = now - input.lift.tick;
                const uint64_t length = guardClips->liftMs;
                const float sample = combatSample(age, length, LOCAL_LIFT_POSES);
                const float weight = groundLiftWeight(age, length);
                // Ground travel and foot placement follow the active gait during a moving lift.
                const float legWeight = weight * (1.f - gait.runMix);
                blendCombatBankRange(donor, 1, 14, GROUND_POSE_GUARD_END, LOCAL_LIFT_POSES, sample, legWeight);
                blendCombatBank(donor, 14, GROUND_POSE_GUARD_END, LOCAL_LIFT_POSES, sample, weight);
#ifdef SR1_LOCAL_ROTOR44
                localAudioTrack(38,input.lift.tick,sample*.5f,frame.realm,now);
#endif
            }
#endif
        }
#endif
#ifdef SR1_LOCAL_COMBO_FLOW
        groundTransition.airStrikeLanding = phase == GROUND_LAND && previous != GROUND_LAND &&
            sameLocalAction(&lastAirStrikeDraw, &frame, actor, now, groundPolicy->maxGapMs);
        if (groundTransition.airStrikeLanding)
            record("defiance-air-x-land-blend realm=%u ms=%lld", frame.realm, (long long)airStrikeFlow->landingBlendMs);
#endif
#ifdef SR1_LOCAL_COMBAT48
        const LocalChargeView48 cast=localChargeRead48();
        if(cast.casting&&cast.form>=1&&cast.form<=9&&sameLocalAction(&cast.owner,&frame,actor,now,5000)){
            unsigned offset=GROUND_POSE_TOTAL+BODY_AXIS_SAMPLES;
            for(unsigned i=1;i<cast.form;i++)offset+=localChargePoseCounts48[i-1];
            const unsigned count=localChargePoseCounts48[cast.form-1];const uint64_t age=now-cast.start;
            const uint64_t duration=(uint64_t)count*1000u/60u;
            const float weight=fminf(combatEase(age,80),combatEase(duration+100>age?duration+100-age:0,100));
            blendCombatBank(donor,1,offset,count,fminf((float)count-1.f,age*60.f/1000.f),weight);
        }
#endif
        #ifdef SR1_LOCAL_COMBAT57
        const unsigned tkOffset57=GROUND_POSE_TOTAL+BODY_AXIS_SAMPLES+LOCAL_CHARGE_POSES48-localExtraPoseCounts57[3];
        const uint64_t tkDuration57=localExtraPoseCounts57[3]*1000u/60u;
        if(sameLocalAction(&localTkPose57,&frame,actor,now,tkDuration57+100)&&!localFinishActive53(&frame,actor,now)&&!localDodgeBusy56(&frame,actor,now)){
            const uint64_t age=now-localTkPose57.tick;const float w=fminf(combatEase(age,60),combatEase(tkDuration57+100>age?tkDuration57+100-age:0,100));
            blendCombatBankRange(donor,14,50,tkOffset57,localExtraPoseCounts57[3],fminf(localExtraPoseCounts57[3]-1.f,age*.06f),w);
        }
#endif
        const bool wasActive = groundTransition.active;
#ifdef SR1_LOCAL_COMBAT53
        const LocalFinish53 finish53=localFinishRead53();
        if(localFinishActive53(&frame,actor,now)){
            const uint64_t age=now-finish53.start;
            #ifdef SR1_LOCAL_COMBAT58
            const uint64_t visual58=(uint64_t)sheet_sr1Combat58_body_action_transitions.finishPoseMs;
            if(age<visual58){unsigned offset58=GROUND_POSE_SPECIAL;const unsigned bank58=(unsigned)sheet_sr1Combat58_body_action_transitions.finishBank;
                for(unsigned i=0;i<bank58;i++)offset58+=localSpecialPoses[i];
                const unsigned count58=localSpecialPoses[bank58];blendCombatBank(donor,1,offset58,count58,combatSample(age,visual58,count58),1);
                localAudioTrack(47,finish53.start,combatSample(age,visual58,count58)*.5f,frame.realm,now);
            }
#else
            const uint64_t duration=(uint64_t)sheet_sr1Combat53_fast_force_held_soul.finishMs;
            const float weight=fminf(combatEase(age,100),combatEase(duration+100>age?duration+100-age:0,150));
            const unsigned offset=GROUND_POSE_TOTAL+BODY_AXIS_SAMPLES+LOCAL_CHARGE_POSES48-LOCAL_FINISH_POSES53
#ifdef SR1_LOCAL_COMBAT57
                -LOCAL_EXTRA_POSES57
#endif
                ;
            blendCombatBank(donor,1,offset,LOCAL_FINISH_POSES53,fminf(LOCAL_FINISH_POSES53-1.f,age*.06f),weight);
#endif
        }
#endif
        if (!groundTransitionDraw(&groundTransition, phase, now, groundParents, current, donor, drawScratch)) {
            if (wasActive && phase == GROUND_NATIVE) record("defiance-ground-native-complete realm=%u", frame.realm);
            return sr1NativePoseForward(originalGroundDraw, args);
        }
#ifdef SR1_DEFIANCE_GROUND_CALIBRATION
#ifdef SR1_DEFIANCE_GROUND_RESPONSIVE
        if (!holdStrike && (phase == GROUND_IDLE || phase == GROUND_LAND
#ifdef SR1_LOCAL_COMBAT_PRESENTATION
            || phase == GROUND_STRIKE
#endif
        )) {
#ifdef SR1_LOCAL_MOVING_LANDING
            supportGroundSoles(current[0], now, frame.realm, 1.f - landingMix);
#else
            supportGroundSoles(current[0], now, frame.realm, 1.f);
#endif
        }
#else
        if (phase != GROUND_NATIVE) supportGroundSoles(current[0], now, frame.realm, 1.f);
#endif
#endif
#ifdef SR1_LOCAL_DEFIANCE_JUMP
        animateLocalTurn(&frame, actor, now);
#endif
#ifdef SR1_LOCAL_LANDING_CONTACT
        if (phase == GROUND_LAND
#ifdef SR1_LOCAL_IMMEDIATE_REPEAT
            || (phase == GROUND_IDLE && landingPlant.tick)
#endif
        ) plantNeutralLanding(&frame, actor, now, current[0], phase);
        else landingPlant.tick = 0;
#endif
    }
#else
    if (!frame.ready || frame.nativeControl || frame.realm == SR1_LOCAL_UNKNOWN || actor != player) {
        startTick = lastTravel = 0;
        lastPhase = 2;
        lastActor = 0;
        return sr1NativePoseForward(originalGroundDraw, args);
    }
    const uint64_t now = GetTickCount64();
    const float dx = current[0][10] - lastPosition[0], dy = current[0][11] - lastPosition[1];
    if (actor == lastActor && isfinite(dx) && isfinite(dy) && dx * dx + dy * dy > 0.0001f) lastTravel = now;
    if (actor != lastActor) lastTravel = startTick = 0;
    lastActor = actor;
    lastPosition[0] = current[0][10];
    lastPosition[1] = current[0][11];
    const unsigned moving = lastTravel && now - lastTravel < 85;
    const bool changed = moving != lastPhase;
    if (changed || !startTick) startTick = now;
    const unsigned count = moving ? GROUND_POSE_MOVE : GROUND_POSE_IDLE;
    const unsigned first = moving ? GROUND_POSE_IDLE : 0;
    const unsigned sample = first + (unsigned)((now - startTick) * 60 / 1000 % count);
    if (nativeChecks < 20) memcpy(drawScratch, current, sizeof(drawScratch));
    else if (!skeletonRebase(drawScratch, current, groundFrames[sample])) return sr1NativePoseForward(originalGroundDraw, args);
#endif

#ifdef SR1_LOCAL_BODY_AXIS43
    if (nativeChecks>=20 && phase!=GROUND_NATIVE && !holdStrike && !displayOnly) {
        float sample=0.f,weight=0.f,extra=0.f;
        uint64_t action=0;
        const bool rotor=displaySpecial.move==LOCAL_SPECIAL_TEMPEST;
        if (rotor) {
            const uint64_t duration=localSpecialDuration(displaySpecial.bank);
            const uint64_t age=now-displaySpecial.owner.tick<duration?now-displaySpecial.owner.tick:duration;
            const float active=(float)sheet_sr1CombatSync42_synchronized_combat.rotorSample;
            sample=displaySpecial.bank==displaySpecial.first?active*(float)age/duration:
                displaySpecial.bank==displaySpecial.last?active+(BODY_AXIS_SAMPLES-1.f-active)*(float)age/duration:active;
            weight=displaySpecial.bank==displaySpecial.first?combatEase(age,combatLinks->linkBlendMs):
                displaySpecial.bank==displaySpecial.last?combatEase(duration-age,combatLinks->linkBlendMs):1.f;
            if (displaySpecial.bank==displaySpecial.first+1 && displaySpecial.spinStarted)
                extra=bodyAxisDirection(groundPayload.airThirdTwist,BODY_AXIS_SAMPLES)*
                    6.2831853071795864769f*(float)combatRotorShownAge(now-displaySpecial.spinStarted,displaySpecial.spins)/
                    (float)combatRotorPeriod();
            action=displaySpecial.owner.tick;
        }
#ifndef SR1_LOCAL_ROTOR44
        else if (!displaySpecial.move) {
            const LocalAirStrike strike=readLocalAirStrike(&frame,actor,now);
            if (strike.owner.tick && strike.ordinal==2) {
                const uint64_t age=now-strike.owner.tick,duration=localAirStrikeDuration(2);
                sample=combatSample(age,duration,BODY_AXIS_SAMPLES);
                weight=fminf(combatEase(age,combatLinks->linkBlendMs),combatEase(duration-age,combatLinks->linkBlendMs));
                weight=fminf(weight,localAirStrikeRecoveryWeight(2,age)/1000.f);
                action=strike.owner.tick;
            }
        }
#endif
        if (action && weight>0.f) {
            weight*=combatEase(now-groundTransition.start,groundTransition.duration);
            // The authored entry/return move the limbs once. Only committed spin turns
            // add full body revolutions; do not append the source clip's extra revolution.
            const float source=bodyAxisSampleAngle(groundPayload.airThirdTwist,BODY_AXIS_SAMPLES,
                rotor?(float)sheet_sr1CombatSync42_synchronized_combat.rotorSample:sample);
            const float angle=bodyAxisBlendAngle(source+extra,weight);
            if (bodyAxisRotatePose(drawScratch,angle)) {
#ifdef SR1_LOCAL_COMBAT58
                if(rotor)localRotorT58(drawScratch,weight);
#endif
#ifdef SR1_LOCAL_LOCK47
                int16_t target[3];
                unsigned fixedYaw=0;
#ifdef SR1_LOCAL_COMBAT48
                if(rotor&&localRotorYaw48(&frame,actor,now,&fixedYaw)){
                    const float a=fixedYaw*(6.28318530718f/4096.f);
                    target[0]=(int16_t)(drawScratch[15][10]+1000.f*sinf(a));target[1]=(int16_t)(drawScratch[15][11]-1000.f*cosf(a));target[2]=(int16_t)drawScratch[15][12];
                    localTargetTilt47(drawScratch,target,weight);
                }else
#endif
                if (rotor && localTargetPosition47(&frame,actor,now,target))localTargetTilt47(drawScratch,target,weight);
#endif
                static _Thread_local uint64_t reportedBodyAction;
                if (reportedBodyAction!=action) {
                    reportedBodyAction=action;
                    float pivot[3],axis[3];
                    if (bodyAxisFromPose(drawScratch,pivot,axis))
                        record("standalone-body-axis realm=%u rotor=%u chest=%.2f,%.2f,%.2f axis=%.4f,%.4f,%.4f",
                            frame.realm,rotor,pivot[0],pivot[1],pivot[2],axis[0],axis[1],axis[2]);
                }
            } else record("standalone-body-axis-refused realm=%u rotor=%u",frame.realm,rotor);
        }
    }
#endif
#if defined(SR1_LOCAL_COMBAT49) && !defined(SR1_LOCAL_COMBAT50)
    const LocalSpecial thrust49=localReadSpecial(&frame,actor,now);
    if(thrust49.move==LOCAL_SPECIAL_PERFORATE){
        const uint64_t age=now-thrust49.owner.tick,duration=localSpecialDuration(thrust49.bank),blend=sheet_sr1Combat49_combat_physics.thrustBlendMs;
        float strength=thrust49.bank==thrust49.first?fminf(1.f,(float)age/blend):1.f;
        if(thrust49.bank==thrust49.last)strength=fminf(strength,age>=duration?0.f:fminf(1.f,(float)(duration-age)/blend));
        localThrustWrist49(drawScratch,groundParents,strength);
    }
#endif
    #ifdef SR1_LOCAL_COMBAT58
    if(nativeChecks>=20&&phase!=GROUND_NATIVE&&frame.ready&&frame.renderBlend&&!displayOnly){
        unsigned kind58=0;uint64_t action58=0;const LocalFinish53 finish58=localFinishRead53();
        const LocalDodge dodge58=readLocalDodge(&frame,actor,now,0);const LocalAirSlam slam58=readLocalSlam(&frame,actor,now,slamRecoveryDuration());
        const LocalAirStrike air58=readLocalAirStrike(&frame,actor,now);const LocalGroundX ground58=readGroundX(&frame,actor,now);
        const LocalCombatInput input58=readLocalCombatInput();const LocalChargeView48 charge58=localChargeRead48();
        if(localFinishActive53(&frame,actor,now)&&now-finish58.start<(uint64_t)sheet_sr1Combat58_body_action_transitions.finishPoseMs){kind58=100;action58=finish58.start;}
        else if(charge58.casting&&sameLocalAction(&charge58.owner,&frame,actor,now,5000)){kind58=110+charge58.form;action58=charge58.start;}
        else if(displaySpecial.move){kind58=10+displaySpecial.move*16+displaySpecial.bank;action58=displaySpecial.owner.tick;}
        else if(dodge58.owner.tick){kind58=200+dodge58.direction;action58=dodge58.owner.tick;}
        else if(slam58.windup){kind58=210+(slam58.impact?2:slam58.falling?1:0);action58=slam58.owner.tick;}
        else if(air58.owner.tick){kind58=220+air58.ordinal;action58=air58.owner.tick;}
        else if(localYPresentation(&input58,&frame,actor,now)||localLiftJumpPresentation(&input58,&frame,actor,now)){kind58=230;action58=input58.lift.tick;}
        else if(ground58.owner.tick){kind58=240+ground58.ordinal;action58=ground58.start;}
        else if(sameLocalAction(&localTkPose57,&frame,actor,now,localExtraPoseCounts57[3]*1000u/60u+100)){kind58=250;action58=localTkPose57.tick;}
        LocalPoseIdentity58 identity58={actor,frame.playerGeneration,frame.worldGeneration,frame.realm,frame.session};
        const Sheet_sr1Combat58*p58=&sheet_sr1Combat58_body_action_transitions;
        localPoseBlend58(&actionPose58,identity58,kind58,action58,now,drawScratch,groundParents,p58->entryMs,p58->exitMs,p58->linkMs,p58->maxGapMs);
    }else memset(&actionPose58,0,sizeof actionPose58);
#endif
    float forwarded[66][13];
#if defined(SR1_LOCAL_COMBAT56) && !defined(SR1_LOCAL_COMBAT58)
    const LocalFinish53 aimFinish56=localFinishRead53();
    if(localFinishActive53(&frame,actor,now)&&aimFinish56.facing){
        const uint64_t age56=now-aimFinish56.start,duration56=(uint64_t)sheet_sr1Combat53_fast_force_held_soul.finishMs;
        const float blend56=fminf(combatEase(age56,100),combatEase(duration56+100>age56?duration56+100-age56:0,150));
        #ifdef SR1_LOCAL_COMBAT57
        localFinishExtend57(drawScratch,aimFinish56.yaw,blend56);
#else
        localFinishArm56(drawScratch,aimFinish56.aim,blend56);
#endif
    }
#endif
    memcpy(forwarded, drawScratch, sizeof(forwarded));
    args[3] = (uintptr_t)drawScratch;
    insideGroundDraw = true;
    const uintptr_t result = sr1NativePoseForward(originalGroundDraw, args);
    insideGroundDraw = false;
    float after[66][13];
    if (!readAt(d, after, sizeof(after)) || memcmp(current, after, sizeof(current)) ||
        memcmp(drawScratch, forwarded, sizeof(forwarded))) {
        InterlockedExchange(&groundDrawRefused, 1);
#ifdef SR1_DEFIANCE_GROUND_CALIBRATION
        InterlockedExchange(&calibratedDrawReady, 0);
#endif
        record("ground-draw-refused-native-matrix-changed");
    } else if (nativeChecks < 20) {
#if defined(SR1_LOCAL_REAVER_PRESENTATION) && !defined(SR1_AUTHORED_BLADE_SOCKET)
        localBladeCapture(actor, b, forwarded, &frame);
#endif
        if (++nativeChecks == 20) record("ground-draw-native-pass-through-verified");
#ifdef SR1_DEFIANCE_GROUND_CALIBRATION
    } else if (phase != GROUND_NATIVE) {
#ifdef SR1_LOCAL_COMBAT_FACING
        static _Thread_local uint64_t reportedSpecialDraw;
        if (!holdStrike && displaySpecial.move && reportedSpecialDraw!=displaySpecial.owner.tick) {
            reportedSpecialDraw=displaySpecial.owner.tick;
            record("standalone-special-draw realm=%u move=%u stage=%u phase=%u",frame.realm,
                displaySpecial.move,displaySpecial.bank,phase);
        }
#endif
#ifdef SR1_LOCAL_REAVER_PRESENTATION
        localBladeCapture(actor, b, forwarded, &frame);
#endif
#ifdef SR1_LOCAL_THIRD_FINISH
        if (!displayOnly)
#endif
            InterlockedExchange(&calibratedDrawReady, 1);
#ifdef SR1_DEFIANCE_GROUND_AUTHORED
#ifdef SR1_LOCAL_DEFIANCE_JUMP
        if (changed && phase == GROUND_STRIKE) record("defiance-ground-strike realm=%u", frame.realm);
        else if (changed && phase >= GROUND_JUMP) {
            const char *const actions[] = {"jump", "fall", "land"};
            record("defiance-air-pose realm=%u action=%s host=%u", frame.realm, actions[phase - GROUND_JUMP], frame.airState);
        } else
#endif
        if (changed) record("defiance-authored realm=%u action=%s", frame.realm,
            phase == GROUND_RUN ? "run-entry" : previous == GROUND_RUN ? "stop" : "stand");
#else
        if (changed) record("defiance-ground-blend realm=%u native->ground", frame.realm);
#endif
#endif
    } else if (changed) {
#ifdef SR1_DEFIANCE_GROUND_BLEND
        const char *const names[] = {"native", "idle", "run", "jump", "fall", "land", "strike"};
        record("defiance-ground-blend realm=%u %s->%s", frame.realm, names[previous], names[phase]);
#else
        record("defiance-ground-pose realm=%u %s", frame.realm, moving ? "moving" : "idle");
        lastPhase = moving;
#endif
    }
    return result;
}

static bool verifyDrawBlock(uintptr_t rva, DWORD length, const char *digest) {
    char actual[65];
    unsigned char bytes[4096];
    return length <= sizeof(bytes) && readAt(base + rva, bytes, length) &&
        boundedSha256(bytes, length, sizeof(bytes), actual) && !strcmp(actual, digest);
}

static bool prepareGroundDraw(void) {
    return verifyDrawBlock(0x40d10, 1961, GROUND_POSE_RENDER_HASH) &&
        verifyDrawBlock(0x9a90, 265, GROUND_POSE_SETUP_HASH) && loadGroundFrames() &&
        MH_CreateHook((void *)(base + 0x40d10), groundDraw, (void **)&originalGroundDraw) == MH_OK;
}
