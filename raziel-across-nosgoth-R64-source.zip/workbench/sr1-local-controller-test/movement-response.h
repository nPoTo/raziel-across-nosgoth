// SPDX-License-Identifier: GPL-3.0-or-later
#pragma once

#include <stdint.h>

static inline void sr1LocalShapeAxes(int16_t *x, int16_t *y, int threshold, int full) {
    const int absX = *x < 0 ? -*x : *x;
    const int absY = *y < 0 ? -*y : *y;
    const int peak = absX > absY ? absX : absY;
    const int other = absX < absY ? absX : absY;
    if (peak <= threshold || peak >= full) return;

    int strength = peak + (peak - threshold) * (full - peak) / (full - threshold);
    // Keep the direction bits produced by SR1 consistent with the shaped input.
    if (other && other <= threshold && other * strength > threshold * peak) {
        strength = threshold * peak / other;
    }
    *x = (int16_t)(*x * strength / peak);
    *y = (int16_t)(*y * strength / peak);
}
