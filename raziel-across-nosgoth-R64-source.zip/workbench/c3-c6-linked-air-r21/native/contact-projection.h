// SPDX-License-Identifier: GPL-3.0-or-later
#pragma once
#include <stdbool.h>
#include <stdint.h>
#include <limits.h>
#include <math.h>
#include <string.h>
#include "exploration-sheets.h"

typedef struct { float palm[3], tip[3]; } C2VisibleSegment;
typedef struct { int16_t center[3]; uint16_t radius; } C2NativeSphere;
typedef struct {
    uint64_t epoch, marker, sourceGeneration, sourcePoseSerial, hostSourcePoseSerial;
    uint32_t realm, sourceForm, playerGeneration, targetGeneration;
    bool nativeOwned, acquired, hostCanStrike, targetCanReceive, sceneClear;
} C2ContactAuthority;
typedef struct {
    uint64_t epoch, marker, sourceGeneration;
    uint32_t playerGeneration, targetGeneration;
} C2ContactKey;

static inline bool c2ContactKey(const C2ContactAuthority *a, C2ContactKey *out) {
    const Sheet_c2ProjectedContact *p=&sheet_c2ProjectedContact_one_grounded_contact;
    if (!a || !out || !a->epoch || !a->marker || !a->sourceGeneration ||
        !a->sourcePoseSerial || a->sourcePoseSerial!=a->hostSourcePoseSerial ||
        !a->playerGeneration || !a->targetGeneration || a->playerGeneration==a->targetGeneration ||
        (a->realm!=p->materialRealm && a->realm!=p->spectralRealm) ||
        (a->realm==p->spectralRealm?a->sourceForm!=p->spectralSourceForm:!a->sourceForm) ||
        a->nativeOwned || !a->acquired || !a->hostCanStrike || !a->targetCanReceive || !a->sceneClear) return false;
    *out=(C2ContactKey){.epoch=a->epoch,.marker=a->marker,.sourceGeneration=a->sourceGeneration,
        .playerGeneration=a->playerGeneration,.targetGeneration=a->targetGeneration};
    return true;
}

static inline bool c2SphereProjection(const C2VisibleSegment *blade,const C2NativeSphere *weapon,
    const C2NativeSphere *target,int16_t center[3]) {
    const Sheet_c2ProjectedContact *p=&sheet_c2ProjectedContact_one_grounded_contact;
    if (!blade || !weapon || !target || !center || weapon->radius!=p->nativeRadius ||
        !target->radius || target->radius>INT16_MAX) return false;
    double direction[3], length=0, onto=0;
    for (unsigned i=0;i<3;++i) {
        if (!isfinite(blade->palm[i]) || !isfinite(blade->tip[i]) ||
            blade->palm[i]<INT16_MIN || blade->palm[i]>INT16_MAX ||
            blade->tip[i]<INT16_MIN || blade->tip[i]>INT16_MAX) return false;
        direction[i]=(double)blade->tip[i]-blade->palm[i];
        length+=direction[i]*direction[i];
        onto+=direction[i]*(target->center[i]-blade->palm[i]);
    }
    if (length<1) return false;
    const double fraction=fmax(0,fmin(1,onto/length));
    const int64_t radius=(int64_t)weapon->radius+target->radius;
    int64_t squared=0;
    int16_t candidate[3];
    for (unsigned i=0;i<3;++i) {
        const long at=lround(blade->palm[i]+direction[i]*fraction);
        const int64_t delta=at-target->center[i];
        squared+=delta*delta;
        candidate[i]=(int16_t)at;
    }
    // SR1 rejects a zero separation before computing the contact normal.
    // Keep that outcome under native control rather than inventing a normal.
    if (!squared || squared>=radius*radius) return false;
    memcpy(center,candidate,sizeof(candidate));
    return true;
}

// Geometry-only prefix of the native pair gate. Caller still needs the same
// root owner, runtime flags, model matrices and actual native pair visit.
static inline bool c2WithinNativePairRadius(const int16_t a[3],const int16_t b[3],
    int16_t radiusA,int16_t radiusB) {
    if (!a || !b || radiusA<=0 || radiusB<=0) return false;
    int64_t squared=0;
    for (unsigned i=0;i<3;++i) {
        const int32_t delta=(int32_t)a[i]-b[i];
        const int32_t shifted=delta/2-(delta%2<0);
        squared+=(int64_t)shifted*shifted;
    }
    const int32_t radius=((int32_t)radiusA+radiusB)/2;
    return squared<(int64_t)radius*radius;
}

// Input is a local copy of the native matrix. Preserve its axes and fix only
// the integer translation so the checked fixed-point center lands at desired.
static inline bool c2RecenterSphere(const unsigned char matrix[32],const int16_t current[3],
    const int16_t desired[3],unsigned char out[32]) {
    int32_t translation[3];
    memcpy(translation,matrix+20,sizeof(translation));
    for (unsigned i=0;i<3;++i) {
        const int64_t next=(int64_t)translation[i]+desired[i]-current[i];
        if (next<INT32_MIN || next>INT32_MAX) return false;
        translation[i]=(int32_t)next;
    }
    memcpy(out,matrix,32);
    memcpy(out+20,translation,sizeof(translation));
    return true;
}

// The first grounded transaction uses one target slot. A future marker can
// start another transaction. A possibly issued outcome is never sent twice.
typedef struct { C2ContactKey key; bool used; } C2GroundTransaction;
static inline bool c2ReserveGround(C2GroundTransaction *state,C2ContactKey key) {
    if (!state || !key.epoch || !key.marker || !key.sourceGeneration ||
        !key.playerGeneration || !key.targetGeneration) return false;
    if (state->used && (key.epoch<state->key.epoch ||
        (key.epoch==state->key.epoch && (key.marker<=state->key.marker ||
            key.sourceGeneration<state->key.sourceGeneration)))) return false;
    state->key=key;
    state->used=true;
    return true;
}
