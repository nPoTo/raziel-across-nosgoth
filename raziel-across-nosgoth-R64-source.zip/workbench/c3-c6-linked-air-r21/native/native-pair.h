// SPDX-License-Identifier: GPL-3.0-or-later
#pragma once
#include <stddef.h>
#include "contact-projection.h"

// Data-only seam used inside SR1's original sphere transform. The destination
// is the engine's current vector, never a model, palette or instance field.
typedef struct {
    C2ContactKey key;
    uintptr_t primitiveCenter;
    uint32_t currentSite, previousSite;
    int16_t center[3];
    bool ready;
} C2NativePairPlan;

typedef struct {
    uint64_t hostEpoch,sourceEpoch,marker,sourceGeneration,tick,sourceTick;
    uintptr_t actor,model,blade;
    uint32_t generation,form,realm;
    int32_t stream;
} C2DrawIdentity;

static inline bool c2ConsecutiveStrikeDraw(const C2DrawIdentity *older,const C2DrawIdentity *newer,
    uint64_t limit) {
    return older->marker && older->hostEpoch==newer->hostEpoch &&
        older->sourceEpoch==newer->sourceEpoch && older->marker==newer->marker &&
        older->sourceGeneration==newer->sourceGeneration && older->actor==newer->actor &&
        older->model==newer->model && older->blade==newer->blade &&
        older->generation==newer->generation && older->form==newer->form &&
        older->realm==newer->realm && older->stream==newer->stream &&
        newer->sourceTick>older->sourceTick && newer->sourceTick-older->sourceTick<=limit &&
        newer->tick>=older->tick && newer->tick-older->tick<=limit;
}

// Prefer a current overlap. Intermediate samples do not enlarge either
// sphere, and an earlier sample cannot authorize a different native swing.
static inline unsigned c2BladeProjection(const C2VisibleSegment *current,const C2VisibleSegment *older,
    const C2NativeSphere *weapon,const C2NativeSphere *target,C2VisibleSegment *at,int16_t center[3]) {
    if (c2SphereProjection(current,weapon,target,center)) {
        *at=*current;
        return 1;
    }
    if (!older) return 0;
    double alignment=0;
    for (unsigned i=0;i<3;++i)
        alignment+=((double)current->tip[i]-current->palm[i])*
            ((double)older->tip[i]-older->palm[i]);
    if (!(alignment>0)) return 0;
    for (unsigned step=1;step<=4;++step) {
        const float back=step*.25f;
        C2VisibleSegment blended;
        for (unsigned i=0;i<3;++i) {
            blended.palm[i]=current->palm[i]+back*(older->palm[i]-current->palm[i]);
            blended.tip[i]=current->tip[i]+back*(older->tip[i]-current->tip[i]);
        }
        if (c2SphereProjection(&blended,weapon,target,center)) {
            *at=blended;
            return 1+step;
        }
    }
    return 0;
}

// The exact native branch requires byte 0 bit 0 on the first primitive and
// bits 0 plus 2 on the second. Byte 1 has the sphere lane and attacker masks.
static inline unsigned c2SphereEntryMask(bool first) { return first?1u:5u; }

static inline bool c2SphereEntryUsable(const unsigned char entry[16],bool blade,bool first) {
    if (!entry || entry[2]!=1 || !(entry[1]&0x20) || (first && !(entry[1]&4))) return false;
    return blade ? entry[3]==0 && !(entry[0]&1) :
        (entry[0]&c2SphereEntryMask(first))==c2SphereEntryMask(first);
}

static inline bool c2PrimaryBladeSphere(const unsigned char sphere[16]) {
    uint16_t radius=0;
    memcpy(&radius,sphere+14,sizeof(radius));
    return sphere[4]==9 && radius==sheet_c2ProjectedContact_one_grounded_contact.nativeRadius;
}

typedef struct {
    uintptr_t actor,target;
    uint16_t distance,duration;
    uint32_t power;
} C2NativeHit;
_Static_assert(sizeof(C2NativeHit)==24 && offsetof(C2NativeHit,power)==20,"SR1 monster hit data");

static inline bool c2ShouldForwardHit(bool owned,bool committed,bool current,uintptr_t caller,
    uintptr_t recipient,uint32_t message,const C2NativeHit *hit,uintptr_t player,uintptr_t target) {
    return owned && !committed && current && caller==0xffa26 && message==0x100001f && hit &&
        player && recipient==player && target && target!=player && hit->actor==player &&
        hit->target==target && hit->power==4096;
}

// Carry a rendered segment into the next ordinary simulation step. A load,
// instance change or large displacement must never acquire the old segment.
static inline bool c2RebaseSegment(const C2VisibleSegment *visible,const int16_t drawn[3],
    const int16_t current[3],unsigned maximum,C2VisibleSegment *out) {
    if (!visible || !drawn || !current || !out || !maximum) return false;
    C2VisibleSegment moved=*visible;
    int64_t distanceSquared=0;
    for (unsigned i=0;i<3;++i) {
        const int32_t delta=(int32_t)current[i]-drawn[i];
        distanceSquared+=(int64_t)delta*delta;
        moved.palm[i]+=(float)delta;
        moved.tip[i]+=(float)delta;
        if (!isfinite(moved.palm[i]) || !isfinite(moved.tip[i]) || moved.palm[i]<INT16_MIN ||
            moved.palm[i]>INT16_MAX || moved.tip[i]<INT16_MIN || moved.tip[i]>INT16_MAX) return false;
    }
    if ((uint64_t)distanceSquared>(uint64_t)maximum*maximum) return false;
    *out=moved;
    return true;
}

static inline bool c2BuildNativePair(C2NativePairPlan *plan,const C2ContactAuthority *authority,
    const C2VisibleSegment *segment,const C2NativeSphere *blade,const C2NativeSphere *target,
    uintptr_t nativeCenter,bool bladeFirst) {
    C2NativePairPlan candidate={0};
    if (!plan) return false;
    *plan=candidate;
    if (!nativeCenter || !c2ContactKey(authority,&candidate.key) ||
        !c2SphereProjection(segment,blade,target,candidate.center)) return false;
    candidate.primitiveCenter=nativeCenter;
    candidate.currentSite=bladeFirst?0x3066b:0x30780;
    candidate.previousSite=bladeFirst?0x306b8:0x307ce;
    candidate.ready=true;
    *plan=candidate;
    return true;
}

static inline bool c2NativePairCenter(const C2NativePairPlan *plan,uint32_t site,
    uintptr_t nativeCenter,int32_t result[3]) {
    if (!plan || !plan->ready || !result || plan->primitiveCenter!=nativeCenter ||
        (site!=plan->currentSite && site!=plan->previousSite)) return false;
    for (unsigned i=0;i<3;++i) result[i]=plan->center[i];
    return true;
}
