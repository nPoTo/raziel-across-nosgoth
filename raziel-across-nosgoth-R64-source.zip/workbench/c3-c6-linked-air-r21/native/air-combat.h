// SPDX-License-Identifier: GPL-3.0-or-later
#pragma once
#include <stddef.h>
#include <stdint.h>
#include <stdbool.h>
#include <math.h>
#include "air-combat-policy.h"

typedef enum { AIR_STRIKE_NONE, AIR_STRIKE_LIFT, AIR_STRIKE_REAVER } AirStrike;

static inline bool airMaterialEnemy(uint32_t realm,uint32_t monsterClass) {
    return realm==1 && (monsterClass&AIR_MATERIAL_MONSTER_MASK) &&
        !(monsterClass&AIR_PROTECTED_MONSTER_MASK);
}

static inline AirStrike airStrikeRoute(const uint32_t primary[3], const uint32_t secondary[3]) {
    const AirStrike action = primary[0] == AIR_LIFT_PRIMARY && secondary[0] == AIR_LIFT_SECONDARY ?
        AIR_STRIKE_LIFT : primary[0] == AIR_MELEE_PRIMARY && secondary[0] == AIR_MELEE_SECONDARY ?
        AIR_STRIKE_REAVER : AIR_STRIKE_NONE;
    for (unsigned i = 1; i < 3; ++i) {
        if (primary[i] != primary[0] || secondary[i] != secondary[0]) return AIR_STRIKE_NONE;
    }
    return action;
}

static inline AirStrike airStrikeClass(const uint32_t primary[3], const uint32_t secondary[3],
    uint32_t openAction, uint32_t poseAction) {
    const AirStrike route=airStrikeRoute(primary,secondary);
    if (route==AIR_STRIKE_LIFT && (openAction!=AIR_LIFT_ACTION_KIND || poseAction!=AIR_LIFT_ACTION_KIND))
        return AIR_STRIKE_NONE;
    return route;
}

typedef struct {
    uint64_t until, hitMarker;
} AirVictimHold;

static inline bool airFlightWindow(uint64_t launch,uint64_t now) {
    return now>=launch && now-launch<AIR_HOLD_FLIGHT_LIMIT_MS;
}

static inline int32_t airApexGravity(int32_t speed) {
    if (speed<=-AIR_APEX_VELOCITY_BAND || speed>=AIR_APEX_VELOCITY_BAND) return AIR_FLIGHT_GRAVITY;
    const int32_t width=AIR_APEX_VELOCITY_BAND;
    const int32_t x=speed<0?-speed:speed;
    const int32_t denominator=width*width*width;
    const int32_t ease=x*x*(3*width-2*x);
    return -AIR_APEX_MIN_GRAVITY-
        ((-AIR_FLIGHT_GRAVITY-AIR_APEX_MIN_GRAVITY)*ease+denominator/2)/denominator;
}

static inline bool airSlamContactsMatch(uint64_t armed,uint64_t victim,uint64_t player,uint64_t now) {
    if (!armed || victim<armed || player<armed || victim>now || player>now) return false;
    const uint64_t latest=victim>player?victim:player;
    const uint64_t earliest=victim<player?victim:player;
    return latest-armed<=AIR_SLAM_MAX_MS && latest-earliest<=AIR_SLAM_CONTACT_MS &&
        now-latest<=AIR_SLAM_CONTACT_MS;
}

static inline bool airSlamBounceReady(uint64_t impact,uint64_t spark,uint64_t now) {
    return impact && spark>=impact && now>=spark && now-impact<=AIR_SLAM_BOUNCE_MAX_MS;
}

typedef enum { AIR_RELIFT_NONE, AIR_RELIFT_UP, AIR_RELIFT_SIDE } AirRelift;

static inline AirRelift airReliftNext(unsigned prior,bool playerGrounded,int32_t victimVelocity) {
    if (!playerGrounded || victimVelocity>=0 || prior>=AIR_RELIFT_LIMIT) return AIR_RELIFT_NONE;
    return prior+1==AIR_RELIFT_LIMIT?AIR_RELIFT_SIDE:AIR_RELIFT_UP;
}

static inline int32_t airBoundedLiftSpeed(int allowance,int minimum) {
    if (allowance<=0) return 0;
    for (int speed=AIR_FLIGHT_VELOCITY;speed>=minimum;--speed) {
        int upward=0;
        for (int32_t v=speed;v>0;) {
            const int32_t gravity=airApexGravity(v);
            upward+=2*v+gravity;
            v+=gravity;
        }
        if (upward<=2*allowance) return speed;
    }
    return 0;
}

static inline int32_t airReliftSpeed(int rise) {
    return airBoundedLiftSpeed(AIR_LIFT_APEX_RISE-(rise>0?rise:0),AIR_APEX_VELOCITY_BAND);
}

static inline bool airReducedLift(int clearance,int *takeoff,int32_t *speed) {
    if (clearance<=3*AIR_LIFT_HEADROOM_MARGIN) return false;
    const int offset=clearance/3<AIR_TAKEOFF_CLEARANCE?clearance/3:AIR_TAKEOFF_CLEARANCE;
    const int32_t fitted=airBoundedLiftSpeed(clearance-offset-AIR_LIFT_HEADROOM_MARGIN,1);
    if (!fitted) return false;
    *takeoff=offset;
    *speed=fitted;
    return true;
}

static inline bool airVictimHoldHit(AirVictimHold *hold,uint64_t launch,uint64_t now,
    uint64_t marker,bool damageConfirmed) {
    if (!damageConfirmed || !marker || marker<=hold->hitMarker || !airFlightWindow(launch,now)) return false;
    hold->hitMarker=marker;
    const uint64_t until=now+AIR_HOLD_HIT_MS;
    if (until>hold->until) hold->until=until;
    return true;
}

static inline bool airVictimHeld(const AirVictimHold *hold,uint64_t launch,uint64_t now) {
    return airFlightWindow(launch,now) && now<hold->until;
}

static inline int32_t airHitHopStep(int height,int origin,uint64_t until,uint64_t now) {
    if (now>=until || height<origin || height-origin>=AIR_HIT_HOP_RISE) return 0;
    const int remaining=AIR_HIT_HOP_RISE-(height-origin);
    return remaining<AIR_HIT_HOP_SPEED?remaining:AIR_HIT_HOP_SPEED;
}

static inline bool airSlamReach(const int16_t actor[3],const int16_t target[3],
    int actorFloor,int victimFloor) {
    const int64_t dx=(int)actor[0]-target[0],dy=(int)actor[1]-target[1];
    const int dz=(int)actor[2]-target[2],floor=actorFloor-victimFloor;
    return dx*dx+dy*dy<=AIR_SLAM_MAX_RANGE*AIR_SLAM_MAX_RANGE &&
        dz>=-AIR_SLAM_MAX_HEIGHT_DELTA && dz<=AIR_SLAM_MAX_HEIGHT_DELTA &&
        floor>=-AIR_SLAM_MAX_GROUND_DELTA && floor<=AIR_SLAM_MAX_GROUND_DELTA &&
        actor[2]>actorFloor && target[2]>victimFloor;
}

static inline int32_t airSlamVelocity(int playerHeight,int victimHeight,int32_t playerSpeed) {
    const int32_t expected=playerHeight+playerSpeed;
    // Track remaining height rather than world Z. At the final step both
    // actors may use different floor elevations and the game's contact wins.
    const int32_t where=expected>0?expected:0;
    const int32_t distance=victimHeight-where;
    if (distance<=0 && playerHeight>0) return 0;
    if (distance>AIR_SLAM_MAX_SPEED) return -AIR_SLAM_MAX_SPEED;
    return distance>0?-distance:-1;
}

static inline bool airVictimDamageConfirmed(int16_t before,int16_t after,int nativeResult) {
    return (before>0 && after>=0 && after<before) || (before==0 && after==0 && nativeResult!=0);
}

static inline bool airDeferVictimReaction(uintptr_t site,uint32_t state,bool confirmed) {
    return confirmed && site==AIR_VICTIM_HIT_TRANSITION_RETURN && (state==8 || state==9);
}

typedef struct {
    uint64_t serial, tick, epoch, actor;
    uint32_t realm;
    float animationClock;
    uint32_t animationPosition;
} AirShotEvent;

static inline bool airCastOrigin(uintptr_t site) {
    return site == AIR_CAST_RETURN || site == AIR_REPEAT_CAST_RETURN;
}

static inline bool airShotOrigin(uintptr_t castSite, uintptr_t postSite, uint32_t message) {
    return airCastOrigin(castSite) && postSite == AIR_PROJECTILE_RETURN && message == AIR_PROJECTILE_MESSAGE;
}

static inline bool airShotFromReleaseCue(uintptr_t site, int result, uint64_t before, uint64_t after) {
    return site==AIR_CAST_RETURN && result==0 && before==after;
}

static inline bool airShotFresh(const AirShotEvent *event, uint64_t epoch, uint64_t actor,
    uint32_t realm, uint64_t tick, unsigned limit) {
    return event->serial && event->epoch == epoch && event->actor == actor && event->realm == realm &&
        event->tick >= epoch && tick >= event->tick && tick - event->tick <= limit;
}

static inline bool airShotTake(const AirShotEvent *event, AirShotEvent *last) {
    if (last->epoch == event->epoch && last->actor == event->actor && last->serial >= event->serial) return false;
    *last = *event;
    return true;
}

static inline bool airLocalPressFresh(uint64_t tick,uint64_t now) {
    return tick && now>=tick && now-tick<=AIR_AIR_PRESS_MS;
}

static inline int32_t airLocalHoldTime(int32_t time,int32_t submitted,uint64_t tick,uint64_t now) {
    if (!tick || now<tick || now-tick>=AIR_AIR_HOLD_MS || time<=0 || time>8192 || submitted<=0) return submitted;
    const int32_t slowed=time*AIR_AIR_HOLD_SCALAR/4096;
    const int32_t bounded=slowed>0?slowed:1;
    return bounded<submitted?bounded:submitted;
}

static inline bool airForceInCone(uint16_t yaw,uint16_t bearing) {
    const unsigned turn=((unsigned)bearing-yaw)&4095u;
    return turn<=AIR_FORCE_HALF_CONE || turn>=4096u-AIR_FORCE_HALF_CONE;
}

static inline bool airForceClose(const int16_t origin[3],const int16_t target[3],bool airHeight) {
    const int64_t dx=(int64_t)target[0]-origin[0],dy=(int64_t)target[1]-origin[1];
    const int height=(int)target[2]-origin[2];
    const int limit=airHeight?AIR_FORCE_CLOSE_FLIGHT_HEIGHT:AIR_FORCE_CLOSE_HEIGHT;
    return dx*dx+dy*dy<=(int64_t)AIR_FORCE_CLOSE_RADIUS*AIR_FORCE_CLOSE_RADIUS &&
        height>=-limit && height<=limit;
}

static inline bool airForceThrowDirection(int32_t dx,int32_t dy,uint16_t yaw,int32_t out[2]) {
    const double length=hypot((double)dx,(double)dy);
    if (length>0.0) {
        out[0]=(int32_t)lround((double)dx*AIR_RELIFT_SIDE_SPEED/length);
        out[1]=(int32_t)lround((double)dy*AIR_RELIFT_SIDE_SPEED/length);
        return true;
    }
    if (yaw>4095u) return false;
    const unsigned forward=(yaw+4096u-AIR_FORCE_FORWARD_YAW_OFFSET)&4095u;
    const double angle=forward*(6.2831853071795864769/4096.0);
    out[0]=(int32_t)lround(cos(angle)*AIR_RELIFT_SIDE_SPEED);
    out[1]=(int32_t)lround(sin(angle)*AIR_RELIFT_SIDE_SPEED);
    return true;
}

typedef enum { AIR_FORCE_CONTACT_WAIT, AIR_FORCE_CONTACT_RUN, AIR_FORCE_CONTACT_FINISH } AirForceContactStep;

static inline AirForceContactStep airForceContactStep(uint64_t birth,uint64_t now,bool nativeHit,bool transformsReady) {
    if (!birth || now<birth || now-birth>AIR_FORCE_CLOSE_WAIT_MS || nativeHit) return AIR_FORCE_CONTACT_FINISH;
    if (now==birth || !transformsReady) return AIR_FORCE_CONTACT_WAIT;
    return AIR_FORCE_CONTACT_RUN;
}

typedef struct {
    unsigned char unused[10];
    uint8_t ownType,otherType;
    uint32_t padding;
    uintptr_t ownPrimitive,otherPrimitive,projectile,target;
    unsigned char separationPadding[16];
    int16_t separation[4];
} AirForceCollision;
_Static_assert(offsetof(AirForceCollision,ownPrimitive)==0x10 &&
    offsetof(AirForceCollision,target)==0x28 && offsetof(AirForceCollision,separation)==0x40 &&
    sizeof(AirForceCollision)==0x48,"SR1 sphere contact layout");

typedef enum { AIR_VICTIM_NONE, AIR_VICTIM_VERTICAL, AIR_VICTIM_FLINCH } AirVictimReaction;

static inline bool airRollLiftRestore(int16_t launch,int16_t current,int32_t expected,int32_t observed) {
    const int displacement=(int)current-launch;
    return observed==0 && expected>0 && expected<=AIR_FLIGHT_VELOCITY &&
        displacement>=0 && displacement<=AIR_ROLL_LAUNCH_RESTORE_TOLERANCE;
}

static inline AirVictimReaction airVictimReaction(AirStrike strike, uint32_t before, uint32_t after) {
    // Native hit reactions (4, 8) and stun (9) are observed Ronin outcomes.
    if (strike == AIR_STRIKE_LIFT && before != AIR_FLIGHT_STATE && (after == 4 || after == 8 || after == 9))
        return AIR_VICTIM_VERTICAL;
    if (strike == AIR_STRIKE_REAVER && before == AIR_FLIGHT_STATE && after == AIR_FLIGHT_STATE)
        return AIR_VICTIM_FLINCH;
    return AIR_VICTIM_NONE;
}

static inline bool airTakeoffHeights(int16_t ground,int16_t center,uint16_t radius,
    int16_t *launch,int16_t *top,int16_t *ceiling) {
    const int raised = (int)ground + AIR_TAKEOFF_CLEARANCE;
    const int head = (int)center + radius;
    const int clear = head + AIR_LIFT_APEX_RISE + AIR_LIFT_CLEARANCE_RESERVE;
    if (!radius || raised>INT16_MAX || head<ground || clear>INT16_MAX) return false;
    *launch=(int16_t)raised;
    *top=(int16_t)head;
    *ceiling=(int16_t)clear;
    return true;
}
