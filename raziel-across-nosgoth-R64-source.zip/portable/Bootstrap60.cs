// SPDX-License-Identifier: GPL-3.0-or-later
using System;using System.IO;using System.Diagnostics;using System.Drawing;using System.Text;using System.Runtime.InteropServices;using System.Threading;using System.Windows.Forms;using System.Web.Script.Serialization;
internal static class Bootstrap60 {
 [DllImport("user32.dll")]static extern short GetAsyncKeyState(int k);[DllImport("user32.dll")]static extern IntPtr GetForegroundWindow();[DllImport("user32.dll")]static extern uint GetWindowThreadProcessId(IntPtr h,out uint pid);
 static string root,data;static Process game,provider;static NotifyIcon tray;static Form guide;static bool f7,lastGuide,waitingSelection;static System.Windows.Forms.Timer timer;static string donor="",lastError="";
 [STAThread]static int Main(string[] args){
  try{
   if(args.Length==1&&args[0]=="--check"){if(!PortableCore60.Within(Path.GetTempPath(),Path.Combine(Path.GetTempPath(),"safe","file")))return 2;Console.WriteLine("R64 bootstrap: local runtime, Unicode paths and native .NET dependencies ready.");return 0;}
   int pid=0;for(int i=0;i+1<args.Length;i+=2){if(args[i]=="--pid")pid=Int32.Parse(args[i+1]);if(args[i]=="--root")root=Path.GetFullPath(args[i+1]);if(args[i]=="--data")data=Path.GetFullPath(args[i+1]);}
   if(pid<=0||String.IsNullOrEmpty(root)||String.IsNullOrEmpty(data))return 2;
   game=Process.GetProcessById(pid);if(!String.Equals(game.ProcessName,"SRX",StringComparison.OrdinalIgnoreCase))return 2;
   bool created;using(var mutex=new Mutex(true,"Local\\RazielR60Bootstrap-"+pid,out created)){if(!created)return 0;
    Directory.CreateDirectory(data);Application.EnableVisualStyles();Application.SetCompatibleTextRenderingDefault(false);
    tray=new NotifyIcon{Icon=SystemIcons.Application,Text="Raziel R64: loading resources",Visible=true};var menu=new ContextMenuStrip();menu.Items.Add("Field Guide (F7)",null,(s,e)=>ToggleGuide());menu.Items.Add("Toggle mod / F10",null,(s,e)=>Toggle(pid));menu.Items.Add("Open logs",null,(s,e)=>Process.Start("explorer.exe",PortableCore60.Quote(data)));tray.ContextMenuStrip=menu;tray.DoubleClick+=(s,e)=>ToggleGuide();
    donor=PortableCore60.ReadDonor();if(!PortableCore60.Donor(donor))donor=PortableCore60.Detect("Legacy of Kain Defiance Remastered");
    timer=new System.Windows.Forms.Timer{Interval=75};timer.Tick+=(s,e)=>Tick(pid);timer.Start();Application.Run();
    timer.Dispose();if(guide!=null)guide.Dispose();tray.Visible=false;tray.Dispose();menu.Dispose();if(provider!=null&&!provider.HasExited)provider.Kill();mutex.ReleaseMutex();
   }return 0;
  }catch(Exception ex){try{if(!String.IsNullOrEmpty(data))File.AppendAllText(Path.Combine(data,"bootstrap-errors.log"),ex+Environment.NewLine);}catch{}MessageBox.Show(ex.Message,"Raziel R64",MessageBoxButtons.OK,MessageBoxIcon.Error);return 1;}
 }
 static void Toggle(int pid){try{using(var ev=EventWaitHandle.OpenExisting("Local\\RazielR60Toggle-"+pid))ev.Set();}catch{}}
 static bool Sr1Loaded(){try{foreach(ProcessModule m in game.Modules)if(String.Equals(m.ModuleName,"sr1.dll",StringComparison.OrdinalIgnoreCase))return true;}catch{}return false;}
 static void Tick(int pid){
  if(game.HasExited){Application.ExitThread();return;}
  uint foreground;GetWindowThreadProcessId(GetForegroundWindow(),out foreground);bool down=(GetAsyncKeyState(0x76)&0x8000)!=0;
  if(down&&!f7&&(foreground==(uint)pid||foreground==(uint)Process.GetCurrentProcess().Id))ToggleGuide();f7=down;
  try{string status=File.ReadAllText(Path.Combine(data,"status.txt"),Encoding.UTF8);tray.Text=("Raziel R64: "+status).Substring(0,Math.Min(63,12+status.Length));if(guide!=null&&guide.Visible)guide.Text="Raziel R64 — "+status;}catch{}
  if(provider==null&&!waitingSelection&&Sr1Loaded()){
   if(!PortableCore60.Donor(donor)){
    timer.Stop();using(var dialog=new FolderBrowserDialog{Description="Select your installed Defiance Remastered folder (contains defiance.exe and bigfile.x64.dat)."}){if(dialog.ShowDialog()==DialogResult.OK)donor=dialog.SelectedPath;}
    timer.Start();if(!PortableCore60.Donor(donor)){File.WriteAllText(Path.Combine(data,"status.txt"),"Defiance folder required — select it from the guide");waitingSelection=true;return;}
   }
   PortableCore60.SaveDonor(donor);string runtime=Path.Combine(root,"runtime"),node=Path.Combine(root,"node.exe"),host=Directory.GetParent(root).FullName;
   var start=new ProcessStartInfo(node,"--import "+PortableCore60.Quote(new Uri(Path.Combine(runtime,"portable-config60.mjs")).AbsoluteUri)+" "+PortableCore60.Quote(Path.Combine(runtime,"workbench","sr1-local-controller-test","serve-ground-poses.mjs"))+" "+pid+" --combat-r60"){UseShellExecute=false,CreateNoWindow=true,WorkingDirectory=runtime,RedirectStandardError=true,RedirectStandardOutput=true};
   start.EnvironmentVariables["RAZIEL_GAME_PATHS"]=new JavaScriptSerializer().Serialize(new{host=host,donor=donor});
   provider=new Process{StartInfo=start};provider.ErrorDataReceived+=(s,e)=>{if(e.Data!=null){lastError=e.Data;File.AppendAllText(Path.Combine(data,"provider.err"),e.Data+Environment.NewLine);}};provider.Start();provider.BeginErrorReadLine();provider.BeginOutputReadLine();File.WriteAllText(Path.Combine(data,"provider.json"),new JavaScriptSerializer().Serialize(new{pid=provider.Id,game=pid}));
  }
  if(provider!=null&&provider.HasExited&&provider.ExitCode!=0){File.WriteAllText(Path.Combine(data,"status.txt"),"Failed: resource provider — see provider.err");if(!lastGuide){lastGuide=true;MessageBox.Show("R64 could not load the installed game resources. Check the selected Defiance Remastered folder and provider.err. Restart SR1 after correcting the path.\n\n"+lastError,"Raziel R64",MessageBoxButtons.OK,MessageBoxIcon.Error);}}
 }
 static void ToggleGuide(){
  if(guide!=null&&!guide.IsDisposed){if(guide.Visible){guide.Hide();return;}guide.Show();guide.Activate();return;}
  guide=new Form{Text="Raziel R64 — Field Guide",Width=820,Height=700,StartPosition=FormStartPosition.CenterScreen,BackColor=Color.FromArgb(16,28,41)};
  var text=new RichTextBox{Dock=DockStyle.Fill,ReadOnly=true,BackColor=guide.BackColor,ForeColor=Color.White,Font=new Font("Segoe UI",11),BorderStyle=BorderStyle.None,Text=File.ReadAllText(Path.Combine(root,"GUIDE.txt"),Encoding.UTF8)};guide.Controls.Add(text);
  var choose=new Button{Text="Choose Defiance folder",Dock=DockStyle.Bottom,Height=36};choose.Click+=(s,e)=>{using(var d=new FolderBrowserDialog{Description="Defiance Remastered folder",SelectedPath=donor})if(d.ShowDialog()==DialogResult.OK&&PortableCore60.Donor(d.SelectedPath)){donor=d.SelectedPath;waitingSelection=false;PortableCore60.SaveDonor(donor);MessageBox.Show("Folder saved. Restart SR1 if resource loading already failed.");}};guide.Controls.Add(choose);guide.FormClosing+=(s,e)=>{e.Cancel=true;guide.Hide();};guide.Show();
 }
}

