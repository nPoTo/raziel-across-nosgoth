// SPDX-License-Identifier: GPL-3.0-or-later
using System;using System.IO;using System.Collections.Generic;using System.Diagnostics;using System.Security.Cryptography;using System.Text.RegularExpressions;using System.Web.Script.Serialization;using Microsoft.Win32;
internal static class PortableCore60 {
 internal static string DataRoot {get{return Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),"RazielAcrossNosgoth","R60");}}
 internal static string Hash(string file){using(var s=File.OpenRead(file))using(var h=SHA256.Create())return BitConverter.ToString(h.ComputeHash(s)).Replace("-","").ToLowerInvariant();}
 internal static bool Host(string p){try{return File.Exists(Path.Combine(p,"SRX.exe"))&&File.Exists(Path.Combine(p,"1","BIGFILE.DAT"))&&Hash(Path.Combine(p,"SRX.exe"))=="0fb3aef0530ebf0510191f934dc371b69b43574331d3623eda694b72f060db93"&&Hash(Path.Combine(p,"1","sr1.dll"))=="c006dea45509cdc3fbfab3a4230b47869c306ecdd7df8b4fd2499fd3654a2205";}catch{return false;}}
 internal static bool Donor(string p){return !String.IsNullOrEmpty(p)&&File.Exists(Path.Combine(p,"bigfile.x64.dat"))&&File.Exists(Path.Combine(p,"defiance.exe"));}
 internal static string Quote(string s){return "\""+s.TrimEnd('\\')+"\"";}
 internal static string Detect(string name){
  var roots=new HashSet<string>(StringComparer.OrdinalIgnoreCase);string steam=Convert.ToString(Registry.GetValue(@"HKEY_CURRENT_USER\Software\Valve\Steam","SteamPath",null));
  if(!String.IsNullOrEmpty(steam))roots.Add(steam);roots.Add(Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ProgramFilesX86),"Steam"));
  foreach(string root in new List<string>(roots)){string vdf=Path.Combine(root,"steamapps","libraryfolders.vdf");if(File.Exists(vdf))foreach(Match m in Regex.Matches(File.ReadAllText(vdf),"\"path\"\\s*\"([^\"]+)\""))roots.Add(m.Groups[1].Value.Replace("\\\\","\\"));}
  foreach(string root in roots){string p=Path.Combine(root,"steamapps","common",name);if(Directory.Exists(p))return p;}return "";
 }
 internal static string ReadDonor(){try{var d=new JavaScriptSerializer().Deserialize<Dictionary<string,string>>(File.ReadAllText(Path.Combine(DataRoot,"games.json")));return d.ContainsKey("donor")?d["donor"]:"";}catch{return "";}}
 internal static void SaveDonor(string donor){Directory.CreateDirectory(DataRoot);File.WriteAllText(Path.Combine(DataRoot,"games.json"),new JavaScriptSerializer().Serialize(new{donor=donor}));}
 internal static bool Within(string root,string path){string full=Path.GetFullPath(root).TrimEnd(Path.DirectorySeparatorChar)+Path.DirectorySeparatorChar;return Path.GetFullPath(path).StartsWith(full,StringComparison.OrdinalIgnoreCase);}
 internal static bool GamesClosed(){return Process.GetProcessesByName("SRX").Length==0&&Process.GetProcessesByName("Defiance").Length==0;}
}
