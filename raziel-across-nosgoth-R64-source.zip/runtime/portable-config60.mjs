// SPDX-License-Identifier: GPL-3.0-or-later
// Redirect only this runtime's game-directory configuration. Resources stay in the
// installed games, while runtime sources/configuration may be read-only.
import fs from'node:fs';import path from'node:path';import{fileURLToPath}from'node:url';import{syncBuiltinESMExports}from'node:module';
const gameConfig=path.join(import.meta.dirname,'config/games.json');
const selected=JSON.parse(process.env.RAZIEL_GAME_PATHS||'null');
if(!selected?.host||!selected?.donor)throw Error('Missing selected installed game folders');
const config=JSON.stringify({games:[{id:'soul-reaver',directory:selected.host},{id:'defiance',directory:selected.donor}]});
const original=fs.readFileSync;
let inspection;
function localInspection(){if(inspection)return inspection;const file=path.join(selected.donor,'defiance.exe'),b=original(file),pe=b.readUInt32LE(0x3c);if(b.toString('ascii',pe,pe+4)!=='PE\0\0')throw Error('Invalid installed Defiance executable');const count=b.readUInt16LE(pe+6),start=pe+24+b.readUInt16LE(pe+20),sections=[];if(count>96||start+count*40>b.length)throw Error('Invalid PE sections');for(let i=0;i<count;i++){const p=start+i*40;sections.push({name:b.toString('ascii',p,p+8).replace(/\0.*$/,''),virtualSize:b.readUInt32LE(p+8),rva:b.readUInt32LE(p+12),rawSize:b.readUInt32LE(p+16),rawOffset:b.readUInt32LE(p+20)});}return inspection=JSON.stringify({modules:[{game:'defiance',file,sections}]});}
fs.readFileSync=function(file,options){let requested;try{requested=path.resolve(file instanceof URL?fileURLToPath(file):file).toLowerCase();}catch{}let value;if(requested===gameConfig.toLowerCase())value=config;
 if(requested===path.join(import.meta.dirname,'reports/local-inspection.json').toLowerCase())value=localInspection();
 if(requested===path.join(import.meta.dirname,'reports/discovery/reaver-menu-first-hud-1793254488160.json').toLowerCase())value=original(path.join(import.meta.dirname,'config/r60-hud-layout.json'),'utf8');
 if(value!==undefined){const encoding=typeof options==='string'?options:options?.encoding;return encoding?value:Buffer.from(value);}return original.call(this,file,options);};
syncBuiltinESMExports();
