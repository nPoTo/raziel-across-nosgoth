// SPDX-License-Identifier: GPL-3.0-or-later
// Selected installed archive entry -> RAM-only topology. No asset serializer.
import fs from 'node:fs';import path from 'node:path';import crypto from 'node:crypto';
const hash=b=>crypto.createHash('sha256').update(b).digest('hex');
export function decodeSr1RigEntry(b,profile){
 const need=(at,n)=>{if(!Number.isSafeInteger(at)||!Number.isSafeInteger(n)||at<0||n<0||at>b.length-n)throw Error('Offline rig bounds');return at;};
 if(!Buffer.isBuffer(b)||b.length!==profile.entryBytes||hash(b)!==profile.entrySha256||profile.relocationAlignment!==2048||profile.segmentCount!==66||profile.modelCount!==1||profile.segmentBytes!==24||profile.parentOffset!==18)throw Error('Offline rig identity/layout');
 const count=b.readUInt32LE(need(0,4));if(!count||count>100000)throw Error('Offline relocation count');
 need(4,count*4);const base=Math.ceil((4+count*4)/2048)*2048;need(base,76);
 const payloadBytes=b.length-base,relocations=new Set();
 for(let i=0;i<count;i++){const at=b.readUInt32LE(4+i*4);if(at>payloadBytes-4||relocations.has(at))throw Error('Offline relocation bounds/duplicate');relocations.add(at);}
 const u=(at)=>b.readUInt32LE(need(base+at,4)),pointer=(at,n)=>{if(!relocations.has(at))throw Error('Offline pointer absent from relocation table');const p=u(at);need(base+p,n);if(!p)throw Error('Offline null pointer');return p;};
 const name=pointer(profile.objectNameOffset,9);if(b.toString('ascii',base+name,base+name+9)!=='raziel__\0')throw Error('Offline object identity');
 if(b.readUInt16LE(base+8)!==1)throw Error('Offline model count');
 const models=pointer(profile.objectModelsOffset,4),model=pointer(models,56),n=u(model+profile.modelCountOffset);if(n!==66)throw Error('Offline segment count');
 const segments=pointer(model+profile.modelSegmentsOffset,n*24),parents=[],local=[];
 for(let i=0;i<n;i++){const at=base+segments+i*24,p=b.readInt16LE(at+18);if(p< -1||p>=n||p===i)throw Error('Offline parent index');parents.push(p);local.push([12,14,16].map(o=>b.readInt16LE(at+o)));}
 const positions=[],active=new Set(),at=i=>{if(positions[i])return positions[i];if(active.has(i))throw Error('Offline hierarchy cycle');active.add(i);positions[i]=local[i].map((v,k)=>v+(parents[i]<0?0:at(parents[i])[k]));active.delete(i);return positions[i];};parents.forEach((_,i)=>at(i));
 if(parents.filter(p=>p<0).length!==1||hash(JSON.stringify(parents))!==profile.topologySha256)throw Error('Offline topology differs from live proof');
 return {parents,positions,entrySha256:profile.entrySha256,topologySha256:profile.topologySha256};
}
export function readInstalledSr1Rig(folder,profile,mesh){
 if(!path.isAbsolute(folder)||profile.archive!=='1/BIGFILE.DAT')throw Error('Installed SR1 archive path required');
 const fd=fs.openSync(path.join(folder,profile.archive),'r');
 try{
  const size=fs.fstatSync(fd).size,read=(at,n)=>{if(!Number.isSafeInteger(n)||n<0||at<0||at>size-n)throw Error('Archive read bounds');const out=Buffer.alloc(n);let done=0;while(done<n){const got=fs.readSync(fd,out,done,n-done,at+done);if(!got)throw Error('Archive truncated');done+=got;}return out;};
  const count=read(0,4).readUInt32LE();if(!count||count>100000)throw Error('Archive index count');const index=read(4,count*16),matches=[];
  for(let i=0;i<count;i++)if(index.readUInt32LE(i*16)===profile.indexHash)matches.push(i);
  if(matches.length!==1)throw Error('Archive selected-entry ambiguity');const at=matches[0]*16,n=index.readUInt32LE(at+4),offset=index.readUInt32LE(at+8);
  if(n!==profile.entryBytes||n>4*1024*1024||offset<4+count*16||offset%2048)throw Error('Archive selected-entry identity');
  const rig=decodeSr1RigEntry(read(offset,n),profile);let error=0;
  for(let i=0;i<66;i++)for(let k=0;k<3;k++)error=Math.max(error,Math.abs(rig.positions[i][k]+mesh.bindOffsets[i][k]));
  if(error>.001)throw Error('Offline rig differs from current installed SRM bind');return {...rig,maxBindDifference:error};
 }finally{fs.closeSync(fd);}
}
