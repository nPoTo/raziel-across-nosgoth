// SPDX-License-Identifier: GPL-3.0-or-later
// Full66 target coverage, strict source rotations, no native writes or clips.
import {quatIdentity as I,quatMultiply as mul,quatInverse as inv,quatBlend,rigidFromPackedRender,localFromWorld,validateRig,quatRotate,retargetControlledPose} from './retarget-pose.mjs';
import {skinSr1Pose} from './sr1-skin.mjs';
import {sr1FootVertices,alignSr1GroundSoles} from './sr1-ground-contact.mjs';
const indices=(s,n)=>{const r=s.split(',').map(Number);if(r.length<2||new Set(r).size!==r.length||r.some(i=>!Number.isInteger(i)||i<0||i>=n))throw Error('Invalid control chain');return r;};
const rig=(parents,positions)=>({parents,rest:positions.map((p,i)=>({position:p.map((v,k)=>v-(parents[i]<0?0:positions[parents[i]][k])),rotation:I()}))});
const arc=(ids,positions)=>{const d=[0];for(let i=1;i<ids.length;i++)d.push(d.at(-1)+Math.hypot(...positions[ids[i]].map((v,k)=>v-positions[ids[i-1]][k])));if(!Number.isFinite(d.at(-1))||d.at(-1)<1e-6)throw Error('Zero/nonfinite control arc');return d.map(v=>v/d.at(-1));};
const column=m=>{if(!Array.isArray(m)||m.length!==16||m.some(v=>!Number.isFinite(v))||Math.abs(m[3])+Math.abs(m[7])+Math.abs(m[11])+Math.abs(m[15]-1)>1e-5)throw Error('Invalid motion control matrix');return rigidFromPackedRender([m[0],m[4],m[8],m[1],m[5],m[9],m[2],m[6],m[10],0,m[12],m[13],m[14]]);};
export class MotionFrameRejected extends Error{}
export function compileSr1MotionControls({hostParents,hostBind,sourceParents,sourceBind,rows,chains,policy}){
 if(!policy||policy.hostBones!==66||policy.sourceBones!==85||policy.identityBasis!==true||policy.removePelvisHeading!==true||policy.sourcePelvis!==1||policy.flightNative!==true||policy.glideNative!==true)throw Error('Unsupported motion authority policy');
 if(hostParents.length!==66||hostBind.length!==66||sourceParents.length!==85||sourceBind.length!==85||rows.length!==66)throw Error('Full66/85 rig required');
 validateRig(rig(hostParents,hostBind));validateRig(rig(sourceParents,sourceBind));const groups=new Map();
 for(const c of chains){if(groups.has(c.id))throw Error('Duplicate chain group');const h=indices(c.targets,66),s=indices(c.sources,85);if(!c.virtualPath){for(const [ids,parents]of [[h,hostParents],[s,sourceParents]])for(let i=1;i<ids.length;i++)if(parents[ids[i]]!==ids[i-1])throw Error('Unproved nonvirtual chain topology');}groups.set(c.id,{h,s,H:arc(h,hostBind),S:arc(s,sourceBind)});}
 const seen=new Set(),controls=rows.map(r=>{
  if(!Number.isInteger(r.target)||r.target<0||r.target>=66||seen.has(r.target)||r.enabled!==false)throw Error('Control coverage/admission');seen.add(r.target);
  if(r.mode==='native_root'){if(r.target!==0||hostParents[0]!==-1||r.source!==-1)throw Error('Invalid native root');return {...r};}
  if(r.target===0)throw Error('Donor root mapping refused');
  if(r.mode==='native_local'){if(r.source!==-1||![2,3,22,25,26].includes(r.target))throw Error('Undeclared native residual');return {...r};}
  if(r.mode==='donor_rotation'){if(!Number.isInteger(r.source)||r.source<=0||r.source>=85)throw Error('Invalid source control');return {...r,a:r.source,b:r.source,t:0};}
  if(r.mode!=='arc_rotation'||r.source!==-1)throw Error('Unknown control mode');const g=groups.get(r.chain),i=g?.h.indexOf(r.target);if(!g||i<1)throw Error('Missing arc target');const f=g.H[i];let j=1;while(j<g.S.length-1&&g.S[j]<f)j++;const span=g.S[j]-g.S[j-1];if(span<=1e-8)throw Error('Degenerate source arc interval');return {...r,a:g.s[j-1],b:g.s[j],t:Math.min(1,Math.max(0,(f-g.S[j-1])/span))};
 }).sort((a,b)=>a.target-b.target);
 if(controls.some((c,i)=>c.target!==i)||controls.filter(c=>c.mode==='native_root').length!==1)throw Error('Incomplete target coverage');
 const needed=[...new Set(controls.flatMap(c=>c.a===undefined?[]:[c.a,c.b]))];return {controls,needed,parents:[...hostParents],hostBind:hostBind.map(v=>[...v]),sourceParents:[...sourceParents],policy:{...policy}};
}
export function sourceMotionControls(compiled,pose){
 if(!pose?.valid||pose.matrices?.length!==110||pose.baseHierarchyCandidate?.parents?.length!==85||pose.baseHierarchyCandidate.parents.some((p,i)=>p!==compiled.sourceParents[i]))throw Error('Source rig/pose identity changed');
 const read=m=>{try{return column(m);}catch(e){throw new MotionFrameRejected(e.message);}},root=read(pose.rootMatrix),inverse=inv(root.rotation),rotations=new Map();for(const i of compiled.needed)rotations.set(i,mul(inverse,read(pose.matrices[i]).rotation));
 // The native movement root does not contain all visual facing: recorded
 // pelvis1 can turn independently by nearly180deg. Remove its world-up twist
 // from the whole skeleton. Preserve swing/lean and limb-relative movement;
 // the target actor root remains SR1's only heading authority.
 const pelvis=rotations.get(compiled.policy.sourcePelvis);if(!pelvis)throw Error('Source pelvis heading control absent');const norm=Math.hypot(pelvis[2],pelvis[3]);if(norm<1e-6)throw new MotionFrameRejected('Source pelvis heading singular');
 const inverseHeading=[0,0,-pelvis[2]/norm,pelvis[3]/norm];for(const [i,q]of rotations)rotations.set(i,mul(inverseHeading,q));
 return compiled.controls.map(c=>c.a===undefined?null:quatBlend(rotations.get(c.a),rotations.get(c.b),c.t));
}
function hostMotionFrame(compiled,hostRender){
 if(!Array.isArray(hostRender)||hostRender.length!==66)throw Error('Incomplete native target frame');const world=hostRender.map(m=>rigidFromPackedRender(m)),root=world[0],native=localFromWorld(compiled.parents,world,root),inverse=inv(root.rotation),relative=world.map(t=>({position:quatRotate(inverse,t.position.map((v,k)=>v-root.position[k])),rotation:mul(inverse,t.rotation)}));
 return {root,native,relative};
}
export function captureSr1MotionReference(compiled,hostRender,donorPose){
 const host=hostMotionFrame(compiled,hostRender);return {target:host.native.map(t=>({position:[...t.position],rotation:[...t.rotation]})),source:sourceMotionControls(compiled,donorPose)};
}
export function nativeSr1MotionPositions(compiled,mesh,hostRender){return skinSr1Pose(mesh,hostMotionFrame(compiled,hostRender).relative);}
export function retargetSr1Motion({compiled,mesh,hostRender,donorPose,reference,groundPolicy,groundAllowed,experimental}){
 if(experimental!=='sr1-motion-ground66-reference-v1')throw Error('Explicit full66 reference preview required');
 if(groundAllowed!==true)return {allow:false,reason:'native_context',controlCount:66};
 if(!reference||reference.target?.length!==66||reference.source?.length!==66)throw Error('Explicit full66 reference preview required');
 const host=hostMotionFrame(compiled,hostRender);let current;try{current=sourceMotionControls(compiled,donorPose);}catch(e){if(e instanceof MotionFrameRejected)return {allow:false,hold:true,reason:'source_pose_incoherent',controlCount:66};throw e;}
 const target={parents:compiled.parents,rest:reference.target.map((t,i)=>({...t,position:compiled.controls[i].mode==='native_local'?[...host.native[i].position]:[...t.position]}))},controls=[];
 for(let i=0;i<66;i++)if(current[i]){if(!reference.source[i])throw Error('Incomplete source reference');controls.push({target:i,delta:mul(current[i],inv(reference.source[i]))});}
 let pose=retargetControlledPose({target,nativeLocal:host.native.map(t=>t.rotation),controls}),positions=skinSr1Pose(mesh,pose.world),nativePositions=skinSr1Pose(mesh,host.relative);
 const feet=sr1FootVertices(mesh,groundPolicy),up=quatRotate(inv(host.root.rotation),[0,0,1]),restWorld=compiled.hostBind.map(position=>({position,rotation:I()}));
 // All original weighted branches must descend from the single native pelvis.
 for(const b of mesh.palette){let at=b;while(at>=0&&at!==groundPolicy.pelvisBone)at=compiled.parents[at];if(at!==groundPolicy.pelvisBone)throw Error('Weighted branch outside presentation pelvis');}
 const ground=alignSr1GroundSoles({pose,positions,nativePositions,feet,up,restWorld,policy:groundPolicy,groundAllowed});
 if(ground.allow){pose=ground.pose;positions=skinSr1Pose(mesh,pose.world);}
 return {allow:ground.allow,reason:ground.reason,positions,pose,nativePositions,hostRoot:host.root,controlCount:66,donorControls:controls.length,groundCorrection:ground.correction};
}
