// SPDX-License-Identifier: GPL-3.0-or-later
import fs from 'node:fs';
import path from 'node:path';
const workspace=path.resolve(import.meta.dirname,'..');
export const evidenceKinds=['requirement','measured','policy','runtime'];
const object=v=>v!==null&&typeof v==='object'&&!Array.isArray(v);
const text=v=>typeof v==='string'&&v.trim().length>0;
export function migrateV1(document){
 if(document?.schemaVersion!==1)throw new Error('Expected schemaVersion 1');
 const result=structuredClone(document);result.schemaVersion=2;
 for(const table of Object.values(result.tables))for(const row of table.rows){
  row.cells=Object.fromEntries(Object.keys(table.columns).map(column=>[column,{status:'unreviewed',kind:'policy',evidence:row.evidence??'',migration:'Legacy row evidence requires explicit per-cell review'}]));
  delete row.checked;delete row.evidence;
 }
 return result;
}
export function checkV2(document){
 const errors=[],tables=document?.tables,ids=Object.create(null),symbols=new Set();
 if(document?.schemaVersion!==2||!object(tables))return ['Invalid sheet schema v2'];
 const validName=n=>typeof n==='string'&&/^[A-Za-z_]\w*$/.test(n);
 const validType=t=>['string','integer','boolean'].includes(t)||typeof t==='string'&&/^(ref|optional-ref|list-ref):[A-Za-z_]\w*$/.test(t)||object(t)&&Array.isArray(t.enum)&&t.enum.length>0&&t.enum.every(text)&&new Set(t.enum).size===t.enum.length;
 for(const [name,table] of Object.entries(tables)){
  if(!validName(name)||!object(table)||!object(table.columns)||!Array.isArray(table.rows)){errors.push(`${name}: invalid table`);continue;}
  ids[name]=new Set();
  if(table.columns.id!=='string')errors.push(`${name}.id: required string ID column`);
  for(const [column,type] of Object.entries(table.columns))if(!validName(column)||!validType(type))errors.push(`${name}.${column}: invalid column/type`);
  for(const [index,row] of table.rows.entries()){
   const label=`${name}[${index}]`;if(!object(row)||!object(row.values)||!object(row.cells)){errors.push(`${label}: missing values/cells`);continue;}
   if(!text(row.values.id))errors.push(`${label}.id: missing ID`);
   const symbol=name+'_'+String(row.values.id).replaceAll('-','_');
   if(!validName(symbol)||symbols.has(symbol))errors.push(`${label}.id: invalid/colliding generated identifier`);symbols.add(symbol);
   if(ids[name].has(row.values.id))errors.push(`${label}.id: duplicate ID ${row.values.id}`);ids[name].add(row.values.id);
   for(const key of [...Object.keys(row.values),...Object.keys(row.cells)])if(!(key in table.columns))errors.push(`${label}.${key}: undeclared cell`);
   for(const [column,type] of Object.entries(table.columns)){
    const loc=`${label}.${column}`,v=row.values[column],cell=row.cells[column];
    let ok=false;
    if(type==='string'||typeof type==='string'&&type.startsWith('ref:'))ok=text(v);
    else if(type==='integer')ok=Number.isSafeInteger(v);
    else if(type==='boolean')ok=typeof v==='boolean';
    else if(object(type))ok=Array.isArray(type.enum)&&type.enum.includes(v);
    else if(typeof type==='string'&&type.startsWith('list-ref:'))ok=Array.isArray(v)&&v.every(text)&&new Set(v).size===v.length;
    else if(typeof type==='string'&&type.startsWith('optional-ref:'))ok=object(v)&&((v.kind==='ref'&&text(v.id)&&Object.keys(v).every(k=>['kind','id'].includes(k)))||(v.kind==='unavailable'&&text(v.reason)&&Object.keys(v).every(k=>['kind','reason'].includes(k))));
    if(!ok)errors.push(`${loc}: missing/invalid typed value`);
    if(!object(cell)||cell.status!=='checked'||!evidenceKinds.includes(cell.kind)||!text(cell.evidence))errors.push(`${loc}: missing, unreviewed or invalid evidence`);
    else if((cell.kind==='measured'||cell.kind==='runtime')&&!text(cell.artifact))errors.push(`${loc}: measured/runtime evidence needs artifact`);
    else if(cell.kind==='runtime'&&(!text(cell.scenario)||!(/^[a-f0-9]{64}$/i.test(cell.buildSha256??''))))errors.push(`${loc}: runtime evidence needs scenario and build SHA256`);
    if(object(cell)&&text(cell.artifact)){
     const artifact=path.resolve(workspace,cell.artifact);
     if(!artifact.startsWith(workspace+path.sep)||!fs.existsSync(artifact)||!fs.statSync(artifact).isFile())errors.push(`${loc}: stale or invalid artifact reference`);
    }
   }
  }
 }
 for(const [name,table] of Object.entries(tables)){
  if(!object(table?.columns)||!Array.isArray(table.rows))continue;
  for(const [column,type] of Object.entries(table.columns)){
   if(typeof type!=='string'||!type.includes(':'))continue;
   const [kind,target]=type.split(':');if(!ids[target]){errors.push(`${name}.${column}: unknown reference table ${target}`);continue;}
   for(const [i,row] of table.rows.entries()){
    const value=row?.values?.[column],refs=kind==='list-ref'?Array.isArray(value)?value:[]:kind==='optional-ref'?value?.kind==='ref'?[value.id]:[]:[value];
    for(const ref of refs)if(!ids[target].has(ref))errors.push(`${name}[${i}].${column}: unresolved ${target} ${ref}`);
   }
  }
 }
 if(Array.isArray(tables.capabilities?.rows))for(const [i,row] of tables.capabilities.rows.entries()){
  const v=row?.values;if(!v)continue;
  if(v.availability==='unavailable'&&(v.enabled!==false||v.hook?.kind!=='unavailable'))errors.push(`capabilities[${i}]: unavailable must be disabled with typed reason`);
  if(v.enabled===true){
   const hook=Array.isArray(tables.hooks?.rows)?tables.hooks.rows.find(r=>r?.values?.id===v.hook?.id):null;
   const build=hook&&Array.isArray(tables.builds?.rows)?tables.builds.rows.find(r=>r?.values?.id===hook.values.buildRef):null;
   if(v.availability!=='available'||!hook||hook.values.verified!==true||row.cells?.hook?.kind!=='measured'||!['measured','runtime'].includes(hook.cells?.verified?.kind)||!build||build.values.verified!==true)errors.push(`capabilities[${i}]: enabled native capability needs measured verified hook/build`);
  }
 }
 if(tables.games?.columns?.configId&&Array.isArray(tables.games.rows)){
  const host=tables.games.rows.filter(r=>r.values.role==='primary');
  if(host.length!==1||host[0].values.id!=='sr1'||host[0].values.configId!=='soul-reaver')errors.push('games: primary sr1 must explicitly map to soul-reaver config ID');
  const donor=tables.games.rows.filter(r=>r.values.id==='defiance');
  if(donor.length!==1||donor[0].values.role!=='companion'||donor[0].values.configId!=='defiance')errors.push('games: Defiance companion config ID mismatch');
 }
 if(tables.tutorialLifetimeStages){
  let previous=tables.tutorialStages?.rows?.at(-1)?.values?.end;
  const rows=tables.tutorialLifetimeStages.rows;
  if(!Array.isArray(rows)||!rows.length)errors.push('tutorialLifetimeStages: missing scenario');
  else for(const row of rows){const v=row?.values;if(!v||v.begin!==previous||!Number.isInteger(v.end)||v.end<=v.begin)errors.push('tutorialLifetimeStages: contiguous positive stage required');previous=v?.end;}
  if(previous!==tables.sessionLifetime?.rows?.[0]?.values?.testSeconds)errors.push('tutorialLifetimeStages: scenario must end at session duration');
 }
 if(tables.interactionObservationStages||tables.interactionObservationPolicy){
  const rows=tables.interactionObservationStages?.rows,p=tables.interactionObservationPolicy?.rows?.[0]?.values;
  if(tables.interactionObservationPolicy?.rows?.length!==1||!p||p.id!=='bounded'||p.seconds!==180||p.intervalMs<50||p.intervalMs>1000||p.maxSamples!==p.seconds*1000/p.intervalMs||p.maxSamples>3600||p.startupMs<1000||p.startupMs>10000||p.stallMs<1500||p.stallMs>5000||p.maxLineBytes<1024||p.maxLineBytes>16384)errors.push('interactionObservationPolicy: bounded scalar observation required');
  for(const [name,scenario] of [['interactionObservationStages',rows],['glideObservationStages',tables.glideObservationStages?.rows]]){
   let previous=0;
   if(!Array.isArray(scenario)||!scenario.length)errors.push(name+': missing scenario');
   else for(const row of scenario){const v=row?.values;if(!v||v.begin!==previous||!Number.isInteger(v.end)||v.end<=v.begin)errors.push(name+': contiguous positive stages required');previous=v?.end;}
   if(previous!==p?.seconds)errors.push(name+': scenario duration mismatch');
  }
 }
 if(tables.roomObservationStages||tables.roomObservationPolicy){
  const p=tables.roomObservationPolicy?.rows?.[0]?.values,rows=tables.roomObservationStages?.rows;
  if(tables.roomObservationPolicy?.rows?.length!==1||!p||p.id!=='bounded'||p.seconds!==300||p.intervalMs!==100||p.maxSamples!==3000||p.startupMs<1000||p.startupMs>10000||p.stallMs<1500||p.stallMs>5000||p.maxLineBytes<1024||p.maxLineBytes>16384)errors.push('roomObservationPolicy: bounded300s scalar observation required');
  let previous=0;
  if(!Array.isArray(rows)||!rows.length)errors.push('roomObservationStages: missing scenario');
  else for(const row of rows){const v=row?.values;if(!v||v.begin!==previous||!Number.isInteger(v.end)||v.end<=v.begin)errors.push('roomObservationStages: contiguous positive stages required');previous=v?.end;}
  if(previous!==p?.seconds)errors.push('roomObservationStages: scenario duration mismatch');
  if(JSON.stringify(rows?.map(r=>r?.values?.id))!==JSON.stringify(['stay','engage','push-pull','ledge','climb','rotate','glide','finish']))errors.push('roomObservationStages: preserve user action order');
 }
 if(tables.donorActionStateProbe){const rows=tables.donorActionStateProbe.rows,v=rows?.[0]?.values;if(rows?.length!==1||v?.id!=='current'||v.actorStateOffset!==0x3f8||v.statePrefixBytes!==32||v.firstCallbackOffset!==16||v.secondCallbackOffset!==24||v.stableReads!==2||v.requireExecutableImage!==true||v.serializePointers!==false)errors.push('donorActionStateProbe: bounded read-only identity fields and executable-image/no-pointer guards required');}
 if(tables.donorStateSectionsProbe){const rows=tables.donorStateSectionsProbe.rows,v=rows?.[0]?.values;if(rows?.length!==1||v?.id!=='current'||v.ownerOffset!==0||v.sectionStride!==0x250||v.sectionCount!==3||v.prefixBytes!==32||v.stableReads!==2||v.requireExecutableImage!==true||v.serializePointers!==false)errors.push('donorStateSectionsProbe: exact bounded three-section/no-pointer observation required');}
 if(tables.donorMessageObservationPolicy){const expected=[0,0x4010402,0x4010008,0x4010080,0x4020000,0x4010400],ids=tables.donorMessageSampleIds?.rows?.map(r=>r.values?.messageId);if(ids?.length!==expected.length||expected.some(id=>ids.filter(v=>v===id).length!==1))errors.push('donorMessageSampleIds: exact6 observed metadata flood IDs required; preserve changed pairs');}
 if(tables.donorBlockTargetProbe){const rows=tables.donorBlockTargetProbe.rows,v=rows?.[0]?.values,expected={id:'current',contextPointerRva:0xc67120,actorPointerRva:0xc5aa78,actorStateOffset:0x3f8,stateOwnerOffset:0,engagementPointerOffset:0x1c0,engagementLowFlagsOffset:0x1c8,entryTargetOffset:0,heldTargetOffset:0x28,targetMessageCallbackOffset:0x3a8,ownerRelationOffset:0x340,targetRelationOffset:0x32c,pointerBytes:8,relationBytes:4,flagReadBytes:1,stableReads:2,serializePointers:false,serializeRelationValues:false,targetWrapperRva:0xee380,targetUserdataOffset:0x3f8,userdataHandlerOffset:8};if(rows?.length!==1||!v||Object.entries(expected).some(([k,x])=>v[k]!==x))errors.push('donorBlockTargetProbe: exact supported-image widths, stable reads and scalar-only output required');}
 if(tables.hostBlockStateProbe){const rows=tables.hostBlockStateProbe.rows,v=rows?.[0]?.values,expected={id:'current',currentActorRva:0x2a89310,stateRva:0x2a88588,ownerOffset:0,firstCallbackOffset:0x10,sectionStride:0x228,sectionCount:3,eventQueueOffset:0x18,deferQueueOffset:0x120,queueReadOffset:0,queueWriteOffset:4,queueRecordOffset:8,queueRecordBytes:16,queueCapacity:16,messageIdOffset:0,payloadOffset:8,engagementPointerRva:0x2a88ca0,engagementFlagsRva:0x2a88ca8,entryTargetOffset:0,heldTargetOffset:0x10,ownerRelationOffset:0x118,targetRelationOffset:0x64,pointerBytes:8,relationBytes:4,stableReads:2,serializePointers:false,serializePayloads:false,intervalMs:50,maxSamples:3600,precheckSamples:20,moduleSha256:'c006dea45509cdc3fbfab3a4230b47869c306ecdd7df8b4fd2499fd3654a2205',executableSha256:'0fb3aef0530ebf0510191f934dc371b69b43574331d3623eda694b72f060db93'};if(rows?.length!==1||!v||Object.entries(expected).some(([k,x])=>v[k]!==x))errors.push('hostBlockStateProbe: exact supported SR1 layout, bounded queue/clock and scalar-only policy required');}
 if(tables.donorMessageObservationPolicy||tables.donorMessageObservationStages){const rows=tables.donorMessageObservationPolicy?.rows,p=rows?.[0]?.values;if(rows?.length!==1||p?.id!=='bounded'||p.plan!==11||p.seconds!==60||p.intervalMs!==100||p.maxSamples!==600||p.maxRecords!==20000||p.rawMaxRecords!==120000||p.sampleMs!==100||p.sampleKeys!==128||p.pendingPairs!==128||p.queueCapacity!==512||p.maxDepth!==32||p.maxProcessAgeMs!==500000||p.leaseMs!==1500||p.skipTick!==0x100000||p.skipBefore!==0x100017||p.skipAfter!==0x100018)errors.push('donorMessageObservationPolicy: exact bounded forwarding-only60s policy required');let end=0;const stages=tables.donorMessageObservationStages?.rows;if(stages?.length!==5)errors.push('donorMessageObservationStages: five preparation/action stages required');for(const row of stages||[]){const v=row?.values;if(!v||v.begin!==end||!Number.isInteger(v.end)||v.end<=end)errors.push('donorMessageObservationStages: contiguous bounded timeline required');end=v?.end;}const extended=tables.donorAnimationStepPolicy?.rows?.[0]?.values?.revision===2||tables.hostBlockSurveyPolicy?.rows?.[0]?.values?.prepareSeconds===20;if(end!==60||stages?.[0]?.values?.begin!==0||stages?.[0]?.values?.end!==(extended?20:10))errors.push('donorMessageObservationStages: preserve bounded preparation and60s total');if(extended&&[[0,20],[20,35],[35,50],[50,55],[55,60]].some(([a,b],i)=>stages?.[i]?.values?.begin!==a||stages?.[i]?.values?.end!==b))errors.push('donorMessageObservationStages: revision2 step observation requires exact20s preparation timeline');}
 if(tables.hostBlockSurveyPolicy){
  const expected={id:'lateral-lift',revision:1,plan:11,seconds:60,prepareSeconds:20,serializePointers:false,syntheticCalls:false,commandsEnabled:false};
  const rows=tables.hostBlockSurveyPolicy.rows,v=rows?.[0]?.values;
  if(rows?.length!==1||!tables.hostBlockStateProbe||!tables.hostAnimationIndexProbe||!v||Object.keys(v).length!==Object.keys(expected).length||Object.entries(expected).some(([k,x])=>v[k]!==x))errors.push('hostBlockSurveyPolicy: exact read-only lateral/lift survey and20s preparation required');
  const ids=['prepare','lateral','lift-flip','release','finish'];
  if(tables.donorMessageObservationStages?.rows?.some((r,i)=>r.values.id!==ids[i]))errors.push('hostBlockSurveyPolicy: exact five native HUD stage identities required');
 }
 if(tables.guidanceBackendPolicy){const r=tables.guidanceBackendPolicy.rows,v=r?.[0]?.values;if(r?.length!==1||v?.id!=='donor'||v.enabled!==true||v.api!=='d3d11'||v.presentSlot!==8||v.present1Slot!==22||v.visibilityDeadlineMs!==3000)errors.push('guidanceBackendPolicy: public donor DXGI contract and bounded visibility gate required');}
 if(tables.hostAnimationIndexProbe){const rows=tables.hostAnimationIndexProbe.rows,v=rows?.[0]?.values,expected={id:'current',actorAnimationIdOffset:0x374,actorAnimationSectionStride:0x50,sectionCount:3,animationIdBytes:2,stableReads:2,requireSameHostStateSnapshot:true,serializeAnimationResources:false};if(rows?.length!==1||!tables.hostBlockStateProbe||!v||Object.keys(v).length!==Object.keys(expected).length||Object.entries(expected).some(([k,x])=>v[k]!==x))errors.push('hostAnimationIndexProbe: exact supported native scalar getter and stable host state required; animation resources forbidden');}
 if(tables.donorAnimationSelectionProbe){const rows=tables.donorAnimationSelectionProbe.rows,v=rows?.[0]?.values,expected={id:'current',actorPointerRva:0xc5aa78,actorStateOffset:0x3f8,sectionCount:3,stateSectionStride:0x250,selectionKeyOffset:0x248,cachedDescriptorOffset:0x250,animationIdOffset:0x1f4,animationSectionStride:0x68,selectionKeyBytes:4,descriptorPointerBytes:8,animationIdBytes:2,stableReads:2,serializePointers:false,serializeDescriptors:false};if(rows?.length!==1||!tables.donorActionStateProbe||!tables.donorStateSectionsProbe||!v||Object.keys(v).length!==Object.keys(expected).length||Object.entries(expected).some(([k,x])=>v[k]!==x))errors.push('donorAnimationSelectionProbe: exact scalar selector layout and stable owner/section identity required; descriptors/resources forbidden');}
 if(tables.donorAnimationEventProbe){const rows=tables.donorAnimationEventProbe.rows,v=rows?.[0]?.values,expected={id:'current',actorObjectOffset:0x88,sectionBaseOffset:0x1d0,sectionStride:0x68,callbackOffset:0x30,contextOffset:0x38,sourceObjectOffset:0x40,eventTableOffset:0x48,clipResourceOffset:0x50,blendOffset:0x58,pointerBytes:8,stableReads:2,serializePointers:false,dereferenceResources:false};if(rows?.length!==1||!tables.donorAnimationSelectionProbe||!v||Object.keys(v).length!==Object.keys(expected).length||Object.entries(expected).some(([k,x])=>v[k]!==x))errors.push('donorAnimationEventProbe: exact bracketed scalar code-RVA/presence/equality reads; pointer/resource serialization forbidden');}
 if(tables.donorAnimationCallPolicy){const rows=tables.donorAnimationCallPolicy.rows,v=rows?.[0]?.values,expected={id:'bounded',rva:0x149790,bodyBytes:291,plan:11,seconds:60,queueCapacity:512,maxRecords:4096,maxDepth:32,serializePointers:false,syntheticCalls:false};if(rows?.length!==1||!tables.donorAnimationSelectionProbe||!tables.donorMessageObservationPolicy||!v||Object.keys(v).length!==Object.keys(expected).length||Object.entries(expected).some(([k,x])=>v[k]!==x))errors.push('donorAnimationCallPolicy: bounded exact native forwarding-only observer with no synthetic calls required');}
 if(tables.donorActorIdentityProbe){const rows=tables.donorActorIdentityProbe.rows,v=rows?.[0]?.values,expected={id:'current',actorPointerRva:0xc5aa78,actorObjectOffset:0x88,pointerBytes:8,stableReads:2,samples:20,intervalMs:100,serializePointers:false,serializeNames:false};if(rows?.length!==1||!v||Object.keys(v).length!==Object.keys(expected).length||Object.entries(expected).some(([k,x])=>v[k]!==x))errors.push('donorActorIdentityProbe: bounded stable scalar identity only; pointers/names forbidden');}
 if(tables.donorAnimationMarkerPolicy){const rows=tables.donorAnimationMarkerPolicy.rows,v=rows?.[0]?.values,expected={id:'bounded',rva:0x14f600,spanBytes:2112,rootOffset:0x1a8,plan:11,seconds:60,queueCapacity:512,maxRecords:8192,maxDepth:32,requireSingleProducer:true,recordDropReasons:true,serializePointers:false,dereferencePayloads:false,syntheticCalls:false};if(rows?.length!==1||!tables.donorAnimationCallPolicy||!tables.donorAnimationEventProbe||!v||Object.keys(v).length!==Object.keys(expected).length||Object.entries(expected).some(([k,x])=>v[k]!==x))errors.push('donorAnimationMarkerPolicy: exact bounded single-producer forwarding-only scalar callback observer with drop reasons; payload reads/synthetic calls forbidden');}
 if(tables.hostNativeEnqueuePolicy){const rows=tables.hostNativeEnqueuePolicy.rows,v=rows?.[0]?.values,expected={id:'bounded',rva:0x10ccc0,bodyBytes:42,plan:11,seconds:60,queueCapacity:512,maxRecords:65536,maxDepth:32,requireSingleProducer:true,serializePointers:false,serializePayloads:false,syntheticCalls:false};if(rows?.length!==1||!tables.hostBlockStateProbe||!tables.hostAnimationIndexProbe||!v||Object.keys(v).length!==Object.keys(expected).length||Object.entries(expected).some(([k,x])=>v[k]!==x))errors.push('hostNativeEnqueuePolicy: exact bounded forwarding-only three-argument leaf with current host queue guards; payloads/pointers/synthetic calls forbidden');}
 if(tables.hostNativeTransitionPolicy){const rows=tables.hostNativeTransitionPolicy.rows,v=rows?.[0]?.values,expected={id:'bounded',sectionRva:0x1100f0,sectionBytes:158,wholeRva:0x10ffc0,wholeBytes:163,plan:11,seconds:60,queueCapacity:512,maxRecords:4096,maxDepth:32,requireSingleProducer:true,serializePointers:false,serializePayloads:false,syntheticCalls:false};if(rows?.length!==1||tables.hostNativeEnqueuePolicy||!tables.hostBlockStateProbe||!tables.hostAnimationIndexProbe||!v||Object.keys(v).length!==Object.keys(expected).length||Object.entries(expected).some(([k,x])=>v[k]!==x))errors.push('hostNativeTransitionPolicy: exact two native switches, bounded forwarding-only scalar observation; separate from enqueue; no pointers/payloads/synthetic calls');}
 if(tables.donorAnimationContextProbe){const rows=tables.donorAnimationContextProbe.rows,v=rows?.[0]?.values,expected={id:'current',actorPointerRva:0xc5aa78,globalContextRva:0x1140490,actorObjectOffset:0x88,actorStateOffset:0x3f8,actorContextOffset:0x310,keyMapOffset:0xd0,descriptorBaseOffset:0x78,descriptorBytes:16,keyBytes:2,maxDescriptorIndex:4095,stateSectionStride:0x250,selectionKeyOffset:0x248,cachedDescriptorOffset:0x250,sectionCount:3,samples:20,intervalMs:100,serializePointers:false,serializeDescriptors:false};const keys=tables.donorAnimationContextKeys?.rows?.map(r=>r.values?.key);if(rows?.length!==1||!tables.donorActorIdentityProbe||!v||Object.keys(v).length!==Object.keys(expected).length||Object.entries(expected).some(([k,x])=>v[k]!==x)||JSON.stringify(keys)!==JSON.stringify([53,65,66,67,75,87]))errors.push('donorAnimationContextProbe: bounded stable current Raziel context and six observed keys only; pointers/descriptor serialization forbidden');}
  if(tables.donorInitializationPolicy){const rows=tables.donorInitializationPolicy.rows,v=rows?.[0]?.values,expected={id:'bounded',rva:0x14e930,bodyBytes:3267,seconds:600,maxCalls:128,queueCapacity:64,serializePointers:false,retainDescriptors:false,syntheticCalls:false};if(rows?.length!==1||!tables.donorAnimationContextProbe||!v||Object.keys(v).length!==Object.keys(expected).length||Object.entries(expected).some(([k,x])=>v[k]!==x))errors.push('donorInitializationPolicy: exact original one-argument initializer, bounded epochs/fresh context only; no retained descriptors/pointers/synthetic calls');}
  if(tables.donorAlternativeDescriptorProbe){const rows=tables.donorAlternativeDescriptorProbe.rows,v=rows?.[0]?.values,expected={id:'bounded',tableOffset:0x58,rowBytes:8,descriptorOffset:0,maxRows:64,descriptorBytes:16,samples:200,intervalMs:100,serializePointers:false,serializeDescriptors:false,syntheticCalls:false};if(rows?.length!==1||!tables.donorAnimationContextProbe||!v||Object.keys(v).length!==Object.keys(expected).length||Object.entries(expected).some(([k,x])=>v[k]!==x))errors.push('donorAlternativeDescriptorProbe: exact bounded current-context alternative table, scalar masks only; no pointers/descriptors/synthetic calls');}
  if(tables.donorBlockMotionPolicy){const rows=tables.donorBlockMotionPolicy.rows,v=rows?.[0]?.values,expected={id:'bounded',startRva:0xcee90,startBytes:1566,finishRva:0xcea50,finishBytes:547,flagsOffset:0,directionOffset:0x70,selectorOffset:0x78,positionOffset:0x20,plan:11,seconds:60,queueCapacity:512,maxRecords:4096,maxDepth:32,serializePointers:false,serializeFinishReturn:false,syntheticCalls:false};if(rows?.length!==1||!tables.donorBlockTargetProbe||!tables.donorMessageObservationPolicy||!v||Object.keys(v).length!==Object.keys(expected).length||Object.entries(expected).some(([k,x])=>v[k]!==x))errors.push('donorBlockMotionPolicy: exact bounded original target helpers/scalar fields; no pointers, finish return or synthetic calls');}
  if(tables.donorBlockInitializationPolicy){const rows=tables.donorBlockInitializationPolicy.rows,v=rows?.[0]?.values,expected={id:'bounded',rva:0xcdd20,bodyBytes:909,seconds:600,maxCalls:1024,queueCapacity:256,maxDepth:32,actorFlagsOffset:0xa8,cleanupMask:0x20000,actorResourceOffset:0x310,resourceMagicOffset:4,resourceMagic:0xb00b,resourceSubtypeOffset:2,resourceSubtype:1,actorCallbackOffset:0x3a8,knownCallbackRva:0xee380,actorUserdataOffset:0x3f8,userdataHandlerOffset:8,initialHandlerRva:0xce270,serializePointers:false,syntheticCalls:false};if(rows?.length!==1||!tables.donorBlockTargetProbe||!v||Object.keys(v).length!==Object.keys(expected).length||Object.entries(expected).some(([k,x])=>v[k]!==x))errors.push('donorBlockInitializationPolicy: exact bounded original subtype1 boundary, no cleanup userdata dereference, pointers or synthetic calls');}
  if(tables.donorAnimationStepPolicy){const rows=tables.donorAnimationStepPolicy.rows,v=rows?.[0]?.values,expected={id:'bounded',revision:2,rva:0x5cd50,bodyBytes:569,tailRva:0x5cf90,tailBytes:1266,actorOffset:0x1d0,sectionStride:0x68,sections:3,scratchSlotRva:0x66bda8,scratchDefaultRva:0xc26890,arenaBeginRva:0x17c2e30,arenaEndRva:0x17d2e30,cursorRva:0x17d2e30,arenaChunkBytes:8192,callerFirst:0x5ea5e,callerSecond:0x5eb18,plan:11,seconds:60,prepareSeconds:20,filterOtherActors:true,recordExpiredAdmissions:true,queueCapacity:512,maxRecords:65536,maxDepth:32,serializePointers:false,syntheticCalls:false};if(rows?.length!==1||!tables.donorMessageObservationPolicy||!tables.donorStateSectionsProbe||!v||Object.keys(v).length!==Object.keys(expected).length||Object.entries(expected).some(([k,x])=>v[k]!==x))errors.push('donorAnimationStepPolicy: exact revision2 current-actor original float-step admission with20s preparation and explicit expired-admission accounting required');}
  if(tables.donorControlQueryPolicy){const rows=tables.donorControlQueryPolicy.rows,v=rows?.[0]?.values,expected={id:'bounded',rva:0x7a310,bodyBytes:344,queryFirst:0x45,querySecond:0x49,bindingTableRva:0x10aa820,rowBytes:12,keyboardMapperSlotRva:0xc655a0,keyboardMapperRva:0x19b150,plan:11,seconds:60,queueCapacity:512,maxRecords:65536,maxDepth:32,serializePointers:false,overrideInput:false,syntheticCalls:false};if(rows?.length!==1||!tables.donorMessageObservationPolicy||!tables.donorStateSectionsProbe||!v||Object.keys(v).length!==Object.keys(expected).length||Object.entries(expected).some(([k,x])=>v[k]!==x))errors.push('donorControlQueryPolicy: exact bounded logical0x45/0x49 original-result observation, no input override/pointers/synthetic calls');}
  if(tables.donorControlQueryPolicy||tables.donorControlQueryCallers){const rows=tables.donorControlQueryCallers?.rows,expected=[[0x114c49,0x45],[0x114c57,0x49],[0x118100,0x45],[0x11810e,0x49],[0x1187e8,0x45],[0x1187fa,0x49],[0x1189c0,0x45],[0x1189d2,0x49]];if(!tables.donorControlQueryPolicy||rows?.length!==8||expected.some(([r,q],i)=>rows[i]?.values?.id!=='caller'+i||rows[i]?.values?.returnRva!==r||rows[i]?.values?.query!==q||Object.keys(rows[i]?.values??{}).length!==3))errors.push('donorControlQueryCallers: all8 exact supported block return sites and logical0x45/0x49 queries required');}
  if(tables.guidanceRenderPolicy){
  const rows=tables.guidanceRenderPolicy.rows,p=rows?.[0]?.values;
  if(rows?.length!==1||p?.id!=='native'||p.rasterWidth!==1280||p.rasterHeight!==180||p.maxDisplayWidth!==1920||p.marginPixels!==16||p.topPixels!==36||p.pollMs!==100||['titlePixels','detailPixels','counterPixels'].some(k=>!Number.isInteger(p[k])||p[k]<12||p[k]>48))errors.push('guidanceRenderPolicy: bounded native render surface required');
 }
 if(tables.guidanceVisibilityStages){const rows=tables.guidanceVisibilityStages.rows,v=rows?.[0]?.values;if(rows?.length!==1||v?.id!=='visibility'||v.begin!==0||v.end!==20)errors.push('guidanceVisibilityStages: fixed20s visibility check required');}
 if(tables.launchReadiness){
  const rows=tables.launchReadiness.rows,v=Array.isArray(rows)&&rows.length===1?rows[0]?.values:null;
  if(!v||v.id!=='probe'||v.samples<3||v.samples>3600||v.stableSamples<2||v.stableSamples>v.samples||v.intervalMs<1||v.intervalMs>1000||v.timeoutMs<v.samples*v.intervalMs||v.timeoutMs>30000||v.maxLineBytes<1000||v.maxLineBytes>100000||v.hostAppId!==2521380||v.donorAppId!==3747730)errors.push('launchReadiness: invalid bounded supported-game policy');
 }
 if(tables.hostInputDevice){
  const rows=tables.hostInputDevice.rows;
  const v=Array.isArray(rows)&&rows.length===1?rows[0]?.values:null;
  if(!v||v.id!=='physical'||v.maxPads!==4||v.requireUnique!==true||!Number.isInteger(v.leftDeadzone)||v.leftDeadzone<0||v.leftDeadzone>32767||!Number.isInteger(v.triggerLimit)||v.triggerLimit<1||v.triggerLimit>255)errors.push('hostInputDevice: bounded unique four-slot policy required');
 }
 return errors;
}
