// SPDX-License-Identifier: GPL-3.0-or-later
// BC1/BC3 layout: Microsoft Direct3D block-compression specification.
// Pure memory conversions; this module has no filesystem access.
export function decodeMip({format,side,bytes}) {
  const stride={DXT1:8,DXT5:16}[format];
  if(!stride||!Number.isInteger(side)||side<4||side>2048||side%4||!Buffer.isBuffer(bytes)||bytes.length!==(side/4)**2*stride)throw new Error('Unsupported compressed mip');
  const pixels=Buffer.alloc(side*side*4);
  const color=v=>{const r=v>>11,g=(v>>5)&63,b=v&31;return [(r<<3)|(r>>2),(g<<2)|(g>>4),(b<<3)|(b>>2),255];};
  for(let by=0,offset=0;by<side;by+=4)for(let bx=0;bx<side;bx+=4,offset+=stride) {
    const co=offset+(format==='DXT5'?8:0),a=bytes.readUInt16LE(co),b=bytes.readUInt16LE(co+2),colors=[color(a),color(b)];
    if(a>b||format==='DXT5') {
      colors.push(colors[0].map((v,i)=>i===3?255:Math.floor((2*v+colors[1][i])/3)));
      colors.push(colors[0].map((v,i)=>i===3?255:Math.floor((v+2*colors[1][i])/3)));
    }else{colors.push(colors[0].map((v,i)=>i===3?255:Math.floor((v+colors[1][i])/2)));colors.push([0,0,0,0]);}
    const indices=bytes.readUInt32LE(co+4),alpha=[bytes[offset],bytes[offset+1]];
    let alphaBits=0;
    if(format==='DXT5') {
      alphaBits=bytes.readUIntLE(offset+2,6);
      if(alpha[0]>alpha[1])for(let j=1;j<=6;j++)alpha.push(Math.floor(((7-j)*alpha[0]+j*alpha[1])/7));
      else {for(let j=1;j<=4;j++)alpha.push(Math.floor(((5-j)*alpha[0]+j*alpha[1])/5));alpha.push(0,255);}
    }
    for(let y=0;y<4;y++)for(let x=0;x<4;x++) {
      const p=y*4+x,rgba=colors[(indices>>>(2*p))&3],dest=((by+y)*side+bx+x)*4;
      pixels[dest]=rgba[0];pixels[dest+1]=rgba[1];pixels[dest+2]=rgba[2];pixels[dest+3]=format==='DXT5'?alpha[Math.floor(alphaBits/2**(p*3))%8]:rgba[3];
    }
  }
  return pixels;
}
export function renderPackets(mesh,textures,positions) {
  const lod=mesh.lods[0],vertices=lod.vertexCount;
  if(vertices!==24135||lod.indices.length!==125790||textures.length!==8||!(positions instanceof Float32Array)||positions.length!==vertices*3)throw new Error('Unsupported render packet layout');
  const geometry=Buffer.alloc(16+positions.byteLength+lod.indices.length*4);
  geometry.write('RZL1');geometry.writeUInt32LE(vertices,4);geometry.writeUInt32LE(lod.indices.length,8);geometry.writeUInt32LE(1,12);
  for(let i=0;i<positions.length;i++){if(!Number.isFinite(positions[i])||Math.abs(positions[i])>100000)throw new Error('Invalid position');geometry.writeFloatLE(positions[i],16+i*4);}
  lod.indices.forEach((v,i)=>{if(!Number.isInteger(v)||v<0||v>=vertices)throw new Error('Invalid index');geometry.writeUInt32LE(v,16+positions.byteLength+i*4);});
  const appearance=Buffer.alloc(48+vertices*12+8*512*512*4);
  appearance.write('RZT1');appearance.writeUInt32LE(vertices,4);appearance.writeUInt32LE(8,8);appearance.writeUInt32LE(512,12);Buffer.from(mesh.sha256,'hex').copy(appearance,16);
  for(let i=0;i<vertices;i++) {
    const values=[...lod.uvs[i],lod.materials[i]];
    if(values.length!==3||values.some(v=>!Number.isFinite(v)||Math.abs(v)>128)||!Number.isInteger(values[2])||values[2]<0||values[2]>7)throw new Error('Invalid UV/material');
    values.forEach((v,k)=>appearance.writeFloatLE(v,48+i*12+k*4));
  }
  textures.forEach((texture,i)=>{if(texture.side!==512)throw new Error('Unsupported mip size');decodeMip(texture).copy(appearance,48+vertices*12+i*512*512*4);});
  return {geometry,appearance};
}
