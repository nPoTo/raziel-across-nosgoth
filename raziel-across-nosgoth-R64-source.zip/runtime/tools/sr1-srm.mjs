// SPDX-License-Identifier: GPL-3.0-or-later
// Original installed SR1 mesh retained in RAM. No serializer or file writer.
import crypto from 'node:crypto';
export function parseSr1Srm(b){
 if(!Buffer.isBuffer(b)||b.length>32*1024*1024)throw Error('Invalid SR1 SRM buffer');
 let p=0;const take=n=>{if(!Number.isSafeInteger(n)||n<0||p+n>b.length)throw Error('SR1 SRM bounds');const a=p;p+=n;return a;};
 const u=()=>b.readUInt32LE(take(4));const f=()=>{const v=b.readFloatLE(take(4));if(!Number.isFinite(v))throw Error('Nonfinite SRM float');return v;};
 const count=(n,max)=>{if(n<1||n>max)throw Error('Unsupported SRM count');return n;};
 if(u()!==0x014d5253)throw Error('Expected SR1 SRM1');
 const shaders=Array.from({length:count(u(),256)},()=>{const type=u(),parameters=Array.from({length:4},f);return {type,parameters,ranges:Array.from({length:3},()=>[u(),u()])};});
 const textures=Array.from({length:count(u(),256)},()=>{const a=take(32),name=b.toString('ascii',a,a+31).replace(/\0.*$/s,'');if(!/^[A-Za-z0-9_]+$/.test(name))throw Error('Bad texture name');return {name,flag:b[a+31]};});
 const extra=u();if(extra>224)throw Error('Too many bind groups');
 const bindOffsets=Array.from({length:(32+extra)*4},()=>[f(),f(),f()]);
 if(p+4<=b.length&&b.readUInt32LE(p)===0x80000000)take(4);
 const a=take(128),flags=Array.from(b.subarray(a,a+128));if(flags.some(v=>v!==0&&v!==1))throw Error('Bad bone flags');
 const palette=flags.flatMap((v,i)=>v?[i]:[]);if(!palette.length)throw Error('No weighted bones');
 const vertexCount=count(u(),1000000),indexCount=count(u(),3000000);if(indexCount%3)throw Error('Non-triangle index count');
 const positions=[],joints=[],weights=[],uvs=[],materials=[];
 for(let i=0;i<vertexCount;i++){
  positions.push([f(),f(),f()]);const q=take(20);materials.push(b[q+7]);
  const js=Array.from(b.subarray(q+8,q+11)),ws=Array.from(b.subarray(q+12,q+15));
  if(ws.reduce((a,b)=>a+b,0)!==255||ws.some((w,j)=>w&&(js[j]>=palette.length||palette[js[j]]>=bindOffsets.length)))throw Error('Bad SR1 weights');
  joints.push(js);weights.push(ws);uvs.push([b[q+11]/255,b[q+15]/255]);
 }
 const indices=Array.from({length:indexCount},()=>b.readUInt16LE(take(2)));
 // SR1 texture slots are 1-based (unlike the current Defiance reader). Keep
 // raw slots explicitly; a renderer must deliberately account for this base.
 if(indices.some(i=>i>=vertexCount)||materials.some(m=>m<1||m>textures.length)||shaders.some(s=>s.ranges.some(([a,n])=>a+n>indexCount||n%3))||p!==b.length)throw Error('Invalid SR1 topology/material/size');
 return {sha256:crypto.createHash('sha256').update(b).digest('hex'),materialIndexBase:1,shaders,textures,bindOffsets,palette,positions,joints,weights,uvs,materials,indices};
}
