// SPDX-License-Identifier: GPL-3.0-or-later
// Read the native tex.map registry in place. Never export resource payloads.
import fs from 'node:fs';import path from 'node:path';import crypto from 'node:crypto';
import {pathToFileURL} from 'node:url';
import {assetHash,DefianceArchive} from './defiance-archive.mjs';
import {decodeMip} from './memory-render-packets.mjs';
export function loadReaverHdTextures(ids,{writeReport=false}={}){
if(!Array.isArray(ids)||ids.length>128||ids.some(id=>!Number.isInteger(id)||id<1||id>65535)||new Set(ids).size!==ids.length)throw Error('Invalid Reaver texture references');
const ramTextures=[];
const expected='fc6a406ff7ac9b5eb7788dc7a65d335e1c1aad9236618112671975b71d2daddc';
const module=JSON.parse(fs.readFileSync('reports/local-inspection.json')).modules.find(x=>x.game==='defiance');
if(crypto.createHash('sha256').update(fs.readFileSync(module.file)).digest('hex')!==expected)throw Error('Executable identity');
const fd=fs.openSync(path.join(path.dirname(module.file),'bigfilehd.dat'),'r');
try{
 const size=fs.fstatSync(fd).size;
 const read=(n,at)=>{if(!Number.isSafeInteger(n)||n<1||n>4*1024*1024||!Number.isSafeInteger(at)||at<0||at>size-n)throw Error('Archive bounds');const b=Buffer.alloc(n);if(fs.readSync(fd,b,0,n,at)!==n)throw Error('Short read');return b;};
 const count=read(4,0).readUInt32LE();if(!count||count>100000)throw Error('Index count');
 const table=read(count*28,4),matches=[];
 for(let i=0;i<count;i++){if(i&&table.readUInt32LE(i*4)<table.readUInt32LE((i-1)*4))throw Error('Unsorted index');if(table.readUInt32LE(i*4)===assetHash('tex.map'))matches.push(i);}
 if(matches.length!==1)throw Error('Registry ambiguity');
 const at=count*4+matches[0]*24,bytes=Number(table.readBigUInt64LE(at)),offset=Number(table.readBigUInt64LE(at+8));
 if(table.readBigUInt64LE(at+16)!==0n||offset%2048||offset<4+table.length)throw Error('Registry entry');
 const registry=read(bytes,offset),entries=registry.readUInt32LE();
 // Native admission uses id<count. This installed file has one additional
 // complete record; never index it or reinterpret count as the last ID.
 if(!entries||entries>65536||bytes<4+entries*48||bytes>4+(entries+1)*48||(bytes-4)%48)throw Error('Registry layout');
 const textures=ids.map(id=>{
  if(id>=entries)return {id,name:null,reason:'outside_registry'};
  const row=registry.subarray(4+id*48,4+(id+1)*48),end=row.indexOf(0);if(end<0)throw Error('Unterminated texture name');
  const raw=row.toString('ascii',0,end),name=raw.split('.tga')[0];
  if(name&&!/^[a-zA-Z0-9_.-]+$/.test(name))throw Error('Unsupported texture name');
  return {id,name:name||null,reason:name?'registered':'no_substitution'};
 });
 const archive=new DefianceArchive(path.join(path.dirname(module.file),'bigfilehd.dat'));
 try{for(const texture of textures.filter(t=>t.name)){
  const key='tex_hd/'+texture.name.toLowerCase()+'.dds',dds=archive.read(key,16*1024*1024);
  if(dds.length<128||dds.readUInt32LE(4)!==124||dds.readUInt32LE(76)!==32)throw Error('DDS header');
  texture.dds={key,bytes:dds.length,width:dds.readUInt32LE(16),height:dds.readUInt32LE(12),mips:dds.readUInt32LE(28),format:dds.toString('ascii',84,88)};
  const {width,height,mips,format}=texture.dds,block={DXT1:8,DXT5:16}[format];
  if(!block||width!==height||width<4||width>2048||(width&(width-1))||mips!==Math.log2(width)+1||dds.readUInt32LE(112)!==0||dds.readUInt32LE(24)>1)throw Error('Unsupported DDS');
  let length=128;for(let level=0;level<mips;level++)length+=Math.max(1,Math.ceil((width>>level)/4))**2*block;
  if(length!==dds.length)throw Error('DDS mip bounds');
  const pixels=decodeMip({format,side:width,bytes:dds.subarray(128,128+(width/4)**2*block)});
  ramTextures.push({id:texture.id,width,height,pixels});
  texture.dds.basePixelBytes=pixels.length;texture.dds.basePixelSha256=crypto.createHash('sha256').update(pixels).digest('hex');
 }}finally{archive.close();}
 const metadata={moduleSha256:expected,evidence:'reports/discovery/rea-defiance-hd-texture-registry-load-19e033.json',registry:{entries,bytes,offset,unusedTrailingBytes:bytes-4-entries*48},textures,assetFilesWritten:0,renderingVerified:false};
 if(writeReport)fs.writeFileSync('reports/discovery/R01.04-reaver-hd-textures-20261024.json',JSON.stringify(metadata,null,2)+'\n');
 return {metadata,textures:ramTextures};
}finally{fs.closeSync(fd);}
}
if(process.argv[1]&&pathToFileURL(path.resolve(process.argv[1])).href===import.meta.url){
 const ids=JSON.parse(fs.readFileSync('reports/discovery/R01.04-reaver-legacy-resources-20261024.json')).resources[0].container.textureReferences;
 const r=loadReaverHdTextures(ids,{writeReport:true});console.log(JSON.stringify({referenced:ids.length,hdDecoded:r.textures.length,assetFilesWritten:0}));
}
