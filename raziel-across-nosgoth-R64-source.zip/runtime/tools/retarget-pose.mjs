// SPDX-License-Identifier: GPL-3.0-or-later
// Pure, parent-space pose conversion. Actual bone correspondence is a separate
// measured input, never inferred from identical indices or current world pose.
const finite=v=>Number.isFinite(v);
const vec=(v,n)=>Array.isArray(v)&&v.length===n&&v.every(finite);
export const quatIdentity=()=>[0,0,0,1];
export function quatNormalize(q){if(!vec(q,4))throw Error('Invalid quaternion');const n=Math.hypot(...q);if(!finite(n)||n<1e-9)throw Error('Zero/overflow quaternion');return q.map(v=>v/n);}
export const quatInverse=q=>{const n=quatNormalize(q);return [-n[0],-n[1],-n[2],n[3]];};
export function quatMultiply(a,b){a=quatNormalize(a);b=quatNormalize(b);const [x,y,z,w]=a,[X,Y,Z,W]=b;return quatNormalize([w*X+x*W+y*Z-z*Y,w*Y-x*Z+y*W+z*X,w*Z+x*Y-y*X+z*W,w*W-x*X-y*Y-z*Z]);}
export function quatRotate(q,v){if(!vec(v,3))throw Error('Invalid vector');const [x,y,z,w]=quatNormalize(q),[a,b,c]=v,tx=2*(y*c-z*b),ty=2*(z*a-x*c),tz=2*(x*b-y*a);return [a+w*tx+y*tz-z*ty,b+w*ty+z*tx-x*tz,c+w*tz+x*ty-y*tx];}
export function quatBlend(a,b,t){if(!finite(t)||t<0||t>1)throw Error('Invalid blend');a=quatNormalize(a);b=quatNormalize(b);let d=a.reduce((s,v,i)=>s+v*b[i],0);if(d<0){b=b.map(v=>-v);d=-d;}d=Math.min(1,d);if(d>.9995)return quatNormalize(a.map((v,i)=>v+(b[i]-v)*t));const theta=Math.acos(d),s=Math.sin(theta);return quatNormalize(a.map((v,i)=>(v*Math.sin((1-t)*theta)+b[i]*Math.sin(t*theta))/s));}
export function validateRig(rig,maxBones=128){
 if(!rig||!Number.isInteger(maxBones)||maxBones<1||maxBones>128||!Array.isArray(rig.parents)||!rig.parents.length||rig.parents.length>maxBones||!Array.isArray(rig.rest)||rig.rest.length!==rig.parents.length)throw Error('Invalid rig');
 const n=rig.parents.length,order=[],seen=new Set(),active=new Set();
 function visit(i){if(seen.has(i))return;if(active.has(i))throw Error('Rig cycle');active.add(i);const p=rig.parents[i];if(!Number.isInteger(p)||p< -1||p>=n||p===i)throw Error('Invalid parent');if(p>=0)visit(p);const t=rig.rest[i];if(!t||!vec(t.position,3)||t.position.some(x=>Math.abs(x)>1000000))throw Error('Invalid rest position');quatNormalize(t.rotation);active.delete(i);seen.add(i);order.push(i);}
 for(let i=0;i<n;i++)visit(i);return order;
}
export function retargetLocalPose({source,target,sourceLocal,nativeLocal,map,blend=1,maxBones=128}){
 validateRig(source,maxBones);const order=validateRig(target,maxBones);
 for(const [pose,rig]of [[sourceLocal,source],[nativeLocal,target]]){if(!Array.isArray(pose)||pose.length!==rig.parents.length)throw Error('Incomplete pose');pose.forEach(q=>quatNormalize(q));}
 if(!Array.isArray(map)||map.length>target.parents.length)throw Error('Invalid map');
 const mapped=new Set(),result=nativeLocal.map(quatNormalize);
 for(const m of map){
  if(!m||!Number.isInteger(m.source)||!Number.isInteger(m.target)||m.source<0||m.source>=source.parents.length||m.target<0||m.target>=target.parents.length||mapped.has(m.target)||source.parents[m.source]<0||target.parents[m.target]<0)throw Error('Invalid or root-driven mapping');
  mapped.add(m.target);const basis=quatNormalize(m.basis),delta=quatMultiply(quatInverse(source.rest[m.source].rotation),sourceLocal[m.source]);
  const converted=quatMultiply(quatMultiply(basis,delta),quatInverse(basis));
  const desired=quatMultiply(target.rest[m.target].rotation,converted);result[m.target]=quatBlend(nativeLocal[m.target],desired,blend);
 }
 // Preserve SR1 proportions and every root transform. Donor positions/root yaw
 // are absent from this API so they cannot become authoritative accidentally.
 return {parents:[...target.parents],order,local:result.map((rotation,i)=>({rotation,position:[...target.rest[i].position]}))};
}
export function composeRig(pose,hostRoot){
 if(!hostRoot||!vec(hostRoot.position,3)||hostRoot.position.some(v=>Math.abs(v)>1000000))throw Error('Invalid host root');
 quatNormalize(hostRoot.rotation);const rig={parents:pose.parents,rest:pose.local},order=validateRig(rig),world=[];
 for(const i of order){const local=pose.local[i],p=pose.parents[i]<0?hostRoot:world[pose.parents[i]],v=quatRotate(p.rotation,local.position);world[i]={position:v.map((x,k)=>x+p.position[k]),rotation:quatMultiply(p.rotation,local.rotation)};}
 return world;
}
export function attachToHand(world,hand,attachment){
 if(!Array.isArray(world)||!Number.isInteger(hand)||!world[hand]||!attachment||!vec(attachment.position,3)||!finite(attachment.scale)||attachment.scale<=0||attachment.scale>1000)throw Error('Invalid hand attachment');
 const p=world[hand];if(!vec(p.position,3))throw Error('Invalid hand pose');const offset=quatRotate(p.rotation,attachment.position);
 return {position:p.position.map((v,i)=>v+offset[i]),rotation:quatMultiply(p.rotation,attachment.rotation),scale:attachment.scale};
}
export function rigidFromPackedRender(m,tolerance=.03){
 if(!vec(m,13)||!finite(tolerance)||tolerance<=0||tolerance>.1||m.some(v=>Math.abs(v)>1000000))throw Error('Invalid packed render transform');
 for(let a=0;a<3;a++)for(let b=a;b<3;b++){let dot=0;for(let k=0;k<3;k++)dot+=m[k*3+a]*m[k*3+b];if(Math.abs(dot-(a===b?1:0))>tolerance)throw Error('Non-rigid matrix');}
 const [a,b,c,d,e,f,g,h,i]=m,det=a*(e*i-f*h)-b*(d*i-f*g)+c*(d*h-e*g);if(Math.abs(det-1)>tolerance*2)throw Error('Reflected matrix');
 let q,t;if(a+e+i>0){t=Math.sqrt(1+a+e+i)*2;q=[(h-f)/t,(c-g)/t,(d-b)/t,t/4];}
 else if(a>e&&a>i){t=Math.sqrt(1+a-e-i)*2;q=[t/4,(b+d)/t,(c+g)/t,(h-f)/t];}
 else if(e>i){t=Math.sqrt(1+e-a-i)*2;q=[(b+d)/t,t/4,(f+h)/t,(c-g)/t];}
 else {t=Math.sqrt(1+i-a-e)*2;q=[(c+g)/t,(f+h)/t,t/4,(d-b)/t];}
 return {position:m.slice(10,13),rotation:quatNormalize(q)};
}
export function localFromWorld(parents,world,actorRoot){
 if(!Array.isArray(world)||!Array.isArray(parents)||world.length!==parents.length||!actorRoot||!vec(actorRoot.position,3))throw Error('Invalid world rig');
 quatNormalize(actorRoot.rotation);const rig={parents,rest:world};validateRig(rig);
 return world.map((w,i)=>{const p=parents[i]<0?actorRoot:world[parents[i]],inverse=quatInverse(p.rotation);return {position:quatRotate(inverse,w.position.map((v,k)=>v-p.position[k])),rotation:quatMultiply(inverse,w.rotation)};});
}
export function quatFromTo(a,b){
 if(!vec(a,3)||!vec(b,3))throw Error('Invalid bone axis');const A=Math.hypot(...a),B=Math.hypot(...b);if(A<1e-8||B<1e-8)throw Error('Zero bone axis');a=a.map(x=>x/A);b=b.map(x=>x/B);
 const d=a.reduce((s,v,i)=>s+v*b[i],0);if(d>1-1e-8)return quatIdentity();
 if(d<-1+1e-8){const basis=Math.abs(a[0])<.8?[1,0,0]:[0,1,0];return quatNormalize([a[1]*basis[2]-a[2]*basis[1],a[2]*basis[0]-a[0]*basis[2],a[0]*basis[1]-a[1]*basis[0],0]);}
 return quatNormalize([a[1]*b[2]-a[2]*b[1],a[2]*b[0]-a[0]*b[2],a[0]*b[1]-a[1]*b[0],1+d]);
}
export function retargetWorldPose({sourceWorld,sourceActorRoot,target,nativeLocal,map,blend=1}){
 const order=validateRig(target);if(!Array.isArray(sourceWorld)||!sourceWorld.length||sourceWorld.length>128||!Array.isArray(nativeLocal)||nativeLocal.length!==target.parents.length||!Array.isArray(map))throw Error('Invalid world pose inputs');
 // Null explicitly means an unused source bone. Facial/hair scale helpers are
 // not rotations and must not invalidate a separate, rigid limb mapping.
 sourceWorld.forEach(t=>{if(t===null)return;if(!t||!vec(t.position,3))throw Error('Invalid source transform');quatNormalize(t.rotation);});
 if(!sourceActorRoot||!vec(sourceActorRoot.position,3))throw Error('Invalid source root');const inverse=quatInverse(sourceActorRoot.rotation),byTarget=new Map();
 for(const m of map){if(!m||!Number.isInteger(m.source)||m.source<=0||m.source>=sourceWorld.length||!sourceWorld[m.source]||!Number.isInteger(m.target)||m.target<0||m.target>=target.parents.length||target.parents[m.target]<0||byTarget.has(m.target)||Object.hasOwn(m,'alignment'))throw Error('Invalid world bone map or obsolete additive alignment');quatNormalize(m.basis);quatNormalize(m.sourceRestRotation);byTarget.set(m.target,m);}
 const controls=[];
 for(const [index,mapping]of byTarget){
  const relative=quatMultiply(inverse,sourceWorld[mapping.source].rotation),delta=quatMultiply(relative,quatInverse(mapping.sourceRestRotation));
  controls.push({target:index,delta:quatMultiply(quatMultiply(mapping.basis,delta),quatInverse(mapping.basis))});
 }
 return retargetControlledPose({target,nativeLocal,controls,blend});
}
// Exactly one optional model-space deformation per target. Virtual/arc source
// controls are resolved by the adapter, never materialized as extra host bones.
export function retargetControlledPose({target,nativeLocal,controls,blend=1}){
 const order=validateRig(target);if(!Array.isArray(nativeLocal)||nativeLocal.length!==target.parents.length||!Array.isArray(controls)||!finite(blend)||blend<0||blend>1)throw Error('Invalid target controls');
 const byTarget=new Map();for(const c of controls){if(!c||!Number.isInteger(c.target)||c.target<0||c.target>=target.parents.length||target.parents[c.target]<0||byTarget.has(c.target))throw Error('Duplicate/root target control');byTarget.set(c.target,quatNormalize(c.delta));}
 const reference=composeRig({parents:target.parents,local:target.rest},{position:[0,0,0],rotation:quatIdentity()});
 const local=[],world=[];
 for(const i of order){const p=target.parents[i],parent=p<0?{position:[0,0,0],rotation:quatIdentity()}:world[p];let rotation=quatNormalize(nativeLocal[i]);const delta=byTarget.get(i);
  if(delta){
   // These are skin-space deformations, not joint-frame orientations. A bind
   // edge's anatomical direction is NOT an additive rotation. Subtract the
   // explicit source reference, convert the deformation's coordinate basis,
   // and apply it to the target reference. Identity motion stays identity.
   const desiredGlobal=quatMultiply(delta,reference[i].rotation),desiredLocal=quatMultiply(quatInverse(parent.rotation),desiredGlobal);rotation=quatBlend(rotation,desiredLocal,blend);
  }
  local[i]={position:[...target.rest[i].position],rotation};const shift=quatRotate(parent.rotation,local[i].position);world[i]={position:shift.map((v,k)=>v+parent.position[k]),rotation:quatMultiply(parent.rotation,rotation)};
 }
 return {parents:[...target.parents],order,local,world};
}
