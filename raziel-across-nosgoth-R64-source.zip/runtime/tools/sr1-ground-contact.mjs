// SPDX-License-Identifier: GPL-3.0-or-later
// Pure presentation-only sole alignment. No game state or actor-root writes.
import {quatInverse,quatRotate,validateRig} from './retarget-pose.mjs';
const finite3=v=>Array.isArray(v)&&v.length===3&&v.every(Number.isFinite);
export function sr1FootVertices(mesh,policy){
 const bones=new Set(policy.footBones.split(',').map(Number));
 if(bones.size!==4||!Number.isInteger(policy.minFootWeight)||policy.minFootWeight<1||policy.minFootWeight>255)throw Error('Invalid foot policy');
 return mesh.positions.flatMap((_,i)=>mesh.joints[i].reduce((s,j,k)=>s+(bones.has(mesh.palette[j])?mesh.weights[i][k]:0),0)>=policy.minFootWeight?[i]:[]);
}
export function alignSr1GroundSoles({pose,positions,nativePositions,feet,up,restWorld,policy,groundAllowed}){
 const order=validateRig({parents:pose.parents,rest:pose.local}),pelvis=policy.pelvisBone;
 if(!Number.isInteger(pelvis)||pose.parents[pelvis]!==0||!finite3(up)||Math.abs(Math.hypot(...up)-1)>.0001||!Number.isInteger(policy.maxCorrectionLegPermille)||policy.maxCorrectionLegPermille<1||policy.maxCorrectionLegPermille>350||!Array.isArray(feet)||!feet.length||positions.length!==nativePositions.length)throw Error('Invalid grounding inputs');
 if(!groundAllowed)return {allow:false,reason:'native_context',pose,correction:0};
 const below=order.map(i=>{let at=i;while(at>=0&&at!==pelvis)at=pose.parents[at];return at===pelvis;});
 // Every weighted target bone must be under the pelvis. Root0 stays untouched.
 const low=a=>{let min=Infinity;for(const i of feet){if(!Number.isInteger(i)||i<0||i*3+2>=a.length)throw Error('Invalid foot vertex');let value=0;for(let k=0;k<3;k++){const v=a[i*3+k];if(!Number.isFinite(v))throw Error('Invalid sole position');value+=v*up[k];}min=Math.min(min,value);}return min;};
 const distance=(a,b)=>Math.hypot(...restWorld[a].position.map((v,k)=>v-restWorld[b].position[k]));
 const leg=(distance(6,7)+distance(7,8)+distance(8,9)+distance(10,11)+distance(11,12)+distance(12,13))/2,limit=leg*policy.maxCorrectionLegPermille/1000,correction=low(nativePositions)-low(positions);
 if(!Number.isFinite(limit)||limit<=0||!Number.isFinite(correction))throw Error('Invalid native leg reference');
 if(Math.abs(correction)>limit)return {allow:false,reason:'sole_gap_out_of_bounds',pose,correction,limit};
 const shift=up.map(v=>v*correction),parentRotation=pose.world[0].rotation,localShift=quatRotate(quatInverse(parentRotation),shift);
 const local=pose.local.map((b,i)=>({...b,rotation:[...b.rotation],position:b.position.map((v,k)=>v+(i===pelvis?localShift[k]:0))}));
 const world=pose.world.map((b,i)=>({...b,rotation:[...b.rotation],position:b.position.map((v,k)=>v+(below[i]?shift[k]:0))}));
 return {allow:true,reason:'bounded_native_sole_reference',pose:{...pose,local,world},correction,limit};
}
