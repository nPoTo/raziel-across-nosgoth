// SPDX-License-Identifier: GPL-3.0-or-later
// Disabled, bone-only absolute pose conversion. No renderer, mesh or game writes.
import {quatIdentity as I,quatMultiply as mul,quatInverse as inv,quatRotate as rotate,quatBlend,rigidFromPackedRender,localFromWorld,validateRig} from './retarget-pose.mjs';
const sub=(a,b)=>a.map((v,k)=>v-b[k]),dot=(a,b)=>a.reduce((s,v,k)=>s+v*b[k],0);
const cross=(a,b)=>[a[1]*b[2]-a[2]*b[1],a[2]*b[0]-a[0]*b[2],a[0]*b[1]-a[1]*b[0]];
const unit=v=>{const n=Math.hypot(...v);if(!Number.isFinite(n)||n<1e-7)throw Error('Degenerate anatomical edge');return v.map(x=>x/n);};
const point=(c,positions)=>positions[c.a].map((x,k)=>x+(positions[c.b][k]-x)*c.t);
const packed=q=>{const x=rotate(q,[1,0,0]),y=rotate(q,[0,1,0]),z=rotate(q,[0,0,1]);return [x[0],y[0],z[0],x[1],y[1],z[1],x[2],y[2],z[2],0,0,0,0];};
// Scalar fault provenance only. Preserve the original failure/message and all
// geometry predicates; stage distinguishes donor, host and target namespaces.
const diagnosed=(stage,bone,work)=>{try{return work();}catch(e){e.stage??=stage;e.bone??=bone;throw e;}};
const column=m=>{
 if(!Array.isArray(m)||m.length!==16||m.some(v=>!Number.isFinite(v))||Math.abs(m[3])+Math.abs(m[7])+Math.abs(m[11])+Math.abs(m[15]-1)>1e-5)throw Error('Invalid source skeletal matrix');
 return rigidFromPackedRender([m[0],m[4],m[8],m[1],m[5],m[9],m[2],m[6],m[10],0,m[12],m[13],m[14]]);
};
function frame(primary,secondary,minSine){
 const x=unit(primary),s=unit(secondary),y0=s.map((v,k)=>v-dot(s,x)*x[k]);
 if(Math.hypot(...y0)<minSine)throw Error('Singular anatomical frame');
 const y=unit(y0),z=unit(cross(x,y));
 return rigidFromPackedRender([x[0],y[0],z[0],x[1],y[1],z[1],x[2],y[2],z[2],0,0,0,0]).rotation;
}
export function compileSkeletonAlignment({hostParents,hostBind,sourceParents,sourceBind,controls,rows,policy}){
 if(policy?.id!=='sr1_absolute_bind_frame_v1'||policy.enabled!==false||policy.firstFrameIsZero!==false||policy.bodyPayload!==false||policy.nativeRoot!==true||policy.nativeLengths!==true||policy.targetBones!==66||policy.sourceBones!==85||policy.secondaryRule!=='fixed_least_parallel_bind_axis'||!['length_preserving_source_edges','length_preserving_source_edges_with_authored_wrap'].includes(policy.positions))throw Error('Unsupported skeleton alignment policy');
 if(hostParents.length!==66||sourceParents.length!==85||hostBind.length!==66||sourceBind.length!==85||controls.length!==66||rows.length!==66)throw Error('Full66/85 skeleton required');
 const rest=(parents,positions)=>positions.map((p,i)=>({position:parents[i]<0?[...p]:sub(p,positions[parents[i]]),rotation:I()}));
 const hostRest=rest(hostParents,hostBind),order=validateRig({parents:hostParents,rest:hostRest});validateRig({parents:sourceParents,rest:rest(sourceParents,sourceBind)});
 const minSine=policy.minimumFrameSineMilli/1000;if(!Number.isFinite(minSine)||minSine<.01||minSine>.25)throw Error('Invalid frame singularity bound');
 const seen=new Set();for(const c of controls){if(seen.has(c.target)||!Number.isInteger(c.target)||c.target<0||c.target>=66)throw Error('Invalid control target');seen.add(c.target);if(c.a!==undefined&&(![c.a,c.b].every(i=>Number.isInteger(i)&&i>0&&i<85)||!Number.isFinite(c.t)||c.t<0||c.t>1))throw Error('Invalid source control');}
 if(controls.some((c,i)=>c.target!==i))throw Error('Control order changed');
 const points=controls.map(c=>c.a===undefined?null:point(c,sourceBind)),frames=[];seen.clear();
 for(const r of rows){
  const i=r.target,c=controls[i];if(!Number.isInteger(i)||i<0||i>=66||seen.has(i))throw Error('Duplicate/missing frame target');seen.add(i);
  const f={...r};
  if(r.method==='native_root'){if(i!==0||c.mode!=='native_root'||r.child!==-1)throw Error('Invalid native root frame');}
  else if(r.method==='native_local'){if(c.mode!=='native_local'||r.child!==-1)throw Error('Invalid native local frame');}
  else {
   if(c.a===undefined||i===0)throw Error('Missing mapped frame control');
   if(r.method==='outgoing_frame'){
    const j=r.child;if(!Number.isInteger(j)||j<0||j>=66||hostParents[j]!==i||!points[j])throw Error('Unmapped/non-child primary edge');
    const h=unit(sub(hostBind[j],hostBind[i])),s=unit(sub(points[j],points[i]));
    const axes=[[1,0,0],[0,1,0],[0,0,1]];
    f.secondary=axes.toSorted((a,b)=>Math.max(Math.abs(dot(a,h)),Math.abs(dot(a,s)))-Math.max(Math.abs(dot(b,h)),Math.abs(dot(b,s))))[0];
    f.targetBindFrame=frame(h,f.secondary,minSine);frame(s,f.secondary,minSine);
   } else if(r.method==='inherit_frame'||r.method==='inherit_frame_bind_offset'){
    if(r.method==='inherit_frame_bind_offset'&&(policy.positions!=='length_preserving_source_edges_with_authored_wrap'||![21,23].includes(i)||hostParents[i]!==17||hostParents.includes(i)))throw Error('Unproved authored attachment');
    if(r.child!==-1)throw Error('Unexpected inherited primary edge');let p=hostParents[i];while(p>0&&controls[p].a===undefined)p=hostParents[p];
    if(p<=0||controls[p].a===undefined)throw Error('No anatomical ancestor');f.ancestor=p;
   } else if(r.method!=='source_frame'||r.child!==-1)throw Error('Unknown frame conversion');
  }
  frames[i]=f;
 }
 return {policy:{...policy},parents:[...hostParents],sourceParents:[...sourceParents],hostRest,order,controls:controls.map(c=>({...c})),frames,minSine};
}
function sourceFrame(compiled,pose){
 if(!pose?.valid||pose.matrices?.length!==110||pose.baseHierarchyCandidate?.parents?.length!==85||pose.baseHierarchyCandidate.parents.some((p,i)=>p!==compiled.sourceParents[i]))throw Error('Source identity/topology changed');
 const root=diagnosed('donor_matrix',0,()=>column(pose.matrices[0])),inverse=inv(root.rotation),needed=[...new Set(compiled.controls.flatMap(c=>c.a===undefined?[]:[c.a,c.b]))],joints=new Map();
 for(const i of needed){const w=diagnosed('donor_matrix',i,()=>column(pose.matrices[i]));joints.set(i,{position:rotate(inverse,sub(w.position,root.position)),rotation:mul(inverse,w.rotation)});}
 const pelvis=joints.get(1)?.rotation;if(!pelvis)throw Error('Source pelvis control missing');
 const n=Math.hypot(pelvis[2],pelvis[3]);if(n<1e-6)diagnosed('donor_heading',1,()=>{throw Error('Source heading singular');});const heading=[0,0,-pelvis[2]/n,pelvis[3]/n];
 const points=[],rotations=[];
 for(const c of compiled.controls){if(c.a===undefined){points.push(null);rotations.push(null);continue;}
  const a=joints.get(c.a),b=joints.get(c.b);points.push(rotate(heading,a.position.map((x,k)=>x+(b.position[k]-x)*c.t)));rotations.push(mul(heading,quatBlend(a.rotation,b.rotation,c.t)));
 }
 return {points,rotations};
}
export function rebaseSkeletonMatrices(actorLocalMatrices,currentHostRender){
 if(!Array.isArray(actorLocalMatrices)||actorLocalMatrices.length!==66||!Array.isArray(currentHostRender)||currentHostRender.length!==66)throw Error('Full native/local skeleton required');
 const root=diagnosed('host_render',0,()=>rigidFromPackedRender(currentHostRender[0])),relative=actorLocalMatrices.map((m,i)=>diagnosed('target_matrix',i,()=>rigidFromPackedRender(m))),zero=actorLocalMatrices[0];
 if(zero.some((v,k)=>Math.abs(v-([0,4,8].includes(k)?1:0))>1e-6))throw Error('Actor-local root must be identity');
 return relative.map((w,i)=>{if(i===0)return [...currentHostRender[0]];const m=packed(mul(root.rotation,w.rotation)),p=rotate(root.rotation,w.position);m[9]=currentHostRender[i][9];for(let k=0;k<3;k++)m[10+k]=root.position[k]+p[k];diagnosed('target_rebased_matrix',i,()=>rigidFromPackedRender(m));return m;});
}
export function alignSr1Skeleton({compiled,hostRender,donorPose,groundAllowed,experimental}){
 if(experimental!=='sr1-absolute-skeleton-offline-v1')throw Error('Disabled skeletal alignment requires explicit offline admission');
 if(groundAllowed!==true)return {allow:false,reason:'native_context',runtimeEligible:false};
 try {
  if(!Array.isArray(hostRender)||hostRender.length!==66)throw Error('Incomplete native host pose');
  const nativeWorld=hostRender.map((m,i)=>diagnosed('host_render',i,()=>rigidFromPackedRender(m))),root=nativeWorld[0],native=diagnosed('host_local_frame',null,()=>localFromWorld(compiled.parents,nativeWorld,root)),source=diagnosed('donor_identity',null,()=>sourceFrame(compiled,donorPose)),local=[],world=[],corrections=[];
  for(const i of compiled.order){
   const f=compiled.frames[i],p=compiled.parents[i],parent=p<0?{position:[0,0,0],rotation:I()}:world[p];let rotation=native[i].rotation;
   if(f.method!=='native_root'&&f.method!=='native_local'){
    let desired;
    if(f.method==='outgoing_frame')desired=diagnosed('target_outgoing_frame',i,()=>mul(frame(sub(source.points[f.child],source.points[i]),rotate(source.rotations[i],f.secondary),compiled.minSine),inv(f.targetBindFrame)));
    else if(f.method==='source_frame')desired=source.rotations[i];
    else desired=mul(source.rotations[i],corrections[f.ancestor]);
    corrections[i]=mul(inv(source.rotations[i]),desired);rotation=mul(inv(parent.rotation),desired);
   }
   // One parent rotation cannot match several different bind branch angles.
   // Reconstruct mapped joint edges in current source directions, using ONLY
   // their SR1 lengths; convert the offset through the already adapted parent.
   // Root/pelvis/native-local offsets remain host-owned. No source translation
   // is copied and the original native skeleton buffer remains untouched.
   let position;
   if(p<0||i===1||f.method==='native_local')position=[...native[i].position];
   else if(f.method==='inherit_frame_bind_offset')position=[...compiled.hostRest[i].position];
   else {
    if(!source.points[i]||!source.points[p])throw Error('Unmapped anatomical edge parent');
    const direction=diagnosed('target_anatomical_edge',i,()=>unit(sub(source.points[i],source.points[p]))),length=Math.hypot(...compiled.hostRest[i].position);
    position=rotate(inv(parent.rotation),direction.map(v=>v*length));
   }
   local[i]={position,rotation};
   world[i]={position:rotate(parent.rotation,position).map((v,k)=>v+parent.position[k]),rotation:mul(parent.rotation,rotation)};
  }
  const actorLocalMatrices=world.map(w=>{const m=packed(w.rotation);for(let k=0;k<3;k++)m[10+k]=w.position[k];return m;}),matrices=rebaseSkeletonMatrices(actorLocalMatrices,hostRender);
  matrices.forEach((m,i)=>diagnosed('target_rebased_matrix',i,()=>rigidFromPackedRender(m)));
  return {allow:true,runtimeEligible:false,parents:[...compiled.parents],local,world,actorLocalMatrices,matrices,controlCount:66,meshBytes:0,textureBytes:0};
 } catch(e){return {allow:false,reason:'incoherent_skeleton',detail:e.message,stage:e.stage??'alignment',bone:e.bone??null,runtimeEligible:false};}
}
