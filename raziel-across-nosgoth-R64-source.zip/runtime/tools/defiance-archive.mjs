// SPDX-License-Identifier: GPL-3.0-or-later
// Read selected content in place. This module never writes game assets to disk.
import fs from 'node:fs';
export function assetHash(key) {
  let value=0xffffffff;
  for(const byte of Buffer.from(key)) {
    value^=byte<<24;
    for(let i=0;i<8;i++)value=value&0x80000000?(value<<1)^0x04c11db7:value<<1;
  }
  return (~value)>>>0;
}
export function normalizeAssetKey(key) {
  if(typeof key!=='string')throw new Error('Asset key must be a string');
  key=key.replaceAll('\\','/').toLowerCase();
  if(!/^[a-z0-9_-]+(?:\/[a-z0-9_.-]+)+\.(srm|dds)$/.test(key)||key.split('/').some(p=>p==='.'||p==='..'))throw new Error('Invalid asset key');
  return key;
}
export class DefianceArchive {
  #fd; #size; #table; #count;
  constructor(filename) {
    this.#fd=fs.openSync(filename,'r');
    try {
      this.#size=fs.fstatSync(this.#fd).size;
      if(!Number.isSafeInteger(this.#size))throw new Error('Archive is too large');
      this.#count=this.#read(4,0).readUInt32LE();
      if(!this.#count||this.#count>100000)throw new Error('Invalid archive entry count');
      this.#table=this.#read(4+this.#count*28,0);
      for(let i=1;i<this.#count;i++)if(this.#table.readUInt32LE(4+i*4)<this.#table.readUInt32LE(i*4))throw new Error('Unsorted archive index');
    } catch(error){this.close();throw error;}
  }
  #read(size,offset) {
    if(this.#fd===undefined)throw new Error('Archive is closed');
    if(!Number.isSafeInteger(size)||!Number.isSafeInteger(offset)||size<0||offset<0||offset>this.#size-size)throw new Error('Truncated archive');
    const data=Buffer.alloc(size);
    let done=0;
    while(done<size){const n=fs.readSync(this.#fd,data,done,size-done,offset+done);if(!n)throw new Error('Truncated archive');done+=n;}
    return data;
  }
  read(key,maxBytes=64*1024*1024) {
    if(this.#fd===undefined)throw new Error('Archive is closed');
    if(!Number.isSafeInteger(maxBytes)||maxBytes<1||maxBytes>64*1024*1024)throw new Error('Invalid read bound');
    key=normalizeAssetKey(key);
    const hash=assetHash(key),matches=[];
    for(let i=0;i<this.#count;i++)if(this.#table.readUInt32LE(4+i*4)===hash)matches.push(i);
    if(matches.length!==1)throw new Error(`Expected one asset match, found ${matches.length}`);
    const at=4+this.#count*4+matches[0]*24;
    const size=Number(this.#table.readBigUInt64LE(at)),offset=Number(this.#table.readBigUInt64LE(at+8)),flags=this.#table.readBigUInt64LE(at+16);
    if(!Number.isSafeInteger(size)||!Number.isSafeInteger(offset)||size<4||size>maxBytes||offset<this.#table.length||offset%2048||flags!==0n)throw new Error('Unsupported asset entry');
    const bytes=this.#read(size,offset);
    if(key.endsWith('.dds')?bytes.toString('ascii',0,4)!=='DDS ':bytes.toString('hex',0,4)!=='53524d08')throw new Error('Unexpected asset format');
    return bytes;
  }
  close(){if(this.#fd!==undefined){fs.closeSync(this.#fd);this.#fd=undefined;}}
}
