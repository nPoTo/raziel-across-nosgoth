// SPDX-License-Identifier: GPL-3.0-or-later
// Pure packed-vertex decoding. No filesystem, game calls, or camera transform.
export function decodeReaverVertices({bytes,count,bones,scale,policy}){
 if(policy?.id!=='legacy_v11'||policy.nativeIntegrationEnabled!==false||policy.vertexStride!==16||policy.positionOffset!==0||policy.boneOffset!==10||policy.uvOffset!==12||policy.uvEncoding!=='float32_high16')throw Error('Unsupported legacy vertex policy');
 if(!Buffer.isBuffer(bytes)||!Number.isInteger(count)||count<1||count>policy.maxVertices||bytes.length!==count*policy.vertexStride||!Number.isInteger(bones)||bones<1||bones>policy.maxBones)throw Error('Invalid vertex input');
 if(!Array.isArray(scale)||scale.length!==3||scale.some(x=>!Number.isFinite(x)||x<=0))throw Error('Invalid scale');
 const positions=new Float32Array(count*3),uv=new Float32Array(count*2),boneIndices=new Uint16Array(count),scratch=new DataView(new ArrayBuffer(4));
 for(let i=0;i<count;i++){
  const at=i*policy.vertexStride,bone=bytes.readInt16LE(at+policy.boneOffset);
  if(bone<0||bone>=bones)throw Error('Invalid vertex bone');boneIndices[i]=bone;
  for(let k=0;k<3;k++){positions[i*3+k]=bytes.readInt16LE(at+k*2)*scale[k];if(!Number.isFinite(positions[i*3+k]))throw Error('Position overflow');}
  for(let k=0;k<2;k++){
   scratch.setUint32(0,bytes.readUInt16LE(at+policy.uvOffset+k*2)*65536,true);
   uv[i*2+k]=scratch.getFloat32(0,true);if(!Number.isFinite(uv[i*2+k]))throw Error('Nonfinite UV');
  }
 }
 return {positions,uv,boneIndices};
}
