// SPDX-License-Identifier: GPL-3.0-or-later
// Normal constant-light pass only. Input opacity must come from the draw path,
// not an independently applied second fade after the packed alpha conversion.
export function reaverVertexColors({policy,graphics,renderOpacity,frame,expectedFrame}){
 const refuse=reason=>({valid:false,reason,rgba:null});
 if(policy?.id!=='constant_light'||policy.nativeIntegrationEnabled!==false||policy.objectConstantLightMask!==0x4000000||
 policy.instanceColorScaleMask!==0x40000000||policy.colorMode!==0||policy.vertexColorMultiplier!==2||policy.maxVertices!==2048)throw Error('Unsupported vertex color policy');
 if(!graphics?.valid||!Number.isSafeInteger(frame)||frame<0||frame!==expectedFrame)return refuse('incoherent_colors');
 for(const k of ['objectFlags','flags2','colorMode'])if(!Number.isSafeInteger(graphics[k])||graphics[k]<0||graphics[k]>0xffffffff)return refuse('missing_color_mode');
 if(!(graphics.objectFlags&policy.objectConstantLightMask)||(graphics.flags2&policy.instanceColorScaleMask)||graphics.colorMode!==0||graphics.alternateColors!=null)return refuse('special_lighting_or_colors');
 if(!(graphics.colors instanceof Uint32Array)||!graphics.colors.length||graphics.colors.length>policy.maxVertices||graphics.vertices!==graphics.colors.length)return refuse('invalid_color_count');
 if(!Number.isFinite(renderOpacity)||renderOpacity<0||renderOpacity>1)return refuse('missing_draw_opacity');
 const rgba=new Float32Array(graphics.colors.length*4),opacity=Math.fround(renderOpacity);
 for(let i=0;i<graphics.colors.length;i++){
  const word=graphics.colors[i];
  // Native188670 packs AARRGGBB after truncating/clamping CPU alpha.
  // Shader6 doubles all four normalized channels, including alpha. Preserve
  // values above1 here; the texture multiplication occurs before output clamp.
  rgba[i*4]=((word>>>16)&255)*2/255;rgba[i*4+1]=((word>>>8)&255)*2/255;rgba[i*4+2]=(word&255)*2/255;
  rgba[i*4+3]=Math.min(255,Math.max(0,Math.trunc(Math.fround((word>>>24)*opacity))))*2/255;
 }
 return {valid:true,reason:'constant_light_normal_pass',rgba,opacityAlreadyApplied:true,runtimeEligible:false};
}
