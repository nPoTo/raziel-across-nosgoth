// SPDX-License-Identifier: GPL-3.0-or-later
// Exact legacy material flags from current-image 190b10. Sampling quality is
// explicitly base-level linear here; donor anisotropic mip sampling is pending.
export function reaverMaterialState(batch){
 if(!Number.isInteger(batch?.material)||batch.material<0||batch.material>0xffffffff||
 !Number.isInteger(batch.textureFlags)||batch.textureFlags<0||batch.textureFlags>255||!Number.isFinite(batch.scroll))throw Error('Invalid current material');
 const material=(batch.textureFlags&0x10)?(batch.material&0xffe7ffff)>>>0:batch.material;
 return {repeat:(material&0x180000)!==0,linear:true,scroll:batch.scroll,
  alphaTest:(material&0x800)?-1:(material&0x40000000)?16/255:1/255,
  samplerQuality:'base_level_linear',donorMipSampling:false};
}
