// SPDX-License-Identifier: GPL-3.0-or-later
// Exact observed D3D11 output-merger state only. Not a shader approximation.
export function reaverBlendState(material,rows){
 const refuse=reason=>({valid:false,reason,runtimeEligible:false});
 if(!Number.isInteger(material)||material<0||material>0xffffffff||!Array.isArray(rows))return refuse('invalid_material');
 const bits=material&0xe000,found=rows.filter(r=>r.materialBits===bits);
 if(found.length!==1)return refuse('unproved_blend_mode');
 const r=found[0];
 if(r.nativeIntegrationEnabled!==false||![0x2000,0x4000].includes(bits)||r.stateIndex!==bits/0x2000||
  r.srcColor!==5||r.dstColor!==(bits===0x2000?6:2)||r.colorOp!==1||r.srcAlpha!==2||r.dstAlpha!==6||r.alphaOp!==1||r.writeMask!==15||
  r.shaderModeBits!==bits/128||r.setsFogColor!==(bits===0x2000))return refuse('changed_blend_contract');
 // OpenGL enum values are resolved by the native renderer, not serialized GPU handles.
 return {valid:true,stateIndex:r.stateIndex,enabled:true,color:{source:'SRC_ALPHA',destination:r.dstColor===6?'ONE_MINUS_SRC_ALPHA':'ONE',equation:'ADD'},
  alpha:{source:'ONE',destination:'ONE_MINUS_SRC_ALPHA',equation:'ADD'},writeMask:15,
  shaderModeBits:r.shaderModeBits,setsFogColor:r.setsFogColor,shaderVerified:false,runtimeEligible:false};
}

