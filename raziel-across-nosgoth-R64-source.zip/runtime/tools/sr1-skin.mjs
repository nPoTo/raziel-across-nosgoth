// SPDX-License-Identifier: GPL-3.0-or-later
// Skin the ORIGINAL SR1 mesh using its own palette, bind offsets and weights.
// Input matrices are model-relative; SR1 applies the authoritative actor root.
import {quatNormalize} from './retarget-pose.mjs';
export function skinSr1Pose(mesh,bones){
 if(!mesh||!Array.isArray(mesh.positions)||!Array.isArray(bones)||!bones.length||bones.length>128||mesh.joints.length!==mesh.positions.length||mesh.weights.length!==mesh.positions.length)throw Error('Incomplete SR1 skin');
 const matrices=bones.map(b=>{if(!b||!Array.isArray(b.position)||b.position.length!==3||!b.position.every(v=>Number.isFinite(v)&&Math.abs(v)<=1000000))throw Error('Invalid skin transform');const [x,y,z,w]=quatNormalize(b.rotation);return [1-2*(y*y+z*z),2*(x*y-z*w),2*(x*z+y*w),2*(x*y+z*w),1-2*(x*x+z*z),2*(y*z-x*w),2*(x*z-y*w),2*(y*z+x*w),1-2*(x*x+y*y),...b.position];});
 const out=new Float32Array(mesh.positions.length*3);
 for(let i=0;i<mesh.positions.length;i++){
  const v=mesh.positions[i],sum=[0,0,0];if(!Array.isArray(v)||v.length!==3||!v.every(Number.isFinite)||mesh.weights[i].reduce((s,w)=>s+w,0)!==255)throw Error('Invalid skin vertex');
  for(let j=0;j<3;j++){const weight=mesh.weights[i][j];if(!Number.isInteger(weight)||weight<0||weight>255)throw Error('Invalid weight');if(!weight)continue;const bone=mesh.palette[mesh.joints[i][j]],m=matrices[bone],offset=mesh.bindOffsets[bone];if(!m||!offset||!offset.every(Number.isFinite))throw Error('Unmapped weighted bone');const p=v.map((x,k)=>x+offset[k]);for(let k=0;k<3;k++)sum[k]+=weight/255*(m[k*3]*p[0]+m[k*3+1]*p[1]+m[k*3+2]*p[2]+m[9+k]);}
  for(let k=0;k<3;k++){if(!Number.isFinite(sum[k])||Math.abs(sum[k])>1000000)throw Error('Invalid skinned position');out[i*3+k]=sum[k];}
 }
 return out;
}
