// SPDX-License-Identifier: GPL-3.0-or-later
// Actual installed animation FX and PCM remain memory-only.
import assert from 'node:assert/strict';
import crypto from 'node:crypto';
import fs from 'node:fs';
import {chargedHitWave51} from './charged-hit-audio51.mjs';
import {archiveResource,drmSections,smfSamples} from './inspect-audio-resources.mjs';
export function readSwordEvents({groundImpact=false,chargedCast=false}={}) {
 const resource=archiveResource('pcenglish\\raziel.x64.drm'),{data}=resource,sections=drmSections(data),root=sections[0];
 assert(root.relocs.includes(0x38));
 const pointer=data.readUInt32LE(root.start+0x38),list=sections[pointer>>>22],offset=pointer&0x3fffff;
 const clips=[29,30,31,33,34,35,36,38,39,44,45,46,47,48,49,50,53,54,55],events=[];
 const castForms=new Map([[112,1],[115,2],[118,3],[119,4],[116,5],[117,6],[113,7],[120,8],[114,9]]);
 if(chargedCast)clips.push(...castForms.keys());
 const refs=data.readUInt32LE(root.start+0x30),references=sections[refs>>>22],referencesOffset=refs&0x3fffff;
 for(const clip of clips) {
  assert(list.relocs.includes(offset+clip*8));
  const ptr=data.readUInt32LE(list.start+offset+clip*8),section=sections[ptr>>>22];
  let at=section.start+(ptr&0x3fffff),terminated=false;
  for(let i=0;i<1024&&at<section.start+section.size;i++) {
   const header=data.readUInt16LE(at);if(header===65535){terminated=true;break;}
   // Installed Defiance iterator 0x5d510..0x5d617: packed section/type/size/form.
   const size=(((header>>>2)&60)+4)&~7,type=(header>>>8)&3,sourceForm=header>>>12;
   const form=castForms.has(clip)?castForms.get(clip):sourceForm;
   assert(size>=8&&at+size<=section.start+section.size);
   const frame=data.readInt16LE(at+2);
   const reference=data.readUInt32LE(references.start+referencesOffset+clip*4);
   assert.equal(reference>>>16,0xffff);
   const source=sections.findIndex(s=>s.type===2&&s.key===(reference&0xffff));
   assert(source>=0);const keys=data.readUInt16LE(sections[source].start+8);
   if(groundImpact&&clip===36&&type===0&&form===0&&frame===4&&[321,322].includes(data.readUInt16LE(at+12))) {
    for(let selected=1;selected<=9;selected++)events.push({clip:100,form:selected,frame:0,keys:1,id:data.readUInt16LE(at+12),volume:data.readUInt16LE(at+14),pitch:data.readFloatLE(at+20),variance:data.readFloatLE(at+24),group:0,weight:1});
   }
   if(form>=1&&form<=9&&(type===0||type===3)&&!(groundImpact&&clip===36&&frame>=15)) {
    if(type===0) {
     assert.equal(size,32);
     events.push({clip,form,frame,keys,id:data.readUInt16LE(at+12),volume:data.readUInt16LE(at+14),pitch:data.readFloatLE(at+20),variance:data.readFloatLE(at+24),group:0,weight:1});
    } else {
     assert.equal(size,56);
     const group=events.length+1;
     for(let n=0;n<3;n++) {
      const row=at+16+n*12,weight=data.readUInt8(row);
      if(weight)events.push({clip,form,frame,keys,id:data.readUInt16LE(row+2),volume:data.readUInt8(row+1),pitch:data.readFloatLE(row+4),variance:data.readFloatLE(row+8),group,weight});
     }
    }
   }
   at+=size;
  }
  assert(terminated,'Missing FX terminator '+clip);
 }
 return {events,source:{name:resource.name,key:resource.key,size:resource.size,offset:resource.offset}};
}
export function buildLocalAudio(options={}) {
 const resource=archiveResource('pcenglish\\raziel.smf'),general=archiveResource('pcenglish\\generalbank.smf'),fx=readSwordEvents(options);
 const samples=smfSamples(resource.data).map(s=>({...s,resource:resource.name}));
 const known=new Set(samples.map(s=>s.id));
 samples.push(...smfSamples(general.data).filter(s=>!known.has(s.id)).map(s=>({...s,resource:general.name})));
 const ids=new Set(fx.events.map(e=>e.id)),selected=samples.filter(s=>ids.has(s.id));
 assert.equal(selected.length,ids.size,'All sword-form events must resolve to installed PCM');
 const chunks=selected.map(s=>{const data=s.resource===resource.name?resource.data:general.data;return data.subarray(s.offset,s.offset+s.bytes);});
 const generated=[];
 if(options.chargedHit){
  const profiles=JSON.parse(fs.readFileSync(new URL('./local-combat-r51-scope.json',import.meta.url))).tables.sr1ChargedAudio51.rows.map(r=>r.values);
  assert.equal(profiles.length,9);
  for(const p of profiles){
   const sources=[p.sourceLeft,p.sourceRight].map(id=>{
    assert(fx.events.some(e=>e.clip===p.sourceClip&&e.form===p.form&&e.id===id),'Wrong form source');
    const index=selected.findIndex(s=>s.id===id);assert(index>=0);return {...selected[index],pcm:chunks[index]};
   });
   assert(!selected.some(s=>s.id===p.waveId));const wave=chargedHitWave51(p,sources);
   selected.push({id:p.waveId,rate:p.rate,bytes:wave.pcm.length,flags:0,gain:1,resource:'custom-derived-in-RAM',durationMs:p.durationMs});chunks.push(wave.pcm);generated.push(wave.metadata);
   fx.events.push({clip:p.clip,form:p.form,frame:0,keys:1,id:p.waveId,volume:p.volume,pitch:0,variance:0,group:0,weight:1});
  }
 }
 let cursor=0;const records=selected.map(s=>{const result={...s,pcmOffset:cursor};cursor+=s.bytes;return result;});
 const header=Buffer.alloc(32),waves=Buffer.alloc(records.length*24),events=Buffer.alloc(fx.events.length*40);
 header.write('DA44');header.writeUInt32LE(1,4);header.writeUInt32LE(records.length,8);header.writeUInt32LE(fx.events.length,12);header.writeUInt32LE(cursor,16);
 records.forEach((s,i)=>{const p=i*24;[s.id,s.rate,s.pcmOffset,s.bytes,s.flags].forEach((v,k)=>waves.writeUInt32LE(v,p+k*4));waves.writeFloatLE(s.gain,p+20);});
 fx.events.forEach((s,i)=>{const p=i*40;[s.clip,s.form,s.frame,s.keys,records.findIndex(r=>r.id===s.id),s.volume].forEach((v,k)=>events.writeUInt32LE(v,p+k*4));events.writeFloatLE(s.pitch,p+24);events.writeFloatLE(s.variance,p+28);events.writeUInt32LE(s.group,p+32);events.writeUInt32LE(s.weight,p+36);});
 const packet=Buffer.concat([header,waves,events,...chunks]);
 return {packet,hash:crypto.createHash('sha256').update(packet).digest('hex'),waveCount:records.length,eventCount:fx.events.length,pcmBytes:cursor,
  metadata:{source:fx.source,sampleSource:{name:resource.name,key:resource.key,size:resource.size,offset:resource.offset},samples:records,events:fx.events,generated}};
}
