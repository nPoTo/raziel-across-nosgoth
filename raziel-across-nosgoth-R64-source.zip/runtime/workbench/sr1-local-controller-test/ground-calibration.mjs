// SPDX-License-Identifier: GPL-3.0-or-later
import assert from 'node:assert/strict';
import {quatBlend, quatInverse, quatMultiply, quatRotate, rigidFromPackedRender} from '../../tools/retarget-pose.mjs';
import {skinSr1Pose} from '../reaver-force-on-r20/tools/sr1-skin.mjs';

function lowestSole(mesh, bones) {
    const positions = skinSr1Pose(mesh, bones);
    let lowest = Infinity;
    for (let i = 2; i < positions.length; i += 3) lowest = Math.min(lowest, positions[i]);
    assert(Number.isFinite(lowest), 'Measured sole height required');
    return lowest;
}

const difference = (a, b) => a.map((value, k) => value - b[k]);
const median = values => {
    const sorted = values.toSorted((a, b) => a - b);
    const mid = sorted.length >> 1;
    return (sorted[mid] + sorted[(sorted.length - 1) >> 1]) / 2;
};

export function prepareGroundSupport(trajectory, feet, hostRender, authored, responsive) {
    const hostFloor = lowestSole(feet, hostRender.map(matrix => rigidFromPackedRender(matrix)));
    function plantAnkles(world, weight) {
        if (!authored || weight <= 0) return world;
        const planted = [...world];
        for (const [ankle, toe] of [[authored.leftAnkle, authored.leftToe], [authored.rightAnkle, authored.rightToe]]) {
            assert.equal(trajectory.compiled.parents[toe], ankle);
            const joint = world[ankle], tip = world[toe];
            const [, , z, w] = joint.rotation;
            const norm = Math.hypot(z, w);
            assert(norm > 1e-5, 'Standing-foot yaw is singular');
            const level = [0, 0, z / norm, w / norm];
            const rotation = quatBlend(joint.rotation, level, weight);
            const original = difference(tip.position, joint.position);
            const offset = quatRotate(level, trajectory.compiled.hostRest[toe].position);
            planted[ankle] = {...joint, rotation};
            planted[toe] = {position: joint.position.map((v, k) => v + original[k] + weight * (offset[k] - original[k])),
                rotation: quatBlend(tip.rotation, level, weight)};
        }
        return planted;
    }
    function shiftPelvis(world, delta) {
        return world.map((bone, i) => trajectory.below[i] ? {
            rotation: bone.rotation, position: bone.position.map((value, k) => value + delta[k])
        } : bone);
    }
    return {
        sample(donor, aligned, plant = 0) {
            // Same root-relative, heading-free pelvis and leg-ratio conversion as v0.2.
            const unpack = m => rigidFromPackedRender([m[0],m[4],m[8],m[1],m[5],m[9],m[2],m[6],m[10],0,...m.slice(12,15)]);
            const root = unpack(donor.rootMatrix), pelvis = unpack(donor.matrices[1]);
            const inverse = quatInverse(root.rotation), relative = quatMultiply(inverse, pelvis.rotation);
            const length = Math.hypot(relative[2], relative[3]);
            assert(length > 1e-6, 'Ground pelvis heading is singular');
            const removeTwist = [0, 0, -relative[2] / length, relative[3] / length];
            const position = quatRotate(removeTwist, quatRotate(inverse, difference(pelvis.position, root.position)));
            let delta = difference(position, trajectory.sourcePelvisBind).map(v => v * trajectory.scale);
            const excursion = Math.hypot(...delta);
            const envelope = trajectory.hostLeg * trajectory.policy.maxTravelLegPermille / 1000;
            if (authored && excursion > envelope) delta = delta.map(v => v * envelope / excursion);
            assert(authored || excursion <= envelope,
                'Ground pelvis outside the v0.2 envelope');
            const desired = trajectory.hostPelvis.map((v, k) => v + delta[k]);
            const world = plantAnkles(shiftPelvis(aligned.world, difference(desired, aligned.world[1].position)), plant);
            return {world, original: aligned.actorLocalMatrices, floor: lowestSole(feet, world)};
        },
        finish(banks, stopPoseCount = banks[0].length) {
            const standingOffset = median(banks[0].slice(0, stopPoseCount).map(frame => hostFloor - frame.floor));
            const limit = trajectory.hostLeg * trajectory.policy.maxOffsetLegPermille / 1000;
            const support = [];
            const samples = banks.map((bank, index) => bank.map((frame, sample) => {
                // Keep the gait's authored rise. Standing uses a planted support line.
                const offset = index === 0 || index === 4 ? hostFloor - frame.floor : responsive?.fixedMovingSupport ?
                    standingOffset : Math.max(standingOffset, hostFloor - frame.floor);
                assert(Math.abs(offset) <= limit, `Sole correction outside the v0.2 envelope: bank ${index}, sample ${sample}, ${offset} vs ${limit}`);
                const world = shiftPelvis(frame.world, [0, 0, offset]);
                support.push(lowestSole(feet, world) - hostFloor);
                return frame.original.map((matrix, i) => {
                    if (i === 0 || !authored) return [...matrix.slice(0, 10), ...world[i].position];
                    const cols = [[1,0,0],[0,1,0],[0,0,1]].map(axis => quatRotate(world[i].rotation, axis));
                    return [0,1,2].flatMap(k => cols.map(v => v[k])).concat([matrix[9], ...world[i].position]);
                }).flat();
            }));
            const idle = support.slice(0, banks[0].length);
            const moving = support.slice(banks[0].length, banks[0].length + banks[1].length);
            assert((responsive ? idle : support).every(n => n >= -0.001), 'An authored frame crossed the bind sole line');
            return {samples, metrics: {hostFloor, standingOffset, correctionLimit: limit,
                originalIdleSoleRange: [Math.min(...banks[0].map(frame => frame.floor)), Math.max(...banks[0].map(frame => frame.floor))],
                groundedIdleSoleRange: [Math.min(...idle), Math.max(...idle)],
                ...(responsive ? {movingSoleRange: [Math.min(...moving), Math.max(...moving)]} : {})}};
        }
    };
}

export function groundSoleCoefficients(mesh) {
    // Three packed weighted contributions per foot vertex. Kept in RAM only.
    const data = Buffer.alloc(mesh.positions.length * 52);
    mesh.positions.forEach((position, i) => {
        const at = i * 52;
        for (let j = 0; j < 3; j++) {
            const weight = mesh.weights[i][j] / 255;
            const bone = weight ? mesh.palette[mesh.joints[i][j]] : 0;
            data[at + j] = bone;
            const v = at + 4 + j * 16;
            for (let k = 0; k < 3; k++) data.writeFloatLE((position[k] + mesh.bindOffsets[bone][k]) * weight, v + 4 * k);
            data.writeFloatLE(weight, v + 12);
        }
    });
    return data;
}
