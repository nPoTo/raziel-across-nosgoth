// SPDX-License-Identifier: GPL-3.0-or-later
import fs from 'node:fs';
import path from 'node:path';
import { assetHash } from '../../tools/defiance-archive.mjs';
import { composeRig, quatMultiply, quatRotate, validateRig } from '../../tools/retarget-pose.mjs';

const align = (value, boundary) => Math.ceil(value / boundary) * boundary;
const maxResourceBytes = 8 * 1024 * 1024;

function readObject(folder, profile) {
    if (!path.isAbsolute(folder) || profile.archive !== 'bigfile.x64.dat' ||
        profile.resource !== 'pcenglish\\raziel.x64.drm' || assetHash(profile.resource) !== profile.resourceHash) {
        throw new Error('Invalid Defiance motion source');
    }
    const fd = fs.openSync(path.join(folder, profile.archive), 'r');
    try {
        const bytes = fs.fstatSync(fd).size;
        function read(offset, size) {
            if (![offset, size].every(Number.isSafeInteger) || size < 1 || size > maxResourceBytes ||
                offset < 0 || offset > bytes - size) throw new Error('Invalid archive read range');
            const buffer = Buffer.allocUnsafe(size);
            let copied = 0;
            while (copied < size) {
                const length = fs.readSync(fd, buffer, copied, size - copied, offset + copied);
                if (!length) throw new Error('Truncated archive');
                copied += length;
            }
            return buffer;
        }
        const count = read(0, 4).readUInt32LE(0);
        if (count < 1 || count > 100000) throw new Error('Invalid archive index');
        const index = read(4, count * 28);
        let entry = -1, previous = 0;
        for (let i = 0; i < count; ++i) {
            const key = index.readUInt32LE(i * 4);
            if (key < previous) throw new Error('Unsorted archive index');
            previous = key;
            if (key !== profile.resourceHash) continue;
            if (entry !== -1) throw new Error('Ambiguous Raziel resource');
            entry = count * 4 + i * 24;
        }
        if (entry === -1) throw new Error('Missing installed Raziel resource');
        const size = Number(index.readBigUInt64LE(entry));
        const offset = Number(index.readBigUInt64LE(entry + 8));
        if (offset % 2048 || offset < index.length + 4 || index.readBigUInt64LE(entry + 16) !== 0n) {
            throw new Error('Unsupported Raziel resource entry');
        }
        return read(offset, size);
    } finally {
        fs.closeSync(fd);
    }
}

export function readDefianceMotion(folder, profile, combat, additionalClips = []) {
    const object = readObject(folder, profile);
    if (object.length < 8 || object.readUInt32LE(0) !== profile.containerVersion) {
        throw new Error('Unsupported motion container');
    }
    const sections = object.readUInt32LE(4);
    if (!sections || sections > 1024 || 8 + sections * 12 > object.length) throw new Error('Invalid section index');
    let cursor = align(8 + sections * 12, 16);
    const clips = new Map();
    const spans = [];
    for (let i = 0; i < sections; ++i) {
        if (cursor > object.length - 4) throw new Error('Truncated section header');
        const header = 8 + i * 12;
        const size = object.readUInt32LE(header);
        const type = object.readUInt16LE(header + 4);
        const key = object.readUInt32LE(header + 8);
        const relocationStart = cursor;
        const relocations = object.readUInt32LE(cursor);
        const start = cursor + align(4 + relocations * 4, 16);
        cursor = start + align(size, 16);
        if (cursor > object.length) throw new Error('Truncated motion container');
        spans.push({start, size, relocations, relocationStart});
        if (type !== 2) continue;
        if (size < 24 || relocations || key !== object.readUInt16LE(start) ||
            profile.skeletonBones !== object.readUInt16LE(start + 2)) throw new Error('Unsupported motion clip header');
        const clip = object.subarray(start, start + size);
        const variants = clips.get(key) ?? [];
        if (!variants.some(other => other.equals(clip))) variants.push(clip);
        clips.set(key, variants);
    }
    if (cursor !== object.length || !clips.size) throw new Error('Incomplete section index');
    return {clips, ...readRig(object, spans, profile.skeletonBones, combat, additionalClips)};
}

function readRig(object, spans, bones, combat, additionalClips) {
    function follow(section, field, length) {
        const span = spans[section];
        if (!span || field > span.size - 8) throw new Error('Invalid rig pointer slot');
        let found = false;
        for (let i = 0; i < span.relocations; ++i) {
            if (object.readUInt32LE(span.relocationStart + 4 + i * 4) === field) found = true;
        }
        if (!found) throw new Error('Missing rig relocation');
        const record = object.readUInt32LE(span.start + field);
        const nextSection = record >>> 22;
        const offset = record & 0x3fffff;
        const next = spans[nextSection];
        if (!next || offset > next.size - length) throw new Error('Invalid rig pointer target');
        return {section: nextSection, offset, start: next.start + offset};
    }
    const root = spans[0];
    const modelCount = object.readUInt16LE(root.start + 0x20);
    if (modelCount < 1 || modelCount > 16) throw new Error('Invalid Raziel model count');
    const list = follow(0, 0x28, modelCount * 8);
    const models = Array.from({length: modelCount}, (_, i) => follow(list.section, list.offset + i * 8, 24));
    const model = models.find(record => object.readUInt32LE(record.start) === 0x04c2042f &&
        object.readUInt32LE(record.start + 4) === bones && object.readUInt32LE(record.start + 8) === 25);
    if (!model) throw new Error('Missing Defiance Raziel rig');
    const segments = follow(model.section, model.offset + 16, bones * 40);
    const parents = [], rest = [];
    for (let bone = 0; bone < bones; ++bone) {
        const at = segments.start + bone * 40;
        if (object.readFloatLE(at + 12) !== 1) throw new Error('Unexpected model segment');
        parents.push(object.readInt32LE(at + 24));
        rest.push({position: [0, 4, 8].map(offset => object.readFloatLE(at + offset)), rotation: [0, 0, 0, 1]});
    }
    validateRig({parents, rest});
    for (const {runtimeClip, archiveKey} of additionalClips) {
        const references = follow(0, 0x30, (runtimeClip + 1) * 4);
        if (object.readUInt32LE(references.start + runtimeClip * 4) !== 0xffff0000 + archiveKey) {
            throw new Error(`Defiance guard clip reference mismatch: ${runtimeClip}`);
        }
    }
    let strikeKey, strikeTravel, strikeCombo;
    if (combat) {
        const data = follow(0, 0x48, 0x68);
        const attacks = follow(data.section, data.offset + 0x60, (combat.donorSlot + 1) * 8);
        const variants = follow(attacks.section, attacks.offset + combat.donorSlot * 8, 8);
        const descriptor = follow(variants.section, variants.offset, 2);
        const runtime = object.readUInt16LE(descriptor.start);
        const animationList = follow(0, 0x30, (runtime + 1) * 4);
        const reference = object.readUInt32LE(animationList.start + runtime * 4);
        if (runtime !== combat.runtimeClip || reference >>> 16 !== 0xffff ||
            (reference & 0xffff) !== combat.archiveKey) throw new Error('Defiance ground strike descriptor mismatch');
        strikeKey = reference & 0xffff;
        if (combat.travel) {
            const travel = follow(variants.section, variants.offset, 0x3c);
            strikeTravel = {
                mode: object.readUInt16LE(travel.start + 0x24),
                advanceKeys: object.readUInt16LE(travel.start + 0x26),
                distance: object.readFloatLE(travel.start + 0x38)
            };
            for (const [field, value] of Object.entries(strikeTravel)) {
                if (combat.travel[field] !== value) throw new Error(`Defiance strike travel mismatch: ${field}`);
            }
        }
        if (combat.combo) {
            let next;
            for (const expected of combat.combo) {
                if (expected.ordinal === 0) {
                    const slots = follow(data.section, data.offset + 0x60, (expected.donorSlot + 1) * 8);
                    const group = follow(slots.section, slots.offset + expected.donorSlot * 8, 8);
                    next = follow(group.section, group.offset, 0x80);
                }
                if (!next) throw new Error('Incomplete Defiance attack descriptor chain');
                const runtime = object.readUInt16LE(next.start);
                const references = follow(0, 0x30, (runtime + 1) * 4);
                const reference = object.readUInt32LE(references.start + runtime * 4);
                if (runtime !== expected.runtimeClip || reference !== (0xffff0000 + expected.archiveKey) ||
                    object.readUInt16LE(next.start + 0x24) !== expected.mode ||
                    object.readUInt16LE(next.start + 0x26) !== expected.advanceKeys ||
                    object.readFloatLE(next.start + 0x38) !== expected.distance ||
                    (expected.chainKey !== undefined && object.readUInt8(next.start + 0x13) !== expected.chainKey)) {
                    throw new Error(`Defiance attack descriptor mismatch: ${expected.id}`);
                }
                next = object.readBigUInt64LE(next.start + 0x78) ? follow(next.section, next.offset + 0x78, 0x80) : null;
            }
            strikeCombo = combat.combo.filter(row => row.donorSlot === combat.donorSlot);
        }
    }
    const attackCatalog = combat?.catalogSlots?.map(slot => {
        const data = follow(0, 0x48, 0x68);
        const attacks = follow(data.section, data.offset + 0x60, (slot + 1) * 8);
        const variants = follow(attacks.section, attacks.offset + slot * 8, 8);
        const entries = [];
        let descriptor = follow(variants.section, variants.offset, 0x80);
        while (descriptor) {
            if (entries.length >= 16) throw new Error('Unbounded Defiance attack chain');
            const at = descriptor.start;
            const runtimeClip = object.readUInt16LE(at);
            const table = follow(0, 0x30, (runtimeClip + 1) * 4);
            const ref = object.readUInt32LE(table.start + runtimeClip * 4);
            if ((ref >>> 16) !== 0xffff) throw new Error('Unexpected attack animation reference');
            entries.push({
                runtimeClip, archiveKey: ref & 0xffff, continueKey: object.readUInt8(at + 0x13),
                mode: object.readUInt16LE(at + 0x24), advanceKeys: object.readUInt16LE(at + 0x26),
                distance: object.readFloatLE(at + 0x38)
            });
            descriptor = object.readBigUInt64LE(at + 0x78) ?
                follow(descriptor.section, descriptor.offset + 0x78, 0x80) : null;
        }
        return {slot,entries};
    });
    const animationReferences=follow(0,0x30,121*4);
    const runtimeRawReferences=Array.from({length:121},(_,i)=>object.readUInt32LE(animationReferences.start+i*4));
    const runtimeArchiveKeys=runtimeRawReferences.map(v=>v&0xffff);
    const virtualData=follow(0,0x48,0xd8),virtualMap=follow(virtualData.section,virtualData.offset+0xd0,138*2);
    const virtual137Index=object.readInt16LE(virtualMap.start+137*2);
    if(virtual137Index<0||virtual137Index>511)throw Error('Invalid original TK virtual descriptor');
    const virtual137Descriptor=follow(virtualData.section,virtualData.offset+0x78,(virtual137Index+1)*16);
    const virtual137Clips=[0,2,4].map(offset=>object.readUInt16LE(virtual137Descriptor.start+virtual137Index*16+offset));
    return {rig: {parents, rest}, strikeKey, strikeTravel, strikeCombo, attackCatalog,runtimeArchiveKeys,virtual137Index,virtual137Clips};
}

function readChannel(clip, offset, keyCount) {
    if (offset > clip.length - 4) throw new Error('Truncated animation channel');
    const kind = clip.readUInt16LE(offset);
    const runEntries = clip.readInt16LE(offset + 2);
    if (kind > 2 || (kind === 2 && runEntries < 2)) throw new Error('Unknown animation channel encoding');
    const runBytes = kind === 2 ? align(runEntries, 4) : 0;
    const count = kind === 0 ? keyCount : kind === 1 ? 1 : runEntries;
    const floatStart = offset + 4 + runBytes;
    const next = floatStart + count * 4;
    if (next > clip.length) throw new Error('Truncated animation values');
    const values = Array.from({length: count}, (_, i) => clip.readFloatLE(floatStart + i * 4));
    if (values.some(value => !Number.isFinite(value))) throw new Error('Non-finite animation value');
    if (kind !== 2) return {next, sample: key => values[kind === 1 ? 0 : key]};

    const runs = [];
    let lastKey = 0, startValue = values[0];
    for (let i = 1; i < count; ++i) {
        const length = clip[offset + 4 + i];
        if (!length) throw new Error('Empty delta run');
        const delta = values[i];
        runs.push({lastKey: lastKey + length, length, startValue, delta});
        lastKey += length;
        startValue += delta;
    }
    if (lastKey < keyCount - 1 || !Number.isFinite(startValue)) throw new Error('Incomplete delta channel');
    return {
        next,
        sample(key) {
            const run = runs.find(value => key <= value.lastKey);
            return run.startValue + run.delta * (key - (run.lastKey - run.length)) / run.length;
        }
    };
}

export function decodeDefianceClip(clip, expectedBones) {
    if (!Buffer.isBuffer(clip) || clip.length < 24 || clip.readUInt16LE(2) !== expectedBones) {
        throw new Error('Missing animation clip');
    }
    const keyCount = clip.readUInt16LE(8);
    const timePerKey = clip.readInt16LE(10);
    const sections = clip[4];
    if (keyCount < 1 || keyCount > 2048 || timePerKey < 1 || sections < 1 || sections > 3) {
        throw new Error('Unsupported animation timing');
    }
    const maskStart = 12 + 4 * sections;
    const maskStride = align(expectedBones * 3, 8) / 8;
    const groups = ['rotation', 'scale', 'translation'];
    const masks = new Map();
    let maskEnd = maskStart + 1;
    groups.forEach((group, i) => {
        if (clip[maskStart] & (1 << i)) {
            masks.set(group, maskEnd);
            maskEnd += maskStride;
        }
    });
    const sectionStarts = Array.from({length: sections}, (_, i) => {
        const field = 12 + 4 * i;
        return field + clip.readInt32LE(field);
    });
    if (sectionStarts.some((start, i) => start < maskEnd || start > clip.length ||
        (i > 0 && start < sectionStarts[i - 1]))) throw new Error('Invalid animation section ranges');

    let offset = sectionStarts[0];
    const channels = Array.from({length: expectedBones}, (_, bone) => {
        const boneStart = offset;
        const decoded = {};
        for (const [group, start] of masks) {
            decoded[group] = Array.from({length: 3}, (_, axis) => {
                const bit = bone * 3 + axis;
                if (!(clip[start + (bit >> 3)] & (1 << (bit & 7)))) return null;
                const channel = readChannel(clip, offset, keyCount);
                offset = channel.next;
                return channel.sample;
            });
        }
        if (sectionStarts.some(start => boneStart < start && start < offset)) {
            throw new Error('Channel crosses a declared section boundary');
        }
        return decoded;
    });
    if (clip.length - offset >= 16 || sectionStarts.some(start => start > align(offset, 16))) {
        throw new Error('Unconsumed animation data');
    }

    return {
        key: clip.readUInt16LE(0), keyCount, timePerKey,
        sample(time, loop = true) {
            if (!Number.isFinite(time) || time < 0) throw new Error('Invalid animation sample time');
            const fractionalKey = loop ? (time / timePerKey) % keyCount : Math.min(time / timePerKey, keyCount - 1);
            const from = Math.floor(fractionalKey);
            const to = loop ? (from + 1) % keyCount : Math.min(from + 1, keyCount - 1);
            const fraction = fractionalKey - from;
            return channels.map(bone => Object.fromEntries(Object.entries(bone).map(([group, axes]) => [
                group, axes.map(sample => {
                    if (!sample) return null;
                    const start = sample(from);
                    let delta = sample(to) - start;
                    if (group === 'rotation') {
                        if (delta > 0.5) delta -= 1;
                        else if (delta < -0.5) delta += 1;
                    }
                    return start + fraction * delta;
                })
            ])));
        }
    };
}

export function sampleDefiancePose(clip, rig, time, loop = true) {
    const channels = clip.sample(time, loop);
    const local = channels.map((bone, index) => {
        const angles = bone.rotation ?? [];
        let rotation = [0, 0, 0, 1];
        // Original channels are in turns. Compose Z, Y, X in parent space.
        for (const axis of [2, 1, 0]) {
            const halfAngle = (angles[axis] ?? 0) * Math.PI;
            const turn = [0, 0, 0, Math.cos(halfAngle)];
            turn[axis] = Math.sin(halfAngle);
            rotation = quatMultiply(rotation, turn);
        }
        const position = rig.rest[index].position.map((value, axis) => bone.translation?.[axis] ?? value);
        return {position, rotation};
    });
    const world = composeRig({parents: rig.parents, local}, {position: [0, 0, 0], rotation: [0, 0, 0, 1]});
    const matrices = world.map(({position, rotation}) => {
        const columns = [[1,0,0], [0,1,0], [0,0,1]].flatMap(axis => [...quatRotate(rotation, axis), 0]);
        return [...columns, ...position, 1];
    });
    const rootMatrix = matrices[0];
    // Legacy auxiliary bones are outside the existing SR1 correspondence.
    matrices.push(...Array.from({length: 25}, () => [...rootMatrix]));
    return {valid: true, rootMatrix, matrices, baseHierarchyCandidate: {parents: rig.parents}};
}
