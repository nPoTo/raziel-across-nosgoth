// SPDX-License-Identifier: GPL-3.0-or-later
import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import {checkSheets} from '../../tools/preflight-sheets.mjs';
import {hudComposition} from '../reaver-menu-r2/tools/hud-composition.mjs';
import {hudTextureBank,hudFrame} from '../reaver-menu-r2/tools/hud-packet.mjs';
import {loadHudLegacyResources} from '../reaver-menu-r2/tools/hud-legacy-resources.mjs';
import {loadReaverHdTextures} from '../../tools/inspect-reaver-hd-textures.mjs';

const root = path.resolve(import.meta.dirname, '../..');

export function buildLocalReaverHud({charged=false}={}) {
    const doc = JSON.parse(fs.readFileSync(path.join(root, 'workbench/reaver-menu-r2/config/sheets/hud-display.json')));
    assert.deepEqual(checkSheets(doc), []);
    const layout = doc.tables.reaverHudDisplay.rows[0].values;
    const recorded = JSON.parse(fs.readFileSync(path.join(root, 'reports/discovery/reaver-menu-first-hud-1793254488160.json'))).layouts;
    const blade = loadHudLegacyResources().textures.find(t => t.id === 1438);
    assert(blade, 'Missing installed Defiance HUD blade');
    const fills=charged?loadHudLegacyResources({includeBarFrames:true}).textures.filter(t=>t.id!==1413&&t.id!==1438):[];
    const textures = [blade, ...loadReaverHdTextures(Array.from({length:18}, (_,i) => 1414 + i)).textures,...[...new Map(fills.map(t=>[t.id,t])).values()]];
    const ids = textures.map(t => t.id);
    // These constant fields identify a static bank, not a runtime or donor process.
    const bankIdentity = {hostPid:1,writerPid:1,donorPid:1,hostCreation:1,writerCreation:1,donorCreation:1,nonce:1,deadline:1};
    const bank = hudTextureBank(layout, bankIdentity, textures);
    const frame = selected => hudFrame(layout, bankIdentity, selected, 1, hudComposition(layout, {
        valid:true, realm:selected === 1 ? 2 : 1, selected, unlocks:0xff << 11, charge:0, fade:1,
        meter:recorded.meter, orbs:recorded.orbs
    }, ids));
    const frames = Array.from({length:9}, (_,i) => frame(i + 1));
    const header = Buffer.alloc(40);
    header.writeUInt32LE(bank.length);
    frames.forEach((bytes,i) => header.writeUInt32LE(bytes.length, 4 + i * 4));
    const buffer = Buffer.concat([header,bank,...frames]);
    return {buffer, hash:crypto.createHash('sha256').update(buffer).digest('hex'), length:buffer.length,
        count:textures.length, layout};
}
