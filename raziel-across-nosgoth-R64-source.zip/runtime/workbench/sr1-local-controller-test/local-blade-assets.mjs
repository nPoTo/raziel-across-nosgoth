// SPDX-License-Identifier: GPL-3.0-or-later
import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import { checkSheets } from '../../tools/preflight-sheets.mjs';
import { loadReaverLegacyResources } from '../../tools/inspect-reaver-legacy-resources.mjs';
import { loadReaverHdTextures } from '../../tools/inspect-reaver-hd-textures.mjs';
import { readInstalledSr1Rig } from '../../tools/sr1-offline-rig.mjs';
import { parseSr1Srm } from '../../tools/sr1-srm.mjs';
import { composeRig } from '../../tools/retarget-pose.mjs';
import { reaverVertexColors } from '../../tools/reaver-vertex-color.mjs';
import { reaverBlendState } from '../../tools/reaver-blend-state.mjs';
import { reaverMaterialState } from '../../tools/reaver-material-state.mjs';
import { readDefianceMotion } from './defiance-motion.mjs';
import {archiveResource,drmSections} from './inspect-audio-resources.mjs';

const root = path.resolve(import.meta.dirname, '../..');
const read = file => JSON.parse(fs.readFileSync(path.join(root, file)));
function tables(file) {
    const doc = read(file);
    assert.deepEqual(checkSheets(doc), [], file);
    return doc.tables;
}

const sub = (a, b) => a.map((value, i) => value - b[i]);
const dot = (a, b) => a.reduce((sum, value, i) => sum + value * b[i], 0);
const cross = ([x, y, z], [u, v, w]) => [y*w-z*v, z*u-x*w, x*v-y*u];
const normal = v => {
    const len = Math.hypot(...v);
    assert(len > 1e-3);
    return v.map(value => value / len);
};

export function buildLocalBlade({authoredBladeSocket = false, measuredBladeOrigin = false,allForms=false,form=0} = {}) {
    if(allForms){
        const forms=Array.from({length:9},(_,i)=>buildLocalBlade({authoredBladeSocket,measuredBladeOrigin,form:i+1}));
        const header=Buffer.alloc(40);header.write('BF45');forms.forEach((b,i)=>header.writeUInt32LE(b.packet.length,4+i*4));
        const packet=Buffer.concat([header,...forms.map(f=>f.packet)]);
        return {...forms[0],packet,hash:crypto.createHash('sha256').update(packet).digest('hex'),forms:forms.map((f,i)=>({form:i+1,hash:f.hash,bytes:f.packet.length,batches:f.batches}))};
    }
    const scope = tables('workbench/sr1-local-controller-test/local-blade-scope.json').sr1StandaloneBlade.rows[0].values;
    const formats = tables('config/sheets/reaver-resource-format.json');
    const palm = formats.reaverPalmBasis.rows[0].values;
    const scalePolicy = tables('config/sheets/reaver-visual-scenario.json').reaverVisualScale.rows[0].values;
    const profile = tables('workbench/sr1-local-controller-test/defiance-motion-scope.json').defianceLocalMotion.rows[0].values;
    const games = Object.fromEntries(read('config/games.json').games.map(game => [game.id, game.directory]));
    const {rig} = readDefianceMotion(games.defiance, profile);
    const donor = composeRig({parents: rig.parents, local: rig.rest}, {position:[0,0,0], rotation:[0,0,0,1]});
    const mesh = parseSr1Srm(fs.readFileSync(path.join(games['soul-reaver'], '1/OBJECT/RAZIEL_1.SRM')));
    const host = readInstalledSr1Rig(games['soul-reaver'], tables('config/sheets/retarget-rig.json').retargetOfflineRig.rows[0].values, mesh);
    assert.equal(host.parents[scalePolicy.targetChild], scalePolicy.targetParent);
    assert.equal(rig.parents[scalePolicy.sourceChild], scalePolicy.sourceParent);
    assert.equal(palm.sourceSocket, scope.sourceSocket);
    const scale = Math.hypot(...sub(host.positions[scalePolicy.targetChild], host.positions[scalePolicy.targetParent])) /
        Math.hypot(...sub(donor[scalePolicy.sourceChild].position, donor[scalePolicy.sourceParent].position));
    assert(Number.isFinite(scale) && scale > 0 && scale < 4);
    assert(!measuredBladeOrigin || (authoredBladeSocket && Number.isInteger(scope.drawnOffsetZMilli) &&
        scope.drawnOffsetZMilli < 0 && scope.drawnOffsetZMilli > -100000));
    const socketOffsetZ = measuredBladeOrigin ? scope.drawnOffsetZMilli / 1000 : 0;
    const wrist = donor[palm.sourceWrist].position;
    const z = normal(sub(donor[palm.sourceFinger].position, wrist));
    const thumb = sub(donor[palm.sourceThumb].position, wrist);
    const x = normal(sub(thumb, z.map(value => value * dot(thumb, z))));
    const axes = [x, cross(z, x), z];

    const {models, textures} = loadReaverLegacyResources();
    const model = models.find(item => item.slot === scope.legacyModel);
    assert(model && model.bones === 10 && model.vertexCount === 1046);
    assert(model.colors?.length === model.vertexCount && model.rig.length === model.bones);
    const bind = [];
    for (const [i, bone] of model.rig.entries()) {
        assert(bone.translation.every(Number.isFinite) && (i === 0 ? bone.parent === -1 : bone.parent >= 0 && bone.parent < i));
        bind[i] = bone.translation.map((value, k) => value + (i ? bind[bone.parent][k] : 0));
    }
    const colorPolicy = formats.reaverVertexColor.rows[0].values;
    const colors = reaverVertexColors({policy:colorPolicy, graphics:{
        valid:true, objectFlags:colorPolicy.objectConstantLightMask, flags2:0, colorMode:0,
        vertices:model.vertexCount, colors:model.colors
    }, renderOpacity:1, frame:1, expectedFrame:1});
    assert(colors.valid, colors.reason);
    const verts = Buffer.alloc(model.vertexCount * 9 * 4);
    for (let i = 0; i < model.vertexCount; ++i) {
        const local = bind[model.boneIndices[i]].map((value, k) => value + model.positions[i*3+k]);
        const position = authoredBladeSocket ? [local[0], local[1], local[2] + socketOffsetZ] :
            axes.map(axis => dot(axis, local));
        const entry = [...position.map(value => value * scale),
            ...model.uv.subarray(i*2, i*2+2), ...colors.rgba.subarray(i*4, i*4+4)];
        entry.forEach((value, k) => verts.writeFloatLE(value, (i*9+k)*4));
    }
    let selectedPart=scope.basePart,materialIds=null;
    if(form){
        // Installed 15ae60/15aed0: canonical forms 1..9 map directly, material index=form-1.
        // 159e40 uses the tune row's part and four model material replacement groups.
        const {data}=archiveResource('pcenglish\\sreaver.x64.drm'),sections=drmSections(data);
        const follow=p=>{const encoded=data.readUInt32LE(p),s=sections[encoded>>>22],at=encoded&0x3fffff;assert(s&&at<s.size);return s.start+at;};
        const tune=follow(sections[0].start+0x48),rows=follow(tune);
        selectedPart=data.readUInt32LE(rows+(form-1)*16+8)-1;
        const modelArray=follow(sections[0].start+0x28),modelStart=follow(modelArray);
        let group=follow(modelStart+0x80)+8;materialIds=new Map();
        for(let i=0;i<4;i++){
            const table=follow(group),count=data.readUInt32LE(group+16);
            assert.equal(data.readUInt32LE(table),13);assert(count<=4);
            const id=data.readUInt32LE(table+form*4);assert(id>0&&id<8192);
            for(let n=0;n<count;n++){const material=follow(group+24+n*8);materialIds.set(data.readUInt32LE(material)&0x1fff,id);}
            group+=24+count*8;
        }
    }
    const meshBatches = model.batches.filter(batch => batch.part === scope.basePart || batch.part===selectedPart);
    assert(meshBatches.length && meshBatches.length <= scope.maxBatches);
    const ids = meshBatches.map(batch => materialIds?.get(batch.material&0x1fff) ?? (batch.material & 0x1fff));
    const hd = loadReaverHdTextures([...new Set(ids)]).textures;
    const blendRows = formats.reaverBlendState.rows.map(row => row.values);
    const bodies = meshBatches.map((batch, i) => {
        const t = hd.find(item => item.id === ids[i]) ?? textures.find(item => item.id === ids[i]);
        assert(t && t.pixels.length === t.width * t.height * 4);
        const blend = reaverBlendState(batch.material, blendRows);
        const state = reaverMaterialState({material:batch.material, textureFlags:0, scroll:0});
        assert(blend.valid);
        const meta = Buffer.alloc(24);
        [batch.indices.length,t.width,t.height,blend.stateIndex,Number(state.repeat)]
            .forEach((value, k) => meta.writeUInt32LE(value, k*4));
        meta.writeFloatLE(state.alphaTest, 20);
        const indices = Buffer.alloc(batch.indices.length * 2);
        batch.indices.forEach((value, j) => indices.writeUInt16LE(value, j*2));
        return [meta, indices, Buffer.from(t.pixels.buffer, t.pixels.byteOffset, t.pixels.byteLength)];
    });
    const header = Buffer.alloc(8);
    header.writeUInt32LE(model.vertexCount, 0);
    header.writeUInt32LE(bodies.length, 4);
    const packet = Buffer.concat([header, verts, ...bodies.flat()]);
    return {packet, hash:crypto.createHash('sha256').update(packet).digest('hex'),
        scale, batches:bodies.length, vertexCount:model.vertexCount};
}
