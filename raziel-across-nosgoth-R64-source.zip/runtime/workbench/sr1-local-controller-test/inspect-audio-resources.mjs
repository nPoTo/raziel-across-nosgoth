// SPDX-License-Identifier: GPL-3.0-or-later
// Reads installed resources in RAM; reports scalar metadata only.
import fs from 'node:fs';
import path from 'node:path';
import {assetHash} from '../../tools/defiance-archive.mjs';
const root=path.resolve(import.meta.dirname,'../..');
const folder=JSON.parse(fs.readFileSync(root+'/config/games.json')).games.find(x=>x.id==='defiance').directory;
export function archiveResource(name) {
 const fd=fs.openSync(path.join(folder,'bigfile.x64.dat'),'r');
 try {
  const head=Buffer.alloc(4);fs.readSync(fd,head,0,4,0);const n=head.readUInt32LE();
  const index=Buffer.alloc(n*28);fs.readSync(fd,index,0,index.length,4);
  const key=assetHash(name);let found=-1;
  for(let i=0;i<n;i++)if(index.readUInt32LE(i*4)===key){if(found!==-1)throw Error('Ambiguous hash');found=i;}
  if(found<0)throw Error('Absent '+name);
  const at=n*4+found*24,size=Number(index.readBigUInt64LE(at)),offset=Number(index.readBigUInt64LE(at+8));
  if(size>32*1024*1024)throw Error('Oversized resource');
  const data=Buffer.alloc(size);if(fs.readSync(fd,data,0,size,offset)!==size)throw Error('Short read');
  return {name,key,size,offset,data};
 }finally{fs.closeSync(fd);}
}
const align=(x,n)=>Math.ceil(x/n)*n;
export function locateSample(id) {
 const fd=fs.openSync(path.join(folder,'bigfile.x64.dat'),'r'),matches=[];
 try {
  const read=(at,n)=>{const b=Buffer.alloc(n);if(fs.readSync(fd,b,0,n,at)!==n)throw Error('Archive bounds');return b;};
  const count=read(0,4).readUInt32LE(),index=read(4,count*28);
  for(let i=0;i<count;i++) {
   const p=count*4+i*24,size=Number(index.readBigUInt64LE(p)),offset=Number(index.readBigUInt64LE(p+8));
   if(size<64)continue;const h=read(offset,8);if(h.readUInt32LE()!==0x31c6b8)continue;
   let at=48;for(let j=0;j<h.readUInt16LE(6);j++) {
    if(at>size-16)throw Error('Sample bounds');const d=read(offset+at-36,52),n=d.readUInt32LE(36);
    if(n<16||at+n>size)throw Error('Sample size');
    if(d.readUInt16LE(4)===id)matches.push({hash:index.readUInt32LE(i*4),resourceBytes:size,resourceOffset:offset,sampleOffset:at+16,bytes:n-16,rate:d.readUInt32LE(40)});
    at+=align(n,4)+36;
   }
  }
  return matches;
 }finally{fs.closeSync(fd);}
}
export function smfSamples(data) {
 if(data.readUInt32LE()!==0x31c6b8)throw Error('Unknown SMF version');
 const count=data.readUInt16LE(6),samples=[];let at=48;
 for(let i=0;i<count;i++) {
  const size=data.readUInt32LE(at),rate=data.readUInt32LE(at+4);
  if(size<16 || at+size>data.length || rate<1000 || rate>192000 || size%2)throw Error(`Invalid wave descriptor ${i} at ${at}: size ${size} rate ${rate}`);
  samples.push({index:i,id:data.readUInt16LE(at-32),variant:data.readUInt16LE(at-30),flags:data.readUInt32LE(at-28),gain:data.readFloatLE(at-20),rate,loopStart:data.readUInt32LE(at+8),loopEnd:data.readUInt32LE(at+12),offset:at+16,bytes:size-16,durationMs:(size-16)*500/rate});
  at+=align(size,4)+36;
 }
 if(data.length-(at-36)<0 || data.length-(at-36)>4)throw Error('Unexpected SMF tail');
 return samples;
}
export function drmSections(data) {
 if(data.readUInt32LE()!==11)throw Error('Unknown DRM version');
 const count=data.readUInt32LE(4),sections=[];let at=align(8+count*12,16);
 for(let i=0;i<count;i++) {
  const h=8+i*12,size=data.readUInt32LE(h),type=data.readUInt16LE(h+4),key=data.readUInt32LE(h+8);
  const relocations=data.readUInt32LE(at),relocs=Array.from({length:relocations},(_,k)=>data.readUInt32LE(at+4+k*4));
  const start=at+align(4+relocations*4,16);at=start+align(size,16);
  sections.push({index:i,type,key,size,start,relocs});
 }
 if(at!==data.length)throw Error('DRM section bounds');
 return sections;
}
if(process.argv.includes('--inspect')) {
 const raz=archiveResource('pcenglish\\raziel.x64.drm'),sections=drmSections(raz.data),r=sections[0];
 const list=raz.data.readUInt32LE(r.start+0x38)&0x3fffff;
 for(const clip of [20,21,22,33,34,35,36,37,38,39,40,41,42]) {
  const ptr=raz.data.readUInt32LE(r.start+list+clip*8),section=sections[ptr>>>22];
  if(!section){console.log({clip,ptr});continue;}
  const at=section.start+(ptr&0x3fffff),end=section.start+section.size;
  console.log(JSON.stringify({clip,section:section.index,size:section.size,relocs:section.relocs,words:Array.from({length:Math.min(70,(end-at)/4)},(_,i)=>raz.data.readUInt32LE(at+i*4))}));
 }
 for(const name of ['raziel','mreaver','sreaver']) {
  const object=archiveResource('pcenglish\\'+name+'.x64.drm'),parts=drmSections(object.data),r=parts[0];
  console.log(JSON.stringify({name,root:r,words:Array.from({length:Math.min(r.size/4,96)},(_,i)=>object.data.readUInt32LE(r.start+i*4))}));
 }
 const smf=archiveResource('pcenglish\\raziel.smf');const samples=smfSamples(smf.data);console.log(JSON.stringify({name:smf.name,count:samples.length,samples:samples.slice(0,6)}));
}
