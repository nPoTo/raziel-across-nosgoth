// SPDX-License-Identifier: GPL-3.0-or-later
// Custom full-hit sound, derived from each installed form's swing. Never persisted as an asset.
import assert from 'node:assert/strict';
import crypto from 'node:crypto';
const sha=bytes=>crypto.createHash('sha256').update(bytes).digest('hex');
export function chargedHitWave51(profile,sources) {
 const p=profile;
 assert.equal(sources.length,2);assert(p.form>=1&&p.form<=9&&p.clip===101);
 assert(p.rate===24000&&p.durationMs>=300&&p.durationMs<=1000&&p.peakPermille>0&&p.peakPermille<=750);
 assert(p.bodyHz>=30&&p.bodyHz<=120&&p.pitchPermille>=400&&p.pitchPermille<=1000);
 const sourceInfo=sources.map(s=>{
  assert(s.pcm.length>2&&s.pcm.length%2===0&&s.rate>=1000&&s.rate<=192000&&Number.isFinite(s.gain)&&s.gain>0);
  // Anchor the transient at the strongest 8ms window of the authentic swing.
  const count=s.pcm.length/2,window=Math.max(1,Math.round(s.rate*.008));let sum=0,best=0,at=0;
  for(let i=0;i<count;i++){
   const v=s.pcm.readInt16LE(i*2)/32768;sum+=v*v;
   if(i>=window){const old=s.pcm.readInt16LE((i-window)*2)/32768;sum-=old*old;}
   if(sum>best){best=sum;at=Math.max(0,i-window+1);}
  }
  assert(best>0,'Silent source swing');
  return {...s,onset:Math.max(0,at-Math.round(s.rate*.004)),sha256:sha(s.pcm)};
 });
 const sample=(s,seconds)=>{
  const x=s.onset+seconds*s.rate*s.gain*p.pitchPermille/1000,i=Math.floor(x),a=x-i;
  if(i<0||i>=s.pcm.length/2-1)return 0;
  return ((1-a)*s.pcm.readInt16LE(i*2)+a*s.pcm.readInt16LE(i*2+2))/32768;
 };
 let seed=(parseInt(sourceInfo[0].sha256.slice(0,8),16)^p.form)>>>0;
 const noise=()=>{seed^=seed<<13;seed^=seed>>>17;seed^=seed<<5;return (seed>>>0)/2147483647.5-1;};
 const count=Math.round(p.rate*p.durationMs/1000),mixed=new Float64Array(count);let low=0,rumble=0,prior=0,phase=0,peak=0;
 const lowAlpha=1-Math.exp(-2*Math.PI*240/p.rate),rumbleAlpha=1-Math.exp(-2*Math.PI*150/p.rate);
 for(let i=0;i<count;i++){
  const t=i/p.rate,source=(sample(sourceInfo[0],t)+sample(sourceInfo[1],t))*.5;
  low+=lowAlpha*(source-low);rumble+=rumbleAlpha*(noise()-rumble);
  phase+=2*Math.PI*p.bodyHz*(1+.9*Math.exp(-30*t))/p.rate;
  const body=Math.sin(phase)*Math.exp(-11*t),crack=(source-prior)*Math.exp(-20*t);prior=source;
  const envelope=Math.min(1,t/.0025)*Math.min(1,(count-1-i)/(p.rate*.035));
  // Keep the form's pitched swing and its own transient; add a short low thunder body.
  const value=envelope*(.9*source*Math.exp(-4*t)+1.1*low*Math.exp(-5*t)+.48*body+.48*rumble*Math.exp(-7*t)+.85*crack);
  assert(Number.isFinite(value));mixed[i]=value;peak=Math.max(peak,Math.abs(value));
 }
 assert(peak>0);const pcm=Buffer.alloc(count*2),scale=(p.peakPermille/1000)*32767/peak;let square=0,max=0;
 for(let i=0;i<count;i++){const v=Math.round(mixed[i]*scale);assert(Math.abs(v)<32767);pcm.writeInt16LE(v,i*2);square+=v*v;max=Math.max(max,Math.abs(v));}
 assert.equal(pcm.readInt16LE(0),0);assert.equal(pcm.readInt16LE(pcm.length-2),0);
 return {pcm,metadata:{form:p.form,custom:true,id:p.waveId,rate:p.rate,durationMs:p.durationMs,peak:max,rms:Math.sqrt(square/count),sha256:sha(pcm),
  sources:sourceInfo.map(s=>({id:s.id,sha256:s.sha256,onsetSamples:s.onset,rate:s.rate})),profile:p}};
}
