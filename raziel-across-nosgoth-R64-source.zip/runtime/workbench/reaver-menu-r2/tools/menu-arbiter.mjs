// SPDX-License-Identifier: GPL-3.0-or-later
// Pure admission/ownership policy. No guessed native ABI or game writes.
export function deviceMenuBits(p,{device,buttons=0,keys=[]}){
 if(!Number.isInteger(buttons)||buttons<0||buttons>65535||!Array.isArray(keys))throw Error('Invalid input');
 if(device==='controller')return buttons;
 if(device!=='keyboard')throw Error('Unknown device');
 const k=new Set(keys);return (k.has(p.quickKey)?p.downMask:0)|(k.has(p.confirmKey)?p.confirmMask:0)|(k.has(p.cancelKey)?p.cancelMask:0)|(k.has(p.glyphKey)?p.selectMask:0)|(k.has(p.previousKey)?p.leftMask:0)|(k.has(p.nextKey)?p.rightMask:0);
}
export class MenuArbiter{
 constructor(p){this.p=p;this.session=null;this.state='drain';this.previous=0;this.serial=0;this.lastSequence=-1;this.pending=null;}
 step(s){
  const p=this.p,b=deviceMenuBits(p,s),owned=s.owned===true&&typeof s.session==='string'&&s.session.length>0;
  const result={state:'inactive',hostBlocked:0,donorSelectBlocked:owned,donorNeutral:false,poseSuspended:false,command:null};
  if(!owned){this.session=null;this.pending=null;this.state='drain';return result;}
  if(this.session!==s.session){this.session=s.session;this.state='drain';this.previous=b;this.pending=null;this.lastSequence=-1;}
  if(!Number.isSafeInteger(s.sequence)||s.sequence<0||!Number.isSafeInteger(s.now)||!Number.isSafeInteger(s.tick))throw Error('Invalid receipt');
  const fresh=s.sequence>this.lastSequence&&s.now>=s.tick&&s.now-s.tick<=p.maxInputAgeMs;
  const rising=fresh?b&~this.previous:0;
  if(fresh){this.previous=b;this.lastSequence=s.sequence;}
  const uiMask=p.dpadMask|p.confirmMask|p.cancelMask;
  const neutral=(b&(uiMask|p.selectMask))===0;
  const stop=()=>{this.pending=null;this.state='drain';result.donorNeutral=true;result.poseSuspended=true;result.hostBlocked=uiMask;};
  if(!fresh||!s.foreground||!['gameplay','glyph','shift'].includes(s.context)){stop();return {...result,state:this.state};}
  // An authenticated native Glyph context owns its original navigation.
  // Do not classify a generic map/pause/mode12 as this context.
  if(s.context==='glyph'){
   this.state='glyph';this.pending=null;return {...result,state:this.state,donorNeutral:true,poseSuspended:true};
  }
  if(s.context==='shift'){
   this.state='shift';this.pending=null;return {...result,state:this.state,hostBlocked:uiMask,donorNeutral:true,poseSuspended:true};
  }
  if(this.state==='glyph'||this.state==='shift')this.state='drain';
  // On completion do not show donor motion/Reavers in the wrong realm.
  if(!['material','spectral'].includes(s.hostRealm)||s.hostRealm!==s.donorRealm){
   return {...result,state:'realm_wait',hostBlocked:uiMask,donorNeutral:true,poseSuspended:true};
  }
  if(this.state==='drain'){
   if(neutral)this.state='gameplay';
   return {...result,state:this.state,hostBlocked:uiMask|p.selectMask,donorNeutral:true};
  }
  if(rising&p.selectMask){this.state='drain';this.pending=null;return {...result,state:this.state,donorNeutral:true,poseSuspended:true};}
  if(this.state==='pending'){
   if(s.nativeResult?.id===this.pending.id){
    if(s.nativeResult.status==='denied'){this.pending=null;this.state='drain';}
    else if(s.nativeResult.status==='accepted'){this.pending.tick=s.now;this.state='await_native';}
   }else if(s.now-this.pending.tick>p.requestTimeoutMs){this.pending=null;this.state='drain';}
   return {...result,state:this.state,hostBlocked:uiMask,donorNeutral:true,poseSuspended:true};
  }
  if(this.state==='await_native'){
   if(s.now-this.pending.tick>p.requestTimeoutMs){this.pending=null;this.state='drain';}
   return {...result,state:this.state,hostBlocked:uiMask,donorNeutral:true,poseSuspended:true};
  }
  if(this.state==='selector'){
   result.hostBlocked=uiMask;result.donorNeutral=true;
   if(rising&p.cancelMask)this.state='drain';
   else if((rising&p.confirmMask)&&s.nativeEligible===true){
    this.pending={id:this.session+':'+(++this.serial),tick:s.now,from:s.hostRealm};this.state='pending';
    result.command={kind:'native_shift_request',id:this.pending.id,from:s.hostRealm};
   }
   return {...result,state:this.state};
  }
  const dpad=b&p.dpadMask,edge=rising&p.dpadMask;
  result.hostBlocked=p.dpadMask;
  if(dpad===p.downMask&&edge===p.downMask){this.state='selector';result.hostBlocked=uiMask;result.donorNeutral=true;}
  else if((dpad===p.leftMask||dpad===p.rightMask)&&edge===dpad)result.command={kind:'donor_reaver_select',direction:dpad===p.leftMask?'previous':'next'};
  return {...result,state:this.state};
 }
}
export function layoutReaverWidget(p,viewport,source){
 for(const n of [viewport.width,viewport.height,source.width,source.height])if(!Number.isFinite(n)||n<=0)throw Error('Invalid viewport/widget');
 const region={x:viewport.width*p.zoneLeftPermille/1000,y:viewport.height*(1-(p.zoneBottomPermille+p.zoneHeightPermille)/1000),width:viewport.width*p.zoneWidthPermille/1000,height:viewport.height*p.zoneHeightPermille/1000};
 const scale=Math.min(region.width/source.width,region.height/source.height);
 return {x:region.x,y:region.y+region.height-source.height*scale,width:source.width*scale,height:source.height*scale,background:false};
}
