// SPDX-License-Identifier: GPL-3.0-or-later
// Original decoded images stay in RAM. Only quads and scalar state cross this API.
import {layoutReaverWidget} from './menu-arbiter.mjs';
export function hudComposition(p,s,textureIds){
 if(!s.valid||!Number.isInteger(s.selected)||s.selected<1||s.selected>9||![1,2].includes(s.realm)||!Number.isInteger(s.unlocks)||s.unlocks<0||!Number.isFinite(s.charge)||s.charge<0||s.charge>1||!Number.isFinite(s.fade)||s.fade<0||s.fade>1)throw Error('Invalid source HUD state');
 const available=new Set(textureIds),out=[],push=(id,xy,uv=[0,0,1,1],alpha=s.fade)=>{if(!available.has(id))throw Error('Missing original HUD texture '+id);out.push({id,blend:1,xy,uv,rgba:[1,1,1,alpha]});};
 const quad=(x,y,w,h,rotation=0,pivotX=w/2,pivotY=h/2)=>{const c=Math.cos(rotation),n=Math.sin(rotation);return [[0,0],[w,0],[w,h],[0,h]].flatMap(([a,b])=>[x+(a-pivotX)*c-(b-pivotY)*n,y+(a-pivotX)*n+(b-pivotY)*c]);};
 // The horizontal native blade points +X. Its separate CCW rotation points UP.
 // Keep original transparent padding and aspect ratio. No texture stretching.
 const scale=p.bladeScalePermille/1000;
 push(1438,quad(p.circleX,p.bladeBaseY,1024*scale,256*scale,-Math.PI/2,p.bladePivotX*scale,p.bladePivotY*scale));
 // Native fill uses a texture-animation frame, cropped in geometry AND UV.
 // A missing fill at nonzero charge is refused instead of inventing energy.
 if(s.charge>0){if(!s.fill||!Number.isFinite(s.fill.min)||!Number.isFinite(s.fill.max)||s.fill.min<0||s.fill.max>1||s.fill.max<=s.fill.min)throw Error('Unresolved charge artwork');const u=s.fill.min+(s.fill.max-s.fill.min)*s.charge;push(s.fill.id,quad(p.circleX,p.bladeBaseY,1024*scale*u,256*scale,-Math.PI/2,p.bladePivotX*scale,p.bladePivotY*scale),[0,0,u,1]);}
 // Main icon CW, as in the user's vertical reference. Spectral realm has only
 // its legal normal Reaver; donor unlock bits never grant host progression.
 const selected=s.realm===2?1:s.selected;
 push(1413+selected,quad(p.circleX,p.circleY,p.circleSize,p.circleSize,Math.PI/2));
 if(s.realm===1){
  if(!s.orbs||s.orbs.length!==20||s.orbs.some(x=>!Number.isFinite(x))||!s.meter||s.meter.length!==3||!Number.isFinite(s.meter[2])||s.meter[2]<=0)throw Error('Unresolved native orb layout');
  const k=p.circleSize/s.meter[2],cx=s.meter[0]+s.meter[2]/2,cy=s.meter[1]+s.meter[2]/2;
  for(let id=2;id<=9;id++)if((s.unlocks&(1<<(id+9)))!==0){const i=(id-2)*2,dx=(s.orbs[i]-cx)*k,dy=(s.orbs[i+1]-cy)*k,x=p.circleX-dy,y=p.circleY+dx,w=s.orbs[16]*k,h=s.orbs[17]*k;
   if(w<=0||h<=0)throw Error('Invalid native orb size');push(1421+id,quad(x,y,w,h,Math.PI/2));if(selected===id){const a=s.orbs[18]*k,b=s.orbs[19]*k;if(a<=0||b<=0)throw Error('Invalid native halo size');push(1431,quad(x,y,a,b,Math.PI/2));}
  }
 }
 if(out.length>p.maxQuads)throw Error('HUD quad budget');return out;
}
export function hudViewportQuads(p,quads,viewport){
 const box=layoutReaverWidget({zoneLeftPermille:p.leftPermille,zoneBottomPermille:p.bottomPermille,zoneWidthPermille:p.widthPermille,zoneHeightPermille:p.heightPermille},viewport,p),k=box.width/p.width;
 return quads.map(q=>({...q,xy:q.xy.map((v,i)=>v*k+(i%2?box.y:box.x))}));
}
