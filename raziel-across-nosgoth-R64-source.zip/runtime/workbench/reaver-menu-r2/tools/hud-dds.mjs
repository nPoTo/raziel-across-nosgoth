// SPDX-License-Identifier: GPL-3.0-or-later
// Pure RAM-only rectangular BC1/BC3 DDS decode, reuses existing block decoder.
import {decodeMip} from '../../../tools/memory-render-packets.mjs';
export function decodeHudDDS(b,p){
 if(!Buffer.isBuffer(b)||b.length<128||b.length>p.maxDdsBytes||b.toString('ascii',0,4)!=='DDS '||b.readUInt32LE(4)!==124||b.readUInt32LE(76)!==32||b.readUInt32LE(112)!==0||b.readUInt32LE(24)>1)throw Error('HUD DDS header/bound');
 const width=b.readUInt32LE(16),height=b.readUInt32LE(12),mips=b.readUInt32LE(28)||1,format=b.toString('ascii',84,88),stride={DXT1:8,DXT5:16}[format];
 if(!stride||!width||!height||width>p.maxDimension||height>p.maxDimension||width*height*4>p.maxRgbaBytes||mips>Math.floor(Math.log2(Math.max(width,height)))+1)throw Error('Unsupported HUD DDS format/dimensions');
 let length=128;for(let level=0;level<mips;level++)length+=Math.max(1,Math.ceil((width>>level)/4))*Math.max(1,Math.ceil((height>>level)/4))*stride;
 if(length!==b.length)throw Error('HUD DDS mip length');
 const pixels=Buffer.alloc(width*height*4),cols=Math.ceil(width/4),rows=Math.ceil(height/4);
 for(let by=0;by<rows;by++)for(let bx=0;bx<cols;bx++){
  const at=128+(by*cols+bx)*stride,tile=decodeMip({format,side:4,bytes:b.subarray(at,at+stride)});
  for(let y=0;y<4&&by*4+y<height;y++)for(let x=0;x<4&&bx*4+x<width;x++)tile.copy(pixels,((by*4+y)*width+bx*4+x)*4,(y*4+x)*4,(y*4+x+1)*4);
 }
 return {width,height,mips,format,pixels};
}
