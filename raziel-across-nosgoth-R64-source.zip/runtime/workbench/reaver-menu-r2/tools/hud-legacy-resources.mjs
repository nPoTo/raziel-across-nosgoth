// SPDX-License-Identifier: GPL-3.0-or-later
// Bounded Reaver resource decoding only. Payloads remain in RAM; no renderer.
import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import {pathToFileURL} from 'node:url';
import {assetHash} from '../../../tools/defiance-archive.mjs';
import {decodeHudDDS} from './hud-dds.mjs';
import {decodeReaverVertices} from '../../../tools/reaver-legacy-vertices.mjs';
import {checkSheets} from '../../../tools/preflight-sheets.mjs';
export function loadHudLegacyResources({writeReport=false,includeBarFrames=false,barClips=[8,9]}={}){
 if(!Array.isArray(barClips)||barClips.length!==2||barClips.some(x=>!Number.isInteger(x)||x<1||x>11))throw Error('Measured HUD bar clips required');
const hudSheet=JSON.parse(fs.readFileSync('workbench/reaver-menu-r2/config/sheets/hud-legacy-resource.json','utf8').replace(/^\uFEFF/,''));if(checkSheets(hudSheet).length)throw Error('Invalid HUD resource policy');const hudPolicy=hudSheet.tables.hudLegacyResource.rows[0].values;let decodedBytes=0;
const vertexSheet=JSON.parse(fs.readFileSync('config/sheets/reaver-resource-format.json'));
if(checkSheets(vertexSheet).length)throw Error('Invalid vertex sheet');
const vertexPolicy=vertexSheet.tables.reaverLegacyVertexFormat.rows[0].values;
const expected='fc6a406ff7ac9b5eb7788dc7a65d335e1c1aad9236618112671975b71d2daddc';
const m=JSON.parse(fs.readFileSync('reports/local-inspection.json')).modules.find(x=>x.game==='defiance');
const executable=fs.readFileSync(m.file);
if(crypto.createHash('sha256').update(executable).digest('hex')!==expected)throw Error('Unsupported executable');
function stringAt(rva){
 const s=m.sections.find(s=>rva>=s.rva&&rva+32<=s.rva+s.rawSize);if(!s)throw Error('Unbacked string');
 const p=s.rawOffset+rva-s.rva,end=executable.indexOf(0,p);if(end<p||end>p+32)throw Error('Unbounded string');
 return executable.toString('ascii',p,end);
}
if(stringAt(0x5e0cf0)!=='English'||stringAt(0x5e0d90)!=='PC%s\\')throw Error('Resource prefix changed');
function wordAt(rva){const s=m.sections.find(s=>rva>=s.rva&&rva+4<=s.rva+s.rawSize);if(!s)throw Error('Unbacked format table');return executable.readUInt32LE(s.rawOffset+rva-s.rva);}
for(const [fileFormat,internal,dxgi] of [[5,5,71],[9,7,77]])if(wordAt(0x5dcda0+fileFormat*4)!==internal||wordAt(0x528fc0+internal*4)!==dxgi)throw Error('Texture format table changed');
const file=path.join(path.dirname(m.file),'bigfile.x64.dat'),fd=fs.openSync(file,'r');
const resources=[],ramModels=[],ramTextures=[];let textureReferences;const requiredLegacy=new Set([1413,1438]);
try{
 const size=fs.fstatSync(fd).size;
 const read=(n,p)=>{if(!Number.isSafeInteger(n)||!Number.isSafeInteger(p)||n<1||n>hudPolicy.maxContainerBytes||p<0||p>size-n)throw Error('HUD resource read bound '+JSON.stringify({n,p,fileBytes:size}));const b=Buffer.alloc(n);if(fs.readSync(fd,b,0,n,p)!==n)throw Error('Short read');return b;};
 const count=read(4,0).readUInt32LE();if(!count||count>100000)throw Error('Index count');
 const table=read(count*28,4);
 for(let i=0;i<count;i++){
  if(i&&table.readUInt32LE(i*4)<table.readUInt32LE((i-1)*4))throw Error('Unsorted index');
  const at=count*4+i*24,n=Number(table.readBigUInt64LE(at)),p=Number(table.readBigUInt64LE(at+8));
  if(!Number.isSafeInteger(n)||!Number.isSafeInteger(p)||n<1||p<4+table.length||p%2048||p>size-n||table.readBigUInt64LE(at+16)!==0n)throw Error('Unsupported archive entry');
 }
 for(const extension of ['drm','vrm']){
  const key='pcenglish\\raziel_hud.x64.'+extension,hash=assetHash(key),matches=[];
  for(let i=0;i<count;i++)if(table.readUInt32LE(i*4)===hash)matches.push(i);
  if(matches.length!==1)throw Error('Ambiguous/missing exact Reaver resource');
  const at=count*4+matches[0]*24,n=Number(table.readBigUInt64LE(at)),offset=Number(table.readBigUInt64LE(at+8)),b=read(n,offset);
  const modelCandidates=[];let p=-1;
  while((p=b.indexOf(Buffer.from([0x2f,0x04,0xc2,0x04]),p+1))>=0){
   if(p+12>b.length)throw Error('Truncated model header');
   modelCandidates.push({offset:p,bones:b.readUInt32LE(p+4),extraBones:b.readUInt32LE(p+8)});
  }
  let container;
  if(extension==='drm'){
   const align16=x=>Math.ceil(x/16)*16;
   const bounded=(p,n)=>{if(!Number.isSafeInteger(p)||!Number.isSafeInteger(n)||p<0||n<0||p>b.length-n)throw Error('DRM range');};
   if(b.readUInt32LE(0)!==11)throw Error('DRM version');
   const count=b.readUInt32LE(4);if(!count||count>1024)throw Error('DRM section count');
   bounded(8,count*12);
   const sections=Array.from({length:count},(_,i)=>{const p=8+i*12;return {index:i,size:b.readUInt32LE(p),type:b.readUInt16LE(p+4),skip:b.readUInt16LE(p+6),sharedId:b.readUInt32LE(p+8)};});
   let cursor=align16(8+count*12);
   for(const s of sections){
    bounded(cursor,4);s.relocationCount=b.readUInt32LE(cursor);
    const bytes=align16(4+s.relocationCount*4);bounded(cursor,bytes);
    s.relocationOffset=cursor;s.dataOffset=cursor+bytes;
    bounded(s.dataOffset,align16(s.size));cursor=s.dataOffset+align16(s.size);
   }
   let pointers=0;const relocations=new Map();
   for(const s of sections){
    const seen=new Set();
    for(let i=0;i<s.relocationCount;i++){
     const slot=b.readUInt32LE(s.relocationOffset+4+i*4);
     if(slot>s.size-8||seen.has(slot))throw Error('DRM pointer slot');seen.add(slot);
     const encoded=b.readUInt32LE(s.dataOffset+slot),target=sections[encoded>>>22],at=encoded&0x3fffff;
     if(!target||at>=target.size)throw Error('DRM pointer target');pointers++;
     relocations.set(s.dataOffset+slot,{section:target.index,offset:at,fileOffset:target.dataOffset+at});
    }
   }
   if(cursor!==b.length)throw Error('DRM trailing/missing bytes');
   const root=sections[0],modelCount=b.readInt16LE(root.dataOffset+0x20),array=relocations.get(root.dataOffset+0x28);
   if(modelCount!==12||!array||array.offset+modelCount*8>sections[array.section].size)throw Error('Native model array');
   const models=Array.from({length:modelCount},(_,i)=>{
    const p=relocations.get(array.fileOffset+i*8);if(!p||p.offset+12>sections[p.section].size||b.readUInt32LE(p.fileOffset)!==0x04c2042f)throw Error('Native model pointer');
    const bones=b.readUInt32LE(p.fileOffset+4),extraBones=b.readUInt32LE(p.fileOffset+8),base=p.fileOffset;
    const range=(field,bytes)=>{const r=relocations.get(base+field);if(!r||bytes<0||r.offset>sections[r.section].size-bytes)throw Error('Model data range');return r.fileOffset;};
    // Installed 189f70 -> thunk189cb0 -> worker1894f0: 40-byte segments,
    // inclusive vertex ranges at +20/+22; 16-byte packed vertices, bone at +10.
    const vertexCount=b.readUInt32LE(base+0x28);
    if(!vertexCount||vertexCount>65535||bones+extraBones>256)throw Error('Model limits');
    const vertices=range(0x30,vertexCount*16),segments=range(0x10,(bones+extraBones)*40);
    const coverage=new Uint8Array(vertexCount),boneRanges=[];
    for(let bone=0;bone<bones+extraBones;bone++){
     const first=b.readInt16LE(segments+bone*40+20),last=b.readInt16LE(segments+bone*40+22);
     if(last===-1){boneRanges.push({bone,first,last,count:0});continue;}
     if(first<0||last<first||last>=vertexCount)throw Error('Bone vertex range');
     for(let v=first;v<=last;v++){
      if(coverage[v]++||b.readInt16LE(vertices+v*16+10)!==bone)throw Error('Bone ownership mismatch');
     }
     boneRanges.push({bone,first,last,count:last-first+1});
    }
    if(coverage.some(x=>x!==1))throw Error('Incomplete vertex ownership');
    const positionScale=[0x18,0x1c,0x20].map(o=>b.readFloatLE(base+o));
    if(positionScale.some(x=>!Number.isFinite(x)||x<=0))throw Error('Invalid coordinate scale');
    const decoded=decodeReaverVertices({bytes:b.subarray(vertices,vertices+vertexCount*16),count:vertexCount,bones:bones+extraBones,scale:positionScale,policy:vertexPolicy});
    const coordinateBounds=Array.from({length:3},(_,k)=>{let min=Infinity,max=-Infinity;for(let v=0;v<vertexCount;v++){const x=decoded.positions[v*3+k];min=Math.min(min,x);max=Math.max(max,x);}return {min,max};});
    // 189f70 consumes linked triangle batches from +90, remapped by1ace90.
    const batches=[],ramBatches=[];let batch=relocations.get(base+0x90);const visited=new Set();
    if(!batch)throw Error('Missing triangle batches');
    while(true){
     if(visited.has(batch.fileOffset)||batches.length>1024||batch.offset>sections[batch.section].size-2)throw Error('Invalid batch chain');
     visited.add(batch.fileOffset);const at=batch.fileOffset,indices=b.readInt16LE(at);
     if(indices===0)break;
     if(indices<0||indices%3||batch.offset>sections[batch.section].size-24-indices*2)throw Error('Triangle batch bounds');
     for(let k=0;k<indices;k++)if(b.readUInt16LE(at+24+k*2)>=vertexCount)throw Error('Triangle vertex index');
     const material=b.readUInt32LE(at+4);
     batches.push({part:b.readUInt16LE(at+2),indices,triangles:indices/3,material,textureReference:material&0x1fff});
     ramBatches.push({part:b.readUInt16LE(at+2),material,indices:Uint16Array.from({length:indices},(_,k)=>b.readUInt16LE(at+24+k*2))});
     batch=relocations.get(at+16);if(!batch)throw Error('Missing batch successor');
    }
    const textureAnimations=[];const anim=relocations.get(base+0x78);if(anim){let q=anim.fileOffset;const end=sections[anim.section].dataOffset+sections[anim.section].size;if(q>end-4)throw Error('HUD texture animation header');const sets=b.readUInt32LE(q);q+=4;if(sets>64)throw Error('HUD texture animation sets');for(let n=0;n<sets;n++){if(q>end-4)throw Error('HUD texture frame count');const frames=b.readUInt32LE(q);q+=4;if(frames>10000||q>end-frames*4)throw Error('HUD texture frame range');const ids=Uint32Array.from({length:frames},(_,k)=>b.readUInt32LE(q+k*4)&0x1fff);q+=frames*4;textureAnimations.push(ids);if([1,2,6].includes(i)&&ids.length&&ids[0])requiredLegacy.add(ids[0]);}}
    if(includeBarFrames&&barClips.includes(i))for(const set of textureAnimations)for(const id of set)if(id)requiredLegacy.add(id);
    ramModels.push({slot:i,bones,vertexCount,...decoded,batches:ramBatches,textureAnimations});
    return {slot:i,section:p.section,offset:p.offset,bones,extraBones,vertexCount,vertexStride:16,segmentStride:40,positionScale,boneRanges,vertexOwnershipVerified:true,batches,textureAnimationSetFrameCounts:textureAnimations.map(s=>s.length),animationFirstTextureIds:textureAnimations.map(s=>s[0]??0),decodedInRam:true,coordinateBounds};
   });
   for(const slot of [1,2,6])if(models[slot].bones!==1||models[slot].vertexCount!==3||models[slot].extraBones)throw Error('Live HUD model evidence mismatch');
   const table=relocations.get(root.dataOffset+0x80);if(!table)throw Error('Texture references missing');
   textureReferences=[];
   for(let i=0;i<=1024;i++){
    if(table.offset+i*4+4>sections[table.section].size)throw Error('Texture references bounds');
    const id=b.readUInt16LE(table.fileOffset+i*4);if(!id)break;
    if(i===1024)throw Error('Texture references limit');textureReferences.push(id);
   }
   for(const model of models)for(const batch of model.batches)if(batch.textureReference&&!textureReferences.includes(batch.textureReference))throw Error('Batch texture missing from object');
   container={version:11,sections,pointers,models,textureReferences,consumedBytes:cursor,evidence:'reports/discovery/rea-defiance-drm-stream-15ca80.json'};
  }else{
   if(!textureReferences)throw Error('DRM must precede VRM');let cursor=32;const textures=[];
   for(const reference of textureReferences){
    if(cursor>b.length-16)throw Error('VRM header bounds');
    const id=b.readUInt16LE(cursor),format=b.readUInt16LE(cursor+2),width=b.readUInt16LE(cursor+4),height=b.readUInt16LE(cursor+6),bytes=b.readUInt32LE(cursor+8),mips=b.readUInt16LE(cursor+12)+1;
    if(id!==reference||!width||!height||width>16384||height>16384||mips>16||!bytes||bytes>b.length-cursor-16)throw Error('VRM metadata mismatch');
    const decoder={5:'DXT1',9:'DXT5'}[format],block={5:8,9:16}[format];
    if(!decoder||width<1||height<1||width>2048||height>2048||mips>Math.floor(Math.log2(Math.max(width,height)))+1)throw Error('Unsupported HUD texture: '+JSON.stringify({id,format,width,height,mips,bytes}));
    let mipBytes=0;for(let level=0;level<mips;level++)mipBytes+=Math.max(1,Math.ceil((width>>level)/4))*Math.max(1,Math.ceil((height>>level)/4))*block;
    if(mipBytes!==bytes)throw Error('Compressed mip chain size');
    let pixels=null;
    if(requiredLegacy.has(id)){decodedBytes+=width*height*4;if(decodedBytes>hudPolicy.maxDecodedRgbaBytes)throw Error('HUD decoded RAM limit');const dds=Buffer.alloc(128+bytes);dds.write('DDS ');dds.writeUInt32LE(124,4);dds.writeUInt32LE(height,12);dds.writeUInt32LE(width,16);dds.writeUInt32LE(mips,28);dds.writeUInt32LE(32,76);dds.write(decoder,84);b.copy(dds,128,cursor+16,cursor+16+bytes);pixels=decodeHudDDS(dds,{maxDdsBytes:16777216,maxDimension:hudPolicy.maxTextureDimension,maxRgbaBytes:hudPolicy.maxDecodedRgbaBytes}).pixels;ramTextures.push({id,width,height,pixels});}
    textures.push({id,format,width,height,mips,bytes,decoder,decodedInRam:!!pixels,...(pixels?{basePixelBytes:pixels.length,basePixelSha256:crypto.createHash('sha256').update(pixels).digest('hex')}:{})});cursor+=16+bytes;
   }
   if(cursor!==b.length)throw Error('VRM trailing/missing bytes');
   container={textures,consumedBytes:cursor,evidence:'reports/discovery/rea-defiance-vrm-stream-1ac770.json'};
  }
  resources.push({key,hash,index:matches[0],size:n,offset,headerWords:Array.from({length:8},(_,i)=>b.readUInt32LE(i*4)),modelCandidates,container});
 }
 const result={moduleSha256:expected,file,entries:count,resources,
  evidence:['reports/discovery/rea-defiance-object-request-175cc0.json','reports/discovery/rea-defiance-object-load-174db0.json'],
  prefixEvidence:{initializationRva:'0x19e440',languageStringRva:'0x5e0cf0',formatStringRva:'0x5e0d90'},
  textureFormatEvidence:{creationFunction:'0x190a60',wrapperFunction:'0x100340',descriptorFunction:'0x100060',fileToInternalTable:'0x5dcda0',internalToDxgiTable:'0x528fc0',mapping:[{file:5,internal:5,dxgi:71,decoder:'DXT1'},{file:9,internal:7,dxgi:77,decoder:'DXT5'}]},
  gameResourceFilesWritten:0,nativeIntegrationEnabled:false,
  limits:['Exact lowercase backslash keys uniquely match archive; native normalization routine not traced',
   'Packed geometry and UV decoded in RAM; current bone matrices, selected parts and vertex colors are not integrated',
   'Triangle batches and texture references validated; no host rendering or effect transfer implemented',
   'HD texture substitution and final rendering/material equivalence remain unproved']};
 if(writeReport)fs.writeFileSync('reports/discovery/reaver-menu-hud-legacy-resources-20261029.json',JSON.stringify(result,null,2)+'\n');
 return {metadata:result,models:ramModels,textures:ramTextures};
}finally{fs.closeSync(fd);}
}
if(process.argv[1]&&pathToFileURL(path.resolve(process.argv[1])).href===import.meta.url){
 const {metadata:r}=loadHudLegacyResources({writeReport:true});
 console.log(JSON.stringify({resources:r.resources.length,vertices:r.resources[0].container.models.reduce((n,m)=>n+m.vertexCount,0),textures:r.resources[1].container.textures.length,assetFilesWritten:0}));
}
