// SPDX-License-Identifier: GPL-3.0-or-later
import {rigidFromPackedRender,quatInverse as inv,quatMultiply as mul,quatRotate as rotate} from './retarget-pose.mjs';
const column=m=>{if(m?.length!==16||m.some(v=>!Number.isFinite(v)))throw Error('Complete source matrix required');return rigidFromPackedRender([m[0],m[4],m[8],m[1],m[5],m[9],m[2],m[6],m[10],0,...m.slice(12,15)]);};
export function combatPelvisTwist(pose){
 if(!pose?.valid||pose.matrices?.length!==110)throw Error('Current source pose required');
 if(pose.baseHierarchyCandidate?.parents?.[0]!==-1)throw Error('Current palette root required');
 const q=mul(inv(column(pose.matrices[0]).rotation),column(pose.matrices[1]).rotation),n=Math.hypot(q[2],q[3]);
 if(n<1e-6)throw Error('Singular pelvis heading');return [0,0,q[2]/n,q[3]/n];
}
export function combatPelvisHeight(pose){const root=column(pose.rootMatrix),p=column(pose.matrices[1]);return rotate(inv(root.rotation),p.position.map((v,k)=>v-root.position[k]))[2];}
export function restoreCombatTwist(bones,reference,current){
 if(bones?.length!==66)throw Error('Original full skeleton required');
 const delta=mul(inv(reference),current),pivot=bones[1].slice(10,13);
 return bones.map((m,i)=>{if(i===0)return [...m];const w=rigidFromPackedRender(m),q=mul(delta,w.rotation),p=rotate(delta,w.position.map((v,k)=>v-pivot[k])).map((v,k)=>v+pivot[k]),c=[[1,0,0],[0,1,0],[0,0,1]].map(v=>rotate(q,v));return [0,1,2].flatMap(k=>c.map(v=>v[k])).concat([m[9],...p]);});
}
