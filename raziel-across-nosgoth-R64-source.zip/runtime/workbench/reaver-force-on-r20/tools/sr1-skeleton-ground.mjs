// SPDX-License-Identifier: GPL-3.0-or-later
// Native sole scalar measured from installed foot vertices in RAM. The output
// remains only66 bone matrices; no vertices leave this external converter.
import {alignSr1Skeleton} from './sr1-skeleton-alignment.mjs';
import {skinSr1Pose} from './sr1-skin.mjs';import {sr1FootVertices,alignSr1GroundSoles} from './sr1-ground-contact.mjs';
import {quatIdentity as I,quatRotate as rotate,quatInverse as inv,quatMultiply as mul,rigidFromPackedRender} from './retarget-pose.mjs';
export function skeletonSoleReference(mesh,groundPolicy){const ids=sr1FootVertices(mesh,groundPolicy);if(!ids.length)throw Error('Missing native foot reference');return {...mesh,positions:ids.map(i=>mesh.positions[i]),joints:ids.map(i=>mesh.joints[i]),weights:ids.map(i=>mesh.weights[i])};}
export function alignNativeSkeletonGround({compiled,hostRender,donorPose,footMesh,groundPolicy,policy}){
 if(policy.groundSoleNativeReference!==true||policy.hostWrites||policy.bodyPayload)throw Error('Disabled native sole policy');
 const r=alignSr1Skeleton({compiled,hostRender,donorPose,groundAllowed:true,experimental:'sr1-absolute-skeleton-offline-v1'});if(!r.allow)return r;
 const native=hostRender.map(m=>rigidFromPackedRender(m)),root=native[0],inverse=inv(root.rotation),relative=native.map(w=>({position:rotate(inverse,w.position.map((v,k)=>v-root.position[k])),rotation:mul(inverse,w.rotation)})),positions=skinSr1Pose(footMesh,r.world),nativePositions=skinSr1Pose(footMesh,relative);
 const ground=alignSr1GroundSoles({pose:r,positions,nativePositions,feet:footMesh.positions.map((_,i)=>i),up:rotate(inverse,[0,0,1]),restWorld:footMesh.bindOffsets.slice(0,66).map(p=>({position:p.map(v=>-v),rotation:I()})),policy:groundPolicy,groundAllowed:true});
 if(!ground.allow)return {allow:false,reason:ground.reason,correction:ground.correction};
 const bones=ground.pose.world.map(w=>{const c=[[1,0,0],[0,1,0],[0,0,1]].map(v=>rotate(w.rotation,v));return [0,1,2].flatMap(k=>c.map(v=>v[k])).concat([0,...w.position]);});
 return {allow:true,actorLocalMatrices:bones,correction:ground.correction,limit:ground.limit,modelPayloadBytes:0};
}
