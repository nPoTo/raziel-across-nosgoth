// SPDX-License-Identifier: GPL-3.0-or-later
// Current positions and joint twist; bounded secondary-axis history only.
// No previous whole pose, timer, native ownership or game writes.
import {quatIdentity,quatMultiply as mul,quatInverse as inv,quatRotate as rotate,quatNormalize} from './retarget-pose.mjs';
const dot=(a,b)=>a.reduce((n,v,i)=>n+v*b[i],0);
const cross=(a,b)=>[a[1]*b[2]-a[2]*b[1],a[2]*b[0]-a[0]*b[2],a[0]*b[1]-a[1]*b[0]];
const unit=v=>{if(!Array.isArray(v)||v.length!==3||!v.every(Number.isFinite))throw Error('Invalid anatomical direction');const n=Math.hypot(...v);if(n<1e-7)throw Error('Degenerate anatomical edge');return v.map(x=>x/n);};
export function validateFrameStabilityPolicy(p){
 if(p?.id!=='current_secondary_transport_r8'||p.enabled!==true||p.method!=='near_parallel_secondary_transport'||p.currentPoseOnly!==true||p.preservePrimary!==true||p.previousPoseReuse!==false||p.secondaryAxisHistory!==true||p.maxHistoryAgeMs!==150)throw Error('Unsupported anatomical frame stability policy');
 return true;
}
export function sourceSwingFrame({primary,sourceRotation,bindPrimary,bindFrame,bindSecondary}){
 const actual=unit(primary),predicted=unit(rotate(sourceRotation,unit(bindPrimary))),d=Math.max(-1,Math.min(1,dot(predicted,actual)));
 let swing;
 if(d>1-1e-8)swing=quatIdentity();
 else if(d< -1+1e-8){
  // At an exact opposite edge the swing axis is ambiguous. The current source
  // secondary is perpendicular to its bind primary and carries authored roll.
  const s=rotate(sourceRotation,bindSecondary),axis=unit(s.map((v,k)=>v-dot(s,predicted)*predicted[k]));
  swing=[...axis,0];
 }else swing=quatNormalize([...cross(predicted,actual),1+d]);
 return mul(mul(swing,sourceRotation),bindFrame);
}

export function resetAnatomicalFrameState(compiled){if(compiled)compiled.anatomicalFrameState=null;}
function swingOnto(rotation,primary){
 return sourceSwingFrame({primary,sourceRotation:rotation,bindPrimary:[1,0,0],bindSecondary:[0,1,0],bindFrame:quatIdentity()});
}
const same=(a,b)=>a.length===b.length&&a.every((v,k)=>Math.abs(v-b[k])<1e-8);
export function stableAnatomicalFrame({compiled,target,primary,sourceRotation,bindPrimary,bindFrame,bindSecondary,context,legacyFrame}){
 const policy=compiled.frameStability;
 if(!policy||!context){resetAnatomicalFrameState(compiled);return legacyFrame();}
 validateFrameStabilityPolicy(policy);
 if(typeof context.identity!=='string'||!context.identity.length||context.identity.length>4096||!Number.isSafeInteger(context.tick)||context.tick<0||!Number.isSafeInteger(context.sequence)||context.sequence<=0){resetAnatomicalFrameState(compiled);throw Error('Invalid anatomical frame context');}
 const x=unit(primary),q=quatNormalize(sourceRotation);let session=compiled.anatomicalFrameState;
 if(session&&session.identity===context.identity&&(context.tick<session.tick||context.sequence<session.sequence||(context.sequence===session.sequence&&context.tick!==session.tick))){resetAnatomicalFrameState(compiled);throw Error('Regressed anatomical frame context');}
 if(!session||session.identity!==context.identity||context.tick-session.tick>policy.maxHistoryAgeMs){session={identity:context.identity,tick:context.tick,sequence:context.sequence,bones:new Map()};compiled.anatomicalFrameState=session;}
 session.tick=context.tick;session.sequence=context.sequence;
 const previous=session.bones.get(target);
 if(previous?.sequence===context.sequence){
  if(previous.tick!==context.tick||!same(previous.primary,x)||!same(previous.sourceRotation,q)){resetAnatomicalFrameState(compiled);throw Error('Anatomical frame changed within sequence');}
  return [...previous.rotation];
 }
 let raw=null;
 try{raw=legacyFrame();}catch(e){if(e.message!=='Singular anatomical frame')throw e;}
 const history=previous&&context.tick-previous.tick<=policy.maxHistoryAgeMs;
 let rotation=raw,active=previous?.active??false;
 if(!raw||active){
  const reference=history?swingOnto(mul(mul(q,inv(previous.sourceRotation)),previous.rotation),x):sourceSwingFrame({primary:x,sourceRotation:q,bindPrimary,bindFrame,bindSecondary});
  if(!raw){rotation=reference;active=true;}
  else{
   // A fixed secondary projection reverses sign when its primary crosses it.
   // Carry only that secondary branch, retaining the CURRENT primary, current
   // joint twist and every position. This never replays a whole previous pose.
   const flipped=mul(raw,[1,0,0,0]);
   const distance=r=>Math.abs(r.reduce((n,v,k)=>n+v*reference[k],0));
   rotation=distance(flipped)>distance(raw)?flipped:raw;
  }
 }
 session.bones.set(target,{tick:context.tick,sequence:context.sequence,primary:[...x],sourceRotation:[...q],rotation:[...rotation],active});
 return rotation;
}
