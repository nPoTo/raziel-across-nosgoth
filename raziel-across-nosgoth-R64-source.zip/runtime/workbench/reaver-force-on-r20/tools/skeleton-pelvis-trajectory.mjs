// SPDX-License-Identifier: GPL-3.0-or-later
// Candidate only: live mapped pelvis, fixed standing offset, no frame foot clamp.
import {alignSr1Skeleton} from './sr1-skeleton-alignment.mjs';
import {skinSr1Pose} from './sr1-skin.mjs';
import {quatRotate as rotate,quatInverse as inv,quatMultiply as mul,rigidFromPackedRender} from './retarget-pose.mjs';
const sub=(a,b)=>a.map((v,k)=>v-b[k]),length=v=>Math.hypot(...v),dot=(a,b)=>a.reduce((n,v,k)=>n+v*b[k],0);
const point=(c,p)=>p[c.a].map((v,k)=>v+(p[c.b][k]-v)*c.t);
const column=m=>{if(!Array.isArray(m)||m.length!==16||m.some(v=>!Number.isFinite(v))||Math.abs(m[3])+Math.abs(m[7])+Math.abs(m[11])+Math.abs(m[15]-1)>1e-5)throw Error('Rigid donor matrix required');return rigidFromPackedRender([m[0],m[4],m[8],m[1],m[5],m[9],m[2],m[6],m[10],0,...m.slice(12,15)]);};
const key=h=>{if(!h?.valid||!['actor','object','model'].every(k=>typeof h[k]==='string'&&/^0x[0-9a-f]+$/i.test(h[k])&&BigInt(h[k])>0n)||!Number.isSafeInteger(h.epoch)||h.epoch<=0)throw Error('Current host identity required');return [h.actor,h.object,h.model,h.epoch].join('/');};
const low=(a,up)=>{let n=Infinity;for(let i=0;i<a.length;i+=3)n=Math.min(n,a[i]*up[0]+a[i+1]*up[1]+a[i+2]*up[2]);if(!Number.isFinite(n))throw Error('Finite sole required');return n;};
const median=a=>{const s=a.toSorted((x,y)=>x-y),i=Math.floor(s.length/2);return s.length%2?s[i]:(s[i-1]+s[i])/2;};
export function compilePelvisTrajectory(compiled,sourceBind,policy){
 if(policy.id!=='pelvis_ground'||policy.sourcePelvis!==1||policy.targetPelvis!==1||policy.samples!==20||policy.minSpanMs!==600||policy.maxRootDriftUnits!==1||policy.maxOffsetLegPermille!==350||policy.maxTravelLegPermille!==350||policy.hostRootWrites||policy.frameFootClamp||policy.enabled)throw Error('Disabled pelvis trajectory policy required');
 if(sourceBind?.length!==85||compiled.parents?.length!==66||compiled.parents[1]!==0||compiled.controls[1].a!==1||compiled.controls[1].b!==1)throw Error('Proved mapped pelvis required');
 const hostBind=[];for(const i of compiled.order){const p=compiled.parents[i];hostBind[i]=compiled.hostRest[i].position.map((v,k)=>v+(p<0?0:hostBind[p][k]));}
 const sourcePoints=compiled.controls.map(c=>c.a===undefined?null:point(c,sourceBind)),pairs=[[6,7],[7,8],[8,9],[10,11],[11,12],[12,13]],leg=p=>pairs.reduce((n,[a,b])=>n+length(sub(p[a],p[b])),0)/2,hostLeg=leg(hostBind),sourceLeg=leg(sourcePoints),scale=hostLeg/sourceLeg;
 if(!Number.isFinite(scale)||scale<=0||!Number.isFinite(hostLeg)||hostLeg<=0)throw Error('Finite mapped leg proportions required');
 const below=compiled.parents.map((_,i)=>{let at=i;while(at>=0&&at!==1)at=compiled.parents[at];return at===1;});
 return {compiled,policy,hostLeg,sourceLeg,scale,hostPelvis:sub(hostBind[1],hostBind[0]),sourcePelvisBind:sub(sourcePoints[1],sourceBind[0]),below};
}
function posedPelvis(t,pose){
 const root=column(pose.rootMatrix),inverse=inv(root.rotation),pelvis=column(pose.matrices[1]),rotation=mul(inverse,pelvis.rotation),n=Math.hypot(rotation[2],rotation[3]);if(n<1e-6)throw Error('Source heading singular');
 const heading=[0,0,-rotation[2]/n,rotation[3]/n],position=rotate(heading,rotate(inverse,sub(pelvis.position,root.position))),delta=sub(position,t.sourcePelvisBind).map(v=>v*t.scale);
 if(length(delta)>t.hostLeg*t.policy.maxTravelLegPermille/1000)return null;
 return {position:t.hostPelvis.map((v,k)=>v+delta[k]),sourceHeight:position[2]};
}
function trajectoryPose(t,host,source,offset=0){
 const r=alignSr1Skeleton({compiled:t.compiled,hostRender:host.render,donorPose:source.poseCandidate,groundAllowed:true,experimental:'sr1-absolute-skeleton-offline-v1'});if(!r.allow)return r;
 const pelvis=posedPelvis(t,source.poseCandidate);if(!pelvis)return {allow:false,reason:'pelvis_travel_out_of_bounds'};
 const native=host.render.map(m=>rigidFromPackedRender(m)),root=native[0],inverse=inv(root.rotation),up=rotate(inverse,[0,0,1]),desired=pelvis.position.map((v,k)=>v+up[k]*offset),shift=sub(desired,r.world[1].position),world=r.world.map((w,i)=>({...w,position:w.position.map((v,k)=>v+(t.below[i]?shift[k]:0))}));
 return {allow:true,world,up,root,native,sourceHeight:pelvis.sourceHeight,pelvisHeight:dot(desired,up)};
}
export class PelvisStandingReference{
 constructor(trajectory){this.t=trajectory;this.reference=null;this.samples=[];this.identity=null;this.root=null;}
 observe(host,source,footMesh,tick,neutral){
  if(this.reference)return this.reference;
  if(!Number.isSafeInteger(tick)||tick<0)throw Error('Receipt tick required');
  if(!host?.valid||!host.allowed||host.callbacks?.length!==3||host.callbacks.some(v=>v!==0xf2180)||!source?.valid||!source.instance||neutral!==true){this.samples=[];this.root=null;return null;}
  const identity=key(host)+'/'+source.instance;if(this.identity&&this.identity!==identity)throw Error('Paired actor identity changed');this.identity=identity;
  const r=trajectoryPose(this.t,host,source);if(!r.allow){this.samples=[];this.root=null;return null;}
  if(this.root&&(tick<this.samples.at(-1).tick||length(sub(r.root.position,this.root))>this.t.policy.maxRootDriftUnits)){this.samples=[];this.root=null;}
  this.root??=[...r.root.position];const inverse=inv(r.root.rotation),nativeLocal=r.native.map(w=>({position:rotate(inverse,sub(w.position,r.root.position)),rotation:mul(inverse,w.rotation)}));
  const offset=low(skinSr1Pose(footMesh,nativeLocal),r.up)-low(skinSr1Pose(footMesh,r.world),r.up);
  if(Math.abs(offset)>this.t.hostLeg*this.t.policy.maxOffsetLegPermille/1000){this.samples=[];this.root=null;return null;}
  // Identity, context, pose, drift and offset checks above still apply to a
  // repeated clock tick. It adds neither another sample nor elapsed evidence.
  if(this.samples.length&&tick===this.samples.at(-1).tick)return null;
  this.samples.push({tick,offset});while(this.samples.length>this.t.policy.samples&&tick-this.samples[1].tick>=this.t.policy.minSpanMs)this.samples.shift();
  if(this.samples.length>=this.t.policy.samples&&tick-this.samples[0].tick>=this.t.policy.minSpanMs){this.reference=Object.freeze({ready:true,key:identity,offset:median(this.samples.map(x=>x.offset)),up:Object.freeze([...r.up]),samples:this.samples.length,spanMs:tick-this.samples[0].tick});this.samples=[];}
  return this.reference;
 }
}
export function alignPelvisTrajectory({trajectory:t,host,source,reference}){
 if(!host?.valid||!host.allowed)return {allow:false,reason:'native_context'};
 if(!reference?.ready||reference.key!==key(host)+'/'+source?.instance||!Number.isFinite(reference.offset))return {allow:false,reason:'pelvis_reference_unavailable'};
 const r=trajectoryPose(t,host,source,reference.offset);if(!r.allow)return r;if(dot(r.up,reference.up)<.97)return {allow:false,reason:'pelvis_reference_up_changed'};
 const bones=r.world.map(w=>{const c=[[1,0,0],[0,1,0],[0,0,1]].map(v=>rotate(w.rotation,v));return [0,1,2].flatMap(k=>c.map(v=>v[k])).concat([0,...w.position]);});
 return {allow:true,actorLocalMatrices:bones,pelvisHeight:r.pelvisHeight,sourcePelvisHeight:r.sourceHeight,standingOffset:reference.offset,frameFootClamp:false,hostRootWrites:0};
}
