param([string]$Compiler='clang.exe')
$ErrorActionPreference='Stop'
Push-Location $PSScriptRoot
try {
 $compileArgs=Get-Content -LiteralPath (Join-Path $PSScriptRoot 'compile-args.json') -Raw | ConvertFrom-Json
 & $Compiler @compileArgs
 if($LASTEXITCODE -ne 0){throw 'Native compilation failed'}
} finally { Pop-Location }
