// SPDX-License-Identifier: GPL-3.0-or-later
#pragma once
#include <stdbool.h>
#include <stdint.h>
#include <string.h>
#include <math.h>

typedef struct {
    uint64_t tick,epoch,marker;
    uint32_t actorGeneration;
    int32_t stream;
    int16_t point[3];
    uint16_t targetRadius;
    uint32_t color;
    bool submitted,landing,slam;
} C2Impact;

static inline bool c2ImpactCurrent(const C2Impact *impact,uint64_t now,uint64_t epoch,
    uint32_t actorGeneration,int32_t stream,unsigned duration) {
    return impact->epoch && impact->epoch==epoch && impact->actorGeneration==actorGeneration &&
        impact->stream==stream && impact->tick<=now && now-impact->tick<duration;
}

static inline bool c2HitTargetEligible(int16_t hp,uint32_t state,uint32_t stunnedState) {
    return hp>0 || (hp==0 && state==stunnedState);
}

static inline bool c2StunAdvanced(const uint32_t before[2],const uint32_t after[2]) {
    const uint32_t first=after[0]-before[0],second=after[1]-before[1];
    return first && first<=INT32_MAX && second && second<=INT32_MAX;
}

static inline void c2ImpactColor(uint32_t color,float alpha,float out[4]) {
    out[0]=(float)((color>>16)&255)/255.0f;
    out[1]=(float)((color>>8)&255)/255.0f;
    out[2]=(float)(color&255)/255.0f;
    out[3]=alpha;
}

static inline uint32_t c2DonorFxRgb(uint32_t native) {
    return ((native&0xff)<<16)|(native&0xff00)|((native>>16)&0xff);
}

static inline bool c2ImpactInFrustum(const float clip[4]) {
    return clip[3]>0 && isfinite(clip[3]) && fabsf(clip[0])<=clip[3] &&
        fabsf(clip[1])<=clip[3] && fabsf(clip[2])<=clip[3];
}

static inline void c2ImpactLocal(const int16_t world[3],const float palm[16],float out[3]) {
    for (unsigned axis=0;axis<3;++axis) {
        out[axis]=0;
        for (unsigned i=0;i<3;++i)
            out[axis]+=palm[axis*4+i]*((float)world[i]-palm[12+i]);
    }
}

// The perspective W row points away from the camera in hand space. Move the
// center toward the camera and use the clip Y row to orient a facing quad.
static inline bool c2ImpactBillboard(const float mvp[16],float radius,float center[3],float right[3],float up[3]) {
    float away[3]={mvp[3],mvp[7],mvp[11]};
    const float length=hypotf(hypotf(away[0],away[1]),away[2]);
    if (!(length>0.00001f) || !isfinite(length)) return false;
    float along=0;
    for (unsigned axis=0;axis<3;++axis) {
        away[axis]/=length;
        up[axis]=mvp[axis*4+1];
        along+=up[axis]*away[axis];
        center[axis]-=away[axis]*radius;
    }
    for (unsigned axis=0;axis<3;++axis) up[axis]-=along*away[axis];
    const float height=hypotf(hypotf(up[0],up[1]),up[2]);
    if (!(height>0.00001f) || !isfinite(height)) return false;
    for (unsigned axis=0;axis<3;++axis) up[axis]/=height;
    for (unsigned axis=0;axis<3;++axis) {
        const unsigned b=(axis+1)%3,c=(axis+2)%3;
        right[axis]=away[b]*up[c]-away[c]*up[b];
    }
    return true;
}

static inline void c2ImpactClip(const float mvp[16],const float center[3],float clip[4]) {
    for (unsigned row=0;row<4;++row)
        clip[row]=mvp[row]*center[0]+mvp[row+4]*center[1]+mvp[row+8]*center[2]+mvp[row+12];
}

static inline float c2ImpactTextureAlpha(float x,float y) {
    const float center=fmaxf(0.0f,1.0f-hypotf(x,y));
    return center*center;
}

static inline float c2ImpactCoreAlpha(float x,float y) {
    return fmaxf(0,fminf(1,(0.86f-hypotf(x,y))*8.5f));
}

static inline float c2ImpactStarAlpha(float x,float y) {
    const float reach=fmaxf(fabsf(x),fabsf(y));
    const float cross=fminf(fabsf(x),fabsf(y));
    const float halfWidth=0.24f*(1-reach);
    return fmaxf(0,fminf(1,(halfWidth-cross)*25.0f));
}

static inline float c2ImpactRayAlpha(float x,float y) {
    const float along=(x+1)*0.5f;
    const float width=0.53f*(1-along);
    const float edge=fmaxf(0,fminf(1,(width-fabsf(y))*9.0f));
    return edge*fmaxf(0,fminf(1,1.2f-1.18f*along));
}
