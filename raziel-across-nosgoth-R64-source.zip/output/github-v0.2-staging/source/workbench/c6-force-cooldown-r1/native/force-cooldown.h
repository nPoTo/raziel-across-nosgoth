// SPDX-License-Identifier: GPL-3.0-or-later
#pragma once
#include <stdint.h>
#include "force-cooldown-policy.h"

typedef enum {
    C6_PRESS_NATIVE,
    C6_PRESS_FAST,
    C6_PRESS_SUPPRESSED
} C6PressRoute;

typedef struct {
    uint64_t epoch;
    uintptr_t actor;
    uint32_t generation;
} C6CooldownOwner;

typedef struct {
    C6CooldownOwner owner;
    uint64_t releaseTick;
} C6ForceCooldown;

static inline uint32_t c6CooldownRemaining(const C6ForceCooldown *state, C6CooldownOwner owner, uint64_t now) {
    const uint32_t interval = C6_FORCE_REPEAT_MS;
    if (!state->releaseTick || state->owner.epoch != owner.epoch ||
        state->owner.actor != owner.actor || state->owner.generation != owner.generation)
        return 0;
    if (now < state->releaseTick) return interval;
    const uint64_t elapsed = now - state->releaseTick;
    return elapsed < interval ? interval - (uint32_t)elapsed : 0;
}
