// SPDX-License-Identifier: GPL-3.0-or-later
#pragma once
#include <stdint.h>
#include <stdbool.h>
#include "c4-native-finish-policy.h"

static inline bool c4MaterialReward(int32_t before,int16_t healthScale,uintptr_t energy,
    int32_t *after,int32_t *cap) {
    if (healthScale<0 || healthScale>15 || before<=0 || energy>INT16_MAX) return false;
    *cap=((int32_t)healthScale+1)*C4_NATIVE_HEALTH_PER_SEGMENT;
    if (before>*cap) return false;
    const int32_t amount=(int32_t)energy*C4_NATIVE_HEALING_NUMERATOR/C4_NATIVE_HEALING_DIVISOR;
    *after=amount>*cap-before ? *cap : before+amount;
    return true;
}
