// SPDX-License-Identifier: GPL-3.0-or-later
#pragma once
// Unit harnesses may provide an explicit literal directory before including us.
#ifdef PROBE_REPORT_DIR
#define PROBE_PATH(suffix) PROBE_REPORT_DIR suffix
#else
#include "exploration-sheets.h"
static wchar_t probeRuntimeDirectory[32768];
static INIT_ONCE probeRuntimeOnce = INIT_ONCE_STATIC_INIT;
static BOOL CALLBACK probeRuntimeInit(PINIT_ONCE once,PVOID parameter,PVOID *context) {
    (void)once;(void)parameter;(void)context;
    DWORD n=GetEnvironmentVariableW(sheet_runtimePaths_session.environment,probeRuntimeDirectory,ARRAYSIZE(probeRuntimeDirectory));
    if(n && n<ARRAYSIZE(probeRuntimeDirectory) && n>3 && probeRuntimeDirectory[1]==L':' &&
       (probeRuntimeDirectory[2]==L'\\'||probeRuntimeDirectory[2]==L'/') &&
       !wcsstr(probeRuntimeDirectory,L"..") && !wcschr(probeRuntimeDirectory,L'%'))return TRUE;
    probeRuntimeDirectory[0]=0;
#ifdef PROBE_DIAGNOSTIC_DIR
    if(wcslen(PROBE_DIAGNOSTIC_DIR)<ARRAYSIZE(probeRuntimeDirectory))wcscpy(probeRuntimeDirectory,PROBE_DIAGNOSTIC_DIR);
#else
    wchar_t parent[32768];
    n=GetEnvironmentVariableW(L"LOCALAPPDATA",parent,ARRAYSIZE(parent));
    if(n && n+40<ARRAYSIZE(parent)) {
        wcscat(parent,L"\\");wcscat(parent,sheet_runtimePaths_session.defaultSubdirectory);CreateDirectoryW(parent,NULL);
        wcscpy(probeRuntimeDirectory,parent);wcscat(probeRuntimeDirectory,L"\\runtime");
        CreateDirectoryW(probeRuntimeDirectory,NULL);
    }
#endif
    return TRUE;
}
static inline const wchar_t *probeReportDirectory(void) {
    InitOnceExecuteOnce(&probeRuntimeOnce,probeRuntimeInit,NULL,NULL);
    return probeRuntimeDirectory;
}
static inline const wchar_t *probeReportPath(const wchar_t *suffix) {
    // Each flag check copies a stable directory into a per-thread scratch buffer.
    static _Thread_local wchar_t result[32768];
    const wchar_t *directory=probeReportDirectory();
    size_t a=wcslen(directory),b=wcslen(suffix);
    if(!a || a+b>=ARRAYSIZE(result)){result[0]=0;return result;}
    memcpy(result,directory,a*sizeof(wchar_t));memcpy(result+a,suffix,(b+1)*sizeof(wchar_t));
    return result;
}
#define PROBE_REPORT_DIR probeReportDirectory()
#define PROBE_PATH(suffix) probeReportPath(suffix)
#endif
