// SPDX-License-Identifier: GPL-3.0-or-later
#pragma once
#include <stdint.h>
typedef uint32_t (*HostGroundFn)(uintptr_t,int16_t *,uint16_t);
static inline uint32_t hostGroundForward(HostGroundFn original,uintptr_t actor,int16_t *payload,uint16_t flags){
 return original(actor,payload,flags);
}
