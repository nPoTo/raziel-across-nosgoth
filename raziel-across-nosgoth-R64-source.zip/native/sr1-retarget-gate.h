// SPDX-License-Identifier: GPL-3.0-or-later
#pragma once
#include <stdint.h>
#include <stdbool.h>
#include "exploration-sheets.h"
typedef struct {bool identity,foreground,verticalVelocityKnown,crouchHeld;int32_t verticalVelocity;uint16_t mode;uint32_t flags,callbacks[3];bool ordinaryAirTransition;} Sr1RetargetContext;
static inline bool sr1RetargetContextAllowed(const Sr1RetargetContext *s){
 if(!s||!s->identity||!s->foreground||s->crouchHeld||!s->verticalVelocityKnown||s->verticalVelocity||s->mode||s->flags&0x10000000u)return false;
 for(unsigned i=0;i<3;i++){bool found=false;for(unsigned j=0;j<sheet_retargetGroundStates_count;j++)if(s->callbacks[i]==sheet_retargetGroundStates_rows[j]->rva)found=true;if(!found)return false;}
 return true;
}
#ifdef SR1_NATIVE_JUMP_POSE
#ifdef SR1_AIR_COMBAT_POSE
static inline bool sr1OrdinaryAirClip(uint32_t callback,uint16_t clip){return callback==0xedb40?(clip==0x1a||clip==0x22):callback==0xee600&&(clip==0x1d||clip==0x25);}
static inline bool sr1OrdinaryAirPattern(const uint32_t callbacks[3],const uint16_t clips[6]){
 const Sheet_ordinaryLandingSectionPattern *p=&sheet_ordinaryLandingSectionPattern_upper_228;
 bool exact=!p->enabled&&p->callbackRva==0xee600&&p->outerClip==29&&p->upperClip==228&&p->bothPalettes&&p->allCallbacks&&!p->gameWrites;
 for(unsigned i=0;i<3;i++)exact=exact&&callbacks[i]==(uint32_t)p->callbackRva;
 for(unsigned i=0;i<6;i++)exact=exact&&clips[i]==(uint16_t)((i%3)==1?p->upperClip:p->outerClip);
 if(exact)return true;
 for(unsigned i=0;i<6;i++)if(clips[i]==228)return false; // No other unproved 228 pattern.
 for(unsigned i=0;i<3;i++)if(callbacks[i]==0xedb40||callbacks[i]==0xee600)
  for(unsigned hd=0;hd<2;hd++)if(!sr1OrdinaryAirClip(callbacks[i],clips[hd*3+i]))return false;
 return true;
}
#endif
// Classification only, not an animation/state call. Native fall/glide/landing
// have distinct callbacks and can never be admitted through this predicate.
static inline bool sr1RetargetJumpContextAllowed(const Sr1RetargetContext *s){
 const Sheet_nativeJumpPosePolicy *p=&sheet_nativeJumpPosePolicy_ordinary;
 if(p->poseMode!=3||p->hostJumpRva!=0xf2ae0||p->sourcePrimaryRva!=0x10f1d0||p->sourceSecondaryRva!=0x10f220||p->maxAbsVerticalVelocity!=2048||p->hostCoordinateWrites||p->hostFacingWrites||p->hostGravityWrites||!p->glideNative||!p->fallNative||!p->landingNative||p->enabled)return false;
 if(!s||!s->identity||!s->foreground||s->crouchHeld||!s->verticalVelocityKnown||s->mode||(s->flags&0x10000000u)||s->verticalVelocity < -p->maxAbsVerticalVelocity||s->verticalVelocity>p->maxAbsVerticalVelocity)return false;
 bool hasAir=false;
 for(unsigned i=0;i<3;i++){
#ifdef SR1_AIR_COMBAT_POSE
  const Sheet_airCombatPosePolicy *a=&sheet_airCombatPosePolicy_air_candidate;
  if(a->enabled||a->hostRootWrites||a->hostGravityWrites||!a->nativeGlide||!a->allValidDonorPoses||a->hostJumpRva!=0xf2ae0||a->hostFallRva!=0xef480||a->poseMode!=3||a->freshMs!=150||a->maxAbsVerticalVelocity!=2048)return false;
  if(a->hostCompressionRva!=0xedb40||a->hostLandingRva!=0xee600||!a->mixedGroundSections)return false;
  const bool air=s->callbacks[i]==(uint32_t)a->hostJumpRva||s->callbacks[i]==(uint32_t)a->hostFallRva||
     ((s->callbacks[i]==(uint32_t)a->hostCompressionRva||s->callbacks[i]==(uint32_t)a->hostLandingRva)&&s->ordinaryAirTransition);
  bool ground=false;for(unsigned j=0;j<sheet_retargetGroundStates_count;j++)if(s->callbacks[i]==sheet_retargetGroundStates_rows[j]->rva)ground=true;
  if(!air&&!ground)return false;hasAir|=air;
#else
  if(s->callbacks[i]!=(uint32_t)p->hostJumpRva)return false;
  hasAir=true;
#endif
 }
 return hasAir;
}
#endif
