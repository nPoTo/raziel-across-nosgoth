// SPDX-License-Identifier: GPL-3.0-or-later
#pragma once
// Exact installed sr1.dll; REA function boundaries, immutable in-place PE bytes.
static const struct {uintptr_t rva;unsigned size;const char *sha256;} repeatJumpAdvanceProofs[]={
 {0xee600,752,"46ce4c6bef0fbbaba451c5b4077d79e48bfa4f1f85549d2387a1d035e7d0809a"},
 {0xedb40,909,"09681009265fe229affe33a23414e0d17bb741d1b3113216bf03eed5c001f90d"},
 {0x10ccc0,42,"d8c8e7061fe757dcba764c8f7ec713ebae89387251459feecb8bfa403d5dd3e5"},
 {0x10dc10,22,"10590aac511d9a34a1ee25d065d7edfb2a1d139e1cecdc00a70549d8c84a2473"}
};
