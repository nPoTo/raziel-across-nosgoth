// SPDX-License-Identifier: GPL-3.0-or-later
#pragma once
// Isolated weapon pass. No hooks, host/donor reads, body rendering or files.
// Caller must supply a currently admitted hand/camera and prepared color frame.
#include <math.h>
#include "guidance-render.h"
#define REAVER_GL(X) \
 X(PFNGLGENBUFFERSPROC,GenBuffers) X(PFNGLDELETEBUFFERSPROC,DeleteBuffers) X(PFNGLBUFFERDATAPROC,BufferData) \
 X(PFNGLVERTEXATTRIBPOINTERPROC,VertexAttribPointer) X(PFNGLENABLEVERTEXATTRIBARRAYPROC,EnableVertexAttribArray) \
 X(PFNGLUNIFORMMATRIX4FVPROC,UniformMatrix4fv) X(PFNGLUNIFORM1FPROC,Uniform1f) X(PFNGLDELETEVERTEXARRAYSPROC,DeleteVertexArrays) \
 X(PFNGLBLENDFUNCSEPARATEIPROC,BlendFuncSeparatei) X(PFNGLBLENDEQUATIONSEPARATEIPROC,BlendEquationSeparatei)
#define REAVER_DECLARE(type,name) static type rg##name;
REAVER_GL(REAVER_DECLARE)
#undef REAVER_DECLARE
typedef struct {float position[3],uv[2],rgba[4];} ReaverGLVertex;
typedef struct {GuidanceGLState shared;GLint array,depthFunc,srcRGB,dstRGB,srcAlpha,dstAlpha,eqRGB,eqAlpha;GLboolean depthMask;} ReaverGLState;
typedef struct {HGLRC context;GLuint program,vao,vbo,ebo,textures[128];unsigned widths[128],heights[128];} ReaverGL;
static bool reaverGLLoad(void){
 if(!guidanceLoadGL())return false;
#define REAVER_LOAD(type,name) do{PROC p=wglGetProcAddress("gl" #name);if(!p||(uintptr_t)p<=3||(uintptr_t)p==UINTPTR_MAX)return false;rg##name=(type)p;}while(0);
 REAVER_GL(REAVER_LOAD)
#undef REAVER_LOAD
 return true;
}
static void reaverGLSave(ReaverGLState *s){
 guidanceSaveGL(&s->shared);glGetIntegerv(GL_ARRAY_BUFFER_BINDING,&s->array);glGetIntegerv(GL_DEPTH_FUNC,&s->depthFunc);glGetBooleanv(GL_DEPTH_WRITEMASK,&s->depthMask);
 ghGetIntegeri_v(GL_BLEND_SRC_RGB,0,&s->srcRGB);ghGetIntegeri_v(GL_BLEND_DST_RGB,0,&s->dstRGB);ghGetIntegeri_v(GL_BLEND_SRC_ALPHA,0,&s->srcAlpha);ghGetIntegeri_v(GL_BLEND_DST_ALPHA,0,&s->dstAlpha);
 ghGetIntegeri_v(GL_BLEND_EQUATION_RGB,0,&s->eqRGB);ghGetIntegeri_v(GL_BLEND_EQUATION_ALPHA,0,&s->eqAlpha);
}
static void reaverGLRestore(const ReaverGLState *s){
 guidanceRestoreGL(&s->shared);ghBindBuffer(GL_ARRAY_BUFFER,(GLuint)s->array);glDepthFunc((GLenum)s->depthFunc);glDepthMask(s->depthMask);
 rgBlendFuncSeparatei(0,(GLenum)s->srcRGB,(GLenum)s->dstRGB,(GLenum)s->srcAlpha,(GLenum)s->dstAlpha);rgBlendEquationSeparatei(0,(GLenum)s->eqRGB,(GLenum)s->eqAlpha);
}
static bool reaverGLDestroy(ReaverGL *r){
 if(!r->context)return true;if(wglGetCurrentContext()!=r->context)return false;
 if(r->program)ghDeleteProgram(r->program);if(r->vao)rgDeleteVertexArrays(1,&r->vao);if(r->vbo)rgDeleteBuffers(1,&r->vbo);if(r->ebo)rgDeleteBuffers(1,&r->ebo);
 glDeleteTextures(128,r->textures);memset(r,0,sizeof(*r));return true;
}
static bool reaverGLInit(ReaverGL *r){
 const Sheet_reaverGpuPolicy *p=&sheet_reaverGpuPolicy_isolated_weapon;
 HGLRC context=wglGetCurrentContext();if(!context||r->context||p->nativeIntegrationEnabled||p->depthWrites||p->maxVertices!=2048||p->maxIndices!=8192||p->maxTextureSize!=2048||p->maxTextures!=128||!reaverGLLoad())return false;
 ReaverGLState saved={0};reaverGLSave(&saved);r->context=context;
 const char *vs="#version 330 core\nlayout(location=0)in vec3 position;layout(location=1)in vec2 texcoord;layout(location=2)in vec4 preparedColor;uniform mat4 mvp;uniform float scroll;out vec2 uv;out vec4 tint;void main(){gl_Position=mvp*vec4(position,1);uv=texcoord+vec2(0,scroll);tint=preparedColor;}";
 const char *fs="#version 330 core\nuniform sampler2D blade;uniform float alphaTest;in vec2 uv;in vec4 tint;out vec4 color;void main(){color=texture(blade,uv)*tint;if(alphaTest>=0&&color.a<alphaTest)discard;}";
 GLuint vertex=guidanceShader(GL_VERTEX_SHADER,vs),fragment=guidanceShader(GL_FRAGMENT_SHADER,fs);bool ok=false;
 if(vertex&&fragment){r->program=ghCreateProgram();ghAttachShader(r->program,vertex);ghAttachShader(r->program,fragment);ghLinkProgram(r->program);GLint linked=0;ghGetProgramiv(r->program,GL_LINK_STATUS,&linked);if(linked){
  ghGenVertexArrays(1,&r->vao);rgGenBuffers(1,&r->vbo);rgGenBuffers(1,&r->ebo);ghBindVertexArray(r->vao);ghBindBuffer(GL_ARRAY_BUFFER,r->vbo);ghBindBuffer(GL_ELEMENT_ARRAY_BUFFER,r->ebo);
  for(unsigned i=0;i<3;i++)rgEnableVertexAttribArray(i);
  rgVertexAttribPointer(0,3,GL_FLOAT,GL_FALSE,sizeof(ReaverGLVertex),(void *)0);rgVertexAttribPointer(1,2,GL_FLOAT,GL_FALSE,sizeof(ReaverGLVertex),(void *)(3*sizeof(float)));rgVertexAttribPointer(2,4,GL_FLOAT,GL_FALSE,sizeof(ReaverGLVertex),(void *)(5*sizeof(float)));
  ok=r->vao&&r->vbo&&r->ebo;
 }}
 if(vertex)ghDeleteShader(vertex);if(fragment)ghDeleteShader(fragment);if(!ok)reaverGLDestroy(r);reaverGLRestore(&saved);return ok;
}
static bool reaverGLTexture(ReaverGL *r,unsigned slot,unsigned width,unsigned height,const unsigned char *rgba,bool linear,bool repeat){
 if(!r->context||r->context!=wglGetCurrentContext()||!r->program||slot>=128||!width||!height||width>2048||height>2048||!rgba)return false;
 ReaverGLState saved={0};reaverGLSave(&saved);ghActiveTexture(GL_TEXTURE0);ghBindSampler(0,0);ghBindBuffer(GL_PIXEL_UNPACK_BUFFER,0);
 glPixelStorei(GL_UNPACK_ALIGNMENT,1);glPixelStorei(GL_UNPACK_ROW_LENGTH,0);glPixelStorei(GL_UNPACK_SKIP_ROWS,0);glPixelStorei(GL_UNPACK_SKIP_PIXELS,0);glPixelStorei(GL_UNPACK_SWAP_BYTES,0);glPixelStorei(GL_UNPACK_LSB_FIRST,0);
 // Allocate separately so a failed upload cannot replace a valid owned image.
 // Owned textures are private to this pass, never retained by host bindings.
 GLuint staged=0;glGenTextures(1,&staged);if(!staged){reaverGLRestore(&saved);return false;}glBindTexture(GL_TEXTURE_2D,staged);
 glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MIN_FILTER,linear?GL_LINEAR:GL_NEAREST);glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MAG_FILTER,linear?GL_LINEAR:GL_NEAREST);
 glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_WRAP_S,repeat?GL_REPEAT:GL_CLAMP_TO_EDGE);glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_WRAP_T,repeat?GL_REPEAT:GL_CLAMP_TO_EDGE);
 glTexImage2D(GL_TEXTURE_2D,0,GL_RGBA8,(GLsizei)width,(GLsizei)height,0,GL_RGBA,GL_UNSIGNED_BYTE,rgba);
 GLint actualWidth=0,actualHeight=0;glGetTexLevelParameteriv(GL_TEXTURE_2D,0,GL_TEXTURE_WIDTH,&actualWidth);glGetTexLevelParameteriv(GL_TEXTURE_2D,0,GL_TEXTURE_HEIGHT,&actualHeight);
 bool ok=actualWidth==(GLint)width&&actualHeight==(GLint)height;
 reaverGLRestore(&saved);
 if(!ok){glDeleteTextures(1,&staged);return false;}
 // Refuse replacement if ownership has escaped onto any texture unit.
 GLuint old=r->textures[slot];if(old){GLint units=0,active=0;glGetIntegerv(GL_MAX_COMBINED_TEXTURE_IMAGE_UNITS,&units);glGetIntegerv(GL_ACTIVE_TEXTURE,&active);
  bool bound=units<=0||units>1024;for(GLint i=0;i<units&&!bound;i++){GLint binding=0;ghActiveTexture(GL_TEXTURE0+i);glGetIntegerv(GL_TEXTURE_BINDING_2D,&binding);bound=(GLuint)binding==old;}
  ghActiveTexture((GLenum)active);if(bound){glDeleteTextures(1,&staged);return false;}
  glDeleteTextures(1,&old);
 }
 r->textures[slot]=staged;r->widths[slot]=width;r->heights[slot]=height;return true;
}
static bool reaverGLDraw(ReaverGL *r,const ReaverGLVertex *vertices,unsigned vertexCount,const uint16_t *indices,unsigned indexCount,unsigned texture,unsigned blend,const float mvp[16],float scroll,float alphaTest){
 if(!r->context||r->context!=wglGetCurrentContext()||!r->program||!vertices||!indices||!vertexCount||vertexCount>2048||!indexCount||indexCount>8192||indexCount%3||texture>=128||!r->textures[texture]||!r->widths[texture]||!r->heights[texture]||(blend!=1&&blend!=2)||!mvp||!isfinite(scroll)||!isfinite(alphaTest)||alphaTest>1)return false;
 for(unsigned i=0;i<16;i++)if(!isfinite(mvp[i]))return false;
 for(unsigned i=0;i<vertexCount;i++){const float *p=(const float *)(vertices+i);for(unsigned k=0;k<9;k++)if(!isfinite(p[k]))return false;}
 for(unsigned i=0;i<indexCount;i++)if(indices[i]>=vertexCount)return false;
 ReaverGLState saved={0};reaverGLSave(&saved);ghUseProgram(r->program);ghBindVertexArray(r->vao);ghBindBuffer(GL_ARRAY_BUFFER,r->vbo);
 rgBufferData(GL_ARRAY_BUFFER,(GLsizeiptr)(vertexCount*sizeof(*vertices)),vertices,GL_STREAM_DRAW);ghBindBuffer(GL_ELEMENT_ARRAY_BUFFER,r->ebo);rgBufferData(GL_ELEMENT_ARRAY_BUFFER,(GLsizeiptr)(indexCount*sizeof(*indices)),indices,GL_STREAM_DRAW);
 ghActiveTexture(GL_TEXTURE0);glBindTexture(GL_TEXTURE_2D,r->textures[texture]);ghBindSampler(0,0);ghUniform1i(ghGetUniformLocation(r->program,"blade"),0);
 rgUniformMatrix4fv(ghGetUniformLocation(r->program,"mvp"),1,GL_FALSE,mvp);rgUniform1f(ghGetUniformLocation(r->program,"scroll"),scroll);rgUniform1f(ghGetUniformLocation(r->program,"alphaTest"),alphaTest);
 glEnable(GL_DEPTH_TEST);glDepthFunc(GL_LEQUAL);glDepthMask(GL_FALSE);ghEnablei(GL_BLEND,0);rgBlendFuncSeparatei(0,GL_SRC_ALPHA,blend==1?GL_ONE_MINUS_SRC_ALPHA:GL_ONE,GL_ONE,GL_ONE_MINUS_SRC_ALPHA);rgBlendEquationSeparatei(0,GL_FUNC_ADD,GL_FUNC_ADD);
 ghColorMaski(0,GL_TRUE,GL_TRUE,GL_TRUE,GL_TRUE);glPolygonMode(GL_FRONT_AND_BACK,GL_FILL);
 glDisable(GL_STENCIL_TEST);glDisable(GL_CULL_FACE);glDisable(GL_SCISSOR_TEST);glDisable(GL_RASTERIZER_DISCARD);glDisable(GL_COLOR_LOGIC_OP);
 for(unsigned i=0;i<8;i++)glDisable(GL_CLIP_DISTANCE0+i);glDisable(GL_SAMPLE_COVERAGE);glDisable(GL_SAMPLE_ALPHA_TO_COVERAGE);glDisable(GL_SAMPLE_ALPHA_TO_ONE);glDisable(GL_SAMPLE_MASK);
 glDrawElements(GL_TRIANGLES,(GLsizei)indexCount,GL_UNSIGNED_SHORT,NULL);reaverGLRestore(&saved);return true;
}
