// SPDX-License-Identifier: GPL-3.0-or-later
#pragma once
// Requires host-transform.h and reaver-submitted-hand.h. No engine writes.
typedef struct {float view[16],inverse[16],projection[16];uint64_t frame,context,program;} ReaverCameraSample;
static inline bool reaverCameraMvp(float out[16],const ReaverCameraSample *a,const ReaverCameraSample *b,
 const ReaverSubmittedHand *hand,uint64_t actor,uint64_t model,uint64_t session,uint64_t frame,uint64_t context,uint64_t program,bool playerScope){
 if(!out)return false;memset(out,0,16*sizeof(float));
 const Sheet_reaverCameraPolicy *p=&sheet_reaverCameraPolicy_current_player_draw;
 if(p->nativeIntegrationEnabled||!p->requireSameFrame||!p->requireSameContext||!p->requireCurrentProgram||!p->requireDoubleRead||!p->requirePlayerScope||
 !a||!b||!hand||!playerScope||!context||!program||!reaverHandCurrent(hand,actor,model,session,frame)||
 a->frame!=frame||b->frame!=frame||a->context!=context||b->context!=context||a->program!=program||b->program!=program||
 memcmp(a->view,b->view,sizeof(a->view))||memcmp(a->inverse,b->inverse,sizeof(a->inverse))||memcmp(a->projection,b->projection,sizeof(a->projection)))return false;
 const float *matrices[]={a->view,a->inverse,a->projection,hand->matrix};
 for(unsigned m=0;m<4;m++)for(unsigned i=0;i<16;i++)if(!isfinite(matrices[m][i])||fabsf(matrices[m][i])>p->maxCoefficient)return false;
 const float tolerance=p->inverseToleranceMillionths/1000000.0f;
 if(tolerance<=0||tolerance>.005f||fabsf(a->projection[15])>.0001f||fabsf(a->projection[11])<.1f)return false;
 float check[16];
 for(unsigned side=0;side<2;side++){
  hostMultiply(side?a->inverse:a->view,side?a->view:a->inverse,check);
  for(unsigned i=0;i<16;i++)if(!isfinite(check[i])||fabsf(check[i]-(i%5==0?1.0f:0.0f))>tolerance)return false;
 }
 float viewHand[16],mvp[16];hostMultiply(a->view,hand->matrix,viewHand);hostMultiply(a->projection,viewHand,mvp);
 for(unsigned i=0;i<16;i++)if(!isfinite(mvp[i]))return false;
 memcpy(out,mvp,sizeof(mvp));return true;
}
