// SPDX-License-Identifier: GPL-3.0-or-later
#pragma once
// Existing camera-probe.h must be included. Call only from proven player GL draw.
#include "reaver-current-camera.h"
static bool reaverHostCameraSample(ReaverCameraSample *out,uint64_t frame,HGLRC context,GLuint program){
 memset(out,0,sizeof(*out));if(!frame||!context||wglGetCurrentContext()!=context||!program||!cameraReady||!cglIsProgram(program))return false;
 GLint current=0,savedBuffer=0,framebuffer=0;glGetIntegerv(GL_CURRENT_PROGRAM,&current);if((GLuint)current!=program)return false;
 glGetIntegerv(GL_DRAW_FRAMEBUFFER_BINDING,&framebuffer);
 if(!sheet_reaverCameraPolicy_current_player_draw.requireDefaultFramebuffer||framebuffer)return false;
 glGetIntegerv(GL_UNIFORM_BUFFER_BINDING,&savedBuffer);unsigned found=0;bool ok=true;
 for(unsigned i=0;i<cameraFieldCount&&ok;i++){
  const CameraField *f=&cameraFields[i];if(f->program!=program)continue;unsigned bit=0;float *matrix=NULL;
  if(!strcmp(f->field,"uViewMatrix")){bit=1;matrix=out->view;}
  else if(!strcmp(f->field,"uViewInverseMatrix")){bit=2;matrix=out->inverse;}
  else if(!strcmp(f->field,"uProjMatrix")){bit=4;matrix=out->projection;}
  else continue;
  if(found&bit){ok=false;break;}GLint buffer=0;if(!cameraRead(f,matrix,&buffer)){ok=false;break;}found|=bit;
  if(f->rowMajor){float copy[16];memcpy(copy,matrix,sizeof(copy));for(unsigned row=0;row<4;row++)for(unsigned col=0;col<4;col++)matrix[col*4+row]=copy[row*4+col];}
 }
 pglBindBuffer(GL_UNIFORM_BUFFER,(GLuint)savedBuffer);GLint after=0;glGetIntegerv(GL_CURRENT_PROGRAM,&current);glGetIntegerv(GL_UNIFORM_BUFFER_BINDING,&after);
 glGetIntegerv(GL_DRAW_FRAMEBUFFER_BINDING,&framebuffer);
 if(!ok||found!=7||(GLuint)current!=program||after!=savedBuffer||framebuffer||wglGetCurrentContext()!=context){memset(out,0,sizeof(*out));return false;}
 out->frame=frame;out->context=(uint64_t)(uintptr_t)context;out->program=program;return true;
}
static bool reaverHostCameraMvp(float out[16],const ReaverSubmittedHand *hand,HGLRC handContext,
 uint64_t actor,uint64_t model,uint64_t session,uint64_t frame,GLuint program,bool playerScope){
 if(!out)return false;memset(out,0,64);HGLRC context=wglGetCurrentContext();
 if(!playerScope||!context||context!=handContext||!reaverHandCurrent(hand,actor,model,session,frame))return false;
 ReaverCameraSample a,b;if(!reaverHostCameraSample(&a,frame,context,program)||!reaverHostCameraSample(&b,frame,context,program))return false;
 return reaverCameraMvp(out,&a,&b,hand,actor,model,session,frame,(uint64_t)(uintptr_t)context,program,true);
}
