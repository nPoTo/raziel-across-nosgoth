// SPDX-License-Identifier: GPL-3.0-or-later
#pragma once
#include "test-tutorial-plan.h"
typedef struct {
 uint32_t magic,version,gamePid,writerPid,plan,seconds,total,reserved;
 uint64_t session;
 unsigned char sheetHash[32];
} GuidanceDescriptor;
_Static_assert(sizeof(GuidanceDescriptor)==72,"Guidance scalar descriptor");
static inline unsigned guidanceSeconds(unsigned plan){
#ifdef SR1_REPEAT_JUMP_HUD
 if(plan==14)return (unsigned)sheet_repeatJumpObservationStages_jump.end;
#endif
#if defined(SR1_RETARGET_PREVIEW) || defined(SR1_NATIVE_SKELETON_ADAPTER)
 if(plan==13)return (unsigned)sheet_retargetPreviewPolicy_bounded.seconds;
#endif
#ifdef FIRST_BLOCK_PILOT
 if(plan==12)return (unsigned)sheet_firstBlockPilotPolicy_bounded.seconds;
#endif
 switch(plan){case 1:return tutorialRoomSeconds();case 2:case 3:return tutorialInteractionSeconds();case 4:return tutorialLifetimeSeconds();case 5:return tutorialWalkJumpSeconds();case 6:case 7:case 8:case 9:return TUTORIAL_SECONDS;case 10:return (unsigned)sheet_guidanceVisibilityStages_visibility.end;case 11:return (unsigned)sheet_donorMessageObservationPolicy_bounded.seconds;default:return 0;}
}
static inline const TutorialStage *guidanceStageAt(unsigned plan,unsigned elapsed){
#ifdef SR1_REPEAT_JUMP_HUD
 if(plan==14){static TutorialStage stage;for(unsigned i=0;i<sheet_repeatJumpObservationStages_count;i++){const Sheet_repeatJumpObservationStages *s=sheet_repeatJumpObservationStages_rows[i];if(elapsed>=s->begin&&elapsed<s->end){stage=(TutorialStage){(unsigned)s->begin,(unsigned)s->end,s->title,s->detail};return &stage;}}return NULL;}
#endif
#if defined(SR1_RETARGET_PREVIEW) || defined(SR1_NATIVE_SKELETON_ADAPTER)
 if(plan==13){static TutorialStage stage;for(unsigned i=0;i<sheet_retargetPreviewStages_count;i++){const Sheet_retargetPreviewStages *s=sheet_retargetPreviewStages_rows[i];if(elapsed>=s->begin&&elapsed<s->end){stage=(TutorialStage){(unsigned)s->begin,(unsigned)s->end,s->title,s->detail};return &stage;}}return NULL;}
#endif
#ifdef FIRST_BLOCK_PILOT
 if(plan==12){static TutorialStage stage;for(unsigned i=0;i<sheet_firstBlockPilotStages_count;i++){const Sheet_firstBlockPilotStages *s=sheet_firstBlockPilotStages_rows[i];if(elapsed>=s->begin&&elapsed<s->end){stage=(TutorialStage){(unsigned)s->begin,(unsigned)s->end,s->title,s->detail};return &stage;}}return NULL;}
#endif
 switch(plan){case 1:return tutorialRoomStageAt(elapsed);case 2:return tutorialGlideStageAt(elapsed);case 3:return tutorialInteractionStageAt(elapsed);case 4:return tutorialLifetimeStageAt(elapsed);case 5:return tutorialWalkJumpStageAt(elapsed);case 6:case 7:case 8:case 9:return plan==6?tutorialGroundStageAt(elapsed):plan==7?tutorialCameraStageAt(elapsed):plan==8?tutorialVisibilityStageAt(elapsed):tutorialStageAt(elapsed);case 10:{static TutorialStage stage;const Sheet_guidanceVisibilityStages *s=&sheet_guidanceVisibilityStages_visibility;if(elapsed>=(unsigned)s->end)return NULL;stage=(TutorialStage){0,(unsigned)s->end,s->title,s->detail};return &stage;}case 11:{static TutorialStage stage;for(unsigned k=0;k<ARRAYSIZE(sheet_donorMessageObservationStages_rows);k++){const Sheet_donorMessageObservationStages *s=sheet_donorMessageObservationStages_rows[k];if(elapsed>=s->begin&&elapsed<s->end){stage=(TutorialStage){(unsigned)s->begin,(unsigned)s->end,s->title,s->detail};return &stage;}}return NULL;}default:return NULL;}
}
static inline unsigned guidanceHex(char c){return c>='0'&&c<='9'?(unsigned)(c-'0'):c>='a'&&c<='f'?(unsigned)(c-'a'+10):255;}
static inline bool guidanceDescriptorValid(const GuidanceDescriptor *d,uint32_t pid,uint32_t writer,uint32_t total){
 unsigned seconds=guidanceSeconds(d->plan);
 if(d->magic!=0x31445548||d->version!=1||d->gamePid!=pid||!writer||d->writerPid!=writer||!d->session||d->reserved||!seconds||d->seconds!=seconds||d->total!=seconds*10||d->total!=total)return false;
 const char *hash=EXPLORATION_SHEET_SHA256;
 for(unsigned i=0;i<32;i++){unsigned a=guidanceHex(hash[i*2]),b=guidanceHex(hash[i*2+1]);if(a>15||b>15||d->sheetHash[i]!=(a*16+b))return false;}
 return true;
}
static inline bool guidanceWithinBudget(uint64_t now,uint64_t start,unsigned seconds){return now>=start&&now-start<tutorialWallBudgetMs(seconds);}
