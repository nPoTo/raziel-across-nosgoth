#include "report-path.h"
// Bounded GL matrix observation; no shader, camera or gameplay writes.
#define CAMERA_GL(X) \
 X(PFNGLISPROGRAMPROC,glIsProgram) X(PFNGLGETACTIVEUNIFORMPROC,glGetActiveUniform) \
 X(PFNGLGETACTIVEUNIFORMSIVPROC,glGetActiveUniformsiv) X(PFNGLGETACTIVEUNIFORMBLOCKIVPROC,glGetActiveUniformBlockiv) \
 X(PFNGLGETINTEGERI_VPROC,glGetIntegeri_v) X(PFNGLGETINTEGER64I_VPROC,glGetInteger64i_v) \
 X(PFNGLGETBUFFERSUBDATAPROC,glGetBufferSubData) X(PFNGLGETBUFFERPARAMETERIVPROC,glGetBufferParameteriv) \
 X(PFNGLGETUNIFORMFVPROC,glGetUniformfv)
#define CAMERA_DECLARE(type,name) static type c##name;
CAMERA_GL(CAMERA_DECLARE)
#undef CAMERA_DECLARE
typedef struct { GLuint program,index; GLint location,block,offset,stride,rowMajor,binding; const char *field; } CameraField;
static CameraField cameraFields[256];
static unsigned int cameraFieldCount;
#ifndef SR1_LOCAL_REAVER_PRESENTATION
static unsigned int cameraSamples;
#endif
static HGLRC cameraContext;
#ifndef SR1_LOCAL_REAVER_PRESENTATION
static ULONGLONG cameraLast;
static bool cameraAttempted,cameraReady;
#else
static bool cameraReady;
#endif
static void cameraDiscover(void) {
    cameraFieldCount=0;
    for(GLuint program=1;program<=4096 && cameraFieldCount<256;++program) {
        if(program==overlayProgram || !cglIsProgram(program)) continue;
        GLint linked=0,count=0; pglGetProgramiv(program,GL_LINK_STATUS,&linked); if(!linked) continue;
        pglGetProgramiv(program,GL_ACTIVE_UNIFORMS,&count); if(count<0 || count>1024) continue;
        for(GLuint i=0;i<(GLuint)count && cameraFieldCount<256;++i) {
            char name[256]={0}; GLsizei length=0; GLint size=0; GLenum type=0;
            cglGetActiveUniform(program,i,sizeof(name),&length,&size,&type,name);
            if(type!=GL_FLOAT_MAT4 || size!=1 || length<=0 || length>=255) continue;
            const char *label=strrchr(name,'.'); label=label?label+1:name;
            const char *field=NULL;
            if(!strcmp(label,"uProjMatrix")) field="uProjMatrix";
            else if(!strcmp(label,"uViewMatrix")) field="uViewMatrix";
            else if(!strcmp(label,"uViewInverseMatrix")) field="uViewInverseMatrix";
            else if(!strcmp(label,"uModelMatrix")) field="uModelMatrix";
            if(!field) continue;
            CameraField f={0}; f.program=program; f.index=i; f.field=field; f.location=pglGetUniformLocation(program,name);
            cglGetActiveUniformsiv(program,1,&i,GL_UNIFORM_BLOCK_INDEX,&f.block);
            if(f.block>=0) {
                cglGetActiveUniformsiv(program,1,&i,GL_UNIFORM_OFFSET,&f.offset);
                cglGetActiveUniformsiv(program,1,&i,GL_UNIFORM_MATRIX_STRIDE,&f.stride);
                cglGetActiveUniformsiv(program,1,&i,GL_UNIFORM_IS_ROW_MAJOR,&f.rowMajor);
                cglGetActiveUniformBlockiv(program,(GLuint)f.block,GL_UNIFORM_BLOCK_BINDING,&f.binding);
                if(f.offset<0 || f.offset>16777152 || f.stride!=16) continue;
            } else if(f.location<0) continue;
            cameraFields[cameraFieldCount++]=f;
        }
    }
    logLine("CAMERA_PROBE discovered fields=%u; candidates only",cameraFieldCount);
}
static bool cameraRead(const CameraField *f,float matrix[16],GLint *bufferOut) {
    *bufferOut=0;
    GLint count=0,size=0,block=0; GLenum type=0; char name[256]={0}; GLsizei length=0;
    pglGetProgramiv(f->program,GL_ACTIVE_UNIFORMS,&count);
    if(count<0 || f->index>=(GLuint)count) return false;
    cglGetActiveUniform(f->program,f->index,sizeof(name),&length,&size,&type,name);
    const char *label=strrchr(name,'.'); label=label?label+1:name;
    if(type!=GL_FLOAT_MAT4 || size!=1 || length<=0 || length>=255 || strcmp(label,f->field)) return false;
    cglGetActiveUniformsiv(f->program,1,&f->index,GL_UNIFORM_BLOCK_INDEX,&block);
    if(block!=f->block) return false;
    if(block<0 && pglGetUniformLocation(f->program,name)!=f->location) return false;
    if(block>=0) {
        GLint offset=0,stride=0,rowMajor=0;
        cglGetActiveUniformsiv(f->program,1,&f->index,GL_UNIFORM_OFFSET,&offset);
        cglGetActiveUniformsiv(f->program,1,&f->index,GL_UNIFORM_MATRIX_STRIDE,&stride);
        cglGetActiveUniformsiv(f->program,1,&f->index,GL_UNIFORM_IS_ROW_MAJOR,&rowMajor);
        if(offset!=f->offset || stride!=16 || rowMajor!=f->rowMajor) return false;
    }
    if(f->block<0) cglGetUniformfv(f->program,f->location,matrix);
    else {
        GLint binding=0,maxBindings=0,buffer=0,bufferSize=0;
        cglGetActiveUniformBlockiv(f->program,(GLuint)f->block,GL_UNIFORM_BLOCK_BINDING,&binding);
        glGetIntegerv(GL_MAX_UNIFORM_BUFFER_BINDINGS,&maxBindings);
        if(binding<0 || binding>=maxBindings) return false;
        cglGetIntegeri_v(GL_UNIFORM_BUFFER_BINDING,(GLuint)binding,&buffer); if(!buffer) return false;
        GLint64 start=0,range=0;
        cglGetInteger64i_v(GL_UNIFORM_BUFFER_START,(GLuint)binding,&start);
        cglGetInteger64i_v(GL_UNIFORM_BUFFER_SIZE,(GLuint)binding,&range);
        pglBindBuffer(GL_UNIFORM_BUFFER,(GLuint)buffer); cglGetBufferParameteriv(GL_UNIFORM_BUFFER,GL_BUFFER_SIZE,&bufferSize);
        if(start<0 || start>16777216 || bufferSize<=0 || bufferSize>16777216 || start+f->offset+64>bufferSize || (range>0 && f->offset+64>range)) return false;
        cglGetBufferSubData(GL_UNIFORM_BUFFER,(GLintptr)(start+f->offset),64,matrix); *bufferOut=buffer;
    }
    for(int i=0;i<16;++i) if(!isfinite(matrix[i]) || fabsf(matrix[i])>1e9f) return false;
    return true;
}
#ifndef SR1_LOCAL_REAVER_PRESENTATION
static void cameraObserve(HGLRC context) {
    if(!context || cameraSamples>=120 || (cameraContext && cameraContext!=context)) return;
    if(GetFileAttributesW(PROBE_PATH(L"\\camera-capture.enable"))==INVALID_FILE_ATTRIBUTES) return;
    if(!cameraAttempted) {
        if(!overlayReady) return; // overlay already gated GL>=3.2 and loaded common functions
        cameraAttempted=true; cameraContext=context;
#define CAMERA_LOAD(type,name) do { PROC fn=wglGetProcAddress(#name); if(!fn || (uintptr_t)fn<=3 || (uintptr_t)fn==UINTPTR_MAX) return; c##name=(type)fn; } while(0);
        CAMERA_GL(CAMERA_LOAD)
#undef CAMERA_LOAD
        cameraReady=true;
    }
    if(!cameraReady || GetTickCount64()-cameraLast<500) return;
    cameraLast=GetTickCount64();
    if(cameraSamples%10==0) cameraDiscover();
    GLint savedBuffer=0,program=0,viewport[4],fbo=0;
    glGetIntegerv(GL_UNIFORM_BUFFER_BINDING,&savedBuffer); glGetIntegerv(GL_CURRENT_PROGRAM,&program);
    glGetIntegerv(GL_VIEWPORT,viewport); glGetIntegerv(GL_DRAW_FRAMEBUFFER_BINDING,&fbo);
    wchar_t path[32768]; _snwprintf(path,ARRAYSIZE(path),PROBE_PATH(L"\\srx-camera-%lu.jsonl"),GetCurrentProcessId());
    FILE *out=_wfopen(path,cameraSamples?L"ab":L"wb");
    if(!out) { cameraReady=false; return; }
    fprintf(out,"{\"sample\":%u,\"tickMs\":%llu,\"currentProgram\":%d,\"drawFbo\":%d,\"viewport\":[%d,%d,%d,%d],\"matrices\":[",cameraSamples,(unsigned long long)cameraLast,program,fbo,viewport[0],viewport[1],viewport[2],viewport[3]);
    unsigned int written=0;
    for(unsigned int i=0;i<cameraFieldCount;++i) {
        CameraField *f=&cameraFields[i]; float matrix[16]; GLint buffer=0;
        if(!cglIsProgram(f->program) || !cameraRead(f,matrix,&buffer)) continue;
        if(written++) fputc(',',out);
        fprintf(out,"{\"program\":%u,\"field\":\"%s\",\"block\":%d,\"buffer\":%d,\"offset\":%d,\"rowMajor\":%d,\"matrix\":[",f->program,f->field,f->block,buffer,f->offset,f->rowMajor);
        for(int j=0;j<16;++j) { if(j) fputc(',',out); fprintf(out,"%.9g",matrix[j]); } fprintf(out,"]}");
    }
    pglBindBuffer(GL_UNIFORM_BUFFER,(GLuint)savedBuffer);
    GLint afterBuffer=0,afterProgram=0; glGetIntegerv(GL_UNIFORM_BUFFER_BINDING,&afterBuffer); glGetIntegerv(GL_CURRENT_PROGRAM,&afterProgram);
    bool restored=afterBuffer==savedBuffer && afterProgram==program;
    fprintf(out,"],\"restoredState\":%s}\n",restored?"true":"false"); fclose(out); ++cameraSamples;
    if(!restored) { logLine("CAMERA_PROBE state mismatch; disabled"); cameraReady=false; }
    if(cameraSamples==1 || cameraSamples%20==0) logLine("CAMERA_PROBE sample=%u matrices=%u restored=%d",cameraSamples,written,restored);
}
#endif
