// Caller supplies a readable buffer; each use retains its own size limit.
static bool boundedSha256(const void *data,ULONG length,ULONG maximum,char output[65]) {
    if(!data||!length||length>maximum)return false;
    BCRYPT_ALG_HANDLE alg=NULL;BCRYPT_HASH_HANDLE hash=NULL;unsigned char digest[32];bool ok=false;
    if(BCryptOpenAlgorithmProvider(&alg,BCRYPT_SHA256_ALGORITHM,NULL,0)<0)goto done;
    if(BCryptCreateHash(alg,&hash,NULL,0,NULL,0,0)<0)goto done;
    for(ULONG offset=0;offset<length;){
        ULONG chunk=length-offset;if(chunk>65536)chunk=65536;
        if(BCryptHashData(hash,(PUCHAR)data+offset,chunk,0)<0)goto done;
        offset+=chunk;
    }
    if(BCryptFinishHash(hash,digest,sizeof(digest),0)<0)goto done;
    for(int i=0;i<32;++i)sprintf(output+i*2,"%02x",digest[i]);output[64]=0;ok=true;
done:
    if(hash)BCryptDestroyHash(hash);if(alg)BCryptCloseAlgorithmProvider(alg,0);return ok;
}
