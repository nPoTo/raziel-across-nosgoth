// SPDX-License-Identifier: GPL-3.0-or-later
#pragma once
#include <math.h>
#include <stdbool.h>
#include <string.h>
typedef struct {bool seen;float q[4];} JumpArc;
static inline void jumpQMul(const float *a,const float *b,float *q){
 q[0]=a[3]*b[0]+a[0]*b[3]+a[1]*b[2]-a[2]*b[1];q[1]=a[3]*b[1]-a[0]*b[2]+a[1]*b[3]+a[2]*b[0];q[2]=a[3]*b[2]+a[0]*b[1]-a[1]*b[0]+a[2]*b[3];q[3]=a[3]*b[3]-a[0]*b[0]-a[1]*b[1]-a[2]*b[2];
}
static inline bool jumpArcBlend(const float *a,const float *target,float t,JumpArc *history,float *out){
 float inv[4]={-a[0],-a[1],-a[2],a[3]},q[4],dot=0,n=0; jumpQMul(inv,target,q);
 for(unsigned k=0;k<4;k++){n+=q[k]*q[k];dot+=q[k]*(history->seen?history->q[k]:(k==3?1.f:0.f));}
 if(n<1e-12f)return false;n=sqrtf(n);for(unsigned k=0;k<4;k++)q[k]/=dot<0?-n:n;
 float axis[3]={q[0],q[1],q[2]},v=sqrtf(q[0]*q[0]+q[1]*q[1]+q[2]*q[2]);
 if(v<1e-6f&&q[3]<0){if(!history->seen)return false;memcpy(axis,history->q,3*sizeof(float));}
 float length=sqrtf(axis[0]*axis[0]+axis[1]*axis[1]+axis[2]*axis[2]);
 memcpy(history->q,q,sizeof(q));history->seen=true;
 if(t==0||(v<1e-6f&&q[3]>=0)){memcpy(out,a,4*sizeof(float));return true;}
 if(t==1){memcpy(out,target,4*sizeof(float));return true;}
 if(length<1e-8f)return false;float angle=atan2f(v,q[3])*t,part[4];
 for(unsigned k=0;k<3;k++)part[k]=axis[k]/length*sinf(angle);part[3]=cosf(angle);jumpQMul(a,part,out);return true;
}
static inline bool jumpArcEdge(const float *a,const float *b,float t,JumpArc *history,float *out){
 float A=0,B=0;for(unsigned k=0;k<3;k++){A+=a[k]*a[k];B+=b[k]*b[k];}A=sqrtf(A);B=sqrtf(B);
 if(A<1e-6f||B<1e-6f){history->seen=false;for(unsigned k=0;k<3;k++)out[k]=a[k]+t*(b[k]-a[k]);return true;}
 float x[3],y[3],d=0;for(unsigned k=0;k<3;k++){x[k]=a[k]/A;y[k]=b[k]/B;d+=x[k]*y[k];}d=fmaxf(-1,fminf(1,d));
 float axis[3]={x[1]*y[2]-x[2]*y[1],x[2]*y[0]-x[0]*y[2],x[0]*y[1]-x[1]*y[0]},n=0;for(unsigned k=0;k<3;k++)n+=axis[k]*axis[k];
 if(n<1e-10f&&d<0){
  if(history->seen){float projection=0;for(unsigned k=0;k<3;k++)projection+=history->q[k]*x[k];for(unsigned k=0;k<3;k++)axis[k]=history->q[k]-projection*x[k];}
  n=0;for(unsigned k=0;k<3;k++)n+=axis[k]*axis[k];
  if(n<1e-10f){unsigned j=fabsf(x[0])<fabsf(x[1])?0:1;if(fabsf(x[2])<fabsf(x[j]))j=2;for(unsigned k=0;k<3;k++)axis[k]=(k==j?1.f:0.f)-x[j]*x[k];n=0;for(unsigned k=0;k<3;k++)n+=axis[k]*axis[k];}
 }
 float q[4]={0,0,0,1},blend[4],identity[4]={0,0,0,1};
 if(n>=1e-10f){float half=acosf(d)*.5f;n=sqrtf(n);for(unsigned k=0;k<3;k++)q[k]=axis[k]/n*sinf(half);q[3]=cosf(half);}
 if(!jumpArcBlend(identity,q,t,history,blend))return false;
 float p[4]={x[0],x[1],x[2],0},tmp[4],rotated[4],inverse[4]={-blend[0],-blend[1],-blend[2],blend[3]};jumpQMul(blend,p,tmp);jumpQMul(tmp,inverse,rotated);
 for(unsigned k=0;k<3;k++)out[k]=rotated[k]*(A+t*(B-A));return true;
}
