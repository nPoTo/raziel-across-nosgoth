// Current installed module, exact leaf through RET and exact running launch call site.
#define LIFT_LAUNCH_SHA "928d7c3b47e075ff774b50eab6ad2c11aa9128c388847cfc20a332aeba09be6b"
#define LIFT_COMPRESSION_SHA "f053cbdb42822d30aa163a4fdc171ccb3cd871986d407391557ad6cd3350b02b"
