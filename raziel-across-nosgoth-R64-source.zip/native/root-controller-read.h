typedef struct {uintptr_t node;bool found,active;unsigned char vector[12];} RootController;
static bool rootControllerRead(uintptr_t module,uintptr_t anim,unsigned kind,RootController *out){
 *out=(RootController){0};if(kind>1)return false;uintptr_t pool=0,poolAfter=0;uint16_t heads[2],again[2],seen[128];unsigned visited=0,matches=0,stride=kind?64:48;
 if(!worldRead(module+(kind?0x2bea48:0x2bea30),&pool,8)||!pool||!worldRead(anim+2,heads,4))return false;
 for(unsigned list=0;list<2;list++){uint16_t index=heads[list];while(index){
  if(index>4096||visited>=128||pool>UINTPTR_MAX-(uintptr_t)index*stride)return false;
  for(unsigned i=0;i<visited;i++)if(seen[i]==index)return false;seen[visited++]=index;
  unsigned char node[64];uintptr_t at=pool+(uintptr_t)index*stride;if(!worldRead(at,node,stride))return false;
  if(node[2]==34&&node[3]==0){if(++matches!=1)return false;out->found=true;out->active=list==0;out->node=at;memcpy(out->vector,node+0x20,kind?12:6);}memcpy(&index,node,2);
 }}
 if(!worldRead(module+(kind?0x2bea48:0x2bea30),&poolAfter,8)||poolAfter!=pool||!worldRead(anim+2,again,4)||memcmp(heads,again,4))return false;
 if(out->found&&kind){float v[3];memcpy(v,out->vector,12);for(unsigned k=0;k<3;k++)if(!isfinite(v[k]))return false;}return true;
}
