// SPDX-License-Identifier: GPL-3.0-or-later
#pragma once
static inline bool reaverPalmFrame(float out[16],const float points[9],const float origin[3]){
 if(!out||!points||!origin)return false;
 float z[3],t[3],x[3],zn=0,tn=0,dot=0,xn=0;
 for(unsigned k=0;k<3;k++){if(!isfinite(origin[k])||!isfinite(points[k])||!isfinite(points[3+k])||!isfinite(points[6+k]))return false;z[k]=points[3+k]-points[k];t[k]=points[6+k]-points[k];zn+=z[k]*z[k];tn+=t[k]*t[k];}
 if(!isfinite(zn)||!isfinite(tn)||zn<.000001f||tn<.000001f)return false;
 zn=sqrtf(zn);tn=sqrtf(tn);for(unsigned k=0;k<3;k++){z[k]/=zn;t[k]/=tn;dot+=z[k]*t[k];}
 if(1-dot*dot<.0001f)return false;
 for(unsigned k=0;k<3;k++){x[k]=t[k]-dot*z[k];xn+=x[k]*x[k];}xn=sqrtf(xn);
 if(!isfinite(xn)||xn<.000001f)return false;
 for(unsigned k=0;k<3;k++)x[k]/=xn;
 float m[16]={x[0],x[1],x[2],0,z[1]*x[2]-z[2]*x[1],z[2]*x[0]-z[0]*x[2],z[0]*x[1]-z[1]*x[0],0,z[0],z[1],z[2],0,origin[0],origin[1],origin[2],1};
 memcpy(out,m,sizeof(m));return true;
}
