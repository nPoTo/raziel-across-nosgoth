// SPDX-License-Identifier: GPL-3.0-or-later
#pragma once
#include "sr1-skeleton-shared.h"
#include "sr1-retarget-gate.h"
#ifdef SR1_JUMP_EXIT_CONTINUOUS
#include "jump-continuous-arc.h"
#endif
// Only presentation scratch is retained. No engine pointers are dereferenced here.
typedef struct {float q[4],p[3];} JumpLocal;
typedef struct {bool ready;uint64_t tick,epoch;uintptr_t actor,object,model;DWORD sourcePid,writerPid;int16_t parents[66];JumpLocal local[66];
#ifdef SR1_JUMP_EXIT_CONTINUOUS
JumpArc rotationArc[66],edgeArc[66];
#endif
} JumpExitBlend;
static inline bool jumpExitPolicy(void){const Sheet_nativeJumpExitBlend *p=&sheet_nativeJumpExitBlend_jump_fall;return p->durationMs==120&&p->maxAgeMs==150&&p->hostFallRva==0xef480&&p->linearPelvis&&p->maxTraceEvents==1024&&!p->gameWrites&&!p->enabled;}
static inline bool jumpExitContext(const Sr1RetargetContext *c){if(!c||!c->identity||!c->foreground||c->mode||c->crouchHeld||(c->flags&0x10000000u)||!c->verticalVelocityKnown)return false;for(unsigned i=0;i<3;i++)if(c->callbacks[i]!=0xef480)return false;return true;}
static inline void jumpQuat(const float *m,float *q){
 float t=m[0]+m[4]+m[8];
 if(t>0){float s=sqrtf(t+1)*2;q[3]=s/4;q[0]=(m[7]-m[5])/s;q[1]=(m[2]-m[6])/s;q[2]=(m[3]-m[1])/s;}
 else {unsigned i=m[4]>m[0]?1:0;if(m[8]>m[i*3+i])i=2;unsigned j=(i+1)%3,k=(j+1)%3;float s=sqrtf(1+m[i*3+i]-m[j*3+j]-m[k*3+k])*2;q[i]=s/4;q[j]=(m[i*3+j]+m[j*3+i])/s;q[k]=(m[i*3+k]+m[k*3+i])/s;q[3]=(m[k*3+j]-m[j*3+k])/s;}
}
static inline void jumpMatrix(const float *q,float *m){float x=q[0],y=q[1],z=q[2],w=q[3];m[0]=1-2*(y*y+z*z);m[1]=2*(x*y-z*w);m[2]=2*(x*z+y*w);m[3]=2*(x*y+z*w);m[4]=1-2*(x*x+z*z);m[5]=2*(y*z-x*w);m[6]=2*(x*z-y*w);m[7]=2*(y*z+x*w);m[8]=1-2*(x*x+y*y);}
static inline bool jumpLocals(const float world[66][13],const int16_t *parents,JumpLocal out[66]){
 if(parents[0]!=-1)return false;
 for(unsigned i=0;i<66;i++)if(!skeletonRigid(world[i]))return false;
 for(unsigned i=1;i<66;i++){int p=parents[i];if(p<0||p>=(int)i)return false;float m[13]={0};for(unsigned r=0;r<3;r++){for(unsigned c=0;c<3;c++)for(unsigned k=0;k<3;k++)m[r*3+c]+=world[p][k*3+r]*world[i][k*3+c];out[i].p[r]=0;for(unsigned k=0;k<3;k++)out[i].p[r]+=world[p][k*3+r]*(world[i][10+k]-world[p][10+k]);}jumpQuat(m,out[i].q);}
 return true;
}
static inline bool jumpExitCapture(JumpExitBlend *b,const SkeletonSnapshot *s,const int16_t *parents,const float actual[66][13],uint64_t now){
 b->ready=false;if(!jumpExitPolicy()||s->mode!=3||s->tick>now||now-s->tick>150)return false;
 #ifdef SR1_JUMP_EXIT_CONTINUOUS
 memset(b->rotationArc,0,sizeof(b->rotationArc));memset(b->edgeArc,0,sizeof(b->edgeArc));
#endif
 memset(b->local,0,sizeof(b->local));if(!jumpLocals(actual,parents,b->local))return false;
 b->tick=now;b->epoch=s->epoch;b->actor=s->actor;b->object=s->object;b->model=s->model;b->sourcePid=s->sourcePid;b->writerPid=s->writerPid;memcpy(b->parents,parents,sizeof(b->parents));b->ready=true;return true;
}
// Interpolate edge direction on the sphere, retaining interpolated edge length.
static inline void jumpEdge(const float *a,const float *b,float t,float *out){
 float A=0,B=0,d=0;for(unsigned k=0;k<3;k++){A+=a[k]*a[k];B+=b[k]*b[k];}A=sqrtf(A);B=sqrtf(B);
 if(A<1e-6f||B<1e-6f){for(unsigned k=0;k<3;k++)out[k]=a[k]+t*(b[k]-a[k]);return;}
 float x[3],y[3];for(unsigned k=0;k<3;k++){x[k]=a[k]/A;y[k]=b[k]/B;d+=x[k]*y[k];}d=fmaxf(-1,fminf(1,d));
 float v[3];if(d>.9995f){for(unsigned k=0;k<3;k++)v[k]=x[k]+t*(y[k]-x[k]);}
 else {float z[3],n=0;for(unsigned k=0;k<3;k++){z[k]=y[k]-d*x[k];n+=z[k]*z[k];}if(n<1e-8f){unsigned j=fabsf(x[0])<fabsf(x[1])?0:1;if(fabsf(x[2])<fabsf(x[j]))j=2;for(unsigned k=0;k<3;k++)z[k]=(k==j?1.f:0.f)-x[j]*x[k];n=0;for(unsigned k=0;k<3;k++)n+=z[k]*z[k];}n=sqrtf(n);float angle=acosf(d)*t;for(unsigned k=0;k<3;k++)v[k]=cosf(angle)*x[k]+sinf(angle)*z[k]/n;}
 float n=sqrtf(v[0]*v[0]+v[1]*v[1]+v[2]*v[2]);for(unsigned k=0;k<3;k++)out[k]=v[k]/n*(A+t*(B-A));
}
static inline bool jumpExitApply(JumpExitBlend *b,const SkeletonSnapshot *s,const Sr1RetargetContext *c,const int16_t *parents,const float current[66][13],uint64_t now,float out[66][13]){
 if(!b->ready||!jumpExitPolicy()||!jumpExitContext(c)||now<b->tick||now-b->tick>=120||s->tick>now||now-s->tick>150||s->epoch!=b->epoch||s->actor!=b->actor||s->object!=b->object||s->model!=b->model||s->sourcePid!=b->sourcePid||s->writerPid!=b->writerPid||memcmp(parents,b->parents,sizeof(b->parents))||(s->mode!=0&&s->mode!=3)){b->ready=false;return false;}
 JumpLocal native[66]={0};if(out==current||!jumpLocals(current,parents,native)){b->ready=false;return false;}
 float t=(float)(now-b->tick)/120.f;t=t*t*(3-2*t);memcpy(out,current,66*13*sizeof(float));
 for(unsigned i=1;i<66;i++){float q[4],dot=0,n=0,m[9],pos[3];for(unsigned k=0;k<4;k++)dot+=b->local[i].q[k]*native[i].q[k];for(unsigned k=0;k<4;k++){q[k]=(1-t)*b->local[i].q[k]+t*(dot<0?-1:1)*native[i].q[k];n+=q[k]*q[k];}if(n<1e-8f){b->ready=false;return false;}n=sqrtf(n);for(unsigned k=0;k<4;k++)q[k]/=n;
#ifdef SR1_JUMP_EXIT_CONTINUOUS
 if(!jumpArcBlend(b->local[i].q,native[i].q,t,&b->rotationArc[i],q)){b->ready=false;return false;}
#endif
 jumpMatrix(q,m);if(i==1){for(unsigned k=0;k<3;k++)pos[k]=b->local[i].p[k]+t*(native[i].p[k]-b->local[i].p[k]);}else {
#ifdef SR1_JUMP_EXIT_CONTINUOUS
 if(!jumpArcEdge(b->local[i].p,native[i].p,t,&b->edgeArc[i],pos)){b->ready=false;return false;}
#else
 jumpEdge(b->local[i].p,native[i].p,t,pos);
#endif
 }int p=parents[i];for(unsigned r=0;r<3;r++){for(unsigned c0=0;c0<3;c0++){out[i][r*3+c0]=0;for(unsigned k=0;k<3;k++)out[i][r*3+c0]+=out[p][r*3+k]*m[k*3+c0];}out[i][10+r]=out[p][10+r];for(unsigned k=0;k<3;k++)out[i][10+r]+=out[p][r*3+k]*pos[k];}if(!skeletonRigid(out[i])){b->ready=false;return false;}}
 return true;
}
