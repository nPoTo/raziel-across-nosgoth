// SPDX-License-Identifier: GPL-3.0-or-later
#pragma once
// Actual 48-byte shader palette, separate from the original 52-byte bone array.
// Caller must establish that both reads bracket the submitted player's draw.
typedef struct {ReaverSubmittedHand hand;uint64_t context;unsigned joints;float values[96*12];bool valid;} ReaverJointPalette;
static inline bool reaverPaletteCapture(ReaverJointPalette *out,const ReaverSubmittedHand *hand,uint64_t context,
 const float *before,unsigned countBefore,const float *after,unsigned countAfter,bool submittedPlayer){
 if(!out)return false;memset(out,0,sizeof(*out));
 const Sheet_reaverPalettePolicy *p=&sheet_reaverPalettePolicy_submitted_gpu_palette;
 if(p->nativeIntegrationEnabled||p->maxJoints!=96||p->floatsPerJoint!=12||!p->requireExactBytes||!p->requireSameFrame||
 !hand||!hand->valid||!hand->draw||!context||!submittedPlayer||!before||!after||!countBefore||countBefore>96||countBefore!=countAfter)return false;
 const size_t bytes=countBefore*12*sizeof(float);if(memcmp(before,after,bytes))return false;
 for(unsigned i=0;i<countBefore*12;i++)if(!isfinite(before[i])||fabsf(before[i])>1e9f)return false;
 out->hand=*hand;out->context=context;out->joints=countBefore;memcpy(out->values,before,bytes);out->valid=true;return true;
}
static inline bool reaverPaletteMatches(const ReaverJointPalette *p,const float *gpu,unsigned joints,
 uint64_t actor,uint64_t model,uint64_t session,uint64_t frame,uint64_t context){
 return p&&p->valid&&gpu&&joints&&joints<=96&&p->joints==joints&&context&&p->context==context&&
 reaverHandCurrent(&p->hand,actor,model,session,frame)&&!memcmp(p->values,gpu,joints*12*sizeof(float));
}
