// SPDX-License-Identifier: GPL-3.0-or-later
#pragma once
// Existing GL reflection functions only. No hard-coded program, buffer or binding.
// Reads current uJoints without changing indexed bindings or consuming GL errors.
static bool reaverGpuPaletteRead(float out[96*12],unsigned joints,HGLRC context,GLuint program){
 memset(out,0,96*12*sizeof(float));
 if(!joints||joints>96||!context||wglGetCurrentContext()!=context||!program||!cameraReady||!cglIsProgram(program))return false;
 GLint current=0,fbo=0,saved=0,count=0;glGetIntegerv(GL_CURRENT_PROGRAM,&current);glGetIntegerv(GL_DRAW_FRAMEBUFFER_BINDING,&fbo);
 if((GLuint)current!=program||fbo)return false;glGetIntegerv(GL_UNIFORM_BUFFER_BINDING,&saved);
 pglGetProgramiv(program,GL_ACTIVE_UNIFORMS,&count);bool ok=count>0&&count<=1024;unsigned found=0;
 for(GLuint i=0;ok&&i<(GLuint)count;i++){
  char name[256]={0};GLsizei length=0;GLint size=0;GLenum type=0;
  cglGetActiveUniform(program,i,sizeof(name),&length,&size,&type,name);
  if(length<=0||length>=255)continue;const char *label=strrchr(name,'.');label=label?label+1:name;
  if(strcmp(label,"uJoints[0]")&&strcmp(label,"uJoints"))continue;
  if(++found!=1||type!=GL_FLOAT_VEC4||size<(GLint)(joints*3)||size>288){ok=false;break;}
  GLint block=-1;cglGetActiveUniformsiv(program,1,&i,GL_UNIFORM_BLOCK_INDEX,&block);
  if(block<0){
   // Array elements need not have adjacent uniform locations.
   size_t baseLength=strlen(name);if(baseLength>=3&&!strcmp(name+baseLength-3,"[0]"))name[baseLength-3]=0;
   for(unsigned row=0;ok&&row<joints*3;row++){
    char element[272];snprintf(element,sizeof(element),"%s[%u]",name,row);
    GLint location=pglGetUniformLocation(program,element);if(location<0){ok=false;break;}
    cglGetUniformfv(program,location,out+row*4);
   }
  }else{
   GLint offset=0,stride=0,binding=0,maxBindings=0,buffer=0,bufferSize=0;
   cglGetActiveUniformsiv(program,1,&i,GL_UNIFORM_OFFSET,&offset);cglGetActiveUniformsiv(program,1,&i,GL_UNIFORM_ARRAY_STRIDE,&stride);
   cglGetActiveUniformBlockiv(program,(GLuint)block,GL_UNIFORM_BLOCK_BINDING,&binding);glGetIntegerv(GL_MAX_UNIFORM_BUFFER_BINDINGS,&maxBindings);
   if(offset<0||offset>16777216||stride!=16||binding<0||binding>=maxBindings){ok=false;break;}
   cglGetIntegeri_v(GL_UNIFORM_BUFFER_BINDING,(GLuint)binding,&buffer);if(!buffer){ok=false;break;}
   GLint64 start=0,range=0;cglGetInteger64i_v(GL_UNIFORM_BUFFER_START,(GLuint)binding,&start);cglGetInteger64i_v(GL_UNIFORM_BUFFER_SIZE,(GLuint)binding,&range);
   pglBindBuffer(GL_UNIFORM_BUFFER,(GLuint)buffer);cglGetBufferParameteriv(GL_UNIFORM_BUFFER,GL_BUFFER_SIZE,&bufferSize);
   const GLint64 bytes=(GLint64)joints*48;
   if(start<0||start>16777216||range<0||bufferSize<=0||bufferSize>16777216||start+offset+bytes>bufferSize||(range>0&&offset+bytes>range)){ok=false;break;}
   cglGetBufferSubData(GL_UNIFORM_BUFFER,(GLintptr)(start+offset),(GLsizeiptr)bytes,out);
  }
 }
 pglBindBuffer(GL_UNIFORM_BUFFER,(GLuint)saved);GLint restored=0;glGetIntegerv(GL_UNIFORM_BUFFER_BINDING,&restored);
 glGetIntegerv(GL_CURRENT_PROGRAM,&current);glGetIntegerv(GL_DRAW_FRAMEBUFFER_BINDING,&fbo);
 ok=ok&&found==1&&restored==saved&&(GLuint)current==program&&!fbo&&wglGetCurrentContext()==context;
 for(unsigned i=0;ok&&i<joints*12;i++)ok=isfinite(out[i])&&fabsf(out[i])<=1e9f;
 if(!ok)memset(out,0,96*12*sizeof(float));return ok;
}
static bool reaverGpuPaletteMatches(const ReaverJointPalette *p,HGLRC context,GLuint program,
 uint64_t actor,uint64_t model,uint64_t session,uint64_t frame){
 if(!p||!p->valid||!context||p->context!=(uint64_t)(uintptr_t)context||!reaverHandCurrent(&p->hand,actor,model,session,frame))return false;
 float a[96*12],b[96*12];
 return reaverGpuPaletteRead(a,p->joints,context,program)&&reaverGpuPaletteRead(b,p->joints,context,program)&&
 !memcmp(a,b,p->joints*12*sizeof(float))&&reaverPaletteMatches(p,a,p->joints,actor,model,session,frame,(uint64_t)(uintptr_t)context);
}
