// SPDX-License-Identifier: GPL-3.0-or-later
#pragma once
// Pure receipt only. Caller owns player-scope proof and real render-frame IDs.
// Uses decodeHostRenderRoot from the existing host-transform.h.
typedef struct {
 uint64_t actor,model,session,frame,draw;
 float matrix[16];bool valid;
} ReaverSubmittedHand;
static inline void reaverHandClear(ReaverSubmittedHand *out){memset(out,0,sizeof(*out));}
static inline bool reaverHandCapture(ReaverSubmittedHand *out,
 const float before[66][13],const float after[66][13],
 uint64_t actor,uint64_t model,uint64_t session,uint64_t frame,uint64_t draw,
 bool playerScope,bool identityUnchanged,unsigned depth){
 reaverHandClear(out);
 const Sheet_reaverSubmittedHand *p=&sheet_reaverSubmittedHand_submitted_hand;
 if(p->hostBone!=49||p->hostBones!=66||p->matrixFloats!=13||p->consumerRva!=0x40d10||
 !p->requireSameFrame||!p->requirePostCallUnchanged||p->gameWrites||p->nativeIntegrationEnabled||
 !before||!after||!actor||!model||!session||!frame||!draw||!playerScope||!identityUnchanged||depth!=1||
 memcmp(before,after,66*13*sizeof(float)))return false;
 float hand[16];if(!decodeHostRenderRoot((const unsigned char *)before[p->hostBone],hand))return false;
 out->actor=actor;out->model=model;out->session=session;out->frame=frame;out->draw=draw;
 memcpy(out->matrix,hand,sizeof(hand));out->valid=true;return true;
}
static inline bool reaverHandCurrent(const ReaverSubmittedHand *s,uint64_t actor,uint64_t model,uint64_t session,uint64_t frame){
 return s&&s->valid&&s->draw&&s->actor==actor&&s->model==model&&s->session==session&&s->frame==frame;
}
