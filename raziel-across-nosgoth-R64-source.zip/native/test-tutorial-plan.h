typedef struct {unsigned begin,end;const wchar_t *title,*detail;} TutorialStage;
#include "exploration-sheets.h"
static unsigned tutorialWalkJumpSeconds(void);
static const TutorialStage *tutorialWalkJumpStageAt(unsigned elapsed);
// Include startup/heartbeat shutdown margins without imposing a shorter wall
// clock than the selected timeline (the old fixed180s cut off lifetime HUDs).
static uint64_t tutorialWallBudgetMs(unsigned seconds){return (uint64_t)seconds*1000+15000;}
static unsigned tutorialInteractionSeconds(void){return (unsigned)sheet_interactionObservationPolicy_bounded.seconds;}
static unsigned tutorialRoomSeconds(void){return (unsigned)sheet_roomObservationPolicy_bounded.seconds;}
static const TutorialStage *tutorialRoomStageAt(unsigned elapsed){
 static TutorialStage stage;
 for(unsigned k=0;k<ARRAYSIZE(sheet_roomObservationStages_rows);k++){
  const Sheet_roomObservationStages *s=sheet_roomObservationStages_rows[k];
  if(elapsed>=s->begin&&elapsed<s->end){stage=(TutorialStage){(unsigned)s->begin,(unsigned)s->end,s->title,s->detail};return &stage;}
 }return NULL;
}
static const TutorialStage *tutorialGlideStageAt(unsigned elapsed){
 static TutorialStage stage;
 for(unsigned k=0;k<ARRAYSIZE(sheet_glideObservationStages_rows);k++){
  const Sheet_glideObservationStages *s=sheet_glideObservationStages_rows[k];
  if(elapsed>=s->begin&&elapsed<s->end){stage=(TutorialStage){(unsigned)s->begin,(unsigned)s->end,s->title,s->detail};return &stage;}
 }return NULL;
}
static const TutorialStage *tutorialInteractionStageAt(unsigned elapsed){
 static TutorialStage stage;
 for(unsigned k=0;k<ARRAYSIZE(sheet_interactionObservationStages_rows);k++){
  const Sheet_interactionObservationStages *s=sheet_interactionObservationStages_rows[k];
  if(elapsed>=s->begin&&elapsed<s->end){stage=(TutorialStage){(unsigned)s->begin,(unsigned)s->end,s->title,s->detail};return &stage;}
 }return NULL;
}
static unsigned tutorialLifetimeSeconds(void){return (unsigned)sheet_sessionLifetime_session.testSeconds;}
static const TutorialStage *tutorialLifetimeStageAt(unsigned elapsed){
 static TutorialStage stage;
 if(elapsed<tutorialWalkJumpSeconds())return tutorialWalkJumpStageAt(elapsed);
 if(elapsed>=tutorialLifetimeSeconds())return NULL;
 for(unsigned k=0;k<ARRAYSIZE(sheet_tutorialLifetimeStages_rows);k++){
  const Sheet_tutorialLifetimeStages *s=sheet_tutorialLifetimeStages_rows[k];
  if(elapsed>=s->begin&&elapsed<s->end){stage=(TutorialStage){(unsigned)s->begin,(unsigned)s->end,s->title,s->detail};return &stage;}
 }return NULL;
}
static unsigned tutorialWalkJumpSeconds(void){return (unsigned)sheet_tutorialStages_rows[ARRAYSIZE(sheet_tutorialStages_rows)-1]->end;}
static const TutorialStage *tutorialWalkJumpStageAt(unsigned elapsed){
 static TutorialStage current;
 for(unsigned k=0;k<ARRAYSIZE(sheet_tutorialStages_rows);k++){
  const Sheet_tutorialStages *s=sheet_tutorialStages_rows[k];
  if(elapsed>=s->begin&&elapsed<s->end){current=(TutorialStage){(unsigned)s->begin,(unsigned)s->end,s->title,s->detail};return &current;}
 }return NULL;
}
#define TUTORIAL_SECONDS 138
static const TutorialStage tutorialStages[]={
 {0,12,L"STAY",L"Release all buttons. Stand on clear, level ground."},
 {12,34,L"MOVE + TURN",L"Left stick: move, reverse direction, release and stop."},
 {34,64,L"LB + A  —  EVADE",L"Hold LB, move the stick, tap A. Forward / back / left / right."},
 {64,90,L"Y  →  X",L"Hold Y to rise. Attack with X in the air. Release X to fall."},
 {90,112,L"A  —  JUMP + GLIDE",L"Release LB. Jump with A, hold A to glide, then land."},
 {112,126,L"RB  —  FEED",L"Hold RB for 3 seconds, then release."},
 {126,138,L"STAY",L"Release all buttons. Wait for recording to finish."}
};
static inline const TutorialStage *tutorialStageAt(unsigned elapsed){for(unsigned k=0;k<sizeof(tutorialStages)/sizeof(tutorialStages[0]);k++)if(elapsed>=tutorialStages[k].begin&&elapsed<tutorialStages[k].end)return &tutorialStages[k];return NULL;}
static const TutorialStage tutorialGroundStages[]={
 {0,12,L"STAY",L"Release all buttons. Wait for the movement link."},
 {12,34,L"MOVE + STOP",L"Left stick: move on clear ground, release, then move again."},
 {34,60,L"TURN + REVERSE",L"Move forward, stop, move back. Try left and right."},
 {60,94,L"LB + A  —  EVADE",L"Hold LB, move the stick, tap A. Forward / back / left / right."},
 {94,120,L"MOVE + TURN",L"Move, change direction and stop. No jump or attack buttons."},
 {120,138,L"STAY",L"Release all buttons. Wait for the original controls to return."}
};
static inline const TutorialStage *tutorialGroundStageAt(unsigned elapsed){for(unsigned k=0;k<sizeof(tutorialGroundStages)/sizeof(tutorialGroundStages[0]);k++)if(elapsed>=tutorialGroundStages[k].begin&&elapsed<tutorialGroundStages[k].end)return &tutorialGroundStages[k];return NULL;}
static const TutorialStage tutorialCameraStages[]={
 {0,12,L"STAY",L"Release all buttons. Keep Raziel still."},
 {12,42,L"CAMERA — LEFT / RIGHT",L"Right stick only: turn the camera left, then right. Do not move Raziel."},
 {42,68,L"CAMERA — UP / DOWN",L"Right stick only: look up, then down. Keep Raziel still."},
 {68,80,L"STAY",L"Release both sticks. Let the camera settle."},
 {80,108,L"MOVE FORWARD + TURN CAMERA",L"Move with the left stick. Turn the camera with the right stick."},
 {108,128,L"FORWARD / BACK",L"Left stick: move forward, stop, then move back."},
 {128,138,L"STAY",L"Release all buttons. Wait for recording to finish."}
};
static inline const TutorialStage *tutorialCameraStageAt(unsigned elapsed){for(unsigned k=0;k<sizeof(tutorialCameraStages)/sizeof(tutorialCameraStages[0]);k++)if(elapsed>=tutorialCameraStages[k].begin&&elapsed<tutorialCameraStages[k].end)return &tutorialCameraStages[k];return NULL;}
static const TutorialStage tutorialVisibilityStages[]={
 {0,12,L"STAY — OPEN FLOOR",L"Release both sticks. Stand outside the tunnel."},
 {12,36,L"CAMERA — OPEN FLOOR",L"Right stick only: turn left and right. Keep Raziel still."},
 {36,60,L"ENTER THE TUNNEL",L"Walk into the nearby tunnel. Release both sticks when inside."},
 {60,90,L"STAY — INSIDE TUNNEL",L"Release all buttons and sticks. Watch whether the level flickers."},
 {90,116,L"CAMERA — INSIDE TUNNEL",L"Right stick only: slowly turn left and right. Keep Raziel still."},
 {116,138,L"EXIT THE TUNNEL",L"Walk back to the open floor, then release both sticks."}
};
static inline const TutorialStage *tutorialVisibilityStageAt(unsigned elapsed){for(unsigned k=0;k<sizeof(tutorialVisibilityStages)/sizeof(tutorialVisibilityStages[0]);k++)if(elapsed>=tutorialVisibilityStages[k].begin&&elapsed<tutorialVisibilityStages[k].end)return &tutorialVisibilityStages[k];return NULL;}
