// SPDX-License-Identifier: GPL-3.0-or-later
#pragma once
#include "guidance-plan.h"
static HDC guidanceDC;static HBITMAP guidanceBitmap;static unsigned char *guidancePixels;
static bool guidanceInitText(void){
 if(guidancePixels)return true;
 BITMAPINFO bi={0};bi.bmiHeader.biSize=sizeof(BITMAPINFOHEADER);bi.bmiHeader.biWidth=(LONG)sheet_guidanceRenderPolicy_native.rasterWidth;bi.bmiHeader.biHeight=-(LONG)sheet_guidanceRenderPolicy_native.rasterHeight;bi.bmiHeader.biPlanes=1;bi.bmiHeader.biBitCount=32;bi.bmiHeader.biCompression=BI_RGB;
 guidanceDC=CreateCompatibleDC(NULL);guidanceBitmap=CreateDIBSection(guidanceDC,&bi,DIB_RGB_COLORS,(void **)&guidancePixels,NULL,0);
 if(!guidanceDC||!guidanceBitmap||!guidancePixels){if(guidanceBitmap)DeleteObject(guidanceBitmap);if(guidanceDC)DeleteDC(guidanceDC);guidanceBitmap=NULL;guidanceDC=NULL;guidancePixels=NULL;return false;}
 SelectObject(guidanceDC,guidanceBitmap);SetBkMode(guidanceDC,TRANSPARENT);SetTextColor(guidanceDC,RGB(255,255,255));return true;
}
static void guidanceText(const wchar_t *text,int top,int bottom,int pixels){
 HFONT font=CreateFontW(-pixels,0,0,0,FW_SEMIBOLD,FALSE,FALSE,FALSE,DEFAULT_CHARSET,OUT_DEFAULT_PRECIS,CLIP_DEFAULT_PRECIS,ANTIALIASED_QUALITY,DEFAULT_PITCH,L"Segoe UI");
 HGDIOBJ old=SelectObject(guidanceDC,font?font:GetStockObject(DEFAULT_GUI_FONT));RECT r={12,top,(LONG)sheet_guidanceRenderPolicy_native.rasterWidth-12,bottom};DrawTextW(guidanceDC,text,-1,&r,DT_CENTER|DT_WORDBREAK|DT_NOPREFIX);SelectObject(guidanceDC,old);if(font)DeleteObject(font);
}
static bool guidanceRaster(unsigned plan,unsigned elapsed){
 const TutorialStage *stage=guidanceStageAt(plan,elapsed);unsigned seconds=guidanceSeconds(plan);if(!stage||elapsed>=seconds||!guidanceInitText())return false;
 size_t count=(size_t)sheet_guidanceRenderPolicy_native.rasterWidth*(size_t)sheet_guidanceRenderPolicy_native.rasterHeight;
 memset(guidancePixels,0,count*4);
 guidanceText(stage->title,8,50,(int)sheet_guidanceRenderPolicy_native.titlePixels);guidanceText(stage->detail,54,116,(int)sheet_guidanceRenderPolicy_native.detailPixels);
 wchar_t counter[160];_snwprintf(counter,160,L"Остават %u:%02u   |   За действието: %u сек.",(seconds-elapsed)/60,(seconds-elapsed)%60,stage->end-elapsed);guidanceText(counter,130,174,(int)sheet_guidanceRenderPolicy_native.counterPixels);GdiFlush();
 // GDI writes RGB coverage but does not provide useful alpha. Keep all empty
 // pixels transparent; the renderer discards them instead of drawing a panel.
 for(size_t p=0;p<count;p++)guidancePixels[p*4+3]=guidancePixels[p*4];return true;
}
