// SR1 legacy fixed-point root MATRIX: int16 rotation /4096, int32 translation.
static bool decodeHostRoot(const unsigned char raw[32],float out[16]) {
    memset(out,0,16*sizeof(float)); out[15]=1;
    for(int r=0;r<3;r++) for(int c=0;c<3;c++) { int16_t v; memcpy(&v,raw+(r*3+c)*2,2); out[c*4+r]=v/4096.0f; }
    for(int k=0;k<3;k++) { int32_t v; memcpy(&v,raw+20+k*4,4); out[12+k]=(float)v; if(v < -1000000 || v > 1000000) return false; }
    for(int c=0;c<3;c++) for(int d=c;d<3;d++) {
        float dot=0; for(int r=0;r<3;r++) dot+=out[c*4+r]*out[d*4+r];
        if(fabsf(dot-(c==d?1.0f:0.0f))>.03f) return false;
    }
    float det=out[0]*(out[5]*out[10]-out[9]*out[6])-out[4]*(out[1]*out[10]-out[9]*out[2])+out[8]*(out[1]*out[6]-out[5]*out[2]);
    return fabsf(det-1)<.05f;
}
// Native HD renderer input: packed float 3x3, one padding float, XYZ at40.
static bool decodeHostRenderRoot(const unsigned char raw[52],float out[16]) {
    memset(out,0,64);out[15]=1;
    for(int r=0;r<3;r++)for(int c=0;c<3;c++){float v;memcpy(&v,raw+(r*3+c)*4,4);if(!isfinite(v))return false;out[c*4+r]=v;}
    for(int k=0;k<3;k++){memcpy(out+12+k,raw+40+k*4,4);if(!isfinite(out[12+k])||fabsf(out[12+k])>1000000)return false;}
    for(int c=0;c<3;c++)for(int d=c;d<3;d++){float dot=0;for(int r=0;r<3;r++)dot+=out[c*4+r]*out[d*4+r];if(fabsf(dot-(c==d))>.03f)return false;}
    float det=out[0]*(out[5]*out[10]-out[9]*out[6])-out[4]*(out[1]*out[10]-out[9]*out[2])+out[8]*(out[1]*out[6]-out[5]*out[2]);return fabsf(det-1)<.05f;
}
static void hostMultiply(const float a[16],const float b[16],float out[16]) {
    float temp[16];
    for(int c=0;c<4;c++) for(int r=0;r<4;r++) {float v=0; for(int k=0;k<4;k++) v+=a[k*4+r]*b[c*4+k]; temp[c*4+r]=v;}
    memcpy(out,temp,sizeof(temp));
}
