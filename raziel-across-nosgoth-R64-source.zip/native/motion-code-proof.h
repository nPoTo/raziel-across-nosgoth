// Generated exact supported controller-vector code proofs.
static const struct {uint32_t rva,size;const char *sha256;} motionCodeProofs[]={
{0x64060,36,"b4a7cb1deb058a0e49882855b5d40ec8339a407c838582b4ef951fc5d012d6b0"},
{0x64090,38,"92ecc6b8995657c9de400237d84a2483bd1e5892f3dfea9ce9571c1667e50fef"},
};
