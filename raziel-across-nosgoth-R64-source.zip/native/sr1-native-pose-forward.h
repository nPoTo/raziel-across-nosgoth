// SPDX-License-Identifier: GPL-3.0-or-later
#pragma once
#include <stdint.h>
// Windows x64 native consumer has four register and four32-bit stack slots.
// Forward opaque slots/return; never invent values or call it synthetically.
typedef uintptr_t (*Sr1NativePoseFn)(uintptr_t,uintptr_t,uintptr_t,uintptr_t,uintptr_t,uintptr_t,uintptr_t,uintptr_t);
static inline int sr1NativePoseArgumentsMatch(uintptr_t record,uintptr_t model,uintptr_t matrices,uintptr_t object,uintptr_t expectedModel,uintptr_t expectedMatrices,uintptr_t recordOffset){
 return object&&expectedModel&&expectedMatrices&&object<=UINTPTR_MAX-recordOffset&&record==object+recordOffset&&model==expectedModel&&matrices==expectedMatrices;
}
static inline uintptr_t sr1NativePoseForward(Sr1NativePoseFn original,const uintptr_t a[8]){
 return original(a[0],a[1],a[2],a[3],a[4],a[5],a[6],a[7]);
}
