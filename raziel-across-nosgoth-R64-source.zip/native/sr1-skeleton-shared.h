// SPDX-License-Identifier: GPL-3.0-or-later
#pragma once
#include <windows.h>
#include <stdint.h>
#include <stdbool.h>
#include <math.h>
#include <string.h>
#include "exploration-sheets.h"
#include "skeleton-policy-identity.h"
enum {SKELETON_BONES=66,SKELETON_FLOATS=13,SKELETON_MAGIC=0x31535a52};
typedef struct {
 uint32_t magic,version,hostPid,sourcePid,writerPid,mode;
 uint64_t epoch,tick,hostTick,sourceTick,sequence,actor,object,model;
 float bones[66][13];unsigned char policyHash[32];
} SkeletonSnapshot;
typedef struct {volatile LONG sequence;SkeletonSnapshot snapshot;} SkeletonShared;
_Static_assert(sizeof(SkeletonSnapshot)==3552,"Frozen skeleton-only wire layout");
static inline void skeletonNames(wchar_t name[96],DWORD pid){_snwprintf(name,96,L"Local\\LOKSkeletonOnly-%lu",pid);}
static inline bool skeletonRigid(const float m[13]){
 for(unsigned i=0;i<13;i++)if(!isfinite(m[i])||fabsf(m[i])>1000000)return false;
 for(unsigned a=0;a<3;a++)for(unsigned b=a;b<3;b++){float v=0;for(unsigned k=0;k<3;k++)v+=m[k*3+a]*m[k*3+b];if(fabsf(v-(a==b))>.03f)return false;}
 float d=m[0]*(m[4]*m[8]-m[5]*m[7])-m[1]*(m[3]*m[8]-m[5]*m[6])+m[2]*(m[3]*m[7]-m[4]*m[6]);return fabsf(d-1)<.06f;
}
static inline bool skeletonLocalValid(const float bones[66][13]){
 for(unsigned i=0;i<66;i++){if(!skeletonRigid(bones[i]))return false;for(unsigned k=10;k<13;k++)if(fabsf(bones[i][k])>10000)return false;}
 for(unsigned k=0;k<13;k++)if(fabsf(bones[0][k]-((k==0||k==4||k==8)?1:0))>1e-6f)return false;
 return true;
}
static inline bool skeletonPacketValid(const SkeletonSnapshot *s,DWORD pid,uint64_t now){
 const Sheet_nativeSkeletonPolicy *p=&sheet_nativeSkeletonPolicy_bounded;
 if(!s||p->bones!=66||p->matrixFloats!=13||p->weighted!=57||p->extraRaw||p->freshMs!=150||!((p->seconds==100&&p->maxSessionMs==120000)||(p->seconds==120&&p->maxSessionMs==140000)||(p->seconds==170&&p->maxSessionMs==200000))||p->copyCalls!=20||p->hostWrites||p->bodyPayload||p->sourceRoot||p->foreignDrawsYield)return false;
 unsigned maxMode=2;
#ifdef SR1_NATIVE_JUMP_POSE
 maxMode=3;
#endif
 if(s->magic!=SKELETON_MAGIC||s->version!=1||s->hostPid!=pid||!s->sourcePid||!s->writerPid||s->sourcePid==pid||s->writerPid==pid||s->mode>maxMode||memcmp(s->policyHash,skeletonPolicyHash,32))return false;
 if(!s->epoch||!s->sequence||!s->actor||!s->object||!s->model||s->epoch>s->tick||s->tick>now||now-s->tick>150||s->tick-s->epoch>=(uint64_t)p->maxSessionMs)return false;
 if(s->hostTick>s->tick||s->sourceTick>s->tick||s->tick-s->hostTick>150||s->tick-s->sourceTick>150)return false;
 return s->mode<2||skeletonLocalValid(s->bones);
}
static inline bool skeletonCopy(const SkeletonShared *shared,SkeletonSnapshot *out){
 if(!shared||!out)return false;for(unsigned n=0;n<3;n++){LONG seq=shared->sequence;if(seq&1)continue;MemoryBarrier();memcpy(out,&shared->snapshot,sizeof(*out));MemoryBarrier();if(seq==shared->sequence)return true;}return false;
}
static inline void skeletonStore(SkeletonShared *shared,const SkeletonSnapshot *s){InterlockedIncrement(&shared->sequence);MemoryBarrier();memcpy(&shared->snapshot,s,sizeof(*s));MemoryBarrier();InterlockedIncrement(&shared->sequence);}
static inline bool skeletonRebase(float out[66][13],const float current[66][13],const float local[66][13]){
 if(!out||!current||!local||out==current||out==local||!skeletonRigid(current[0])||!skeletonLocalValid(local))return false;
 memcpy(out,current,66*13*sizeof(float));
 for(unsigned i=1;i<66;i++){
  for(unsigned r=0;r<3;r++){for(unsigned c=0;c<3;c++){float v=0;for(unsigned k=0;k<3;k++)v+=current[0][r*3+k]*local[i][k*3+c];out[i][r*3+c]=v;}
   float v=current[0][10+r];for(unsigned k=0;k<3;k++)v+=current[0][r*3+k]*local[i][10+k];out[i][10+r]=v;
  }
  if(!skeletonRigid(out[i]))return false;
 }
 return true;
}
typedef struct {uint64_t epoch,lastYield,lastSequence;DWORD thread;unsigned copies;bool failed;} SkeletonAdmission;
// A different object is not evidence that the player entered a native action.
static inline void skeletonMarkDrawYield(SkeletonAdmission *a,bool playerScope,DWORD thread,uint64_t now){
 if(playerScope&&thread&&thread==a->thread)a->lastYield=now;
}
static inline bool skeletonRootMoved(const float previous[13],const float current[13]){
 float x=current[10]-previous[10],y=current[11]-previous[11];return isfinite(x)&&isfinite(y)&&x*x+y*y>.0001f;
}
static inline bool skeletonAdmit(SkeletonAdmission *a,const SkeletonSnapshot *s,DWORD thread,uint64_t now,bool context){
 if(a->failed||!thread||!s->mode)return false;
 if(!a->epoch){if(s->mode!=1)return false;a->epoch=s->epoch;a->thread=thread;}
 if(a->epoch!=s->epoch||a->thread!=thread||s->sequence<a->lastSequence)return false;
 a->lastSequence=s->sequence;
 if(s->mode==1)return true;
 if(!context){a->lastYield=now;return false;}
 return a->copies>=20&&s->hostTick>=a->lastYield&&s->sourceTick>=a->lastYield;
}
