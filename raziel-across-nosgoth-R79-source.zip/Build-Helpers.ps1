param([string]$PayloadZip)
$ErrorActionPreference='Stop'
$source79=Join-Path $PSScriptRoot 'portable'
$out79=Join-Path $PSScriptRoot 'rebuilt-helpers'
$art79=Join-Path $PSScriptRoot 'workbench/desktop-sr1-linked-r1/assets'
$csc79=Join-Path $env:WINDIR 'Microsoft.NET/Framework64/v4.0.30319/csc.exe'
New-Item -ItemType Directory -Force -Path $out79 | Out-Null
$refs79=@('/r:System.Windows.Forms.dll','/r:System.Drawing.dll','/r:System.Web.Extensions.dll','/r:System.Core.dll','/r:System.IO.Compression.dll','/r:System.IO.Compression.FileSystem.dll')
$core79=@((Join-Path $source79 'PortableCore60.cs'),(Join-Path $source79 'Version79.cs'))
& $csc79 /nologo /target:winexe /platform:x64 "/out:$(Join-Path $out79 'RazielBootstrap.exe')" @refs79 @core79 "/resource:$(Join-Path $source79 'assets/guide72.png'),FieldGuide72" "/resource:$(Join-Path $source79 'combo-controls75.tsv'),ComboControls75" "/resource:$(Join-Path $art79 'reaver-light.ico'),ReaverOn72" "/resource:$(Join-Path $art79 'reaver-dark.ico'),ReaverOff72" (Join-Path $source79 'Bootstrap60.cs') (Join-Path $source79 'UpdateCore79.cs')
if($LASTEXITCODE-ne 0){throw 'Bootstrap compile failed'}
& $csc79 /nologo /target:winexe /platform:x64 "/out:$(Join-Path $out79 'RazielUpdater.exe')" @refs79 @core79 (Join-Path $source79 'Updater79.cs') (Join-Path $source79 'UpdateCore79.cs')
if($LASTEXITCODE-ne 0){throw 'Updater compile failed'}
& $csc79 /nologo /target:winexe /platform:x64 "/out:$(Join-Path $out79 'Uninstall R60.exe')" @refs79 "/win32manifest:$(Join-Path $source79 'setup.manifest')" (Join-Path $source79 'Uninstall60.cs') (Join-Path $source79 'InstallEngine60.cs') (Join-Path $source79 'PortableCore60.cs')
if($LASTEXITCODE-ne 0){throw 'Uninstaller compile failed'}
if($PayloadZip){
 $payload79=(Resolve-Path -LiteralPath $PayloadZip).Path
 & $csc79 /nologo /target:winexe /platform:x64 "/out:$(Join-Path $out79 'Raziel R79 Setup.exe')" @refs79 @core79 "/win32manifest:$(Join-Path $source79 'setup.manifest')" "/resource:$payload79,payload.zip" (Join-Path $source79 'Setup60.cs') (Join-Path $source79 'UpdateInstall79.cs') (Join-Path $source79 'InstallEngine60.cs')
 if($LASTEXITCODE-ne 0){throw 'Setup compile failed'}
}
