// SPDX-License-Identifier: GPL-3.0-or-later
internal static class ReleaseVersion79 {
 internal const int Number=79;
 internal const string Tag="R79";
}
