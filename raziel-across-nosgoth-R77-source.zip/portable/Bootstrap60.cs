// SPDX-License-Identifier: GPL-3.0-or-later
using System;using System.IO;using System.Diagnostics;using System.Drawing;using System.Text;using System.Runtime.InteropServices;using System.Threading;using System.Windows.Forms;using System.Web.Script.Serialization;
internal static class Bootstrap60 {
 [DllImport("user32.dll")]static extern short GetAsyncKeyState(int k);[DllImport("user32.dll")]static extern IntPtr GetForegroundWindow();[DllImport("user32.dll")]static extern uint GetWindowThreadProcessId(IntPtr h,out uint pid);
 static string root,data;static Process game,provider;static NotifyIcon tray;static Form guide;static Label shortcuts;static bool f7,lastGuide,waitingSelection;static System.Windows.Forms.Timer timer;static string donor="",lastError="",lastShortcut="";
 static bool guidePreview72;static Icon trayOn72,trayOff72;
 static Icon LoadIcon72(string name){using(var stream=typeof(Bootstrap60).Assembly.GetManifestResourceStream(name)){using(var icon=new Icon(stream))return (Icon)icon.Clone();}}
 [STAThread]static int Main(string[] args){
  try{
   if(args.Length==1&&args[0]=="--check"){if(!PortableCore60.Within(Path.GetTempPath(),Path.Combine(Path.GetTempPath(),"safe","file")))return 2;using(var stream=typeof(Bootstrap60).Assembly.GetManifestResourceStream("FieldGuide72")){if(stream==null)return 3;}using(var controls=CreateComboControls()){if(controls.Rows.Count!=14||controls.Columns.Count!=4)return 4;}Console.WriteLine("R77 bootstrap: artwork and all 14 combo mappings loaded.");return 0;}
   if(args.Length==3&&args[0]=="--guide-preview"){root=Path.GetFullPath(args[1]);guidePreview72=true;lastShortcut="R77 ready — F7 closes the guide. F10 toggles the mod.";Application.EnableVisualStyles();Application.SetCompatibleTextRenderingDefault(false);ToggleGuide();guide.ClientSize=new Size(1440,990);guide.StartPosition=FormStartPosition.Manual;guide.Location=new Point(-30000,-30000);guide.ShowInTaskbar=false;guide.Show();Application.DoEvents();guide.PerformLayout();guide.Refresh();using(var bitmap=new Bitmap(guide.Width,guide.Height)){guide.DrawToBitmap(bitmap,new Rectangle(Point.Empty,bitmap.Size));bitmap.Save(args[2],System.Drawing.Imaging.ImageFormat.Png);}guide.Hide();guide.Dispose();return 0;}
   int pid=0;for(int i=0;i+1<args.Length;i+=2){if(args[i]=="--pid")pid=Int32.Parse(args[i+1]);if(args[i]=="--root")root=Path.GetFullPath(args[i+1]);if(args[i]=="--data")data=Path.GetFullPath(args[i+1]);}
   if(pid<=0||String.IsNullOrEmpty(root)||String.IsNullOrEmpty(data))return 2;
   game=Process.GetProcessById(pid);if(!String.Equals(game.ProcessName,"SRX",StringComparison.OrdinalIgnoreCase))return 2;
   bool created;using(var mutex=new Mutex(true,"Local\\RazielR60Bootstrap-"+pid,out created)){if(!created)return 0;
    Directory.CreateDirectory(data);Application.EnableVisualStyles();Application.SetCompatibleTextRenderingDefault(false);
    trayOn72=LoadIcon72("ReaverOn72");trayOff72=LoadIcon72("ReaverOff72");tray=new NotifyIcon{Icon=trayOff72,Text="Raziel R77: loading resources",Visible=true};var menu=new ContextMenuStrip();menu.Items.Add("Field Guide (F7)",null,(s,e)=>ToggleGuide());menu.Items.Add("Toggle mod / F10",null,(s,e)=>Toggle(pid));menu.Items.Add("Open logs",null,(s,e)=>Process.Start("explorer.exe",PortableCore60.Quote(data)));tray.ContextMenuStrip=menu;tray.DoubleClick+=(s,e)=>ToggleGuide();
    donor=PortableCore60.ReadDonor();if(!PortableCore60.Donor(donor))donor=PortableCore60.Detect("Legacy of Kain Defiance Remastered");
    timer=new System.Windows.Forms.Timer{Interval=75};timer.Tick+=(s,e)=>Tick(pid);timer.Start();Application.Run();
    timer.Dispose();if(guide!=null)guide.Dispose();tray.Visible=false;tray.Dispose();trayOn72.Dispose();trayOff72.Dispose();menu.Dispose();if(provider!=null&&!provider.HasExited)provider.Kill();mutex.ReleaseMutex();
   }return 0;
  }catch(Exception ex){try{if(!String.IsNullOrEmpty(data))File.AppendAllText(Path.Combine(data,"bootstrap-errors.log"),ex+Environment.NewLine);}catch{}MessageBox.Show(ex.Message,"Raziel R77",MessageBoxButtons.OK,MessageBoxIcon.Error);return 1;}
 }
 static void Toggle(int pid){try{using(var ev=EventWaitHandle.OpenExisting("Local\\RazielR60Toggle-"+pid))ev.Set();}catch{}}
 static bool Sr1Loaded(){try{foreach(ProcessModule m in game.Modules)if(String.Equals(m.ModuleName,"sr1.dll",StringComparison.OrdinalIgnoreCase))return true;}catch{}return false;}
 static void Tick(int pid){
  if(game.HasExited){Application.ExitThread();return;}
  uint foreground;GetWindowThreadProcessId(GetForegroundWindow(),out foreground);bool down=(GetAsyncKeyState(0x76)&0x8000)!=0;
  if(down&&!f7&&(foreground==(uint)pid||foreground==(uint)Process.GetCurrentProcess().Id))ToggleGuide();f7=down;
  try{string status=File.ReadAllText(Path.Combine(data,"status.txt"),Encoding.UTF8);string caption="Raziel R77: "+status;tray.Text=caption.Substring(0,Math.Min(63,caption.Length));tray.Icon=status.StartsWith("On",StringComparison.Ordinal)?trayOn72:trayOff72;if(guide!=null&&guide.Visible)guide.Text="Raziel R77 — "+status;}catch{}
  try{string message=File.ReadAllText(Path.Combine(data,"shortcuts.txt"),Encoding.UTF8);if(message!=lastShortcut){lastShortcut=message;if(shortcuts!=null)shortcuts.Text=message;tray.ShowBalloonTip(2500,"Raziel shortcuts",message,ToolTipIcon.Info);}}catch{}
  if(provider==null&&!waitingSelection&&Sr1Loaded()){
   if(!PortableCore60.Donor(donor)){
    timer.Stop();using(var dialog=new FolderBrowserDialog{Description="Select your installed Defiance Remastered folder (contains defiance.exe and bigfile.x64.dat)."}){if(dialog.ShowDialog()==DialogResult.OK)donor=dialog.SelectedPath;}
    timer.Start();if(!PortableCore60.Donor(donor)){File.WriteAllText(Path.Combine(data,"status.txt"),"Defiance folder required — select it from the guide");waitingSelection=true;return;}
   }
   PortableCore60.SaveDonor(donor);string runtime=Path.Combine(root,"runtime"),node=Path.Combine(root,"node.exe"),host=Directory.GetParent(root).FullName;
   var start=new ProcessStartInfo(node,"--import "+PortableCore60.Quote(new Uri(Path.Combine(runtime,"portable-config60.mjs")).AbsoluteUri)+" "+PortableCore60.Quote(Path.Combine(runtime,"workbench","sr1-local-controller-test","serve-ground-poses.mjs"))+" "+pid+" --combat-r60"){UseShellExecute=false,CreateNoWindow=true,WorkingDirectory=runtime,RedirectStandardError=true,RedirectStandardOutput=true};
   start.EnvironmentVariables["RAZIEL_GAME_PATHS"]=new JavaScriptSerializer().Serialize(new{host=host,donor=donor});
   provider=new Process{StartInfo=start};provider.ErrorDataReceived+=(s,e)=>{if(e.Data!=null){lastError=e.Data;File.AppendAllText(Path.Combine(data,"provider.err"),e.Data+Environment.NewLine);}};provider.Start();provider.BeginErrorReadLine();provider.BeginOutputReadLine();File.WriteAllText(Path.Combine(data,"provider.json"),new JavaScriptSerializer().Serialize(new{pid=provider.Id,game=pid}));
  }
  if(provider!=null&&provider.HasExited&&provider.ExitCode!=0){File.WriteAllText(Path.Combine(data,"status.txt"),"Failed: resource provider — see provider.err");if(!lastGuide){lastGuide=true;MessageBox.Show("R77 could not load the installed game resources. Check the selected Defiance Remastered folder and provider.err. Restart SR1 after correcting the path.\n\n"+lastError,"Raziel R77",MessageBoxButtons.OK,MessageBoxIcon.Error);}}
 }
 static DataGridView CreateComboControls(){
  var grid=new DataGridView{Dock=DockStyle.Fill,ReadOnly=true,AllowUserToAddRows=false,AllowUserToDeleteRows=false,AllowUserToResizeRows=false,RowHeadersVisible=false,AutoSizeRowsMode=DataGridViewAutoSizeRowsMode.AllCells,AutoSizeColumnsMode=DataGridViewAutoSizeColumnsMode.Fill,BackgroundColor=Color.FromArgb(19,34,48),BorderStyle=BorderStyle.None};
  grid.DefaultCellStyle=new DataGridViewCellStyle{WrapMode=DataGridViewTriState.True,BackColor=grid.BackgroundColor,ForeColor=Color.White,SelectionBackColor=Color.FromArgb(42,71,87),Font=new Font("Segoe UI",10),Padding=new Padding(5)};
  using(var stream=typeof(Bootstrap60).Assembly.GetManifestResourceStream("ComboControls75"))
  using(var reader=new StreamReader(stream,Encoding.UTF8)){
   var headings=reader.ReadLine().Split('\t');foreach(string heading in headings)grid.Columns.Add(heading,heading);
   grid.Columns[3].FillWeight=170;
   string line;while((line=reader.ReadLine())!=null){if(line.Length!=0)grid.Rows.Add(line.Split('\t'));}
  }
  foreach(DataGridViewColumn col in grid.Columns)col.SortMode=DataGridViewColumnSortMode.NotSortable;
  return grid;
 }
 static void ToggleGuide(){
  if(guide!=null&&!guide.IsDisposed){if(guide.Visible){guide.Hide();return;}guide.Show();guide.Activate();return;}
  var area=Screen.FromPoint(Cursor.Position).WorkingArea;
  guide=new Form{Text="Raziel R77 — Field Guide",ClientSize=new Size(Math.Min(1440,area.Width-48),Math.Min(990,area.Height-90)),MinimumSize=new Size(800,560),StartPosition=FormStartPosition.CenterScreen,BackColor=Color.FromArgb(12,22,32),KeyPreview=true};
  Bitmap artwork;using(var stream=typeof(Bootstrap60).Assembly.GetManifestResourceStream("FieldGuide72")){using(var image=Image.FromStream(stream))artwork=new Bitmap(image);}
  var picture=new PictureBox{Dock=DockStyle.Fill,SizeMode=PictureBoxSizeMode.Zoom,Image=artwork};guide.Controls.Add(picture);guide.Disposed+=(s,e)=>artwork.Dispose();
  shortcuts=new Label{Text=lastShortcut,AutoEllipsis=true,Dock=DockStyle.Top,Height=36,ForeColor=Color.LightSkyBlue,Padding=new Padding(10,6,10,0)};guide.Controls.Add(shortcuts);
  var actions=new FlowLayoutPanel{Dock=DockStyle.Bottom,Height=42,Padding=new Padding(8,4,8,4)};
  var combos=new Button{Text="Combo controls",Width=150,Height=30,FlatStyle=FlatStyle.Flat,ForeColor=Color.White};
  combos.Click+=(s,e)=>{using(var detail=new Form{Text="Raziel — Combo controls",ClientSize=new Size(Math.Min(1100,area.Width-60),Math.Min(740,area.Height-90)),StartPosition=FormStartPosition.CenterParent,KeyPreview=true}){
   detail.Controls.Add(CreateComboControls());detail.KeyDown+=(sender,key)=>{if(key.KeyCode==Keys.Escape||key.KeyCode==Keys.F7)detail.Close();};detail.ShowDialog(guide);
  }};actions.Controls.Add(combos);
  var full=new Button{Text="Full guide",Width=180,Height=30,FlatStyle=FlatStyle.Flat,ForeColor=Color.White};full.Click+=(s,e)=>{using(var detail=new Form{Text="Raziel R77 — Complete Guide",Width=900,Height=740,StartPosition=FormStartPosition.CenterParent,BackColor=guide.BackColor}){detail.Controls.Add(new RichTextBox{Dock=DockStyle.Fill,ReadOnly=true,BackColor=guide.BackColor,ForeColor=Color.White,Font=new Font("Segoe UI",11),BorderStyle=BorderStyle.None,Text=File.ReadAllText(Path.Combine(root,"GUIDE.txt"),Encoding.UTF8)});detail.ShowDialog(guide);}};actions.Controls.Add(full);
  var choose=new Button{Text="Choose Defiance folder",Width=190,Height=30,FlatStyle=FlatStyle.Flat,ForeColor=Color.White};choose.Click+=(s,e)=>{using(var d=new FolderBrowserDialog{Description="Defiance Remastered folder",SelectedPath=donor})if(d.ShowDialog()==DialogResult.OK&&PortableCore60.Donor(d.SelectedPath)){donor=d.SelectedPath;waitingSelection=false;PortableCore60.SaveDonor(donor);MessageBox.Show("Folder saved. Restart SR1 if resource loading already failed.");}};actions.Controls.Add(choose);guide.Controls.Add(actions);
  guide.KeyDown+=(s,e)=>{if(e.KeyCode==Keys.Escape){guide.Hide();e.Handled=true;}};guide.FormClosing+=(s,e)=>{e.Cancel=true;guide.Hide();};if(!guidePreview72)guide.Show();
 }
}


