param([string]$Compiler='clang.exe')
$ErrorActionPreference='Stop'
Push-Location $PSScriptRoot
try {
 $destination77=Join-Path $PSScriptRoot 'workbench/sr1-local-controller-test/build/defiance-combat-r60'
 New-Item -ItemType Directory -Force -Path $destination77 | Out-Null
 $compileArgs=Get-Content -LiteralPath (Join-Path $PSScriptRoot 'compile-args.json') -Raw | ConvertFrom-Json
 & $Compiler @compileArgs
 if($LASTEXITCODE -ne 0){throw 'Native compilation failed'}
} finally { Pop-Location }
