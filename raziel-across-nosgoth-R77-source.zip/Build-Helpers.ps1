param([string]$PayloadZip)
$ErrorActionPreference='Stop'
$source73=Join-Path $PSScriptRoot 'portable'
$compiler77=Join-Path $env:WINDIR 'Microsoft.NET/Framework64/v4.0.30319/csc.exe'
$assets73=Join-Path $PSScriptRoot 'workbench/desktop-sr1-linked-r1/assets'
$out73=Join-Path $PSScriptRoot 'rebuilt-helpers'
New-Item -ItemType Directory -Force -Path $out73 | Out-Null
$refs73=@('/r:System.Windows.Forms.dll','/r:System.Drawing.dll','/r:System.Web.Extensions.dll','/r:System.Core.dll','/r:System.IO.Compression.dll','/r:System.IO.Compression.FileSystem.dll')
& $compiler77 /nologo /target:winexe /platform:x64 "/out:$(Join-Path $out73 'RazielBootstrap.exe')" @refs73 "/resource:$(Join-Path $source73 'combo-controls75.tsv'),ComboControls75" "/resource:$(Join-Path $source73 'assets/guide72.png'),FieldGuide72" "/resource:$(Join-Path $assets73 'reaver-light.ico'),ReaverOn72" "/resource:$(Join-Path $assets73 'reaver-dark.ico'),ReaverOff72" "$(Join-Path $source73 'Bootstrap60.cs')" "$(Join-Path $source73 'PortableCore60.cs')"
if($LASTEXITCODE-ne 0){throw 'Bootstrap compile failed'}
& $compiler77 /nologo /target:winexe /platform:x64 "/out:$(Join-Path $out73 'Uninstall R60.exe')" @refs73 "/win32manifest:$(Join-Path $source73 'setup.manifest')" "$(Join-Path $source73 'Uninstall60.cs')" "$(Join-Path $source73 'InstallEngine60.cs')" "$(Join-Path $source73 'PortableCore60.cs')"
if($LASTEXITCODE-ne 0){throw 'Uninstaller compile failed'}
if($PayloadZip){
 $payload73=(Resolve-Path -LiteralPath $PayloadZip).Path
 & $compiler77 /nologo /target:winexe /platform:x64 "/out:$(Join-Path $out73 'Raziel R77 Setup.exe')" @refs73 "/win32manifest:$(Join-Path $source73 'setup.manifest')" "/resource:$payload73,payload.zip" "$(Join-Path $source73 'Setup60.cs')" "$(Join-Path $source73 'InstallEngine60.cs')" "$(Join-Path $source73 'PortableCore60.cs')"
 if($LASTEXITCODE-ne 0){throw 'Setup compile failed'}
}
