// SPDX-License-Identifier: GPL-3.0-or-later
using System;using System.IO;using System.IO.Compression;using System.Linq;using System.Collections.Generic;using System.Web.Script.Serialization;
internal sealed class PackageFile60 { public string path;public string sha256; }
internal sealed class Package60 { public string version;public PackageFile60[] files; }
internal sealed class OwnedFile60 { public string path;public string installed;public string backup;public string before; }
internal sealed class Installation60 { public string root;public OwnedFile60[] files; }
internal static class InstallEngine60 {
 internal static string TestDataRoot60; static string DataRoot { get { return TestDataRoot60??PortableCore60.DataRoot; } }
 internal static readonly JavaScriptSerializer Json=new JavaScriptSerializer{MaxJsonLength=16*1024*1024};
 static string Safe(string root,string relative){if(String.IsNullOrWhiteSpace(relative)||relative.Contains(":")||relative.StartsWith("/")||relative.StartsWith("\\"))throw new IOException("Unsafe package path");string p=Path.GetFullPath(Path.Combine(root,relative.Replace('/',Path.DirectorySeparatorChar)));if(!PortableCore60.Within(root,p))throw new IOException("Package path escapes game folder");return p;}
 static bool Allowed(string s){return s=="winmm.dll"||s=="winmm.ini"||s=="scripts/SR1LocalController.asi"||s.StartsWith("RazielR60/",StringComparison.Ordinal);}
 internal static Installation60 Install(Stream payload,string root,string donor,bool verifyGames=true,int failAfter=-1){
  root=Path.GetFullPath(root);if(verifyGames&&(!PortableCore60.Host(root)||!PortableCore60.Donor(donor)||!PortableCore60.GamesClosed()))throw new IOException("Close both games and select the supported installed SR1 and Defiance folders.");
  var changes=new List<OwnedFile60>();string record=Path.Combine(root,"RazielR60","installed.json");Installation60 old=File.Exists(record)?Json.Deserialize<Installation60>(File.ReadAllText(record)):null;
  if(old!=null&&!String.Equals(Path.GetFullPath(old.root),root,StringComparison.OrdinalIgnoreCase))throw new IOException("Installation record belongs to another folder.");
  string backupRoot=Path.Combine(DataRoot,"install-backups",Guid.NewGuid().ToString("N"));
  using(var zip=new ZipArchive(payload,ZipArchiveMode.Read,true)){
   var manifest=zip.GetEntry("RazielR60/package.json");if(manifest==null)throw new IOException("Missing package manifest");Package60 pack;using(var r=new StreamReader(manifest.Open()))pack=Json.Deserialize<Package60>(r.ReadToEnd());
   if(pack.version!="R65")throw new IOException("Wrong package version");var entries=new Dictionary<string,ZipArchiveEntry>(StringComparer.OrdinalIgnoreCase);foreach(var e in zip.Entries){if(e.FullName.EndsWith("/"))continue;Safe(root,e.FullName);if(!Allowed(e.FullName)||entries.ContainsKey(e.FullName))throw new IOException("Unexpected/duplicate package path");entries.Add(e.FullName,e);}
   var listed=new HashSet<string>(StringComparer.OrdinalIgnoreCase);foreach(var f in pack.files){if(!Allowed(f.path)||!listed.Add(f.path)||!entries.ContainsKey(f.path))throw new IOException("Invalid package inventory");using(var h=System.Security.Cryptography.SHA256.Create())using(var s=entries[f.path].Open()){string actual=BitConverter.ToString(h.ComputeHash(s)).Replace("-","").ToLowerInvariant();if(actual!=f.sha256)throw new IOException("Package checksum failed: "+f.path);}}
   if(entries.Keys.Any(p=>p!="RazielR60/package.json"&&!listed.Contains(p)))throw new IOException("Unlisted package file");
   // Resolve every collision before the first game-folder write.
   foreach(var e in entries){string dest=Safe(root,e.Key);if(!File.Exists(dest))continue;string hash=PortableCore60.Hash(dest);var own=old==null?null:old.files.FirstOrDefault(f=>f.path==e.Key);bool same=listed.Contains(e.Key)&&pack.files.First(f=>f.path==e.Key).sha256==hash;
    bool loader=e.Key=="winmm.dll"&&hash=="031a3e5576d91dce1e438d36b9a3d462c7334ab4791990a8ff1e3ddc0e132daf";
    bool r59=e.Key=="scripts/SR1LocalController.asi"&&hash=="fa79f8a87fc38329da9b32421a7d3c34a27682f388c636fd1761ae19bdf90c6e";
    if(!same&&!loader&&!r59&&(own==null||own.installed!=hash))throw new IOException("Existing file is not owned by this package. Uninstall the earlier mod first: "+e.Key);
   }
   try{
    foreach(var e in entries){string dest=Safe(root,e.Key),before=File.Exists(dest)?PortableCore60.Hash(dest):null;var own=old==null?null:old.files.FirstOrDefault(f=>f.path==e.Key);
     if(e.Key=="winmm.dll"&&before=="031a3e5576d91dce1e438d36b9a3d462c7334ab4791990a8ff1e3ddc0e132daf"&&own==null)continue;
     string save=null;if(before!=null){save=Safe(backupRoot,e.Key);Directory.CreateDirectory(Path.GetDirectoryName(save));File.Copy(dest,save,false);}
     Directory.CreateDirectory(Path.GetDirectoryName(dest));using(var src=e.Value.Open())using(var dst=File.Create(dest))src.CopyTo(dst);
     changes.Add(new OwnedFile60{path=e.Key,installed=PortableCore60.Hash(dest),backup=save,before=before});
     if(failAfter>=0&&changes.Count>=failAfter)throw new IOException("Injected install failure for rollback test");
    }
    var permanent=changes.Select(f=>{var prior=old==null?null:old.files.FirstOrDefault(x=>x.path==f.path);return prior==null?f:new OwnedFile60{path=f.path,installed=f.installed,backup=prior.backup,before=prior.before};}).ToArray();
    var result=new Installation60{root=root,files=permanent};if(verifyGames)PortableCore60.SaveDonor(donor);File.WriteAllText(record,Json.Serialize(result));return result;
   }catch{for(int i=changes.Count-1;i>=0;i--){var f=changes[i];string dest=Safe(root,f.path);if(File.Exists(dest)&&PortableCore60.Hash(dest)==f.installed){if(f.backup==null)File.Delete(dest);else File.Copy(f.backup,dest,true);}}throw;}
  }
 }
 internal static string Uninstall(string root){root=Path.GetFullPath(root);if(!PortableCore60.GamesClosed())throw new IOException("Close SR1 and Defiance first.");string record=Path.Combine(root,"RazielR60","installed.json");if(!File.Exists(record))throw new IOException("No installer record. For a ZIP installation follow its README.");var data=Json.Deserialize<Installation60>(File.ReadAllText(record));if(!String.Equals(Path.GetFullPath(data.root),root,StringComparison.OrdinalIgnoreCase))throw new IOException("Installation root mismatch");var retained=new List<string>();foreach(var f in data.files.Reverse()){string dest=Safe(root,f.path);if(!File.Exists(dest))continue;if(PortableCore60.Hash(dest)!=f.installed){retained.Add(f.path);continue;}if(f.backup!=null){if(!PortableCore60.Within(Path.Combine(DataRoot,"install-backups"),f.backup)||!File.Exists(f.backup)||PortableCore60.Hash(f.backup)!=f.before)throw new IOException("Backup checksum failed: "+f.path);File.Copy(f.backup,dest,true);}else File.Delete(dest);}if(retained.Count==0)File.Delete(record);return retained.Count==0?"Mod removed. Original owned files restored. Saves were not changed.":"Modified files preserved: "+String.Join(", ",retained);}
}


